#!/usr/bin/env python
"""
Agent Registration & Connection Management — using okta-client-python SDK

This script demonstrates the full lifecycle of registering an AI agent,
managing connections (all three types), and performing XAA token exchange
using the official okta-client-python SDK.

Sections:
  1. SDK Setup — OAuth2Client with JWT bearer assertions
  2. Agent Registration — register, activate, add public key
  3. IDENTITY_ASSERTION_CUSTOM_AS — XAA token exchange via CrossAppAccessFlow
  4. STS_VAULT_SECRET — retrieve vaulted secrets from Okta PA
  5. STS_SERVICE_ACCOUNT — retrieve service account credentials from Okta PA
  6. Potential Connections Discovery — browse available connections
  7. Connection Lifecycle — create, activate, deactivate, delete

Prerequisites:
  pip install okta-client-python httpx python-jose

Environment:
  OKTA_DOMAIN=dev-xxx.okta.com
  OKTA_AI_AGENT_ID=agtXXXXXXXX
  OKTA_AI_AGENT_PRIVATE_KEY={"kty":"RSA","n":"...","e":"AQAB","d":"..."}
"""

import asyncio
import json
import os

# ============================================================================
# 1. SDK Setup — OAuth2Client with JWT Bearer Assertions
# ============================================================================

def create_oauth2_client():
    """Create an OAuth2Client configured with JWT bearer assertion auth.

    The official okta-client-python SDK uses:
    - LocalKeyProvider: holds the agent's private JWK
    - JWTBearerClaims: issuer=principalId, subject=principalId
    - ClientAssertionAuthorization: signs JWTs for client auth
    - OAuth2ClientConfiguration: binds it all together
    - OAuth2Client: the HTTP client for Okta APIs
    """
    from okta_client.authfoundation import (
        OAuth2Client, OAuth2ClientConfiguration, LocalKeyProvider
    )
    from okta_client.authfoundation.oauth2.jwt_bearer_claims import JWTBearerClaims
    from okta_client.authfoundation.oauth2.client_authorization import ClientAssertionAuthorization

    okta_domain = os.getenv("OKTA_DOMAIN", "dev-xxx.okta.com")
    if not okta_domain.startswith("https://"):
        okta_domain = f"https://{okta_domain}"

    principal_id = os.getenv("OKTA_AI_AGENT_ID", "agtXXXXXXXX")
    private_key_json = os.getenv("OKTA_AI_AGENT_PRIVATE_KEY", "{}")
    private_key = json.loads(private_key_json)

    # 1. Key provider from agent's private JWK (stored encrypted in DB)
    key_provider = LocalKeyProvider(
        key=private_key,
        algorithm=private_key.get("alg", "RS256"),
        key_id=private_key.get("kid"),
    )

    # 2. JWT bearer claims — principalId as issuer + subject
    jwt_claims = JWTBearerClaims(
        issuer=principal_id,
        subject=principal_id,
        audience=f"{okta_domain}/oauth2/v1/token",
        expires_in=300,
    )

    # 3. Client assertion authorization
    client_auth = ClientAssertionAuthorization(
        assertion_claims=jwt_claims,
        key_provider=key_provider,
    )

    # 4. Configuration
    config = OAuth2ClientConfiguration(
        issuer=okta_domain,
        client_authorization=client_auth,
    )

    # 5. OAuth2 client
    return OAuth2Client(configuration=config)


# ============================================================================
# 2. Agent Registration
# ============================================================================

async def demo_agent_registration():
    """Register a new AI agent via the Okta Workload Principals API.

    Uses OktaAIAgentClient (our wrapper around the Okta REST API).
    The registration is async — returns 202 Accepted, then we poll.
    """
    from okta_agent_proxy.auth.okta_ai_agent_client import OktaAIAgentClient

    client = OktaAIAgentClient()

    # Register agent (async operation — polls until complete)
    agent = await client.register_agent(
        app_id="0oaYourOIDCAppId",
        name="My AI Assistant",
        description="AI assistant for internal tools",
        okta_token="your-admin-okta-token",
    )
    print(f"Agent registered: {agent}")

    # Activate the agent
    await client.activate_agent(agent["id"], okta_token="your-admin-okta-token")

    # Add a public key for JWT verification
    public_jwk = {
        "kty": "RSA",
        "use": "sig",
        "alg": "RS256",
        "kid": "my-key-1",
        "n": "...",
        "e": "AQAB",
    }
    await client.add_public_key(agent["id"], public_jwk, okta_token="your-admin-okta-token")

    return agent


# ============================================================================
# 3. IDENTITY_ASSERTION_CUSTOM_AS — CrossAppAccessFlow
# ============================================================================

async def demo_xaa_token_exchange():
    """Exchange a user's ID token for a backend access token using
    the CrossAppAccessFlow from okta-client-python.

    This is the ID-JAG (Identity Assertion JWT Authorization Grant) pattern:
    1. flow.start(token=user_id_token) — exchanges for ID-JAG
    2. flow.resume() — exchanges ID-JAG for backend access token
    """
    from okta_client.oauth2auth import CrossAppAccessFlow, CrossAppAccessTarget

    okta_domain = os.getenv("OKTA_DOMAIN", "dev-xxx.okta.com")
    if not okta_domain.startswith("https://"):
        okta_domain = f"https://{okta_domain}"

    # Create OAuth2Client (reuse from section 1)
    oauth2_client = create_oauth2_client()

    # Target: the authorization server protecting the backend
    target = CrossAppAccessTarget(
        issuer=f"{okta_domain}/oauth2/ausYourAuthServerId"
    )

    # Create the flow
    flow = CrossAppAccessFlow(client=oauth2_client, target=target)

    # Step 1+2: Exchange user ID token for ID-JAG
    user_id_token = "eyJ..."  # From user's Okta session
    start_result = await flow.start(token=user_id_token, scope=["mcp:read"])

    # The ID-JAG is at flow.context.id_jag_token
    id_jag = flow.context.id_jag_token
    print(f"ID-JAG token obtained, expires_in={id_jag.expires_in}s")

    # Step 3: Exchange ID-JAG for backend access token
    backend_token = await flow.resume()
    print(f"Backend token: {backend_token.access_token[:20]}...")
    print(f"Expires in: {backend_token.expires_in}s")
    print(f"Scope: {backend_token.scope}")

    return backend_token


# ============================================================================
# 4. STS_VAULT_SECRET — Retrieve Vaulted Secrets
# ============================================================================

async def demo_vault_secret():
    """Retrieve a secret from Okta Privileged Access via an STS_VAULT_SECRET connection.

    Connection shape from Okta API:
    {
        "connectionType": "STS_VAULT_SECRET",
        "secret": {
            "orn": "orn:okta:pam:00o...:secrets:d2642f68-...",
            "name": "slack-api-key",
            "path": "/vault/integrations/slack"
        }
    }

    The OktaSecretsClient retrieves the actual secret value at runtime.
    """
    from okta_agent_proxy.auth.okta_secrets_client import OktaSecretsClient

    client = OktaSecretsClient()

    # Retrieve secret value
    result = await client.get_vault_secret(
        agent_id="agtYourAgentId",
        connection_id="connYourConnectionId",
        okta_token="your-admin-okta-token",  # or None for service auth
    )

    if result:
        print(f"Secret name: {result.get('name')}")
        print(f"Secret path: {result.get('path')}")
        print(f"Secret value: {result.get('value', '')[:5]}...")  # Redacted
    else:
        print("Failed to retrieve secret")

    return result


# ============================================================================
# 5. STS_SERVICE_ACCOUNT — Retrieve Service Account Credentials
# ============================================================================

async def demo_service_account():
    """Retrieve service account credentials from Okta Privileged Access
    via an STS_SERVICE_ACCOUNT connection.

    Connection shape from Okta API:
    {
        "connectionType": "STS_SERVICE_ACCOUNT",
        "serviceAccount": {
            "orn": "orn:okta:pam:00o...:service_accounts:4923897d-...",
            "name": "jira-bot"
        },
        "app": {
            "orn": "orn:okta:idp:00o...:apps:jira:0oa..."
        }
    }

    The OktaSecretsClient retrieves username/password at runtime.
    """
    from okta_agent_proxy.auth.okta_secrets_client import OktaSecretsClient

    client = OktaSecretsClient()

    # Retrieve service account credentials
    result = await client.get_service_account_credentials(
        agent_id="agtYourAgentId",
        connection_id="connYourConnectionId",
    )

    if result:
        print(f"Username: {result.get('username')}")
        print(f"App: {result.get('app_name')}")
        # Password is used for Basic Auth — never log it
    else:
        print("Failed to retrieve credentials")

    return result


# ============================================================================
# 6. Potential Connections Discovery
# ============================================================================

async def demo_potential_connections():
    """Discover available connections that can be added to an agent.

    The Potential Connections API returns resources the agent *could*
    connect to, filtered by connection type.
    """
    from okta_agent_proxy.auth.okta_ai_agent_client import OktaAIAgentClient

    client = OktaAIAgentClient()
    okta_token = "your-admin-okta-token"

    # List available authorization servers
    auth_servers = await client.list_potential_connections(
        connection_type="IDENTITY_ASSERTION_CUSTOM_AS",
        okta_token=okta_token,
    )
    print(f"Available auth servers: {len(auth_servers)}")

    # List available vault secrets (with fuzzy search)
    secrets = await client.list_potential_connections(
        connection_type="STS_VAULT_SECRET",
        match="slack",  # fuzzy search, 3-50 chars
        okta_token=okta_token,
    )
    print(f"Matching secrets: {len(secrets)}")

    # List available service accounts
    svc_accounts = await client.list_potential_connections(
        connection_type="STS_SERVICE_ACCOUNT",
        okta_token=okta_token,
    )
    print(f"Available service accounts: {len(svc_accounts)}")


# ============================================================================
# 7. Connection Lifecycle — Create, Activate, Deactivate, Delete
# ============================================================================

async def demo_connection_lifecycle():
    """Full connection lifecycle: create, activate, deactivate, delete.

    Each connection type has a different payload shape.
    """
    from okta_agent_proxy.auth.okta_ai_agent_client import OktaAIAgentClient

    client = OktaAIAgentClient()
    agent_id = "agtYourAgentId"
    okta_token = "your-admin-okta-token"

    # --- Create IDENTITY_ASSERTION_CUSTOM_AS connection ---
    ia_conn = await client.create_connection(agent_id, {
        "connectionType": "IDENTITY_ASSERTION_CUSTOM_AS",
        "authorizationServer": {
            "orn": "orn:okta:idp:00o...:authorization_servers:aus..."
        },
        "scopeCondition": "INCLUDE_ONLY",
        "scopes": ["mcp:read", "mcp:write"],
    }, okta_token)
    print(f"Created IA connection: {ia_conn.get('id')}")

    # --- Create STS_VAULT_SECRET connection ---
    vs_conn = await client.create_connection(agent_id, {
        "connectionType": "STS_VAULT_SECRET",
        "secret": {
            "orn": "orn:okta:pam:00o...:secrets:uuid-..."
        },
    }, okta_token)
    print(f"Created vault secret connection: {vs_conn.get('id')}")

    # --- Create STS_SERVICE_ACCOUNT connection ---
    sa_conn = await client.create_connection(agent_id, {
        "connectionType": "STS_SERVICE_ACCOUNT",
        "serviceAccount": {
            "orn": "orn:okta:pam:00o...:service_accounts:uuid-..."
        },
        "app": {
            "orn": "orn:okta:idp:00o...:apps:jira:0oa..."
        },
    }, okta_token)
    print(f"Created service account connection: {sa_conn.get('id')}")

    # --- Lifecycle operations ---
    conn_id = ia_conn.get("id")

    # Deactivate
    await client.deactivate_connection(agent_id, conn_id, okta_token)
    print(f"Deactivated connection {conn_id}")

    # Re-activate
    await client.activate_connection(agent_id, conn_id, okta_token)
    print(f"Re-activated connection {conn_id}")

    # Update scope condition (IDENTITY_ASSERTION_CUSTOM_AS only)
    await client.update_connection(agent_id, conn_id, {
        "scopeCondition": "DISALLOW",
        "scopes": ["admin:write"],
    }, okta_token)
    print(f"Updated scopes on connection {conn_id}")

    # Delete
    await client.delete_connection(agent_id, conn_id, okta_token)
    print(f"Deleted connection {conn_id}")


# ============================================================================
# Main
# ============================================================================

if __name__ == "__main__":
    print("=" * 70)
    print("Okta Agent Registration & Connection Management")
    print("Using okta-client-python SDK")
    print("=" * 70)
    print()
    print("This script contains runnable demo functions.")
    print("Import and call them individually, or set environment variables")
    print("and uncomment the asyncio.run() calls below.")
    print()
    print("Functions:")
    print("  create_oauth2_client()           — SDK setup")
    print("  demo_agent_registration()        — Register + activate agent")
    print("  demo_xaa_token_exchange()        — CrossAppAccessFlow (ID-JAG)")
    print("  demo_vault_secret()              — STS_VAULT_SECRET retrieval")
    print("  demo_service_account()           — STS_SERVICE_ACCOUNT retrieval")
    print("  demo_potential_connections()      — Browse available connections")
    print("  demo_connection_lifecycle()       — Create/activate/deactivate/delete")

    # Uncomment to run:
    # asyncio.run(demo_agent_registration())
    # asyncio.run(demo_xaa_token_exchange())
    # asyncio.run(demo_vault_secret())
    # asyncio.run(demo_service_account())
    # asyncio.run(demo_potential_connections())
    # asyncio.run(demo_connection_lifecycle())
