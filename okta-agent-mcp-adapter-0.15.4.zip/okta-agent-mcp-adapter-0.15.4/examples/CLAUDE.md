# CLAUDE.md - Examples Directory

This file provides guidance to Claude Code when working with the example MCP servers in this directory.

## Overview

The `examples/` directory contains reference implementations of MCP backend servers that demonstrate different authentication patterns with the Okta MCP Adapter gateway.

## Tool Registry

This registry catalogs all MCP tools available across all example servers. Use this as a quick reference when working with or testing the examples.

### 01-hr-system

**Port:** 8001
**Path:** `/hr`
**Auth:** Pre-Shared Key (PSK)
**Status:** Active

Tools:
- `health_check() -> str` - Health check endpoint returning service status
- `get_employee(employee_id: str) -> dict` - Retrieve employee details by ID
- `search_employees(query: str, department: str = None) -> list[dict]` - Search employees by name or department
- `get_org_chart(employee_id: str = None) -> dict` - Get organizational chart (reports tree)
- `get_leave_balance(employee_id: str) -> dict` - Get employee's leave balance and history
- `submit_leave_request(employee_id: str, leave_type: str, start_date: str, end_date: str, reason: str) -> dict` - Submit a leave request

### 05-deploy-server

**Port:** 8005
**Path:** `/deploy`
**Auth:** `okta-cross-app` (ID-JAG) — `okta-ai-sdk` `verify_auth_server_token()`, `privateJWK=None`
**Status:** Active
**Config:** `auth_method: okta-cross-app` (stored id_token -> ID-JAG -> AT-2)

Tools:
- `health_check() -> dict` - Health check endpoint returning service status (no auth)
- `get_deployments(service: str, env: str = "prod") -> list` - List recent deployments for a service. Status: success/failed/rolled_back/in_progress
- `get_deploy_logs(deploy_id: str, lines: int = 50) -> dict` - Retrieve CI/CD build/deploy logs for a specific deployment
- `rollback_deployment(service: str, env: str, reason: str) -> dict` - Initiate a rollback to previous version. Returns rollback_id and initiated_by (from token sub claim). Logs warning if mcp:write scope missing
- `get_env_config(service: str, env: str = "prod") -> dict` - Retrieve environment config with redacted secret keys (demonstrates backend-enforced authz post-XAA)
- `get_service_health(service: str, env: str = "prod") -> dict` - Check health status (healthy/degraded/unhealthy), replicas, CPU, memory, endpoint latency

Services: `api-gateway`, `user-service`, `payment-service`, `notification-service`, `search-service`
Environments: `prod`, `staging`, `dev` (or `all` for get_deployments)

### 02-finance-system (Planned)

**Port:** 8002
**Path:** `/finance`
**Auth:** OAuth2 Cross-App (ID-JAG)
**Status:** Planned

Tools: TBD

### 03-analytics-system (Planned)

**Port:** 8003
**Path:** `/analytics`
**Auth:** Service Account
**Status:** Planned

Tools: TBD

### 04-ticketing-system (Planned)

**Port:** 8004
**Path:** `/ticketing`
**Auth:** Pre-Shared Key (PSK)
**Status:** Planned

Tools: TBD

## Testing Commands

### Run Tests for Specific Example

```bash
# HR System
cd examples/01-hr-system
pytest tests/ -v

# With coverage
pytest tests/ -v --cov=. --cov-report=html
```

### Run Tests for All Examples

```bash
# From repo root
pytest examples/*/tests/ -v
```

### Run Specific Test

```bash
pytest examples/01-hr-system/tests/test_hr_server.py::test_health_check -v
```

## Development Commands

### Start Example Server Locally

```bash
cd examples/01-hr-system
export PSK_SECRET="your-secret-key-here"
export LOG_LEVEL="DEBUG"
python server.py
```

### Start with Docker Compose

```bash
cd examples/01-hr-system
docker compose up --build
```

### View Logs

```bash
docker compose logs -f hr-mcp-server
docker compose logs -f gateway
```

### Stop Services

```bash
docker compose down
```

## Authentication Patterns

### Pre-Shared Key (PSK) - 01-hr-system

**Implementation Pattern:**

```python
import os
from fastmcp import Context

PSK_SECRET = os.getenv("PSK_SECRET")

@mcp.tool()
def my_tool(ctx: Context, param: str) -> str:
    """Tool description."""
    # Validate X-API-Key header
    request = ctx.request
    api_key = request.headers.get("x-api-key")

    if not api_key or api_key != PSK_SECRET:
        raise ValueError("Invalid or missing API key")

    # Tool logic here
    return result
```

**Key Points:**
- Gateway adds `X-API-Key` header before proxying
- Backend validates header on every tool call
- Backend does NOT need Okta integration
- Secret shared between gateway and backend (via env vars)

### OAuth2 Cross-App (ID-JAG) - 02-finance-system

**Implementation Pattern:**

```python
from fastmcp import Context
import jwt

@mcp.tool()
def my_tool(ctx: Context, param: str) -> str:
    """Tool description."""
    # Extract and validate Bearer token
    request = ctx.request
    auth_header = request.headers.get("authorization")

    if not auth_header or not auth_header.startswith("Bearer "):
        raise ValueError("Missing or invalid authorization header")

    token = auth_header[7:]

    # Validate JWT (verify signature, expiration, audience)
    # This requires backend OAuth server setup
    decoded = jwt.decode(token, ...)

    # Tool logic here
    return result
```

**Key Points:**
- Gateway performs ID-JAG token exchange
- Backend receives standard OAuth2 Bearer token
- Backend validates token against its own auth server
- Supports cross-org authentication (Okta → Okta)

### Service Account - 03-analytics-system

**Implementation Pattern:**

```python
import base64
from fastmcp import Context

SERVICE_USERNAME = os.getenv("SERVICE_USERNAME")
SERVICE_PASSWORD = os.getenv("SERVICE_PASSWORD")

@mcp.tool()
def my_tool(ctx: Context, param: str) -> str:
    """Tool description."""
    # Extract and validate Basic Auth
    request = ctx.request
    auth_header = request.headers.get("authorization")

    if not auth_header or not auth_header.startswith("Basic "):
        raise ValueError("Missing or invalid authorization header")

    encoded_creds = auth_header[6:]
    decoded_creds = base64.b64decode(encoded_creds).decode()
    username, password = decoded_creds.split(":", 1)

    if username != SERVICE_USERNAME or password != SERVICE_PASSWORD:
        raise ValueError("Invalid credentials")

    # Tool logic here
    return result
```

**Key Points:**
- Gateway adds HTTP Basic Auth header
- Backend validates username/password
- No per-user attribution (all requests use service account)
- Simple but less secure than OAuth

## File Structure

Each example MUST follow this structure:

```
examples/
├── README.md                      # Master catalog and port registry
├── CLAUDE.md                      # This file - tool registry and dev guide
└── ##-service-name/               # Example directory (e.g., 01-hr-system)
    ├── README.md                  # Example-specific documentation
    ├── server.py                  # FastMCP server implementation
    ├── requirements.txt           # Python dependencies
    ├── Dockerfile                 # Container build
    ├── docker-compose.yml         # Multi-service orchestration
    ├── .env.example               # Environment variables template
    ├── config/
    │   └── gateway-backend.yml    # Backend config snippet for gateway
    └── tests/
        └── test_<service>_server.py  # Pytest test suite
```

## Common Issues

### Server Won't Start

**Check:**
1. Port not already in use: `lsof -i :8001`
2. Environment variables set: `echo $PSK_SECRET`
3. Dependencies installed: `pip install -r requirements.txt`
4. Python version: `python --version` (3.12+ recommended)

### Tests Failing

**Check:**
1. Server is running: `curl http://localhost:8001/health`
2. PSK_SECRET matches in tests and server
3. Using pytest-asyncio: `@pytest.mark.asyncio`
4. Async client context: `async with Client(...) as client:`

### Docker Issues

**Check:**
1. Network exists: `docker network ls | grep mcp-examples-net`
2. Create if missing: `docker network create mcp-examples-net`
3. Services on same network in docker-compose.yml
4. Health checks passing: `docker compose ps`

### Gateway Can't Reach Backend

**Check:**
1. Service name matches in gateway config and docker-compose
2. Both services on `mcp-examples-net` network
3. Backend is healthy: `docker compose logs hr-mcp-server`
4. Port is correct in gateway config

## Adding New Tools to Existing Example

When adding a new tool to an existing example server:

1. **Add tool function in server.py:**

```python
@mcp.tool()
def new_tool(ctx: Context, param: str) -> dict:
    """Clear description of what this tool does.

    Args:
        param: Description of parameter

    Returns:
        Description of return value
    """
    # Validate authentication (same pattern as other tools)
    validate_api_key(ctx)

    # Tool logic
    result = {"status": "success", "data": param}
    return result
```

2. **Add test in test_<service>_server.py:**

```python
@pytest.mark.asyncio
async def test_new_tool():
    async with Client("http://localhost:8001") as client:
        result = await client.call_tool(
            "new_tool",
            param="test_value",
            headers={"X-API-Key": PSK_SECRET}
        )
        assert result["status"] == "success"
```

3. **Update tool registry in this file (CLAUDE.md)**

4. **Update example README.md with usage example**

5. **Run tests to verify:**

```bash
pytest tests/test_hr_server.py::test_new_tool -v
```

## Mock Data Guidelines

When creating mock data for examples:

1. **Realistic:** Use plausible names, departments, dates
2. **Diverse:** Include variety (departments, hierarchies, statuses)
3. **Interconnected:** Show relationships (manager-report, dependencies)
4. **Demonstrable:** Design data to showcase tool capabilities
5. **Consistent:** Same employee IDs across different tools

**Example:**

```python
MOCK_EMPLOYEES = {
    "E001": {
        "id": "E001",
        "name": "Sarah Chen",
        "department": "Engineering",
        "manager_id": None,  # CEO
        "title": "Chief Technology Officer"
    },
    "E002": {
        "id": "E002",
        "name": "Marcus Johnson",
        "department": "Engineering",
        "manager_id": "E001",  # Reports to Sarah
        "title": "Senior Software Engineer"
    }
}
```

## Transport Requirement

**CRITICAL:** All examples MUST use Streamable HTTP transport.

```python
# CORRECT
mcp.run(transport="streamable-http", host="0.0.0.0", port=8001)

# WRONG - Don't use these
mcp.run(transport="stdio")  # Can't be hosted remotely
mcp.run(transport="sse")    # Deprecated in MCP spec
```

Streamable HTTP allows:
- Remote hosting in Docker containers
- Standard HTTP/HTTPS connectivity
- Compatibility with all MCP clients
- Easy integration with gateway proxy

## Environment Variables

Standard environment variables across all examples:

```bash
# Authentication (varies by example)
PSK_SECRET=<pre-shared-key>              # PSK examples
SERVICE_USERNAME=<username>              # Service account examples
SERVICE_PASSWORD=<password>              # Service account examples
OAUTH_CLIENT_ID=<id>                     # OAuth examples
OAUTH_CLIENT_SECRET=<secret>             # OAuth examples

# Logging
LOG_LEVEL=INFO                           # DEBUG, INFO, WARNING, ERROR

# Server Configuration
SERVER_HOST=0.0.0.0                      # Listen address
SERVER_PORT=8001                         # Service port (from registry)
TIMEOUT_SECONDS=30                       # Request timeout
```

## Validation Checklist

Before marking an example as complete, verify:

- [ ] Port allocated in examples/README.md registry
- [ ] Tool registry entry in this file (CLAUDE.md)
- [ ] FastMCP uses streamable-http transport
- [ ] Authentication validation in ALL tools
- [ ] Realistic mock data demonstrating value
- [ ] Dockerfile uses non-root user
- [ ] docker-compose.yml uses mcp-examples-net network
- [ ] Health check implemented
- [ ] All environment variables in .env.example
- [ ] No hardcoded secrets
- [ ] Comprehensive test coverage (90%+)
- [ ] Tests use pytest.mark.asyncio
- [ ] README with architecture diagram
- [ ] requirements.txt with pinned versions

## Performance Considerations

When implementing example servers:

1. **Keep tools fast:** Aim for <100ms response time
2. **Use in-memory data:** Don't require external databases for examples
3. **Cache when possible:** Store computed results if expensive
4. **Limit data size:** Return reasonable amounts of data (not massive JSON)
5. **Implement timeouts:** Don't let tools hang indefinitely

## Security Notes

Examples are for demonstration purposes:

1. **Not production-ready:** These examples prioritize clarity over security
2. **No rate limiting:** Implement rate limiting for production use
3. **No input sanitization:** Add proper validation for production
4. **Mock data only:** Don't use real employee/customer data
5. **Rotate secrets:** Change PSK secrets regularly in production

## Resources

- FastMCP: https://github.com/jlowin/fastmcp
- MCP Spec: https://spec.modelcontextprotocol.io/
- Docker Compose: https://docs.docker.com/compose/
- Pytest-asyncio: https://pytest-asyncio.readthedocs.io/
