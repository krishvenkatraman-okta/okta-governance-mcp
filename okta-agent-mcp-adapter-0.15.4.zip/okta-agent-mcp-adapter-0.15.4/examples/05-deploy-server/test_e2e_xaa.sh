#!/usr/bin/env bash
# ============================================================================
# test_e2e_xaa.sh — End-to-End XAA Flow Validation (Unified MCP Endpoint)
# ============================================================================
#
# Validates the complete 4-step Cross-App Access flow through the gateway's
# unified MCP endpoint (POST /):
#
#   Step 1: Gateway validates user's Okta JWT
#   Step 2: Gateway checks agent authorization (backend_access list)
#   Step 3: Gateway issues ID-JAG JWT, exchanges it at Org B's token endpoint
#   Step 4: Backend validates the received Bearer token (okta-jwt-verifier)
#   Step 5: Tool executes and returns result
#
# If all 5 tool calls succeed, the entire 4-step SDK chain is validated.
#
# Usage:
#   USER_TOKEN="eyJ..." ./test_e2e_xaa.sh
#   USER_TOKEN="eyJ..." ./test_e2e_xaa.sh --verbose
#
# ============================================================================

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# Configuration
GATEWAY_URL="${GATEWAY_URL:-http://localhost:8000}"
DEPLOY_URL="${DEPLOY_URL:-http://localhost:8005}"
AGENT_ID="${AGENT_ID:-claude-code}"
VERBOSE=false
JSONRPC_ID=1

# Colors
if [ -t 1 ]; then
    GREEN='\033[0;32m'; RED='\033[0;31m'; YELLOW='\033[1;33m'
    CYAN='\033[0;36m'; BOLD='\033[1m'; NC='\033[0m'
else
    GREEN=''; RED=''; YELLOW=''; CYAN=''; BOLD=''; NC=''
fi

# Parse flags
for arg in "$@"; do
    case "$arg" in
        --verbose|-v) VERBOSE=true ;;
        --help|-h)
            echo "Usage: USER_TOKEN=\"eyJ...\" $0 [--verbose]"
            echo ""
            echo "Environment variables:"
            echo "  USER_TOKEN     (required) Okta JWT for the test user"
            echo "  GATEWAY_URL    Gateway endpoint (default: http://localhost:8000)"
            echo "  DEPLOY_URL     Deploy server endpoint (default: http://localhost:8005)"
            echo "  AGENT_ID       Agent ID for X-MCP-Agent header (default: claude-code)"
            exit 0
            ;;
    esac
done

# Counters
PASS=0; FAIL=0; TOTAL=0
RESULTS=()
START_TIME=$(date +%s)

info()  { echo -e "${CYAN}[INFO]${NC}  $*"; }
pass()  { echo -e "${GREEN}[PASS]${NC}  $*"; ((PASS++)); ((TOTAL++)); }
fail()  { echo -e "${RED}[FAIL]${NC}  $*"; ((FAIL++)); ((TOTAL++)); }
warn()  { echo -e "${YELLOW}[WARN]${NC}  $*"; }

# ---------------------------------------------------------------------------
# JSON-RPC helper
# ---------------------------------------------------------------------------
call_tool() {
    local tool_name="$1"
    local params="$2"
    local label="$3"
    local id=$((JSONRPC_ID++))

    local body
    body=$(cat <<EOF
{"jsonrpc":"2.0","method":"tools/call","params":{"name":"deploy-server__${tool_name}","arguments":${params}},"id":${id}}
EOF
)

    if $VERBOSE; then
        echo -e "${CYAN}>>> Request:${NC}"
        echo "$body" | python3 -m json.tool 2>/dev/null || echo "$body"
    fi

    local tool_start
    tool_start=$(python3 -c "import time; print(int(time.time()*1000))")

    local http_code response
    response=$(curl -s -w "\n%{http_code}" \
        -X POST "${GATEWAY_URL}/" \
        -H "Content-Type: application/json" \
        -H "Authorization: Bearer ${USER_TOKEN}" \
        -H "X-MCP-Agent: ${AGENT_ID}" \
        -d "$body" 2>&1)

    http_code=$(echo "$response" | tail -1)
    local body_resp
    body_resp=$(echo "$response" | sed '$d')

    local tool_end
    tool_end=$(python3 -c "import time; print(int(time.time()*1000))")
    local elapsed=$(( tool_end - tool_start ))

    if $VERBOSE; then
        echo -e "${CYAN}<<< Response (HTTP ${http_code}, ${elapsed}ms):${NC}"
        echo "$body_resp" | python3 -m json.tool 2>/dev/null || echo "$body_resp"
        echo ""
    fi

    # Classify result
    if [[ "$http_code" == "200" ]]; then
        # Check for JSON-RPC error in response body
        local has_error
        has_error=$(echo "$body_resp" | python3 -c "
import sys, json
try:
    data = json.load(sys.stdin)
    if 'error' in data:
        msg = data['error'].get('message', 'unknown error')
        print(f'error:{msg}')
    elif 'result' in data:
        print('ok')
    else:
        print('ok')
except:
    print('parse_error')
" 2>/dev/null || echo "parse_error")

        if [[ "$has_error" == "ok" ]]; then
            pass "${label} (${elapsed}ms)"
            RESULTS+=("PASS|${label}|${elapsed}ms")
        elif [[ "$has_error" == parse_error ]]; then
            fail "${label} — could not parse response (${elapsed}ms)"
            RESULTS+=("FAIL|${label}|parse error")
        else
            local err_msg="${has_error#error:}"
            # Classify the error
            if echo "$err_msg" | grep -qi "authorization\|token\|bearer\|401\|forbidden"; then
                fail "${label} — auth error: ${err_msg} (${elapsed}ms)"
                warn "  Hint: Check token validity and agent backend_access list"
                RESULTS+=("FAIL|${label}|auth: ${err_msg}")
            else
                fail "${label} — tool error: ${err_msg} (${elapsed}ms)"
                RESULTS+=("FAIL|${label}|tool: ${err_msg}")
            fi
        fi
    elif [[ "$http_code" == "401" || "$http_code" == "403" ]]; then
        fail "${label} — gateway auth failure (HTTP ${http_code}, ${elapsed}ms)"
        warn "  Hint: Steps 1-3 failed. Check USER_TOKEN validity and OKTA_DOMAIN config"
        RESULTS+=("FAIL|${label}|gateway auth (HTTP ${http_code})")
    elif [[ "$http_code" == "502" || "$http_code" == "504" ]]; then
        fail "${label} — gateway proxy failure (HTTP ${http_code}, ${elapsed}ms)"
        warn "  Hint: Token exchange (Step 3) may have failed. Check gateway logs for ID-JAG errors"
        RESULTS+=("FAIL|${label}|proxy (HTTP ${http_code})")
    else
        fail "${label} — unexpected HTTP ${http_code} (${elapsed}ms)"
        RESULTS+=("FAIL|${label}|HTTP ${http_code}")
    fi
}

# ============================================================================
# Pre-flight checks
# ============================================================================

echo ""
echo -e "${BOLD}============================================${NC}"
echo -e "${BOLD} XAA End-to-End Test — Unified Endpoint    ${NC}"
echo -e "${BOLD}============================================${NC}"
echo ""

# Check USER_TOKEN
if [[ -z "${USER_TOKEN:-}" ]]; then
    echo -e "${RED}ERROR: USER_TOKEN environment variable is required${NC}"
    echo ""
    echo "Obtain a token from your Okta org and run:"
    echo "  USER_TOKEN=\"eyJ...\" $0"
    echo ""
    echo "For dev/testing with auth disabled on the gateway, you can use any string:"
    echo "  USER_TOKEN=\"test\" $0"
    exit 1
fi

info "Gateway:  ${GATEWAY_URL}"
info "Backend:  ${DEPLOY_URL}"
info "Agent:    ${AGENT_ID}"
info "Verbose:  ${VERBOSE}"
echo ""

# Step 1: Gateway health
info "Checking gateway health..."
gw_status=$(curl -s -o /dev/null -w "%{http_code}" "${GATEWAY_URL}/.well-known/oauth-protected-resource" 2>/dev/null || echo "000")
if [[ "$gw_status" == "200" ]]; then
    pass "Gateway is reachable (${GATEWAY_URL})"
else
    fail "Gateway not reachable (HTTP ${gw_status})"
    echo -e "${RED}Cannot continue without gateway. Start with: ./start.sh${NC}"
    exit 1
fi

# Step 2: Deploy server health
info "Checking deploy server health..."
ds_status=$(curl -s -o /dev/null -w "%{http_code}" "${DEPLOY_URL}/" 2>/dev/null || echo "000")
if [[ "$ds_status" == "200" || "$ds_status" == "405" ]]; then
    pass "Deploy server is reachable (${DEPLOY_URL})"
else
    fail "Deploy server not reachable (HTTP ${ds_status})"
    echo -e "${RED}Cannot continue without deploy server.${NC}"
    exit 1
fi

# ============================================================================
# MCP Initialize handshake
# ============================================================================

echo ""
info "Initializing MCP session..."
init_body='{"jsonrpc":"2.0","method":"initialize","params":{"protocolVersion":"2025-03-26","capabilities":{},"clientInfo":{"name":"e2e-test","version":"1.0"}},"id":0}'
init_resp=$(curl -s -w "\n%{http_code}" \
    -X POST "${GATEWAY_URL}/" \
    -H "Content-Type: application/json" \
    -H "X-MCP-Agent: ${AGENT_ID}" \
    -d "$init_body" 2>&1)
init_code=$(echo "$init_resp" | tail -1)
if [[ "$init_code" == "200" ]]; then
    pass "MCP initialize handshake"
else
    fail "MCP initialize returned HTTP ${init_code}"
    warn "  Hint: The unified endpoint may not be configured"
fi

# ============================================================================
# Tool calls — each validates the full 4-step XAA flow
# ============================================================================

echo ""
info "Calling tools through gateway (each call validates 4-step XAA)..."
echo ""

# Tool 1: get_deployments
call_tool "get_deployments" \
    '{"service":"api-gateway","env":"prod"}' \
    "get_deployments(api-gateway, prod)"

# Tool 2: get_deploy_logs
call_tool "get_deploy_logs" \
    '{"deploy_id":"dep-1f64","lines":10}' \
    "get_deploy_logs(dep-1f64)"

# Tool 3: rollback_deployment
call_tool "rollback_deployment" \
    '{"service":"user-service","env":"staging","reason":"E2E test rollback"}' \
    "rollback_deployment(user-service, staging)"

# Tool 4: get_env_config
call_tool "get_env_config" \
    '{"service":"payment-service","env":"prod"}' \
    "get_env_config(payment-service, prod)"

# Tool 5: get_service_health
call_tool "get_service_health" \
    '{"service":"notification-service","env":"prod"}' \
    "get_service_health(notification-service, prod)"

# ============================================================================
# Summary
# ============================================================================

END_TIME=$(date +%s)
ELAPSED=$(( END_TIME - START_TIME ))

echo ""
echo -e "${BOLD}============================================${NC}"
echo -e "${BOLD} Summary                                    ${NC}"
echo -e "${BOLD}============================================${NC}"
echo ""
printf "  %-45s %s\n" "Test" "Result"
printf "  %-45s %s\n" "----" "------"
for r in "${RESULTS[@]}"; do
    IFS='|' read -r status label detail <<< "$r"
    if [[ "$status" == "PASS" ]]; then
        printf "  %-45s ${GREEN}PASS${NC} %s\n" "$label" "$detail"
    else
        printf "  %-45s ${RED}FAIL${NC} %s\n" "$label" "$detail"
    fi
done
echo ""
echo -e "  Total: ${TOTAL}  |  ${GREEN}Passed: ${PASS}${NC}  |  ${RED}Failed: ${FAIL}${NC}  |  Time: ${ELAPSED}s"
echo ""

if [[ $FAIL -eq 0 ]]; then
    echo -e "${GREEN}${BOLD}All 4 XAA steps validated end-to-end.${NC}"
    echo -e "${GREEN}XAA chain: ID-JAG issue → token exchange → bearer validation (okta-jwt-verifier)${NC}"
else
    echo -e "${RED}${BOLD}Some tests failed. Check hints above for debugging.${NC}"
    exit 1
fi
