#!/usr/bin/env bash
# ============================================================================
# test_e2e_xaa_path.sh — End-to-End XAA Flow (Path-Based Proxy Route)
# ============================================================================
#
# Same XAA validation as test_e2e_xaa.sh but uses the path-based proxy route
# (POST /deploy) instead of the unified MCP endpoint (POST /).
#
# This validates that:
#   1. Path-based routing correctly maps /deploy → deploy-server backend
#   2. The full 4-step XAA flow works through the ProxyHandler path
#   3. Tool names are NOT namespaced (sent as-is, e.g., "get_deployments")
#
# Usage:
#   USER_TOKEN="eyJ..." ./test_e2e_xaa_path.sh
#   USER_TOKEN="eyJ..." ./test_e2e_xaa_path.sh --verbose
#
# ============================================================================

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# Configuration
GATEWAY_URL="${GATEWAY_URL:-http://localhost:8000}"
DEPLOY_URL="${DEPLOY_URL:-http://localhost:8005}"
AGENT_ID="${AGENT_ID:-claude-code}"
VERBOSE=false
JSONRPC_ID=1

# Colors
if [ -t 1 ]; then
    GREEN='\033[0;32m'; RED='\033[0;31m'; YELLOW='\033[1;33m'
    CYAN='\033[0;36m'; BOLD='\033[1m'; NC='\033[0m'
else
    GREEN=''; RED=''; YELLOW=''; CYAN=''; BOLD=''; NC=''
fi

# Parse flags
for arg in "$@"; do
    case "$arg" in
        --verbose|-v) VERBOSE=true ;;
        --help|-h)
            echo "Usage: USER_TOKEN=\"eyJ...\" $0 [--verbose]"
            echo ""
            echo "Same as test_e2e_xaa.sh but uses path-based route (POST /deploy)"
            echo "instead of the unified MCP endpoint (POST /)."
            exit 0
            ;;
    esac
done

# Counters
PASS=0; FAIL=0; TOTAL=0
RESULTS=()
START_TIME=$(date +%s)

info()  { echo -e "${CYAN}[INFO]${NC}  $*"; }
pass()  { echo -e "${GREEN}[PASS]${NC}  $*"; ((PASS++)); ((TOTAL++)); }
fail()  { echo -e "${RED}[FAIL]${NC}  $*"; ((FAIL++)); ((TOTAL++)); }
warn()  { echo -e "${YELLOW}[WARN]${NC}  $*"; }

# ---------------------------------------------------------------------------
# JSON-RPC helper — uses /deploy path (no namespace prefix on tool names)
# ---------------------------------------------------------------------------
call_tool() {
    local tool_name="$1"
    local params="$2"
    local label="$3"
    local id=$((JSONRPC_ID++))

    # Path-based proxy: tool names are NOT namespaced
    local body
    body=$(cat <<EOF
{"jsonrpc":"2.0","method":"tools/call","params":{"name":"${tool_name}","arguments":${params}},"id":${id}}
EOF
)

    if $VERBOSE; then
        echo -e "${CYAN}>>> Request (POST /deploy):${NC}"
        echo "$body" | python3 -m json.tool 2>/dev/null || echo "$body"
    fi

    local tool_start
    tool_start=$(python3 -c "import time; print(int(time.time()*1000))")

    local http_code response
    response=$(curl -s -w "\n%{http_code}" \
        -X POST "${GATEWAY_URL}/deploy" \
        -H "Content-Type: application/json" \
        -H "Authorization: Bearer ${USER_TOKEN}" \
        -H "X-MCP-Agent: ${AGENT_ID}" \
        -d "$body" 2>&1)

    http_code=$(echo "$response" | tail -1)
    local body_resp
    body_resp=$(echo "$response" | sed '$d')

    local tool_end
    tool_end=$(python3 -c "import time; print(int(time.time()*1000))")
    local elapsed=$(( tool_end - tool_start ))

    if $VERBOSE; then
        echo -e "${CYAN}<<< Response (HTTP ${http_code}, ${elapsed}ms):${NC}"
        echo "$body_resp" | python3 -m json.tool 2>/dev/null || echo "$body_resp"
        echo ""
    fi

    # Classify result
    if [[ "$http_code" == "200" ]]; then
        local has_error
        has_error=$(echo "$body_resp" | python3 -c "
import sys, json
try:
    data = json.load(sys.stdin)
    if 'error' in data:
        msg = data['error'].get('message', 'unknown error')
        print(f'error:{msg}')
    elif 'result' in data:
        print('ok')
    else:
        print('ok')
except:
    print('parse_error')
" 2>/dev/null || echo "parse_error")

        if [[ "$has_error" == "ok" ]]; then
            pass "${label} (${elapsed}ms)"
            RESULTS+=("PASS|${label}|${elapsed}ms")
        elif [[ "$has_error" == parse_error ]]; then
            fail "${label} — could not parse response (${elapsed}ms)"
            RESULTS+=("FAIL|${label}|parse error")
        else
            local err_msg="${has_error#error:}"
            if echo "$err_msg" | grep -qi "authorization\|token\|bearer\|401\|forbidden"; then
                fail "${label} — auth error: ${err_msg} (${elapsed}ms)"
                warn "  Hint: Token validation failed. Check Step 4 (backend token verification)"
                RESULTS+=("FAIL|${label}|auth: ${err_msg}")
            else
                fail "${label} — tool error: ${err_msg} (${elapsed}ms)"
                RESULTS+=("FAIL|${label}|tool: ${err_msg}")
            fi
        fi
    elif [[ "$http_code" == "401" || "$http_code" == "403" ]]; then
        fail "${label} — gateway auth failure (HTTP ${http_code}, ${elapsed}ms)"
        warn "  Hint: Steps 1-3 failed. Check USER_TOKEN and OKTA_DOMAIN"
        RESULTS+=("FAIL|${label}|gateway auth (HTTP ${http_code})")
    elif [[ "$http_code" == "404" ]]; then
        fail "${label} — route not found (HTTP 404, ${elapsed}ms)"
        warn "  Hint: /deploy path not registered. Run seed_deploy_backend.py or check gateway config"
        RESULTS+=("FAIL|${label}|route not found")
    elif [[ "$http_code" == "502" || "$http_code" == "504" ]]; then
        fail "${label} — gateway proxy failure (HTTP ${http_code}, ${elapsed}ms)"
        warn "  Hint: ID-JAG exchange (Step 3) may have failed. Check gateway logs"
        RESULTS+=("FAIL|${label}|proxy (HTTP ${http_code})")
    else
        fail "${label} — unexpected HTTP ${http_code} (${elapsed}ms)"
        RESULTS+=("FAIL|${label}|HTTP ${http_code}")
    fi
}

# ============================================================================
# Pre-flight checks
# ============================================================================

echo ""
echo -e "${BOLD}============================================${NC}"
echo -e "${BOLD} XAA End-to-End Test — Path-Based Route     ${NC}"
echo -e "${BOLD} POST /deploy (ProxyHandler)                ${NC}"
echo -e "${BOLD}============================================${NC}"
echo ""

# Check USER_TOKEN
if [[ -z "${USER_TOKEN:-}" ]]; then
    echo -e "${RED}ERROR: USER_TOKEN environment variable is required${NC}"
    echo ""
    echo "  USER_TOKEN=\"eyJ...\" $0"
    exit 1
fi

info "Gateway:  ${GATEWAY_URL}"
info "Route:    POST /deploy"
info "Agent:    ${AGENT_ID}"
info "Verbose:  ${VERBOSE}"
echo ""

# Gateway health
info "Checking gateway health..."
gw_status=$(curl -s -o /dev/null -w "%{http_code}" "${GATEWAY_URL}/.well-known/oauth-protected-resource" 2>/dev/null || echo "000")
if [[ "$gw_status" == "200" ]]; then
    pass "Gateway is reachable"
else
    fail "Gateway not reachable (HTTP ${gw_status})"
    exit 1
fi

# Deploy server health
info "Checking deploy server health..."
ds_status=$(curl -s -o /dev/null -w "%{http_code}" "${DEPLOY_URL}/" 2>/dev/null || echo "000")
if [[ "$ds_status" == "200" || "$ds_status" == "405" ]]; then
    pass "Deploy server is reachable"
else
    fail "Deploy server not reachable (HTTP ${ds_status})"
    exit 1
fi

# ============================================================================
# MCP Initialize handshake on /deploy path
# ============================================================================

echo ""
info "Initializing MCP session on /deploy..."
init_body='{"jsonrpc":"2.0","method":"initialize","params":{"protocolVersion":"2025-03-26","capabilities":{},"clientInfo":{"name":"e2e-test","version":"1.0"}},"id":0}'
init_resp=$(curl -s -w "\n%{http_code}" \
    -X POST "${GATEWAY_URL}/deploy" \
    -H "Content-Type: application/json" \
    -H "Authorization: Bearer ${USER_TOKEN}" \
    -H "X-MCP-Agent: ${AGENT_ID}" \
    -d "$init_body" 2>&1)
init_code=$(echo "$init_resp" | tail -1)
if [[ "$init_code" == "200" ]]; then
    pass "MCP initialize on /deploy"
else
    warn "MCP initialize on /deploy returned HTTP ${init_code} (may be expected if proxy forwards directly)"
fi

# ============================================================================
# Tool calls — path-based (no namespace prefix)
# ============================================================================

echo ""
info "Calling tools via POST /deploy (path-based proxy)..."
echo ""

call_tool "get_deployments" \
    '{"service":"api-gateway","env":"prod"}' \
    "get_deployments(api-gateway, prod)"

call_tool "get_deploy_logs" \
    '{"deploy_id":"dep-1f64","lines":10}' \
    "get_deploy_logs(dep-1f64)"

call_tool "rollback_deployment" \
    '{"service":"user-service","env":"staging","reason":"E2E path test"}' \
    "rollback_deployment(user-service, staging)"

call_tool "get_env_config" \
    '{"service":"payment-service","env":"prod"}' \
    "get_env_config(payment-service, prod)"

call_tool "get_service_health" \
    '{"service":"notification-service","env":"prod"}' \
    "get_service_health(notification-service, prod)"

# ============================================================================
# Summary
# ============================================================================

END_TIME=$(date +%s)
ELAPSED=$(( END_TIME - START_TIME ))

echo ""
echo -e "${BOLD}============================================${NC}"
echo -e "${BOLD} Summary (Path-Based Route)                 ${NC}"
echo -e "${BOLD}============================================${NC}"
echo ""
printf "  %-45s %s\n" "Test" "Result"
printf "  %-45s %s\n" "----" "------"
for r in "${RESULTS[@]}"; do
    IFS='|' read -r status label detail <<< "$r"
    if [[ "$status" == "PASS" ]]; then
        printf "  %-45s ${GREEN}PASS${NC} %s\n" "$label" "$detail"
    else
        printf "  %-45s ${RED}FAIL${NC} %s\n" "$label" "$detail"
    fi
done
echo ""
echo -e "  Total: ${TOTAL}  |  ${GREEN}Passed: ${PASS}${NC}  |  ${RED}Failed: ${FAIL}${NC}  |  Time: ${ELAPSED}s"
echo ""

if [[ $FAIL -eq 0 ]]; then
    echo -e "${GREEN}${BOLD}Path-based XAA flow validated.${NC}"
else
    echo -e "${RED}${BOLD}Some tests failed.${NC}"
    exit 1
fi
