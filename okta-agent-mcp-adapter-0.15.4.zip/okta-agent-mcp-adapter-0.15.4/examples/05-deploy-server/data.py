"""
Data Engine — Deterministic deployment data generation for demos.

Produces consistent, cross-referenced deployment data using a fixed random seed.
All data is generated at import time and remains stable across server restarts.

Classes:
    ServiceTopology  — Service definitions, versions, dependencies, resource profiles
    DeploymentHistory — 18 deployments across 7 days with realistic status distribution
    LogGenerator     — CI/CD log output correlated with deployment status
    EnvConfigStore   — Per-service, per-environment configuration with redacted secrets
"""

import hashlib
import random
from datetime import datetime, timedelta
from typing import Any, Dict, List, Optional

# Fixed seed for deterministic data generation
_RNG = random.Random(42)

# Reference timestamp — all times are relative to this
_NOW = datetime(2026, 3, 9, 14, 30, 0)

# Deployer pool
DEPLOYERS = [
    "j.chen@acme.dev",
    "s.patel@acme.dev",
    "m.johnson@acme.dev",
    "a.garcia@acme.dev",
    "r.kim@acme.dev",
    "l.santos@acme.dev",
]


def _commit_sha(seed: str) -> str:
    """Generate a deterministic 7-char commit SHA from a seed string."""
    return hashlib.sha256(seed.encode()).hexdigest()[:7]


def _deploy_id(index: int) -> str:
    """Generate a deterministic deploy ID."""
    h = hashlib.md5(f"deploy-{index}".encode()).hexdigest()[:4]
    return f"dep-{h}"


# ============================================================================
# ServiceTopology
# ============================================================================

class ServiceTopology:
    """Defines the simulated microservice infrastructure.

    5 services with version history, environments, replica profiles,
    and dependency relationships.
    """

    SERVICES: Dict[str, Dict[str, Any]] = {
        "api-gateway": {
            "current_version": {"prod": "4.2.1", "staging": "4.3.0-rc2", "dev": "4.3.0-dev.7"},
            "previous_version": {"prod": "4.2.0", "staging": "4.2.1", "dev": "4.3.0-dev.6"},
            "replicas": {"prod": 4, "staging": 2, "dev": 1},
            "base_cpu": 35.0,
            "base_memory_mb": 320,
            "health_endpoints": ["/gateway/health", "/gateway/readiness"],
            "dependencies": ["user-service", "payment-service", "notification-service"],
            "registry": "registry.acme.dev/api-gateway",
        },
        "user-service": {
            "current_version": {"prod": "2.11.0", "staging": "2.12.0-rc1", "dev": "2.12.0-dev.3"},
            "previous_version": {"prod": "2.10.4", "staging": "2.11.0", "dev": "2.12.0-dev.2"},
            "replicas": {"prod": 3, "staging": 2, "dev": 1},
            "base_cpu": 28.0,
            "base_memory_mb": 256,
            "health_endpoints": ["/users/health"],
            "dependencies": ["search-service"],
            "registry": "registry.acme.dev/user-service",
        },
        "payment-service": {
            "current_version": {"prod": "3.7.2", "staging": "3.8.0-rc1", "dev": "3.8.0-dev.5"},
            "previous_version": {"prod": "3.7.1", "staging": "3.7.2", "dev": "3.8.0-dev.4"},
            "replicas": {"prod": 3, "staging": 2, "dev": 1},
            "base_cpu": 45.0,
            "base_memory_mb": 384,
            "health_endpoints": ["/payments/health", "/payments/validate"],
            "dependencies": ["user-service", "notification-service"],
            "registry": "registry.acme.dev/payment-service",
        },
        "notification-service": {
            "current_version": {"prod": "1.14.0", "staging": "1.15.0-rc1", "dev": "1.15.0-dev.2"},
            "previous_version": {"prod": "1.13.3", "staging": "1.14.0", "dev": "1.15.0-dev.1"},
            "replicas": {"prod": 4, "staging": 2, "dev": 1},
            "base_cpu": 52.0,
            "base_memory_mb": 448,
            "health_endpoints": ["/notifications/health", "/notifications/queue"],
            "dependencies": [],
            "registry": "registry.acme.dev/notification-service",
        },
        "search-service": {
            "current_version": {"prod": "1.5.0", "staging": "1.6.0-rc1", "dev": "1.6.0-dev.4"},
            "previous_version": {"prod": "1.4.8", "staging": "1.5.0", "dev": "1.6.0-dev.3"},
            "replicas": {"prod": 2, "staging": 1, "dev": 1},
            "base_cpu": 62.0,
            "base_memory_mb": 512,
            "health_endpoints": ["/search/health"],
            "dependencies": [],
            "registry": "registry.acme.dev/search-service",
        },
    }

    @classmethod
    def get_service(cls, name: str) -> Optional[Dict[str, Any]]:
        return cls.SERVICES.get(name)

    @classmethod
    def list_services(cls) -> List[str]:
        return list(cls.SERVICES.keys())

    @classmethod
    def get_version(cls, service: str, env: str) -> Optional[str]:
        svc = cls.SERVICES.get(service)
        if not svc:
            return None
        return svc["current_version"].get(env)

    @classmethod
    def get_previous_version(cls, service: str, env: str) -> Optional[str]:
        svc = cls.SERVICES.get(service)
        if not svc:
            return None
        return svc["previous_version"].get(env)


# ============================================================================
# DeploymentHistory
# ============================================================================

class DeploymentHistory:
    """Pre-generated deployment history: 18 deployments over the past 7 days.

    Status distribution: ~70% success, ~15% failed, ~10% rolled_back, ~5% in_progress.
    Deployments are cross-referenced with ServiceTopology versions.
    """

    def __init__(self):
        self._deployments: List[Dict[str, Any]] = []
        self._by_service: Dict[str, List[Dict[str, Any]]] = {}
        self._by_id: Dict[str, Dict[str, Any]] = {}
        self._generate()

    def _generate(self):
        rng = random.Random(42)

        # Define deployments with controlled status distribution
        # Format: (service, env, version, status, hours_ago, deployer_idx)
        deploy_specs = [
            # api-gateway — 4 deploys
            ("api-gateway", "prod", "4.2.1", "success", 3, 0),
            ("api-gateway", "prod", "4.2.0", "success", 72, 2),
            ("api-gateway", "staging", "4.3.0-rc2", "in_progress", 0.5, 0),
            ("api-gateway", "staging", "4.3.0-rc1", "success", 48, 1),
            # user-service — 4 deploys
            ("user-service", "prod", "2.11.0", "success", 8, 1),
            ("user-service", "prod", "2.10.4", "success", 120, 3),
            ("user-service", "staging", "2.12.0-rc1", "success", 24, 1),
            ("user-service", "dev", "2.12.0-dev.3", "success", 2, 4),
            # payment-service — 4 deploys
            ("payment-service", "prod", "3.7.2", "success", 12, 2),
            ("payment-service", "prod", "3.7.1", "failed", 36, 5),
            ("payment-service", "staging", "3.8.0-rc1", "rolled_back", 6, 2),
            ("payment-service", "dev", "3.8.0-dev.5", "success", 1, 4),
            # notification-service — 4 deploys
            ("notification-service", "prod", "1.14.0", "rolled_back", 4, 3),
            ("notification-service", "prod", "1.13.3", "success", 96, 0),
            ("notification-service", "staging", "1.15.0-rc1", "failed", 18, 5),
            ("notification-service", "dev", "1.15.0-dev.2", "success", 1.5, 4),
            # search-service — 2 deploys
            ("search-service", "prod", "1.5.0", "success", 48, 3),
            ("search-service", "staging", "1.6.0-rc1", "success", 20, 1),
        ]

        for i, (service, env, version, status, hours_ago, deployer_idx) in enumerate(deploy_specs):
            dep_id = _deploy_id(i)
            dep = {
                "deploy_id": dep_id,
                "service": service,
                "environment": env,
                "version": version,
                "status": status,
                "deployed_by": DEPLOYERS[deployer_idx],
                "deployed_at": (_NOW - timedelta(hours=hours_ago)).isoformat() + "Z",
                "commit_sha": _commit_sha(f"{service}-{version}"),
            }
            self._deployments.append(dep)
            self._by_service.setdefault(service, []).append(dep)
            self._by_id[dep_id] = dep

    def get_deployments(self, service: str, env: str = "prod") -> List[Dict[str, Any]]:
        deploys = self._by_service.get(service, [])
        if env != "all":
            deploys = [d for d in deploys if d["environment"] == env]
        return deploys

    def get_deployment(self, deploy_id: str) -> Optional[Dict[str, Any]]:
        return self._by_id.get(deploy_id)

    def list_deploy_ids(self) -> List[str]:
        return list(self._by_id.keys())

    def get_latest_deploy(self, service: str, env: str) -> Optional[Dict[str, Any]]:
        """Get the most recent deployment for a service/env (by hours_ago, i.e., first in list)."""
        deploys = self.get_deployments(service, env)
        return deploys[0] if deploys else None


# ============================================================================
# LogGenerator
# ============================================================================

class LogGenerator:
    """Generates realistic CI/CD log output correlated with deployment status."""

    def __init__(self, history: DeploymentHistory):
        self._logs: Dict[str, List[str]] = {}
        self._generate(history)

    def _generate(self, history: DeploymentHistory):
        for dep_id in history.list_deploy_ids():
            dep = history.get_deployment(dep_id)
            svc = ServiceTopology.get_service(dep["service"])
            registry = svc["registry"] if svc else f"registry.acme.dev/{dep['service']}"
            replicas = svc["replicas"].get(dep["environment"], 2) if svc else 2

            if dep["status"] == "success":
                self._logs[dep_id] = self._success_logs(dep, registry, replicas)
            elif dep["status"] == "failed":
                self._logs[dep_id] = self._failed_logs(dep, registry, replicas)
            elif dep["status"] == "rolled_back":
                self._logs[dep_id] = self._rollback_logs(dep, registry, replicas)
            elif dep["status"] == "in_progress":
                self._logs[dep_id] = self._in_progress_logs(dep, registry, replicas)

    def _success_logs(self, dep: dict, registry: str, replicas: int) -> List[str]:
        svc, ver, sha = dep["service"], dep["version"], dep["commit_sha"]
        env_label = f" to {dep['environment']}" if dep["environment"] != "prod" else ""
        lines = [
            f"[00:00] Starting deployment of {svc} v{ver}{env_label}",
            f"[00:01] Pulling container image: {registry}:{ver}",
            f"[00:03] Image pulled successfully (sha256:{sha}...)",
            f"[00:04] Running pre-deploy health checks...",
            f"[00:05] Health checks passed ({replicas}/{replicas} endpoints healthy)",
        ]
        for r in range(1, replicas + 1):
            lines.append(f"[00:{5 + r:02d}] Rolling update: {r}/{replicas} pods updated")
        t = 6 + replicas
        lines.extend([
            f"[00:{t:02d}] Running post-deploy validation...",
            f"[00:{t + 1:02d}] All health endpoints returning 200 OK",
            f"[00:{t + 2:02d}] Deployment complete. All {replicas} pods running v{ver}",
            f"[00:{t + 2:02d}] Metrics: p99 latency=38ms, error_rate=0.02%",
        ])
        return lines

    def _failed_logs(self, dep: dict, registry: str, replicas: int) -> List[str]:
        svc, ver, sha = dep["service"], dep["version"], dep["commit_sha"]
        prev = ServiceTopology.get_previous_version(dep["service"], dep["environment"]) or "unknown"
        lines = [
            f"[00:00] Starting deployment of {svc} v{ver}",
            f"[00:01] Pulling container image: {registry}:{ver}",
            f"[00:02] Image pulled successfully (sha256:{sha}...)",
            f"[00:03] Rolling update: 1/{replicas} pods updated",
            f"[00:04] Readiness probe failed: /health returned 503",
            f"[00:05] ERROR: Pod {svc}-pod-{sha[:4]} CrashLoopBackOff",
            f"[00:06] ERROR: OOMKilled — container exceeded memory limit (512Mi)",
            f"[00:07] Auto-rollback triggered: reverting to v{prev}",
            f"[00:08] Rollback complete. Running v{prev}",
            f"[00:08] Deployment marked as FAILED",
        ]
        return lines

    def _rollback_logs(self, dep: dict, registry: str, replicas: int) -> List[str]:
        svc, ver, sha = dep["service"], dep["version"], dep["commit_sha"]
        prev = ServiceTopology.get_previous_version(dep["service"], dep["environment"]) or "unknown"
        lines = [
            f"[00:00] Starting deployment of {svc} v{ver}",
            f"[00:01] Pulling container image: {registry}:{ver}",
            f"[00:03] Image pulled successfully (sha256:{sha}...)",
        ]
        mid = replicas // 2 or 1
        for r in range(1, mid + 1):
            lines.append(f"[00:{3 + r:02d}] Rolling update: {r}/{replicas} pods updated")
        t = 4 + mid
        lines.extend([
            f"[00:{t:02d}] WARNING: Error rate spike detected (4.8% > threshold 1.0%)",
            f"[00:{t + 1:02d}] WARNING: p99 latency 920ms > threshold 200ms",
            f"[00:{t + 2:02d}] Auto-rollback initiated: reverting to v{prev}",
        ])
        for r in range(1, mid + 1):
            lines.append(f"[00:{t + 2 + r:02d}] Rolling back: {r}/{replicas} pods reverted")
        lines.append(f"[00:{t + 3 + mid:02d}] Rollback complete. All {replicas} pods running v{prev}")
        return lines

    def _in_progress_logs(self, dep: dict, registry: str, replicas: int) -> List[str]:
        svc, ver, sha = dep["service"], dep["version"], dep["commit_sha"]
        env_label = f" to {dep['environment']}" if dep["environment"] != "prod" else ""
        lines = [
            f"[00:00] Starting deployment of {svc} v{ver}{env_label}",
            f"[00:01] Pulling container image: {registry}:{ver}",
            f"[00:03] Image pulled successfully (sha256:{sha}...)",
            f"[00:04] Running database migration: 0057_add_rate_limit_table.sql",
            f"[00:05] Migration applied (1 table created, 2 indexes added)",
            f"[00:06] Rolling update: 1/{replicas} pods updated",
            f"[00:07] Waiting for readiness probe...",
        ]
        return lines

    def get_logs(self, deploy_id: str) -> Optional[List[str]]:
        return self._logs.get(deploy_id)


# ============================================================================
# EnvConfigStore
# ============================================================================

class EnvConfigStore:
    """Per-service, per-environment configuration with redacted secret keys.

    Configs vary by environment: dev uses DEBUG logging, staging uses INFO,
    prod uses WARN. Feature flags differ across environments to simulate
    progressive rollout.
    """

    _CONFIGS: Dict[str, Dict[str, Dict[str, Any]]] = {
        "api-gateway": {
            "prod": {
                "config": {
                    "LOG_LEVEL": "WARN",
                    "RATE_LIMIT_RPM": "2000",
                    "CORS_ORIGINS": "https://app.acme.dev,https://admin.acme.dev",
                    "CIRCUIT_BREAKER_THRESHOLD": "5",
                    "MAX_REQUEST_SIZE_MB": "10",
                    "FEATURE_FLAGS": "graphql_v2=true,websocket_proxy=false",
                    "UPSTREAM_TIMEOUT_MS": "5000",
                    "RETRY_POLICY": "exponential_backoff",
                },
                "redacted_keys": ["TLS_PRIVATE_KEY", "JWT_SIGNING_SECRET", "DATABASE_URL"],
                "last_updated": (_NOW - timedelta(hours=3)).isoformat() + "Z",
                "updated_by": "j.chen@acme.dev",
            },
            "staging": {
                "config": {
                    "LOG_LEVEL": "INFO",
                    "RATE_LIMIT_RPM": "10000",
                    "CORS_ORIGINS": "*",
                    "CIRCUIT_BREAKER_THRESHOLD": "10",
                    "MAX_REQUEST_SIZE_MB": "50",
                    "FEATURE_FLAGS": "graphql_v2=true,websocket_proxy=true",
                    "UPSTREAM_TIMEOUT_MS": "10000",
                    "RETRY_POLICY": "immediate",
                },
                "redacted_keys": ["TLS_PRIVATE_KEY", "JWT_SIGNING_SECRET", "DATABASE_URL"],
                "last_updated": (_NOW - timedelta(hours=1)).isoformat() + "Z",
                "updated_by": "s.patel@acme.dev",
            },
            "dev": {
                "config": {
                    "LOG_LEVEL": "DEBUG",
                    "RATE_LIMIT_RPM": "99999",
                    "CORS_ORIGINS": "*",
                    "CIRCUIT_BREAKER_THRESHOLD": "100",
                    "MAX_REQUEST_SIZE_MB": "100",
                    "FEATURE_FLAGS": "graphql_v2=true,websocket_proxy=true,debug_panel=true",
                    "UPSTREAM_TIMEOUT_MS": "30000",
                    "RETRY_POLICY": "none",
                },
                "redacted_keys": ["DATABASE_URL"],
                "last_updated": (_NOW - timedelta(hours=2)).isoformat() + "Z",
                "updated_by": "r.kim@acme.dev",
            },
        },
        "user-service": {
            "prod": {
                "config": {
                    "LOG_LEVEL": "WARN",
                    "DATABASE_POOL_SIZE": "20",
                    "CACHE_TTL": "600",
                    "SESSION_TIMEOUT_SECONDS": "3600",
                    "MAX_LOGIN_ATTEMPTS": "5",
                    "FEATURE_FLAGS": "sso_v2=true,profile_photos=true,mfa_required=true",
                    "PASSWORD_MIN_LENGTH": "12",
                    "ACCOUNT_LOCKOUT_MINUTES": "30",
                },
                "redacted_keys": ["DATABASE_URL", "OKTA_API_TOKEN", "HMAC_SECRET", "ENCRYPTION_KEY"],
                "last_updated": (_NOW - timedelta(hours=8)).isoformat() + "Z",
                "updated_by": "s.patel@acme.dev",
            },
            "staging": {
                "config": {
                    "LOG_LEVEL": "INFO",
                    "DATABASE_POOL_SIZE": "5",
                    "CACHE_TTL": "60",
                    "SESSION_TIMEOUT_SECONDS": "7200",
                    "MAX_LOGIN_ATTEMPTS": "20",
                    "FEATURE_FLAGS": "sso_v2=true,profile_photos=true,mfa_required=false",
                    "PASSWORD_MIN_LENGTH": "8",
                    "ACCOUNT_LOCKOUT_MINUTES": "5",
                },
                "redacted_keys": ["DATABASE_URL", "OKTA_API_TOKEN", "HMAC_SECRET"],
                "last_updated": (_NOW - timedelta(hours=24)).isoformat() + "Z",
                "updated_by": "s.patel@acme.dev",
            },
            "dev": {
                "config": {
                    "LOG_LEVEL": "DEBUG",
                    "DATABASE_POOL_SIZE": "2",
                    "CACHE_TTL": "10",
                    "SESSION_TIMEOUT_SECONDS": "86400",
                    "MAX_LOGIN_ATTEMPTS": "999",
                    "FEATURE_FLAGS": "sso_v2=true,profile_photos=true,mfa_required=false,debug_auth=true",
                    "PASSWORD_MIN_LENGTH": "4",
                    "ACCOUNT_LOCKOUT_MINUTES": "1",
                },
                "redacted_keys": ["DATABASE_URL"],
                "last_updated": (_NOW - timedelta(hours=2)).isoformat() + "Z",
                "updated_by": "r.kim@acme.dev",
            },
        },
        "payment-service": {
            "prod": {
                "config": {
                    "LOG_LEVEL": "WARN",
                    "DATABASE_POOL_SIZE": "25",
                    "CACHE_TTL": "300",
                    "FEATURE_FLAGS": "refund_v2=true,batch_payments=false,crypto=false",
                    "RATE_LIMIT_RPM": "500",
                    "MAX_TRANSACTION_AMOUNT": "50000",
                    "CURRENCY_DEFAULT": "USD",
                    "PCI_COMPLIANCE_MODE": "strict",
                },
                "redacted_keys": [
                    "DATABASE_URL", "STRIPE_SECRET_KEY", "ENCRYPTION_KEY",
                    "PCI_AUDIT_TOKEN", "WEBHOOK_SIGNING_SECRET",
                ],
                "last_updated": (_NOW - timedelta(hours=12)).isoformat() + "Z",
                "updated_by": "m.johnson@acme.dev",
            },
            "staging": {
                "config": {
                    "LOG_LEVEL": "INFO",
                    "DATABASE_POOL_SIZE": "5",
                    "CACHE_TTL": "60",
                    "FEATURE_FLAGS": "refund_v2=true,batch_payments=true,crypto=true",
                    "RATE_LIMIT_RPM": "5000",
                    "MAX_TRANSACTION_AMOUNT": "999999",
                    "CURRENCY_DEFAULT": "USD",
                    "PCI_COMPLIANCE_MODE": "relaxed",
                },
                "redacted_keys": ["DATABASE_URL", "STRIPE_TEST_KEY", "ENCRYPTION_KEY"],
                "last_updated": (_NOW - timedelta(hours=6)).isoformat() + "Z",
                "updated_by": "m.johnson@acme.dev",
            },
            "dev": {
                "config": {
                    "LOG_LEVEL": "DEBUG",
                    "DATABASE_POOL_SIZE": "2",
                    "CACHE_TTL": "0",
                    "FEATURE_FLAGS": "refund_v2=true,batch_payments=true,crypto=true,mock_gateway=true",
                    "RATE_LIMIT_RPM": "99999",
                    "MAX_TRANSACTION_AMOUNT": "999999",
                    "CURRENCY_DEFAULT": "USD",
                    "PCI_COMPLIANCE_MODE": "disabled",
                },
                "redacted_keys": ["DATABASE_URL"],
                "last_updated": (_NOW - timedelta(hours=1)).isoformat() + "Z",
                "updated_by": "r.kim@acme.dev",
            },
        },
        "notification-service": {
            "prod": {
                "config": {
                    "LOG_LEVEL": "WARN",
                    "QUEUE_CONCURRENCY": "8",
                    "BATCH_SIZE": "100",
                    "RETRY_DELAY_SECONDS": "30",
                    "FEATURE_FLAGS": "email_v2=true,sms=true,push=false,slack=true",
                    "TEMPLATE_CACHE_TTL": "1800",
                    "MAX_RECIPIENTS_PER_BATCH": "500",
                    "DEDUP_WINDOW_SECONDS": "300",
                },
                "redacted_keys": [
                    "SMTP_PASSWORD", "TWILIO_AUTH_TOKEN", "FIREBASE_KEY",
                    "SLACK_WEBHOOK_URL", "DATABASE_URL",
                ],
                "last_updated": (_NOW - timedelta(hours=4)).isoformat() + "Z",
                "updated_by": "a.garcia@acme.dev",
            },
            "staging": {
                "config": {
                    "LOG_LEVEL": "INFO",
                    "QUEUE_CONCURRENCY": "2",
                    "BATCH_SIZE": "10",
                    "RETRY_DELAY_SECONDS": "5",
                    "FEATURE_FLAGS": "email_v2=true,sms=true,push=true,slack=true",
                    "TEMPLATE_CACHE_TTL": "60",
                    "MAX_RECIPIENTS_PER_BATCH": "50",
                    "DEDUP_WINDOW_SECONDS": "30",
                },
                "redacted_keys": ["SMTP_PASSWORD", "TWILIO_AUTH_TOKEN", "DATABASE_URL"],
                "last_updated": (_NOW - timedelta(hours=18)).isoformat() + "Z",
                "updated_by": "l.santos@acme.dev",
            },
            "dev": {
                "config": {
                    "LOG_LEVEL": "DEBUG",
                    "QUEUE_CONCURRENCY": "1",
                    "BATCH_SIZE": "1",
                    "RETRY_DELAY_SECONDS": "1",
                    "FEATURE_FLAGS": "email_v2=true,sms=true,push=true,slack=true,dry_run=true",
                    "TEMPLATE_CACHE_TTL": "0",
                    "MAX_RECIPIENTS_PER_BATCH": "5",
                    "DEDUP_WINDOW_SECONDS": "0",
                },
                "redacted_keys": ["DATABASE_URL"],
                "last_updated": (_NOW - timedelta(hours=1.5)).isoformat() + "Z",
                "updated_by": "r.kim@acme.dev",
            },
        },
        "search-service": {
            "prod": {
                "config": {
                    "LOG_LEVEL": "WARN",
                    "INDEX_REFRESH_SECONDS": "30",
                    "MAX_RESULTS_PER_QUERY": "100",
                    "FEATURE_FLAGS": "fuzzy_search=true,autocomplete=true,vector_search=false",
                    "CACHE_TTL": "120",
                    "QUERY_TIMEOUT_MS": "3000",
                    "MIN_SCORE_THRESHOLD": "0.7",
                },
                "redacted_keys": ["ELASTICSEARCH_URL", "API_KEY", "DATABASE_URL"],
                "last_updated": (_NOW - timedelta(days=2)).isoformat() + "Z",
                "updated_by": "a.garcia@acme.dev",
            },
            "staging": {
                "config": {
                    "LOG_LEVEL": "INFO",
                    "INDEX_REFRESH_SECONDS": "5",
                    "MAX_RESULTS_PER_QUERY": "500",
                    "FEATURE_FLAGS": "fuzzy_search=true,autocomplete=true,vector_search=true",
                    "CACHE_TTL": "10",
                    "QUERY_TIMEOUT_MS": "10000",
                    "MIN_SCORE_THRESHOLD": "0.3",
                },
                "redacted_keys": ["ELASTICSEARCH_URL", "DATABASE_URL"],
                "last_updated": (_NOW - timedelta(hours=20)).isoformat() + "Z",
                "updated_by": "s.patel@acme.dev",
            },
            "dev": {
                "config": {
                    "LOG_LEVEL": "DEBUG",
                    "INDEX_REFRESH_SECONDS": "1",
                    "MAX_RESULTS_PER_QUERY": "1000",
                    "FEATURE_FLAGS": "fuzzy_search=true,autocomplete=true,vector_search=true,explain_scores=true",
                    "CACHE_TTL": "0",
                    "QUERY_TIMEOUT_MS": "30000",
                    "MIN_SCORE_THRESHOLD": "0.0",
                },
                "redacted_keys": ["DATABASE_URL"],
                "last_updated": (_NOW - timedelta(hours=2)).isoformat() + "Z",
                "updated_by": "r.kim@acme.dev",
            },
        },
    }

    @classmethod
    def get_config(cls, service: str, env: str) -> Optional[Dict[str, Any]]:
        return cls._CONFIGS.get(service, {}).get(env)


# ============================================================================
# Health — derived from recent deployments
# ============================================================================

def _derive_health(topology: type, history: DeploymentHistory) -> Dict[str, Dict[str, Dict[str, Any]]]:
    """Generate health data correlated with recent deployment outcomes.

    - success → healthy (full replicas, low CPU/memory)
    - failed → degraded (running previous version, elevated metrics)
    - rolled_back → degraded (partial replicas, high latency)
    - in_progress → degraded (partial replicas, waiting)
    """
    health: Dict[str, Dict[str, Dict[str, Any]]] = {}

    for svc_name, svc_def in topology.SERVICES.items():
        health[svc_name] = {}
        for env in ["prod", "staging", "dev"]:
            replicas_desired = svc_def["replicas"].get(env, 1)
            base_cpu = svc_def["base_cpu"]
            base_mem = svc_def["base_memory_mb"]
            endpoints = svc_def["health_endpoints"]

            latest = history.get_latest_deploy(svc_name, env)
            status = latest["status"] if latest else "success"

            if status == "success":
                h = {
                    "status": "healthy",
                    "uptime_seconds": 864000 + _RNG.randint(0, 100000),
                    "replicas": {"current": replicas_desired, "desired": replicas_desired},
                    "cpu_percent": round(base_cpu + _RNG.uniform(-5, 10), 1),
                    "memory_mb": base_mem + _RNG.randint(-20, 40),
                    "last_restart": None,
                    "endpoints": [
                        {"url": ep, "status": "healthy", "latency_ms": _RNG.randint(5, 50)}
                        for ep in endpoints
                    ],
                }
            elif status == "failed":
                h = {
                    "status": "degraded",
                    "uptime_seconds": _RNG.randint(3600, 14400),
                    "replicas": {"current": max(1, replicas_desired - 1), "desired": replicas_desired},
                    "cpu_percent": round(base_cpu + _RNG.uniform(20, 40), 1),
                    "memory_mb": base_mem + _RNG.randint(50, 120),
                    "last_restart": (_NOW - timedelta(hours=_RNG.uniform(0.5, 4))).isoformat() + "Z",
                    "endpoints": [
                        {"url": ep, "status": "degraded", "latency_ms": _RNG.randint(200, 800)}
                        for ep in endpoints
                    ],
                }
            elif status == "rolled_back":
                h = {
                    "status": "unhealthy",
                    "uptime_seconds": _RNG.randint(1800, 7200),
                    "replicas": {"current": max(1, replicas_desired - 1), "desired": replicas_desired},
                    "cpu_percent": round(base_cpu + _RNG.uniform(30, 50), 1),
                    "memory_mb": base_mem + _RNG.randint(80, 160),
                    "last_restart": (_NOW - timedelta(minutes=_RNG.randint(10, 120))).isoformat() + "Z",
                    "endpoints": [
                        {"url": ep, "status": "unhealthy", "latency_ms": _RNG.randint(500, 2000)}
                        for ep in endpoints
                    ],
                }
            else:  # in_progress
                partial = max(1, replicas_desired // 2)
                h = {
                    "status": "degraded",
                    "uptime_seconds": _RNG.randint(600, 3600),
                    "replicas": {"current": partial, "desired": replicas_desired},
                    "cpu_percent": round(base_cpu + _RNG.uniform(10, 25), 1),
                    "memory_mb": base_mem + _RNG.randint(20, 60),
                    "last_restart": (_NOW - timedelta(minutes=_RNG.randint(1, 15))).isoformat() + "Z",
                    "endpoints": [
                        {"url": ep, "status": "healthy", "latency_ms": _RNG.randint(30, 150)}
                        for ep in endpoints
                    ],
                }

            health[svc_name][env] = h

    return health


# ============================================================================
# Module-level singletons — initialized once at import
# ============================================================================

deployment_history = DeploymentHistory()
log_generator = LogGenerator(deployment_history)
service_health = _derive_health(ServiceTopology, deployment_history)
