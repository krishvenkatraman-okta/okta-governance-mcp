"""
Shared test helpers for the Deploy Server test suite.

Mocking strategy (post okta-jwt-verifier migration):
DeployTokenVerifier.verify() returns a claims dict on success and raises
ValueError on failure. Tests replace the module-level `server.verifier`
with a MagicMock-backed object that returns canned claims or raises.
"""

from typing import Any, Dict, Optional
from unittest.mock import MagicMock


def make_claims(
    sub: str = "alice@acme.dev",
    aud: str = "api://deploy-server",
    iss: str = "https://org-b.okta.com/oauth2/ausABC123",
    scope: str = "mcp:read mcp:write",
    exp: int = 9999999999,
) -> Dict[str, Any]:
    """Build a verified-claims dict matching DeployTokenVerifier.verify()'s shape."""
    return {
        "valid": True,
        "sub": sub,
        "aud": aud,
        "iss": iss,
        "scope": scope,
        "exp": exp,
    }


def make_context(headers: Optional[Dict[str, str]] = None) -> MagicMock:
    """Create a mock FastMCP Context with configurable request headers."""
    ctx = MagicMock()
    ctx.request = MagicMock()
    _headers = headers or {}
    ctx.request.headers = MagicMock()
    ctx.request.headers.get = lambda key, default="": _headers.get(key, default)
    return ctx
