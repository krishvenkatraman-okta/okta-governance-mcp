"""
Tests for okta-jwt-verifier-based token verification.

Tests the DeployTokenVerifier class which wraps okta-jwt-verifier's
AccessTokenVerifier. Mocking is done at the server.verifier boundary
to exercise the real verification code path up to the SDK boundary.
"""

import importlib
import inspect
import os
import sys
from unittest.mock import MagicMock, patch

import pytest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
sys.path.insert(0, os.path.dirname(__file__))

from helpers import make_claims, make_context


# ============================================================================
# Token verification (using mock_sdk_verifier)
# ============================================================================


def test_valid_token_returns_claims(mock_sdk_verifier, mock_ctx):
    """Verified token returns all six claim keys with correct defaults."""
    import server

    claims = server.validate_bearer_token(mock_ctx)

    assert claims["valid"] is True
    assert claims["sub"] == "alice@acme.dev"
    assert claims["aud"] == "api://deploy-server"
    assert claims["iss"] == "https://org-b.okta.com/oauth2/ausABC123"
    assert claims["scope"] == "mcp:read mcp:write"
    assert claims["exp"] == 9999999999


def test_invalid_token_raises(mock_sdk_verifier, mock_ctx):
    """Verifier raises ValueError -> validate_bearer_token propagates it."""
    mock_sdk_verifier.set_error(
        ValueError("Token verification failed: signature invalid")
    )

    import server

    with pytest.raises(ValueError, match="Token verification failed"):
        server.validate_bearer_token(mock_ctx)


def test_sub_claim_extracted(mock_sdk_verifier, mock_ctx):
    """Custom sub and iss claims are extracted correctly."""
    mock_sdk_verifier(
        make_claims(
            sub="bob.smith@partner.org",
            iss="https://partner.okta.com/oauth2/ausXYZ789",
            scope="mcp:read",
        )
    )

    import server

    claims = server.validate_bearer_token(mock_ctx)
    assert claims["sub"] == "bob.smith@partner.org"
    assert claims["iss"] == "https://partner.okta.com/oauth2/ausXYZ789"


# ============================================================================
# Authorization header validation
# ============================================================================


def test_missing_auth_header(mock_sdk_verifier, mock_ctx_no_auth):
    """No Authorization header -> ValueError."""
    import server

    with pytest.raises(ValueError, match="Missing Authorization header"):
        server.validate_bearer_token(mock_ctx_no_auth)


def test_malformed_auth_header(mock_sdk_verifier, mock_ctx_basic_auth):
    """'Basic' instead of 'Bearer' -> ValueError."""
    import server

    with pytest.raises(ValueError, match="Authorization header must use Bearer scheme"):
        server.validate_bearer_token(mock_ctx_basic_auth)


def test_empty_bearer_token(mock_sdk_verifier):
    """'Bearer ' with no token value -> ValueError."""
    import server

    mock_request = MagicMock()
    mock_request.headers = {"authorization": "Bearer "}
    with patch("fastmcp.server.dependencies.get_http_request", return_value=mock_request):
        with pytest.raises(ValueError, match="Bearer token is empty"):
            server.validate_bearer_token(mock_request)


# ============================================================================
# DeployTokenVerifier construction
# ============================================================================


def _patch_okta_jwt_verifier_modules():
    """Return a sys.modules patch dict that stubs okta_jwt_verifier."""
    mock_atv = MagicMock()
    mock_exceptions = MagicMock()
    mock_exceptions.JWTValidationException = type(
        "JWTValidationException", (Exception,), {}
    )
    mock_exceptions.JWKException = type("JWKException", (Exception,), {})

    return {
        "okta_jwt_verifier": MagicMock(
            AccessTokenVerifier=mock_atv,
        ),
        "okta_jwt_verifier.exceptions": mock_exceptions,
    }, mock_atv


def test_verifier_init_constructs_issuer():
    """AccessTokenVerifier is called with correct issuer, audience, leeway."""
    modules_patch, mock_atv = _patch_okta_jwt_verifier_modules()

    with patch.dict("sys.modules", modules_patch):
        import auth

        importlib.reload(auth)
        verifier = auth.DeployTokenVerifier(
            okta_domain="dev-12345.okta.com",
            auth_server_id="ausABC123",
            audience="api://deploy-server",
        )

    mock_atv.assert_called_once_with(
        issuer="https://dev-12345.okta.com/oauth2/ausABC123",
        audience="api://deploy-server",
        leeway=0,
    )
    assert verifier.issuer == "https://dev-12345.okta.com/oauth2/ausABC123"


def test_no_client_id_parameter():
    """DeployTokenVerifier.__init__ has no client_id, client_secret, or private_jwk params."""
    modules_patch, _ = _patch_okta_jwt_verifier_modules()

    with patch.dict("sys.modules", modules_patch):
        import auth

        importlib.reload(auth)
        params = inspect.signature(auth.DeployTokenVerifier.__init__).parameters
        assert "client_id" not in params
        assert "client_secret" not in params
        assert "private_jwk" not in params


def test_domain_normalization_https():
    """Domain starting with https:// is left unchanged."""
    modules_patch, mock_atv = _patch_okta_jwt_verifier_modules()

    with patch.dict("sys.modules", modules_patch):
        import auth

        importlib.reload(auth)
        verifier = auth.DeployTokenVerifier(
            okta_domain="https://already-https.okta.com",
            auth_server_id="aus1",
        )

    assert verifier.issuer == "https://already-https.okta.com/oauth2/aus1"


def test_domain_normalization_http():
    """Domain starting with http:// is upgraded to https://."""
    modules_patch, mock_atv = _patch_okta_jwt_verifier_modules()

    with patch.dict("sys.modules", modules_patch):
        import auth

        importlib.reload(auth)
        verifier = auth.DeployTokenVerifier(
            okta_domain="http://insecure.okta.com",
            auth_server_id="aus1",
        )

    assert verifier.issuer == "https://insecure.okta.com/oauth2/aus1"


def test_domain_normalization_bare():
    """Bare domain gets https:// prepended."""
    modules_patch, mock_atv = _patch_okta_jwt_verifier_modules()

    with patch.dict("sys.modules", modules_patch):
        import auth

        importlib.reload(auth)
        verifier = auth.DeployTokenVerifier(
            okta_domain="bare.okta.com",
            auth_server_id="aus1",
        )

    assert verifier.issuer == "https://bare.okta.com/oauth2/aus1"


def test_domain_normalization_trailing_slash():
    """Trailing slash is stripped before constructing issuer."""
    modules_patch, mock_atv = _patch_okta_jwt_verifier_modules()

    with patch.dict("sys.modules", modules_patch):
        import auth

        importlib.reload(auth)
        verifier = auth.DeployTokenVerifier(
            okta_domain="https://trailing.okta.com/",
            auth_server_id="aus1",
        )

    assert verifier.issuer == "https://trailing.okta.com/oauth2/aus1"


# ============================================================================
# _init_verifier behavior
# ============================================================================


def test_init_verifier_missing_domain_raises():
    """Missing DEPLOY_OKTA_DOMAIN raises RuntimeError."""
    modules_patch, _ = _patch_okta_jwt_verifier_modules()

    with patch.dict("sys.modules", modules_patch):
        import auth

        importlib.reload(auth)

        with patch.dict(
            os.environ,
            {"DEPLOY_OKTA_DOMAIN": "", "DEPLOY_OKTA_AUTH_SERVER_ID": "aus1"},
        ):
            with pytest.raises(RuntimeError, match="DEPLOY_OKTA_DOMAIN"):
                auth._init_verifier()


def test_init_verifier_missing_auth_server_id_raises():
    """Missing DEPLOY_OKTA_AUTH_SERVER_ID raises RuntimeError."""
    modules_patch, _ = _patch_okta_jwt_verifier_modules()

    with patch.dict("sys.modules", modules_patch):
        import auth

        importlib.reload(auth)

        with patch.dict(
            os.environ,
            {"DEPLOY_OKTA_DOMAIN": "dev.okta.com", "DEPLOY_OKTA_AUTH_SERVER_ID": ""},
        ):
            with pytest.raises(RuntimeError, match="DEPLOY_OKTA_AUTH_SERVER_ID"):
                auth._init_verifier()


def test_init_verifier_legacy_client_id_emits_deprecation_warning(caplog):
    """Legacy DEPLOY_OKTA_CLIENT_ID triggers DeprecationWarning and WARNING log."""
    modules_patch, _ = _patch_okta_jwt_verifier_modules()

    with patch.dict("sys.modules", modules_patch):
        import auth

        importlib.reload(auth)

        env = {
            "DEPLOY_OKTA_DOMAIN": "dev.okta.com",
            "DEPLOY_OKTA_AUTH_SERVER_ID": "aus1",
            "DEPLOY_OKTA_CLIENT_ID": "0oaLEGACY",
        }

        with patch.dict(os.environ, env):
            import logging

            with caplog.at_level(logging.WARNING):
                with pytest.warns(DeprecationWarning):
                    result = auth._init_verifier()

        # Verify warning log contains expected text
        warning_records = [
            r for r in caplog.records if r.levelno == logging.WARNING
        ]
        assert any(
            "DEPLOY_OKTA_CLIENT_ID" in r.message and "deprecated" in r.message
            for r in warning_records
        ), "Expected WARNING log mentioning DEPLOY_OKTA_CLIENT_ID and deprecated"

        # Verify it still returns a DeployTokenVerifier (legacy var doesn't block startup)
        assert isinstance(result, auth.DeployTokenVerifier)


def test_init_verifier_no_client_id_no_warning(caplog):
    """No DEPLOY_OKTA_CLIENT_ID set -> no deprecation warning logged."""
    modules_patch, _ = _patch_okta_jwt_verifier_modules()

    with patch.dict("sys.modules", modules_patch):
        import auth

        importlib.reload(auth)

        env = {
            "DEPLOY_OKTA_DOMAIN": "dev.okta.com",
            "DEPLOY_OKTA_AUTH_SERVER_ID": "aus1",
        }
        # Ensure legacy var is absent
        cleaned_env = os.environ.copy()
        cleaned_env.pop("DEPLOY_OKTA_CLIENT_ID", None)
        cleaned_env.update(env)

        import logging

        with caplog.at_level(logging.WARNING):
            with patch.dict(os.environ, cleaned_env, clear=True):
                auth._init_verifier()

        warning_records = [
            r for r in caplog.records if r.levelno == logging.WARNING
        ]
        assert not any(
            "DEPLOY_OKTA_CLIENT_ID" in r.message for r in warning_records
        ), "No WARNING log should mention DEPLOY_OKTA_CLIENT_ID"
