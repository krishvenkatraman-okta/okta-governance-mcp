"""
Tests for all 5 business tools + health_check.

Each tool is tested by calling the function directly with a mock Context.
Auth is mocked via the mock_sdk_verifier fixture so tests focus on
business logic and data correctness.
"""

import os
import sys
import uuid

import pytest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
sys.path.insert(0, os.path.dirname(__file__))

from helpers import make_context


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

@pytest.fixture(autouse=True)
def _mock_auth(mock_sdk_verifier, mock_ctx):
    """All tests in this module run with a mocked verifier."""
    pass


@pytest.fixture
def ctx():
    return make_context({"authorization": "Bearer test"})


# ============================================================================
# health_check
# ============================================================================


def test_health_check():
    from server import health_check

    result = health_check()
    assert result["status"] == "healthy"
    assert result["service"] == "deploy-server"
    assert isinstance(result["port"], int)


# ============================================================================
# get_deployments
# ============================================================================


def test_get_deployments_returns_list(ctx):
    from server import get_deployments

    result = get_deployments(ctx, service="api-gateway", env="prod")
    assert isinstance(result, list)
    assert len(result) > 0


def test_get_deployments_filters_by_env(ctx):
    from server import get_deployments

    prod = get_deployments(ctx, service="api-gateway", env="prod")
    staging = get_deployments(ctx, service="api-gateway", env="staging")

    # All returned records must match the requested env
    assert all(d["environment"] == "prod" for d in prod)
    assert all(d["environment"] == "staging" for d in staging)


def test_get_deployments_all_envs(ctx):
    from server import get_deployments

    all_deps = get_deployments(ctx, service="api-gateway", env="all")
    envs = {d["environment"] for d in all_deps}
    assert "prod" in envs
    assert "staging" in envs


def test_get_deployments_unknown_service(ctx):
    from server import get_deployments

    result = get_deployments(ctx, service="nonexistent-service", env="prod")
    assert isinstance(result, dict)
    assert result["deployments"] == []


def test_deployment_record_structure(ctx):
    """Each deployment has the expected fields."""
    from server import get_deployments

    deps = get_deployments(ctx, service="api-gateway", env="prod")
    dep = deps[0]

    required_keys = {"deploy_id", "service", "environment", "version", "status",
                     "deployed_by", "deployed_at", "commit_sha"}
    assert required_keys.issubset(dep.keys())
    assert dep["deploy_id"].startswith("dep-")
    assert dep["deployed_by"].endswith("@acme.dev")


def test_deployment_status_values(ctx):
    """All deployments have valid status values."""
    from server import get_deployments
    from data import ServiceTopology

    valid_statuses = {"success", "failed", "rolled_back", "in_progress"}
    for svc in ServiceTopology.list_services():
        deps = get_deployments(ctx, service=svc, env="all")
        if isinstance(deps, list):
            for dep in deps:
                assert dep["status"] in valid_statuses, f"Invalid status: {dep['status']}"


# ============================================================================
# get_deploy_logs
# ============================================================================


def test_get_deploy_logs_valid_id(ctx):
    """Returns log lines for a known deployment."""
    from server import get_deploy_logs
    from data import deployment_history

    dep_id = deployment_history.list_deploy_ids()[0]
    result = get_deploy_logs(ctx, deploy_id=dep_id)

    assert result["deploy_id"] == dep_id
    assert isinstance(result["log_lines"], list)
    assert len(result["log_lines"]) > 0
    assert isinstance(result["total_lines"], int)
    assert isinstance(result["truncated"], bool)


def test_get_deploy_logs_invalid_id(ctx):
    """Raises ValueError for unknown deployment."""
    from server import get_deploy_logs

    with pytest.raises(ValueError, match="not found"):
        get_deploy_logs(ctx, deploy_id="dep-nonexistent")


def test_get_deploy_logs_truncation(ctx):
    """Requesting fewer lines than total triggers truncation."""
    from server import get_deploy_logs
    from data import deployment_history

    dep_id = deployment_history.list_deploy_ids()[0]
    result = get_deploy_logs(ctx, deploy_id=dep_id, lines=2)

    if result["total_lines"] > 2:
        assert result["truncated"] is True
        assert len(result["log_lines"]) == 2


def test_get_deploy_logs_no_truncation(ctx):
    """Requesting more lines than available -> not truncated."""
    from server import get_deploy_logs
    from data import deployment_history

    dep_id = deployment_history.list_deploy_ids()[0]
    result = get_deploy_logs(ctx, deploy_id=dep_id, lines=9999)

    assert result["truncated"] is False
    assert len(result["log_lines"]) == result["total_lines"]


# ============================================================================
# rollback_deployment
# ============================================================================


def test_rollback_returns_confirmation(ctx):
    """Rollback returns UUID-based rollback_id and status."""
    from server import rollback_deployment

    result = rollback_deployment(ctx, service="api-gateway", env="prod", reason="Test rollback")

    assert result["rollback_id"].startswith("rb-")
    assert result["service"] == "api-gateway"
    assert result["environment"] == "prod"
    assert result["status"] == "initiated"
    assert result["reason"] == "Test rollback"
    assert result["initiated_by"] == "alice@acme.dev"  # mock claims sub


def test_rollback_has_version_info(ctx):
    """Rollback includes from/to version strings."""
    from server import rollback_deployment

    result = rollback_deployment(ctx, service="user-service", env="prod", reason="Revert")

    assert "rolled_back_from" in result
    assert "rolled_back_to" in result
    assert result["rolled_back_from"] != result["rolled_back_to"]


def test_rollback_invalid_service(ctx):
    """Rollback for unknown service raises ValueError."""
    from server import rollback_deployment

    with pytest.raises(ValueError, match="No version info found"):
        rollback_deployment(ctx, service="nonexistent", env="prod", reason="Nope")


def test_rollback_invalid_env(ctx):
    """Rollback for unknown environment raises ValueError."""
    from server import rollback_deployment

    with pytest.raises(ValueError, match="No version info found"):
        rollback_deployment(ctx, service="api-gateway", env="nonexistent", reason="Nope")


def test_rollback_unique_ids(ctx):
    """Each rollback produces a unique rollback_id."""
    from server import rollback_deployment

    r1 = rollback_deployment(ctx, service="api-gateway", env="prod", reason="First")
    r2 = rollback_deployment(ctx, service="api-gateway", env="prod", reason="Second")
    assert r1["rollback_id"] != r2["rollback_id"]


# ============================================================================
# get_env_config
# ============================================================================


def test_get_env_config_has_redacted_keys(ctx):
    """Response includes redacted_keys list."""
    from server import get_env_config

    result = get_env_config(ctx, service="payment-service", env="prod")

    assert "redacted_keys" in result
    assert isinstance(result["redacted_keys"], list)
    assert len(result["redacted_keys"]) > 0


def test_get_env_config_varies_by_env(ctx):
    """Dev and prod configs differ (e.g., LOG_LEVEL)."""
    from server import get_env_config

    prod = get_env_config(ctx, service="api-gateway", env="prod")
    dev = get_env_config(ctx, service="api-gateway", env="dev")

    assert prod["config"]["LOG_LEVEL"] != dev["config"]["LOG_LEVEL"]
    assert prod["config"]["LOG_LEVEL"] == "WARN"
    assert dev["config"]["LOG_LEVEL"] == "DEBUG"


def test_get_env_config_structure(ctx):
    """Response has all required fields."""
    from server import get_env_config

    result = get_env_config(ctx, service="user-service", env="prod")

    assert result["service"] == "user-service"
    assert result["environment"] == "prod"
    assert isinstance(result["config"], dict)
    assert isinstance(result["redacted_keys"], list)
    assert "last_updated" in result
    assert "updated_by" in result


def test_get_env_config_unknown_service(ctx):
    """Unknown service raises ValueError."""
    from server import get_env_config

    with pytest.raises(ValueError, match="No config found"):
        get_env_config(ctx, service="nonexistent", env="prod")


def test_get_env_config_unknown_env(ctx):
    """Unknown environment raises ValueError."""
    from server import get_env_config

    with pytest.raises(ValueError, match="No config found"):
        get_env_config(ctx, service="api-gateway", env="nonexistent")


def test_get_env_config_dev_fewer_redacted_keys(ctx):
    """Dev environments generally have fewer redacted keys than prod."""
    from server import get_env_config

    prod = get_env_config(ctx, service="payment-service", env="prod")
    dev = get_env_config(ctx, service="payment-service", env="dev")

    assert len(prod["redacted_keys"]) > len(dev["redacted_keys"])


def test_get_env_config_all_services(ctx):
    """All 5 services have configs for all 3 environments."""
    from server import get_env_config
    from data import ServiceTopology

    for svc in ServiceTopology.list_services():
        for env in ["prod", "staging", "dev"]:
            result = get_env_config(ctx, service=svc, env=env)
            assert result["service"] == svc
            assert result["environment"] == env


# ============================================================================
# get_service_health
# ============================================================================


def test_get_service_health_structure(ctx):
    """Response has all required fields."""
    from server import get_service_health

    result = get_service_health(ctx, service="api-gateway", env="prod")

    required_keys = {"service", "environment", "status", "uptime_seconds",
                     "replicas", "cpu_percent", "memory_mb", "last_restart",
                     "endpoints"}
    assert required_keys.issubset(result.keys())
    assert result["service"] == "api-gateway"
    assert result["environment"] == "prod"


def test_get_service_health_replicas_structure(ctx):
    """Replicas contains current and desired counts."""
    from server import get_service_health

    result = get_service_health(ctx, service="api-gateway", env="prod")
    replicas = result["replicas"]

    assert "current" in replicas
    assert "desired" in replicas
    assert replicas["current"] > 0
    assert replicas["desired"] > 0


def test_get_service_health_endpoints(ctx):
    """Endpoints list has url, status, and latency_ms."""
    from server import get_service_health

    result = get_service_health(ctx, service="api-gateway", env="prod")
    endpoints = result["endpoints"]

    assert len(endpoints) > 0
    for ep in endpoints:
        assert "url" in ep
        assert "status" in ep
        assert "latency_ms" in ep


def test_get_service_health_unknown_service(ctx):
    """Unknown service raises ValueError."""
    from server import get_service_health

    with pytest.raises(ValueError, match="No health data found"):
        get_service_health(ctx, service="nonexistent", env="prod")


def test_get_service_health_all_services(ctx):
    """All 5 services have health data for all 3 environments."""
    from server import get_service_health
    from data import ServiceTopology

    valid_statuses = {"healthy", "degraded", "unhealthy"}
    for svc in ServiceTopology.list_services():
        for env in ["prod", "staging", "dev"]:
            result = get_service_health(ctx, service=svc, env=env)
            assert result["status"] in valid_statuses
