"""
Tests for mock data integrity and cross-referencing.

Validates that the data engine produces consistent, cross-referenced data:
- All deployments reference valid services
- All deployments have logs
- Health correlates with deployment outcomes
- Data generation is deterministic
"""

import os
import sys

import pytest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))


# ============================================================================
# Service topology integrity
# ============================================================================


def test_service_count():
    """Exactly 5 services in topology."""
    from data import ServiceTopology

    assert len(ServiceTopology.SERVICES) == 5


def test_service_names():
    """Services match expected names."""
    from data import ServiceTopology

    expected = {"api-gateway", "user-service", "payment-service",
                "notification-service", "search-service"}
    assert set(ServiceTopology.list_services()) == expected


def test_services_have_all_envs():
    """Every service has version info for prod, staging, dev."""
    from data import ServiceTopology

    for name, svc in ServiceTopology.SERVICES.items():
        for env in ["prod", "staging", "dev"]:
            assert env in svc["current_version"], f"{name} missing current_version for {env}"
            assert env in svc["previous_version"], f"{name} missing previous_version for {env}"
            assert env in svc["replicas"], f"{name} missing replicas for {env}"


# ============================================================================
# Deployment -> Service cross-referencing
# ============================================================================


def test_all_deployments_reference_valid_services():
    """Every deployment's service exists in ServiceTopology."""
    from data import ServiceTopology, deployment_history

    valid_services = set(ServiceTopology.list_services())
    for dep_id in deployment_history.list_deploy_ids():
        dep = deployment_history.get_deployment(dep_id)
        assert dep["service"] in valid_services, \
            f"Deployment {dep_id} references unknown service: {dep['service']}"


def test_all_services_have_deployments():
    """Every service in topology has at least one deployment."""
    from data import ServiceTopology, deployment_history

    for svc_name in ServiceTopology.list_services():
        all_deps = deployment_history.get_deployments(svc_name, env="all")
        assert len(all_deps) > 0, f"Service '{svc_name}' has no deployments"


def test_deployment_count():
    """Total of 18 deployments across all services."""
    from data import deployment_history

    assert len(deployment_history.list_deploy_ids()) == 18


def test_deployment_status_distribution():
    """Status distribution: ~70% success, ~15% failed, ~10% rolled_back, ~5% in_progress."""
    from data import deployment_history

    status_counts = {}
    for dep_id in deployment_history.list_deploy_ids():
        dep = deployment_history.get_deployment(dep_id)
        status_counts[dep["status"]] = status_counts.get(dep["status"], 0) + 1

    # Success should be majority
    assert status_counts.get("success", 0) >= 10, f"Too few success: {status_counts}"
    assert status_counts.get("failed", 0) >= 1, f"No failed deployments"
    assert status_counts.get("rolled_back", 0) >= 1, f"No rolled_back deployments"
    assert status_counts.get("in_progress", 0) >= 1, f"No in_progress deployments"


def test_deployer_emails():
    """All deployers use @acme.dev domain."""
    from data import deployment_history

    for dep_id in deployment_history.list_deploy_ids():
        dep = deployment_history.get_deployment(dep_id)
        assert dep["deployed_by"].endswith("@acme.dev"), \
            f"Deployment {dep_id} has non-acme deployer: {dep['deployed_by']}"


def test_deploy_ids_are_unique():
    """All deploy IDs are unique."""
    from data import deployment_history

    ids = deployment_history.list_deploy_ids()
    assert len(ids) == len(set(ids))


# ============================================================================
# Deployment -> Logs cross-referencing
# ============================================================================


def test_all_deployments_have_logs():
    """Every deployment ID has corresponding logs."""
    from data import deployment_history, log_generator

    for dep_id in deployment_history.list_deploy_ids():
        logs = log_generator.get_logs(dep_id)
        assert logs is not None, f"No logs for deployment {dep_id}"
        assert len(logs) > 0, f"Empty logs for deployment {dep_id}"


def test_success_logs_show_completion():
    """Successful deployment logs end with 'complete'."""
    from data import deployment_history, log_generator

    for dep_id in deployment_history.list_deploy_ids():
        dep = deployment_history.get_deployment(dep_id)
        if dep["status"] == "success":
            logs = log_generator.get_logs(dep_id)
            last_lines = " ".join(logs[-3:]).lower()
            assert "complete" in last_lines, \
                f"Success deploy {dep_id} logs don't mention completion"


def test_failed_logs_show_error():
    """Failed deployment logs contain ERROR."""
    from data import deployment_history, log_generator

    for dep_id in deployment_history.list_deploy_ids():
        dep = deployment_history.get_deployment(dep_id)
        if dep["status"] == "failed":
            logs = log_generator.get_logs(dep_id)
            combined = " ".join(logs)
            assert "ERROR" in combined, \
                f"Failed deploy {dep_id} logs don't contain ERROR"


def test_rollback_logs_show_rollback():
    """Rolled-back deployment logs mention rollback."""
    from data import deployment_history, log_generator

    for dep_id in deployment_history.list_deploy_ids():
        dep = deployment_history.get_deployment(dep_id)
        if dep["status"] == "rolled_back":
            logs = log_generator.get_logs(dep_id)
            combined = " ".join(logs).lower()
            assert "rollback" in combined, \
                f"Rolled-back deploy {dep_id} logs don't mention rollback"


def test_in_progress_logs_show_waiting():
    """In-progress deployment logs show waiting or partial state."""
    from data import deployment_history, log_generator

    for dep_id in deployment_history.list_deploy_ids():
        dep = deployment_history.get_deployment(dep_id)
        if dep["status"] == "in_progress":
            logs = log_generator.get_logs(dep_id)
            combined = " ".join(logs).lower()
            assert "waiting" in combined or "rolling" in combined, \
                f"In-progress deploy {dep_id} logs don't show partial state"


# ============================================================================
# Health <-> Deployment correlation
# ============================================================================


def test_health_reflects_deployments():
    """Services with failed/rolled_back deploys show degraded/unhealthy health."""
    from data import ServiceTopology, deployment_history, service_health

    for svc_name in ServiceTopology.list_services():
        for env in ["prod", "staging", "dev"]:
            latest = deployment_history.get_latest_deploy(svc_name, env)
            health = service_health.get(svc_name, {}).get(env)

            if latest is None:
                continue

            assert health is not None, f"No health data for {svc_name}/{env}"

            if latest["status"] == "success":
                assert health["status"] == "healthy", \
                    f"{svc_name}/{env}: latest deploy success but health is {health['status']}"
            elif latest["status"] == "failed":
                assert health["status"] == "degraded", \
                    f"{svc_name}/{env}: latest deploy failed but health is {health['status']}"
            elif latest["status"] == "rolled_back":
                assert health["status"] == "unhealthy", \
                    f"{svc_name}/{env}: latest deploy rolled_back but health is {health['status']}"
            elif latest["status"] == "in_progress":
                assert health["status"] == "degraded", \
                    f"{svc_name}/{env}: latest deploy in_progress but health is {health['status']}"


def test_health_all_services_all_envs():
    """Health data exists for all 5 services x 3 environments = 15 entries."""
    from data import ServiceTopology, service_health

    count = 0
    for svc_name in ServiceTopology.list_services():
        for env in ["prod", "staging", "dev"]:
            assert svc_name in service_health, f"Missing health for {svc_name}"
            assert env in service_health[svc_name], f"Missing health for {svc_name}/{env}"
            count += 1
    assert count == 15


def test_health_replicas_bounded():
    """Current replicas are between 1 and desired."""
    from data import ServiceTopology, service_health

    for svc_name in ServiceTopology.list_services():
        for env in ["prod", "staging", "dev"]:
            h = service_health[svc_name][env]
            assert 1 <= h["replicas"]["current"] <= h["replicas"]["desired"]


# ============================================================================
# EnvConfigStore coverage
# ============================================================================


def test_env_config_all_services_all_envs():
    """Config exists for all 5 services x 3 environments."""
    from data import ServiceTopology, EnvConfigStore

    for svc_name in ServiceTopology.list_services():
        for env in ["prod", "staging", "dev"]:
            config = EnvConfigStore.get_config(svc_name, env)
            assert config is not None, f"No config for {svc_name}/{env}"
            assert "config" in config
            assert "redacted_keys" in config
            assert "last_updated" in config
            assert "updated_by" in config


def test_env_config_prod_has_secrets():
    """Prod configs have more redacted keys than dev."""
    from data import ServiceTopology, EnvConfigStore

    for svc_name in ServiceTopology.list_services():
        prod = EnvConfigStore.get_config(svc_name, "prod")
        dev = EnvConfigStore.get_config(svc_name, "dev")
        assert len(prod["redacted_keys"]) >= len(dev["redacted_keys"]), \
            f"{svc_name}: prod has fewer redacted keys than dev"


# ============================================================================
# Determinism
# ============================================================================


def test_deterministic_data():
    """Two DeploymentHistory instances produce identical data."""
    from data import DeploymentHistory

    h1 = DeploymentHistory()
    h2 = DeploymentHistory()

    ids1 = h1.list_deploy_ids()
    ids2 = h2.list_deploy_ids()
    assert ids1 == ids2

    for dep_id in ids1:
        d1 = h1.get_deployment(dep_id)
        d2 = h2.get_deployment(dep_id)
        assert d1 == d2, f"Deployment {dep_id} differs between instances"


def test_deterministic_logs():
    """Two LogGenerator instances produce identical logs."""
    from data import DeploymentHistory, LogGenerator

    h = DeploymentHistory()
    l1 = LogGenerator(h)
    l2 = LogGenerator(h)

    for dep_id in h.list_deploy_ids():
        assert l1.get_logs(dep_id) == l2.get_logs(dep_id), \
            f"Logs for {dep_id} differ between instances"
