"""
Shared fixtures for the Deploy Server test suite.

All tests mock the verifier directly at the DeployTokenVerifier.verify() boundary.
"""

import os
import sys
from unittest.mock import MagicMock, patch

import pytest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
sys.path.insert(0, os.path.dirname(__file__))

from helpers import make_claims, make_context


# ---------------------------------------------------------------------------
# Ensure `import server` succeeds even without real Okta env vars.
# server.py calls _init_verifier() at module level, which constructs a
# DeployTokenVerifier. We set dummy env vars so the constructor doesn't
# RuntimeError, and mock AccessTokenVerifier so it doesn't reach Okta.
# ---------------------------------------------------------------------------
os.environ.setdefault("DEPLOY_OKTA_DOMAIN", "test.okta.com")
os.environ.setdefault("DEPLOY_OKTA_AUTH_SERVER_ID", "ausTest123")
os.environ.setdefault("DEPLOY_OKTA_AUDIENCE", "api://deploy-server")


@pytest.fixture
def mock_valid_claims():
    """Default valid claims dict used by tests."""
    return make_claims()


@pytest.fixture
def mock_sdk_verifier(mock_valid_claims):
    """Replace server.verifier with a MagicMock that returns claims from .verify().

    Yields a setter function. Call set_result(claims_dict) to change the
    return value or set_error(exc) to make .verify raise.
    """
    import server

    original_verifier = server.verifier
    mock_verifier = MagicMock()
    mock_verifier.verify = MagicMock(return_value=mock_valid_claims)
    server.verifier = mock_verifier

    def set_result(claims):
        mock_verifier.verify.side_effect = None
        mock_verifier.verify.return_value = claims

    def set_error(exc):
        mock_verifier.verify.side_effect = exc

    # Expose both setters by attribute on the returned function for convenience
    set_result.set_error = set_error
    yield set_result

    server.verifier = original_verifier


def _make_mock_request(headers):
    """Create a mock HTTP request with the given headers dict."""
    mock_request = MagicMock()
    mock_request.headers = headers
    return mock_request


@pytest.fixture
def mock_ctx():
    """Patch get_http_request to return a request with a valid Bearer token header."""
    mock_request = _make_mock_request({"authorization": "Bearer test-token-abc123"})
    with patch("fastmcp.server.dependencies.get_http_request", return_value=mock_request):
        yield mock_request


@pytest.fixture
def mock_ctx_no_auth():
    """Patch get_http_request to return a request with no Authorization header."""
    mock_request = _make_mock_request({})
    with patch("fastmcp.server.dependencies.get_http_request", return_value=mock_request):
        yield mock_request


@pytest.fixture
def mock_ctx_basic_auth():
    """Patch get_http_request to return a request with Basic auth instead of Bearer."""
    mock_request = _make_mock_request({"authorization": "Basic dXNlcjpwYXNz"})
    with patch("fastmcp.server.dependencies.get_http_request", return_value=mock_request):
        yield mock_request
