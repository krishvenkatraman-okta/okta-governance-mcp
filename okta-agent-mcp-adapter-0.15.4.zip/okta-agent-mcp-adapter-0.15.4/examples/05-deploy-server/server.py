#!/usr/bin/env python3
"""
DevOps Deploy MCP Server - Example Backend for Okta MCP Adapter

This server demonstrates OAuth2 Cross-App Access (XAA) authentication
using okta-jwt-verifier for Bearer token validation.

In the ID-JAG XAA flow, the adapter performs:
  1. Validate user's Okta JWT (AT-1)
  2. Look up stored id_token from the user token store
  3. Issue ID-JAG JWT using the id_token, exchange at OK1Az2 for AT-2
This server receives AT-2 and validates it using okta-jwt-verifier AccessTokenVerifier.

Port: 8005 (configurable via DEPLOY_SERVER_PORT)
Path: /deploy
Auth: OAuth2 Bearer token (validated via okta-jwt-verifier)
"""

import logging
import os
import uuid
from datetime import datetime
from typing import Any, Dict, List

from fastmcp import FastMCP, Context
from auth import DeployTokenVerifier, _init_verifier
from data import (
    ServiceTopology,
    deployment_history,
    log_generator,
    service_health,
    EnvConfigStore,
)

# Configure logging
LOG_LEVEL = os.getenv("LOG_LEVEL", "INFO")
logging.basicConfig(
    level=LOG_LEVEL,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
)
logger = logging.getLogger(__name__)

def _resolve_port() -> int:
    """Resolve the server port from environment variables.

    Priority: DEPLOY_SERVER_PORT (new canonical) > SERVER_PORT (deprecated) > 8005 default.
    """
    new = os.getenv("DEPLOY_SERVER_PORT")
    old = os.getenv("SERVER_PORT")
    if new is not None:
        port = int(new)
    elif old is not None:
        import warnings
        warnings.warn(
            "SERVER_PORT is deprecated for the deploy server; "
            "use DEPLOY_SERVER_PORT. SERVER_PORT support will be "
            "removed in a future release.",
            DeprecationWarning,
            stacklevel=2,
        )
        port = int(old)
    else:
        return 8005
    if not (1 <= port <= 65535):
        raise ValueError(
            f"Port must be between 1 and 65535, got {port}"
        )
    return port


# Server configuration
SERVER_HOST = os.getenv("SERVER_HOST", "0.0.0.0")
SERVER_PORT = _resolve_port()
# ============================================================================
# Verifier initialization (singleton)
# ============================================================================

verifier = _init_verifier()


# ============================================================================
# Auth helper
# ============================================================================

def validate_bearer_token(ctx: Context) -> Dict[str, Any]:
    """Extract and validate the Bearer token from the request.

    Returns:
        Dict with verified claims (valid, sub, aud, iss, scope, exp).

    Raises:
        ValueError: If the Authorization header is missing, malformed, or the
            token fails SDK verification.
    """
    from fastmcp.server.dependencies import get_http_request
    request = get_http_request()
    auth_header = request.headers.get("authorization", "")

    if not auth_header:
        raise ValueError("Missing Authorization header")
    if not auth_header.startswith("Bearer "):
        raise ValueError("Authorization header must use Bearer scheme")

    token = auth_header[7:]
    if not token:
        raise ValueError("Bearer token is empty")

    claims = verifier.verify(token)
    logger.info("Access token claims: %s", claims)
    return claims


# ============================================================================
# FastMCP Server & Tools
# ============================================================================

mcp = FastMCP("Deploy Server")


@mcp.tool()
def health_check() -> dict:
    """Health check endpoint returning service status."""
    return {"status": "healthy", "service": "deploy-server", "port": SERVER_PORT}


@mcp.tool()
def get_deployments(ctx: Context, service: str, env: str = "prod") -> list:
    """List recent deployments for a service.

    Args:
        service: Service name (e.g., 'api-gateway', 'user-service', 'payment-service',
                 'notification-service', 'search-service')
        env: Environment filter -- 'prod', 'staging', 'dev', or 'all' (default: 'prod')

    Returns:
        List of deployment records with status, version, deployer, and timing.
    """
    claims = validate_bearer_token(ctx)
    logger.info(
        "get_deployments called by sub=%s for service=%s env=%s",
        claims["sub"], service, env,
    )

    deployments = deployment_history.get_deployments(service, env)

    if not deployments:
        return {"message": f"No deployments found for {service} in {env}", "deployments": []}

    return deployments


@mcp.tool()
def get_deploy_logs(ctx: Context, deploy_id: str, lines: int = 50) -> dict:
    """Retrieve build/deploy logs for a specific deployment.

    Args:
        deploy_id: Deployment ID (e.g., 'dep-1f64')
        lines: Maximum number of log lines to return (default: 50)

    Returns:
        Dict with deploy_id, log_lines, total_lines, and truncated flag.
    """
    claims = validate_bearer_token(ctx)
    logger.info(
        "get_deploy_logs called by sub=%s for deploy_id=%s",
        claims["sub"], deploy_id,
    )

    all_lines = log_generator.get_logs(deploy_id)
    if all_lines is None:
        raise ValueError(f"Deployment {deploy_id} not found")

    total = len(all_lines)
    truncated = total > lines
    returned_lines = all_lines[:lines]

    return {
        "deploy_id": deploy_id,
        "log_lines": returned_lines,
        "total_lines": total,
        "truncated": truncated,
    }


@mcp.tool()
def rollback_deployment(ctx: Context, service: str, env: str, reason: str) -> dict:
    """Initiate a rollback for a service to its previous version.

    Args:
        service: Service name (e.g., 'api-gateway', 'user-service', 'payment-service',
                 'notification-service', 'search-service')
        env: Target environment -- 'prod', 'staging', or 'dev'
        reason: Reason for the rollback (e.g., 'Error rate spike after v3.7.2 deploy')

    Returns:
        Dict with rollback_id, versions, initiator identity, and status.
    """
    claims = validate_bearer_token(ctx)
    logger.info(
        "rollback_deployment called by sub=%s for service=%s env=%s reason=%r",
        claims["sub"], service, env, reason,
    )

    # Scope check: warn if mcp:write is missing (don't block for demo)
    scope = claims.get("scope", "")
    if "mcp:write" not in scope:
        logger.warning(
            "rollback_deployment: caller sub=%s lacks mcp:write scope (has: %s)",
            claims["sub"], scope,
        )

    current = ServiceTopology.get_version(service, env)
    previous = ServiceTopology.get_previous_version(service, env)
    if not current or not previous:
        raise ValueError(f"No version info found for {service} in {env}")

    rollback_id = f"rb-{uuid.uuid4().hex[:8]}"
    now = datetime.utcnow().isoformat() + "Z"

    result = {
        "rollback_id": rollback_id,
        "service": service,
        "environment": env,
        "rolled_back_from": current,
        "rolled_back_to": previous,
        "initiated_by": claims["sub"],
        "initiated_at": now,
        "reason": reason,
        "status": "initiated",
    }

    logger.info(
        "Rollback %s initiated: %s %s %s -> %s by %s",
        rollback_id, service, env, current, previous, claims["sub"],
    )
    return result


@mcp.tool()
def get_env_config(ctx: Context, service: str, env: str = "prod") -> dict:
    """Retrieve environment configuration for a service.

    Non-secret configuration values are returned directly. Secret keys are listed
    in 'redacted_keys' -- the backend enforces its own access policies even after
    cross-app access authentication succeeds.

    Args:
        service: Service name (e.g., 'api-gateway', 'user-service', 'payment-service',
                 'notification-service', 'search-service')
        env: Environment -- 'prod', 'staging', or 'dev' (default: 'prod')

    Returns:
        Dict with service, environment, config (key-value pairs), redacted_keys,
        last_updated, and updated_by.
    """
    claims = validate_bearer_token(ctx)
    logger.info(
        "get_env_config called by sub=%s for service=%s env=%s",
        claims["sub"], service, env,
    )

    env_data = EnvConfigStore.get_config(service, env)
    if not env_data:
        raise ValueError(f"No config found for {service} in {env}")

    return {
        "service": service,
        "environment": env,
        "config": env_data["config"],
        "redacted_keys": env_data["redacted_keys"],
        "last_updated": env_data["last_updated"],
        "updated_by": env_data["updated_by"],
    }


@mcp.tool()
def get_service_health(ctx: Context, service: str, env: str = "prod") -> dict:
    """Check the health status of a deployed service.

    Args:
        service: Service name (e.g., 'api-gateway', 'user-service', 'payment-service',
                 'notification-service', 'search-service')
        env: Environment -- 'prod', 'staging', or 'dev' (default: 'prod')

    Returns:
        Dict with service, environment, status, uptime, replica counts, resource
        usage, and endpoint health details.
    """
    claims = validate_bearer_token(ctx)
    logger.info(
        "get_service_health called by sub=%s for service=%s env=%s",
        claims["sub"], service, env,
    )

    health_data = service_health.get(service, {}).get(env)
    if not health_data:
        raise ValueError(f"No health data found for {service} in {env}")

    return {
        "service": service,
        "environment": env,
        "status": health_data["status"],
        "uptime_seconds": health_data["uptime_seconds"],
        "replicas": health_data["replicas"],
        "cpu_percent": health_data["cpu_percent"],
        "memory_mb": health_data["memory_mb"],
        "last_restart": health_data["last_restart"],
        "endpoints": health_data["endpoints"],
    }


# ============================================================================
# Entry point
# ============================================================================

if __name__ == "__main__":
    logger.info("Starting DevOps Deploy MCP Server on %s:%d", SERVER_HOST, SERVER_PORT)
    mcp.run(transport="streamable-http", host=SERVER_HOST, port=SERVER_PORT)
