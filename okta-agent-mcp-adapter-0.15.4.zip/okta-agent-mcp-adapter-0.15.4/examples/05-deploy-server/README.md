# DevOps Deploy Server — Cross-App Access (ID-JAG) Demo

Example MCP backend demonstrating **Cross-App Access (XAA)** using **okta-jwt-verifier** for token validation.

This is the reference implementation for the `okta-cross-app` authentication pattern: the adapter looks up the user's stored id_token, uses it in an ID-JAG exchange to get AT-2, and this backend validates AT-2 using `okta-jwt-verifier` `AccessTokenVerifier.verify()`.

## Architecture: ID-JAG Token Flow

```
┌──────────────┐         ┌──────────────────────────────┐         ┌───────────────────┐
│   AI Agent   │         │   Okta MCP Adapter            │         │  Deploy Server    │
│ (VS Code /   │         │   Gateway                     │         │  (OK1Az2)         │
│  Claude Code)│         │                               │         │                   │
└──────┬───────┘         └──────────────┬───────────────┘         └────────┬──────────┘
       │                                │                                   │
       │  1. Bearer <AT-1>              │                                   │
       │  X-MCP-Agent: claude-code      │                                   │
       │───────────────────────────────>│                                   │
       │                                │                                   │
       │                      ┌─────────┴──────────────────┐                │
       │                      │ Step 1: Validate AT-1      │                │
       │                      │ against OK1Az1 JWKS        │                │
       │                      │                            │                │
       │                      │ Step 2: Look up stored     │                │
       │                      │ id_token from user token   │                │
       │                      │ store (captured at BFF     │                │
       │                      │ token exchange)            │                │
       │                      │                            │                │
       │                      │ Step 3: Issue ID-JAG JWT   │                │
       │                      │ using stored id_token      │                │
       │                      │ Exchange at OK1Az2 for     │                │
       │                      │ AT-2 (backend token)       │                │
       │                      └─────────┬──────────────────┘                │
       │                                │                                   │
       │                                │  Bearer <AT-2>                    │
       │                                │──────────────────────────────────>│
       │                                │                                   │
       │                                │                         ┌─────────┴─────────┐
       │                                │                         │ Step 4: Validate   │
       │                                │                         │ AT-2 via okta-jwt- │
       │                                │                         │ verifier           │
       │                                │                         │ AccessTokenVerifier│
       │                                │                         │ .verify()          │
       │                                │                         │                    │
       │                                │                         │ No private key     │
       │                                │                         │ needed — only      │
       │                                │                         │ verifies tokens    │
       │                                │                         └─────────┬─────────┘
       │                                │                                   │
       │                                │  Tool result (JSON)               │
       │                                │<──────────────────────────────────│
       │                                │                                   │
       │  Tool result                   │                                   │
       │<───────────────────────────────│                                   │
```

**Key:** The adapter performs id_token lookup + ID-JAG exchange (Steps 1-3). This backend only validates the resulting AT-2 (Step 4). It does NOT need a private key — it only calls `AccessTokenVerifier.verify()` which fetches JWKS from OK1Az2 automatically.

## Prerequisites

### Okta Setup for ID-JAG XAA

1. **Create OK1Az2** (backend authorization server) in Okta:
   - Add scopes: `mcp:read`, `mcp:write`
   - Add access policy with JWT Bearer grant rule
2. No OIDC application needs to be created for the deploy-server itself — it only validates tokens issued by the OK1Az2 custom AS.
3. **Configure the gateway backend** with `auth_method: okta-cross-app` (see `config/gateway-backend.yml`)

## Quick Start

### Local Development

```bash
cd examples/05-deploy-server
pip install -r requirements.txt
python server.py
```

### With Docker

```bash
cd examples/05-deploy-server
./start.sh
```

### XAA Mode (With Okta)

1. Complete the Okta setup above
2. Update the root `.env`:
   ```bash
   DEPLOY_OKTA_DOMAIN=dev-XXXXX.okta.com
   DEPLOY_OKTA_AUTH_SERVER_ID=ausYYYYYYYY
   DEPLOY_OKTA_AUDIENCE=api://deploy-server
   ```
3. Update the gateway backend via Admin API:
   ```bash
   curl -X PUT http://localhost:8000/api/admin/backends/deploy-server \
     -H "Authorization: Bearer $TOKEN" \
     -H "Content-Type: application/json" \
     -d '{
       "auth_config": {
         "target_authorization_server": "https://dev-XXXXX.okta.com/oauth2/ausYYYYYYYY",
         "target_token_endpoint": "https://dev-XXXXX.okta.com/oauth2/ausYYYYYYYY/v1/token",
         "scopes": ["mcp:read", "mcp:write"]
       }
     }'
   ```
4. Restart the stack: `docker compose up -d --build`

### Run E2E Tests

Requires full XAA mode with a valid Okta user token:

```bash
# Unified endpoint (POST /)
USER_TOKEN="eyJ..." ./test_e2e_xaa.sh

# Path-based route (POST /deploy)
USER_TOKEN="eyJ..." ./test_e2e_xaa_path.sh

# Verbose mode (shows full JSON-RPC request/response)
USER_TOKEN="eyJ..." ./test_e2e_xaa.sh --verbose
```

## Tool Reference

All tools require Bearer token authentication (validated via `okta-jwt-verifier`). The `sub` claim from the token identifies the user making the request.

### health_check

Health check endpoint (no auth required).

```
-> health_check()
<- {"status": "healthy", "service": "deploy-server", "port": 8005}
```

### get_deployments

List recent deployments for a service.

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| `service` | string | required | Service name (`api-gateway`, `user-service`, `payment-service`, `notification-service`, `search-service`) |
| `env` | string | `"prod"` | Environment filter: `prod`, `staging`, `dev`, or `all` |

### get_deploy_logs

Retrieve build/deploy logs for a specific deployment.

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| `deploy_id` | string | required | Deployment ID (e.g., `dep-1f64`) |
| `lines` | int | `50` | Maximum log lines to return |

### rollback_deployment

Initiate a rollback for a service to its previous version. Logs a warning if `mcp:write` scope is missing (does not block for demo purposes).

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| `service` | string | required | Service name |
| `env` | string | required | Target environment: `prod`, `staging`, or `dev` |
| `reason` | string | required | Reason for rollback |

`initiated_by` in the response is the `sub` claim from the validated XAA token — per-user attribution.

### get_env_config

Retrieve environment configuration for a service. Secret values are redacted.

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| `service` | string | required | Service name |
| `env` | string | `"prod"` | Environment: `prod`, `staging`, or `dev` |

`redacted_keys` demonstrates backend-level access control — even after XAA authentication succeeds, the backend enforces its own policies.

### get_service_health

Check the health status of a deployed service.

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| `service` | string | required | Service name |
| `env` | string | `"prod"` | Environment: `prod`, `staging`, or `dev` |

Health status correlates with deployment outcomes: successful deploys produce `healthy`, failed deploys produce `degraded`, rolled-back deploys produce `unhealthy`.

## Testing

### Unit Tests (65 tests)

```bash
cd examples/05-deploy-server

# Run all tests
pytest tests/ -v

# Run specific test file
pytest tests/test_auth.py -v        # 16 tests — SDK verification
pytest tests/test_tools.py -v       # 28 tests — tool functionality
pytest tests/test_data.py -v        # 21 tests — data integrity

# With coverage
pytest tests/ --cov=. --cov-report=term-missing
```

### End-to-End Tests

Require a running gateway + deploy server + valid Okta user token.

```bash
USER_TOKEN="eyJ..." ./test_e2e_xaa.sh          # Unified MCP endpoint
USER_TOKEN="eyJ..." ./test_e2e_xaa_path.sh      # Path-based proxy
USER_TOKEN="eyJ..." ./test_e2e_xaa.sh --verbose  # Full request/response JSON
```

## Configuration Reference

### Deploy Server Environment Variables

| Variable | Required | Default | Description |
|----------|----------|---------|-------------|
| `DEPLOY_OKTA_DOMAIN` | Yes | - | Okta org domain (e.g., `https://dev-XXXXX.okta.com`) |
| `DEPLOY_OKTA_CLIENT_ID` | Deprecated | - | No longer used. Logs a deprecation warning if set. Remove from `.env`. |
| `DEPLOY_OKTA_AUTH_SERVER_ID` | Yes | - | OK1Az2 Authorization Server ID |
| `DEPLOY_OKTA_AUDIENCE` | No | `api://deploy-server` | Expected `aud` claim |
| `SERVER_HOST` | No | `0.0.0.0` | Listen address |
| `SERVER_PORT` | No | `8005` | Listen port |
| `LOG_LEVEL` | No | `INFO` | Logging level |

**Note:** The deploy-server requires no client credentials whatsoever — no client_id, no client_secret, no private key. okta-jwt-verifier validates inbound access tokens using only the issuer URL and the expected audience, fetching the OK1Az2 JWKS internally.

### Gateway Backend Config (okta-cross-app)

See `config/gateway-backend.yml`:

```yaml
backends:
  deploy-server:
    url: http://deploy-mcp-server:8005
    paths: [/deploy]
    auth_method: okta-cross-app
    auth_config:
      target_authorization_server: https://dev-XXXXX.okta.com/oauth2/ausYYYYYYYY
      target_token_endpoint: https://dev-XXXXX.okta.com/oauth2/ausYYYYYYYY/v1/token
      scopes: [mcp:read, mcp:write]
```

## File Structure

```
05-deploy-server/
├── README.md                    # This file
├── server.py                    # FastMCP server with 5 tools
├── auth.py                      # Token verification (okta-jwt-verifier, no client credentials)
├── data.py                      # Deterministic deployment data generator
├── requirements.txt             # Python dependencies
├── Dockerfile                   # Container build (python:3.12-slim, non-root)
├── docker-compose.yml           # Deploy server service
├── docker-compose.override.yml  # Full stack (gateway + postgres + deploy)
├── .env.example                 # Environment variable template
├── start.sh                     # Convenience script for full stack
├── seed_deploy_backend.py       # Register backend via Admin API
├── test_e2e_xaa.sh              # E2E test — unified endpoint
├── test_e2e_xaa_path.sh         # E2E test — path-based route
├── config/
│   └── gateway-backend.yml      # Backend config for gateway
└── tests/
    ├── __init__.py
    ├── conftest.py              # Shared fixtures
    ├── helpers.py               # Mock objects (MockVerificationResult)
    ├── test_auth.py             # SDK verification tests (16)
    ├── test_tools.py            # Tool functionality tests (28)
    └── test_data.py             # Data integrity tests (21)
```

## Troubleshooting

### "Token verification failed" from deploy server

The gateway successfully exchanged the ID-JAG (Steps 1-3), but the deploy server rejects the resulting AT-2.

1. Check `DEPLOY_OKTA_DOMAIN` and `DEPLOY_OKTA_AUTH_SERVER_ID` together construct the expected issuer: `https://{DEPLOY_OKTA_DOMAIN}/oauth2/{DEPLOY_OKTA_AUTH_SERVER_ID}`. This must match the `iss` claim in the AT-2 token.
2. Check `DEPLOY_OKTA_AUTH_SERVER_ID` matches the authorization server that issued the token
3. Check `DEPLOY_OKTA_AUDIENCE` matches the `aud` claim (or omit to skip audience check)
4. Verify OK1Az2's JWKS endpoint is reachable: `curl https://your-org.okta.com/oauth2/ausXXXXXX/v1/keys`

### Gateway returns 502

The gateway accepted the user JWT but failed during the ID-JAG exchange.

1. Check that the agent has a stored id_token (captured during BFF token exchange)
2. Verify agent's `private_key` is configured in the gateway
3. Check gateway logs: `LOG_LEVEL=DEBUG docker compose logs -f gateway | grep -i "id-jag\|xaa"`

### Tools return 0 results

The data engine uses 5 specific service names: `api-gateway`, `user-service`, `payment-service`, `notification-service`, `search-service`. Check that your tool call uses one of these exact names.
