"""
Token verification for the Deploy Server using okta-jwt-verifier.

Wraps okta-jwt-verifier's AccessTokenVerifier for resource-server validation
of XAA AT-2 tokens. Requires only issuer (domain + auth server ID) and audience
-- no client_id, client_secret, or private key needed.

The server always verifies tokens.
Tests mock at the DeployTokenVerifier.verify() boundary.
"""

import asyncio
import logging
import os
import warnings
from typing import Any, Dict

from jose import jwt as jose_jwt
from okta_jwt_verifier import AccessTokenVerifier
from okta_jwt_verifier.exceptions import JWKException, JWTValidationException

logger = logging.getLogger(__name__)


class DeployTokenVerifier:
    """Validates Bearer tokens using okta-jwt-verifier AccessTokenVerifier.

    Only needs issuer + audience to verify access tokens. No client_id,
    client_secret, or private key required -- this is a pure resource server.
    """

    def __init__(
        self,
        okta_domain: str,
        auth_server_id: str,
        audience: str | None = None,
        leeway: int = 0,
    ):
        # Normalize domain
        okta_domain = okta_domain.rstrip("/")
        if okta_domain.startswith("http://"):
            okta_domain = okta_domain.replace("http://", "https://", 1)
        elif not okta_domain.startswith("https://"):
            okta_domain = f"https://{okta_domain}"

        self.issuer = f"{okta_domain}/oauth2/{auth_server_id}"
        self.audience = audience
        self.leeway = leeway

        self._verifier = AccessTokenVerifier(
            issuer=self.issuer,
            audience=self.audience,
            leeway=self.leeway,
        )

        logger.info(
            "DeployTokenVerifier initialized (issuer=%s, audience=%s)",
            self.issuer,
            self.audience,
        )

    def verify(self, token: str) -> Dict[str, Any]:
        """Validate a Bearer token via okta-jwt-verifier.

        Returns:
            Dict with keys: valid, sub, aud, iss, scope, exp

        Raises:
            ValueError: If the token is invalid or verification fails.
        """
        try:
            asyncio.run(self._verifier.verify(token))
        except JWTValidationException as e:
            logger.warning("Token verification failed: %s", e)
            raise ValueError(f"Token verification failed: {e}")
        except JWKException as e:
            logger.warning("JWKS error during token verification: %s", e)
            raise ValueError(f"Token verification failed: {e}")
        except Exception as e:
            logger.error("Unexpected error during token verification: %s", e)
            raise ValueError(f"Token verification failed: {e}")

        # Signature already validated by the SDK -- decode claims without re-verifying
        claims = jose_jwt.get_unverified_claims(token)

        # Okta uses "scp" (list) for access tokens; fall back to "scope" (string)
        scope = claims.get("scp", claims.get("scope"))
        if isinstance(scope, list):
            scope = " ".join(scope)

        result = {
            "valid": True,
            "sub": claims.get("sub"),
            "aud": claims.get("aud"),
            "iss": claims.get("iss"),
            "scope": scope,
            "exp": claims.get("exp"),
        }

        logger.info("Token verified -- sub=%s (XAA user identity)", result["sub"])
        logger.debug(
            "Token claims: aud=%s, iss=%s, scope=%s",
            result["aud"],
            result["iss"],
            result["scope"],
        )
        return result


def _init_verifier():
    """Create the module-level token verifier singleton."""
    domain = os.getenv("DEPLOY_OKTA_DOMAIN", "").strip()
    auth_server_id = os.getenv("DEPLOY_OKTA_AUTH_SERVER_ID", "").strip()
    audience = os.getenv("DEPLOY_OKTA_AUDIENCE", "").strip() or None
    legacy_cid = os.getenv("DEPLOY_OKTA_CLIENT_ID", "").strip()

    if legacy_cid:
        msg = (
            "DEPLOY_OKTA_CLIENT_ID is deprecated and ignored — the new okta-jwt-verifier "
            "SDK does not require a client_id for resource-server token validation. "
            "Remove this variable from your .env."
        )
        warnings.warn(msg, DeprecationWarning, stacklevel=2)
        logger.warning(msg)

    missing = []
    if not domain:
        missing.append("DEPLOY_OKTA_DOMAIN")
    if not auth_server_id:
        missing.append("DEPLOY_OKTA_AUTH_SERVER_ID")

    if missing:
        raise RuntimeError(
            f"Required environment variable(s) not set: {', '.join(missing)}. "
            "These are required for okta-jwt-verifier token validation. "
            "Set them in your .env file or environment."
        )

    return DeployTokenVerifier(
        okta_domain=domain,
        auth_server_id=auth_server_id,
        audience=audience,
    )
