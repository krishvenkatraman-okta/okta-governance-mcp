#!/usr/bin/env bash
# ============================================================================
# start.sh — Bring up the Deploy Server + Gateway integration stack
# ============================================================================
#
# Creates the shared Docker network, starts all services, waits for health,
# seeds the backend configuration, and prints connection instructions.
#
# Usage:
#   ./start.sh              # Full stack startup
#   ./start.sh --no-seed    # Start services without seeding
#   ./start.sh --down       # Tear down the stack
# ============================================================================

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"

COMPOSE_CMD="docker compose -f docker-compose.yml -f docker-compose.override.yml"
NETWORK_NAME="mcp-examples-net"
GATEWAY_URL="${GATEWAY_URL:-http://localhost:8000}"
MAX_WAIT=120  # seconds

# Colors (if terminal supports them)
if [ -t 1 ]; then
    GREEN='\033[0;32m'
    YELLOW='\033[1;33m'
    RED='\033[0;31m'
    NC='\033[0m'
else
    GREEN='' YELLOW='' RED='' NC=''
fi

info()  { echo -e "${GREEN}[INFO]${NC}  $*"; }
warn()  { echo -e "${YELLOW}[WARN]${NC}  $*"; }
error() { echo -e "${RED}[ERROR]${NC} $*" >&2; }

# ============================================================================
# Tear down
# ============================================================================
if [[ "${1:-}" == "--down" ]]; then
    info "Tearing down the stack..."
    $COMPOSE_CMD down -v
    info "Done."
    exit 0
fi

# ============================================================================
# Step 1: Create shared Docker network (if needed)
# ============================================================================
info "Ensuring Docker network '${NETWORK_NAME}' exists..."
if ! docker network inspect "$NETWORK_NAME" &>/dev/null; then
    docker network create "$NETWORK_NAME"
    info "  Created network '${NETWORK_NAME}'"
else
    info "  Network '${NETWORK_NAME}' already exists"
fi

# ============================================================================
# Step 2: Generate encryption key (if not set)
# ============================================================================
if [[ -z "${ENCRYPTION_KEY:-}" ]]; then
    if [[ -f .env ]] && grep -q "^ENCRYPTION_KEY=" .env; then
        info "Using ENCRYPTION_KEY from .env"
    else
        warn "ENCRYPTION_KEY not set — generating a temporary key for dev mode"
        ENCRYPTION_KEY=$(python3 -c "import base64, os; print(base64.urlsafe_b64encode(os.urandom(32)).decode())" 2>/dev/null || true)
        if [[ -n "$ENCRYPTION_KEY" ]]; then
            export ENCRYPTION_KEY
            info "  Generated temporary ENCRYPTION_KEY (not persisted)"
        else
            error "Failed to generate encryption key. Set ENCRYPTION_KEY in .env or environment."
            exit 1
        fi
    fi
fi

# ============================================================================
# Step 3: Build and start services
# ============================================================================
info "Building and starting services..."
$COMPOSE_CMD up --build -d

# ============================================================================
# Step 4: Wait for health checks
# ============================================================================
info "Waiting for services to become healthy (timeout: ${MAX_WAIT}s)..."

wait_for_service() {
    local service="$1"
    local elapsed=0
    while [[ $elapsed -lt $MAX_WAIT ]]; do
        local status
        status=$($COMPOSE_CMD ps --format json "$service" 2>/dev/null | python3 -c "
import sys, json
for line in sys.stdin:
    data = json.loads(line)
    print(data.get('Health', data.get('Status', 'unknown')))
    break
" 2>/dev/null || echo "unknown")

        if [[ "$status" == *"healthy"* ]]; then
            return 0
        fi
        sleep 2
        elapsed=$((elapsed + 2))
    done
    return 1
}

for service in postgres gateway deploy-mcp-server; do
    printf "  Waiting for %-20s " "$service..."
    if wait_for_service "$service"; then
        echo -e "${GREEN}healthy${NC}"
    else
        echo -e "${RED}timeout${NC}"
        error "Service '$service' did not become healthy within ${MAX_WAIT}s"
        error "Check logs: $COMPOSE_CMD logs $service"
        exit 1
    fi
done

# ============================================================================
# Step 5: Seed backend configuration
# ============================================================================
if [[ "${1:-}" != "--no-seed" ]]; then
    info "Seeding deploy-server backend configuration..."
    if python3 seed_deploy_backend.py; then
        info "Seed complete"
    else
        warn "Seed script failed — you may need to register the backend manually"
        warn "See config/gateway-backend.yml for the configuration"
    fi
else
    info "Skipping seed (--no-seed)"
fi

# ============================================================================
# Step 6: Print connection instructions
# ============================================================================
echo ""
echo "============================================"
echo " Deploy Server Integration Stack — Ready"
echo "============================================"
echo ""
echo " Services:"
echo "   Gateway:       ${GATEWAY_URL}"
echo "   Deploy Server: http://localhost:8005"
echo "   PostgreSQL:    localhost:${POSTGRES_PORT:-5433}"
echo ""
echo " Admin API (requires Okta access token — export OKTA_ADMIN_TOKEN):"
echo "   Agents:     GET ${GATEWAY_URL}/api/admin/agents -H \"Authorization: Bearer \$OKTA_ADMIN_TOKEN\""
echo "   Resources:  GET ${GATEWAY_URL}/api/admin/resources"
echo ""
echo " MCP Endpoint (via gateway):"
echo "   POST ${GATEWAY_URL}/deploy"
echo ""
echo " Logs:"
echo "   $COMPOSE_CMD logs -f"
echo "   $COMPOSE_CMD logs -f deploy-mcp-server"
echo "   $COMPOSE_CMD logs -f gateway"
echo ""
echo " Tear down:"
echo "   ./start.sh --down"
echo ""
