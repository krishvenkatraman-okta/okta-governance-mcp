#!/usr/bin/env python3
"""
Seed the deploy-server backend and update agent access via the Admin API.

Registers the deploy-server backend with okta-cross-app auth and grants
access to the claude-code and cursor agents.

Idempotent — safe to run multiple times (409 duplicates are handled gracefully).

Usage:
    # Obtain an Okta access token (sign in to the Admin UI and copy it from
    # browser devtools, or use the okta CLI), then:
    export OKTA_ADMIN_TOKEN="<token>"
    python seed_deploy_backend.py

    # Custom gateway URL
    GATEWAY_URL=http://gateway:8000 OKTA_ADMIN_TOKEN=... python seed_deploy_backend.py
"""

import json
import os
import sys
import time
import logging

logging.basicConfig(level=logging.INFO, format="%(message)s")
logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------

GATEWAY_URL = os.getenv("GATEWAY_URL", "http://localhost:8000")
OKTA_ADMIN_TOKEN = os.getenv("OKTA_ADMIN_TOKEN", "").strip()
MAX_RETRIES = int(os.getenv("SEED_MAX_RETRIES", "5"))
RETRY_DELAY = int(os.getenv("SEED_RETRY_DELAY", "3"))

# Agents that should get deploy-server access
TARGET_AGENTS = ["claude-code", "cursor"]

# Backend definition (matches config/gateway-backend.yml)
DEPLOY_BACKEND = {
    "name": "deploy-server",
    "url": "http://deploy-mcp-server:8005",
    "paths": ["/deploy"],
    "auth_method": "okta-cross-app",
    "auth_config": {
        "target_authorization_server": os.getenv(
            "DEPLOY_TARGET_AUTH_SERVER",
            "https://your-org-b.okta.com/oauth2/ausXXXXXXXX",
        ),
        "target_token_endpoint": os.getenv(
            "DEPLOY_TARGET_TOKEN_ENDPOINT",
            "https://your-org-b.okta.com/oauth2/ausXXXXXXXX/v1/token",
        ),
        "scopes": ["mcp:read", "mcp:write"],
    },
    "description": "DevOps Deploy Server — cross-app access (ID-JAG) demo",
    "timeout_seconds": 30,
    "enabled": True,
}


# ---------------------------------------------------------------------------
# HTTP helpers (using urllib to avoid extra dependencies)
# ---------------------------------------------------------------------------

try:
    import httpx

    def _request(method, url, headers=None, json_body=None, timeout=10):
        with httpx.Client(timeout=timeout) as client:
            resp = client.request(method, url, headers=headers, json=json_body)
            return resp.status_code, resp.json() if resp.content else {}

except ImportError:
    import urllib.request
    import urllib.error

    def _request(method, url, headers=None, json_body=None, timeout=10):
        data = json.dumps(json_body).encode() if json_body else None
        req = urllib.request.Request(url, data=data, method=method)
        req.add_header("Content-Type", "application/json")
        if headers:
            for k, v in headers.items():
                req.add_header(k, v)
        try:
            with urllib.request.urlopen(req, timeout=timeout) as resp:
                body = resp.read().decode()
                return resp.status, json.loads(body) if body else {}
        except urllib.error.HTTPError as e:
            body = e.read().decode()
            return e.code, json.loads(body) if body else {}


# ---------------------------------------------------------------------------
# Admin API operations
# ---------------------------------------------------------------------------

def admin_login() -> str:
    """Return the Okta access token for Admin API calls.

    Password login was removed in v0.15.x; the adapter accepts only Okta
    OAuth access tokens. Callers must export OKTA_ADMIN_TOKEN with a token
    issued by the Admin UI's Okta OIDC app.
    """
    if not OKTA_ADMIN_TOKEN:
        raise RuntimeError(
            "OKTA_ADMIN_TOKEN is not set.\n"
            "Sign in to the Admin UI, copy the access token from browser devtools, "
            "and export it:\n"
            "    export OKTA_ADMIN_TOKEN=\"<token>\""
        )
    return OKTA_ADMIN_TOKEN


def auth_headers(token: str) -> dict:
    return {"Authorization": f"Bearer {token}"}


def create_backend(token: str) -> bool:
    """Create the deploy-server backend. Returns True if created, False if exists."""
    url = f"{GATEWAY_URL}/api/admin/backends"
    status, body = _request("POST", url, headers=auth_headers(token), json_body=DEPLOY_BACKEND)

    if status == 201:
        logger.info("  + Backend 'deploy-server' created")
        return True
    elif status == 409:
        logger.info("  = Backend 'deploy-server' already exists, skipping")
        return False
    else:
        raise RuntimeError(f"Failed to create backend (HTTP {status}): {body}")


def grant_agent_access(token: str, agent_id: str) -> bool:
    """Add 'deploy-server' to an agent's backend_access list.

    Returns True if updated, False if already has access or agent not found.
    """
    # Fetch current agent config
    url = f"{GATEWAY_URL}/api/admin/agents/{agent_id}"
    status, body = _request("GET", url, headers=auth_headers(token))

    if status == 404:
        logger.info(f"  ! Agent '{agent_id}' not found, skipping")
        return False

    if status != 200:
        raise RuntimeError(f"Failed to get agent '{agent_id}' (HTTP {status}): {body}")

    # Check if deploy-server is already in backend_access
    current_access = body.get("backend_access", [])
    if "deploy-server" in current_access:
        logger.info(f"  = Agent '{agent_id}' already has deploy-server access")
        return False

    # Add deploy-server to backend_access
    updated_access = current_access + ["deploy-server"]
    status, body = _request("PUT", url, headers=auth_headers(token), json_body={
        "backend_access": updated_access,
    })

    if status == 200:
        logger.info(f"  + Agent '{agent_id}' granted deploy-server access")
        return True
    else:
        raise RuntimeError(f"Failed to update agent '{agent_id}' (HTTP {status}): {body}")


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def wait_for_gateway():
    """Wait for the gateway to become healthy before seeding."""
    url = f"{GATEWAY_URL}/.well-known/oauth-protected-resource"
    for attempt in range(1, MAX_RETRIES + 1):
        try:
            status, _ = _request("GET", url, timeout=5)
            if status == 200:
                return
        except Exception:
            pass
        if attempt < MAX_RETRIES:
            logger.info(f"  Waiting for gateway ({attempt}/{MAX_RETRIES})...")
            time.sleep(RETRY_DELAY)
    raise RuntimeError(f"Gateway not reachable at {GATEWAY_URL} after {MAX_RETRIES} attempts")


def main():
    logger.info("=== Deploy Server Seed Script ===")
    logger.info(f"Gateway: {GATEWAY_URL}")
    logger.info("")

    # Wait for gateway health
    logger.info("[1/3] Waiting for gateway...")
    wait_for_gateway()
    logger.info("  Gateway is healthy")
    logger.info("")

    # Authenticate
    logger.info("[2/3] Registering backend...")
    token = admin_login()
    create_backend(token)
    logger.info("")

    # Grant agent access
    logger.info("[3/3] Granting agent access...")
    for agent_id in TARGET_AGENTS:
        grant_agent_access(token, agent_id)
    logger.info("")

    logger.info("=== Seed complete ===")


if __name__ == "__main__":
    try:
        main()
    except RuntimeError as e:
        logger.error(f"ERROR: {e}")
        sys.exit(1)
    except KeyboardInterrupt:
        logger.info("\nAborted")
        sys.exit(130)
