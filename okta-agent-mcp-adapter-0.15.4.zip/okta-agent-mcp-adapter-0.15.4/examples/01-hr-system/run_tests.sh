#!/bin/bash
set -e

echo "Installing test dependencies..."
pip install --quiet --index-url https://pypi.org/simple -r requirements.txt

echo "Running tests..."
pytest tests/ -v --tb=short
