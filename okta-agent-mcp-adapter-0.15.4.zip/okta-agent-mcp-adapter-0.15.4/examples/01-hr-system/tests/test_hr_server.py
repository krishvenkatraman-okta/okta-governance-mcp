"""
Tests for HR MCP Server

Tests all 6 tools with valid authentication, invalid authentication,
and various edge cases.
"""

import os
import pytest
from typing import Dict, Any
import httpx

# Test configuration
TEST_PSK_SECRET = os.getenv("PSK_SECRET", "test-secret-key-12345")
SERVER_URL = os.getenv("SERVER_URL", "http://localhost:8001")
MCP_ENDPOINT = f"{SERVER_URL}/mcp"  # MCP servers use /mcp endpoint

# ============================================================================
# FIXTURES
# ============================================================================

@pytest.fixture
def valid_headers() -> Dict[str, str]:
    """Valid authentication headers for testing."""
    return {
        "X-API-Key": TEST_PSK_SECRET,
        "Content-Type": "application/json",
        "Accept": "application/json, text/event-stream"
    }


@pytest.fixture
def invalid_headers() -> Dict[str, str]:
    """Invalid authentication headers for testing."""
    return {
        "X-API-Key": "wrong-key",
        "Content-Type": "application/json",
        "Accept": "application/json, text/event-stream"
    }


# ============================================================================
# HEALTH CHECK TESTS
# ============================================================================

@pytest.mark.asyncio
async def test_health_check():
    """Test health check endpoint (no auth required)."""
    headers = {
        "Content-Type": "application/json",
        "Accept": "application/json, text/event-stream"
    }
    async with httpx.AsyncClient() as client:
        response = await client.post(
            MCP_ENDPOINT,
            headers=headers,
            json={
                "jsonrpc": "2.0",
                "id": 1,
                "method": "tools/call",
                "params": {
                    "name": "health_check",
                    "arguments": {}
                }
            }
        )

        assert response.status_code == 200
        # Parse SSE response
        text = response.text
        assert "HR System MCP Server is healthy" in text


# ============================================================================
# GET EMPLOYEE TESTS
# ============================================================================

@pytest.mark.asyncio
async def test_get_employee_success(valid_headers):
    """Test retrieving a valid employee."""
    async with httpx.AsyncClient() as client:
        response = await client.post(
            MCP_ENDPOINT,
            headers=valid_headers,
            json={
                "jsonrpc": "2.0",
                "id": 1,
                "method": "tools/call",
                "params": {
                    "name": "get_employee",
                    "arguments": {"employee_id": "E001"}
                }
            }
        )

        assert response.status_code == 200
        data = response.json()
        assert "result" in data

        result = data["result"]
        assert result["content"][0]["text"]["id"] == "E001"
        assert result["content"][0]["text"]["name"] == "Sarah Chen"
        assert result["content"][0]["text"]["department"] == "Engineering"
        assert result["content"][0]["text"]["title"] == "Chief Technology Officer"


@pytest.mark.asyncio
async def test_get_employee_not_found(valid_headers):
    """Test retrieving a non-existent employee."""
    async with httpx.AsyncClient() as client:
        response = await client.post(
            MCP_ENDPOINT,
            headers=valid_headers,
            json={
                "jsonrpc": "2.0",
                "id": 1,
                "method": "tools/call",
                "params": {
                    "name": "get_employee",
                    "arguments": {"employee_id": "E999"}
                }
            }
        )

        assert response.status_code == 200
        data = response.json()
        assert "error" in data
        assert "not found" in data["error"]["message"].lower()


@pytest.mark.asyncio
async def test_get_employee_invalid_auth(invalid_headers):
    """Test get_employee with invalid API key."""
    async with httpx.AsyncClient() as client:
        response = await client.post(
            MCP_ENDPOINT,
            headers=invalid_headers,
            json={
                "jsonrpc": "2.0",
                "id": 1,
                "method": "tools/call",
                "params": {
                    "name": "get_employee",
                    "arguments": {"employee_id": "E001"}
                }
            }
        )

        assert response.status_code == 200
        data = response.json()
        assert "error" in data
        assert "invalid api key" in data["error"]["message"].lower()


@pytest.mark.asyncio
async def test_get_employee_missing_auth():
    """Test get_employee without API key header."""
    async with httpx.AsyncClient() as client:
        response = await client.post(
            MCP_ENDPOINT,
            json={
                "jsonrpc": "2.0",
                "id": 1,
                "method": "tools/call",
                "params": {
                    "name": "get_employee",
                    "arguments": {"employee_id": "E001"}
                }
            }
        )

        assert response.status_code == 200
        data = response.json()
        assert "error" in data
        assert "missing" in data["error"]["message"].lower()


# ============================================================================
# SEARCH EMPLOYEES TESTS
# ============================================================================

@pytest.mark.asyncio
async def test_search_employees_by_name(valid_headers):
    """Test searching employees by name."""
    async with httpx.AsyncClient() as client:
        response = await client.post(
            MCP_ENDPOINT,
            headers=valid_headers,
            json={
                "jsonrpc": "2.0",
                "id": 1,
                "method": "tools/call",
                "params": {
                    "name": "search_employees",
                    "arguments": {"query": "Chen"}
                }
            }
        )

        assert response.status_code == 200
        data = response.json()
        assert "result" in data

        results = data["result"]["content"][0]["text"]
        assert len(results) >= 1
        assert any(emp["name"] == "Sarah Chen" for emp in results)


@pytest.mark.asyncio
async def test_search_employees_by_department(valid_headers):
    """Test searching employees by department."""
    async with httpx.AsyncClient() as client:
        response = await client.post(
            MCP_ENDPOINT,
            headers=valid_headers,
            json={
                "jsonrpc": "2.0",
                "id": 1,
                "method": "tools/call",
                "params": {
                    "name": "search_employees",
                    "arguments": {
                        "query": "",
                        "department": "Engineering"
                    }
                }
            }
        )

        assert response.status_code == 200
        data = response.json()
        assert "result" in data

        results = data["result"]["content"][0]["text"]
        assert len(results) >= 1
        assert all(emp["department"] == "Engineering" for emp in results)


@pytest.mark.asyncio
async def test_search_employees_combined_filter(valid_headers):
    """Test searching with both name and department filters."""
    async with httpx.AsyncClient() as client:
        response = await client.post(
            MCP_ENDPOINT,
            headers=valid_headers,
            json={
                "jsonrpc": "2.0",
                "id": 1,
                "method": "tools/call",
                "params": {
                    "name": "search_employees",
                    "arguments": {
                        "query": "Johnson",
                        "department": "Engineering"
                    }
                }
            }
        )

        assert response.status_code == 200
        data = response.json()
        assert "result" in data

        results = data["result"]["content"][0]["text"]
        assert len(results) == 1
        assert results[0]["name"] == "Marcus Johnson"
        assert results[0]["department"] == "Engineering"


@pytest.mark.asyncio
async def test_search_employees_no_results(valid_headers):
    """Test search with no matching results."""
    async with httpx.AsyncClient() as client:
        response = await client.post(
            MCP_ENDPOINT,
            headers=valid_headers,
            json={
                "jsonrpc": "2.0",
                "id": 1,
                "method": "tools/call",
                "params": {
                    "name": "search_employees",
                    "arguments": {"query": "NonExistentName"}
                }
            }
        )

        assert response.status_code == 200
        data = response.json()
        assert "result" in data

        results = data["result"]["content"][0]["text"]
        assert len(results) == 0


# ============================================================================
# ORG CHART TESTS
# ============================================================================

@pytest.mark.asyncio
async def test_get_org_chart_full(valid_headers):
    """Test retrieving full organizational chart."""
    async with httpx.AsyncClient() as client:
        response = await client.post(
            MCP_ENDPOINT,
            headers=valid_headers,
            json={
                "jsonrpc": "2.0",
                "id": 1,
                "method": "tools/call",
                "params": {
                    "name": "get_org_chart",
                    "arguments": {}
                }
            }
        )

        assert response.status_code == 200
        data = response.json()
        assert "result" in data

        org_chart = data["result"]["content"][0]["text"]
        assert "organization" in org_chart
        assert "leadership_team" in org_chart
        assert len(org_chart["leadership_team"]) > 0


@pytest.mark.asyncio
async def test_get_org_chart_specific_employee(valid_headers):
    """Test retrieving org chart for specific employee."""
    async with httpx.AsyncClient() as client:
        response = await client.post(
            MCP_ENDPOINT,
            headers=valid_headers,
            json={
                "jsonrpc": "2.0",
                "id": 1,
                "method": "tools/call",
                "params": {
                    "name": "get_org_chart",
                    "arguments": {"employee_id": "E002"}
                }
            }
        )

        assert response.status_code == 200
        data = response.json()
        assert "result" in data

        org_chart = data["result"]["content"][0]["text"]
        assert org_chart["id"] == "E002"
        assert org_chart["name"] == "Marcus Johnson"
        assert "direct_reports" in org_chart


@pytest.mark.asyncio
async def test_get_org_chart_employee_not_found(valid_headers):
    """Test org chart with non-existent employee."""
    async with httpx.AsyncClient() as client:
        response = await client.post(
            MCP_ENDPOINT,
            headers=valid_headers,
            json={
                "jsonrpc": "2.0",
                "id": 1,
                "method": "tools/call",
                "params": {
                    "name": "get_org_chart",
                    "arguments": {"employee_id": "E999"}
                }
            }
        )

        assert response.status_code == 200
        data = response.json()
        assert "error" in data
        assert "not found" in data["error"]["message"].lower()


# ============================================================================
# LEAVE BALANCE TESTS
# ============================================================================

@pytest.mark.asyncio
async def test_get_leave_balance_success(valid_headers):
    """Test retrieving employee leave balance."""
    async with httpx.AsyncClient() as client:
        response = await client.post(
            MCP_ENDPOINT,
            headers=valid_headers,
            json={
                "jsonrpc": "2.0",
                "id": 1,
                "method": "tools/call",
                "params": {
                    "name": "get_leave_balance",
                    "arguments": {"employee_id": "E001"}
                }
            }
        )

        assert response.status_code == 200
        data = response.json()
        assert "result" in data

        balance = data["result"]["content"][0]["text"]
        assert balance["employee_id"] == "E001"
        assert "vacation_days" in balance
        assert "sick_days" in balance
        assert "personal_days" in balance
        assert "remaining_vacation" in balance
        assert "remaining_sick" in balance
        assert "remaining_personal" in balance


@pytest.mark.asyncio
async def test_get_leave_balance_not_found(valid_headers):
    """Test leave balance for non-existent employee."""
    async with httpx.AsyncClient() as client:
        response = await client.post(
            MCP_ENDPOINT,
            headers=valid_headers,
            json={
                "jsonrpc": "2.0",
                "id": 1,
                "method": "tools/call",
                "params": {
                    "name": "get_leave_balance",
                    "arguments": {"employee_id": "E999"}
                }
            }
        )

        assert response.status_code == 200
        data = response.json()
        assert "error" in data
        assert "not found" in data["error"]["message"].lower()


# ============================================================================
# SUBMIT LEAVE REQUEST TESTS
# ============================================================================

@pytest.mark.asyncio
async def test_submit_leave_request_success(valid_headers):
    """Test submitting a valid leave request."""
    async with httpx.AsyncClient() as client:
        response = await client.post(
            MCP_ENDPOINT,
            headers=valid_headers,
            json={
                "jsonrpc": "2.0",
                "id": 1,
                "method": "tools/call",
                "params": {
                    "name": "submit_leave_request",
                    "arguments": {
                        "employee_id": "E003",
                        "leave_type": "vacation",
                        "start_date": "2025-06-01",
                        "end_date": "2025-06-05",
                        "reason": "Summer vacation"
                    }
                }
            }
        )

        assert response.status_code == 200
        data = response.json()
        assert "result" in data

        request = data["result"]["content"][0]["text"]
        assert request["employee_id"] == "E003"
        assert request["type"] == "vacation"
        assert request["start_date"] == "2025-06-01"
        assert request["end_date"] == "2025-06-05"
        assert request["days"] == 5
        assert request["status"] == "pending"


@pytest.mark.asyncio
async def test_submit_leave_request_invalid_type(valid_headers):
    """Test submitting leave request with invalid type."""
    async with httpx.AsyncClient() as client:
        response = await client.post(
            MCP_ENDPOINT,
            headers=valid_headers,
            json={
                "jsonrpc": "2.0",
                "id": 1,
                "method": "tools/call",
                "params": {
                    "name": "submit_leave_request",
                    "arguments": {
                        "employee_id": "E003",
                        "leave_type": "invalid_type",
                        "start_date": "2025-06-01",
                        "end_date": "2025-06-05",
                        "reason": "Test"
                    }
                }
            }
        )

        assert response.status_code == 200
        data = response.json()
        assert "error" in data
        assert "invalid leave_type" in data["error"]["message"].lower()


@pytest.mark.asyncio
async def test_submit_leave_request_invalid_dates(valid_headers):
    """Test submitting leave request with invalid date format."""
    async with httpx.AsyncClient() as client:
        response = await client.post(
            MCP_ENDPOINT,
            headers=valid_headers,
            json={
                "jsonrpc": "2.0",
                "id": 1,
                "method": "tools/call",
                "params": {
                    "name": "submit_leave_request",
                    "arguments": {
                        "employee_id": "E003",
                        "leave_type": "vacation",
                        "start_date": "06/01/2025",  # Wrong format
                        "end_date": "2025-06-05",
                        "reason": "Test"
                    }
                }
            }
        )

        assert response.status_code == 200
        data = response.json()
        assert "error" in data
        assert "invalid date format" in data["error"]["message"].lower()


@pytest.mark.asyncio
async def test_submit_leave_request_end_before_start(valid_headers):
    """Test submitting leave request with end date before start date."""
    async with httpx.AsyncClient() as client:
        response = await client.post(
            MCP_ENDPOINT,
            headers=valid_headers,
            json={
                "jsonrpc": "2.0",
                "id": 1,
                "method": "tools/call",
                "params": {
                    "name": "submit_leave_request",
                    "arguments": {
                        "employee_id": "E003",
                        "leave_type": "vacation",
                        "start_date": "2025-06-10",
                        "end_date": "2025-06-05",  # Before start
                        "reason": "Test"
                    }
                }
            }
        )

        assert response.status_code == 200
        data = response.json()
        assert "error" in data
        assert "after start date" in data["error"]["message"].lower()


@pytest.mark.asyncio
async def test_submit_leave_request_employee_not_found(valid_headers):
    """Test submitting leave request for non-existent employee."""
    async with httpx.AsyncClient() as client:
        response = await client.post(
            MCP_ENDPOINT,
            headers=valid_headers,
            json={
                "jsonrpc": "2.0",
                "id": 1,
                "method": "tools/call",
                "params": {
                    "name": "submit_leave_request",
                    "arguments": {
                        "employee_id": "E999",
                        "leave_type": "vacation",
                        "start_date": "2025-06-01",
                        "end_date": "2025-06-05",
                        "reason": "Test"
                    }
                }
            }
        )

        assert response.status_code == 200
        data = response.json()
        assert "error" in data
        assert "not found" in data["error"]["message"].lower()


# ============================================================================
# INTEGRATION TESTS
# ============================================================================

@pytest.mark.asyncio
async def test_full_employee_workflow(valid_headers):
    """Test complete workflow: get employee, check balance, submit request."""
    async with httpx.AsyncClient() as client:
        # 1. Get employee details
        response1 = await client.post(
            MCP_ENDPOINT,
            headers=valid_headers,
            json={
                "jsonrpc": "2.0",
                "id": 1,
                "method": "tools/call",
                "params": {
                    "name": "get_employee",
                    "arguments": {"employee_id": "E004"}
                }
            }
        )
        assert response1.status_code == 200
        employee = response1.json()["result"]["content"][0]["text"]
        assert employee["id"] == "E004"

        # 2. Check leave balance
        response2 = await client.post(
            MCP_ENDPOINT,
            headers=valid_headers,
            json={
                "jsonrpc": "2.0",
                "id": 2,
                "method": "tools/call",
                "params": {
                    "name": "get_leave_balance",
                    "arguments": {"employee_id": "E004"}
                }
            }
        )
        assert response2.status_code == 200
        balance = response2.json()["result"]["content"][0]["text"]
        assert balance["employee_id"] == "E004"
        assert balance["remaining_vacation"] > 0

        # 3. Submit leave request
        response3 = await client.post(
            MCP_ENDPOINT,
            headers=valid_headers,
            json={
                "jsonrpc": "2.0",
                "id": 3,
                "method": "tools/call",
                "params": {
                    "name": "submit_leave_request",
                    "arguments": {
                        "employee_id": "E004",
                        "leave_type": "vacation",
                        "start_date": "2025-08-15",
                        "end_date": "2025-08-20",
                        "reason": "Family vacation"
                    }
                }
            }
        )
        assert response3.status_code == 200
        request = response3.json()["result"]["content"][0]["text"]
        assert request["status"] == "pending"
        assert request["days"] == 6


@pytest.mark.asyncio
async def test_search_and_get_org_chart(valid_headers):
    """Test workflow: search for manager, get their org chart."""
    async with httpx.AsyncClient() as client:
        # 1. Search for managers in Engineering
        response1 = await client.post(
            MCP_ENDPOINT,
            headers=valid_headers,
            json={
                "jsonrpc": "2.0",
                "id": 1,
                "method": "tools/call",
                "params": {
                    "name": "search_employees",
                    "arguments": {
                        "query": "Johnson",
                        "department": "Engineering"
                    }
                }
            }
        )
        assert response1.status_code == 200
        results = response1.json()["result"]["content"][0]["text"]
        manager_id = results[0]["id"]

        # 2. Get org chart for that manager
        response2 = await client.post(
            MCP_ENDPOINT,
            headers=valid_headers,
            json={
                "jsonrpc": "2.0",
                "id": 2,
                "method": "tools/call",
                "params": {
                    "name": "get_org_chart",
                    "arguments": {"employee_id": manager_id}
                }
            }
        )
        assert response2.status_code == 200
        org_chart = response2.json()["result"]["content"][0]["text"]
        assert org_chart["id"] == manager_id
        assert "direct_reports" in org_chart
