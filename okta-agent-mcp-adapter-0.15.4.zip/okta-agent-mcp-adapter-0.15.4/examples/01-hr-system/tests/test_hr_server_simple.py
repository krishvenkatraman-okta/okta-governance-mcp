"""
Simplified tests for HR MCP Server using FastMCP Client

These tests use the FastMCP Client which handles the MCP protocol correctly.
"""

import os
import pytest
from fastmcp import Client

# Test configuration
TEST_PSK_SECRET = os.getenv("PSK_SECRET", "test-secret-key-12345")
SERVER_URL = os.getenv("SERVER_URL", "http://localhost:8001")
MCP_ENDPOINT = SERVER_URL  # Client will append /mcp automatically

# Custom headers for authentication
AUTH_HEADERS = {
    "X-API-Key": TEST_PSK_SECRET
}

# ============================================================================
# HEALTH CHECK TEST
# ============================================================================

@pytest.mark.asyncio
async def test_health_check():
    """Test health check tool."""
    async with Client(MCP_ENDPOINT, headers=AUTH_HEADERS) as client:
        result = await client.call_tool("health_check", arguments={})
        assert "HR System MCP Server is healthy" in str(result)


# ============================================================================
# GET EMPLOYEE TESTS
# ============================================================================

@pytest.mark.asyncio
async def test_get_employee_success():
    """Test retrieving a valid employee."""
    async with Client(MCP_ENDPOINT, headers=AUTH_HEADERS) as client:
        result = await client.call_tool("get_employee", arguments={"employee_id": "E001"})
        assert "Sarah Chen" in str(result)
        assert "Engineering" in str(result)


@pytest.mark.asyncio
async def test_get_employee_not_found():
    """Test retrieving a non-existent employee."""
    async with Client(MCP_ENDPOINT, headers=AUTH_HEADERS) as client:
        try:
            await client.call_tool("get_employee", arguments={"employee_id": "E999"})
            assert False, "Should have raised an error"
        except Exception as e:
            assert "not found" in str(e).lower()


# ============================================================================
# SEARCH EMPLOYEES TESTS
# ============================================================================

@pytest.mark.asyncio
async def test_search_employees_by_name():
    """Test searching employees by name."""
    async with Client(MCP_ENDPOINT, headers=AUTH_HEADERS) as client:
        result = await client.call_tool("search_employees", arguments={"query": "Chen", "department": None})
        assert "Sarah Chen" in str(result)


@pytest.mark.asyncio
async def test_search_employees_by_department():
    """Test searching employees by department."""
    async with Client(MCP_ENDPOINT, headers=AUTH_HEADERS) as client:
        result = await client.call_tool("search_employees", arguments={"query": "", "department": "Engineering"})
        assert "Engineering" in str(result)


# ============================================================================
# ORG CHART TESTS
# ============================================================================

@pytest.mark.asyncio
async def test_get_org_chart_full():
    """Test retrieving full organizational chart."""
    async with Client(MCP_ENDPOINT, headers=AUTH_HEADERS) as client:
        result = await client.call_tool("get_org_chart", arguments={})
        assert "organization" in str(result).lower() or "leadership" in str(result).lower()


@pytest.mark.asyncio
async def test_get_org_chart_specific_employee():
    """Test retrieving org chart for specific employee."""
    async with Client(MCP_ENDPOINT, headers=AUTH_HEADERS) as client:
        result = await client.call_tool("get_org_chart", arguments={"employee_id": "E002"})
        assert "Marcus Johnson" in str(result)


# ============================================================================
# LEAVE BALANCE TESTS
# ============================================================================

@pytest.mark.asyncio
async def test_get_leave_balance_success():
    """Test retrieving employee leave balance."""
    async with Client(MCP_ENDPOINT, headers=AUTH_HEADERS) as client:
        result = await client.call_tool("get_leave_balance", arguments={"employee_id": "E001"})
        assert "vacation_days" in str(result) or "vacation" in str(result).lower()


# ============================================================================
# SUBMIT LEAVE REQUEST TESTS
# ============================================================================

@pytest.mark.asyncio
async def test_submit_leave_request_success():
    """Test submitting a valid leave request."""
    async with Client(MCP_ENDPOINT, headers=AUTH_HEADERS) as client:
        result = await client.call_tool(
            "submit_leave_request",
            arguments={
                "employee_id": "E003",
                "leave_type": "vacation",
                "start_date": "2025-06-01",
                "end_date": "2025-06-05",
                "reason": "Summer vacation"
            }
        )
        assert "pending" in str(result).lower() or "vacation" in str(result).lower()


@pytest.mark.asyncio
async def test_submit_leave_request_invalid_type():
    """Test submitting leave request with invalid type."""
    async with Client(MCP_ENDPOINT, headers=AUTH_HEADERS) as client:
        try:
            await client.call_tool(
                "submit_leave_request",
                arguments={
                    "employee_id": "E003",
                    "leave_type": "invalid_type",
                    "start_date": "2025-06-01",
                    "end_date": "2025-06-05",
                    "reason": "Test"
                }
            )
            assert False, "Should have raised an error"
        except Exception as e:
            assert "invalid" in str(e).lower()


# ============================================================================
# INTEGRATION TESTS
# ============================================================================

@pytest.mark.asyncio
async def test_full_employee_workflow():
    """Test complete workflow: get employee, check balance, submit request."""
    async with Client(MCP_ENDPOINT, headers=AUTH_HEADERS) as client:
        # 1. Get employee details
        result1 = await client.call_tool("get_employee", arguments={"employee_id": "E004"})
        assert "E004" in str(result1)

        # 2. Check leave balance
        result2 = await client.call_tool("get_leave_balance", arguments={"employee_id": "E004"})
        assert "vacation" in str(result2).lower()

        # 3. Submit leave request
        result3 = await client.call_tool(
            "submit_leave_request",
            arguments={
                "employee_id": "E004",
                "leave_type": "vacation",
                "start_date": "2025-08-15",
                "end_date": "2025-08-20",
                "reason": "Family vacation"
            }
        )
        assert "pending" in str(result3).lower() or "vacation" in str(result3).lower()
