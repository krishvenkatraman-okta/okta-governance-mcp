# HR MCP Server Example

Complete reference implementation of an MCP backend server demonstrating Pre-Shared Key (PSK) authentication with the Okta MCP Adapter gateway.

## Overview

This example provides a fully functional HR system with 6 MCP tools covering employee data management, organizational charts, and leave management. It demonstrates:

- **Pre-Shared Key (PSK)** authentication pattern
- **Streamable HTTP** transport for remote hosting
- **Realistic mock data** for compelling demos
- **Docker multi-service** deployment
- **Comprehensive test coverage** (18+ test cases)

## Quick Start

### 1. Prerequisites

- Docker and Docker Compose installed
- Okta account with MCP Adapter configured
- Python 3.12+ (for local development)

### 2. Setup Environment

```bash
# Copy environment template
cp .env.example .env

# Edit .env and set required values
# - OKTA_DOMAIN: Your Okta domain
# - HR_PSK_SECRET: Generate with: openssl rand -base64 32
```

### 3. Start Services

```bash
# Build and start both gateway and HR server
docker compose up --build

# Or start in detached mode
docker compose up -d

# View logs
docker compose logs -f
```

### 4. Verify Services

```bash
# Check health status
curl http://localhost:8000/.well-known/oauth-protected-resource
curl http://localhost:8001/

# Test HR server directly (with PSK)
curl -X POST http://localhost:8001/ \
  -H "X-API-Key: your-psk-secret" \
  -H "Content-Type: application/json" \
  -d '{
    "jsonrpc": "2.0",
    "id": 1,
    "method": "tools/call",
    "params": {
      "name": "health_check",
      "arguments": {}
    }
  }'
```

## Architecture

### System Architecture

```
┌─────────────────────────────────────────────────────────────────────┐
│                          AI Agent Client                             │
│                     (Claude Code, Cursor, etc.)                      │
└────────────────────────────┬────────────────────────────────────────┘
                             │
                             │ 1. Request with Okta JWT
                             │    Authorization: Bearer <okta_jwt>
                             │    X-MCP-Agent: claude-code
                             │
                             ▼
┌─────────────────────────────────────────────────────────────────────┐
│                    Okta MCP Adapter Gateway                          │
│                         Port 8000                                    │
│                                                                       │
│  Layer 2: Authentication  ──► Validate Okta JWT (JWKS)              │
│  Layer 3: Authorization   ──► Check backend_access list             │
│  Layer 4: Routing         ──► /hr → hr-system backend               │
│  Layer 5: Token Exchange  ──► N/A (PSK doesn't need exchange)       │
│  Layer 6: Cache           ──► N/A (PSK uses static key)             │
│  Layer 7: Proxy           ──► Add X-API-Key header                  │
│                                                                       │
└────────────────────────────┬────────────────────────────────────────┘
                             │
                             │ 2. Proxied request with PSK
                             │    X-API-Key: <HR_PSK_SECRET>
                             │    (Original body preserved)
                             │
                             ▼
┌─────────────────────────────────────────────────────────────────────┐
│                         HR MCP Server                                │
│                          Port 8001                                   │
│                                                                       │
│  ┌─────────────────────────────────────────────────────────┐        │
│  │ validate_api_key()                                      │        │
│  │   - Check X-API-Key header present                      │        │
│  │   - Verify matches PSK_SECRET env var                   │        │
│  │   - Return 401 if invalid                               │        │
│  └─────────────────────────────────────────────────────────┘        │
│                             │                                        │
│                             ▼                                        │
│  ┌─────────────────────────────────────────────────────────┐        │
│  │ MCP Tools (6 total)                                     │        │
│  │   - health_check()           - get_leave_balance()      │        │
│  │   - get_employee()           - submit_leave_request()   │        │
│  │   - search_employees()       - get_org_chart()          │        │
│  └─────────────────────────────────────────────────────────┘        │
│                             │                                        │
│                             ▼                                        │
│  ┌─────────────────────────────────────────────────────────┐        │
│  │ Mock Data Store                                         │        │
│  │   - 15 employees across 6 departments                   │        │
│  │   - Management hierarchy (CEO → VPs → Managers)         │        │
│  │   - Leave balances and request history                  │        │
│  └─────────────────────────────────────────────────────────┘        │
│                                                                       │
└───────────────────────────────────────────────────────────────────────┘
```

### Authentication Flow

```
┌──────────┐                    ┌─────────┐                    ┌──────────┐
│ AI Agent │                    │ Gateway │                    │ HR Server│
└────┬─────┘                    └────┬────┘                    └────┬─────┘
     │                               │                              │
     │ 1. POST /hr/get_employee      │                              │
     │    Authorization: Bearer JWT  │                              │
     │    X-MCP-Agent: claude-code   │                              │
     ├──────────────────────────────►│                              │
     │                               │                              │
     │                               │ 2. Validate JWT via Okta     │
     │                               │    JWKS endpoint             │
     │                               │                              │
     │                               │ 3. Check Authorization       │
     │                               │    - Agent exists?           │
     │                               │    - 'hr-system' in          │
     │                               │      backend_access?         │
     │                               │                              │
     │                               │ 4. Add X-API-Key header      │
     │                               │    X-API-Key: <PSK_SECRET>   │
     │                               │                              │
     │                               │ 5. POST to backend           │
     │                               ├─────────────────────────────►│
     │                               │                              │
     │                               │                              │ 6. Validate
     │                               │                              │    X-API-Key
     │                               │                              │    header
     │                               │                              │
     │                               │                              │ 7. Execute
     │                               │                              │    tool logic
     │                               │                              │
     │                               │ 8. Return employee data      │
     │                               │◄─────────────────────────────┤
     │                               │                              │
     │ 9. Proxy response to agent    │                              │
     │◄──────────────────────────────┤                              │
     │                               │                              │
```

### Docker Networking

```
┌─────────────────────────────────────────────────────────────────┐
│  Docker Network: mcp-examples-net                               │
│                                                                  │
│  ┌────────────────────┐              ┌────────────────────┐    │
│  │  gateway           │              │  hr-mcp-server     │    │
│  │  (okta-gateway)    │              │                    │    │
│  │                    │              │                    │    │
│  │  External: 8000    │──connects──►│  External: 8001    │    │
│  │  Internal: 8000    │   to via    │  Internal: 8001    │    │
│  │                    │   DNS name  │                    │    │
│  └────────────────────┘              └────────────────────┘    │
│                                                                  │
│  Gateway config uses: http://hr-mcp-server:8001                │
│  (Docker DNS resolves service name to container IP)            │
│                                                                  │
└─────────────────────────────────────────────────────────────────┘
```

## Available Tools

### 1. health_check()

Health monitoring endpoint for service status checks.

**Usage:**
```python
result = await client.call_tool("health_check")
```

**Returns:**
```json
"HR System MCP Server is healthy"
```

**Notes:**
- No authentication required
- Used by Docker healthcheck
- Fast response (<10ms)

---

### 2. get_employee(employee_id: str)

Retrieve detailed information for a specific employee.

**Parameters:**
- `employee_id` (str): Employee identifier (E001-E015)

**Usage:**
```python
result = await client.call_tool(
    "get_employee",
    employee_id="E001",
    headers={"X-API-Key": psk_secret}
)
```

**Returns:**
```json
{
  "id": "E001",
  "name": "Sarah Chen",
  "email": "sarah.chen@company.com",
  "department": "Engineering",
  "title": "Chief Technology Officer",
  "manager_id": null,
  "manager_name": null,
  "hire_date": "2018-03-15",
  "location": "San Francisco, CA",
  "employment_type": "Full-time"
}
```

**Errors:**
- `ValueError`: Employee not found
- `ValueError`: Invalid or missing API key

---

### 3. search_employees(query: str, department: str = None)

Search for employees by name or filter by department.

**Parameters:**
- `query` (str): Search term for name matching (case-insensitive)
- `department` (str, optional): Filter by department

**Departments:** Engineering, Product, Sales, HR, Finance, Marketing

**Usage:**
```python
# Search by name
results = await client.call_tool(
    "search_employees",
    query="Chen",
    headers={"X-API-Key": psk_secret}
)

# Filter by department
results = await client.call_tool(
    "search_employees",
    query="",
    department="Engineering",
    headers={"X-API-Key": psk_secret}
)

# Combined search
results = await client.call_tool(
    "search_employees",
    query="Johnson",
    department="Engineering",
    headers={"X-API-Key": psk_secret}
)
```

**Returns:**
```json
[
  {
    "id": "E001",
    "name": "Sarah Chen",
    "department": "Engineering",
    "title": "Chief Technology Officer",
    ...
  }
]
```

---

### 4. get_org_chart(employee_id: str = None)

Get organizational chart showing reporting structure.

**Parameters:**
- `employee_id` (str, optional): Root the chart at this employee. If None, returns full org chart.

**Usage:**
```python
# Full org chart
chart = await client.call_tool(
    "get_org_chart",
    headers={"X-API-Key": psk_secret}
)

# Specific employee's reports
chart = await client.call_tool(
    "get_org_chart",
    employee_id="E002",
    headers={"X-API-Key": psk_secret}
)
```

**Returns (full chart):**
```json
{
  "organization": "Company",
  "leadership_team": [
    {
      "id": "E001",
      "name": "Sarah Chen",
      "title": "Chief Technology Officer",
      "department": "Engineering",
      "direct_reports": [
        {
          "id": "E002",
          "name": "Marcus Johnson",
          "title": "Senior Software Engineer",
          "department": "Engineering",
          "direct_reports": [...]
        }
      ]
    }
  ]
}
```

**Returns (specific employee):**
```json
{
  "id": "E002",
  "name": "Marcus Johnson",
  "title": "Senior Software Engineer",
  "department": "Engineering",
  "direct_reports": [
    {
      "id": "E003",
      "name": "Priya Patel",
      "title": "Software Engineer",
      "department": "Engineering",
      "direct_reports": []
    }
  ]
}
```

---

### 5. get_leave_balance(employee_id: str)

Get employee's leave balance and recent leave requests.

**Parameters:**
- `employee_id` (str): Employee identifier

**Usage:**
```python
balance = await client.call_tool(
    "get_leave_balance",
    employee_id="E001",
    headers={"X-API-Key": psk_secret}
)
```

**Returns:**
```json
{
  "employee_id": "E001",
  "vacation_days": 15,
  "sick_days": 10,
  "personal_days": 5,
  "total_days": 30,
  "used_vacation": 8,
  "used_sick": 2,
  "used_personal": 1,
  "remaining_vacation": 7,
  "remaining_sick": 8,
  "remaining_personal": 4,
  "remaining_total": 19,
  "recent_requests": [
    {
      "id": "LR001",
      "type": "vacation",
      "start_date": "2024-12-20",
      "end_date": "2024-12-30",
      "days": 7,
      "status": "approved",
      "reason": "Holiday vacation"
    }
  ]
}
```

---

### 6. submit_leave_request(employee_id, leave_type, start_date, end_date, reason)

Submit a new leave request for an employee.

**Parameters:**
- `employee_id` (str): Employee identifier
- `leave_type` (str): Type of leave (vacation, sick, personal)
- `start_date` (str): Start date (YYYY-MM-DD format)
- `end_date` (str): End date (YYYY-MM-DD format)
- `reason` (str): Reason for leave

**Usage:**
```python
request = await client.call_tool(
    "submit_leave_request",
    employee_id="E003",
    leave_type="vacation",
    start_date="2025-06-01",
    end_date="2025-06-05",
    reason="Summer vacation",
    headers={"X-API-Key": psk_secret}
)
```

**Returns:**
```json
{
  "id": "LR003",
  "employee_id": "E003",
  "type": "vacation",
  "start_date": "2025-06-01",
  "end_date": "2025-06-05",
  "days": 5,
  "status": "pending",
  "reason": "Summer vacation",
  "submitted_at": "2025-03-02T10:15:30.123456"
}
```

**Errors:**
- `ValueError`: Invalid leave_type (must be vacation, sick, or personal)
- `ValueError`: Invalid date format (must be YYYY-MM-DD)
- `ValueError`: End date before start date
- `ValueError`: Employee not found

---

## Mock Data

The HR server includes 15 employees across 6 departments with a realistic organizational hierarchy:

### Organizational Structure

```
Company
├── Engineering (Sarah Chen - CTO)
│   └── Marcus Johnson - Senior SWE
│       ├── Priya Patel - Software Engineer
│       └── James Wilson - DevOps Engineer
├── Product (Emily Rodriguez - VP)
│   └── David Kim - Senior PM
│       └── Lisa Thompson - Product Manager
├── Sales (Ahmed Hassan - VP)
│   ├── Jennifer Lee - Senior AE
│   └── Michael Brown - Account Executive
├── HR (Anna Kowalski - Director)
│   └── Carlos Martinez - HR Business Partner
├── Finance (Rachel Green - CFO)
│   └── Tom Anderson - Senior Financial Analyst
└── Marketing (Maya Singh - VP)
```

### Employee IDs

- **E001-E004**: Engineering team
- **E005-E007**: Product team
- **E008-E010**: Sales team
- **E011-E012**: HR team
- **E013-E014**: Finance team
- **E015**: Marketing team

### Leave Data

All employees have leave balances configured with:
- Vacation days: 12-15 days
- Sick days: 10 days
- Personal days: 3-5 days
- Realistic usage patterns
- Sample leave requests (approved and pending)

## Configuration

### Environment Variables

Create a `.env` file (use `.env.example` as template):

```bash
# Okta Configuration
OKTA_DOMAIN=your-domain.okta.com

# HR Server Authentication
HR_PSK_SECRET=your-secure-random-key-here

# Logging
LOG_LEVEL=INFO
```

### Gateway Backend Configuration

Add to gateway's `config.yaml`:

```yaml
backends:
  hr-system:
    url: http://hr-mcp-server:8001
    paths:
      - /hr
    auth_method: pre-shared-key
    auth_config:
      api_key: "${HR_PSK_SECRET}"
    description: HR System MCP Server
    timeout_seconds: 30
    enabled: true
```

### Agent Authorization

Allow an agent to access the HR backend:

```yaml
agents:
  claude-code:
    backend_access:
      - hr-system
```

## Testing

### Run All Tests

```bash
# Install dependencies
pip install -r requirements.txt

# Set test environment variables
export PSK_SECRET="test-secret-key-12345"
export SERVER_URL="http://localhost:8001"

# Run tests
pytest tests/ -v

# Run with coverage
pytest tests/ --cov=. --cov-report=html

# Run specific test
pytest tests/test_hr_server.py::test_get_employee_success -v
```

### Test Coverage

The test suite includes 18+ test cases covering:

- ✅ Health check endpoint
- ✅ Valid and invalid authentication
- ✅ Employee retrieval (found and not found)
- ✅ Employee search (by name, department, combined)
- ✅ Org chart (full and specific employee)
- ✅ Leave balance retrieval
- ✅ Leave request submission (valid and invalid)
- ✅ Integration workflows

### Manual Testing

```bash
# Test health check
curl -X POST http://localhost:8001/ \
  -H "Content-Type: application/json" \
  -d '{
    "jsonrpc": "2.0",
    "id": 1,
    "method": "tools/call",
    "params": {"name": "health_check", "arguments": {}}
  }'

# Test get_employee with authentication
curl -X POST http://localhost:8001/ \
  -H "X-API-Key: your-psk-secret" \
  -H "Content-Type: application/json" \
  -d '{
    "jsonrpc": "2.0",
    "id": 1,
    "method": "tools/call",
    "params": {
      "name": "get_employee",
      "arguments": {"employee_id": "E001"}
    }
  }'
```

## Development

### Local Development (Without Docker)

```bash
# Install dependencies
pip install -r requirements.txt

# Set environment variables
export PSK_SECRET="dev-secret-key"
export LOG_LEVEL="DEBUG"

# Run server
python server.py
```

### Docker Development

```bash
# Build image
docker compose build

# Start services
docker compose up

# View logs
docker compose logs -f hr-mcp-server

# Restart after code changes
docker compose restart hr-mcp-server

# Rebuild after requirements change
docker compose build --no-cache hr-mcp-server
```

### Adding New Tools

1. **Add tool function to server.py:**

```python
@mcp.tool()
def my_new_tool(ctx: Context, param: str) -> dict:
    """Tool description."""
    validate_api_key(ctx)
    # Tool logic here
    return {"result": param}
```

2. **Add test to test_hr_server.py:**

```python
@pytest.mark.asyncio
async def test_my_new_tool(valid_headers):
    async with httpx.AsyncClient() as client:
        response = await client.post(...)
        assert response.status_code == 200
```

3. **Update documentation:**
   - Add to this README's "Available Tools" section
   - Add to `examples/CLAUDE.md` tool registry

4. **Run tests:**

```bash
pytest tests/ -v
```

## Troubleshooting

### Service Won't Start

**Check logs:**
```bash
docker compose logs hr-mcp-server
```

**Common issues:**
- Port 8001 already in use: `lsof -i :8001`
- PSK_SECRET not set in .env
- Invalid Docker network configuration

### Authentication Failures

**Symptom:** 401 Unauthorized or "Invalid API key" errors

**Solutions:**
- Verify PSK_SECRET matches in gateway and HR server
- Check X-API-Key header is present in requests
- Enable DEBUG logging: `LOG_LEVEL=DEBUG`

### Gateway Can't Reach HR Server

**Symptom:** Connection refused or timeout

**Solutions:**
- Verify both services are on `mcp-examples-net` network
- Check service name in gateway config: `http://hr-mcp-server:8001`
- Verify HR server is healthy: `docker compose ps`

### Tests Failing

**Check:**
1. Server is running: `curl http://localhost:8001/`
2. PSK_SECRET environment variable set for tests
3. Using pytest-asyncio: `pip install pytest-asyncio`

## Production Considerations

This example is designed for demonstration purposes. For production use:

1. **Security:**
   - Store PSK_SECRET in secure secret management (Vault, AWS Secrets Manager)
   - Implement rate limiting
   - Add input validation and sanitization
   - Use HTTPS/TLS for all communications

2. **Monitoring:**
   - Add structured logging
   - Implement metrics collection
   - Set up alerting for failures
   - Monitor authentication attempts

3. **Scalability:**
   - Replace in-memory data with database
   - Add caching layer (Redis)
   - Implement horizontal scaling
   - Add load balancing

4. **Reliability:**
   - Add circuit breakers
   - Implement retry logic
   - Set appropriate timeouts
   - Add graceful shutdown

## Resources

- [FastMCP Documentation](https://github.com/jlowin/fastmcp)
- [MCP Specification](https://spec.modelcontextprotocol.io/)
- [Okta MCP Adapter](../../README.md)
- [Docker Compose Documentation](https://docs.docker.com/compose/)
- [Examples Directory](../README.md)

## License

Same license as parent project.
