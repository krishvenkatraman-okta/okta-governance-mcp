#!/usr/bin/env python3
"""
HR MCP Server - Example Backend for Okta MCP Adapter

This server demonstrates Pre-Shared Key (PSK) authentication with realistic
HR data including employees, organizational hierarchy, and leave management.

Port: 8001 (configurable via HR_BACKEND_PORT)
Path: /hr
Auth: Pre-Shared Key via X-API-Key header
"""

import os
import logging
from datetime import datetime, timedelta
from typing import Optional, List, Dict, Any
from fastmcp import FastMCP, Context

# Configure logging
LOG_LEVEL = os.getenv("LOG_LEVEL", "INFO")
logging.basicConfig(
    level=LOG_LEVEL,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s"
)
logger = logging.getLogger(__name__)

# Pre-shared key for authentication
PSK_SECRET = os.getenv("PSK_SECRET")
if not PSK_SECRET:
    logger.warning("PSK_SECRET not set - authentication will fail!")


def _resolve_port() -> int:
    """Resolve the server port from environment variables.

    Priority: HR_BACKEND_PORT (new canonical) > SERVER_PORT (deprecated) > 8001 default.
    """
    new = os.getenv("HR_BACKEND_PORT")
    old = os.getenv("SERVER_PORT")
    if new is not None:
        port = int(new)
    elif old is not None:
        import warnings
        warnings.warn(
            "SERVER_PORT is deprecated for the HR backend; "
            "use HR_BACKEND_PORT. SERVER_PORT support will be "
            "removed in a future release.",
            DeprecationWarning,
            stacklevel=2,
        )
        port = int(old)
    else:
        return 8001
    if not (1 <= port <= 65535):
        raise ValueError(
            f"Port must be between 1 and 65535, got {port}"
        )
    return port


# Initialize FastMCP server
mcp = FastMCP("HR System")

# ============================================================================
# MOCK DATA - Realistic HR Dataset
# ============================================================================

MOCK_EMPLOYEES = {
    "E001": {
        "id": "E001",
        "name": "Sarah Chen",
        "email": "sarah.chen@company.com",
        "department": "Engineering",
        "title": "Chief Technology Officer",
        "manager_id": None,
        "hire_date": "2018-03-15",
        "location": "San Francisco, CA",
        "employment_type": "Full-time"
    },
    "E002": {
        "id": "E002",
        "name": "Marcus Johnson",
        "email": "marcus.johnson@company.com",
        "department": "Engineering",
        "title": "Senior Software Engineer",
        "manager_id": "E001",
        "hire_date": "2019-06-01",
        "location": "San Francisco, CA",
        "employment_type": "Full-time"
    },
    "E003": {
        "id": "E003",
        "name": "Priya Patel",
        "email": "priya.patel@company.com",
        "department": "Engineering",
        "title": "Software Engineer",
        "manager_id": "E002",
        "hire_date": "2021-09-15",
        "location": "Austin, TX",
        "employment_type": "Full-time"
    },
    "E004": {
        "id": "E004",
        "name": "James Wilson",
        "email": "james.wilson@company.com",
        "department": "Engineering",
        "title": "DevOps Engineer",
        "manager_id": "E002",
        "hire_date": "2020-11-20",
        "location": "Remote",
        "employment_type": "Full-time"
    },
    "E005": {
        "id": "E005",
        "name": "Emily Rodriguez",
        "email": "emily.rodriguez@company.com",
        "department": "Product",
        "title": "VP of Product",
        "manager_id": None,
        "hire_date": "2017-08-01",
        "location": "New York, NY",
        "employment_type": "Full-time"
    },
    "E006": {
        "id": "E006",
        "name": "David Kim",
        "email": "david.kim@company.com",
        "department": "Product",
        "title": "Senior Product Manager",
        "manager_id": "E005",
        "hire_date": "2020-02-14",
        "location": "New York, NY",
        "employment_type": "Full-time"
    },
    "E007": {
        "id": "E007",
        "name": "Lisa Thompson",
        "email": "lisa.thompson@company.com",
        "department": "Product",
        "title": "Product Manager",
        "manager_id": "E006",
        "hire_date": "2021-05-10",
        "location": "Seattle, WA",
        "employment_type": "Full-time"
    },
    "E008": {
        "id": "E008",
        "name": "Ahmed Hassan",
        "email": "ahmed.hassan@company.com",
        "department": "Sales",
        "title": "VP of Sales",
        "manager_id": None,
        "hire_date": "2019-01-07",
        "location": "Chicago, IL",
        "employment_type": "Full-time"
    },
    "E009": {
        "id": "E009",
        "name": "Jennifer Lee",
        "email": "jennifer.lee@company.com",
        "department": "Sales",
        "title": "Senior Account Executive",
        "manager_id": "E008",
        "hire_date": "2020-07-22",
        "location": "Boston, MA",
        "employment_type": "Full-time"
    },
    "E010": {
        "id": "E010",
        "name": "Michael Brown",
        "email": "michael.brown@company.com",
        "department": "Sales",
        "title": "Account Executive",
        "manager_id": "E008",
        "hire_date": "2022-01-15",
        "location": "Atlanta, GA",
        "employment_type": "Full-time"
    },
    "E011": {
        "id": "E011",
        "name": "Anna Kowalski",
        "email": "anna.kowalski@company.com",
        "department": "HR",
        "title": "Director of People Operations",
        "manager_id": None,
        "hire_date": "2018-10-01",
        "location": "San Francisco, CA",
        "employment_type": "Full-time"
    },
    "E012": {
        "id": "E012",
        "name": "Carlos Martinez",
        "email": "carlos.martinez@company.com",
        "department": "HR",
        "title": "HR Business Partner",
        "manager_id": "E011",
        "hire_date": "2021-03-18",
        "location": "Miami, FL",
        "employment_type": "Full-time"
    },
    "E013": {
        "id": "E013",
        "name": "Rachel Green",
        "email": "rachel.green@company.com",
        "department": "Finance",
        "title": "CFO",
        "manager_id": None,
        "hire_date": "2017-04-12",
        "location": "New York, NY",
        "employment_type": "Full-time"
    },
    "E014": {
        "id": "E014",
        "name": "Tom Anderson",
        "email": "tom.anderson@company.com",
        "department": "Finance",
        "title": "Senior Financial Analyst",
        "manager_id": "E013",
        "hire_date": "2020-09-01",
        "location": "New York, NY",
        "employment_type": "Full-time"
    },
    "E015": {
        "id": "E015",
        "name": "Maya Singh",
        "email": "maya.singh@company.com",
        "department": "Marketing",
        "title": "VP of Marketing",
        "manager_id": None,
        "hire_date": "2019-11-05",
        "location": "San Francisco, CA",
        "employment_type": "Full-time"
    }
}

MOCK_LEAVE_BALANCES = {
    "E001": {
        "employee_id": "E001",
        "vacation_days": 15,
        "sick_days": 10,
        "personal_days": 5,
        "total_days": 30,
        "used_vacation": 8,
        "used_sick": 2,
        "used_personal": 1,
        "recent_requests": [
            {
                "id": "LR001",
                "type": "vacation",
                "start_date": "2024-12-20",
                "end_date": "2024-12-30",
                "days": 7,
                "status": "approved",
                "reason": "Holiday vacation"
            }
        ]
    },
    "E002": {
        "employee_id": "E002",
        "vacation_days": 15,
        "sick_days": 10,
        "personal_days": 5,
        "total_days": 30,
        "used_vacation": 5,
        "used_sick": 1,
        "used_personal": 0,
        "recent_requests": [
            {
                "id": "LR002",
                "type": "sick",
                "start_date": "2025-01-15",
                "end_date": "2025-01-15",
                "days": 1,
                "status": "approved",
                "reason": "Medical appointment"
            }
        ]
    },
    "E003": {
        "employee_id": "E003",
        "vacation_days": 12,
        "sick_days": 10,
        "personal_days": 3,
        "total_days": 25,
        "used_vacation": 3,
        "used_sick": 0,
        "used_personal": 1,
        "recent_requests": []
    },
    "E006": {
        "employee_id": "E006",
        "vacation_days": 15,
        "sick_days": 10,
        "personal_days": 5,
        "total_days": 30,
        "used_vacation": 10,
        "used_sick": 3,
        "used_personal": 2,
        "recent_requests": [
            {
                "id": "LR006",
                "type": "vacation",
                "start_date": "2025-03-10",
                "end_date": "2025-03-14",
                "days": 5,
                "status": "pending",
                "reason": "Spring break with family"
            }
        ]
    }
}

# Initialize leave balances for all employees
for emp_id in MOCK_EMPLOYEES:
    if emp_id not in MOCK_LEAVE_BALANCES:
        MOCK_LEAVE_BALANCES[emp_id] = {
            "employee_id": emp_id,
            "vacation_days": 15,
            "sick_days": 10,
            "personal_days": 5,
            "total_days": 30,
            "used_vacation": 0,
            "used_sick": 0,
            "used_personal": 0,
            "recent_requests": []
        }

# ============================================================================
# AUTHENTICATION HELPER
# ============================================================================

def validate_api_key(ctx: Context) -> None:
    """Validate X-API-Key header matches PSK_SECRET.

    Args:
        ctx: FastMCP context containing request information

    Raises:
        ValueError: If API key is missing or invalid
    """
    # FastMCP 3.x: use get_http_request() or request_context.request
    from fastmcp.server.dependencies import get_http_request
    request = get_http_request()
    api_key = request.headers.get("x-api-key")

    if not api_key:
        logger.warning("Request missing X-API-Key header")
        raise ValueError("Missing X-API-Key header")

    if api_key != PSK_SECRET:
        logger.warning("Invalid API key provided")
        raise ValueError("Invalid API key")

    logger.debug("API key validated successfully")

# ============================================================================
# MCP TOOLS
# ============================================================================

@mcp.tool()
def health_check(ctx: Context) -> str:
    """Health check endpoint for monitoring and Docker healthchecks.

    Returns:
        Status message indicating service health
    """
    # Note: Health check doesn't require authentication
    return "HR System MCP Server is healthy"


@mcp.tool()
def get_employee(ctx: Context, employee_id: str) -> Dict[str, Any]:
    """Retrieve detailed information for a specific employee.

    Args:
        employee_id: Unique employee identifier (e.g., E001)

    Returns:
        Dictionary containing employee details including name, department,
        title, manager, hire date, location, and employment type

    Raises:
        ValueError: If authentication fails or employee not found
    """
    validate_api_key(ctx)

    logger.info(f"Fetching employee details for {employee_id}")

    if employee_id not in MOCK_EMPLOYEES:
        logger.warning(f"Employee {employee_id} not found")
        raise ValueError(f"Employee {employee_id} not found")

    employee = MOCK_EMPLOYEES[employee_id].copy()

    # Add manager name if applicable
    if employee["manager_id"]:
        manager = MOCK_EMPLOYEES.get(employee["manager_id"])
        if manager:
            employee["manager_name"] = manager["name"]

    logger.info(f"Successfully retrieved employee {employee_id}")
    return employee


@mcp.tool()
def search_employees(
    ctx: Context,
    query: str,
    department: Optional[str] = None
) -> List[Dict[str, Any]]:
    """Search for employees by name or filter by department.

    Args:
        query: Search term to match against employee names (case-insensitive)
        department: Optional department filter (Engineering, Product, Sales, HR, Finance, Marketing)

    Returns:
        List of employee dictionaries matching the search criteria

    Raises:
        ValueError: If authentication fails
    """
    validate_api_key(ctx)

    logger.info(f"Searching employees: query='{query}', department='{department}'")

    results = []
    query_lower = query.lower() if query else ""

    for employee in MOCK_EMPLOYEES.values():
        # Department filter
        if department and employee["department"] != department:
            continue

        # Name search
        if query and query_lower not in employee["name"].lower():
            continue

        results.append(employee.copy())

    logger.info(f"Found {len(results)} matching employees")
    return results


@mcp.tool()
def get_org_chart(ctx: Context, employee_id: Optional[str] = None) -> Dict[str, Any]:
    """Get organizational chart showing reporting structure.

    Args:
        employee_id: Optional employee ID to root the chart at. If None, returns full org chart

    Returns:
        Dictionary representing the organizational hierarchy with direct reports

    Raises:
        ValueError: If authentication fails or employee not found
    """
    validate_api_key(ctx)

    logger.info(f"Fetching org chart rooted at {employee_id or 'top-level'}")

    # If employee_id specified, verify it exists
    if employee_id and employee_id not in MOCK_EMPLOYEES:
        logger.warning(f"Employee {employee_id} not found")
        raise ValueError(f"Employee {employee_id} not found")

    def build_tree(manager_id: Optional[str]) -> List[Dict[str, Any]]:
        """Recursively build org chart tree."""
        direct_reports = []

        for emp_id, emp_data in MOCK_EMPLOYEES.items():
            if emp_data["manager_id"] == manager_id:
                node = {
                    "id": emp_id,
                    "name": emp_data["name"],
                    "title": emp_data["title"],
                    "department": emp_data["department"],
                    "direct_reports": build_tree(emp_id)
                }
                direct_reports.append(node)

        return direct_reports

    if employee_id:
        # Build tree for specific employee
        employee = MOCK_EMPLOYEES[employee_id]
        org_chart = {
            "id": employee_id,
            "name": employee["name"],
            "title": employee["title"],
            "department": employee["department"],
            "direct_reports": build_tree(employee_id)
        }
    else:
        # Build full org chart (top-level executives)
        org_chart = {
            "organization": "Company",
            "leadership_team": build_tree(None)
        }

    logger.info("Org chart retrieved successfully")
    return org_chart


@mcp.tool()
def get_leave_balance(ctx: Context, employee_id: str) -> Dict[str, Any]:
    """Get employee's leave balance and recent leave requests.

    Args:
        employee_id: Unique employee identifier (e.g., E001)

    Returns:
        Dictionary containing leave balances (vacation, sick, personal days),
        used days, remaining days, and recent leave requests

    Raises:
        ValueError: If authentication fails or employee not found
    """
    validate_api_key(ctx)

    logger.info(f"Fetching leave balance for {employee_id}")

    if employee_id not in MOCK_EMPLOYEES:
        logger.warning(f"Employee {employee_id} not found")
        raise ValueError(f"Employee {employee_id} not found")

    balance = MOCK_LEAVE_BALANCES[employee_id].copy()

    # Calculate remaining days
    balance["remaining_vacation"] = balance["vacation_days"] - balance["used_vacation"]
    balance["remaining_sick"] = balance["sick_days"] - balance["used_sick"]
    balance["remaining_personal"] = balance["personal_days"] - balance["used_personal"]
    balance["remaining_total"] = (
        balance["remaining_vacation"] +
        balance["remaining_sick"] +
        balance["remaining_personal"]
    )

    logger.info(f"Successfully retrieved leave balance for {employee_id}")
    return balance


@mcp.tool()
def submit_leave_request(
    ctx: Context,
    employee_id: str,
    leave_type: str,
    start_date: str,
    end_date: str,
    reason: str
) -> Dict[str, Any]:
    """Submit a new leave request for an employee.

    Args:
        employee_id: Unique employee identifier (e.g., E001)
        leave_type: Type of leave (vacation, sick, personal)
        start_date: Start date in YYYY-MM-DD format
        end_date: End date in YYYY-MM-DD format
        reason: Reason for leave request

    Returns:
        Dictionary containing the created leave request with status

    Raises:
        ValueError: If authentication fails, employee not found, or invalid parameters
    """
    validate_api_key(ctx)

    logger.info(f"Submitting leave request for {employee_id}")

    # Validate employee exists
    if employee_id not in MOCK_EMPLOYEES:
        logger.warning(f"Employee {employee_id} not found")
        raise ValueError(f"Employee {employee_id} not found")

    # Validate leave type
    valid_types = ["vacation", "sick", "personal"]
    if leave_type not in valid_types:
        raise ValueError(f"Invalid leave_type. Must be one of: {', '.join(valid_types)}")

    # Validate date format and calculate days
    try:
        start = datetime.strptime(start_date, "%Y-%m-%d")
        end = datetime.strptime(end_date, "%Y-%m-%d")
        days = (end - start).days + 1

        if days <= 0:
            raise ValueError("End date must be after start date")
    except ValueError as e:
        logger.warning(f"Invalid date format: {e}")
        raise ValueError(f"Invalid date format. Use YYYY-MM-DD: {e}")

    # Generate request ID
    request_id = f"LR{len(MOCK_LEAVE_BALANCES[employee_id]['recent_requests']) + 1:03d}"

    # Create leave request
    leave_request = {
        "id": request_id,
        "employee_id": employee_id,
        "type": leave_type,
        "start_date": start_date,
        "end_date": end_date,
        "days": days,
        "status": "pending",
        "reason": reason,
        "submitted_at": datetime.now().isoformat()
    }

    # Add to employee's requests (in-memory only for demo)
    MOCK_LEAVE_BALANCES[employee_id]["recent_requests"].append(leave_request)

    logger.info(f"Leave request {request_id} submitted successfully")
    return leave_request


# ============================================================================
# SERVER STARTUP
# ============================================================================

if __name__ == "__main__":
    # Server configuration
    host = os.getenv("SERVER_HOST", "0.0.0.0")
    port = _resolve_port()

    logger.info("=" * 70)
    logger.info("HR MCP Server Starting")
    logger.info("=" * 70)
    logger.info(f"Host: {host}")
    logger.info(f"Port: {port}")
    logger.info(f"PSK Authentication: {'Enabled' if PSK_SECRET else 'DISABLED (WARNING)'}")
    logger.info(f"Total Employees: {len(MOCK_EMPLOYEES)}")
    logger.info(f"Log Level: {LOG_LEVEL}")
    logger.info("=" * 70)

    # Start server with Streamable HTTP transport (REQUIRED)
    mcp.run(transport="streamable-http", host=host, port=port)
