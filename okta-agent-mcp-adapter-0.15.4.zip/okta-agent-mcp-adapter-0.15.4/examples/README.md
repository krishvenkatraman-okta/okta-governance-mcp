# MCP Backend Examples

This directory contains reference implementations of MCP servers that work with the Okta MCP Adapter gateway. Each example demonstrates a different authentication pattern and use case.

## Quick Start

1. Choose an example from the catalog below
2. Navigate to the example directory: `cd examples/01-hr-system`
3. Follow the example's README.md for setup instructions
4. Start the Docker stack: `docker compose up`

## Port Registry

All examples use consistent port allocation to avoid conflicts. The gateway always runs on port 8000.

| Port | Service | Example | Status |
|------|---------|---------|--------|
| 8000 | Gateway (always) | All examples | Reserved |
| 8001 | HR MCP Server | 01-hr-system | Active |
| 8002 | Finance MCP Server | 02-finance-system | Planned |
| 8003 | Analytics MCP Server | 03-analytics-system | Planned |
| 8004 | Ticketing MCP Server | 04-ticketing-system | Planned |
| 8005 | Deploy MCP Server | 05-deploy-server | Active |
| 8006-8099 | Future examples | - | Available |

## Example Catalog

### 01-hr-system (Active)
**Authentication:** Pre-Shared Key (PSK)
**Port:** 8001
**Tools:** 6 (health_check, get_employee, search_employees, get_org_chart, get_leave_balance, submit_leave_request)
**Description:** Human Resources system demonstrating static API key authentication. Includes realistic employee data with departments, management hierarchy, and leave management.

**Key Concepts:**
- Pre-shared key authentication pattern
- Streamable HTTP transport
- Health check implementation
- Mock data design for realistic demos
- Docker multi-service deployment

### 05-deploy-server (Active)
**Authentication:** OAuth2 Cross-App (ID-JAG) via `okta-ai-sdk` `verify_auth_server_token()`
**Port:** 8005
**Tools:** 6 (health_check, get_deployments, get_deploy_logs, rollback_deployment, get_env_config, get_service_health)
**Description:** DevOps deployment management system demonstrating the Cross-App Access (XAA) pattern with `auth_method: okta-cross-app`. The adapter looks up the user's stored id_token, performs an ID-JAG exchange to get AT-2, and this backend validates AT-2 using `okta-ai-sdk` `verify_auth_server_token()` — no private key needed. Includes realistic deployment history, CI/CD logs, service health, and environment configuration with redacted secrets.

**Key Concepts:**
- ID-JAG XAA: stored id_token -> ID-JAG JWT -> AT-2 exchange
- Backend only verifies tokens (`privateJWK=None`) — no signing, no key management
- Per-user identity propagation via `sub` claim
- Backend-enforced access control (redacted secrets post-XAA)
- Deterministic data generation with cross-referenced deployments/logs/health
- Full E2E test scripts for validating the XAA flow

### 02-finance-system (Planned)
**Authentication:** OAuth2 Cross-App (ID-JAG)
**Port:** 8002
**Description:** Finance system demonstrating Okta-to-Okta token exchange pattern.

### 03-analytics-system (Planned)
**Authentication:** Service Account
**Port:** 8003
**Description:** Analytics system demonstrating HTTP Basic Auth with service accounts.

### 04-ticketing-system (Planned)
**Authentication:** Pre-Shared Key (PSK)
**Port:** 8004
**Description:** Ticketing system demonstrating issue tracking and workflow automation.

## Architecture Overview

```
┌─────────────────────────────────────────────────────────────────┐
│                          AI Agent                                │
│                    (Claude Code, Cursor)                         │
└────────────────────────────┬────────────────────────────────────┘
                             │ Bearer token (Okta JWT)
                             │ X-MCP-Agent: agent-name
                             ▼
┌─────────────────────────────────────────────────────────────────┐
│                    Okta MCP Adapter Gateway                      │
│                         (Port 8000)                              │
│                                                                   │
│  ┌────────────┐  ┌──────────────┐  ┌─────────────┐             │
│  │  Layer 2   │→ │   Layer 3    │→ │   Layer 4   │             │
│  │   Auth     │  │    Authz     │  │   Routing   │             │
│  │  (Okta)    │  │  (Backend    │  │  (Path →    │             │
│  │            │  │   Access)    │  │  Backend)   │             │
│  └────────────┘  └──────────────┘  └─────────────┘             │
│                                                                   │
│  ┌────────────┐  ┌──────────────┐  ┌─────────────┐             │
│  │  Layer 5   │→ │   Layer 6    │→ │   Layer 7   │             │
│  │   Token    │  │    Cache     │  │    Proxy    │             │
│  │  Exchange  │  │   (TTL)      │  │  (Forward)  │             │
│  └────────────┘  └──────────────┘  └─────────────┘             │
└────────────────────────────┬────────────────────────────────────┘
                             │ X-API-Key: <psk> (PSK auth)
                             │ Authorization: Bearer <token> (OAuth)
                             │ Authorization: Basic <creds> (Service)
                             ▼
┌─────────────────────────────────────────────────────────────────┐
│                      Backend MCP Servers                         │
│                                                                   │
│  ┌─────────────┐  ┌─────────────┐  ┌─────────────┐             │
│  │  HR System  │  │  Deploy     │  │  Finance    │             │
│  │  (8001)     │  │  (8005)     │  │  (8002)     │             │
│  │  PSK Auth   │  │  XAA/SDK    │  │  ID-JAG     │             │
│  └─────────────┘  └─────────────┘  └─────────────┘             │
└─────────────────────────────────────────────────────────────────┘
```

## Authentication Patterns

### Pre-Shared Key (PSK)
Used by: 01-hr-system, 04-ticketing-system

**Flow:**
1. AI agent sends Okta JWT to gateway
2. Gateway validates JWT and checks authorization
3. Gateway adds `X-API-Key: <secret>` header
4. Backend validates the static key

**Pros:** Simple, no additional auth server needed
**Cons:** Key rotation requires coordination, no per-user tokens

### OAuth2 Cross-App (ID-JAG)
Used by: 05-deploy-server, 02-finance-system (planned)

**Flow:**
1. AI agent sends Okta JWT to gateway
2. Gateway validates JWT and checks authorization
3. Gateway issues ID-JAG JWT signed with agent's private key
4. Gateway exchanges ID-JAG for backend access token
5. Backend validates access token against its auth server

**Pros:** Full OAuth2 flow, per-user tokens, automatic expiration
**Cons:** More complex setup, requires OAuth server on backend

### Service Account
Used by: 03-analytics-system

**Flow:**
1. AI agent sends Okta JWT to gateway
2. Gateway validates JWT and checks authorization
3. Gateway adds HTTP Basic Auth header with service credentials
4. Backend validates credentials

**Pros:** Standard pattern, widely supported
**Cons:** Credentials in gateway config, no per-user attribution

## How to Add a New Example

Follow these steps to create a new backend example:

### 1. Reserve a Port

Edit this README.md and add your example to the Port Registry table:

```markdown
| 8005 | My Service | 05-my-service | Active |
```

### 2. Create Directory Structure

```bash
mkdir -p examples/05-my-service/{config,tests}
cd examples/05-my-service
```

### 3. Create Required Files

Your example MUST include:

- `README.md` - Setup instructions, architecture diagram, usage examples
- `server.py` - FastMCP server implementation
- `requirements.txt` - Python dependencies (pinned versions)
- `Dockerfile` - Container build configuration
- `docker-compose.yml` - Multi-service orchestration
- `.env.example` - Environment variable template
- `config/gateway-backend.yml` - Backend configuration snippet
- `tests/test_<service>_server.py` - Pytest test suite

### 4. Follow Naming Conventions

- Example directory: `##-service-name` (e.g., `01-hr-system`)
- Service name in Docker: `<service>-mcp-server` (e.g., `hr-mcp-server`)
- Backend name in config: `<service>-system` (e.g., `hr-system`)
- Test file: `test_<service>_server.py` (e.g., `test_hr_server.py`)

### 5. Implement FastMCP Server

```python
from fastmcp import FastMCP

# Initialize MCP server
mcp = FastMCP("My Service")

@mcp.tool()
def my_tool(param: str) -> str:
    """Tool description."""
    # Validate authentication header
    # Implement tool logic
    return result

if __name__ == "__main__":
    # MUST use streamable-http transport
    mcp.run(transport="streamable-http", host="0.0.0.0", port=8005)
```

### 6. Configure Docker Networking

All services MUST use the `mcp-examples-net` network:

```yaml
networks:
  mcp-net:
    name: mcp-examples-net
    driver: bridge
```

### 7. Update Gateway Configuration

Create `config/gateway-backend.yml` with your backend configuration:

```yaml
backends:
  my-system:
    url: http://my-mcp-server:8005
    paths:
      - /my-service
    auth_method: pre-shared-key  # or okta-cross-app, service-account
    auth_config:
      api_key: "${MY_PSK_SECRET}"
    description: My Service MCP Server
    timeout_seconds: 30
    enabled: true
```

### 8. Write Tests

Use pytest with async support:

```python
import pytest
from fastmcp import Client

@pytest.mark.asyncio
async def test_my_tool():
    async with Client("http://localhost:8005") as client:
        result = await client.call_tool("my_tool", param="test")
        assert result["content"][0]["text"] == "expected"
```

### 9. Document in CLAUDE.md

Add your tools to `examples/CLAUDE.md`:

```markdown
### 05-my-service
- `my_tool(param: str) -> str` - Tool description
```

### 10. Update Example Catalog

Add your example to the "Example Catalog" section of this README.

## Testing All Examples

Run tests for all examples:

```bash
# Test specific example
cd examples/01-hr-system
pytest tests/ -v

# Test all examples (from repo root)
pytest examples/*/tests/ -v

# Run with coverage
pytest examples/*/tests/ --cov=examples --cov-report=html
```

## Docker Management

### Start All Examples

```bash
# From repo root
docker compose -f examples/01-hr-system/docker-compose.yml up -d
docker compose -f examples/02-finance-system/docker-compose.yml up -d
```

### Stop All Examples

```bash
docker compose -f examples/*/docker-compose.yml down
```

### View Logs

```bash
# Specific example
docker compose -f examples/01-hr-system/docker-compose.yml logs -f

# All services
docker compose -f examples/01-hr-system/docker-compose.yml logs -f --tail=100
```

### Network Management

All examples share the `mcp-examples-net` network. Create it once:

```bash
docker network create mcp-examples-net
```

This allows the gateway to reach all backend servers by service name.

## Best Practices

### Security
- Never commit real secrets (use `.env` files with `.gitignore`)
- Use environment variables for all credentials
- Rotate PSK secrets regularly in production
- Implement proper input validation in all tools

### Docker
- Use multi-stage builds to minimize image size
- Run as non-root user in containers
- Pin Python and dependency versions
- Implement health checks for all services

### Testing
- Test all tools with valid and invalid inputs
- Test authentication failures
- Test error handling and edge cases
- Use mock data that demonstrates value

### Documentation
- Include architecture diagrams in README files
- Provide clear setup instructions
- Document environment variables
- Include usage examples with expected outputs

## Troubleshooting

### Gateway Can't Reach Backend

**Symptom:** Connection refused or timeout errors

**Solution:**
1. Verify both services are on `mcp-examples-net` network
2. Check service name matches in gateway config and docker-compose
3. Ensure backend is healthy: `docker compose ps`
4. Check backend logs: `docker compose logs hr-mcp-server`

### Authentication Failures

**Symptom:** 401 Unauthorized responses

**Solution:**
1. Verify PSK_SECRET matches in gateway and backend `.env` files
2. Check X-API-Key header is being added by gateway
3. Enable debug logging: `LOG_LEVEL=DEBUG`
4. Verify backend is validating the correct header

### Port Conflicts

**Symptom:** Address already in use

**Solution:**
1. Check Port Registry in this README for allocations
2. Stop conflicting service: `lsof -i :<port>` then `kill <pid>`
3. Choose unused port from 8005-8099 range
4. Update Port Registry table

### Import Errors

**Symptom:** ModuleNotFoundError

**Solution:**
1. Verify requirements.txt includes all dependencies
2. Rebuild Docker image: `docker compose build --no-cache`
3. Check Python version matches (3.12+ recommended)

## Resources

- [FastMCP Documentation](https://github.com/jlowin/fastmcp)
- [MCP Specification](https://spec.modelcontextprotocol.io/)
- [Okta MCP Adapter Documentation](../README.md)
- [Docker Compose Documentation](https://docs.docker.com/compose/)
- [Pytest-asyncio Documentation](https://pytest-asyncio.readthedocs.io/)

## Contributing

When contributing new examples:

1. Follow the "How to Add a New Example" guide above
2. Ensure all validation checklist items pass
3. Write comprehensive tests (aim for 90%+ coverage)
4. Document authentication flow in README
5. Include realistic demo data
6. Test with actual AI agents (Claude Code, Cursor)

## License

Same license as parent project (see root LICENSE file).
