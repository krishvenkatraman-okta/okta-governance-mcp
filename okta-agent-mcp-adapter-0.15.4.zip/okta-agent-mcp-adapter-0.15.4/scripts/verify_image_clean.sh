#!/usr/bin/env bash
# ============================================================================
# verify_image_clean.sh — Prove the adapter image is free of SQLA/greenlet.
#
# v0.15.0 removed SQLAlchemy, Alembic, psycopg2, and greenlet to eliminate
# the CWE-121 stack-overflow finding in greenlet/TStackState.cpp. This
# script asserts the invariant still holds on the current build by running
# import probes + a pipdeptree graph audit inside the image.
#
# Usage:
#   ./scripts/verify_image_clean.sh                              # defaults
#   ./scripts/verify_image_clean.sh my-registry/adapter:1.2.3    # explicit tag
#   OKTA_ADAPTER_IMAGE=foo:bar ./scripts/verify_image_clean.sh   # via env
#
# Exit 0 on all-pass, 1 on any failure. Safe to wire into CI after the
# docker build step.
# ============================================================================
set -u

IMAGE="${1:-${OKTA_ADAPTER_IMAGE:-okta-agent-mcp-adapter:latest}}"

RED=$'\033[0;31m'
GREEN=$'\033[0;32m'
BOLD=$'\033[1m'
NC=$'\033[0m'

pass() { echo "${GREEN}[PASS]${NC} $*"; }
fail() { echo "${RED}[FAIL]${NC} $*"; FAIL_COUNT=$((FAIL_COUNT + 1)); }

FAIL_COUNT=0

if ! command -v docker >/dev/null 2>&1; then
    echo "${RED}docker CLI not found. Install Docker or run on a host with it.${NC}" >&2
    exit 2
fi

if ! docker image inspect "$IMAGE" >/dev/null 2>&1; then
    echo "${RED}Image '$IMAGE' not found on this host.${NC}" >&2
    echo "Build it first:  docker compose build okta-agent-mcp-adapter" >&2
    exit 2
fi

echo "${BOLD}Verifying image:${NC} $IMAGE"
echo ""

# ----------------------------------------------------------------------------
# 1. Import probes — these modules MUST NOT be importable.
# ----------------------------------------------------------------------------
echo "${BOLD}Removed-dependency import probes${NC}"
for mod in greenlet sqlalchemy alembic psycopg2; do
    if docker run --rm --entrypoint python "$IMAGE" -c "import $mod" >/dev/null 2>&1; then
        fail "$mod is importable (CWE-121 finding may have returned)"
    else
        pass "$mod not importable"
    fi
done

# ----------------------------------------------------------------------------
# 2. Positive assertion — the replacement driver MUST be importable.
# ----------------------------------------------------------------------------
echo ""
echo "${BOLD}Replacement-driver import probe${NC}"
if version=$(docker run --rm --entrypoint python "$IMAGE" -c "import psycopg; print(psycopg.__version__)" 2>&1); then
    pass "psycopg (psycopg3) importable — version $version"
else
    fail "psycopg (psycopg3) not importable — output: $version"
fi

# ----------------------------------------------------------------------------
# 3. Dependency-graph audit via pipdeptree.
#    Catches transitive pulls a source grep would miss. Runs as root
#    (--user 0) because the image's appuser has no writable site-packages;
#    this only affects the ephemeral container, not the shipped image.
# ----------------------------------------------------------------------------
echo ""
echo "${BOLD}pipdeptree graph audit${NC}"
graph_output=$(docker run --rm --user 0 --entrypoint sh "$IMAGE" -c \
    'pip install --quiet --no-warn-script-location pipdeptree && pipdeptree --warn silence' \
    2>&1) || graph_output=""

if [ -z "$graph_output" ]; then
    fail "pipdeptree produced no output — unable to audit dependency graph"
elif echo "$graph_output" | grep -qi 'error\|permission denied'; then
    echo "${RED}pipdeptree bootstrap output:${NC}"
    echo "$graph_output" | sed 's/^/    /'
    fail "pipdeptree bootstrap failed"
elif echo "$graph_output" | grep -iE 'greenlet|sqlalchemy|alembic|psycopg2' >/dev/null; then
    echo "${RED}Offending lines in pipdeptree output:${NC}"
    echo "$graph_output" | grep -iE 'greenlet|sqlalchemy|alembic|psycopg2' | sed 's/^/    /'
    fail "pipdeptree shows a removed package in the dependency graph"
else
    pass "pipdeptree shows no greenlet/sqlalchemy/alembic/psycopg2 in the graph"
fi

# ----------------------------------------------------------------------------
# Summary
# ----------------------------------------------------------------------------
echo ""
if [ "$FAIL_COUNT" -eq 0 ]; then
    echo "${GREEN}${BOLD}All checks passed.${NC} Image '$IMAGE' is free of SQLA/greenlet."
    exit 0
else
    echo "${RED}${BOLD}$FAIL_COUNT check(s) failed.${NC} Image '$IMAGE' must not ship."
    exit 1
fi
