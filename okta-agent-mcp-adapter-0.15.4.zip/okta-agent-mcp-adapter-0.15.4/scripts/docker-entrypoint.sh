#!/usr/bin/env bash
# Docker entrypoint for the Okta MCP Adapter gateway.
# 1. If the container was started with a command override (e.g., the
#    dedicated migrate ECS task), exec it directly and skip the gateway
#    boilerplate.
# 2. Otherwise: run DB migrations (static-password mode only) and exec uvicorn.

set -e

# Command override path: used by the one-shot migrate task which runs
# `/bin/sh -c "psql ... && python -m okta_agent_proxy.storage.migrate ..."`.
# Without this, ECS passes the override as $@ but the script ignored it and
# booted uvicorn, which then fails because migrate-task env lacks OKTA_DOMAIN.
if [ "$#" -gt 0 ]; then
    exec "$@"
fi

# Check Redis availability (informational only — not required).
# The preflight PING cannot authenticate with IAM- or Entra-minted tokens
# because it does not run the credential provider. Skip the raw-URL PING
# when REDIS_AUTH_MODE is not "static" — the application's runtime
# credential provider will authenticate correctly a moment later.
redis_auth_mode="$(printf '%s' "${REDIS_AUTH_MODE:-static}" | sed -e 's/^[[:space:]]*//' -e 's/[[:space:]]*$//' | tr '[:upper:]' '[:lower:]')"
if [ "${CACHE_PROVIDER:-memory}" = "redis" ] || [ -n "${REDIS_URL:-}" ]; then
    if [ "$redis_auth_mode" != "static" ]; then
        echo "→ REDIS_AUTH_MODE=${redis_auth_mode} — skipping startup PING (runtime credential provider will authenticate)."
    else
        echo "→ Checking Redis availability..."
        if python -c "
import redis, os, sys
url = os.getenv('REDIS_URL', 'redis://localhost:6379')
try:
    r = redis.from_url(url, socket_connect_timeout=3)
    r.ping()
    print('✓ Redis is available — using Redis cache backend.')
except Exception as e:
    print(f'⚠ Redis is not available ({e}) — falling back to in-memory cache.')
    sys.exit(1)
" 2>/dev/null; then
            :
        else
            echo "⚠ Gateway will start with in-memory caching."
        fi
    fi
else
    echo "→ CACHE_PROVIDER=memory — using in-memory cache (no Redis)."
fi

# In non-static credential modes (rds_iam, azure_entra, vault) the adapter
# runs as the app DML-only role and has no DATABASE_URL. Migrations must be
# run out-of-band by the dedicated migrate task (P13) using the owner role
# before this container starts. Skip the in-process migration step in those
# modes to avoid a guaranteed failure.
provider="${DB_CREDENTIAL_PROVIDER:-static}"
case "$provider" in
    static|"")
        echo "→ Running database migrations (psycopg3 runner)..."
        if python -m okta_agent_proxy.storage.migrate upgrade \
            --migrations-dir deploy/migrations/sql; then
            echo "✓ Migrations applied successfully."
        else
            echo "✗ Database migration failed — cannot start gateway."
            exit 1
        fi
        ;;
    *)
        echo "→ DB_CREDENTIAL_PROVIDER=${provider} — migrations handled by the migrate task; skipping."
        ;;
esac

echo "→ Starting uvicorn on port ${GATEWAY_PORT:-8000}..."
exec python -m uvicorn okta_agent_proxy.app:app \
    --host 0.0.0.0 \
    --port "${GATEWAY_PORT:-8000}" \
    --proxy-headers \
    --forwarded-allow-ips "*"
