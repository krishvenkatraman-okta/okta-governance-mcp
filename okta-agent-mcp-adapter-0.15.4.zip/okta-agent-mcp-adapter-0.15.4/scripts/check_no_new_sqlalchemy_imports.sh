#!/usr/bin/env bash
# Post-P07: SQLAlchemy is gone from the runtime and the test suite. The
# test files that still reference the old ORM models skip at import time;
# grep below ignores them. Any other `sqlalchemy` import fails CI.
#
# The four skipped modules still carry dead `from sqlalchemy ...` lines so
# their reason-for-skip message names the packages that used to back them.
# They never execute — the module-level ``pytest.skip(..., allow_module_level=True)``
# runs first. They remain on the allowlist below until the modules are
# deleted or rewritten against the psycopg3 fixtures.
set -e
ALLOWED_RE='^(tests/test_resource_map_models\.py|tests/test_okta_syncer\.py|tests/test_linkage_model\.py|tests/test_app_lifecycle\.py|tests/test_dcr_agent_selection_schema\.py)$'
VIOLATIONS=$(grep -rln "from sqlalchemy\|import sqlalchemy" okta_agent_proxy/ tests/ --include="*.py" \
  | grep -v -E "$ALLOWED_RE" || true)
if [ -n "$VIOLATIONS" ]; then
  echo "ERROR: SQLAlchemy imports detected in files outside the post-P07 skip list:"
  echo "$VIOLATIONS"
  exit 1
fi
echo "OK: no SQLAlchemy imports in live code."
