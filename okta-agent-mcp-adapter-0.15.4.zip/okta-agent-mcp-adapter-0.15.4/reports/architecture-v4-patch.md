# Architecture v4 Patch — Caching Completeness (P2-P7)

**Date:** 2026-04-13
**Target:** `okta_mcp_adapter_architecture_v4.docx` Section 11 (Caching Architecture)
**Status:** Hand-merge required — this file describes the deltas; do NOT auto-apply.

---

## 1. New Caches to Add to the Cache Architecture Diagram

The following components were migrated from pure in-process caches to CacheService-backed (L1 local + L2 Redis) in P2-P3.5:

| Component | File | L2 Key Pattern | Value Type | Encryption | TTL |
|-----------|------|----------------|------------|------------|-----|
| **UserTokenStore** | `auth/user_token_store.py` | `user_token:{sha256(access_token)}` | Encrypted JSON: id_token, refresh_token, user_sub, agent_id | Yes (AES-256-GCM) | 86400s (24h) |
| **GatewayCodeManager (codes)** | `auth/gateway_code_manager.py` | `gateway_code:{64-char-hex}` | Encrypted JSON: PendingCodeSession (tokens, client_id, extra) | Yes | 300s (5m) |
| **GatewayCodeManager (tokens)** | `auth/gateway_code_manager.py` | `gateway_token:{access_token}` | Encrypted JSON: client_id, id_token, relay credentials | Yes | 3600s (1h) |
| **ConfidentialRelay state** | `auth/confidential_relay.py` | `relay_state:{state}` | Encrypted JSON: RelaySession (credentials, tokens, PKCE) | Yes | 600s (10m) |
| **ConfidentialRelay pre-consent** | `auth/confidential_relay.py` | `relay_preconsent:{state}` | Encrypted JSON: PreConsentSession | Yes | 600s (10m) |
| **ConsentTransactionStore (by ID)** | `auth/consent_transaction.py` | `consent_tx:{uuid4}` | Encrypted JSON: ConsentTransaction (tokens, connections) | Yes | 600s (10m) |
| **ConsentTransactionStore (session index)** | `auth/consent_transaction.py` | `consent_session:{session_id}` | Plain text: transaction_id pointer | No | 600s (10m) |

These should be added to the cache architecture diagram alongside the existing entries (TokenCache, MCPSessionManager, JWKS, ConfigCache, tool catalog, CIMD metadata).

## 2. New Pub/Sub Channels

Add these four channels to the pub/sub channel diagram in Section 11:

| Channel | Trigger | Effect on Receiving Pod |
|---------|---------|------------------------|
| `user_token_invalidate` | `UserTokenStore.aremove()` / `aremove_by_user()` | Drops matching entry from L1 TTLCache |
| `relay_session_invalidate` | Relay state or pre-consent state deleted after callback | Drops matching entry from L1 session dicts |
| `consent_tx_invalidate` | `ConsentTransactionStore.aremove()` | Drops transaction from L1 by-id and by-session dicts |
| `user_logout` | *(No endpoint yet — TODO)* | Cascades: clears UserTokenStore + TokenCache entries for the user |

All user-scoped channels use a standard JSON envelope: `{"v": 1, "key": "<identifier>", "user_sub": "<optional>"}`.

Existing channels unchanged: `route_invalidate`, `agent_invalidate`, `tool_catalog_invalidate`, `dcr_patterns_invalidate`.

## 3. Update "Stateless HTTP for FastMCP" Row

The adapter uses a Starlette ASGI application (`app.py`) for HTTP transport, not FastMCP's built-in HTTP server. All per-flow state that previously required session stickiness now lives in Redis when `CACHE_PROVIDER=redis` is set:

- OAuth relay sessions (CIMD authorize → callback)
- Gateway authorization codes (single-use, cross-pod atomicity enforced via L2 exists check)
- STS consent transactions (multi-step consent interstitial)
- User token mappings (access_token → id_token for XAA)

**Implication:** Session stickiness is no longer required. The adapter can run behind a round-robin load balancer with 2+ replicas.

## 4. Cross-Pod Single-Use Enforcement (Bug Fix)

`GatewayCodeManager.aexchange_code()` now includes a cross-pod single-use guard: when an L1 hit occurs, it checks whether the L2 entry still exists before accepting. If another pod already consumed the code via L2 (deleting it), the L1 entry is treated as stale and `GatewayCodeNotFound` is raised. This prevents double-exchange across pods.

## 5. Known Limitations

- `UserTokenStore.aremove_by_user()` uses `clear_prefix("user_token:")` in L2, which removes ALL user_token entries (not just one user's). This is acceptable because pods re-populate from Okta on the next request. A per-user secondary index is deferred.
- No `/logout` endpoint exists yet. The `user_logout` pub/sub channel is wired but has no publisher. A TODO is placed in `app.py`.
