# Docker Cheat Sheet - Admin UI

Quick reference for common Docker operations with the admin UI.

## Development

### Local Development (Recommended)
```bash
cd okta_agent_proxy_admin_ui
npm install
npm run dev
```
Access at: http://localhost:3001

## Docker Compose (Full Stack)

### Start Everything
```bash
# From repository root
./setup.sh
```

### Start Only Admin UI
```bash
docker compose up -d admin-ui
```

### View Logs
```bash
# Follow logs
docker compose logs -f admin-ui

# Last 50 lines
docker compose logs --tail=50 admin-ui

# All logs
docker compose logs admin-ui
```

### Restart Admin UI
```bash
docker compose restart admin-ui
```

### Stop Admin UI
```bash
docker compose stop admin-ui
```

### Rebuild After Code Changes
```bash
docker compose build admin-ui
docker compose up -d admin-ui
```

### Check Status
```bash
docker compose ps admin-ui
```

### Remove Container
```bash
docker compose down admin-ui
```

## Standalone Docker (Without Compose)

### Build Image
```bash
cd okta_agent_proxy_admin_ui
docker build -t okta-mcp-admin-ui:latest .
```

### Run Container
```bash
docker run -d \
  --name okta-mcp-admin-ui \
  -p 3001:3001 \
  -e NEXT_PUBLIC_API_URL=http://localhost:8000 \
  okta-mcp-admin-ui:latest
```

### View Logs
```bash
docker logs -f okta-mcp-admin-ui
```

### Stop Container
```bash
docker stop okta-mcp-admin-ui
```

### Remove Container
```bash
docker rm okta-mcp-admin-ui
```

### Access Shell
```bash
docker exec -it okta-mcp-admin-ui sh
```

## Troubleshooting

### Check if Container is Running
```bash
docker ps | grep admin-ui
```

### Check Health Status
```bash
docker inspect okta-mcp-admin-ui | grep -A 10 Health
```

### Test from Inside Container
```bash
docker exec okta-mcp-admin-ui wget -O- http://localhost:3001/
```

### Test API Connection
```bash
docker exec okta-mcp-admin-ui wget -O- http://okta-agent-mcp-adapter:8000/.well-known/oauth-protected-resource
```

### View Environment Variables
```bash
docker exec okta-mcp-admin-ui env | grep NEXT_PUBLIC
```

### Check Resource Usage
```bash
docker stats okta-mcp-admin-ui
```

## Cleanup

### Remove All Stopped Containers
```bash
docker container prune
```

### Remove Unused Images
```bash
docker image prune -a
```

### Full Cleanup (All Services)
```bash
# From repository root
docker compose down -v
```

## Production

### Build for Production
```bash
docker build -t okta-mcp-admin-ui:v1.0.0 .
```

### Run with Custom Environment
```bash
docker run -d \
  --name okta-mcp-admin-ui \
  -p 3001:3001 \
  -e NEXT_PUBLIC_API_URL=https://gateway.example.com \
  -e NODE_ENV=production \
  --restart unless-stopped \
  okta-mcp-admin-ui:v1.0.0
```

### Save Image
```bash
docker save okta-mcp-admin-ui:latest | gzip > admin-ui.tar.gz
```

### Load Image
```bash
docker load < admin-ui.tar.gz
```

### Tag for Registry
```bash
docker tag okta-mcp-admin-ui:latest your-registry.com/okta-mcp-admin-ui:latest
docker push your-registry.com/okta-mcp-admin-ui:latest
```

## Debugging

### Interactive Shell
```bash
# Alpine-based image uses sh, not bash
docker exec -it okta-mcp-admin-ui sh
```

### Check Port Bindings
```bash
docker port okta-mcp-admin-ui
```

### Inspect Container
```bash
docker inspect okta-mcp-admin-ui
```

### View Build History
```bash
docker history okta-mcp-admin-ui:latest
```

### Check Disk Usage
```bash
docker system df
```

## Environment Variables

### Required
- `NEXT_PUBLIC_API_URL` - Gateway API URL
  - Development: `http://localhost:8000`
  - Docker Compose: `http://okta-agent-mcp-adapter:8000`
  - Production: `https://gateway.example.com`

### Optional
- `NEXT_PUBLIC_APP_NAME` - App name (default: "Okta MCP Adapter Admin")
- `NODE_ENV` - Environment (default: "production")
- `PORT` - Port to listen on (default: "3001")
- `HOSTNAME` - Bind address (default: "0.0.0.0")

## Quick Tests

### Test Login Page
```bash
curl http://localhost:3001/login
```

### Test Health
```bash
curl -f http://localhost:3001/ && echo "OK" || echo "FAIL"
```

### Test API Connectivity
```bash
curl http://localhost:8000/.well-known/oauth-protected-resource
```

### Test Admin Auth
```bash
# Admin API accepts only Okta OAuth access tokens (v0.15.x+).
# Without a bearer → 401:
curl -s -o /dev/null -w '%{http_code}\n' http://localhost:8000/api/admin/agents

# With a valid Okta token → 200:
curl -H "Authorization: Bearer $OKTA_ADMIN_TOKEN" http://localhost:8000/api/admin/agents
```

## Common Issues

### Port Already in Use
```bash
# Find process using port 3001
lsof -i :3001

# Or use different port
docker run -p 3002:3001 ...
```

### Cannot Connect to Gateway
```bash
# Check gateway is running
docker ps | grep okta-agent-mcp-adapter

# Check network connectivity
docker network inspect mcp-network
```

### Build Fails
```bash
# Clean build cache
docker builder prune

# Build without cache
docker build --no-cache -t okta-mcp-admin-ui:latest .
```

### Container Exits Immediately
```bash
# Check logs
docker logs okta-mcp-admin-ui

# Run interactively to debug
docker run -it --rm okta-mcp-admin-ui:latest sh
```
