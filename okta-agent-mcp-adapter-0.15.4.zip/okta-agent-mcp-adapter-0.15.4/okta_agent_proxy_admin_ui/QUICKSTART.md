# Quick Start Guide

Get the admin UI running in 5 minutes.

## Prerequisites

- Node.js 20+ installed
- Okta MCP Adapter gateway running on `http://localhost:8000`

## Step 1: Install

```bash
cd okta_agent_proxy_admin_ui
./setup.sh
```

This will:
- Install npm dependencies
- Create `.env.local` from example
- Display next steps

## Step 2: Start

```bash
npm run dev
```

The admin UI starts at `http://localhost:3001`

## Step 3: Sign in

Open `http://localhost:3001` in your browser and click **Sign in**. You'll
be redirected to Okta (the OIDC app configured via `ADMIN_UI_OKTA_*`
environment variables). Sign in with any user assigned to that app.

There is no local username/password — the adapter's admin API accepts only
Okta OAuth access tokens (v0.15.x+).

## Step 4: Verify

After login, you should see:
- Dashboard with agent and backend statistics
- Navigation to Agents and Backends pages
- System status indicators

## What You Can Do

### Manage Agents

1. Click **Agents** in navigation
2. Click **Add Agent** button
3. Fill in:
   - Agent ID (e.g., `claude-code`)
   - Okta Client ID
   - Client Secret (encrypted in database)
   - Private Key (JWK format for ID-JAG)
   - Backend Access (comma-separated list)
4. Click **Create**

### Manage Backends

1. Click **Backends** in navigation
2. Click **Add Backend** button
3. Fill in:
   - Backend Name (e.g., `hr-system`)
   - URL (e.g., `http://hr-mcp.example.com`)
   - Paths (e.g., `/hr, /employees`)
   - Auth Method (okta-cross-app, pre-shared-key, or service-account)
   - Auth configuration (varies by method)
4. Click **Create**

## Troubleshooting

**Cannot connect to API**

Check if the gateway is running:

```bash
curl http://localhost:8000/.well-known/oauth-protected-resource
```

If not running, start it:

```bash
cd .. && python -m okta_agent_proxy.main http
```

**Login fails**

Verify admin credentials in gateway configuration or environment variables.

**Port 3001 already in use**

Change the port in `package.json`:

```json
"dev": "next dev -p 3002",
"start": "next start -p 3002"
```

**Build errors**

Clear cache and reinstall:

```bash
rm -rf .next node_modules
npm install
```

## Next Steps

- Read [README.md](README.md) for detailed documentation
- Review [DEVELOPMENT.md](DEVELOPMENT.md) for development guide
- Check the main project [CLAUDE.md](../CLAUDE.md) for architecture details

## Production Deployment

For production use:

1. Set production API URL in `.env.local`:
   ```
   NEXT_PUBLIC_API_URL=https://your-gateway.example.com
   ```

2. Build and start:
   ```bash
   npm run build
   npm start
   ```

3. Or deploy to Vercel:
   ```bash
   vercel deploy
   ```

See [README.md](README.md) for more deployment options (Docker, static export, etc.)
