# Okta OIDC Authentication Setup for Admin UI

The Admin UI now uses Okta as the identity provider via OpenID Connect (OIDC) for authentication. This provides enterprise-grade security with OAuth 2.0 Authorization Code flow with PKCE.

## Prerequisites

- Okta account (developer or production)
- Admin access to create OAuth applications in Okta

## Step 1: Create OAuth 2.0 Application in Okta

1. Log in to your Okta Admin Console
2. Navigate to **Applications** > **Applications**
3. Click **Create App Integration**
4. Select **OIDC - OpenID Connect**
5. Choose **Web Application**
6. Configure the application:

### Application Settings

| Field | Value |
|-------|-------|
| **App integration name** | Okta MCP Adapter Admin UI |
| **Grant type** | Authorization Code, Refresh Token |
| **Sign-in redirect URIs** | `http://localhost:3001/api/auth/callback/okta` (for local dev)<br/>`https://your-domain.com/api/auth/callback/okta` (for production) |
| **Sign-out redirect URIs** | `http://localhost:3001/login` (for local dev)<br/>`https://your-domain.com/login` (for production) |
| **Controlled access** | Choose based on your requirements (e.g., "Allow everyone in your organization to access") |

7. Click **Save**
8. Note the **Client ID** and **Client secret** from the application page

> **Note:** If you plan to use **Okta Agent Import**, you must also configure OAuth for Okta scopes — see Step 1b.

## Step 1b: Enable OAuth for Okta Scopes (Required for AI Agent Import)

The Admin UI's OIDC app must be granted Okta Management API scopes so the admin's token can call Okta's AI Agent APIs directly.

### Why This Is Needed

When an admin imports agents, the adapter forwards the admin's own Okta access token to Okta's AI Agent Management APIs. The OIDC app must be authorized to request these scopes, and the admin must have an Okta role that permits them.

### Grant Okta API Scopes

1. In **Okta Admin Console** → **Applications > Applications**
2. Click on your **Admin UI OIDC application**
3. Go to the **Okta API Scopes** tab
   - If not visible, your org may not have "OAuth for Okta" enabled — contact Okta support.
4. Click **Grant** next to each:

   | Scope | Purpose |
   |-------|---------|
   | `okta.aiAgents.read` | List and read AI Agent details |
   | `okta.aiAgents.manage` | Import and sync operations |
   | `okta.apps.read` | Read linked OIDC app details |
   | `okta.groups.read` | Read group information |
   | `okta.authorizationServers.read` | Match connections to adapter backends |

5. Verify each shows **Granted** (green checkmark)

### Verify Admin User Role

1. Navigate to **Security > Administrators**
2. Verify the admin user has **Super Administrator** or a custom role with: Manage AI agents, View applications, View groups, View authorization servers

### Troubleshooting

| Symptom | Fix |
|---------|-----|
| "Okta API Scopes" tab not visible | Contact Okta support to enable OAuth for Okta |
| 403 "insufficient_scopes" on Import page | Grant required scopes on the OIDC app |
| 403 after granting scopes | Verify admin user has correct Okta role |
| Still failing after granting | Sign out and sign back in for fresh token |
| "okta_auth_required" error | Use "Sign in with Okta" not legacy login |

## Step 2: Configure Environment Variables

### For Local Development

Create or update `.env.local`:

```bash
# NextAuth Configuration
NEXTAUTH_URL=http://localhost:3001
NEXTAUTH_SECRET=<generate-random-secret>  # Use: openssl rand -base64 32

# Okta OIDC Provider
OKTA_DOMAIN=your-okta-domain.okta.com  # e.g., dev-12345.okta.com
OKTA_CLIENT_ID=<client-id-from-okta>
OKTA_CLIENT_SECRET=<client-secret-from-okta>
```

### For Docker/Production

Add to your `.env` file (root of repository):

```bash
# Admin UI NextAuth Configuration
ADMIN_UI_NEXTAUTH_URL=http://localhost:3001  # or your production URL
ADMIN_UI_NEXTAUTH_SECRET=<generate-random-secret>

# Admin UI Okta OIDC Provider
ADMIN_UI_OKTA_DOMAIN=your-okta-domain.okta.com
ADMIN_UI_OKTA_CLIENT_ID=<client-id-from-okta>
ADMIN_UI_OKTA_CLIENT_SECRET=<client-secret-from-okta>
```

## Step 3: Generate NEXTAUTH_SECRET

Run this command to generate a secure random secret:

```bash
openssl rand -base64 32
```

Use the output as your `NEXTAUTH_SECRET` value.

## Step 4: Start the Application

### Local Development

```bash
cd okta_agent_proxy_admin_ui
npm install
npm run dev
```

Visit `http://localhost:3001` and click "Sign in with Okta"

### Docker

```bash
docker-compose build admin-ui
docker-compose up -d admin-ui
```

Visit `http://localhost:3001` and click "Sign in with Okta"

## Authentication Flow

1. **User visits Admin UI** → Redirected to login page
2. **Click "Sign in with Okta"** → Redirected to Okta login page
3. **User authenticates with Okta** → Okta validates credentials
4. **Okta redirects back** → Authorization code sent to callback URL
5. **Token exchange** → Admin UI exchanges code for ID/Access tokens
6. **Session created** → User can access the dashboard

## Security Features

- ✅ **OAuth 2.0 Authorization Code flow with PKCE** - Industry standard for web apps
- ✅ **State parameter** - CSRF protection
- ✅ **JWT session tokens** - Stateless authentication
- ✅ **Automatic token refresh** - Seamless session management
- ✅ **Secure session storage** - HTTP-only cookies
- ✅ **Route protection** - Middleware-based authorization

## Troubleshooting

### Error: "OAuthCallback"

- Verify redirect URI in Okta matches exactly: `http://localhost:3001/api/auth/callback/okta`
- Check that the OAuth app in Okta has "Authorization Code" grant type enabled

### Error: "OAuthSignin"

- Verify `OKTA_DOMAIN` is correct (without https://)
- Check that `OKTA_CLIENT_ID` and `OKTA_CLIENT_SECRET` are correct
- Ensure the OAuth application is assigned to your user/group in Okta

### User redirected to login after authentication

- Verify `NEXTAUTH_SECRET` is set and is a strong random value
- Check browser console for errors
- Ensure `NEXTAUTH_URL` matches the URL you're accessing

### "Invalid client credentials"

- Double-check `OKTA_CLIENT_SECRET` is correct
- Verify the OAuth client is active in Okta

## Advanced Configuration

### Custom Scopes

To request additional scopes from Okta, modify `lib/auth.ts`:

```typescript
authorization: {
  params: {
    scope: "openid email profile offline_access groups",  // Add custom scopes
  },
},
```

### Token Refresh

Token refresh is configured but not fully implemented. To enable:

1. Add "Refresh Token" grant type in Okta OAuth app
2. Implement refresh logic in `lib/auth.ts` jwt callback

### Custom Claims

Access custom Okta claims in your app:

```typescript
// In callbacks.jwt
async jwt({ token, account, profile }) {
  if (profile) {
    token.groups = profile.groups;  // Access custom claims
  }
  return token;
}
```

## Migration from Old Authentication

The previous username/password authentication was **fully removed** in v0.15.x.
The adapter no longer exposes `POST /api/admin/login` and the admin API
accepts only Okta OAuth access tokens. The Admin UI NextAuth flow is the only
supported sign-in path.

## Support

For issues or questions:
- NextAuth.js docs: https://next-auth.js.org/
- Okta OIDC docs: https://developer.okta.com/docs/guides/implement-oauth-for-okta/main/
- Report issues: https://github.com/anthropics/okta-agent-mcp-adapter/issues
