#!/bin/sh
set -e

# Print environment for debugging
echo "Starting Admin UI"
echo "Gateway URL: okta-agent-mcp-adapter:8000 (hardcoded for Docker Compose)"

# Start Next.js server
exec node server.js
