"use client"

import { useEffect, useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Users, Shield, CheckCircle, AlertTriangle, Clock, Server } from 'lucide-react';
import { apiClient, type ConnectionStatus } from '@/lib/api-client';

export default function DashboardPage() {
  const [stats, setStats] = useState({
    totalAgents: 0,
    enabledAgents: 0,
    totalResources: 0,
  });
  const [syncStatus, setSyncStatus] = useState<ConnectionStatus | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadStats();
  }, []);

  const loadStats = async () => {
    try {
      const [agents, resources, status] = await Promise.all([
        apiClient.listAgents(),
        apiClient.listResources().catch(() => []),
        apiClient.getConnectionStatus().catch(() => null),
      ]);

      const agentsArray = Array.isArray(agents) ? agents : [];
      const resourcesArray = Array.isArray(resources) ? resources : [];

      setStats({
        totalAgents: agentsArray.length,
        enabledAgents: agentsArray.filter(a => a.enabled).length,
        totalResources: resourcesArray.length,
      });
      setSyncStatus(status);
    } catch (error) {
      console.error('Load stats error:', error);
    } finally {
      setLoading(false);
    }
  };

  const syncInfo = syncStatus?.syncer;

  const cards = [
    {
      title: 'Agents',
      value: stats.totalAgents,
      description: `${stats.enabledAgents} enabled`,
      icon: Users,
      color: 'text-blue-600',
    },
    {
      title: 'Resources',
      value: stats.totalResources,
      description: 'Downstream endpoints',
      icon: Server,
      color: 'text-green-600',
    }
  ];

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="text-muted-foreground">Loading...</div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-3xl font-bold tracking-tight">Dashboard</h2>
        <p className="text-muted-foreground">
          Overview of your Okta MCP Adapter configuration
        </p>
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
        {cards.map((card) => {
          const Icon = card.icon;
          return (
            <Card key={card.title}>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">
                  {card.title}
                </CardTitle>
                <Icon className={`h-4 w-4 ${card.color}`} />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{card.value}</div>
                <p className="text-xs text-muted-foreground">
                  {card.description}
                </p>
              </CardContent>
            </Card>
          );
        })}
      </div>

      {/* Sync Status Card */}
      <Card>
        <CardHeader>
          <CardTitle className="text-lg">Sync Status</CardTitle>
          <CardDescription>Okta Managed Connections sync state — use Agents &gt; Sync All to refresh</CardDescription>
        </CardHeader>
        <CardContent>
          {syncInfo ? (
            <div className="flex items-center gap-6 text-sm">
              <div className="flex items-center gap-2">
                {syncInfo.status === 'success' || syncInfo.status === 'local' ? (
                  <CheckCircle className="w-4 h-4 text-green-600" />
                ) : syncInfo.status === 'error' ? (
                  <AlertTriangle className="w-4 h-4 text-amber-600" />
                ) : (
                  <Clock className="w-4 h-4 text-gray-400" />
                )}
                <span>Status: <span className="font-medium">{syncInfo.status}</span></span>
              </div>
              <span>Resources: <span className="font-medium">{syncInfo.resources_count}</span></span>
              {syncInfo.unresolved_count > 0 && (
                <span className="text-amber-600 font-medium">
                  {syncInfo.unresolved_count} unresolved
                </span>
              )}
              {syncInfo.last_sync_at && (
                <span className="text-muted-foreground">
                  Last: {new Date(syncInfo.last_sync_at).toLocaleString()}
                </span>
              )}
            </div>
          ) : (
            <p className="text-sm text-muted-foreground">
              Sync status unavailable. Configure OKTA_AI_AGENT_ID and OKTA_SERVICE_TOKEN to enable.
            </p>
          )}
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Getting Started</CardTitle>
          <CardDescription>
            Quick guide to managing your MCP Adapter
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid gap-4 md:grid-cols-2">
            <div className="space-y-2">
              <h3 className="font-semibold flex items-center">
                <Server className="w-4 h-4 mr-2 text-green-600" />
                Resources
              </h3>
              <p className="text-sm text-muted-foreground">
                Resources are downstream endpoints (MCP servers). Create them in the Resources page. When linked to Okta connections, they get automatic authentication.
              </p>
            </div>
            <div className="space-y-2">
              <h3 className="font-semibold flex items-center">
                <Users className="w-4 h-4 mr-2 text-blue-600" />
                Agents
              </h3>
              <p className="text-sm text-muted-foreground">
                Agents represent MCP clients (Claude Code, Visual Studio Code etc). Import them from Okta via the Okta Import page.
              </p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
