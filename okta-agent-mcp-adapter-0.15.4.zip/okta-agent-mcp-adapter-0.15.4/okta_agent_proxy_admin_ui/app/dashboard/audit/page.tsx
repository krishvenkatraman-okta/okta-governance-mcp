"use client"

import { useEffect, useState } from 'react';
import { apiClient, AuditLogEntry } from '@/lib/api-client';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { useToast } from '@/components/ui/use-toast';
import { RefreshCw, Search, X } from 'lucide-react';

export default function AuditLogPage() {
  const [auditLog, setAuditLog] = useState<AuditLogEntry[]>([]);
  const [loading, setLoading] = useState(true);
  const [entityType, setEntityType] = useState('');
  const [entityId, setEntityId] = useState('');
  const [limit, setLimit] = useState('100');
  const { toast } = useToast();

  const loadAuditLog = async () => {
    setLoading(true);
    try {
      const params: any = {};
      if (entityType) params.entity_type = entityType;
      if (entityId) params.entity_id = entityId;
      if (limit) params.limit = parseInt(limit);

      const log = await apiClient.getAuditLog(params);
      setAuditLog(log);
    } catch (error: any) {
      toast({
        title: 'Error',
        description: error.message || 'Failed to load audit log',
        variant: 'destructive',
      });
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadAuditLog();
  }, []);

  const handleClearFilters = () => {
    setEntityType('');
    setEntityId('');
    setLimit('100');
  };

  const formatTimestamp = (timestamp?: string) => {
    if (!timestamp) return '—';
    const d = new Date(timestamp);
    if (isNaN(d.getTime())) return timestamp;
    return d.toLocaleString();
  };

  const getActionBadgeColor = (action: string) => {
    if (action.includes('created')) return 'bg-green-100 text-green-800';
    if (action.includes('updated')) return 'bg-blue-100 text-blue-800';
    if (action.includes('deleted')) return 'bg-red-100 text-red-800';
    if (action.includes('failure') || action.includes('rejected') || action.includes('denied')) {
      return 'bg-red-100 text-red-800';
    }
    if (action.includes('success') || action.includes('validated') || action.includes('granted')) {
      return 'bg-green-100 text-green-800';
    }
    return 'bg-gray-100 text-gray-800';
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold">Audit Log</h1>
          <p className="text-gray-600 mt-1">View system activity and configuration changes</p>
        </div>
        <Button onClick={loadAuditLog} disabled={loading}>
          <RefreshCw className={`w-4 h-4 mr-2 ${loading ? 'animate-spin' : ''}`} />
          Refresh
        </Button>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Filters</CardTitle>
          <CardDescription>Filter audit log entries</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div>
              <Label htmlFor="entity-type">Entity Type</Label>
              <Input
                id="entity-type"
                placeholder="e.g., agent, resource"
                value={entityType}
                onChange={(e) => setEntityType(e.target.value)}
              />
            </div>
            <div>
              <Label htmlFor="entity-id">Entity ID</Label>
              <Input
                id="entity-id"
                placeholder="e.g., claude-code"
                value={entityId}
                onChange={(e) => setEntityId(e.target.value)}
              />
            </div>
            <div>
              <Label htmlFor="limit">Limit</Label>
              <Input
                id="limit"
                type="number"
                placeholder="100"
                value={limit}
                onChange={(e) => setLimit(e.target.value)}
              />
            </div>
            <div className="flex items-end gap-2">
              <Button onClick={loadAuditLog} className="flex-1">
                <Search className="w-4 h-4 mr-2" />
                Apply
              </Button>
              <Button onClick={handleClearFilters} variant="outline">
                <X className="w-4 h-4" />
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Audit Entries ({auditLog.length})</CardTitle>
          <CardDescription>Recent system events and configuration changes</CardDescription>
        </CardHeader>
        <CardContent>
          {loading ? (
            <div className="text-center py-8 text-gray-500">Loading audit log...</div>
          ) : auditLog.length === 0 ? (
            <div className="text-center py-8 text-gray-500">No audit entries found</div>
          ) : (
            <div className="space-y-3">
              {auditLog.map((entry, index) => (
                <div
                  key={entry.id || index}
                  className="border rounded-lg p-4 hover:bg-gray-50 transition"
                >
                  <div className="flex justify-between items-start mb-2">
                    <div className="flex items-center gap-2">
                      <span
                        className={`px-2 py-1 rounded text-xs font-medium ${getActionBadgeColor(
                          entry.action
                        )}`}
                      >
                        {entry.action}
                      </span>
                      {entry.entity_type && (
                        <span className="text-sm text-gray-600">
                          {entry.entity_type}
                          {entry.entity_id && `: ${entry.entity_id}`}
                        </span>
                      )}
                    </div>
                    <span className="text-sm text-gray-500">
                      {formatTimestamp(entry.changed_at)}
                    </span>
                  </div>

                  {entry.changed_by && (
                    <div className="text-sm text-gray-600 mb-2">
                      User: <span className="font-mono">{entry.changed_by}</span>
                    </div>
                  )}

                  {entry.changes && Object.keys(entry.changes).length > 0 && (
                    <details className="mt-2">
                      <summary className="cursor-pointer text-sm text-blue-600 hover:text-blue-800">
                        View Changes
                      </summary>
                      <pre className="mt-2 p-2 bg-gray-100 rounded text-xs overflow-x-auto">
                        {JSON.stringify(entry.changes, null, 2)}
                      </pre>
                    </details>
                  )}

                  {entry.details && Object.keys(entry.details).length > 0 && (
                    <details className="mt-2">
                      <summary className="cursor-pointer text-sm text-blue-600 hover:text-blue-800">
                        View Details
                      </summary>
                      <pre className="mt-2 p-2 bg-gray-100 rounded text-xs overflow-x-auto">
                        {JSON.stringify(entry.details, null, 2)}
                      </pre>
                    </details>
                  )}
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
