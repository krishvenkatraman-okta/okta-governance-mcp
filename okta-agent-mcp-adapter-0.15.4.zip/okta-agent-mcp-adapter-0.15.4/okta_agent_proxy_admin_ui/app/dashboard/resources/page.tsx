"use client"

import { useEffect, useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { useToast } from '@/components/ui/use-toast';
import { apiClient, type Resource } from '@/lib/api-client';
import { Edit, Trash2, FileText, Info, Loader2 } from 'lucide-react';
import Link from 'next/link';

function TypeBadge({ type }: { type?: string }) {
  const t = (type || 'mcp').toLowerCase();
  const colors =
    t === 'mcp'
      ? 'bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200'
      : t === 'a2a'
      ? 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200'
      : t === 'api'
      ? 'bg-purple-100 text-purple-800 dark:bg-purple-900 dark:text-purple-200'
      : 'bg-gray-100 text-gray-800 dark:bg-gray-800 dark:text-gray-200';
  return (
    <span className={`inline-flex items-center px-1.5 py-0.5 rounded text-[10px] font-medium uppercase ${colors}`}>
      {t}
    </span>
  );
}

export default function ResourcesPage() {
  const [resources, setResources] = useState<Resource[]>([]);
  const [loading, setLoading] = useState(true);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [deletingName, setDeletingName] = useState<string | null>(null);
  const [editingResource, setEditingResource] = useState<Resource | null>(null);
  const [saving, setSaving] = useState(false);
  const [formData, setFormData] = useState({
    name: '',
    type: 'mcp',
    url: '',
    description: '',
    tags: '',
    enabled: true,
  });
  const { toast } = useToast();

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      const data = await apiClient.listResources();
      // Hide unlinked rows (no URL yet). Configure those from the agent
      // detail page; the Resources list is for live, enabled endpoints.
      const linked = (Array.isArray(data) ? data : []).filter(
        (r) => !!(r.url || r.mcp_url)
      );
      setResources(linked);
    } catch (error: any) {
      if (error.status !== 401) {
        setResources([]);
      }
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to load resources",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const handleEdit = (resource: Resource) => {
    setEditingResource(resource);
    setFormData({
      name: resource.name,
      type: resource.type || resource.protocol || 'mcp',
      url: resource.url || resource.mcp_url || '',
      description: resource.description || '',
      tags: (resource.tags || []).join(', '),
      enabled: resource.enabled !== false,
    });
    setDialogOpen(true);
  };

  const handleSave = async () => {
    if (!editingResource) return;
    if (!formData.url.trim()) {
      toast({ title: "Validation Error", description: "URL is required", variant: "destructive" });
      return;
    }

    setSaving(true);
    try {
      const payload: Partial<Resource> = {
        name: formData.name.trim(),
        type: formData.type,
        url: formData.url.trim(),
        description: formData.description.trim(),
        tags: formData.tags ? formData.tags.split(',').map(t => t.trim()).filter(Boolean) : [],
        enabled: formData.enabled,
      };
      await apiClient.updateResource(editingResource.name, payload);
      toast({ title: "Success", description: "Resource updated" });
      setDialogOpen(false);
      loadData();
    } catch (error: any) {
      toast({ title: "Error", description: error.message || "Failed to save resource", variant: "destructive" });
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = async () => {
    if (!deletingName) return;
    try {
      await apiClient.deleteResource(deletingName);
      toast({ title: "Success", description: "Resource deleted" });
      setDeleteDialogOpen(false);
      setDeletingName(null);
      loadData();
    } catch (error: any) {
      toast({ title: "Error", description: error.message || "Failed to delete resource", variant: "destructive" });
    }
  };

  if (loading) {
    return <div className="flex items-center justify-center h-64">Loading...</div>;
  }

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-3xl font-bold tracking-tight">Resources</h2>
        <p className="text-muted-foreground">
          Linked resources (URL configured). New per-connection rows appear on the agent detail page; set a URL there to surface them here.
        </p>
      </div>

      {resources.length > 0 ? (
        <Card>
          <CardContent className="p-0">
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="border-b bg-muted/50">
                    <th className="text-left p-3 text-sm font-medium text-muted-foreground">Name</th>
                    <th className="text-left p-3 text-sm font-medium text-muted-foreground">Agent</th>
                    <th className="text-left p-3 text-sm font-medium text-muted-foreground">Connection</th>
                    <th className="text-left p-3 text-sm font-medium text-muted-foreground">Type</th>
                    <th className="text-left p-3 text-sm font-medium text-muted-foreground">URL</th>
                    <th className="text-left p-3 text-sm font-medium text-muted-foreground">Auth Method</th>
                    <th className="text-left p-3 text-sm font-medium text-muted-foreground">Enabled</th>
                    <th className="text-right p-3 text-sm font-medium text-muted-foreground">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {resources.map((r) => (
                    <tr key={r.name} className="border-b last:border-0 hover:bg-muted/30">
                      <td className="p-3 text-sm font-medium">{r.name}</td>
                      <td className="p-3 text-sm text-muted-foreground font-mono">
                        {r.agent_id ? (
                          <Link href={`/dashboard/agents/${encodeURIComponent(r.agent_id)}`} className="hover:underline">
                            {r.agent_id}
                          </Link>
                        ) : '-'}
                      </td>
                      <td className="p-3 text-sm text-muted-foreground font-mono truncate max-w-xs">{r.connection_id || '-'}</td>
                      <td className="p-3">
                        <TypeBadge type={r.type || r.protocol} />
                      </td>
                      <td className="p-3 text-sm max-w-xs truncate">{r.url || r.mcp_url || <span className="text-muted-foreground italic">not set</span>}</td>
                      <td className="p-3 text-sm text-muted-foreground">{r.auth_method || '-'}</td>
                      <td className="p-3">
                        <span className={`inline-block w-2 h-2 rounded-full ${r.enabled !== false ? 'bg-green-500' : 'bg-gray-400'}`} />
                        <span className="ml-1.5 text-sm">{r.enabled !== false ? 'Yes' : 'No'}</span>
                      </td>
                      <td className="p-3 text-right">
                        <div className="flex justify-end gap-1">
                          <Link href={`/dashboard/resources/${encodeURIComponent(r.name)}/audit`}>
                            <Button variant="ghost" size="icon" title="View Audit">
                              <FileText className="w-4 h-4" />
                            </Button>
                          </Link>
                          <Button variant="ghost" size="icon" onClick={() => handleEdit(r)} title="Edit">
                            <Edit className="w-4 h-4" />
                          </Button>
                          <Button variant="ghost" size="icon" onClick={() => { setDeletingName(r.name); setDeleteDialogOpen(true); }} title="Delete">
                            <Trash2 className="w-4 h-4 text-red-500" />
                          </Button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </CardContent>
        </Card>
      ) : (
        <Card>
          <CardContent className="flex flex-col items-center justify-center py-12">
            <FileText className="w-12 h-12 text-gray-400 mb-4" />
            <p className="text-lg font-medium text-muted-foreground mb-2">No linked resources yet</p>
            <p className="text-sm text-muted-foreground text-center max-w-lg">
              Rows appear here once you set a URL on one of the agent&apos;s Managed Connections. Go to{' '}
              <Link href="/dashboard/agents" className="underline">Agents</Link>, open an imported agent, and configure a connection.
            </p>
          </CardContent>
        </Card>
      )}

      <div className="flex items-start gap-3 p-4 rounded-lg bg-muted/30 border">
        <Info className="w-5 h-5 text-muted-foreground mt-0.5 flex-shrink-0" />
        <p className="text-sm text-muted-foreground">
          Each row represents one (agent, Okta Managed Connection) pair. Sync owns connection type,
          scopes, and scope condition; admins edit the downstream URL, slug, description, and
          enabled flag.
        </p>
      </div>

      {/* Edit dialog */}
      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Edit Resource</DialogTitle>
            <DialogDescription>
              Update routing fields. Connection state (scopes, type) is read-only — change it in Okta and re-sync.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="name">Name *</Label>
              <Input
                id="name"
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                placeholder="hr-system"
              />
              <p className="text-xs text-muted-foreground">Lowercase slug (a-z, 0-9, hyphens)</p>
            </div>
            <div className="space-y-2">
              <Label htmlFor="type">Type</Label>
              <select
                id="type"
                value={formData.type}
                onChange={(e) => setFormData({ ...formData, type: e.target.value })}
                className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm"
              >
                <option value="mcp">MCP</option>
                <option value="api">API</option>
                <option value="a2a">A2A</option>
              </select>
            </div>
            <div className="space-y-2">
              <Label htmlFor="url">URL *</Label>
              <Input
                id="url"
                value={formData.url}
                onChange={(e) => setFormData({ ...formData, url: e.target.value })}
                placeholder="https://hr-mcp.example.com/mcp"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="description">Description</Label>
              <Textarea
                id="description"
                value={formData.description}
                onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                placeholder="HR resource for employee lookups"
                rows={2}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="tags">Tags</Label>
              <Input
                id="tags"
                value={formData.tags}
                onChange={(e) => setFormData({ ...formData, tags: e.target.value })}
                placeholder="hr, employees, internal (comma-separated)"
              />
            </div>
            <div className="flex items-center gap-2">
              <input
                id="enabled"
                type="checkbox"
                checked={formData.enabled}
                onChange={(e) => setFormData({ ...formData, enabled: e.target.checked })}
                className="h-4 w-4"
              />
              <Label htmlFor="enabled">Enabled</Label>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setDialogOpen(false)}>Cancel</Button>
            <Button onClick={handleSave} disabled={saving}>
              {saving && <Loader2 className="w-4 h-4 mr-2 animate-spin" />}
              Update
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Delete confirmation */}
      <Dialog open={deleteDialogOpen} onOpenChange={setDeleteDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Delete Resource</DialogTitle>
            <DialogDescription>
              Are you sure you want to delete this resource? Agents with access will lose connectivity until the next Okta sync recreates the row.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button variant="outline" onClick={() => setDeleteDialogOpen(false)}>Cancel</Button>
            <Button variant="destructive" onClick={handleDelete}>Delete</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
