"use client"

import { useEffect, useRef, useState, useCallback } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { useToast } from '@/components/ui/use-toast';
import {
  getDcrRedirectPatterns,
  updateDcrRedirectPatterns,
  type DcrRedirectPatternsResponse,
} from '@/lib/api/dcr-policy';
import {
  validateRedirectPattern,
  validateRedirectPatterns,
  RedirectPatternError,
} from '@/lib/validation/redirect-pattern';
import { Loader2, Plus, Trash2, RotateCcw, Copy, ChevronDown, ChevronUp, Info, Database, FileText } from 'lucide-react';

const EXAMPLES: { heading: string; patterns: string[] }[] = [
  {
    heading: 'Web redirects',
    patterns: [
      'https://global.consent.azure-apim.net/redirect/*',
      'https://*.consent.azure-apim.net/redirect/*',
      'https://app.example.com/oauth/callback',
    ],
  },
  {
    heading: 'Loopback (local dev / native apps)',
    patterns: [
      'http://localhost:*/callback',
      'http://127.0.0.1:*/callback',
      'http://[::1]:*/callback',
    ],
  },
  {
    heading: 'Native-app schemes (RFC 8252 §7.1)',
    patterns: [
      'com.example.app:/oauth2redirect',
      'com.example.app:/oauth2redirect/*',
      'cursor://anysphere.cursor-mcp/oauth/callback',
      'vscode://vscode.vscode-mcp/oauth/callback',
    ],
  },
];

interface RowError {
  [index: number]: string | undefined;
}

export default function DcrRedirectPatternsPage() {
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [lastLoaded, setLastLoaded] = useState<DcrRedirectPatternsResponse | null>(null);
  const [draft, setDraft] = useState<string[]>([]);
  const [rowErrors, setRowErrors] = useState<RowError>({});
  const [resetDialogOpen, setResetDialogOpen] = useState(false);
  const [examplesOpen, setExamplesOpen] = useState(false);
  const rowRefs = useRef<(HTMLInputElement | null)[]>([]);
  const { toast } = useToast();

  const loadPatterns = useCallback(async () => {
    try {
      const data = await getDcrRedirectPatterns();
      setLastLoaded(data);
      setDraft([...data.patterns]);
      setRowErrors({});
    } catch (error) {
      toast({
        title: 'Error',
        description: error instanceof Error ? error.message : 'Failed to load redirect patterns',
        variant: 'destructive',
      });
    } finally {
      setLoading(false);
    }
  }, [toast]);

  useEffect(() => {
    loadPatterns();
  }, [loadPatterns]);

  // --- Derived state ---

  const isDirty = (() => {
    if (!lastLoaded) return false;
    const saved = lastLoaded.patterns;
    if (draft.length !== saved.length) return true;
    return draft.some((p, i) => p !== saved[i]);
  })();

  const hasValidationErrors = Object.values(rowErrors).some(Boolean);
  const isEmpty = draft.length === 0;
  const canSave = isDirty && !hasValidationErrors && !isEmpty && !saving;

  // --- Row handlers ---

  const validateRow = (index: number, value: string) => {
    if (value.trim() === '') {
      setRowErrors((prev) => ({ ...prev, [index]: 'Pattern must not be empty' }));
      return;
    }
    try {
      validateRedirectPattern(value.trim());
      setRowErrors((prev) => {
        const next = { ...prev };
        delete next[index];
        return next;
      });
    } catch (e) {
      setRowErrors((prev) => ({
        ...prev,
        [index]: e instanceof RedirectPatternError ? e.message : 'Invalid pattern',
      }));
    }
  };

  const updateRow = (index: number, value: string) => {
    setDraft((prev) => {
      const next = [...prev];
      next[index] = value;
      return next;
    });
    validateRow(index, value);
  };

  const removeRow = (index: number) => {
    setDraft((prev) => prev.filter((_, i) => i !== index));
    // Rebuild errors with shifted indices
    setRowErrors((prev) => {
      const next: RowError = {};
      Object.entries(prev).forEach(([k, v]) => {
        const ki = Number(k);
        if (ki < index) next[ki] = v;
        else if (ki > index) next[ki - 1] = v;
        // ki === index is removed
      });
      return next;
    });
  };

  const addRow = () => {
    setDraft((prev) => [...prev, '']);
    // Focus the new row after render
    setTimeout(() => {
      rowRefs.current[draft.length]?.focus();
    }, 0);
  };

  const discardChanges = () => {
    if (lastLoaded) {
      setDraft([...lastLoaded.patterns]);
      setRowErrors({});
    }
  };

  const handleResetToDefaults = async () => {
    setResetDialogOpen(false);
    setLoading(true);
    await loadPatterns();
  };

  const handleSave = async () => {
    // Full-list client-side validation
    let normalized: string[];
    try {
      normalized = validateRedirectPatterns(draft);
    } catch (e) {
      toast({
        title: 'Validation Error',
        description: e instanceof Error ? e.message : 'Invalid patterns',
        variant: 'destructive',
      });
      return;
    }

    setSaving(true);
    try {
      const response = await updateDcrRedirectPatterns(normalized);
      setLastLoaded(response);
      setDraft([...response.patterns]);
      setRowErrors({});
      toast({
        title: 'Success',
        description: `Saved ${response.patterns.length} redirect pattern${response.patterns.length !== 1 ? 's' : ''}.`,
      });
    } catch (err: any) {
      toast({
        title: 'Error',
        description: err.message || 'Failed to save redirect patterns',
        variant: 'destructive',
      });
    } finally {
      setSaving(false);
    }
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text).then(() => {
      toast({ title: 'Copied', description: text });
    });
  };

  // --- Render ---

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <Loader2 className="w-6 h-6 animate-spin text-muted-foreground" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Page header */}
      <div>
        <h2 className="text-3xl font-bold tracking-tight">DCR Policy — Redirect Patterns</h2>
        <p className="text-muted-foreground mt-1 max-w-3xl">
          These patterns control which redirect URIs are accepted during Dynamic Client Registration.
          Changes take effect immediately for all subsequent DCR requests.
        </p>
      </div>

      {/* Help blurb */}
      <div className="flex items-start gap-3 p-4 rounded-lg bg-muted/30 border">
        <Info className="w-5 h-5 text-muted-foreground mt-0.5 flex-shrink-0" />
        <div className="text-sm text-muted-foreground space-y-1">
          <p>Three kinds of patterns are supported:</p>
          <ul className="list-disc ml-5 space-y-0.5">
            <li>
              <strong>Web redirects</strong> (https://... or http://...) — wildcards allowed as
              the entire leftmost host label, in path segments, or in the port.
            </li>
            <li>
              <strong>Loopback</strong> (http://localhost, http://127.0.0.1, http://[::1]) — any
              port is allowed per RFC 8252.
            </li>
            <li>
              <strong>Native-app schemes</strong> (e.g. com.example.app:/callback,
              cursor://..., vscode://...) — RFC 8252 §7.1 recommends reverse-DNS,
              but single-word schemes from real-world IDEs are also accepted.
              Network-protocol schemes (ftp, ws, mailto, etc.) are blocked.
            </li>
          </ul>
        </div>
      </div>

      {/* Metadata row */}
      <Card>
        <CardContent className="py-4 px-6">
          <div className="flex flex-wrap gap-x-8 gap-y-2 text-sm">
            <div className="flex items-center gap-2">
              {lastLoaded?.source === 'database' ? (
                <Database className="w-4 h-4 text-green-600 dark:text-green-400" />
              ) : (
                <FileText className="w-4 h-4 text-amber-600 dark:text-amber-400" />
              )}
              <span className="text-muted-foreground">Source:</span>
              <span className="font-medium">
                {lastLoaded?.source === 'database'
                  ? 'Loaded from database'
                  : 'Using defaults — not yet saved'}
              </span>
            </div>
            {lastLoaded?.updated_at && (
              <div>
                <span className="text-muted-foreground">Last updated:</span>{' '}
                <span className="font-medium">{new Date(lastLoaded.updated_at).toLocaleString()}</span>
              </div>
            )}
            {lastLoaded?.updated_by && (
              <div>
                <span className="text-muted-foreground">By:</span>{' '}
                <span className="font-medium">{lastLoaded.updated_by}</span>
              </div>
            )}
          </div>
        </CardContent>
      </Card>

      {/* Editable pattern list */}
      <Card>
        <CardHeader className="pb-4">
          <div className="flex items-center justify-between">
            <CardTitle className="text-lg">Redirect Patterns</CardTitle>
            <div className="flex gap-2">
              <Button
                variant="outline"
                size="sm"
                onClick={() => setResetDialogOpen(true)}
              >
                <RotateCcw className="w-4 h-4 mr-1.5" />
                Reset to defaults
              </Button>
              <Button variant="outline" size="sm" onClick={addRow}>
                <Plus className="w-4 h-4 mr-1.5" />
                Add pattern
              </Button>
            </div>
          </div>
        </CardHeader>
        <CardContent className="space-y-3">
          {draft.length === 0 && (
            <p className="text-sm text-muted-foreground text-center py-6">
              No patterns configured. Click &quot;Add pattern&quot; to get started.
            </p>
          )}

          {draft.map((pattern, index) => {
            const errorId = `pattern-error-${index}`;
            const inputId = `pattern-input-${index}`;
            const error = rowErrors[index];
            return (
              <div key={index} className="space-y-1">
                <div className="flex items-center gap-2">
                  <Label htmlFor={inputId} className="sr-only">
                    Redirect pattern {index + 1}
                  </Label>
                  <Input
                    id={inputId}
                    ref={(el) => { rowRefs.current[index] = el; }}
                    value={pattern}
                    onChange={(e) => updateRow(index, e.target.value)}
                    placeholder="https://app.example.com/oauth/callback"
                    className={error ? 'border-red-500 focus-visible:ring-red-500' : ''}
                    aria-describedby={error ? errorId : undefined}
                    aria-invalid={!!error}
                  />
                  <Button
                    variant="destructive"
                    size="icon"
                    onClick={() => removeRow(index)}
                    title={`Remove pattern ${index + 1}`}
                    className="flex-shrink-0"
                  >
                    <Trash2 className="w-4 h-4" />
                  </Button>
                </div>
                {error && (
                  <p id={errorId} className="text-xs text-red-500 ml-1" role="alert">
                    {error}
                  </p>
                )}
              </div>
            );
          })}
        </CardContent>
      </Card>

      {/* Action buttons */}
      <div className="flex gap-3">
        <Button onClick={handleSave} disabled={!canSave}>
          {saving && <Loader2 className="w-4 h-4 mr-2 animate-spin" />}
          Save changes
        </Button>
        <Button variant="outline" onClick={discardChanges} disabled={!isDirty}>
          Discard changes
        </Button>
      </div>

      {/* Common examples (collapsible) */}
      <Card>
        <CardHeader className="pb-0">
          <button
            type="button"
            className="flex items-center justify-between w-full text-left"
            onClick={() => setExamplesOpen(!examplesOpen)}
            aria-expanded={examplesOpen}
          >
            <CardTitle className="text-lg">Common examples</CardTitle>
            {examplesOpen ? (
              <ChevronUp className="w-5 h-5 text-muted-foreground" />
            ) : (
              <ChevronDown className="w-5 h-5 text-muted-foreground" />
            )}
          </button>
        </CardHeader>
        {examplesOpen && (
          <CardContent className="pt-4 space-y-4">
            {EXAMPLES.map((group) => (
              <div key={group.heading}>
                <h4 className="text-sm font-semibold text-muted-foreground mb-2">
                  {group.heading}
                </h4>
                <div className="space-y-1.5">
                  {group.patterns.map((p) => (
                    <button
                      key={p}
                      type="button"
                      onClick={() => copyToClipboard(p)}
                      title="Click to copy"
                      className="flex items-center gap-2 w-full text-left group px-2 py-1 rounded hover:bg-muted/50 transition-colors"
                    >
                      <code className="text-sm font-mono break-all">{p}</code>
                      <Copy className="w-3.5 h-3.5 text-muted-foreground opacity-0 group-hover:opacity-100 transition-opacity flex-shrink-0" />
                    </button>
                  ))}
                </div>
              </div>
            ))}
          </CardContent>
        )}
      </Card>

      {/* Reset to defaults confirmation dialog */}
      <Dialog open={resetDialogOpen} onOpenChange={setResetDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Reset to defaults</DialogTitle>
            <DialogDescription>
              This will discard your current draft and reload the patterns from the server.
              Any unsaved changes will be lost.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button variant="outline" onClick={() => setResetDialogOpen(false)}>
              Cancel
            </Button>
            <Button variant="destructive" onClick={handleResetToDefaults}>
              Reset
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
