"use client"

import { signOut, useSession } from 'next-auth/react';
import { usePathname } from 'next/navigation';
import Link from 'next/link';
import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import {
  LogOut,
  Home,
  Users,
  Server,
  User,
  FileText,
  Menu,
  X,
  ChevronRight,
  Moon,
  Sun,
  Download,
  Settings
} from 'lucide-react';
import { Toaster } from '@/components/ui/toaster';
import { OktaLogo } from '@/components/okta-logo';

interface NavSection {
  title: string;
  items: {
    href: string;
    label: string;
    icon: any;
  }[];
}

export default function DashboardLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  const pathname = usePathname();
  const { data: session } = useSession();
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);
  const [theme, setTheme] = useState<'light' | 'dark'>('light');

  // Load theme from localStorage on mount
  useEffect(() => {
    const savedTheme = localStorage.getItem('theme') as 'light' | 'dark' | null;
    if (savedTheme) {
      setTheme(savedTheme);
      document.documentElement.classList.toggle('dark', savedTheme === 'dark');
    }
  }, []);

  const toggleTheme = () => {
    const newTheme = theme === 'light' ? 'dark' : 'light';
    setTheme(newTheme);
    localStorage.setItem('theme', newTheme);
    document.documentElement.classList.toggle('dark', newTheme === 'dark');
  };

  const handleLogout = async () => {
    let logoutUrl = '/login';
    try {
      const res = await fetch('/api/auth/okta-logout', { method: 'POST' });
      if (res.ok) {
        const data = await res.json();
        if (data?.logoutUrl) {
          logoutUrl = data.logoutUrl;
        }
      }
    } catch {
      // fall through to plain signOut if the revoke call fails
    }

    await signOut({ redirect: false });
    window.location.href = logoutUrl;
  };

  const navSections: NavSection[] = [
    {
      title: 'Dashboard',
      items: [
        { href: '/dashboard', label: 'Overview', icon: Home },
      ],
    },
    {
      title: 'Configuration',
      items: [
        { href: '/dashboard/agents', label: 'Agents', icon: Users },
        { href: '/dashboard/resources', label: 'Resources', icon: Server },
        { href: '/dashboard/okta-import', label: 'Okta Import', icon: Download },
      ],
    },
    {
      title: 'Security & Compliance',
      items: [
        { href: '/dashboard/audit', label: 'Audit Log', icon: FileText },
        { href: '/dashboard/sessions', label: 'User Sessions', icon: LogOut },
      ],
    },
    {
      title: 'Settings',
      items: [
        { href: '/dashboard/settings/dcr', label: 'DCR Policy', icon: Settings },
      ],
    },
  ];

  const SidebarContent = () => (
    <div className="flex flex-col h-full">
      {/* Logo */}
      <div className="flex items-center justify-between p-4 border-b dark:border-gray-700">
        {!sidebarCollapsed && (
          <div className="flex items-center space-x-3">
            <OktaLogo className="h-8" isDark={theme === 'dark'} />
            <h3 className="text-lg font-semibold text-gray-800 dark:text-white">Okta MCP Adapter</h3>
          </div>
        )}
        {sidebarCollapsed && (
          <div className="mx-auto">
            <OktaLogo className="h-8" isDark={theme === 'dark'} />
          </div>
        )}
      </div>

      {/* Navigation */}
      <nav className="flex-1 overflow-y-auto p-4 space-y-6">
        {navSections.map((section) => (
          <div key={section.title}>
            {!sidebarCollapsed && (
              <h3 className="px-3 text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wider mb-2">
                {section.title}
              </h3>
            )}
            <div className="space-y-1">
              {section.items.map((item) => {
                const Icon = item.icon;
                const isActive = pathname === item.href;
                return (
                  <Link
                    key={item.href}
                    href={item.href}
                    onClick={() => setSidebarOpen(false)}
                    className={`flex items-center px-3 py-2 text-sm font-medium rounded-lg transition-colors ${
                      isActive
                        ? 'bg-primary text-white'
                        : 'text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-800'
                    } ${sidebarCollapsed ? 'justify-center' : ''}`}
                    title={sidebarCollapsed ? item.label : undefined}
                  >
                    <Icon className={`w-5 h-5 ${sidebarCollapsed ? '' : 'mr-3'}`} />
                    {!sidebarCollapsed && <span>{item.label}</span>}
                  </Link>
                );
              })}
            </div>
          </div>
        ))}
      </nav>

      {/* Footer */}
      <div className="p-4 border-t dark:border-gray-700 space-y-2">
        {/* Theme Toggle */}
        <Button
          variant="ghost"
          size="sm"
          onClick={toggleTheme}
          className={`w-full ${sidebarCollapsed ? 'justify-center' : 'justify-start'}`}
          title="Toggle theme"
        >
          {theme === 'light' ? (
            <Moon className={`w-4 h-4 ${sidebarCollapsed ? '' : 'mr-2'}`} />
          ) : (
            <Sun className={`w-4 h-4 ${sidebarCollapsed ? '' : 'mr-2'}`} />
          )}
          {!sidebarCollapsed && <span>{theme === 'light' ? 'Dark Mode' : 'Light Mode'}</span>}
        </Button>

        {/* Collapse Toggle - Desktop only */}
        <Button
          variant="ghost"
          size="sm"
          onClick={() => setSidebarCollapsed(!sidebarCollapsed)}
          className={`hidden md:flex w-full ${sidebarCollapsed ? 'justify-center' : 'justify-start'}`}
          title={sidebarCollapsed ? 'Expand sidebar' : 'Collapse sidebar'}
        >
          <ChevronRight
            className={`w-4 h-4 transition-transform ${
              sidebarCollapsed ? '' : 'rotate-180 mr-2'
            }`}
          />
          {!sidebarCollapsed && <span>Collapse</span>}
        </Button>
      </div>
    </div>
  );

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
      {/* Mobile sidebar backdrop */}
      {sidebarOpen && (
        <div
          className="fixed inset-0 bg-black bg-opacity-50 z-40 md:hidden"
          onClick={() => setSidebarOpen(false)}
        />
      )}

      {/* Sidebar */}
      <aside
        className={`fixed top-0 left-0 z-50 h-full bg-white dark:bg-gray-800 border-r dark:border-gray-700 transition-all duration-300 ${
          sidebarCollapsed ? 'w-16' : 'w-64'
        } ${sidebarOpen ? 'translate-x-0' : '-translate-x-full'} md:translate-x-0`}
      >
        <SidebarContent />
      </aside>

      {/* Main content */}
      <div
        className={`transition-all duration-300 ${
          sidebarCollapsed ? 'md:pl-16' : 'md:pl-64'
        }`}
      >
        {/* Top bar */}
        <header className="bg-white dark:bg-gray-800 border-b dark:border-gray-700 sticky top-0 z-30">
          <div className="flex items-center justify-between px-4 py-3">
            <div className="flex items-center space-x-4">
              {/* Mobile menu button */}
              <Button
                variant="ghost"
                size="icon"
                className="md:hidden"
                onClick={() => setSidebarOpen(!sidebarOpen)}
              >
                {sidebarOpen ? (
                  <X className="w-5 h-5" />
                ) : (
                  <Menu className="w-5 h-5" />
                )}
              </Button>

              {/* Mobile logo */}
              <div className="flex items-center space-x-3 md:hidden">
                <OktaLogo className="h-7" isDark={theme === 'dark'} />
                <h3 className="text-base font-semibold text-gray-800 dark:text-white">Okta MCP Adapter</h3>
              </div>
            </div>

            {/* User menu */}
            <div className="flex items-center space-x-4">
              {session?.user && (
                <div className="hidden sm:flex items-center text-sm text-gray-700 dark:text-gray-300">
                  <User className="w-4 h-4 mr-2" />
                  <span>{session.user.email || session.user.name}</span>
                </div>
              )}
              <Button variant="ghost" size="sm" onClick={handleLogout}>
                <LogOut className="w-4 h-4 mr-2" />
                <span className="hidden sm:inline">Sign Out</span>
              </Button>
            </div>
          </div>
        </header>

        {/* Page content */}
        <main className="p-4 md:p-6 lg:p-8">
          <div className="max-w-7xl mx-auto">
            {children}
          </div>
        </main>
      </div>

      <Toaster />
    </div>
  );
}
