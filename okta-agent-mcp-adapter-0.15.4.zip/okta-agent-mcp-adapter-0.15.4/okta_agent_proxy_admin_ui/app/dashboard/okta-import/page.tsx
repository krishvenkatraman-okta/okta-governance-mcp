"use client"

import { useEffect, useState, useCallback } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { useToast } from '@/components/ui/use-toast';
import {
  apiClient,
  type OktaAgent,
  type OktaAgentDetail,
  type ImportResult,
  type ConnectionStatus,
} from '@/lib/api-client';
import {
  Download,
  RefreshCw,
  CheckCircle,
  AlertTriangle,
  ShieldAlert,
  WifiOff,
  ChevronDown,
  Cloud,
  Link2,
  Loader2,
} from 'lucide-react';

type ErrorState =
  | { type: 'insufficient_scopes'; scopes: string[] }
  | { type: 'okta_unreachable'; message: string }
  | null;

export default function OktaImportPage() {
  const [agents, setAgents] = useState<OktaAgent[]>([]);
  const [loading, setLoading] = useState(true);
  const [errorState, setErrorState] = useState<ErrorState>(null);
  const [selectedIds, setSelectedIds] = useState<Set<string>>(new Set());
  const [importing, setImporting] = useState<Set<string>>(new Set());
  const [syncing, setSyncing] = useState<Set<string>>(new Set());
  const [syncDropdownOpen, setSyncDropdownOpen] = useState(false);
  const [syncingAll, setSyncingAll] = useState(false);
  const [connSyncStatus, setConnSyncStatus] = useState<ConnectionStatus | null>(null);
  const [connSyncing, setConnSyncing] = useState(false);

  // Import dialog state
  const [importDialogOpen, setImportDialogOpen] = useState(false);
  const [importTarget, setImportTarget] = useState<OktaAgent | null>(null);
  const [importDetail, setImportDetail] = useState<OktaAgentDetail | null>(null);
  const [importDetailLoading, setImportDetailLoading] = useState(false);
  const [importAgentName, setImportAgentName] = useState('');
  const [resourceOverrides, setResourceOverrides] = useState<Record<string, string>>({});

  const { toast } = useToast();

  const loadData = useCallback(async () => {
    try {
      setErrorState(null);
      const data = await apiClient.listOktaAgents();
      if (Array.isArray(data)) {
        setAgents(data);
      } else {
        setAgents([]);
      }
    } catch (error: any) {
      // Don't clear agents on 401 - user will be redirected to login
      // This prevents blank page flash during session expiration
      if (error.status !== 401) {
        setAgents([]);
      }
      if (error.status === 403 && error.code === 'insufficient_scopes') {
        setErrorState({
          type: 'insufficient_scopes',
          scopes: error.required_scopes || [],
        });
      } else if (error.status === 502) {
        setErrorState({ type: 'okta_unreachable', message: error.message });
      } else {
        toast({
          title: "Error",
          description: error.message || "Failed to load agents",
          variant: "destructive",
        });
      }
    } finally {
      setLoading(false);
    }
  }, [toast]);

  useEffect(() => {
    loadData();
  }, [loadData]);

  // Load connection sync status
  useEffect(() => {
    apiClient.getConnectionStatus().then(setConnSyncStatus).catch(() => {});
  }, []);

  // Close sync dropdown on outside click
  useEffect(() => {
    if (!syncDropdownOpen) return;
    const handler = () => setSyncDropdownOpen(false);
    document.addEventListener('click', handler);
    return () => document.removeEventListener('click', handler);
  }, [syncDropdownOpen]);

  const openImportDialog = async (agent: OktaAgent) => {
    setImportTarget(agent);
    setImportAgentName('');
    setResourceOverrides({});
    setImportDetail(null);
    setImportDialogOpen(true);

    // Fetch detail
    setImportDetailLoading(true);
    try {
      const detail = await apiClient.getOktaAgentDetail(agent.okta_agent_id);
      setImportDetail(detail);
    } catch {
      // Non-critical — dialog still usable without detail
    } finally {
      setImportDetailLoading(false);
    }
  };

  const handleImport = async () => {
    if (!importTarget) return;
    const id = importTarget.okta_agent_id;
    setImporting((prev) => new Set(prev).add(id));
    setImportDialogOpen(false);

    try {
      const result = await apiClient.importOktaAgent(id, {
        agent_name: importAgentName || undefined,
        resource_mapping: Object.keys(resourceOverrides).length > 0 ? resourceOverrides : undefined,
      });
      if (result.success) {
        toast({
          title: "Imported",
          description: result.message,
        });
        if (result.warnings.length > 0) {
          toast({
            title: "Warnings",
            description: result.warnings.join('; '),
            variant: "destructive",
          });
        }
      } else {
        toast({
          title: "Import Failed",
          description: result.message,
          variant: "destructive",
        });
      }
      loadData();
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message || "Import failed",
        variant: "destructive",
      });
    } finally {
      setImporting((prev) => {
        const next = new Set(prev);
        next.delete(id);
        return next;
      });
    }
  };

  const handleSync = async (agent: OktaAgent) => {
    const id = agent.okta_agent_id;
    setSyncing((prev) => new Set(prev).add(id));
    try {
      const result = await apiClient.syncOktaAgent(id);
      toast({
        title: result.success ? "Synced" : "Sync Failed",
        description: result.message,
        variant: result.success ? "default" : "destructive",
      });
      loadData();
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message || "Sync failed",
        variant: "destructive",
      });
    } finally {
      setSyncing((prev) => {
        const next = new Set(prev);
        next.delete(id);
        return next;
      });
    }
  };

  const handleBulkImport = async () => {
    const ids = Array.from(selectedIds).filter(
      (id) => !agents.find((a) => a.okta_agent_id === id)?.already_imported
    );
    if (ids.length === 0) return;

    setImporting(new Set(ids));
    try {
      const result = await apiClient.bulkImportOktaAgents(ids);
      toast({
        title: "Bulk Import Complete",
        description: `${result.imported} imported, ${result.failed} failed`,
        variant: result.failed > 0 ? "destructive" : "default",
      });
      setSelectedIds(new Set());
      loadData();
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message || "Bulk import failed",
        variant: "destructive",
      });
    } finally {
      setImporting(new Set());
    }
  };

  const handleSyncAll = async (mode: 'agents' | 'resources' | 'all') => {
    setSyncDropdownOpen(false);

    const labels: Record<string, string> = {
      agents: 'Sync All Agents',
      resources: 'Sync All Resources',
      all: 'Sync Everything',
    };
    const descriptions: Record<string, string> = {
      agents: 'Re-sync enabled status and resource access for all Okta-imported agents.',
      resources: 'Update Managed Connection scopes on all resources from Okta.',
      all: 'Sync all imported agents and resource scopes from Okta.',
    };

    if (!confirm(`${labels[mode]}\n\n${descriptions[mode]}\n\nContinue?`)) return;

    setSyncingAll(true);
    try {
      if (mode === 'agents') {
        const result = await apiClient.syncAllAgents();
        toast({
          title: "Agents Synced",
          description: `${result.synced} synced, ${result.failed} failed`,
          variant: result.failed > 0 ? "destructive" : "default",
        });
      } else if (mode === 'resources') {
        const result = await apiClient.syncAllResources();
        toast({
          title: "Resources Synced",
          description: `${result.resources_updated.length} updated, ${result.unchanged.length} unchanged`,
        });
      } else {
        const result = await apiClient.syncAll();
        toast({
          title: "Full Sync Complete",
          description: `Agents: ${result.agents.synced} synced, ${result.agents.failed} failed. Resources: ${result.resources.resources_updated.length} updated.`,
          variant: result.agents.failed > 0 ? "destructive" : "default",
        });
      }
      loadData();
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message || "Sync failed",
        variant: "destructive",
      });
    } finally {
      setSyncingAll(false);
    }
  };

  const toggleSelect = (id: string) => {
    setSelectedIds((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  };

  const toggleSelectAll = () => {
    if (selectedIds.size === agents.length) {
      setSelectedIds(new Set());
    } else {
      setSelectedIds(new Set(agents.map((a) => a.okta_agent_id)));
    }
  };

  const statusColor = (status: string) => {
    switch (status.toUpperCase()) {
      case 'ACTIVE': return 'bg-green-100 text-green-800';
      case 'STAGED': return 'bg-yellow-100 text-yellow-800';
      case 'DEACTIVATED': return 'bg-red-100 text-red-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  // --- Error states ---
  if (errorState?.type === 'insufficient_scopes') {
    return (
      <div className="space-y-6">
        <h2 className="text-3xl font-bold tracking-tight">Import Agents from Okta</h2>
        <Card className="border-red-200">
          <CardContent className="flex flex-col items-center justify-center py-12">
            <ShieldAlert className="w-12 h-12 text-red-500 mb-4" />
            <p className="text-lg font-medium mb-2">Insufficient Okta Scopes</p>
            <p className="text-muted-foreground text-center max-w-md mb-4">
              Your Okta OAuth token does not have the required scopes for AI Agent management.
              Update your Okta authorization server to grant these scopes:
            </p>
            <div className="flex flex-wrap gap-2 justify-center">
              {errorState.scopes.map((scope) => (
                <span
                  key={scope}
                  className="inline-flex items-center px-3 py-1 rounded-full text-sm font-medium bg-red-100 text-red-800"
                >
                  {scope}
                </span>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  if (errorState?.type === 'okta_unreachable') {
    return (
      <div className="space-y-6">
        <h2 className="text-3xl font-bold tracking-tight">Import Agents from Okta</h2>
        <Card className="border-red-200">
          <CardContent className="flex flex-col items-center justify-center py-12">
            <WifiOff className="w-12 h-12 text-red-500 mb-4" />
            <p className="text-lg font-medium mb-2">Okta Unreachable</p>
            <p className="text-muted-foreground text-center max-w-md mb-4">
              {errorState.message}
            </p>
            <Button onClick={() => { setLoading(true); loadData(); }}>
              <RefreshCw className="w-4 h-4 mr-2" />
              Retry
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  if (loading) {
    return <div className="flex items-center justify-center h-64">Loading...</div>;
  }

  const importableCount = agents.filter((a) => !a.already_imported).length;
  const selectedImportable = Array.from(selectedIds).filter(
    (id) => !agents.find((a) => a.okta_agent_id === id)?.already_imported
  );

  const handleConnectionSync = async () => {
    setConnSyncing(true);
    try {
      const result = await apiClient.syncConnections();
      toast({
        title: "Connection Sync Complete",
        description: `${result.total} resources: +${result.added.length} added, ${result.unresolved.length} unresolved`,
      });
      apiClient.getConnectionStatus().then(setConnSyncStatus).catch(() => {});
    } catch (error: any) {
      toast({ title: "Sync Failed", description: error.message, variant: "destructive" });
    } finally {
      setConnSyncing(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Connection Sync Card */}
      <Card>
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-3">
          <div>
            <CardTitle className="text-lg">Connection Sync</CardTitle>
            <CardDescription>Sync Okta Managed Connections with the Resource Map</CardDescription>
          </div>
          <Button onClick={handleConnectionSync} disabled={connSyncing} size="sm">
            {connSyncing ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <RefreshCw className="w-4 h-4 mr-2" />}
            Sync Connections
          </Button>
        </CardHeader>
        <CardContent>
          {connSyncStatus?.syncer ? (
            <div className="flex items-center gap-4 text-sm">
              {connSyncStatus.syncer.status === 'success' || connSyncStatus.syncer.status === 'local' ? (
                <CheckCircle className="w-4 h-4 text-green-600" />
              ) : connSyncStatus.syncer.status === 'error' ? (
                <AlertTriangle className="w-4 h-4 text-amber-600" />
              ) : (
                <Cloud className="w-4 h-4 text-gray-400" />
              )}
              <span>Status: <strong>{connSyncStatus.syncer.status}</strong></span>
              <span>Resources: <strong>{connSyncStatus.syncer.resources_count}</strong></span>
              {connSyncStatus.syncer.unresolved_count > 0 && (
                <span className="text-amber-600 font-medium">{connSyncStatus.syncer.unresolved_count} unresolved</span>
              )}
              {connSyncStatus.syncer.last_sync_at && (
                <span className="text-muted-foreground">Last: {new Date(connSyncStatus.syncer.last_sync_at).toLocaleString()}</span>
              )}
            </div>
          ) : (
            <p className="text-sm text-muted-foreground">Connection sync status unavailable.</p>
          )}
        </CardContent>
      </Card>

      {/* Header */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h2 className="text-3xl font-bold tracking-tight">Import Agents from Okta</h2>
          <p className="text-muted-foreground">
            Discover and import Okta AI Agent principals into the adapter
          </p>
        </div>
        <div className="flex items-center gap-2">
          <Button variant="outline" onClick={() => { setLoading(true); loadData(); }}>
            <RefreshCw className="w-4 h-4 mr-2" />
            Refresh
          </Button>

          {/* Sync All dropdown */}
          <div className="relative">
            <Button
              variant="outline"
              disabled={syncingAll}
              onClick={(e) => {
                e.stopPropagation();
                setSyncDropdownOpen(!syncDropdownOpen);
              }}
            >
              {syncingAll ? (
                <Loader2 className="w-4 h-4 mr-2 animate-spin" />
              ) : (
                <RefreshCw className="w-4 h-4 mr-2" />
              )}
              Sync All
              <ChevronDown className="w-3 h-3 ml-1" />
            </Button>
            {syncDropdownOpen && (
              <div className="absolute right-0 mt-1 w-52 bg-white dark:bg-gray-800 border dark:border-gray-700 rounded-lg shadow-lg z-50">
                <button
                  className="w-full text-left px-4 py-2 text-sm hover:bg-gray-100 dark:hover:bg-gray-700 rounded-t-lg"
                  onClick={() => handleSyncAll('agents')}
                >
                  Sync All Agents
                </button>
                <button
                  className="w-full text-left px-4 py-2 text-sm hover:bg-gray-100 dark:hover:bg-gray-700"
                  onClick={() => handleSyncAll('resources')}
                >
                  Sync All Resources
                </button>
                <button
                  className="w-full text-left px-4 py-2 text-sm hover:bg-gray-100 dark:hover:bg-gray-700 rounded-b-lg"
                  onClick={() => handleSyncAll('all')}
                >
                  Sync Everything
                </button>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Bulk actions */}
      {selectedIds.size > 0 && (
        <div className="flex items-center gap-3 p-3 bg-blue-50 dark:bg-blue-900/20 rounded-lg">
          <span className="text-sm font-medium">
            {selectedIds.size} selected
          </span>
          {selectedImportable.length > 0 && (
            <Button
              size="sm"
              onClick={handleBulkImport}
              disabled={importing.size > 0}
            >
              <Download className="w-4 h-4 mr-1" />
              Import Selected ({selectedImportable.length})
            </Button>
          )}
          <Button size="sm" variant="outline" onClick={() => setSelectedIds(new Set())}>
            Clear
          </Button>
        </div>
      )}

      {/* Agent grid */}
      {agents.length > 0 && (
        <div className="flex items-center gap-2 mb-2">
          <input
            type="checkbox"
            checked={selectedIds.size === agents.length && agents.length > 0}
            onChange={toggleSelectAll}
            className="rounded"
          />
          <span className="text-sm text-muted-foreground">
            Select all ({agents.length} agents, {importableCount} importable)
          </span>
        </div>
      )}

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
        {agents.map((agent) => {
          const isImporting = importing.has(agent.okta_agent_id);
          const isSyncing = syncing.has(agent.okta_agent_id);

          return (
            <Card key={agent.okta_agent_id} className={agent.already_imported ? 'border-green-200 dark:border-green-800' : ''}>
              <CardHeader>
                <div className="flex justify-between items-start">
                  <div className="flex items-start gap-2">
                    <input
                      type="checkbox"
                      checked={selectedIds.has(agent.okta_agent_id)}
                      onChange={() => toggleSelect(agent.okta_agent_id)}
                      className="rounded mt-1"
                    />
                    <div>
                      <CardTitle className="text-lg flex items-center gap-2">
                        {agent.name}
                        <span className={`inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium ${statusColor(agent.status)}`}>
                          {agent.status}
                        </span>
                      </CardTitle>
                      <CardDescription className="text-xs mt-1 break-all">
                        {agent.okta_agent_id}
                      </CardDescription>
                    </div>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  <div className="flex items-center text-sm text-muted-foreground">
                    <Link2 className="w-3 h-3 mr-1" />
                    {agent.connections_count} connection{agent.connections_count !== 1 ? 's' : ''}
                  </div>
                  {agent.linked_app_client_id && (
                    <div className="text-sm">
                      <span className="font-medium">Client ID:</span>{' '}
                      <span className="text-xs text-muted-foreground break-all">
                        {agent.linked_app_client_id}
                      </span>
                    </div>
                  )}
                  {agent.description && (
                    <p className="text-xs text-muted-foreground line-clamp-2">
                      {agent.description}
                    </p>
                  )}
                </div>

                <div className="mt-4 pt-4 border-t flex gap-2">
                  {agent.already_imported ? (
                    <>
                      <span className="inline-flex items-center px-3 py-1.5 rounded-md text-xs font-medium bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-400">
                        <CheckCircle className="w-3 h-3 mr-1" />
                        Imported
                      </span>
                      <Button
                        variant="outline"
                        size="sm"
                        disabled={isSyncing}
                        onClick={() => handleSync(agent)}
                      >
                        {isSyncing ? (
                          <Loader2 className="w-3 h-3 mr-1 animate-spin" />
                        ) : (
                          <RefreshCw className="w-3 h-3 mr-1" />
                        )}
                        Sync
                      </Button>
                    </>
                  ) : (
                    <Button
                      size="sm"
                      disabled={isImporting}
                      onClick={() => openImportDialog(agent)}
                    >
                      {isImporting ? (
                        <Loader2 className="w-4 h-4 mr-1 animate-spin" />
                      ) : (
                        <Download className="w-4 h-4 mr-1" />
                      )}
                      Import
                    </Button>
                  )}
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>

      {agents.length === 0 && !errorState && (
        <Card>
          <CardContent className="flex flex-col items-center justify-center py-12">
            <Cloud className="w-12 h-12 text-gray-400 mb-4" />
            <p className="text-muted-foreground mb-2">No AI Agents found</p>
            <p className="text-xs text-muted-foreground text-center max-w-md">
              Create AI Agents in your Okta org (Directory &gt; AI Agents) and they will appear here for import.
            </p>
          </CardContent>
        </Card>
      )}

      {/* Import Dialog */}
      <Dialog open={importDialogOpen} onOpenChange={setImportDialogOpen}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Import Agent: {importTarget?.name}</DialogTitle>
            <DialogDescription>
              Review connection mapping and import this agent into the adapter
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="import_agent_name">Agent Name (optional override)</Label>
              <Input
                id="import_agent_name"
                value={importAgentName}
                onChange={(e) => setImportAgentName(e.target.value)}
                placeholder={importTarget?.name ? importTarget.name.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '') : ''}
              />
              <p className="text-xs text-muted-foreground">
                Leave blank to auto-generate from the Okta agent name
              </p>
            </div>

            {importTarget?.linked_app_client_id && (
              <div className="p-3 bg-muted rounded-lg">
                <p className="text-sm font-medium">Linked OIDC App</p>
                <p className="text-xs text-muted-foreground mt-1">
                  Client ID: {importTarget.linked_app_client_id}
                </p>
              </div>
            )}

            {/* Connection mapping */}
            <div>
              <Label>Connection Mapping</Label>
              {importDetailLoading && (
                <div className="flex items-center gap-2 mt-2 text-sm text-muted-foreground">
                  <Loader2 className="w-4 h-4 animate-spin" />
                  Loading connections...
                </div>
              )}
              {importDetail && importDetail.connections.length > 0 ? (
                <div className="mt-2 space-y-2">
                  {importDetail.connections.map((conn, i) => (
                    <div key={i} className="flex items-center gap-2 p-2 bg-muted rounded text-sm">
                      <span className="font-medium truncate flex-1">
                        {conn.connection.name || conn.connection.type || `Connection ${i + 1}`}
                      </span>
                      <span className="text-xs text-muted-foreground">
                        {conn.connection.type}
                      </span>
                      {conn.matched_resource ? (
                        <span className="inline-flex items-center px-2 py-0.5 rounded text-xs font-medium bg-green-100 text-green-800">
                          {conn.matched_resource}
                        </span>
                      ) : (
                        <span className="inline-flex items-center px-2 py-0.5 rounded text-xs font-medium bg-gray-100 text-gray-600">
                          No match
                        </span>
                      )}
                    </div>
                  ))}
                </div>
              ) : !importDetailLoading ? (
                <p className="text-xs text-muted-foreground mt-2">
                  No connections found for this agent
                </p>
              ) : null}
            </div>

            {importTarget && !importTarget.linked_app_client_id && (
              <div className="flex items-start gap-2 p-3 bg-amber-50 dark:bg-amber-900/20 border border-amber-200 dark:border-amber-800 rounded-lg">
                <AlertTriangle className="w-4 h-4 text-amber-600 mt-0.5 flex-shrink-0" />
                <p className="text-sm text-amber-800 dark:text-amber-200">
                  No linked OIDC app found. The Okta agent ID will be used as the client_id.
                </p>
              </div>
            )}
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setImportDialogOpen(false)}>
              Cancel
            </Button>
            <Button onClick={handleImport}>
              <Download className="w-4 h-4 mr-2" />
              Import
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
