"use client"

import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { useToast } from '@/components/ui/use-toast';
import { apiClient, type ForceLogoutInput, type ForceLogoutSummary } from '@/lib/api-client';
import { AlertTriangle, Loader2, LogOut } from 'lucide-react';

type LookupMode = 'email' | 'sub';

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
const SUB_RE = /^00u[a-zA-Z0-9]{6,}$/;

export default function SessionsPage() {
  const [mode, setMode] = useState<LookupMode>('email');
  const [value, setValue] = useState('');
  const [confirmOpen, setConfirmOpen] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [lastSummary, setLastSummary] = useState<ForceLogoutSummary | null>(null);

  const { toast } = useToast();

  const trimmed = value.trim();
  const validEmail = mode === 'email' && EMAIL_RE.test(trimmed);
  const validSub = mode === 'sub' && SUB_RE.test(trimmed);
  const canSubmit = (validEmail || validSub) && !submitting;

  const handleModeChange = (next: LookupMode) => {
    setMode(next);
    setValue('');
  };

  const openConfirm = () => {
    if (!canSubmit) return;
    setConfirmOpen(true);
  };

  const handleConfirm = async () => {
    setConfirmOpen(false);
    setSubmitting(true);
    setLastSummary(null);

    const input: ForceLogoutInput = mode === 'email' ? { email: trimmed } : { sub: trimmed };

    try {
      const summary = await apiClient.forceLogoutUser(input);
      setLastSummary(summary);
      const relayCount = summary.relay_tokens_revoked ?? 0;
      toast({
        title: 'Force-logout complete',
        description:
          `Revoked ${summary.tokens_revoked} Okta tokens, ${relayCount} relay tokens; ` +
          `terminated ${summary.sessions_terminated} path-based sessions.` +
          (summary.sub_marked_revoked
            ? ' User sub added to revocation registry — in-flight JWTs will 401 on next call.'
            : ''),
      });
      setValue('');
    } catch (error: any) {
      if (error.status === 404) {
        toast({
          title: 'User not found',
          description: 'No Okta user found for that email.',
          variant: 'destructive',
        });
      } else if (error.status === 403) {
        toast({
          title: 'Insufficient scope',
          description:
            "Your admin login is missing the 'okta.users.read' scope. Ask the Okta admin to add it to this app.",
          variant: 'destructive',
        });
      } else if (error.status !== 401) {
        toast({
          title: 'Force-logout failed',
          description: error.message || 'Unknown error',
          variant: 'destructive',
        });
      }
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-3xl font-bold tracking-tight">User Sessions</h2>
        <p className="text-muted-foreground">
          Admin-initiated revocation of cached tokens and backend sessions for a specific user.
        </p>
      </div>

      <Card className="max-w-2xl">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <LogOut className="w-5 h-5" />
            Force Logout User
          </CardTitle>
          <CardDescription>
            Revokes all cached tokens and terminates all backend MCP sessions for the target user
            across every adapter pod. Use this to immediately cut off a user after an Okta-side
            suspension or suspected compromise. This action is destructive and audit-logged.
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <Label>Lookup by</Label>
            <div className="flex gap-4">
              <label className="flex items-center gap-2 text-sm cursor-pointer">
                <input
                  type="radio"
                  name="lookup-mode"
                  value="email"
                  checked={mode === 'email'}
                  onChange={() => handleModeChange('email')}
                />
                <span>Email</span>
              </label>
              <label className="flex items-center gap-2 text-sm cursor-pointer">
                <input
                  type="radio"
                  name="lookup-mode"
                  value="sub"
                  checked={mode === 'sub'}
                  onChange={() => handleModeChange('sub')}
                />
                <span>Okta user ID (sub)</span>
              </label>
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="user-value">
              {mode === 'email' ? 'Email address' : 'Okta user ID'}
            </Label>
            <Input
              id="user-value"
              type={mode === 'email' ? 'email' : 'text'}
              value={value}
              onChange={(e) => setValue(e.target.value)}
              placeholder={mode === 'email' ? 'user@example.com' : '00u1abcd2efgh3ijkl'}
              disabled={submitting}
              onKeyDown={(e) => {
                if (e.key === 'Enter' && canSubmit) openConfirm();
              }}
            />
            {value && !canSubmit && !submitting && (
              <p className="text-xs text-amber-600">
                {mode === 'email'
                  ? 'Enter a valid email address.'
                  : 'Okta user IDs start with "00u" followed by alphanumeric characters.'}
              </p>
            )}
          </div>

          <div className="pt-2">
            <Button
              variant="destructive"
              onClick={openConfirm}
              disabled={!canSubmit}
            >
              {submitting ? (
                <Loader2 className="w-4 h-4 mr-2 animate-spin" />
              ) : (
                <LogOut className="w-4 h-4 mr-2" />
              )}
              Force Logout
            </Button>
          </div>
        </CardContent>
      </Card>

      {lastSummary && (
        <Card className="max-w-2xl border-green-200 dark:border-green-800">
          <CardHeader>
            <CardTitle className="text-lg">Last Revocation Result</CardTitle>
            <CardDescription className="break-all">
              Correlation ID: {lastSummary.correlation_id}
            </CardDescription>
          </CardHeader>
          <CardContent>
            <dl className="grid grid-cols-2 gap-x-4 gap-y-2 text-sm">
              <dt className="text-muted-foreground">User sub</dt>
              <dd className="font-mono break-all">{lastSummary.user_sub}</dd>
              <dt className="text-muted-foreground">Okta tokens revoked</dt>
              <dd>{lastSummary.tokens_revoked}</dd>
              <dt className="text-muted-foreground">Downstream cache swept</dt>
              <dd>{lastSummary.cache_swept ? 'yes' : 'no'}</dd>
              <dt
                className="text-muted-foreground"
                title="Relay-tracked CIMD/DCR access tokens purged. This is how VS Code, Cursor and other MCP clients that authenticate via the unified endpoint (POST /) are immediately cut off."
              >
                Relay tokens revoked
              </dt>
              <dd>{lastSummary.relay_tokens_revoked ?? 0}</dd>
              <dt
                className="text-muted-foreground"
                title="The user's Okta sub is now in the revocation registry. Any still-unexpired Okta JWT held by an MCP client returns 401 on the next request."
              >
                Sub marked revoked
              </dt>
              <dd>{lastSummary.sub_marked_revoked ? 'yes' : 'no'}</dd>
              <dt
                className="text-muted-foreground"
                title="Per-user backend MCP sessions terminated. Only populated for traffic through path-based proxy routes (POST /{resource}); unified-endpoint traffic is cut off via the two fields above instead."
              >
                Path-based sessions terminated
              </dt>
              <dd>{lastSummary.sessions_terminated}</dd>
              <dt className="text-muted-foreground">Sessions failed</dt>
              <dd>{lastSummary.sessions_failed}</dd>
            </dl>
            {Object.keys(lastSummary.backends || {}).length > 0 && (
              <div className="mt-4">
                <p className="text-sm font-medium mb-2">Backends</p>
                <ul className="text-sm space-y-1">
                  {Object.entries(lastSummary.backends).map(([name, ok]) => (
                    <li key={name} className="flex items-center gap-2">
                      <span
                        className={`inline-block w-2 h-2 rounded-full ${ok ? 'bg-green-500' : 'bg-red-500'}`}
                      />
                      <span className="font-mono">{name}</span>
                      <span className="text-muted-foreground">{ok ? 'ok' : 'failed'}</span>
                    </li>
                  ))}
                </ul>
              </div>
            )}
          </CardContent>
        </Card>
      )}

      <Dialog open={confirmOpen} onOpenChange={setConfirmOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <AlertTriangle className="w-5 h-5 text-amber-600" />
              Confirm Force Logout
            </DialogTitle>
            <DialogDescription>
              This will revoke all cached tokens and terminate all backend MCP sessions for this
              user across every adapter pod. The user will need to re-authenticate with Okta on
              their next request.
            </DialogDescription>
          </DialogHeader>
          <div className="py-2">
            <p className="text-sm">
              <span className="text-muted-foreground">Target ({mode}):</span>{' '}
              <span className="font-mono break-all">{trimmed}</span>
            </p>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setConfirmOpen(false)}>
              Cancel
            </Button>
            <Button variant="destructive" onClick={handleConfirm}>
              <LogOut className="w-4 h-4 mr-2" />
              Force Logout
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
