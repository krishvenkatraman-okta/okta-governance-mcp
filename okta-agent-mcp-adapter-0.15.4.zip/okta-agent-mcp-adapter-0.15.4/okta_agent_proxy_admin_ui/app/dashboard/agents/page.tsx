"use client"

import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { useToast } from '@/components/ui/use-toast';
import { apiClient, type Agent, type Resource, type OktaAgent, type OktaAgentDetail, type ImportResult } from '@/lib/api-client';
import { Download, RefreshCw, Trash2, Shield, ShieldOff, Cloud, FileText, Loader2, ShieldAlert, AlertTriangle, Settings } from 'lucide-react';
import Link from 'next/link';

// ---------------------------------------------------------------------------
// Status badge component
// ---------------------------------------------------------------------------
function StatusBadge({ status }: { status: string }) {
  const upper = status.toUpperCase();
  const colors =
    upper === 'ACTIVE'
      ? 'bg-green-100 text-green-800'
      : upper === 'STAGED'
      ? 'bg-yellow-100 text-yellow-800'
      : 'bg-red-100 text-red-800';
  return (
    <span className={`inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium ${colors}`}>
      {status}
    </span>
  );
}

// ---------------------------------------------------------------------------
// Import Dialog
// ---------------------------------------------------------------------------
function ImportDialog({
  open,
  onOpenChange,
  onImported,
}: {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onImported: () => void;
}) {
  const [oktaAgents, setOktaAgents] = useState<OktaAgent[]>([]);
  const [resources, setResources] = useState<Resource[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<{ code?: string; message: string } | null>(null);
  const [selected, setSelected] = useState<Set<string>>(new Set());
  const [expandedAgent, setExpandedAgent] = useState<string | null>(null);
  const [agentDetail, setAgentDetail] = useState<OktaAgentDetail | null>(null);
  const [detailLoading, setDetailLoading] = useState(false);
  const [importingId, setImportingId] = useState<string | null>(null);
  const [bulkImporting, setBulkImporting] = useState(false);
  const [nameOverride, setNameOverride] = useState('');
  const [resourceMapping, setResourceMapping] = useState<Record<string, string>>({});
  const [importWarnings, setImportWarnings] = useState<string[]>([]);
  const { toast } = useToast();

  useEffect(() => {
    if (open) {
      loadOktaAgents();
    } else {
      // Reset state when closed
      setOktaAgents([]);
      setError(null);
      setSelected(new Set());
      setExpandedAgent(null);
      setAgentDetail(null);
      setImportWarnings([]);
    }
  }, [open]);

  const loadOktaAgents = async () => {
    setLoading(true);
    setError(null);
    try {
      const [agents, resourcesData] = await Promise.all([
        apiClient.listOktaAgents(),
        apiClient.listResources(),
      ]);
      setOktaAgents(agents);
      setResources(resourcesData);
    } catch (err: any) {
      const code = err.code || '';
      if (code === 'insufficient_scopes') {
        setError({
          code: 'insufficient_scopes',
          message: 'Additional Okta permissions required. Go to your Okta Admin Console \u2192 Applications \u2192 your Admin UI app \u2192 Okta API Scopes tab. Grant: okta.aiAgents.read, okta.aiAgents.manage, okta.apps.read. Then sign out and sign back in.',
        });
      } else if (err.status === 502) {
        setError({
          code: 'okta_unreachable',
          message: 'Cannot reach Okta. Check OKTA_DOMAIN configuration and network connectivity.',
        });
      } else {
        setError({ message: err.message || 'Failed to load agents from Okta' });
      }
    } finally {
      setLoading(false);
    }
  };

  const handleExpandAgent = async (oktaAgentId: string) => {
    if (expandedAgent === oktaAgentId) {
      setExpandedAgent(null);
      setAgentDetail(null);
      setImportWarnings([]);
      return;
    }
    setExpandedAgent(oktaAgentId);
    setDetailLoading(true);
    setImportWarnings([]);
    setResourceMapping({});

    const agent = oktaAgents.find(a => a.okta_agent_id === oktaAgentId);
    setNameOverride(slugify(agent?.name || oktaAgentId));

    try {
      const detail = await apiClient.getOktaAgentDetail(oktaAgentId);
      setAgentDetail(detail);
    } catch (err: any) {
      toast({ title: 'Error', description: err.message, variant: 'destructive' });
      setExpandedAgent(null);
    } finally {
      setDetailLoading(false);
    }
  };

  const handleConfirmImport = async (oktaAgentId: string) => {
    setImportingId(oktaAgentId);
    setImportWarnings([]);
    try {
      const options: { resource_mapping?: Record<string, string>; agent_name?: string } = {};
      if (nameOverride) options.agent_name = nameOverride;
      const mappingEntries = Object.entries(resourceMapping).filter(([, v]) => v);
      if (mappingEntries.length > 0) {
        options.resource_mapping = Object.fromEntries(mappingEntries);
      }
      const result = await apiClient.importOktaAgent(oktaAgentId, options);
      if (result.warnings.length > 0) {
        setImportWarnings(result.warnings);
      }
      toast({
        title: result.success ? 'Imported' : 'Import Failed',
        description: result.message,
        variant: result.success ? 'default' : 'destructive',
      });
      if (result.success) {
        // Refresh both lists
        await loadOktaAgents();
        onImported();
        setExpandedAgent(null);
        setAgentDetail(null);
      }
    } catch (err: any) {
      toast({ title: 'Error', description: err.message, variant: 'destructive' });
    } finally {
      setImportingId(null);
    }
  };

  const handleBulkImport = async () => {
    const ids = Array.from(selected).filter(id => {
      const agent = oktaAgents.find(a => a.okta_agent_id === id);
      return agent && !agent.already_imported;
    });
    if (ids.length === 0) return;

    setBulkImporting(true);
    try {
      const result = await apiClient.bulkImportOktaAgents(ids);
      toast({
        title: 'Bulk Import Complete',
        description: `Imported ${result.imported}. Failed: ${result.failed}.`,
        variant: result.failed > 0 ? 'destructive' : 'default',
      });
      setSelected(new Set());
      await loadOktaAgents();
      onImported();
    } catch (err: any) {
      toast({ title: 'Error', description: err.message, variant: 'destructive' });
    } finally {
      setBulkImporting(false);
    }
  };

  const toggleSelect = (id: string) => {
    const next = new Set(selected);
    if (next.has(id)) next.delete(id);
    else next.add(id);
    setSelected(next);
  };

  const selectableCount = Array.from(selected).filter(id => {
    const agent = oktaAgents.find(a => a.okta_agent_id === id);
    return agent && !agent.already_imported;
  }).length;

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Import Agents from Okta</DialogTitle>
        </DialogHeader>

        {/* Error states */}
        {error && (
          <div className="flex items-start gap-3 p-4 rounded-lg border bg-red-50 border-red-200 text-red-800">
            {error.code === 'insufficient_scopes' ? (
              <ShieldAlert className="w-5 h-5 mt-0.5 flex-shrink-0" />
            ) : (
              <AlertTriangle className="w-5 h-5 mt-0.5 flex-shrink-0" />
            )}
            <p className="text-sm">{error.message}</p>
          </div>
        )}

        {/* Loading */}
        {loading && (
          <div className="flex items-center justify-center py-12">
            <Loader2 className="w-6 h-6 animate-spin text-muted-foreground" />
          </div>
        )}

        {/* Empty state */}
        {!loading && !error && oktaAgents.length === 0 && (
          <div className="text-center py-12 text-muted-foreground">
            No AI Agents found in Okta Universal Directory.
          </div>
        )}

        {/* Agent list */}
        {!loading && !error && oktaAgents.length > 0 && (
          <div className="border rounded-lg overflow-hidden">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b bg-muted/50">
                  <th className="p-3 text-left w-8">
                    <span className="sr-only">Select</span>
                  </th>
                  <th className="p-3 text-left">Status</th>
                  <th className="p-3 text-left">Name</th>
                  <th className="p-3 text-left">Okta Agent ID</th>
                  <th className="p-3 text-left">Linked App</th>
                  <th className="p-3 text-left">Conns</th>
                  <th className="p-3 text-left">Action</th>
                </tr>
              </thead>
              <tbody>
                {oktaAgents.map((agent) => (
                  <AgentRow
                    key={agent.okta_agent_id}
                    agent={agent}
                    resources={resources}
                    isSelected={selected.has(agent.okta_agent_id)}
                    onToggleSelect={() => toggleSelect(agent.okta_agent_id)}
                    isExpanded={expandedAgent === agent.okta_agent_id}
                    onExpand={() => handleExpandAgent(agent.okta_agent_id)}
                    detail={expandedAgent === agent.okta_agent_id ? agentDetail : null}
                    detailLoading={expandedAgent === agent.okta_agent_id && detailLoading}
                    importing={importingId === agent.okta_agent_id}
                    onConfirmImport={() => handleConfirmImport(agent.okta_agent_id)}
                    nameOverride={nameOverride}
                    onNameOverrideChange={setNameOverride}
                    resourceMapping={resourceMapping}
                    onResourceMappingChange={setResourceMapping}
                    importWarnings={expandedAgent === agent.okta_agent_id ? importWarnings : []}
                  />
                ))}
              </tbody>
            </table>
          </div>
        )}

        <DialogFooter className="flex justify-between items-center sm:justify-between">
          <div>
            {selectableCount > 0 && (
              <Button onClick={handleBulkImport} disabled={bulkImporting}>
                {bulkImporting ? (
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                ) : (
                  <Download className="w-4 h-4 mr-2" />
                )}
                Import Selected ({selectableCount})
              </Button>
            )}
          </div>
          <Button variant="outline" onClick={() => onOpenChange(false)}>
            Close
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

// ---------------------------------------------------------------------------
// Agent row in import table
// ---------------------------------------------------------------------------
function AgentRow({
  agent,
  resources,
  isSelected,
  onToggleSelect,
  isExpanded,
  onExpand,
  detail,
  detailLoading,
  importing,
  onConfirmImport,
  nameOverride,
  onNameOverrideChange,
  resourceMapping,
  onResourceMappingChange,
  importWarnings,
}: {
  agent: OktaAgent;
  resources: Resource[];
  isSelected: boolean;
  onToggleSelect: () => void;
  isExpanded: boolean;
  onExpand: () => void;
  detail: OktaAgentDetail | null;
  detailLoading: boolean;
  importing: boolean;
  onConfirmImport: () => void;
  nameOverride: string;
  onNameOverrideChange: (v: string) => void;
  resourceMapping: Record<string, string>;
  onResourceMappingChange: (v: Record<string, string>) => void;
  importWarnings: string[];
}) {
  return (
    <>
      <tr className={`border-b ${isExpanded ? 'bg-muted/30' : 'hover:bg-muted/20'}`}>
        <td className="p-3">
          {!agent.already_imported && (
            <input
              type="checkbox"
              checked={isSelected}
              onChange={onToggleSelect}
              className="rounded"
            />
          )}
        </td>
        <td className="p-3">
          <StatusBadge status={agent.status} />
        </td>
        <td className="p-3 font-medium">{agent.name}</td>
        <td className="p-3">
          <code className="text-xs text-muted-foreground">{agent.okta_agent_id}</code>
        </td>
        <td className="p-3">
          {agent.linked_app_client_id ? (
            <code className="text-xs">{agent.linked_app_client_id}</code>
          ) : (
            <span className="text-xs text-amber-600">No linked app &#x26A0;</span>
          )}
        </td>
        <td className="p-3 text-center">{agent.connections_count}</td>
        <td className="p-3">
          {agent.already_imported ? (
            <span className="text-xs text-green-600 font-medium">Imported &#x2713;</span>
          ) : (
            <Button size="sm" variant="outline" onClick={onExpand}>
              {isExpanded ? 'Cancel' : 'Import'}
            </Button>
          )}
        </td>
      </tr>
      {isExpanded && (
        <tr>
          <td colSpan={7} className="p-4 bg-muted/10 border-b">
            {detailLoading ? (
              <div className="flex items-center justify-center py-6">
                <Loader2 className="w-5 h-5 animate-spin text-muted-foreground" />
              </div>
            ) : detail ? (
              <div className="space-y-4">
                {/* Agent name override */}
                <div className="space-y-1">
                  <Label htmlFor="name-override" className="text-xs font-medium">Agent Name</Label>
                  <Input
                    id="name-override"
                    value={nameOverride}
                    onChange={(e) => onNameOverrideChange(e.target.value)}
                    className="max-w-sm h-8 text-sm"
                    placeholder="agent-name-slug"
                  />
                </div>

                {/* Connection mapping */}
                {detail.connections.length > 0 && (
                  <div className="space-y-2">
                    <p className="text-xs font-medium">Connection Mapping</p>
                    <div className="border rounded overflow-hidden">
                      <table className="w-full text-xs">
                        <thead>
                          <tr className="bg-muted/50 border-b">
                            <th className="p-2 text-left">Type</th>
                            <th className="p-2 text-left">Auth Server</th>
                            <th className="p-2 text-left">Matched Resource</th>
                            <th className="p-2 text-left">Override</th>
                          </tr>
                        </thead>
                        <tbody>
                          {detail.connections.map((conn, idx) => {
                            const connData = conn.connection || {};
                            const connType = connData.type || connData.connectionType || 'unknown';
                            const props = connData.properties || connData;
                            const authServerId = props.authorizationServerId || props.authorization_server_id || '';
                            const connName = connData.name || connData.id || `conn-${idx}`;
                            return (
                              <tr key={idx} className="border-b last:border-0">
                                <td className="p-2">
                                  <code>{connType}</code>
                                </td>
                                <td className="p-2">
                                  <code className="text-muted-foreground">{authServerId || '-'}</code>
                                </td>
                                <td className="p-2">
                                  {conn.matched_resource ? (
                                    <span className="text-green-600">{conn.matched_resource}</span>
                                  ) : (
                                    <span className="text-red-500">No match</span>
                                  )}
                                </td>
                                <td className="p-2">
                                  <select
                                    value={resourceMapping[connName] || ''}
                                    onChange={(e) => {
                                      onResourceMappingChange({
                                        ...resourceMapping,
                                        [connName]: e.target.value,
                                      });
                                    }}
                                    className="h-7 text-xs border rounded px-1 w-full max-w-[180px]"
                                  >
                                    <option value="">Auto-match</option>
                                    {resources.map((b) => (
                                      <option key={b.name} value={b.name}>{b.name}</option>
                                    ))}
                                  </select>
                                </td>
                              </tr>
                            );
                          })}
                        </tbody>
                      </table>
                    </div>
                  </div>
                )}

                {/* Linked app info */}
                {detail.linked_app && (
                  <p className="text-xs text-muted-foreground">
                    Linked app: {detail.linked_app.label || detail.linked_app.app_id}
                    {detail.linked_app.client_id && ` (${detail.linked_app.client_id})`}
                  </p>
                )}

                {/* Warnings */}
                {importWarnings.length > 0 && (
                  <div className="p-3 rounded bg-amber-50 border border-amber-200 text-amber-800 text-xs space-y-1">
                    {importWarnings.map((w, i) => (
                      <p key={i}>{w}</p>
                    ))}
                  </div>
                )}

                {/* Confirm button */}
                <Button size="sm" onClick={onConfirmImport} disabled={importing}>
                  {importing ? (
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  ) : (
                    <Download className="w-4 h-4 mr-2" />
                  )}
                  Confirm Import
                </Button>
              </div>
            ) : null}
          </td>
        </tr>
      )}
    </>
  );
}

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------
function slugify(name: string): string {
  return name.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '') || 'agent';
}

// ---------------------------------------------------------------------------
// Main page
// ---------------------------------------------------------------------------
export default function AgentsPage() {
  const [agents, setAgents] = useState<Agent[]>([]);
  const [loading, setLoading] = useState(true);
  const [importDialogOpen, setImportDialogOpen] = useState(false);
  const [syncingAgent, setSyncingAgent] = useState<string | null>(null);
  const [syncingAll, setSyncingAll] = useState(false);
  const router = useRouter();
  const { toast } = useToast();

  useEffect(() => {
    loadAgents();
  }, []);

  const loadAgents = async () => {
    try {
      const agentsData = await apiClient.listAgents();
      setAgents(Array.isArray(agentsData) ? agentsData : []);
    } catch (error: any) {
      console.error('Load agents error:', error);
      // Don't clear agents on 401 - user will be redirected to login
      // This prevents blank page flash during session expiration
      if (error.status !== 401) {
        setAgents([]);
      }
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to load agents",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const handleDelete = async (agentId: string) => {
    if (!confirm('Are you sure you want to delete this agent?')) return;
    try {
      await apiClient.deleteAgent(agentId);
      toast({ title: "Success", description: "Agent deleted successfully" });
      loadAgents();
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to delete agent",
        variant: "destructive",
      });
    }
  };

  const handleSyncAgent = async (agent: Agent) => {
    if (!agent.okta_ai_agent_id) return;
    setSyncingAgent(agent.agent_id);
    try {
      const result = await apiClient.syncOktaAgent(agent.okta_ai_agent_id);
      toast({
        title: result.success ? "Synced" : "Sync Failed",
        description: result.message,
        variant: result.success ? "default" : "destructive",
      });
      loadAgents();
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message || "Sync failed",
        variant: "destructive",
      });
    } finally {
      setSyncingAgent(null);
    }
  };

  const handleSyncAll = async () => {
    setSyncingAll(true);
    try {
      const result = await apiClient.syncAllAgents();
      if (result.synced === 0 && result.failed === 0) {
        toast({ title: "Sync", description: "All agents up to date." });
      } else {
        const connSync = result.connection_sync;
        const desc = connSync
          ? `${result.synced} agents synced, ${connSync.resources_resolved} resources resolved`
          : `Synced ${result.synced} agents. ${result.failed} failures.`;
        toast({
          title: "Sync Complete",
          description: desc,
          variant: result.failed > 0 ? "destructive" : "default",
        });
      }
      loadAgents();
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message || "Sync failed",
        variant: "destructive",
      });
    } finally {
      setSyncingAll(false);
    }
  };

  const hasOktaImported = agents.some((a) => a.registration_source === 'okta-import');

  if (loading) {
    return <div className="flex items-center justify-center h-64">Loading...</div>;
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-3xl font-bold tracking-tight">Agents</h2>
          <p className="text-muted-foreground">
            Manage MCP client agents and their access permissions
          </p>
        </div>
        <div className="flex items-center gap-2">
          {hasOktaImported && (
            <Button variant="outline" onClick={handleSyncAll} disabled={syncingAll}>
              {syncingAll ? (
                <Loader2 className="w-4 h-4 mr-2 animate-spin" />
              ) : (
                <RefreshCw className="w-4 h-4 mr-2" />
              )}
              Sync All
            </Button>
          )}
          <Button onClick={() => setImportDialogOpen(true)}>
            <Download className="w-4 h-4 mr-2" />
            Import from Okta
          </Button>
        </div>
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
        {agents.map((agent) => (
          <Card key={agent.agent_id}>
            <CardHeader>
              <div className="flex justify-between items-start">
                <div className="flex items-center space-x-2">
                  {agent.enabled ? (
                    <Shield className="w-5 h-5 text-green-600" />
                  ) : (
                    <ShieldOff className="w-5 h-5 text-gray-400" />
                  )}
                  <div>
                    <CardTitle className="text-lg flex items-center gap-1.5">
                      <Link href={`/dashboard/agents/${agent.agent_id}`} className="hover:underline">
                        {agent.agent_id}
                      </Link>
                      {agent.registration_source === 'okta-import' && (
                        <span title="Imported from Okta">
                          <Cloud className="w-4 h-4 text-blue-500" />
                        </span>
                      )}
                    </CardTitle>
                    {agent.registration_source === 'okta-import' && agent.okta_ai_agent_id && (
                      <p className="text-xs text-muted-foreground font-mono mt-0.5">
                        {agent.okta_ai_agent_id}
                      </p>
                    )}
                    {agent.registration_source && agent.registration_source !== 'okta-import' && (
                      <p className="text-xs text-muted-foreground mt-0.5">Manual</p>
                    )}
                  </div>
                </div>
                <div className="flex space-x-1">
                  {agent.registration_source === 'okta-import' && agent.okta_ai_agent_id && (
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={() => handleSyncAgent(agent)}
                      disabled={syncingAgent === agent.agent_id}
                      title="Sync from Okta"
                    >
                      {syncingAgent === agent.agent_id ? (
                        <Loader2 className="w-4 h-4 animate-spin" />
                      ) : (
                        <RefreshCw className="w-4 h-4" />
                      )}
                    </Button>
                  )}
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={() => router.push(`/dashboard/agents/${agent.agent_id}`)}
                    title="View Details"
                  >
                    <Settings className="w-4 h-4" />
                  </Button>
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={() => handleDelete(agent.agent_id)}
                  >
                    <Trash2 className="w-4 h-4" />
                  </Button>
                </div>
              </div>
              <CardDescription>
                Client ID: {agent.client_id}
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                {agent.principal_id && (
                  <div>
                    <p className="text-sm font-medium">Principal ID:</p>
                    <p className="text-xs text-muted-foreground break-all mt-1">
                      {agent.principal_id}
                    </p>
                  </div>
                )}
                {agent.cimd_client_id_url && (
                  <div>
                    <p className="text-sm font-medium">CIMD Client ID:</p>
                    <p className="text-xs text-muted-foreground break-all mt-1">
                      {agent.cimd_client_id_url}
                    </p>
                  </div>
                )}
                <div className="flex items-center text-sm">
                  <span className={`inline-block w-2 h-2 rounded-full mr-2 ${
                    agent.enabled ? 'bg-green-500' : 'bg-gray-400'
                  }`} />
                  {agent.enabled ? 'Enabled' : 'Disabled'}
                </div>
              </div>
              <div className="mt-4 pt-4 border-t">
                <Link href={`/dashboard/agents/${agent.agent_id}/audit`}>
                  <Button variant="outline" size="sm" className="w-full">
                    <FileText className="w-4 h-4 mr-2" />
                    View Audit Log
                  </Button>
                </Link>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {agents.length === 0 && (
        <Card>
          <CardContent className="flex flex-col items-center justify-center py-12">
            <Shield className="w-12 h-12 text-gray-400 mb-4" />
            <p className="text-muted-foreground mb-4">No agents configured</p>
            <Button onClick={() => setImportDialogOpen(true)}>
              <Download className="w-4 h-4 mr-2" />
              Import from Okta
            </Button>
          </CardContent>
        </Card>
      )}

      <ImportDialog
        open={importDialogOpen}
        onOpenChange={setImportDialogOpen}
        onImported={loadAgents}
      />
    </div>
  );
}
