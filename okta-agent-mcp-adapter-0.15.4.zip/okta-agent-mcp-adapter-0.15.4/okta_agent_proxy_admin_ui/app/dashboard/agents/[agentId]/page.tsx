"use client"

import { useEffect, useState, useCallback } from 'react';
import { useParams, useRouter } from 'next/navigation';
import Link from 'next/link';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { useToast } from '@/components/ui/use-toast';
import {
  apiClient,
  type Agent,
  type AgentDetail,
  type AgentConnection,
  type AgentToolsResponse,
  type AuditLogEntry,
  type CredentialStatus,
} from '@/lib/api-client';
import {
  AlertTriangle,
  ArrowLeft,
  ArrowRight,
  Cloud,
  Copy,
  Edit,
  ExternalLink,
  Globe,
  Check,
  ChevronDown,
  ChevronRight,
  Key,
  Loader2,
  RefreshCw,
  Server,
  Shield,
  ShieldOff,
  Trash2,
  Wrench,
  X,
} from 'lucide-react';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from '@/components/ui/dialog';

// ---------------------------------------------------------------------------
// Tab definitions
// ---------------------------------------------------------------------------
const TABS = [
  { id: 'connections', label: 'Connections & Resources' },
  { id: 'configuration', label: 'Configuration' },
  { id: 'tools', label: 'Tools' },
  { id: 'audit', label: 'Audit Log' },
] as const;

type TabId = (typeof TABS)[number]['id'];

// ---------------------------------------------------------------------------
// Main agent detail page
// ---------------------------------------------------------------------------
export default function AgentDetailPage() {
  const params = useParams();
  const router = useRouter();
  const agentId = params.agentId as string;
  const { toast } = useToast();

  const [activeTab, setActiveTab] = useState<TabId>('connections');
  const [loading, setLoading] = useState(true);
  const [agent, setAgent] = useState<Agent | null>(null);
  const [detail, setDetail] = useState<AgentDetail | null>(null);
  const [syncing, setSyncing] = useState(false);

  const loadData = useCallback(async () => {
    setLoading(true);
    try {
      const [agentData, detailData] = await Promise.all([
        apiClient.getAgent(agentId),
        apiClient.getAgentDetail(agentId).catch(() => null),
      ]);
      setAgent(agentData);
      setDetail(detailData);
    } catch (err: any) {
      toast({ title: 'Error', description: err.message, variant: 'destructive' });
    } finally {
      setLoading(false);
    }
  }, [agentId, toast]);

  useEffect(() => {
    if (agentId) loadData();
  }, [agentId, loadData]);

  const handleSync = async () => {
    if (!agent?.okta_ai_agent_id) return;
    setSyncing(true);
    try {
      const result = await apiClient.syncOktaAgent(agent.okta_ai_agent_id);
      toast({
        title: result.success ? 'Synced' : 'Sync Failed',
        description: result.message,
        variant: result.success ? 'default' : 'destructive',
      });
      await loadData();
    } catch (err: any) {
      toast({ title: 'Error', description: err.message, variant: 'destructive' });
    } finally {
      setSyncing(false);
    }
  };

  const handleDelete = async () => {
    if (!confirm(`Delete agent "${agentId}"? This cannot be undone.`)) return;
    try {
      await apiClient.deleteAgent(agentId);
      toast({ title: 'Deleted', description: `Agent ${agentId} deleted` });
      router.push('/dashboard/agents');
    } catch (err: any) {
      toast({ title: 'Error', description: err.message, variant: 'destructive' });
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <Loader2 className="w-6 h-6 animate-spin text-muted-foreground" />
      </div>
    );
  }

  if (!agent) {
    return (
      <div className="space-y-4">
        <Button variant="ghost" size="sm" onClick={() => router.push('/dashboard/agents')}>
          <ArrowLeft className="w-4 h-4 mr-2" /> Back to Agents
        </Button>
        <p className="text-muted-foreground">Agent not found.</p>
      </div>
    );
  }

  const isOktaImported = agent.registration_source === 'okta-import';
  const stats = detail?.stats;

  return (
    <div className="space-y-6">
      {/* Breadcrumb */}
      <div className="flex items-center gap-2 text-sm text-muted-foreground">
        <Link href="/dashboard/agents" className="hover:underline">Agents</Link>
        <span>/</span>
        <span className="text-foreground font-medium">{agent.agent_id}</span>
      </div>

      {/* Header */}
      <div className="flex items-start justify-between">
        <div>
          <div className="flex items-center gap-2">
            {agent.enabled ? (
              <Shield className="w-6 h-6 text-green-600" />
            ) : (
              <ShieldOff className="w-6 h-6 text-gray-400" />
            )}
            <h1 className="text-3xl font-bold tracking-tight">{agent.agent_id}</h1>
            {isOktaImported && <span title="Imported from Okta"><Cloud className="w-5 h-5 text-blue-500" /></span>}
          </div>
          <p className="text-muted-foreground mt-1">
            {isOktaImported ? (
              <>
                Okta AI Agent &middot; Imported
                {stats ? ` \u00b7 ${stats.total_connections} connection${stats.total_connections !== 1 ? 's' : ''}` : ''}
                {agent.okta_ai_agent_id && (
                  <> &middot; <code className="text-xs">{agent.okta_ai_agent_id}</code></>
                )}
              </>
            ) : (
              <>Manual agent &middot; <code className="text-xs">{agent.client_id}</code></>
            )}
          </p>
        </div>

        <div className="flex items-center gap-2">
          {isOktaImported && agent.okta_ai_agent_id && (
            <Button variant="outline" size="sm" onClick={handleSync} disabled={syncing}>
              {syncing ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <RefreshCw className="w-4 h-4 mr-2" />}
              Sync from Okta
            </Button>
          )}
          <Button variant="outline" size="sm" onClick={() => setActiveTab('configuration')}>
            Configure
          </Button>
          <Button variant="destructive" size="sm" onClick={handleDelete}>
            <Trash2 className="w-4 h-4 mr-2" /> Delete
          </Button>
        </div>
      </div>

      {/* Stats row */}
      {stats && (
        <div className="grid gap-4 grid-cols-2 md:grid-cols-4">
          <StatCard label="Total Connections" value={stats.total_connections} />
          <StatCard label="Linked" value={stats.fully_linked_count} color="green" />
          <StatCard label="Needs Resource" value={stats.unlinked_count} color={stats.unlinked_count > 0 ? 'amber' : undefined} />
          <StatCard label="Total Resources" value={stats.total_resources} />
        </div>
      )}

      {/* Tabs */}
      <div className="border-b">
        <nav className="flex gap-6">
          {TABS.map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`pb-3 text-sm font-medium transition-colors border-b-2 ${
                activeTab === tab.id
                  ? 'border-primary text-primary'
                  : 'border-transparent text-muted-foreground hover:text-foreground'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </nav>
      </div>

      {/* Tab content */}
      {activeTab === 'connections' && (
        <ConnectionsTab detail={detail} agentId={agentId} onRefresh={loadData} />
      )}
      {activeTab === 'configuration' && (
        <ConfigurationTab agent={agent} onSaved={loadData} />
      )}
      {activeTab === 'tools' && (
        <ToolsTab detail={detail} agentId={agentId} />
      )}
      {activeTab === 'audit' && (
        <AuditTab agentId={agentId} />
      )}
    </div>
  );
}

// ---------------------------------------------------------------------------
// Stat card
// ---------------------------------------------------------------------------
function StatCard({ label, value, color }: { label: string; value: number; color?: string }) {
  const colorCls =
    color === 'green' ? 'text-green-600' :
    color === 'amber' ? 'text-amber-600' :
    '';
  return (
    <Card>
      <CardContent className="pt-6">
        <p className="text-sm text-muted-foreground">{label}</p>
        <p className={`text-2xl font-bold ${colorCls}`}>{value}</p>
      </CardContent>
    </Card>
  );
}

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------
function slugify(name: string): string {
  return name.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '') || 'resource';
}

const SLUG_PATTERN = /^[a-z]([a-z0-9-]*[a-z0-9])?$/;

function derivedAuthMethod(type: string): string {
  switch (type) {
    case 'IDENTITY_ASSERTION_CUSTOM_AS': return 'okta-cross-app';
    case 'STS_VAULT_SECRET':
    case 'SECRET': return 'pre-shared-key';
    case 'STS_SERVICE_ACCOUNT':
    case 'SERVICE_ACCOUNT': return 'service-account';
    default: return 'unknown';
  }
}

// ---------------------------------------------------------------------------
// Connection type badge helpers
// ---------------------------------------------------------------------------
type ConnectionFilter = 'all' | 'active' | 'unlinked' | 'inactive' | 'XAA' | 'SECRET' | 'SERVICE_ACCOUNT';

function connTypeBadge(type: string) {
  switch (type) {
    case 'IDENTITY_ASSERTION_CUSTOM_AS':
      return { label: 'XAA', cls: 'bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200' };
    case 'STS_VAULT_SECRET':
    case 'SECRET':
      return { label: 'Secret / PSK', cls: 'bg-amber-100 text-amber-800 dark:bg-amber-900 dark:text-amber-200' };
    case 'STS_SERVICE_ACCOUNT':
    case 'SERVICE_ACCOUNT':
      return { label: 'Service acct', cls: 'bg-gray-100 text-gray-800 dark:bg-gray-700 dark:text-gray-200' };
    default:
      return { label: type, cls: 'bg-gray-100 text-gray-800' };
  }
}

function protocolBadge(protocol: string) {
  return protocol === 'a2a'
    ? 'bg-violet-100 text-violet-800 dark:bg-violet-900 dark:text-violet-200'
    : 'bg-emerald-100 text-emerald-800 dark:bg-emerald-900 dark:text-emerald-200';
}

// ---------------------------------------------------------------------------
// Connections & Resources Tab
// ---------------------------------------------------------------------------
function ConnectionsTab({
  detail,
  agentId,
  onRefresh,
}: {
  detail: AgentDetail | null;
  agentId: string;
  onRefresh: () => void;
}) {
  const [filter, setFilter] = useState<ConnectionFilter>('all');
  const [editTarget, setEditTarget] = useState<{ conn: AgentConnection; resourceName: string } | null>(null);

  // --- Empty states ---
  if (!detail) {
    return (
      <div className="flex flex-col items-center justify-center py-16 text-center">
        <Server className="w-10 h-10 mb-3 text-muted-foreground/40" />
        <p className="font-medium text-muted-foreground">No connection data available</p>
        <p className="text-sm text-muted-foreground mt-1 max-w-md">
          This agent was created manually and does not have Okta Managed
          Connections. To use Okta-native resource management, import the
          agent from Okta via the Okta Import page.
        </p>
      </div>
    );
  }

  if (detail.connections.length === 0) {
    const agentName = detail.agent.agent_id;
    return (
      <div className="flex flex-col items-center justify-center py-16 text-center">
        <Server className="w-10 h-10 mb-3 text-muted-foreground/40" />
        <p className="font-medium text-muted-foreground">No Managed Connections found</p>
        <p className="text-sm text-muted-foreground mt-1 max-w-lg">
          Add connections in the Okta Admin Console under Directory &rarr; AI
          Agents &rarr; <span className="font-medium">{agentName}</span> &rarr;
          Managed Connections, then click &ldquo;Sync from Okta&rdquo;.
        </p>
      </div>
    );
  }

  // --- Filtering ---
  const connections = detail.connections;
  const hasResource = (c: AgentConnection) =>
    !!(c.resource && c.resource.enabled !== false && c.resource.url);
  const activeCount = connections.filter((c) => c.status === 'ACTIVE').length;
  const unlinkedCount = connections.filter((c) => !hasResource(c) && c.status === 'ACTIVE').length;
  const inactiveCount = connections.filter((c) => c.status !== 'ACTIVE').length;
  const xaaCount = connections.filter((c) => c.connection_type === 'IDENTITY_ASSERTION_CUSTOM_AS').length;
  const secretCount = connections.filter((c) => c.connection_type === 'STS_VAULT_SECRET' || c.connection_type === 'SECRET').length;
  const saCount = connections.filter((c) => c.connection_type === 'STS_SERVICE_ACCOUNT' || c.connection_type === 'SERVICE_ACCOUNT').length;

  const filtered = connections.filter((c) => {
    switch (filter) {
      case 'active': return c.status === 'ACTIVE';
      case 'unlinked': return !hasResource(c) && c.status === 'ACTIVE';
      case 'inactive': return c.status !== 'ACTIVE';
      case 'XAA': return c.connection_type === 'IDENTITY_ASSERTION_CUSTOM_AS';
      case 'SECRET': return c.connection_type === 'STS_VAULT_SECRET' || c.connection_type === 'SECRET';
      case 'SERVICE_ACCOUNT': return c.connection_type === 'STS_SERVICE_ACCOUNT' || c.connection_type === 'SERVICE_ACCOUNT';
      default: return true;
    }
  });

  // Sort: active first, inactive last
  const sorted = [...filtered].sort((a, b) => {
    if (a.status === 'ACTIVE' && b.status !== 'ACTIVE') return -1;
    if (a.status !== 'ACTIVE' && b.status === 'ACTIVE') return 1;
    return 0;
  });

  const filters: { id: ConnectionFilter; label: string; count: number }[] = [
    { id: 'all', label: 'All', count: connections.length },
    { id: 'active', label: 'Active', count: activeCount },
    ...(unlinkedCount > 0 ? [{ id: 'unlinked' as const, label: 'Needs resource', count: unlinkedCount }] : []),
    ...(inactiveCount > 0 ? [{ id: 'inactive' as const, label: 'Inactive', count: inactiveCount }] : []),
    ...(xaaCount > 0 ? [{ id: 'XAA' as const, label: 'XAA', count: xaaCount }] : []),
    ...(secretCount > 0 ? [{ id: 'SECRET' as const, label: 'Secret', count: secretCount }] : []),
    ...(saCount > 0 ? [{ id: 'SERVICE_ACCOUNT' as const, label: 'Service acct', count: saCount }] : []),
  ];

  return (
    <div className="space-y-4">
      {/* Filter bar */}
      <div className="flex flex-wrap gap-2">
        {filters.map((f) => (
          <button
            key={f.id}
            onClick={() => setFilter(f.id)}
            className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-medium transition-colors ${
              filter === f.id
                ? 'bg-primary text-primary-foreground'
                : 'bg-muted text-muted-foreground hover:bg-muted/80'
            }`}
          >
            {f.label}
            <span className={`tabular-nums ${filter === f.id ? 'text-primary-foreground/80' : 'text-muted-foreground/60'}`}>
              {f.count}
            </span>
          </button>
        ))}
      </div>

      {/* Connection cards */}
      {sorted.map((conn) => {
        const resource = conn.resource;
        const hasEnabled = !!(resource && resource.enabled !== false && resource.url);
        const isActive = conn.status === 'ACTIVE';
        const isInactive = !isActive;
        const typeBadge = connTypeBadge(conn.connection_type);

        return (
          <Card
            key={conn.connection_id}
            className={`transition-colors ${
              isInactive
                ? 'opacity-60 bg-muted/30'
                : !hasEnabled
                  ? 'border-l-[3px] border-l-amber-400 bg-amber-50/40 dark:bg-amber-950/20'
                  : 'hover:bg-muted/20'
            }`}
          >
            <CardContent className="p-5 space-y-4">
              {/* --- Connection header --- */}
              <div className="flex items-start justify-between gap-4">
                <div className="space-y-1.5 min-w-0 flex-1">
                  <div className="flex items-center gap-2">
                    <p className="text-[10px] font-semibold tracking-wider uppercase text-muted-foreground">
                      Okta managed connection
                    </p>
                    {!hasEnabled && isActive && (
                      <span className="text-[10px] font-semibold tracking-wider uppercase text-amber-600 dark:text-amber-400">
                        &mdash; needs URL &amp; enable
                      </span>
                    )}
                    {isInactive && (
                      <span className="inline-flex items-center px-2 py-0.5 rounded-full text-[10px] font-medium bg-gray-200 text-gray-600 dark:bg-gray-700 dark:text-gray-300">
                        INACTIVE
                      </span>
                    )}
                  </div>
                  <p className="font-semibold text-sm leading-tight">{conn.display_name}</p>
                  <p className="text-xs font-mono text-muted-foreground break-all">
                    {conn.resource_id || conn.connection_id}
                  </p>

                  <div className="flex flex-wrap gap-1.5 pt-1">
                    <span className={`inline-flex items-center px-2 py-0.5 rounded-full text-[10px] font-medium ${typeBadge.cls}`}>
                      {typeBadge.label}
                    </span>
                    {conn.scope_condition && (
                      <span className="inline-flex items-center px-2 py-0.5 rounded-full text-[10px] font-medium bg-indigo-100 text-indigo-800 dark:bg-indigo-900 dark:text-indigo-200">
                        {conn.scope_condition}
                      </span>
                    )}
                  </div>

                  {conn.scopes.length > 0 && (
                    <div className="flex flex-wrap gap-1 pt-1">
                      {conn.scopes.map((scope) => (
                        <span
                          key={scope}
                          className="inline-flex items-center px-1.5 py-0.5 rounded text-[10px] bg-gray-100 text-gray-600 dark:bg-gray-800 dark:text-gray-300 font-mono"
                        >
                          {scope}
                        </span>
                      ))}
                    </div>
                  )}
                </div>
              </div>

              {isInactive && (
                <div className="p-3 rounded-lg bg-gray-100 dark:bg-gray-800/50 border text-sm text-muted-foreground">
                  This connection is inactive in Okta. Activate it in the Okta Admin Console to enable routing.
                </div>
              )}

              {/* --- Resource row (one per connection) --- */}
              {isActive && resource && (
                <div className="rounded-lg bg-muted/60 border p-3 space-y-2">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2 min-w-0">
                      <Server className={`w-4 h-4 flex-shrink-0 ${hasEnabled ? 'text-green-600' : 'text-amber-500'}`} />
                      <p className="font-semibold text-sm truncate">{resource.name}</p>
                      {resource.enabled === false && (
                        <span className="inline-flex items-center px-1.5 py-0.5 rounded text-[10px] font-medium bg-gray-200 text-gray-700 dark:bg-gray-700 dark:text-gray-300">
                          DISABLED
                        </span>
                      )}
                    </div>
                    <div className="flex gap-1">
                      <Button
                        variant="ghost"
                        size="sm"
                        className="h-7 text-xs px-2"
                        onClick={() => setEditTarget({ conn, resourceName: resource.name })}
                      >
                        <Edit className="w-3 h-3 mr-1" /> Edit
                      </Button>
                      {conn.connection_type === 'STS_ACCESS_TOKEN' && (
                        <CopyPreConsentResourceButton agentId={agentId} resourceName={resource.name} />
                      )}
                    </div>
                  </div>
                  <div className="flex items-center gap-1 text-xs text-muted-foreground">
                    <Globe className="w-3 h-3 flex-shrink-0" />
                    <span className="truncate font-mono">
                      {resource.url || <span className="italic">URL not set — click Edit</span>}
                    </span>
                  </div>
                  {resource.auth_method && (
                    <p className="text-xs text-muted-foreground">
                      Auth: <code className="font-mono">{resource.auth_method}</code>
                    </p>
                  )}
                </div>
              )}
            </CardContent>
          </Card>
        );
      })}

      {sorted.length === 0 && (
        <div className="text-center py-8 text-muted-foreground text-sm">
          No connections match the selected filter.
        </div>
      )}

      {/* Edit resource dialog */}
      {editTarget && (
        <EditConnectionResourceDialog
          resourceName={editTarget.resourceName}
          onClose={() => setEditTarget(null)}
          onSaved={() => { setEditTarget(null); onRefresh(); }}
        />
      )}
    </div>
  );
}

// ---------------------------------------------------------------------------
// Edit Resource Dialog (admin-editable fields only)
// ---------------------------------------------------------------------------
function EditConnectionResourceDialog({
  resourceName,
  onClose,
  onSaved,
}: {
  resourceName: string;
  onClose: () => void;
  onSaved: () => void;
}) {
  const { toast } = useToast();
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [form, setForm] = useState({
    name: resourceName,
    url: '',
    type: 'mcp',
    description: '',
    enabled: false,
  });

  useEffect(() => {
    (async () => {
      try {
        const r = await apiClient.getResource(resourceName);
        setForm({
          name: r.name,
          url: r.url || r.mcp_url || '',
          type: r.type || r.protocol || 'mcp',
          description: r.description || '',
          enabled: r.enabled !== false,
        });
      } catch (e: any) {
        toast({ title: 'Error', description: e.message || 'Failed to load resource', variant: 'destructive' });
      } finally {
        setLoading(false);
      }
    })();
  }, [resourceName, toast]);

  const handleSave = async () => {
    if (!form.url) {
      toast({ title: 'Validation Error', description: 'URL is required', variant: 'destructive' });
      return;
    }
    setSaving(true);
    try {
      await apiClient.updateResource(resourceName, {
        name: form.name,
        url: form.url,
        type: form.type,
        description: form.description,
        enabled: form.enabled,
      });
      toast({ title: 'Saved', description: 'Resource updated' });
      onSaved();
    } catch (e: any) {
      toast({ title: 'Error', description: e.message || 'Failed to save', variant: 'destructive' });
    } finally {
      setSaving(false);
    }
  };

  return (
    <Dialog open onOpenChange={(open) => { if (!open) onClose(); }}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Edit resource</DialogTitle>
          <DialogDescription>
            Change routing fields. Sync-owned fields (scopes, connection type) are managed in Okta.
          </DialogDescription>
        </DialogHeader>
        {loading ? (
          <div className="py-8 flex justify-center"><Loader2 className="w-5 h-5 animate-spin" /></div>
        ) : (
          <div className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="er-name">Name (slug) *</Label>
              <Input
                id="er-name"
                value={form.name}
                onChange={(e) => setForm({ ...form, name: e.target.value })}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="er-url">URL *</Label>
              <Input
                id="er-url"
                value={form.url}
                onChange={(e) => setForm({ ...form, url: e.target.value })}
                placeholder="https://mcp.example.com"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="er-type">Type</Label>
              <select
                id="er-type"
                value={form.type}
                onChange={(e) => setForm({ ...form, type: e.target.value })}
                className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm"
              >
                <option value="mcp">MCP</option>
                <option value="api">API</option>
                <option value="a2a">A2A</option>
              </select>
            </div>
            <div className="space-y-2">
              <Label htmlFor="er-desc">Description</Label>
              <Input
                id="er-desc"
                value={form.description}
                onChange={(e) => setForm({ ...form, description: e.target.value })}
              />
            </div>
            <label className="flex items-center gap-2">
              <input
                type="checkbox"
                checked={form.enabled}
                onChange={(e) => setForm({ ...form, enabled: e.target.checked })}
                className="h-4 w-4"
              />
              <span>Enabled</span>
            </label>
          </div>
        )}
        <DialogFooter>
          <Button variant="outline" onClick={onClose}>Cancel</Button>
          <Button onClick={handleSave} disabled={saving || loading}>
            {saving && <Loader2 className="w-4 h-4 mr-2 animate-spin" />}
            Save
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

// ---------------------------------------------------------------------------
// Create Resource Dialog
// ---------------------------------------------------------------------------

// ---------------------------------------------------------------------------
// Configuration Tab
// ---------------------------------------------------------------------------
function ConfigurationTab({ agent, onSaved }: { agent: Agent; onSaved: () => void }) {
  const { toast } = useToast();
  const [saving, setSaving] = useState(false);
  const [fetchingSecret, setFetchingSecret] = useState(false);
  const [generatingKey, setGeneratingKey] = useState(false);
  const [credStatus, setCredStatus] = useState<CredentialStatus | null>(null);
  const [credStatusError, setCredStatusError] = useState<string | null>(null);
  const [manualOpen, setManualOpen] = useState(false);
  const [form, setForm] = useState({
    cimd_client_id: agent.cimd_client_id_url || '',
    client_secret: '',
    private_key: '',
    enabled: agent.enabled,
    client_mode: agent.dcr_selectable ? 'dcr' : (agent.cimd_client_id_url ? 'cimd' : 'none'),
  });

  const loadCredentialStatus = useCallback(async () => {
    try {
      setCredStatusError(null);
      const status = await apiClient.getCredentialStatus(agent.agent_id);
      setCredStatus(status);
    } catch (err: any) {
      if (err.status === 404) {
        setCredStatus(null);
      } else {
        setCredStatusError(err.message || 'Failed to load credential status');
      }
    }
  }, [agent.agent_id]);

  useEffect(() => {
    loadCredentialStatus();
  }, [loadCredentialStatus]);

  const handleFetchSecret = async () => {
    setFetchingSecret(true);
    try {
      const result = await apiClient.fetchClientSecret(agent.agent_id);
      const msg = result.source === 'fetched_existing'
        ? 'Client secret fetched from Okta'
        : 'New client secret generated in Okta';
      toast({ title: 'Success', description: msg });
      await loadCredentialStatus();
      onSaved();
    } catch (err: any) {
      if (err.status === 401) {
        toast({ title: 'Session Expired', description: 'Your Okta session has expired. Please log in again.', variant: 'destructive' });
      } else if (err.status === 403) {
        toast({ title: 'Insufficient Permissions', description: 'Your Okta admin role needs the okta.apps.manage scope to fetch client secrets.', variant: 'destructive' });
      } else {
        toast({ title: 'Error', description: err.message, variant: 'destructive' });
      }
    } finally {
      setFetchingSecret(false);
    }
  };

  const handleGenerateKey = async () => {
    setGeneratingKey(true);
    try {
      const result = await apiClient.generateKeyPair(agent.agent_id);
      toast({ title: 'Success', description: `Key pair generated and registered (kid: ${result.kid})` });
      await loadCredentialStatus();
      onSaved();
    } catch (err: any) {
      if (err.status === 401) {
        toast({ title: 'Session Expired', description: 'Your Okta session has expired. Please log in again.', variant: 'destructive' });
      } else if (err.status === 403) {
        toast({ title: 'Insufficient Permissions', description: 'Your Okta admin role needs the okta.aiAgents.manage scope to register keys.', variant: 'destructive' });
      } else {
        toast({ title: 'Error', description: err.message, variant: 'destructive' });
      }
    } finally {
      setGeneratingKey(false);
    }
  };

  const handleSave = async () => {
    setSaving(true);
    try {
      const updates: Record<string, any> = {};
      if (form.client_mode === 'cimd') {
        const cimd = form.cimd_client_id.trim();
        updates.cimd_client_id = cimd || null;
        updates.dcr_selectable = false;
      } else if (form.client_mode === 'dcr') {
        updates.cimd_client_id = null;
        updates.dcr_selectable = true;
      } else {
        updates.cimd_client_id = null;
        updates.dcr_selectable = false;
      }
      if (form.client_secret) updates.client_secret = form.client_secret;
      if (form.private_key) updates.private_key = form.private_key;
      updates.enabled = form.enabled;

      await apiClient.updateAgent(agent.agent_id, updates);
      toast({ title: 'Saved', description: `Configuration updated for ${agent.agent_id}` });
      setForm({ ...form, client_secret: '', private_key: '' });
      await loadCredentialStatus();
      onSaved();
    } catch (err: any) {
      toast({ title: 'Error', description: err.message, variant: 'destructive' });
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="max-w-2xl space-y-6">
      {/* Read-only identity */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base">
            {agent.registration_source === 'okta-import' ? 'Okta Identity (read-only)' : 'Identity'}
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 gap-4 text-sm">
            <div>
              <span className="text-muted-foreground">Agent Name:</span>
              <span className="ml-2 font-mono">{agent.agent_id}</span>
            </div>
            <div>
              <span className="text-muted-foreground">Client ID:</span>
              <span className="ml-2 font-mono text-xs">{agent.client_id}</span>
            </div>
            {agent.okta_ai_agent_id && (
              <div className="col-span-2">
                <span className="text-muted-foreground">Okta Agent ID:</span>
                <span className="ml-2 font-mono text-xs">{agent.okta_ai_agent_id}</span>
              </div>
            )}
            {agent.principal_id && (
              <div className="col-span-2">
                <span className="text-muted-foreground">Principal ID:</span>
                <span className="ml-2 font-mono text-xs break-all">{agent.principal_id}</span>
              </div>
            )}
          </div>
        </CardContent>
      </Card>

      {/* Credential Status & Automation */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base">Credential Status</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          {credStatusError ? (
            <p className="text-sm text-muted-foreground">{credStatusError}</p>
          ) : credStatus ? (
            <>
              <div className="space-y-2 text-sm">
                <div className="flex items-center gap-2">
                  {credStatus.has_client_secret ? (
                    <Check className="w-4 h-4 text-green-600" />
                  ) : (
                    <X className="w-4 h-4 text-red-500" />
                  )}
                  <span>
                    Client Secret: {credStatus.has_client_secret ? 'Configured' : 'Not Configured'}
                  </span>
                </div>
                <div className="flex items-center gap-2">
                  {credStatus.has_private_key ? (
                    <Check className="w-4 h-4 text-green-600" />
                  ) : (
                    <X className="w-4 h-4 text-red-500" />
                  )}
                  <span>
                    Signing Key: {credStatus.has_private_key ? 'Configured' : 'Not Configured'}
                  </span>
                </div>
                {credStatus.registered_keys.length > 0 && (
                  <div className="ml-6 space-y-1">
                    <span className="text-muted-foreground text-xs">Registered with Okta:</span>
                    {credStatus.registered_keys.map((k) => (
                      <div key={k.kid} className="flex items-center gap-1 text-xs font-mono text-muted-foreground">
                        <Key className="w-3 h-3" />
                        <span>kid: {k.kid}</span>
                        <span className="text-muted-foreground/60">({k.alg})</span>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              {agent.okta_ai_agent_id ? (
                <div className="flex flex-wrap gap-2 pt-2">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={handleFetchSecret}
                    disabled={fetchingSecret || generatingKey}
                  >
                    {fetchingSecret ? (
                      <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                    ) : (
                      <RefreshCw className="w-4 h-4 mr-2" />
                    )}
                    Fetch Secret from Okta
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={handleGenerateKey}
                    disabled={fetchingSecret || generatingKey}
                  >
                    {generatingKey ? (
                      <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                    ) : (
                      <Key className="w-4 h-4 mr-2" />
                    )}
                    Generate &amp; Register New Key
                  </Button>
                </div>
              ) : (
                <p className="text-xs text-muted-foreground">
                  Link an Okta AI Agent ID to enable automated credential provisioning.
                </p>
              )}
            </>
          ) : (
            <div className="flex items-center gap-2 text-sm text-muted-foreground">
              <Loader2 className="w-4 h-4 animate-spin" />
              Loading credential status...
            </div>
          )}
        </CardContent>
      </Card>

      {/* Settings */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base">Settings</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <Label>Client Mode</Label>
            <div className="space-y-2">
              <label className="flex items-center space-x-2 cursor-pointer">
                <input
                  type="radio"
                  name="client_mode"
                  value="none"
                  checked={form.client_mode === 'none'}
                  onChange={() => setForm({ ...form, client_mode: 'none' })}
                  className="rounded"
                />
                <span className="text-sm">Standard</span>
                <span className="text-xs text-muted-foreground">- No CIMD or DCR</span>
              </label>
              <label className="flex items-center space-x-2 cursor-pointer">
                <input
                  type="radio"
                  name="client_mode"
                  value="cimd"
                  checked={form.client_mode === 'cimd'}
                  onChange={() => setForm({ ...form, client_mode: 'cimd' })}
                  className="rounded"
                />
                <span className="text-sm">CIMD Client</span>
                <span className="text-xs text-muted-foreground">- URL-based client identity</span>
              </label>
              <label className="flex items-center space-x-2 cursor-pointer">
                <input
                  type="radio"
                  name="client_mode"
                  value="dcr"
                  checked={form.client_mode === 'dcr'}
                  onChange={() => setForm({ ...form, client_mode: 'dcr' })}
                  className="rounded"
                />
                <span className="text-sm">DCR Enabled</span>
                <span className="text-xs text-muted-foreground">- Share DCR credentials</span>
              </label>
            </div>
          </div>

          {form.client_mode === 'cimd' && (
            <div className="space-y-1 pl-6 border-l-2 border-muted">
              <Label htmlFor="cfg-cimd">CIMD Client ID</Label>
              <Input
                id="cfg-cimd"
                value={form.cimd_client_id}
                onChange={(e) => setForm({ ...form, cimd_client_id: e.target.value })}
                placeholder="https://claude.ai/oauth/client-metadata.json"
              />
              <p className="text-xs text-muted-foreground">
                URL-based client identifier for CIMD-enabled MCP clients.
              </p>
            </div>
          )}

          <div className="flex items-center space-x-2 pt-2">
            <input
              id="cfg-enabled"
              type="checkbox"
              checked={form.enabled}
              onChange={(e) => setForm({ ...form, enabled: e.target.checked })}
              className="rounded"
            />
            <Label htmlFor="cfg-enabled">Agent Enabled</Label>
            <span className="text-xs text-muted-foreground">(Controls whether this agent can process requests)</span>
          </div>

          <div className="pt-2">
            <Button onClick={handleSave} disabled={saving}>
              {saving && <Loader2 className="w-4 h-4 mr-2 animate-spin" />}
              Save Settings
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Manual credential entry (collapsible) */}
      <Card>
        <CardHeader>
          <button
            type="button"
            className="flex items-center gap-2 w-full text-left"
            onClick={() => setManualOpen(!manualOpen)}
          >
            {manualOpen ? (
              <ChevronDown className="w-4 h-4 text-muted-foreground" />
            ) : (
              <ChevronRight className="w-4 h-4 text-muted-foreground" />
            )}
            <CardTitle className="text-base">Manual Configuration</CardTitle>
          </button>
          <p className="text-xs text-muted-foreground ml-6">
            Directly enter credentials when automated provisioning is not available.
          </p>
        </CardHeader>
        {manualOpen && (
          <CardContent className="space-y-4">
            <div className="space-y-1">
              <Label htmlFor="cfg-secret">Client Secret</Label>
              <Input
                id="cfg-secret"
                type="password"
                value={form.client_secret}
                onChange={(e) => setForm({ ...form, client_secret: e.target.value })}
                placeholder="Leave blank to keep existing value"
              />
              <p className="text-xs text-muted-foreground">
                Okta OIDC app&apos;s client_secret. Stored encrypted.
              </p>
            </div>

            <div className="space-y-1">
              <Label htmlFor="cfg-pk">Private Key (JWK)</Label>
              <textarea
                id="cfg-pk"
                value={form.private_key}
                onChange={(e) => setForm({ ...form, private_key: e.target.value })}
                placeholder="Leave blank to keep existing value"
                className="flex w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 font-mono h-24 resize-y"
              />
              <p className="text-xs text-muted-foreground">
                JWK private key from the Okta AI Agent config. Used for ID-JAG token signing.
              </p>
            </div>

            <div className="pt-2">
              <Button onClick={handleSave} disabled={saving}>
                {saving && <Loader2 className="w-4 h-4 mr-2 animate-spin" />}
                Save Manual Credentials
              </Button>
            </div>
          </CardContent>
        )}
      </Card>

      {/* Pre-Consent Link */}
      <PreConsentLinkSection agentId={agent.agent_id} />
    </div>
  );
}

// ---------------------------------------------------------------------------
// Pre-Consent Link Section
// ---------------------------------------------------------------------------
function PreConsentLinkSection({ agentId }: { agentId: string }) {
  const { toast } = useToast();
  const [copied, setCopied] = useState(false);
  const [gatewayBaseUrl, setGatewayBaseUrl] = useState<string | null>(null);

  useEffect(() => {
    let cancelled = false;
    apiClient
      .getPublicConfig()
      .then((cfg) => {
        if (!cancelled) setGatewayBaseUrl(cfg.gateway_base_url.replace(/\/$/, ''));
      })
      .catch(() => {
        if (!cancelled) setGatewayBaseUrl(null);
      });
    return () => {
      cancelled = true;
    };
  }, []);

  const preConsentUrl = gatewayBaseUrl
    ? `${gatewayBaseUrl}/oauth/pre-consent?agent_id=${encodeURIComponent(agentId)}`
    : '';

  const handleCopy = async () => {
    if (!preConsentUrl) return;
    try {
      await navigator.clipboard.writeText(preConsentUrl);
      setCopied(true);
      toast({ title: 'Copied!', description: 'Pre-consent link copied to clipboard.' });
      setTimeout(() => setCopied(false), 2000);
    } catch {
      toast({ title: 'Error', description: 'Failed to copy to clipboard.', variant: 'destructive' });
    }
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-base">Pre-Consent Link</CardTitle>
      </CardHeader>
      <CardContent className="space-y-3">
        <div className="flex items-center gap-2">
          <Input
            readOnly
            value={preConsentUrl}
            placeholder={gatewayBaseUrl === null ? 'Loading gateway URL…' : ''}
            className="font-mono text-xs flex-1"
            onClick={(e) => (e.target as HTMLInputElement).select()}
          />
          <Button variant="outline" size="sm" onClick={handleCopy} disabled={!preConsentUrl}>
            {copied ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
            <span className="ml-1.5">{copied ? 'Copied' : 'Copy link'}</span>
          </Button>
        </div>
        <p className="text-xs text-muted-foreground">
          Send this link to a user to let them re-verify STS-managed connections without
          restarting their MCP client. The user will authenticate against this agent&apos;s
          Okta app and land on the consent interstitial.
        </p>
      </CardContent>
    </Card>
  );
}

// ---------------------------------------------------------------------------
// Per-resource pre-consent copy button (for STS-type connections)
// ---------------------------------------------------------------------------
function CopyPreConsentResourceButton({ agentId, resourceName }: { agentId: string; resourceName: string }) {
  const { toast } = useToast();

  const handleCopy = async () => {
    try {
      const cfg = await apiClient.getPublicConfig();
      const gatewayBaseUrl = cfg.gateway_base_url.replace(/\/$/, '');
      const url = `${gatewayBaseUrl}/oauth/pre-consent?agent_id=${encodeURIComponent(agentId)}&resource=${encodeURIComponent(resourceName)}`;
      await navigator.clipboard.writeText(url);
      toast({ title: 'Copied!', description: `Pre-consent link for ${resourceName} copied to clipboard.` });
    } catch {
      toast({ title: 'Error', description: 'Failed to copy to clipboard.', variant: 'destructive' });
    }
  };

  return (
    <Button
      variant="ghost"
      size="sm"
      className="h-7 text-xs px-2"
      onClick={handleCopy}
      title={`Copy pre-consent link for ${resourceName}`}
    >
      <Copy className="w-3 h-3 mr-1" /> Pre-consent
    </Button>
  );
}

// ---------------------------------------------------------------------------
// Tools Tab
// ---------------------------------------------------------------------------
function ToolsTab({ detail, agentId }: { detail: AgentDetail | null; agentId: string }) {
  const { toast } = useToast();
  const [tools, setTools] = useState<AgentToolsResponse | null>(null);
  const [loading, setLoading] = useState(true);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const res = await apiClient.getAgentTools(agentId);
      setTools(res);
    } catch (err: any) {
      toast({ title: 'Error', description: err.message, variant: 'destructive' });
    } finally {
      setLoading(false);
    }
  }, [agentId, toast]);

  useEffect(() => { load(); }, [load]);

  const linkedResources = (detail?.connections || [])
    .map((c) => c.resource)
    .filter((r): r is NonNullable<typeof r> => !!r && r.enabled !== false && !!r.url);

  if (linkedResources.length === 0) {
    return (
      <div className="text-center py-12 text-muted-foreground">
        <Wrench className="w-8 h-8 mx-auto mb-2 opacity-50" />
        <p>No tools available.</p>
        <p className="text-sm mt-1">Set a URL and enable a resource on one of this agent&apos;s connections.</p>
      </div>
    );
  }

  const byResource = new Map(
    (tools?.resources || []).map((g) => [g.resource_name, g]),
  );

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <p className="text-sm text-muted-foreground">
          Tools available from {linkedResources.length} linked resource{linkedResources.length !== 1 ? 's' : ''}.
          Tool names are namespaced as <code className="text-xs">resource_name__tool_name</code> in the unified endpoint.
        </p>
        <Button variant="ghost" size="sm" onClick={load} disabled={loading}>
          <RefreshCw className={`w-3 h-3 mr-1 ${loading ? 'animate-spin' : ''}`} />
          Refresh
        </Button>
      </div>
      {linkedResources.map((resource) => {
        const group = byResource.get(resource.name);
        return (
          <Card key={resource.name}>
            <CardHeader className="pb-2">
              <CardTitle className="text-base flex items-center gap-2">
                <Server className="w-4 h-4" />
                {resource.name}
                <span className="text-xs bg-muted px-2 py-0.5 rounded font-normal">{resource.type || 'mcp'}</span>
                {group && (
                  <span className="text-xs bg-green-100 text-green-800 px-2 py-0.5 rounded font-normal">
                    {group.tool_count} tool{group.tool_count !== 1 ? 's' : ''}
                  </span>
                )}
              </CardTitle>
              <p className="text-xs text-muted-foreground">{resource.url}</p>
            </CardHeader>
            <CardContent>
              {group ? (
                <ul className="space-y-2">
                  {group.tools.map((t) => (
                    <li key={t.name} className="text-sm">
                      <code className="text-xs bg-muted px-1.5 py-0.5 rounded">{t.name}</code>
                      {t.description && (
                        <span className="ml-2 text-muted-foreground">
                          {t.description.length > 120 ? `${t.description.slice(0, 120)}…` : t.description}
                        </span>
                      )}
                    </li>
                  ))}
                </ul>
              ) : (
                <p className="text-sm text-muted-foreground">
                  No tool catalog cached yet. Tools appear here after an MCP client calls
                  <code className="text-xs bg-muted px-1 mx-1 rounded">tools/list</code>
                  on this agent.
                </p>
              )}
            </CardContent>
          </Card>
        );
      })}
    </div>
  );
}

// ---------------------------------------------------------------------------
// Audit Tab
// ---------------------------------------------------------------------------
function AuditTab({ agentId }: { agentId: string }) {
  const { toast } = useToast();
  const [entries, setEntries] = useState<AuditLogEntry[]>([]);
  const [loading, setLoading] = useState(true);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const log = await apiClient.getAgentAuditLog(agentId);
      setEntries(log);
    } catch (err: any) {
      toast({ title: 'Error', description: err.message, variant: 'destructive' });
    } finally {
      setLoading(false);
    }
  }, [agentId, toast]);

  useEffect(() => { load(); }, [load]);

  const formatTimestamp = (ts?: string) => {
    if (!ts) return '—';
    const d = new Date(ts);
    if (isNaN(d.getTime())) return ts;
    return d.toLocaleString();
  };

  const badgeColor = (action: string) => {
    if (action.includes('created')) return 'bg-green-100 text-green-800';
    if (action.includes('updated')) return 'bg-blue-100 text-blue-800';
    if (action.includes('deleted')) return 'bg-red-100 text-red-800';
    if (action.includes('failure') || action.includes('rejected') || action.includes('denied'))
      return 'bg-red-100 text-red-800';
    if (action.includes('success') || action.includes('validated') || action.includes('granted'))
      return 'bg-green-100 text-green-800';
    return 'bg-gray-100 text-gray-800';
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <p className="text-sm text-muted-foreground">
          {entries.length} audit entr{entries.length === 1 ? 'y' : 'ies'}
        </p>
        <Button variant="outline" size="sm" onClick={load} disabled={loading}>
          <RefreshCw className={`w-4 h-4 mr-2 ${loading ? 'animate-spin' : ''}`} /> Refresh
        </Button>
      </div>

      {loading ? (
        <div className="text-center py-8 text-muted-foreground">Loading audit log...</div>
      ) : entries.length === 0 ? (
        <div className="text-center py-8 text-muted-foreground">No audit entries found.</div>
      ) : (
        <div className="space-y-3">
          {entries.map((entry, index) => (
            <div key={entry.id || index} className="border rounded-lg p-4 hover:bg-muted/30 transition">
              <div className="flex justify-between items-start mb-2">
                <div className="flex items-center gap-2">
                  <span className={`px-2 py-1 rounded text-xs font-medium ${badgeColor(entry.action)}`}>
                    {entry.action}
                  </span>
                  {entry.entity_type && (
                    <span className="text-sm text-muted-foreground">
                      {entry.entity_type}
                      {entry.entity_id && entry.entity_id !== agentId && `: ${entry.entity_id}`}
                    </span>
                  )}
                </div>
                <span className="text-sm text-muted-foreground">{formatTimestamp(entry.changed_at)}</span>
              </div>
              {entry.changed_by && (
                <div className="text-sm text-muted-foreground mb-2">
                  User: <span className="font-mono">{entry.changed_by}</span>
                </div>
              )}
              {entry.changes && Object.keys(entry.changes).length > 0 && (
                <details className="mt-2">
                  <summary className="cursor-pointer text-sm text-blue-600 hover:text-blue-800">View Changes</summary>
                  <pre className="mt-2 p-2 bg-muted rounded text-xs overflow-x-auto">
                    {JSON.stringify(entry.changes, null, 2)}
                  </pre>
                </details>
              )}
              {entry.details && Object.keys(entry.details).length > 0 && (
                <details className="mt-2">
                  <summary className="cursor-pointer text-sm text-blue-600 hover:text-blue-800">View Details</summary>
                  <pre className="mt-2 p-2 bg-muted rounded text-xs overflow-x-auto">
                    {JSON.stringify(entry.details, null, 2)}
                  </pre>
                </details>
              )}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
