"use client"

import { useEffect, useState } from 'react';
import { useParams, useRouter } from 'next/navigation';
import { apiClient, AuditLogEntry } from '@/lib/api-client';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { useToast } from '@/components/ui/use-toast';
import { RefreshCw, ArrowLeft, Shield } from 'lucide-react';

export default function AgentAuditLogPage() {
  const params = useParams();
  const router = useRouter();
  const agentId = params.agentId as string;
  const [auditLog, setAuditLog] = useState<AuditLogEntry[]>([]);
  const [loading, setLoading] = useState(true);
  const { toast } = useToast();

  const loadAuditLog = async () => {
    setLoading(true);
    try {
      const log = await apiClient.getAgentAuditLog(agentId);
      setAuditLog(log);
    } catch (error: any) {
      toast({
        title: 'Error',
        description: error.message || 'Failed to load audit log',
        variant: 'destructive',
      });
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (agentId) {
      loadAuditLog();
    }
  }, [agentId]);

  const formatTimestamp = (timestamp?: string) => {
    if (!timestamp) return '—';
    const d = new Date(timestamp);
    if (isNaN(d.getTime())) return timestamp;
    return d.toLocaleString();
  };

  const getActionBadgeColor = (action: string) => {
    if (action.includes('created')) return 'bg-green-100 text-green-800';
    if (action.includes('updated')) return 'bg-blue-100 text-blue-800';
    if (action.includes('deleted')) return 'bg-red-100 text-red-800';
    if (action.includes('failure') || action.includes('rejected') || action.includes('denied')) {
      return 'bg-red-100 text-red-800';
    }
    if (action.includes('success') || action.includes('validated') || action.includes('granted')) {
      return 'bg-green-100 text-green-800';
    }
    return 'bg-gray-100 text-gray-800';
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-4">
          <Button variant="ghost" size="icon" onClick={() => router.push('/dashboard/agents')}>
            <ArrowLeft className="w-5 h-5" />
          </Button>
          <div>
            <div className="flex items-center gap-2 mb-1">
              <Shield className="w-6 h-6 text-primary" />
              <h1 className="text-3xl font-bold">{decodeURIComponent(agentId)}</h1>
            </div>
            <p className="text-gray-600">Agent audit log - all activity and changes</p>
          </div>
        </div>
        <Button onClick={loadAuditLog} disabled={loading}>
          <RefreshCw className={`w-4 h-4 mr-2 ${loading ? 'animate-spin' : ''}`} />
          Refresh
        </Button>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Audit Entries ({auditLog.length})</CardTitle>
          <CardDescription>
            All audit events for agent: {decodeURIComponent(agentId)}
          </CardDescription>
        </CardHeader>
        <CardContent>
          {loading ? (
            <div className="text-center py-8 text-gray-500">Loading audit log...</div>
          ) : auditLog.length === 0 ? (
            <div className="text-center py-8 text-gray-500">
              No audit entries found for this agent
            </div>
          ) : (
            <div className="space-y-3">
              {auditLog.map((entry, index) => (
                <div
                  key={entry.id || index}
                  className="border rounded-lg p-4 hover:bg-gray-50 transition"
                >
                  <div className="flex justify-between items-start mb-2">
                    <div className="flex items-center gap-2">
                      <span
                        className={`px-2 py-1 rounded text-xs font-medium ${getActionBadgeColor(
                          entry.action
                        )}`}
                      >
                        {entry.action}
                      </span>
                      {entry.entity_type && (
                        <span className="text-sm text-gray-600">
                          {entry.entity_type}
                          {entry.entity_id && entry.entity_id !== agentId && `: ${entry.entity_id}`}
                        </span>
                      )}
                    </div>
                    <span className="text-sm text-gray-500">
                      {formatTimestamp(entry.changed_at)}
                    </span>
                  </div>

                  {entry.changed_by && (
                    <div className="text-sm text-gray-600 mb-2">
                      User: <span className="font-mono">{entry.changed_by}</span>
                    </div>
                  )}

                  {entry.changes && Object.keys(entry.changes).length > 0 && (
                    <details className="mt-2">
                      <summary className="cursor-pointer text-sm text-blue-600 hover:text-blue-800">
                        View Changes
                      </summary>
                      <pre className="mt-2 p-2 bg-gray-100 rounded text-xs overflow-x-auto">
                        {JSON.stringify(entry.changes, null, 2)}
                      </pre>
                    </details>
                  )}

                  {entry.details && Object.keys(entry.details).length > 0 && (
                    <details className="mt-2">
                      <summary className="cursor-pointer text-sm text-blue-600 hover:text-blue-800">
                        View Details
                      </summary>
                      <pre className="mt-2 p-2 bg-gray-100 rounded text-xs overflow-x-auto">
                        {JSON.stringify(entry.details, null, 2)}
                      </pre>
                    </details>
                  )}
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
