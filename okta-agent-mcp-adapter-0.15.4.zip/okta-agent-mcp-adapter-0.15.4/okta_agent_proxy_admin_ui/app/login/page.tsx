"use client"

import { signIn, useSession } from 'next-auth/react';
import { useRouter, useSearchParams } from 'next/navigation';
import { useEffect, Suspense } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';

function LoginContent() {
  const { data: session, status } = useSession();
  const router = useRouter();
  const searchParams = useSearchParams();
  const error = searchParams.get('error');

  useEffect(() => {
    // Redirect to dashboard if already authenticated
    if (status === 'authenticated') {
      router.push('/dashboard');
    }
  }, [status, router]);

  const handleSignIn = async () => {
    await signIn('okta', { callbackUrl: '/dashboard' });
  };

  if (status === 'loading') {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-blue-50 to-indigo-100">
        <Card className="w-full max-w-md">
          <CardContent className="flex items-center justify-center py-12">
            <p className="text-muted-foreground">Loading...</p>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-blue-50 to-indigo-100">
      <Card className="w-full max-w-md">
        <CardHeader className="space-y-1">
          <CardTitle className="text-2xl font-bold text-center">
            Okta MCP Adapter
          </CardTitle>
          <CardDescription className="text-center">
            Admin Console - Sign in with Okta to continue
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          {error && (
            <div className="p-3 text-sm text-red-800 bg-red-100 border border-red-200 rounded">
              {error === 'OAuthSignin' && 'Error starting OAuth sign-in process'}
              {error === 'OAuthCallback' && 'Error during OAuth callback'}
              {error === 'OAuthCreateAccount' && 'Could not create OAuth account'}
              {error === 'EmailCreateAccount' && 'Could not create email account'}
              {error === 'Callback' && 'Error in callback handler'}
              {error === 'OAuthAccountNotLinked' && 'Email already associated with another account'}
              {error === 'EmailSignin' && 'Check your email for sign-in link'}
              {error === 'CredentialsSignin' && 'Sign in failed. Check your credentials'}
              {error === 'SessionRequired' && 'Please sign in to access this page'}
              {!error.match(/^(OAuth|Email|Credentials|Session)/) && 'Authentication error occurred'}
            </div>
          )}

          <Button onClick={handleSignIn} className="w-full" size="lg">
            Sign in with Okta
          </Button>

          <div className="mt-4 text-xs text-center text-muted-foreground">
            <p>Uses OAuth 2.0 / OpenID Connect</p>
            <p className="mt-1">Authenticates against your Okta organization</p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

export default function LoginPage() {
  return (
    <Suspense fallback={
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-blue-50 to-indigo-100">
        <Card className="w-full max-w-md">
          <CardContent className="flex items-center justify-center py-12">
            <p className="text-muted-foreground">Loading...</p>
          </CardContent>
        </Card>
      </div>
    }>
      <LoginContent />
    </Suspense>
  );
}
