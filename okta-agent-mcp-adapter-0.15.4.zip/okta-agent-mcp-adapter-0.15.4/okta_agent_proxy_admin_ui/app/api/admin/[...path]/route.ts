import { NextRequest, NextResponse } from 'next/server';

// For Docker Compose deployments, use the fixed service name
// For local dev, use localhost
// This avoids the complexity of runtime environment variables in Next.js standalone builds
const getApiUrl = () => {
  // Check server-side environment variable first (for Docker/runtime)
  if (process.env.API_URL) {
    return process.env.API_URL;
  }

  // Check client-side environment variable (for build-time config)
  if (process.env.NEXT_PUBLIC_API_URL) {
    return process.env.NEXT_PUBLIC_API_URL;
  }

  // In Docker Compose, use the service name directly
  // For local dev/production without env var, fallback to localhost
  const isDocker = process.env.DOCKER_ENV === 'true';
  return isDocker ? 'http://okta-agent-mcp-adapter:8000' : 'http://localhost:8000';
};

const API_URL = getApiUrl();

export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ path: string[] }> }
) {
  const resolvedParams = await params;
  return proxyRequest(request, resolvedParams.path);
}

export async function POST(
  request: NextRequest,
  { params }: { params: Promise<{ path: string[] }> }
) {
  const resolvedParams = await params;
  return proxyRequest(request, resolvedParams.path);
}

export async function PUT(
  request: NextRequest,
  { params }: { params: Promise<{ path: string[] }> }
) {
  const resolvedParams = await params;
  return proxyRequest(request, resolvedParams.path);
}

export async function DELETE(
  request: NextRequest,
  { params }: { params: Promise<{ path: string[] }> }
) {
  const resolvedParams = await params;
  return proxyRequest(request, resolvedParams.path);
}

async function proxyRequest(request: NextRequest, path: string[]) {
  const pathString = path.join('/');
  // Use the hardcoded API_URL constant defined above
  const url = `${API_URL}/api/admin/${pathString}`;

  console.log('[Proxy] API_URL:', API_URL);
  console.log('[Proxy] Target URL:', url);

  try {
    // Get headers from the incoming request
    const headers: Record<string, string> = {};
    request.headers.forEach((value, key) => {
      // Forward important headers
      if (['authorization', 'content-type'].includes(key.toLowerCase())) {
        headers[key] = value;
      }
    });

    // Get body for POST/PUT requests
    let body: string | undefined;
    if (request.method === 'POST' || request.method === 'PUT') {
      body = await request.text();
    }

    // Make the proxied request
    const response = await fetch(url, {
      method: request.method,
      headers,
      body,
    });

    // Handle 204 No Content responses
    if (response.status === 204) {
      return new NextResponse(null, {
        status: 204,
      });
    }

    // Get response data
    const data = await response.text();

    // Return response with same status and headers
    return new NextResponse(data, {
      status: response.status,
      headers: {
        'Content-Type': response.headers.get('content-type') || 'application/json',
      },
    });
  } catch (error) {
    console.error('Proxy error:', error);
    return NextResponse.json(
      { error: 'proxy_error', message: 'Failed to proxy request to gateway' },
      { status: 500 }
    );
  }
}
