import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';

export async function POST(request: NextRequest) {
  const session = await getServerSession(authOptions);

  const oktaDomain = process.env.OKTA_DOMAIN;
  const clientId = process.env.OKTA_CLIENT_ID;
  const clientSecret = process.env.OKTA_CLIENT_SECRET;

  if (!oktaDomain) {
    return NextResponse.json(
      { error: 'okta_not_configured', message: 'OKTA_DOMAIN is not set' },
      { status: 500 }
    );
  }

  const accessToken = session?.accessToken;
  const idToken = session?.idToken;

  if (accessToken && clientId && clientSecret) {
    try {
      const basic = Buffer.from(`${clientId}:${clientSecret}`).toString('base64');
      await fetch(`https://${oktaDomain}/oauth2/v1/revoke`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded',
          Authorization: `Basic ${basic}`,
        },
        body: new URLSearchParams({
          token: accessToken,
          token_type_hint: 'access_token',
        }),
      });
    } catch (err) {
      console.error('[okta-logout] Failed to revoke access token');
    }
  }

  const origin = (process.env.NEXTAUTH_URL || request.nextUrl.origin).replace(/\/$/, '');
  const postLogoutRedirect = `${origin}/login`;

  let logoutUrl = `${origin}/login`;
  if (idToken) {
    const url = new URL(`https://${oktaDomain}/oauth2/v1/logout`);
    url.searchParams.set('id_token_hint', idToken);
    url.searchParams.set('post_logout_redirect_uri', postLogoutRedirect);
    logoutUrl = url.toString();
  }

  return NextResponse.json({ logoutUrl });
}
