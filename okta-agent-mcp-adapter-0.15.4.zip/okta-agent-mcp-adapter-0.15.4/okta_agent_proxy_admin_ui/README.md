# Okta MCP Adapter - Admin UI

A modern web-based admin console for managing the Okta MCP Adapter gateway. Built with Next.js, TypeScript, Radix UI, and Tailwind CSS.

## Features

- **Dashboard Overview**: Quick stats and system status
- **Agent Management**: Create, edit, and delete MCP client agents
- **Backend Management**: Configure MCP backend servers with various auth methods
- **Real-time Updates**: Instant feedback on all operations
- **Responsive Design**: Works on desktop and mobile devices
- **Secure Authentication**: JWT-based admin authentication

## Technology Stack

- **Framework**: Next.js 14 (App Router)
- **Language**: TypeScript
- **UI Components**: Radix UI (accessible, unstyled primitives)
- **Styling**: Tailwind CSS
- **Icons**: Lucide React
- **State Management**: React Hooks + Context

## Installation

### Prerequisites

- Node.js 20+
- npm or yarn
- Running Okta MCP Adapter gateway (backend)

### Setup Steps

1. **Install Dependencies**

```bash
cd okta_agent_proxy_admin_ui
npm install
```

2. **Configure Environment**

```bash
cp .env.local.example .env.local
```

Edit `.env.local`:

```env
# Admin API Configuration
NEXT_PUBLIC_API_URL=http://localhost:8000

# Admin Authentication
NEXT_PUBLIC_APP_NAME=Okta MCP Adapter Admin
```

3. **Start Development Server**

```bash
npm run dev
```

The admin UI will be available at `http://localhost:3001`

4. **Sign in**

The Admin UI uses NextAuth + Okta OIDC — there is no local username/password.
Configure the OIDC app via `ADMIN_UI_OKTA_DOMAIN`, `ADMIN_UI_OKTA_CLIENT_ID`,
and `ADMIN_UI_OKTA_CLIENT_SECRET`, then sign in with any user assigned to
that app in Okta.

## Production Deployment

### Docker (Recommended)

The admin UI is included in the main Docker Compose stack:

```bash
# From repository root
./setup.sh
```

This automatically builds and starts all services including the admin UI.

**Access:** http://localhost:3001

For detailed Docker deployment instructions, see [DOCKER.md](DOCKER.md).

### Standalone Deployment

#### Build for Production

```bash
npm run build
npm start
```

#### Environment Variables

For production, set:

```env
NEXT_PUBLIC_API_URL=https://your-gateway.example.com
```

### Other Deployment Options

**Vercel**

```bash
vercel deploy
```

**Manual Docker Build**

```bash
docker build -t okta-mcp-admin-ui:latest .
docker run -d -p 3001:3001 \
  -e NEXT_PUBLIC_API_URL=http://gateway:8000 \
  okta-mcp-admin-ui:latest
```

See [DOCKER.md](DOCKER.md) for complete Docker documentation.

**Static Export (Not Recommended)**

The admin UI requires server-side API proxying, so static export is not recommended. Use Docker or Node.js server instead.

## Architecture

### API Integration

The UI communicates with the Admin API via the API client (`lib/api-client.ts`):

- **Authentication**: Okta OIDC via NextAuth (access token attached as Bearer)
- **Agents**: GET/POST/PUT/DELETE `/api/admin/agents`
- **Resources**: GET/POST/PUT/DELETE `/api/admin/resources`

All admin API requests require `Authorization: Bearer <okta_access_token>`.

### Pages Structure

```
app/
├── page.tsx              # Root redirect to /login
├── login/
│   └── page.tsx         # Login page
├── dashboard/
│   ├── layout.tsx       # Dashboard layout with navigation
│   ├── page.tsx         # Overview dashboard
│   ├── agents/
│   │   └── page.tsx     # Agent management
│   └── backends/
│       └── page.tsx     # Backend management
└── globals.css          # Global styles
```

### Component Library

Reusable UI components in `components/ui/`:

- **Button**: Action buttons with variants
- **Card**: Content containers
- **Dialog**: Modal dialogs for forms
- **Input/Textarea**: Form inputs
- **Label**: Form labels
- **Toast**: Notifications

All components are built with Radix UI primitives and styled with Tailwind CSS.

## Usage Guide

### Managing Agents

Agents represent MCP clients (Claude Code, Cursor, etc.):

1. Navigate to **Agents** page
2. Click **Add Agent**
3. Fill in:
   - **Agent ID**: Unique identifier (e.g., `claude-code`)
   - **Client ID**: Okta OAuth client ID
   - **Client Secret**: OAuth client secret (encrypted in database)
   - **Private Key**: JWK format for ID-JAG token signing
   - **Backend Access**: Comma-separated list of backend names
   - **Enabled**: Toggle to enable/disable
4. Click **Create**

**Editing**: Click the edit icon to update an agent. Leave sensitive fields blank to keep existing values.

**Deleting**: Click the trash icon and confirm.

### Managing Backends

Backends are target MCP servers:

1. Navigate to **Backends** page
2. Click **Add Backend**
3. Fill in:
   - **Backend Name**: Unique identifier (e.g., `hr-system`)
   - **URL**: Backend MCP server URL
   - **Paths**: Comma-separated routing paths (e.g., `/hr, /employees`)
   - **Auth Method**: Choose from:
     - **okta-cross-app**: ID-JAG token exchange
     - **pre-shared-key**: Static API key
     - **service-account**: HTTP Basic Auth
   - Auth-specific fields based on method
   - **Enabled**: Toggle to enable/disable
4. Click **Create**

### Authentication Methods

**Okta Cross-App (ID-JAG)**
- Target Authorization Server URL
- Target Client ID
- Target Client Secret

**Pre-Shared Key**
- API Key Header Name (default: `X-API-Key`)
- API Key Value

**Service Account**
- Username
- Password

### Pre-Consent Links

Pre-consent links allow admins to send users a URL that triggers re-verification of STS-managed connections (vault secrets, service accounts) without restarting their MCP client. When a user clicks the link, they authenticate against the agent's Okta app and are presented with a consent interstitial that walks them through authorizing each STS connection.

**URL format:**

```
{GATEWAY_BASE_URL}/oauth/pre-consent?agent_id={AGENT_ID}
```

- `agent_id` (required): The agent identifier whose STS connections should be verified.
- `resource` (optional): Scope the flow to a single resource instead of all STS connections.

Example with resource scoping:

```
https://gateway.example.com/oauth/pre-consent?agent_id=claude-code&resource=hr-vault
```

**Using the Admin UI:**

1. Navigate to an agent's detail page.
2. Open the **Configuration** tab.
3. The **Pre-Consent Link** section displays the full URL with a **Copy link** button.
4. For STS-type connections (vault secrets, service accounts), each linked resource card also has a **Pre-consent** button that copies a resource-scoped link.

**Requirements:** The user clicking the link must be assigned to the agent's Okta app, otherwise Okta will deny authentication. The adapter never sees the callback in this case.

**Constructing links outside the UI:** Admins can build pre-consent links manually for use in email templates, Slack bots, or automation by following the URL format above. The gateway base URL is the same URL used to access the adapter (e.g., `http://localhost:8000` in development).

## Development

### Project Structure

```
okta_agent_proxy_admin_ui/
├── app/                  # Next.js app router
├── components/           # React components
│   └── ui/              # Reusable UI components
├── contexts/            # React contexts (auth)
├── lib/                 # Utilities and API client
├── public/              # Static assets
├── package.json         # Dependencies
├── tsconfig.json        # TypeScript config
├── tailwind.config.ts   # Tailwind CSS config
└── next.config.js       # Next.js config
```

### Adding New Features

1. Create new page in `app/dashboard/`
2. Add route to navigation in `app/dashboard/layout.tsx`
3. Use existing UI components from `components/ui/`
4. Add API methods to `lib/api-client.ts` if needed

### Styling Guidelines

- Use Tailwind utility classes
- Follow existing color scheme (primary, secondary, destructive, etc.)
- Use Radix UI components for accessibility
- Keep responsive design in mind (mobile-first)

## API Client Reference

### Authentication

```typescript
await apiClient.login(username, password)
apiClient.clearToken()
```

### Agents

```typescript
await apiClient.listAgents()
await apiClient.getAgent(agentId)
await apiClient.createAgent(agentData)
await apiClient.updateAgent(agentId, agentData)
await apiClient.deleteAgent(agentId)
```

### Backends

```typescript
await apiClient.listBackends()
await apiClient.getBackend(backendId)
await apiClient.createBackend(backendData)
await apiClient.updateBackend(backendId, backendData)
await apiClient.deleteBackend(backendId)
```

## Troubleshooting

**Cannot connect to API**
- Verify the gateway is running on the configured URL
- Check `NEXT_PUBLIC_API_URL` in `.env.local`
- Ensure CORS is configured if running on different domain

**Login fails**
- Verify admin credentials in gateway configuration
- Check gateway logs for authentication errors
- Ensure PostgreSQL database is accessible

**Changes not reflected**
- Check browser console for errors
- Verify API response in Network tab
- Restart Next.js dev server

**Build errors**
- Clear `.next` directory: `rm -rf .next`
- Delete `node_modules` and reinstall: `rm -rf node_modules && npm install`
- Check for TypeScript errors: `npm run type-check`

## Security Considerations

- **Token Storage**: JWT tokens are stored in localStorage (client-side only)
- **HTTPS**: Always use HTTPS in production
- **CORS**: Configure CORS properly on the gateway
- **Secret Handling**: Sensitive fields are masked in forms and not displayed after creation
- **Audit Logging**: All changes are logged in the gateway's audit log

## Contributing

This admin UI is part of the Okta MCP Adapter project. See the main repository README for contribution guidelines.

## License

See the main repository for license information.

## Support

For issues and questions:
- Check the main repository documentation
- Review gateway logs for API errors
- Open an issue on GitHub

