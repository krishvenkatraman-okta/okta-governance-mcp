# Admin UI - Development Guide

## Project Structure

```
okta_agent_proxy_admin_ui/
├── app/                      # Next.js App Router
│   ├── globals.css          # Global styles and Tailwind imports
│   ├── layout.tsx           # Root layout
│   ├── page.tsx             # Root page (redirects to /login)
│   ├── login/
│   │   └── page.tsx         # Login page
│   └── dashboard/
│       ├── layout.tsx       # Dashboard layout with navigation
│       ├── page.tsx         # Dashboard overview
│       ├── agents/
│       │   └── page.tsx     # Agent management
│       └── backends/
│           └── page.tsx     # Backend management
├── components/
│   └── ui/                  # Reusable UI components (Radix + Tailwind)
│       ├── button.tsx
│       ├── card.tsx
│       ├── dialog.tsx
│       ├── input.tsx
│       ├── label.tsx
│       ├── textarea.tsx
│       ├── toast.tsx
│       ├── toaster.tsx
│       └── use-toast.ts
├── contexts/
│   └── auth-context.tsx     # Authentication context provider
├── lib/
│   ├── api-client.ts        # Admin API client
│   └── utils.ts             # Utility functions
├── public/                  # Static assets
├── package.json             # Dependencies
├── tsconfig.json            # TypeScript configuration
├── tailwind.config.ts       # Tailwind CSS configuration
├── next.config.js           # Next.js configuration
└── README.md                # Documentation
```

## Development Workflow

### 1. Initial Setup

```bash
# Install dependencies
npm install

# Start development server
npm run dev
```

The dev server runs at `http://localhost:3001` with hot reload enabled.

### 2. Making Changes

**Add a new page:**

1. Create a new directory under `app/dashboard/`
2. Add a `page.tsx` file
3. Update navigation in `app/dashboard/layout.tsx`

**Add a new UI component:**

1. Create component in `components/ui/`
2. Use Radix UI primitives for accessibility
3. Style with Tailwind utility classes
4. Export for use in pages

**Add a new API endpoint:**

1. Add method to `lib/api-client.ts`
2. Define TypeScript interface if needed
3. Use in page component with error handling

### 3. Testing Changes

```bash
# Type checking
npm run type-check

# Linting
npm run lint

# Build for production (verify no errors)
npm run build
```

### 4. Code Style

**TypeScript:**
- Use strict mode (enabled in tsconfig.json)
- Define interfaces for all data structures
- Use async/await for API calls
- Handle errors with try/catch

**React:**
- Use functional components with hooks
- Use "use client" directive for client components
- Keep components small and focused
- Extract reusable logic into custom hooks

**Styling:**
- Use Tailwind utility classes
- Follow existing color scheme (primary, secondary, etc.)
- Keep responsive design in mind (mobile-first)
- Use Radix UI for accessibility

## Adding New Features

### Example: Add a Settings Page

**1. Create the page:**

```typescript
// app/dashboard/settings/page.tsx
"use client"

import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';

export default function SettingsPage() {
  return (
    <div className="space-y-6">
      <h2 className="text-3xl font-bold tracking-tight">Settings</h2>
      <Card>
        <CardHeader>
          <CardTitle>Configuration</CardTitle>
        </CardHeader>
        <CardContent>
          {/* Settings form */}
        </CardContent>
      </Card>
    </div>
  );
}
```

**2. Add navigation:**

```typescript
// app/dashboard/layout.tsx
const navItems = [
  { href: '/dashboard', label: 'Overview', icon: Home },
  { href: '/dashboard/agents', label: 'Agents', icon: Users },
  { href: '/dashboard/backends', label: 'Backends', icon: Server },
  { href: '/dashboard/settings', label: 'Settings', icon: Settings }, // Add this
];
```

**3. Add API methods (if needed):**

```typescript
// lib/api-client.ts
async getSettings(): Promise<Settings> {
  return this.request<Settings>('/api/admin/settings');
}

async updateSettings(settings: Partial<Settings>): Promise<Settings> {
  return this.request<Settings>('/api/admin/settings', {
    method: 'PUT',
    body: JSON.stringify(settings),
  });
}
```

## Common Patterns

### Loading State

```typescript
const [loading, setLoading] = useState(true);

useEffect(() => {
  loadData();
}, []);

const loadData = async () => {
  try {
    const data = await apiClient.listAgents();
    setAgents(data);
  } catch (error) {
    toast({ title: "Error", description: "Failed to load data", variant: "destructive" });
  } finally {
    setLoading(false);
  }
};

if (loading) {
  return <div>Loading...</div>;
}
```

### Form Handling

```typescript
const [formData, setFormData] = useState({
  field1: '',
  field2: '',
});

const handleSave = async () => {
  try {
    await apiClient.createAgent(formData);
    toast({ title: "Success", description: "Saved successfully" });
    loadData();
  } catch (error) {
    toast({ title: "Error", description: error.message, variant: "destructive" });
  }
};

<Input
  value={formData.field1}
  onChange={(e) => setFormData({ ...formData, field1: e.target.value })}
/>
```

### Dialog Management

```typescript
const [dialogOpen, setDialogOpen] = useState(false);
const [editingItem, setEditingItem] = useState<Item | null>(null);

const handleCreate = () => {
  setEditingItem(null);
  setDialogOpen(true);
};

const handleEdit = (item: Item) => {
  setEditingItem(item);
  setDialogOpen(true);
};

<Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
  <DialogContent>
    {/* Form */}
  </DialogContent>
</Dialog>
```

## Debugging

### Enable Verbose Logging

```typescript
// lib/api-client.ts
private async request<T>(endpoint: string, options: RequestInit = {}): Promise<T> {
  console.log('API Request:', endpoint, options); // Add this
  const response = await fetch(`${API_BASE_URL}${endpoint}`, { ...options });
  console.log('API Response:', response.status, response.statusText); // Add this
  // ...
}
```

### Check Network Requests

Open browser DevTools → Network tab to inspect:
- Request URL and method
- Request headers (Authorization, Content-Type)
- Request body
- Response status and body

### Common Issues

**401 Unauthorized:**
- Token expired (logout and login again)
- Token not sent (check Authorization header)
- Invalid credentials

**CORS errors:**
- Check NEXT_PUBLIC_API_URL in .env.local
- Verify gateway CORS configuration
- Use proxy in next.config.js (already configured)

**TypeScript errors:**
- Run `npm run type-check` to see all errors
- Check interface definitions match API responses
- Use `unknown` type if uncertain, then narrow with type guards

## Performance Optimization

### Code Splitting

Next.js automatically code-splits by route. For large components:

```typescript
import dynamic from 'next/dynamic';

const HeavyComponent = dynamic(() => import('./HeavyComponent'), {
  loading: () => <div>Loading...</div>,
});
```

### Memoization

```typescript
import { useMemo } from 'react';

const filteredData = useMemo(() => {
  return data.filter(/* expensive filter */);
}, [data]);
```

### Debouncing

```typescript
import { useEffect, useState } from 'react';

const [searchTerm, setSearchTerm] = useState('');

useEffect(() => {
  const timer = setTimeout(() => {
    // Perform search
  }, 500);
  return () => clearTimeout(timer);
}, [searchTerm]);
```

## Deployment Checklist

- [ ] Update NEXT_PUBLIC_API_URL for production
- [ ] Run `npm run build` successfully
- [ ] Test production build locally with `npm start`
- [ ] Enable HTTPS
- [ ] Configure environment variables on hosting platform
- [ ] Test authentication flow
- [ ] Test CRUD operations for agents and backends
- [ ] Verify error handling and toast notifications

## Useful Resources

- [Next.js Documentation](https://nextjs.org/docs)
- [Radix UI Documentation](https://www.radix-ui.com/docs/primitives)
- [Tailwind CSS Documentation](https://tailwindcss.com/docs)
- [TypeScript Handbook](https://www.typescriptlang.org/docs/handbook/intro.html)
