# Docker Deployment Guide - Admin UI

Complete guide for deploying the Admin UI with Docker.

## Quick Start (Docker Compose)

The admin UI is included in the main `docker-compose.yml` at the repository root:

```bash
# From repository root
./setup.sh
```

This will:
- Build and start all services (PostgreSQL, Redis, Gateway, Admin UI, HR Backend)
- Wait for services to become healthy
- Run smoke tests
- Display connection information

The admin UI will be available at: **http://localhost:3001**

## Manual Docker Commands

### Build the Image

```bash
cd okta_agent_proxy_admin_ui
docker build -t okta-mcp-admin-ui:latest .
```

### Run the Container

```bash
docker run -d \
  --name okta-mcp-admin-ui \
  -p 3001:3001 \
  -e NEXT_PUBLIC_API_URL=http://gateway:8000 \
  -e NODE_ENV=production \
  --network mcp-network \
  okta-mcp-admin-ui:latest
```

### Stop and Remove

```bash
docker stop okta-mcp-admin-ui
docker rm okta-mcp-admin-ui
```

## Docker Compose Configuration

The admin UI service is defined in the main `docker-compose.yml`:

```yaml
admin-ui:
  build:
    context: ./okta_agent_proxy_admin_ui
    dockerfile: Dockerfile
  image: okta-agent-proxy-admin-ui:latest
  container_name: okta-mcp-admin-ui

  depends_on:
    okta-agent-mcp-adapter:
      condition: service_healthy

  ports:
    - "3001:3001"

  environment:
    NEXT_PUBLIC_API_URL: http://okta-agent-mcp-adapter:8000
    NEXT_PUBLIC_APP_NAME: Okta MCP Adapter Admin
    NODE_ENV: production
    PORT: "3001"
    HOSTNAME: "0.0.0.0"

  healthcheck:
    test: ["CMD", "wget", "--no-verbose", "--tries=1", "--spider", "http://localhost:3001/"]
    interval: 30s
    timeout: 5s
    retries: 3
    start_period: 20s

  restart: unless-stopped

  networks:
    - mcp-network
```

## Environment Variables

### Build-time Variables

These are baked into the build:

- `NODE_ENV` - Set to `production` for optimized builds
- `NEXT_TELEMETRY_DISABLED` - Disable Next.js telemetry

### Runtime Variables

These can be changed when starting the container:

- `NEXT_PUBLIC_API_URL` - Gateway API URL (default: `http://okta-agent-mcp-adapter:8000`)
  - For docker-compose: Use internal service name
  - For standalone: Use external URL (e.g., `http://localhost:8000`)
- `NEXT_PUBLIC_APP_NAME` - Application name shown in UI
- `PORT` - Port the app listens on (default: `3001`)
- `HOSTNAME` - Bind address (default: `0.0.0.0`)

## Networking

### Docker Compose Network

The admin UI connects to the gateway via the `mcp-network` bridge network:

```yaml
networks:
  mcp-network:
    driver: bridge
```

Inside the network:
- Admin UI → Gateway: `http://okta-agent-mcp-adapter:8000`
- Gateway → PostgreSQL: `postgresql://postgres:5432/gateway_db`
- Gateway → Redis: `redis://redis:6379/0`

### External Access

From the host machine:
- Admin UI: `http://localhost:3001`
- Gateway: `http://localhost:8000`

## Multi-stage Build Process

The Dockerfile uses a multi-stage build for efficiency:

### Stage 1: Dependencies (`deps`)
- Install production dependencies only
- Cache layer for faster rebuilds

### Stage 2: Builder (`builder`)
- Copy source code
- Run Next.js build with standalone output
- Generate optimized production bundle

### Stage 3: Runner (`runner`)
- Minimal Alpine-based image
- Copy only built artifacts
- Run as non-root user (`nextjs`)
- Expose port 3001

## Health Checks

The health check verifies the admin UI is responding:

```bash
wget --no-verbose --tries=1 --spider http://localhost:3001/
```

Health check parameters:
- **Interval**: 30 seconds (check every 30s)
- **Timeout**: 5 seconds (fail if no response in 5s)
- **Retries**: 3 (3 consecutive failures = unhealthy)
- **Start period**: 20 seconds (grace period during startup)

## Resource Limits

Recommended resource allocation:

```yaml
deploy:
  resources:
    limits:
      cpus: '0.5'
      memory: 256M
    reservations:
      cpus: '0.25'
      memory: 128M
```

Adjust based on:
- Number of concurrent users
- Server hardware capabilities
- Other services on the same host

## Logging

Logs are written to Docker's JSON file driver:

```yaml
logging:
  driver: "json-file"
  options:
    max-size: "10m"
    max-file: "3"
```

View logs:
```bash
docker compose logs -f admin-ui
```

## Production Deployment

### 1. Environment Configuration

Create a production `.env` file:

```bash
# Gateway Configuration
NEXT_PUBLIC_API_URL=https://gateway.example.com
NEXT_PUBLIC_APP_NAME=Okta MCP Adapter Admin

# Node.js Configuration
NODE_ENV=production
```

### 2. Build and Start

```bash
docker compose up -d admin-ui
```

### 3. Verify Deployment

```bash
# Check container status
docker compose ps admin-ui

# Check health
curl -f http://localhost:3001/

# View logs
docker compose logs -f admin-ui
```

### 4. HTTPS Setup

For production, use a reverse proxy with SSL:

**Nginx Example:**

```nginx
server {
    listen 443 ssl http2;
    server_name admin.example.com;

    ssl_certificate /path/to/cert.pem;
    ssl_certificate_key /path/to/key.pem;

    location / {
        proxy_pass http://localhost:3001;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }
}
```

**Traefik Example:**

```yaml
labels:
  - "traefik.enable=true"
  - "traefik.http.routers.admin-ui.rule=Host(`admin.example.com`)"
  - "traefik.http.routers.admin-ui.entrypoints=websecure"
  - "traefik.http.routers.admin-ui.tls.certresolver=letsencrypt"
  - "traefik.http.services.admin-ui.loadbalancer.server.port=3001"
```

## Troubleshooting

### Container Won't Start

**Check logs:**
```bash
docker compose logs admin-ui
```

**Common issues:**
- Port 3001 already in use: Change port mapping in `docker-compose.yml`
- Gateway not accessible: Verify `NEXT_PUBLIC_API_URL` is correct
- Build failures: Clear Docker cache and rebuild

### Cannot Connect to Gateway

**Inside container:**
```bash
docker compose exec admin-ui wget -O- http://okta-agent-mcp-adapter:8000/.well-known/oauth-protected-resource
```

**From host:**
```bash
curl http://localhost:8000/.well-known/oauth-protected-resource
```

If gateway is unreachable, check:
- Gateway container is running and healthy
- Both containers are on same network
- Environment variable `NEXT_PUBLIC_API_URL` is correct

### Login Fails

**Verify admin credentials:**
```bash
docker compose exec okta-agent-mcp-adapter env | grep ADMIN
```

**Test API directly** (requires an Okta OAuth access token — see
[docs/OPERATIONS.md § Admin API Authentication](../docs/OPERATIONS.md#admin-api-authentication)):
```bash
# Should return 401 without bearer (proves the auth middleware is wired)
curl -s -o /dev/null -w '%{http_code}\n' http://localhost:8000/api/admin/agents

# Should return 200 with a valid Okta token
curl -H "Authorization: Bearer $OKTA_ADMIN_TOKEN" http://localhost:8000/api/admin/agents
```

### Performance Issues

**Check resource usage:**
```bash
docker stats okta-mcp-admin-ui
```

**Increase limits in docker-compose.yml:**
```yaml
deploy:
  resources:
    limits:
      cpus: '1.0'
      memory: 512M
```

## Updating the Admin UI

### Pull and Rebuild

```bash
# Stop current container
docker compose down admin-ui

# Rebuild image
docker compose build --no-cache admin-ui

# Start new container
docker compose up -d admin-ui
```

### Zero-downtime Update

```bash
# Build new image with tag
docker build -t okta-mcp-admin-ui:v2 ./okta_agent_proxy_admin_ui/

# Start new container
docker run -d --name admin-ui-new [same options] okta-mcp-admin-ui:v2

# Test new container
curl http://localhost:3002/

# Switch traffic (update proxy or swap ports)

# Remove old container
docker stop okta-mcp-admin-ui
docker rm okta-mcp-admin-ui
```

## Security Considerations

1. **Non-root User**: Container runs as user `nextjs` (UID 1001)
2. **Minimal Image**: Alpine-based for smaller attack surface
3. **No Secrets in Image**: All sensitive values via environment variables
4. **HTTPS**: Use reverse proxy with SSL in production
5. **Network Isolation**: Admin UI only accessible via defined ports
6. **Resource Limits**: Prevent resource exhaustion attacks

## Monitoring

### Health Check Endpoint

```bash
curl http://localhost:3001/
```

Returns HTTP 200 if healthy.

### Container Metrics

```bash
docker stats okta-mcp-admin-ui --no-stream
```

Shows CPU, memory, network, and disk usage.

### Log Monitoring

```bash
# Follow logs
docker compose logs -f admin-ui

# Last 100 lines
docker compose logs --tail=100 admin-ui

# JSON output for log aggregation
docker compose logs --json admin-ui
```

## Scaling

For high availability:

1. **Run multiple instances:**
   ```bash
   docker compose up -d --scale admin-ui=3
   ```

2. **Add load balancer** (nginx/traefik)

3. **Use shared session store** (Redis) if needed

Note: The current admin UI uses localStorage for JWT tokens (client-side), so no server-side session synchronization is required.
