import Image from 'next/image';

export function OktaLogo({
  className = "h-8",
  isDark = false
}: {
  className?: string;
  isDark?: boolean;
}) {
  return (
    <Image
      src={isDark ? "/okta-logo-dark.jpeg" : "/okta-logo.png"}
      alt="Okta"
      width={50}
      height={50}
      className={className}
      priority
      unoptimized
    />
  );
}
