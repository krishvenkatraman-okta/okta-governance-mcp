#!/bin/bash
set -e

echo "============================================"
echo "Okta MCP Adapter - Admin UI Setup"
echo "============================================"
echo ""

# Check Node.js version
if ! command -v node &> /dev/null; then
    echo "❌ Node.js is not installed. Please install Node.js 20+ first."
    echo "   Visit: https://nodejs.org/"
    exit 1
fi

NODE_VERSION=$(node -v | cut -d'v' -f2 | cut -d'.' -f1)
if [ "$NODE_VERSION" -lt 20 ]; then
    echo "❌ Node.js version must be 20 or higher. Current: $(node -v)"
    exit 1
fi

echo "✓ Node.js $(node -v) detected"
echo ""

# Install dependencies
echo "📦 Installing dependencies..."
npm install

echo ""
echo "✓ Dependencies installed"
echo ""

# Setup environment
if [ ! -f .env.local ]; then
    echo "⚙️  Creating .env.local from example..."
    cp .env.local.example .env.local
    echo "✓ .env.local created"
else
    echo "✓ .env.local already exists"
fi

echo ""
echo "============================================"
echo "✅ Setup Complete!"
echo "============================================"
echo ""
echo "Next steps:"
echo ""
echo "1. Ensure the Okta MCP Adapter gateway is running:"
echo "   cd .. && python -m okta_agent_proxy.main http"
echo ""
echo "2. Start the admin UI development server:"
echo "   npm run dev"
echo ""
echo "3. Open your browser to:"
echo "   http://localhost:3001"
echo ""
echo "4. Sign in with your Okta account (configured via ADMIN_UI_OKTA_*)."
echo "   The Admin UI uses NextAuth + Okta OIDC — no local password."
echo ""
echo "For production deployment, see README.md"
echo ""
