import { getSession } from 'next-auth/react';

export interface DcrRedirectPatternsResponse {
  patterns: string[];
  source: 'database' | 'default';
  updated_at: string | null;
  updated_by: string | null;
}

async function authHeaders(): Promise<Record<string, string>> {
  const session = await getSession();
  const token = session?.accessToken;
  return token ? { Authorization: `Bearer ${token}` } : {};
}

export async function getDcrRedirectPatterns(): Promise<DcrRedirectPatternsResponse> {
  const res = await fetch('/api/admin/dcr/policy/redirect-patterns', {
    method: 'GET',
    credentials: 'include',
    headers: await authHeaders(),
  });
  if (!res.ok) {
    const body = await res.json().catch(() => ({}));
    throw new Error(body.message || `Failed to load redirect patterns (${res.status})`);
  }
  return res.json();
}

export async function updateDcrRedirectPatterns(
  patterns: string[],
): Promise<DcrRedirectPatternsResponse> {
  const res = await fetch('/api/admin/dcr/policy/redirect-patterns', {
    method: 'PUT',
    credentials: 'include',
    headers: {
      'Content-Type': 'application/json',
      ...(await authHeaders()),
    },
    body: JSON.stringify({ patterns }),
  });
  if (!res.ok) {
    const body = await res.json().catch(() => ({}));
    const err = new Error(body.message || `Failed to save redirect patterns (${res.status})`);
    (err as any).code = body.error;
    throw err;
  }
  return res.json();
}
