/**
 * Client-side redirect pattern validator.
 *
 * Mirrors the backend rules in okta_agent_proxy/auth/redirect_pattern_validator.py
 * for live UX feedback. The backend remains the source of truth.
 */

export class RedirectPatternError extends Error {
  constructor(message: string) {
    super(message);
    this.name = 'RedirectPatternError';
  }
}

export const DANGEROUS_SCHEMES: ReadonlySet<string> = new Set([
  'javascript', 'data', 'file', 'vbscript', 'about', 'blob',
  'ftp', 'ftps', 'gopher', 'telnet', 'ssh',
  'ws', 'wss', 'mailto', 'tel', 'sms',
  'ldap', 'ldaps',
]);

const LOOPBACK_HOSTS = new Set(['localhost', '127.0.0.1', '::1']);

const DNS_LABEL_RE = /^[a-z0-9]([a-z0-9-]*[a-z0-9])?$/i;

const SCHEME_RE = /^[a-z][a-z0-9.+-]*$/;

const PATH_SEGMENT_RE = /^[A-Za-z0-9._~:@!$&'()+,;=%-]+$/;

/**
 * Parse a URI into scheme, authority (host+port), hostname, port, and path.
 * Uses manual parsing to handle private-use schemes that the WHATWG URL
 * parser rejects, and to support wildcard ports.
 */
function parsePattern(pattern: string): {
  scheme: string;
  netloc: string;
  hostname: string | null;
  portStr: string | null;
  path: string;
} {
  const colonIdx = pattern.indexOf(':');
  if (colonIdx < 1) {
    return { scheme: '', netloc: '', hostname: null, portStr: null, path: '' };
  }

  const scheme = pattern.substring(0, colonIdx);
  let rest = pattern.substring(colonIdx + 1);

  let netloc = '';
  let path = rest;

  if (rest.startsWith('//')) {
    rest = rest.substring(2);
    // Find end of authority
    const pathStart = rest.indexOf('/');
    if (pathStart === -1) {
      netloc = rest;
      path = '';
    } else {
      netloc = rest.substring(0, pathStart);
      path = rest.substring(pathStart);
    }
  } else {
    // No authority — scheme-specific part (e.g., com.example.app:/callback)
    netloc = '';
    path = rest;
  }

  // Extract hostname and port from netloc
  let hostname: string | null = null;
  let portStr: string | null = null;

  if (netloc) {
    if (netloc.startsWith('[')) {
      // IPv6 bracketed: [::1]:port
      const bracketClose = netloc.lastIndexOf(']');
      if (bracketClose !== -1) {
        hostname = netloc.substring(1, bracketClose);
        const after = netloc.substring(bracketClose + 1);
        if (after.startsWith(':') && after.length > 1) {
          portStr = after.substring(1);
        }
      }
    } else if (netloc.includes(':')) {
      const lastColon = netloc.lastIndexOf(':');
      hostname = netloc.substring(0, lastColon);
      portStr = netloc.substring(lastColon + 1);
    } else {
      hostname = netloc;
    }

    if (hostname) {
      hostname = hostname.toLowerCase();
    }
  }

  return { scheme, netloc, hostname, portStr, path };
}

function validatePort(portStr: string | null): void {
  if (portStr === null) return;
  if (portStr === '*') return;
  if (/^\d+$/.test(portStr)) return;
  throw new RedirectPatternError(
    `port '${portStr}' must be a number or the literal '*'`
  );
}

function validatePath(path: string): void {
  if (!path) return;
  const segments = path.split('/');
  for (let i = 0; i < segments.length; i++) {
    const seg = segments[i];
    if (seg === '') {
      if (i === 0) continue; // leading slash
      if (i === segments.length - 1) continue; // trailing slash
      throw new RedirectPatternError(
        "path segment '' is empty; consecutive slashes are not permitted"
      );
    }
    if (seg === '*') continue;
    if (!PATH_SEGMENT_RE.test(seg)) {
      if (seg.includes('*')) {
        throw new RedirectPatternError(
          `path segment '${seg}' contains an embedded wildcard; use '*' as the entire segment`
        );
      }
      throw new RedirectPatternError(
        `path segment '${seg}' contains invalid characters`
      );
    }
  }
}

function validateFamilyA(
  hostname: string,
  portStr: string | null,
  path: string,
): void {
  if (!hostname) {
    throw new RedirectPatternError(
      'host must not be empty for http/https patterns'
    );
  }

  if (!hostname.includes('.')) {
    throw new RedirectPatternError(
      `host must contain at least one dot (got '${hostname}')`
    );
  }

  const labels = hostname.split('.');
  if (labels.length < 2) {
    throw new RedirectPatternError(
      `host must have at least two labels (got '${hostname}')`
    );
  }

  // Leftmost label: '*' or valid DNS label
  const leftmost = labels[0];
  if (leftmost !== '*') {
    if (leftmost.includes('*')) {
      throw new RedirectPatternError(
        `host label '${leftmost}' is not a valid wildcard; use '*' as the entire leftmost label`
      );
    }
    if (!DNS_LABEL_RE.test(leftmost)) {
      throw new RedirectPatternError(
        `host label '${leftmost}' is not a valid DNS label`
      );
    }
  }

  // Wildcard needs >= 3 labels
  if (leftmost === '*' && labels.length < 3) {
    throw new RedirectPatternError(
      `wildcard pattern must have at least two labels after '*' ` +
      `(e.g. '*.example.com'), but the rightmost label '${labels[labels.length - 1]}' is just a TLD`
    );
  }

  // Interior + TLD labels must be valid DNS
  for (let idx = 1; idx < labels.length; idx++) {
    const label = labels[idx];
    if (!label) {
      throw new RedirectPatternError(
        `host contains an empty label at position ${idx} ` +
        '(check for consecutive dots, trailing dot, or leading dot)'
      );
    }
    if (label.includes('*')) {
      throw new RedirectPatternError(
        `wildcard '*' is only allowed in the leftmost host label, ` +
        `but found in label '${label}' at position ${idx}`
      );
    }
    if (!DNS_LABEL_RE.test(label)) {
      throw new RedirectPatternError(
        `host label '${label}' at position ${idx} is not a valid DNS label`
      );
    }
  }

  // TLD: alphabetic, length >= 2
  const tld = labels[labels.length - 1];
  if (tld === '*') {
    throw new RedirectPatternError(
      'rightmost label (TLD) must not be a wildcard'
    );
  }
  if (!/^[a-zA-Z]+$/.test(tld)) {
    throw new RedirectPatternError(
      `rightmost label (TLD) '${tld}' must be alphabetic only`
    );
  }
  if (tld.length < 2) {
    throw new RedirectPatternError(
      `rightmost label (TLD) '${tld}' must be at least 2 characters`
    );
  }

  validatePort(portStr);
  validatePath(path);
}

function validateFamilyB(
  scheme: string,
  portStr: string | null,
  path: string,
): void {
  if (scheme !== 'http') {
    throw new RedirectPatternError(
      `Family B loopback patterns must use the http scheme ` +
      `(got '${scheme}'); per RFC 8252 §8.3, loopback redirects use ` +
      `http because the redirect never leaves the device`
    );
  }
  validatePort(portStr);
  validatePath(path);
}

function validateFamilyC(
  pattern: string,
  scheme: string,
  netloc: string,
  path: string,
): void {
  if (!SCHEME_RE.test(scheme)) {
    throw new RedirectPatternError(
      `scheme '${scheme}' is not a valid URI scheme; ` +
      'must match [a-z][a-z0-9.+-]* (lowercase only)'
    );
  }

  if (scheme.includes('*')) {
    throw new RedirectPatternError(
      `wildcard '*' is not allowed in the scheme '${scheme}'`
    );
  }

  if (netloc && netloc.includes('*')) {
    throw new RedirectPatternError(
      `authority '${netloc}' must not contain wildcards in ` +
      'private-use scheme patterns'
    );
  }

  // Must have non-empty content after scheme:
  const colonIdx = pattern.indexOf(':');
  const afterColon = pattern.substring(colonIdx + 1);
  if (!afterColon) {
    throw new RedirectPatternError(
      `private-use scheme pattern must have a non-empty path after '${scheme}:'`
    );
  }

  validatePath(path);
}

export function validateRedirectPattern(pattern: string): void {
  // Common Rule 1: type, length, no whitespace, no control chars
  if (typeof pattern !== 'string') {
    throw new RedirectPatternError('pattern must be a string');
  }
  if (pattern.length === 0) {
    throw new RedirectPatternError('pattern must not be empty (length 0)');
  }
  if (pattern.length > 512) {
    throw new RedirectPatternError(
      `pattern must not exceed 512 characters (got ${pattern.length})`
    );
  }
  for (let i = 0; i < pattern.length; i++) {
    const ch = pattern[i];
    if (/\s/.test(ch)) {
      throw new RedirectPatternError(
        `pattern contains whitespace at index ${i}`
      );
    }
    const code = pattern.charCodeAt(i);
    if (code < 0x20 || code === 0x7f) {
      throw new RedirectPatternError(
        `pattern contains control character at index ${i} (ord 0x${code.toString(16)})`
      );
    }
  }

  // Common Rule 2: parse
  const parsed = parsePattern(pattern);

  // Common Rule 3: no query or fragment
  if (pattern.includes('?')) {
    throw new RedirectPatternError(
      'query strings and fragments are not allowed in redirect patterns'
    );
  }
  if (pattern.includes('#')) {
    throw new RedirectPatternError(
      'query strings and fragments are not allowed in redirect patterns'
    );
  }

  // Common Rule 4: scheme present and lowercase
  const { scheme } = parsed;
  if (!scheme) {
    const colonIdx = pattern.indexOf(':');
    if (colonIdx > 0) {
      const rawCandidate = pattern.substring(0, colonIdx);
      if (rawCandidate.includes('*')) {
        throw new RedirectPatternError(
          `wildcard '*' is not allowed in the scheme '${rawCandidate}'`
        );
      }
    }
    throw new RedirectPatternError(
      "pattern must be an absolute URI with a scheme (e.g. 'https://example.com/cb')"
    );
  }

  const colonIdx = pattern.indexOf(':');
  const rawScheme = pattern.substring(0, colonIdx);
  if (rawScheme !== rawScheme.toLowerCase()) {
    throw new RedirectPatternError(
      `scheme '${rawScheme}' must be lowercase; use '${rawScheme.toLowerCase()}'`
    );
  }

  // Common Rule 5: dangerous scheme deny list
  if (DANGEROUS_SCHEMES.has(scheme)) {
    throw new RedirectPatternError(
      `scheme '${scheme}' is not allowed (dangerous scheme)`
    );
  }

  // Family detection
  const { hostname, portStr, path, netloc } = parsed;
  if ((scheme === 'http' || scheme === 'https') && hostname && LOOPBACK_HOSTS.has(hostname)) {
    validateFamilyB(scheme, portStr, path);
  } else if (scheme === 'http' || scheme === 'https') {
    validateFamilyA(hostname || '', portStr, path);
  } else {
    validateFamilyC(pattern, scheme, netloc, path);
  }
}

export function validateRedirectPatterns(patterns: string[]): string[] {
  // Strip, drop empties, dedupe preserving order
  const stripped = patterns.map(p => p.trim());
  const nonEmpty = stripped.filter(p => p.length > 0);

  const seen = new Set<string>();
  const unique: string[] = [];
  for (const p of nonEmpty) {
    if (!seen.has(p)) {
      seen.add(p);
      unique.push(p);
    }
  }

  // Validate each
  for (let idx = 0; idx < unique.length; idx++) {
    try {
      validateRedirectPattern(unique[idx]);
    } catch (e) {
      if (e instanceof RedirectPatternError) {
        throw new RedirectPatternError(
          `pattern[${idx}] '${unique[idx]}': ${e.message}`
        );
      }
      throw e;
    }
  }

  return unique;
}
