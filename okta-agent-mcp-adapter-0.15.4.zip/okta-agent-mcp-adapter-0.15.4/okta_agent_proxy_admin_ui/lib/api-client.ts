import { getSession, signOut } from 'next-auth/react';

// Always use empty string to leverage Next.js API route proxy
// The /app/api/admin/[...path]/route.ts handler proxies to the gateway
const API_BASE_URL = '';

export interface Agent {
  agent_id: string;
  agent_name?: string;
  client_id: string;
  client_secret?: string;
  private_key?: string;

  enabled: boolean;
  dcr_selectable?: boolean;
  principal_id?: string;
  cimd_client_id_url?: string;
  okta_ai_agent_id?: string;
  registration_source?: string;
  metadata?: Record<string, any>;
  created_at?: string;
  updated_at?: string;
}

export interface Resource {
  id?: number;
  name: string;
  type?: string;
  url?: string;
  mcp_url?: string;
  protocol?: string;
  description: string;
  config?: Record<string, any>;
  tags?: string[];
  enabled?: boolean;

  // Provenance (set by sync)
  agent_id?: string;
  connection_id?: string;

  // Okta-sourced (set by sync)
  connection_type?: string;
  connection_resource_id?: string | null;
  scopes?: string[];
  scope_condition?: string;
  auth_method?: string | null;
  metadata?: Record<string, any>;

  created_at?: string;
  updated_at?: string;
}

// Backward-compat alias
export type ResourceMapEntry = Resource;

export interface SyncResult {
  added: string[];
  removed: string[];
  modified: string[];
  unresolved: string[];
  total: number;
  synced_at: string;
}

export interface ConnectionStatus {
  syncer: {
    last_sync_at: string | null;
    status: string;
    is_stale: boolean;
    resources_count: number;
    unresolved_count: number;
  };
  last_persisted_state: {
    last_sync_at: string | null;
    status: string;
    resources_count: number;
    unresolved_count: number;
    sync_duration_ms: number;
  } | null;
}

export interface AuditLogEntry {
  id: number;
  changed_at: string;
  action: string;
  entity_type?: string;
  entity_id?: string;
  changed_by?: string;
  ip_address?: string;
  user_agent?: string;
  changes?: Record<string, any>;
  details?: Record<string, any>;
}

export interface OktaAgent {
  okta_agent_id: string;
  name: string;
  description: string;
  status: string;
  app_id: string | null;
  linked_app_client_id: string | null;
  connections_count: number;
  already_imported: boolean;
}

export interface OktaAgentDetail {
  agent: Record<string, any>;
  connections: Array<{
    connection: Record<string, any>;
    matched_resource: string | null;
  }>;
  linked_app: {
    app_id: string | null;
    client_id: string | null;
    label: string | null;
  } | null;
}

export interface ImportResult {
  success: boolean;
  agent_name: string;
  okta_agent_id: string;
  message: string;
  resources_linked: string[];
  warnings: string[];
}

export interface SyncAllResult {
  agents: {
    results: ImportResult[];
    synced: number;
    failed: number;
    unchanged: number;
  };
  resources: {
    resources_updated: string[];
    unchanged: string[];
  };
}

// A Connection's resource row (0 or 1 per agent+connection pair)
export interface ConnectionResource {
  id?: number;
  agent_id?: string;
  connection_id?: string;
  name: string;
  type?: string;
  url?: string;
  description?: string;
  connection_type?: string;
  connection_resource_id?: string | null;
  scopes?: string[];
  scope_condition?: string;
  auth_method?: string | null;
  metadata?: Record<string, any>;
  enabled?: boolean;
}

// Connection from Okta with its single resource row (or null)
export interface AgentConnection {
  connection_id: string;
  connection_type: 'IDENTITY_ASSERTION_CUSTOM_AS' | 'STS_VAULT_SECRET' | 'STS_SERVICE_ACCOUNT' | 'STS_ACCESS_TOKEN' | 'SECRET' | 'SERVICE_ACCOUNT';
  display_name: string;
  resource_id: string;
  resource_indicator: string;
  scopes: string[];
  scope_condition: 'INCLUDE_ONLY' | 'DISALLOW' | 'ALLOW_ALL' | null;
  status: string;
  resource: ConnectionResource | null;
}

// Full agent detail with connections
export interface AgentDetail {
  agent: Agent;
  okta_agent: Record<string, any> | null;
  connections: AgentConnection[];
  linked_app: {
    app_id: string | null;
    client_id: string | null;
    label: string | null;
  } | null;
  stats: {
    total_connections: number;
    fully_linked_count: number;
    partially_linked_count: number;
    unlinked_count: number;
    inactive_count: number;
    total_resources: number;
    total_tools: number;
  };
}

// Tool catalog (read from gateway cache, not a persistent store)
export interface AgentTool {
  name: string;
  description?: string;
  inputSchema?: Record<string, any>;
}

export interface AgentToolsResourceGroup {
  resource_name: string;
  tool_count: number;
  tools: AgentTool[];
}

export interface AgentToolsResponse {
  agent_id: string;
  cached: boolean;
  total_tools: number;
  resources: AgentToolsResourceGroup[];
}

// Response from GET /api/admin/agents/{agentId}/connections
export interface AgentConnectionsResponse {
  agent: Agent;
  connections: AgentConnection[];
  stats: {
    total_connections: number;
    fully_linked_count: number;
    unlinked_count: number;
    inactive_count: number;
    total_resources: number;
    total_tools: number;
  };
}

export interface ApiError {
  error: string;
  message: string;
  required_scopes?: string[];
}

export interface PublicConfig {
  gateway_base_url: string;
}

export interface CredentialStatus {
  has_client_secret: boolean;
  has_private_key: boolean;
  registered_keys: { kid: string; alg: string }[];
  okta_agent_id: string | null;
}

export interface FetchSecretResult {
  status: string;
  source: string;
  app_id: string;
}

export interface GenerateKeyPairResult {
  status: string;
  kid: string;
  agent_id: string;
}

export interface ForceLogoutSummary {
  user_sub: string;
  correlation_id: string;
  tokens_revoked: number;
  cache_swept: boolean;
  sessions_terminated: number;
  sessions_failed: number;
  backends: Record<string, boolean>;
  // Added in v0.15.x: relay-tracked CIMD/DCR tokens purged for this user.
  relay_tokens_revoked?: number;
  // Added in v0.15.x: true when the user's sub was added to the revocation
  // registry so in-flight Okta JWTs are rejected on the hot request path.
  sub_marked_revoked?: boolean;
}

export interface ForceLogoutInput {
  email?: string;
  sub?: string;
}

export class ApiClient {
  // Get Okta access token from NextAuth session
  private async getToken(): Promise<string | null> {
    if (typeof window === 'undefined') {
      return null;
    }

    const session = await getSession();
    return session?.accessToken || null;
  }

  // Legacy methods for backward compatibility (no longer used)
  setToken(_token: string) {
    // No-op - tokens come from NextAuth session now
    console.warn('ApiClient.setToken() is deprecated - tokens come from Okta session');
  }

  clearToken() {
    // No-op - session is cleared by NextAuth signOut
    console.warn('ApiClient.clearToken() is deprecated - use signOut() instead');
  }

  private async request<T>(
    endpoint: string,
    options: RequestInit = {}
  ): Promise<T> {
    const headers: Record<string, string> = {
      'Content-Type': 'application/json',
      ...(options.headers as Record<string, string>),
    };

    // Get Okta access token from NextAuth session
    const token = await this.getToken();

    console.log('[ApiClient] Endpoint:', endpoint);
    console.log('[ApiClient] Token type:', token ? 'Okta OAuth' : 'none');

    if (token) {
      headers['Authorization'] = `Bearer ${token}`;
    }

    const response = await fetch(`${API_BASE_URL}${endpoint}`, {
      ...options,
      headers,
    });

    if (!response.ok) {
      const error = await response.json().catch(() => ({
        error: 'unknown_error',
        message: response.statusText
      }));

      // Handle session expiration - redirect to sign in
      if (response.status === 401) {
        console.log('[ApiClient] Session expired (401), redirecting to sign in...');
        // Sign out and redirect to login page
        // Use setTimeout to allow any pending UI updates (like toasts) to show
        setTimeout(() => {
          signOut({ redirect: true, callbackUrl: '/login' });
        }, 500);

        // Throw error with 401 status so pages can show appropriate message
        const err = new Error('Your Okta session has expired. Redirecting to sign in...') as Error & {
          status?: number;
          code?: string;
        };
        err.status = 401;
        err.code = 'session_expired';
        throw err;
      }

      // Provide actionable error messages for common auth failures
      let message = error.message || `HTTP ${response.status}`;
      if (response.status === 403) {
        if (error.error === 'insufficient_scopes') {
          message = 'Your Okta session lacks AI Agent management permissions. Go to your Okta app → Okta API Scopes tab and grant okta.aiAgents.read and okta.aiAgents.manage, then sign out and back in.';
        } else if (error.error === 'okta_auth_required') {
          message = 'Agent import requires Okta sign-in. Please sign out and use "Sign in with Okta".';
        }
      }

      const err = new Error(message) as Error & {
        status?: number;
        code?: string;
        required_scopes?: string[];
      };
      err.status = response.status;
      err.code = error.error;
      err.required_scopes = error.required_scopes;
      throw err;
    }

    // Handle 204 No Content responses (e.g., DELETE operations)
    if (response.status === 204) {
      return undefined as T;
    }

    return response.json();
  }

  // Authentication (DEPRECATED - use Okta OIDC via signIn())
  async login(_username: string, _password: string): Promise<{ access_token: string; token_type: string; expires_in: number }> {
    console.warn('ApiClient.login() is deprecated - use signIn() from next-auth/react instead');
    throw new Error('Legacy login is disabled. Please sign in with Okta.');
  }

  // Agents
  async listAgents(): Promise<Agent[]> {
    const response = await this.request<{ agents: Agent[] }>('/api/admin/agents');
    return response.agents;
  }

  async getAgent(agentId: string): Promise<Agent> {
    return this.request<Agent>(`/api/admin/agents/${agentId}`);
  }

  async createAgent(agent: Partial<Agent>): Promise<Agent> {
    return this.request<Agent>('/api/admin/agents', {
      method: 'POST',
      body: JSON.stringify(agent),
    });
  }

  async updateAgent(agentId: string, agent: Partial<Agent>): Promise<Agent> {
    return this.request<Agent>(`/api/admin/agents/${agentId}`, {
      method: 'PUT',
      body: JSON.stringify(agent),
    });
  }

  async deleteAgent(agentId: string): Promise<void> {
    await this.request(`/api/admin/agents/${agentId}`, {
      method: 'DELETE',
    });
  }

  // Resources
  async listResources(): Promise<Resource[]> {
    const response = await this.request<{ resources: Resource[] }>('/api/admin/resources');
    return response.resources;
  }

  // Backward-compat alias
  async listResolvedResources(): Promise<Resource[]> {
    return this.listResources();
  }

  async getResource(name: string): Promise<Resource> {
    return this.request<Resource>(`/api/admin/resources/${name}`);
  }

  // Backward-compat alias
  async getResolvedResource(name: string): Promise<Resource> {
    return this.getResource(name);
  }

  async updateResource(name: string, data: Partial<Resource>): Promise<Resource> {
    return this.request<Resource>(`/api/admin/resources/${name}`, {
      method: 'PUT',
      body: JSON.stringify(data),
    });
  }

  async deleteResource(name: string): Promise<void> {
    await this.request(`/api/admin/resources/${name}`, {
      method: 'DELETE',
    });
  }

  // Connection Sync
  async syncConnections(): Promise<SyncResult> {
    return this.request<SyncResult>('/api/admin/connections/sync', {
      method: 'POST',
    });
  }

  async getConnectionStatus(): Promise<ConnectionStatus> {
    return this.request<ConnectionStatus>('/api/admin/connections/status');
  }

  // Audit Log
  async getAuditLog(params?: {
    entity_type?: string;
    entity_id?: string;
    limit?: number;
  }): Promise<AuditLogEntry[]> {
    const queryParams = new URLSearchParams();
    if (params?.entity_type) queryParams.append('entity_type', params.entity_type);
    if (params?.entity_id) queryParams.append('entity_id', params.entity_id);
    if (params?.limit) queryParams.append('limit', params.limit.toString());

    const query = queryParams.toString();
    const endpoint = query ? `/api/admin/audit?${query}` : '/api/admin/audit';

    const response = await this.request<{ audit_log: AuditLogEntry[] }>(endpoint);
    return response.audit_log;
  }

  async getAgentAuditLog(agentId: string): Promise<AuditLogEntry[]> {
    const response = await this.request<{ audit_log: AuditLogEntry[] }>(
      `/api/admin/agents/${agentId}/audit`
    );
    return response.audit_log;
  }

  async getResourceAuditLog(name: string): Promise<AuditLogEntry[]> {
    const response = await this.request<{ audit_log: AuditLogEntry[] }>(
      `/api/admin/resources/${name}/audit`
    );
    return response.audit_log;
  }

  // Okta AI Agent Import
  async listOktaAgents(): Promise<OktaAgent[]> {
    const response = await this.request<{ agents: OktaAgent[] }>('/api/admin/okta/agents');
    return response.agents;
  }

  async getOktaAgentDetail(oktaAgentId: string): Promise<OktaAgentDetail> {
    return this.request<OktaAgentDetail>(`/api/admin/okta/agents/${oktaAgentId}`);
  }

  async importOktaAgent(
    oktaAgentId: string,
    options?: { resource_mapping?: Record<string, string>; agent_name?: string }
  ): Promise<ImportResult> {
    return this.request<ImportResult>(`/api/admin/okta/agents/${oktaAgentId}/import`, {
      method: 'POST',
      body: JSON.stringify(options || {}),
    });
  }

  async bulkImportOktaAgents(agentIds: string[]): Promise<{
    results: ImportResult[];
    imported: number;
    failed: number;
  }> {
    return this.request(`/api/admin/okta/agents/bulk-import`, {
      method: 'POST',
      body: JSON.stringify({ agent_ids: agentIds }),
    });
  }

  async syncOktaAgent(oktaAgentId: string): Promise<ImportResult> {
    return this.request<ImportResult>(`/api/admin/okta/agents/${oktaAgentId}/sync`, {
      method: 'POST',
    });
  }

  async syncAllAgents(): Promise<{
    results: ImportResult[];
    synced: number;
    failed: number;
    unchanged: number;
    connection_sync?: {
      resources_resolved: number;
      unresolved: number;
    };
  }> {
    return this.request(`/api/admin/okta/sync/agents`, { method: 'POST' });
  }

  async syncAllResources(): Promise<{
    resources_updated: string[];
    unchanged: string[];
  }> {
    return this.request(`/api/admin/okta/sync/resources`, { method: 'POST' });
  }

  async syncAll(): Promise<SyncAllResult> {
    return this.request<SyncAllResult>(`/api/admin/okta/sync/all`, { method: 'POST' });
  }

  // Agent Connections & Resource Linkage

  async getAgentConnections(agentId: string): Promise<AgentConnectionsResponse> {
    return this.request<AgentConnectionsResponse>(`/api/admin/agents/${agentId}/connections`);
  }

  async getAgentDetail(agentId: string): Promise<AgentDetail> {
    return this.request<AgentDetail>(`/api/admin/agents/${agentId}/connections`);
  }

  async getAgentTools(agentId: string): Promise<AgentToolsResponse> {
    return this.request<AgentToolsResponse>(`/api/admin/agents/${agentId}/tools`);
  }

  // Gateway Config (public metadata for user-facing URLs)

  async getPublicConfig(): Promise<PublicConfig> {
    return this.request<PublicConfig>('/api/admin/config/public');
  }

  // Credential Automation

  async getCredentialStatus(agentId: string): Promise<CredentialStatus> {
    return this.request<CredentialStatus>(`/api/admin/agents/${agentId}/credentials/status`);
  }

  async fetchClientSecret(agentId: string): Promise<FetchSecretResult> {
    return this.request<FetchSecretResult>(`/api/admin/agents/${agentId}/credentials/fetch-secret`, {
      method: 'POST',
    });
  }

  async generateKeyPair(agentId: string): Promise<GenerateKeyPairResult> {
    return this.request<GenerateKeyPairResult>(`/api/admin/agents/${agentId}/credentials/generate-keypair`, {
      method: 'POST',
    });
  }

  // Admin-initiated force logout
  async forceLogoutUser(input: ForceLogoutInput): Promise<ForceLogoutSummary> {
    return this.request<ForceLogoutSummary>('/api/admin/users/force-logout', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(input),
    });
  }
}

export const apiClient = new ApiClient();
