/** @type {import('next').NextConfig} */
const nextConfig = {
  reactStrictMode: true,
  output: 'standalone',
  // Removed rewrites - proxying is handled by app/api/admin/[...path]/route.ts
  // which can read runtime environment variables properly in Docker
}

module.exports = nextConfig
