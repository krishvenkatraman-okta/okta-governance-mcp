# Changelog

All notable changes to this project will be documented in this file.

## [Unreleased]

## [0.15.4] - 2026-05-13

### Fixed
- **Redis IAM auth: cap SigV4 token lifetime at 900s for ElastiCache.**
  `AwsIamElastiCacheProvider` was relying on a no-op `request.context["timeout"]`
  to set the presigned token's `X-Amz-Expires`, so `SigV4QueryAuth` fell through
  to its botocore default of 3600s. ElastiCache hard-caps IAM AUTH tokens at 900s
  and rejected every mint with the misleading error
  `invalid username-password pair or user is disabled`. The result was that the
  adapter "connected" to Redis but every `GET`/`SET` failed auth and silently fell
  back to L1 in-memory cache — breaking horizontal scaling and cross-worker
  cache sharing. The fix passes `expires=TOKEN_LIFETIME_SECONDS` directly to the
  `SigV4QueryAuth` constructor (where botocore actually reads it).
  (`okta_agent_proxy/cache/redis_credential_providers/aws_iam.py`)
- **Docker entrypoint: Redis preflight respects `REDIS_AUTH_MODE`.**
  The startup PING in `scripts/docker-entrypoint.sh` used a raw
  `redis.from_url(REDIS_URL).ping()` with no credential provider, so every
  `aws-iam` or `azure-entra` deployment saw the false-alarm warning
  `⚠ Redis is not available (Authentication required.) — falling back to in-memory cache.`
  The message was cosmetic (the runtime app still authenticated via its
  credential provider), but confusing. The preflight now emits
  `→ REDIS_AUTH_MODE=<mode> — skipping startup PING (runtime credential provider will authenticate).`
  for any non-`static` auth mode and only runs the raw PING when credentials can
  live in the URL itself.

## [0.15.2] - 2026-05-13

### Fixed
- **AWS ECS: IAM role names now derive from `project_name`.** The
  `iam_role_name_prefix` variable in `deploy/aws-ecs/variables.tf` defaulted
  to a hardcoded `"oktaps-mcp"`, which caused `EntityAlreadyExists` errors on
  redeploys when `project_name` differed. Default is now empty and falls back
  to `project_name`; `aws_iam_role.ecs_task_migrate` uses the shared local
  prefix alongside the other three roles.
- **AWS ECS: `DATABASE_URL` URL-encodes the generated DB password.**
  `random_password` can produce passwords containing `%=` and similar
  sequences that `psql` / `libpq` reject as invalid percent-encoding.
  `aws_secretsmanager_secret_version.db` now wraps the password substitution
  in `urlencode()` so the URL is always syntactically valid while the decoded
  password matches what RDS stores.

### Changed
- **AWS ECS: `ENCRYPTION_KEY` is now Terraform-owned with seed-once
  semantics.** A new `random_password.encryption_key` resource generates a
  32-byte value on first apply and stores it in state. The `app` Secrets
  Manager secret version uses `var.encryption_key` when supplied (preserves
  the `deploy.sh` / `.generated-secrets` workflow), else falls back to the
  random value. `lifecycle.ignore_changes = [secret_string]` on the secret
  version prevents subsequent applies from rewriting `ENCRYPTION_KEY=""` when
  the operator runs `terraform apply` directly without the `TF_VAR_*` exports
  `deploy.sh` injects. Rotation is now an explicit
  `terraform taint aws_secretsmanager_secret_version.app` + apply.
- **AWS ECS: operator-facing drift guardrails.** New
  `deploy/aws-ecs/terraform.tfvars.example` documents the drift-prone
  variables (ECR URLs, image tags, encryption key, admin UI Okta credentials)
  so operators can pin them in a local `terraform.tfvars` instead of
  re-exporting env vars on every apply. `.gitignore` excludes
  `terraform.tfvars` and `*.auto.tfvars`. README adds a top-of-file drift
  warning and a "Using `terraform.tfvars`" subsection explaining the recovery
  path via `AWSPREVIOUS` secret versions when `ENCRYPTION_KEY` has already
  been cleared.

## [0.15.1] - 2026-05-12

### Changed
- **Azure ACA deploy defaults to ECR Public images.** `deploy/azure-aca/scripts/deploy.sh` now pulls prebuilt images from `public.ecr.aws/${ECR_PUBLIC_ALIAS:-oktaps}/okta-mcp-{adapter,admin-ui,hr-server,deploy-server}` at tag `v<pyproject version>` by default — no ACR provisioned, single Bicep deployment (the previous infra → build → apps three-phase flow is replaced with a single `az deployment sub create` when `usePublicImages=true`). Opt into the previous `az acr build` flow with `--build-from-source`; add `--skip-build` to reuse already-pushed ACR images. `--tag=vX.Y.Z` overrides the public-image tag. Bicep adds `usePublicImages` (default `true`) and `publicImageRegistry` (default `public.ecr.aws/oktaps`) parameters; `modules/apps.bicep` and `modules/migrate-job.bicep` now take `imageRegistry` + per-image names instead of `acrLoginServer`; Container Apps omit the `registries` auth block when pulling from the public registry. For egress-controlled environments, customers can `az acr import` the public images into their own ACR and deploy with `--build-from-source --skip-build` — mirror instructions in the README. **Migration note:** existing ACA deployments that applied the build path before this flip keep working unchanged; their `.bicepparam` still names `usePublicImages=false` via the `USE_PUBLIC_IMAGES` env var (default `true`). To switch an existing deployment onto the public path, re-run without `--build-from-source` and `usePublicImages=true` propagates.
- **`deploy/azure-aca/package.sh` now produces two tarballs.** `--bundle=deploy` ships `deploy/azure-aca/`, `deploy/shell-lib/`, `deploy/migrations/sql/`, LICENSE, and pyproject.toml — the slim artifact customers need for the default public-image path. `--bundle=source` additionally ships the Dockerfile, adapter source, admin UI, and example servers for `--build-from-source` workflows. Default is `--bundle=both`. Names: `okta-ps-adapter-azure-aca-<ver>.tar.gz` (deploy-only, customer-facing default) and `okta-ps-adapter-azure-aca-source-<ver>.tar.gz`. Running `--build-from-source` from an extracted deploy-only bundle fails fast with a pointer to the source tarball.
- **AWS ECS deploy defaults to public ECR images.** `deploy/aws-ecs/deploy.sh` and `deploy/aws-ecs-examples/deploy.sh` now pull prebuilt images from `public.ecr.aws/${ECR_PUBLIC_ALIAS:-oktaps}/` at tag `v<pyproject version>` by default — no CodeBuild, no Docker, no private ECR repos, single-phase apply for examples. Opt into the previous build-and-push flow with `--build-from-source` (uses CodeBuild) or `--use-local-docker` (builds locally; implies `--build-from-source`). The intermediate `--use-public-images` flag is removed. **Existing tfstate migration:** operators who previously applied the build path will see Terraform plan to destroy `aws_ecr_repository.adapter` and `.admin_ui` on the next run — keep them by passing `--build-from-source`, or let them destroy after confirming the release tag exists under the public alias. If the `oktaps` ECR Public alias is still pending AWS approval, export `ECR_PUBLIC_ALIAS=<auto-assigned-alias>` before deploying.
- **`deploy/aws-ecs/package.sh` now produces two tarballs.** `--bundle=deploy` (≈440 KB, 45 files) ships `deploy/aws-ecs/`, `deploy/aws-ecs-examples/`, `deploy/shell-lib/`, `deploy/migrations/sql/`, LICENSE, and pyproject.toml — exactly what a customer needs to deploy against ECR Public images (including SQL files for the DBA handoff and local-exec fallback paths). `--bundle=source` (≈16 MB, full source) additionally ships the Dockerfile, adapter source, admin UI, and example servers — needed for `--build-from-source`. Default is `--bundle=both`. Names: `okta-ps-adapter-aws-ecs-<ver>.tar.gz` (deploy-only, the customer-facing default) and `okta-ps-adapter-aws-ecs-source-<ver>.tar.gz` (source). Running `--build-from-source` from an extracted deploy-only bundle fails fast with a pointer at the source tarball.

### Breaking
- **`resources` + `agent_connection_resource_linkage` collapsed into one table.** `resources` now has one row per `(agent_id, connection_id)` pair, materialized by the Okta syncer. There is no standalone-create path for resources. `agent_connection_resource_linkage` is gone; `LocalResourceSyncer` is gone. **No in-place upgrade** — drop the DB and re-run migrations, then re-import agents from Okta.
- **Admin API routes removed.** `POST /api/admin/resources`, all `/api/admin/linkages*` routes (`GET` / `POST` / `DELETE`), `POST /api/admin/agents/{agent_id}/connections/{connection_id}/link`, `POST /api/admin/agents/{agent_id}/connections/{connection_id}/unlink` (both `-resource` and non-`-resource` variants), and `POST /api/admin/agents/{agent_id}/connections/{connection_id}/create-resource`. Rows are created by Okta sync (disabled by default); admins edit `url` and flip `enabled` via `PUT /api/admin/resources/{name}`.
- **`ResourceConfigStore` shrunk.** `create_resource`, `enable_resource`, `disable_resource` are removed from the ABC. `update_resource` now rejects sync-owned fields (`scopes`, `scope_condition`, `connection_type`, `auth_method`, `metadata`, `agent_id`, `connection_id`, `connection_resource_id`).
- **Admin UI rework.** "New Resource" button and create dialog removed. Agent detail page: link/unlink/create-for-connection dialogs removed. Each connection now shows exactly one resource row with inline edit of URL + enabled. `apiClient.createResource` / `linkConnectionResource` / `unlinkConnectionResource` / `createResourceForConnection` removed from `lib/api-client.ts`.

### Added
- **Admin API now accepts Okta service-app tokens** (`client_credentials` + `private_key_jwt`) alongside Admin UI human tokens. Enables unattended automation (CI/CD, integration tests, scripted provisioning) without stored user credentials or refresh tokens. Service-app `cid` must appear in the new `ADMIN_API_SERVICE_CLIENT_IDS` env (comma-separated; empty/unset disables service-app auth). Both principal types share the Okta org-AS issuer and JWKS — no validator changes. Audit events attribute service-app actions via `actor.client_id` and `actor.user_id = service_app:<cid>`. Scope enforcement is deferred; the `cid` allowlist is the authorization gate. See `docs/ADMIN_API_SERVICE_AUTH.md`.

## [0.15.0] - 2026-05-05

### Fixed
- **`invalid_scope: No scopes were requested` on ID-JAG Leg 1 for `ALLOW_ALL` Managed Connections.** Okta returns an empty `scopes` list for connections configured with `scopeCondition = ALLOW_ALL`, and MCP clients often do not request resource-specific scopes, so the computed scope set was empty and Okta rejected the request. At sync time the adapter now fetches `scopes_supported` from the target authorization server's `.well-known/openid-configuration`, filters out OIDC scopes and Okta-internal scopes (configurable via `OKTA_SCOPE_BLOCKLIST`, default `interclient_access`), and persists the result to `managed_connection_scopes`. Both the live syncer (`okta_agent_proxy/resources/syncer.py`) and the admin-triggered `POST /api/admin/okta/sync/resources` endpoint apply the expansion; fetches are deduped per sync run, and failures are non-fatal (sync completes with the connection's raw scopes). Net effect: `ALLOW_ALL` now materializes to "everything the AS actually supports, minus noise," and ID-JAG-issued resource tokens carry real `scp` claims instead of the `openid` last-ditch fallback.
- **`invalid_scope` error on `/oauth/authorize` when custom scopes were discovered.** Follow-up to the ID-JAG scope-plumbing fix below: once MCP clients began picking up custom scopes from `scopes_supported` via RFC 9728 discovery, they included them on the authorization request — which hit Okta's org authorization server, which rejects anything outside the OIDC set. The adapter now splits the client's scope request at `/oauth/authorize`: OIDC scopes (`openid`, `profile`, `email`, `address`, `phone`, `offline_access`) are forwarded to Okta for user login; custom scopes are stashed on the `RelaySession`, bound to the issued access token via `GatewayCodeManager.extra`, and recovered at proxy time for use on ID-JAG Leg 1. Relay refresh carries the stash forward. Cache-miss fallback re-uses `apply_scope_condition`'s `connection.scopes` default — no downstream regression. New audit events: `oauth.custom_scopes.stashed`, `oauth.custom_scopes.recovered`, `token.custom_scopes.bound`. Key files: `okta_agent_proxy/app.py::_split_oidc_custom_scopes`, `okta_agent_proxy/auth/confidential_relay.py::RelaySession.custom_scopes`.
- **ID-JAG scope plumbing end-to-end.** Managed Connection scopes configured on the Okta side (e.g. `bedrock:InvokeAgent` for AgentCore Gateway) now correctly reach the resource access token issued to downstream ISV targets. Three root causes addressed: (1) `ALLOW_ALL` ignored the connection's `scopes` list and fell back to a hardcoded `["mcp:read"]` — it now unions caller-requested scopes with configured scopes; (2) caller-requested scopes from the user's bearer token were hardcoded to `None` — they are now threaded through `proxy/handler.py`, `mcp/unified_handler.py`, `auth/resource_token_resolver.py`, and `routing/router.py`; (3) `EXCLUDE` was declared in the `OktaScopeCondition` enum but was a silent no-op — it now behaves as an alias of `DISALLOW`. The `["mcp:read"]` fallback is removed; an empty computed scope list correctly omits the `scope` parameter on the Leg-1 wire, per RFC 8693 §2.1. Key file: `okta_agent_proxy/auth/cross_app_access.py::apply_scope_condition`.

### Added
- **Okta ITP Universal Logout (Global Logout) support.** Merged from `feature/global-logout`. The adapter now exposes `POST /oauth/global-token-revocation` (per `draft-parecki-oauth-global-token-revocation`) and, on a valid signed JWT from any registered agent's linked Okta OIDC app, cascades revocation across `UserTokenStore` → `TokenCache` (ID-JAG and STS families) → `MCPSessionManager` for the named user. Allowlist is auto-maintained from the agents table (refresh via `CHANNEL_AGENT_INVALIDATE` pub/sub, safety-net TTL `GLOBAL_LOGOUT_ALLOWLIST_TTL_SECONDS`). Per-IP, per-replica rate limiting with bounded in-memory IP table. New audit events: `GLOBAL_LOGOUT_REQUESTED`, `GLOBAL_LOGOUT_COMPLETED`, `GLOBAL_LOGOUT_AUTH_FAILED`, `GLOBAL_LOGOUT_SUBJECT_NOT_FOUND`, `GLOBAL_LOGOUT_SUBJECT_INVALID`, `GLOBAL_LOGOUT_BACKEND_SESSION_TERMINATED`, `GLOBAL_LOGOUT_BACKEND_SESSION_FAILED`. See [`docs/GLOBAL_LOGOUT_CONFIGURATION.md`](docs/GLOBAL_LOGOUT_CONFIGURATION.md).
- **Admin-initiated force logout.** Admin UI → Security & Compliance → **User Sessions** drives a new admin endpoint `POST /api/admin/users/force-logout` that reuses `GlobalLogoutHandler.revoke_user` to revoke all cached tokens and terminate all downstream MCP sessions for a given user across every pod. Accepts either `{"email": ...}` or `{"sub": ...}`; email is resolved to an Okta `sub` via `GET /api/v1/users/{login}` using the admin's own access token (requires the Admin UI OIDC app to carry the `okta.users.read` scope). New audit event `ADMIN_FORCE_LOGOUT` (`admin.user.force_logout`) distinguishes admin-initiated revocation from ITP-initiated ULO in SIEM dashboards; the underlying `GLOBAL_LOGOUT_COMPLETED` event continues to fire, so ULO-native dashboards are unchanged. See [`docs/GLOBAL_LOGOUT_CONFIGURATION.md#admin-initiated-force-logout`](docs/GLOBAL_LOGOUT_CONFIGURATION.md#admin-initiated-force-logout).
- **`OKTA_SCOPE_BLOCKLIST` env var.** Comma-separated list of scopes to strip when the sync process materializes an `ALLOW_ALL` Managed Connection from the target AS's `scopes_supported`. Default: `interclient_access,device_sso` — both commonly appear in Okta's discovery output but aren't granted to the OIDC client behind an AI Agent, so they pass ID-JAG Leg 1 but fail Leg 2 with `invalid_scope: One or more scopes are not configured for the authorization server resource`. Empty string disables the blocklist. OIDC scopes are always stripped regardless of this setting. Each sync emits `AS metadata <issuer> advertises N scopes: [...]` and `ALLOW_ALL materialized for <issuer>: kept=[...] dropped=[...]` at INFO so admins can tune the blocklist. See `okta_agent_proxy/auth/scope_filter.py`.
- **RFC 9728 scope discovery on well-known metadata endpoints.** `/.well-known/oauth-protected-resource/{resource}` now advertises the resource's Managed Connection scopes in `scopes_supported`, unioned with the OIDC baseline. The unified `/.well-known/oauth-protected-resource` reads `X-MCP-Agent` to narrow the union to that agent's accessible resources, or falls back to a global union when the header is absent. Same treatment applied to `/.well-known/oauth-authorization-server` variants. Spec-compliant MCP clients (Claude Code, Cursor, VS Code) now auto-discover what scopes each resource needs and request them on `/oauth/authorize` without any client-side configuration.
- **DCR scope allowlist widened at runtime.** `auth/dcr_policy.SUPPORTED_SCOPES` is now a baseline; at registration time it's unioned with scopes configured on any resolved resource, so DCR clients can self-register with custom scopes like `bedrock:InvokeAgent` instead of having them silently sanitized away.

### Removed
- **`POST /api/admin/login` and the username/password admin auth path.** `admin/auth.py::generate_admin_token` / `verify_admin_token` / `validate_credentials` and the `ADMIN_USERNAME` / `ADMIN_PASSWORD` / `ADMIN_JWT_SECRET` env vars are gone. Admin API auth is now Okta-OAuth-only (see **Security** below). `ADMIN_LOGIN` / `ADMIN_LOGIN_FAILURE` audit event types remain in the enum for SIEM back-compat but are no longer emitted.
- SQLAlchemy, Alembic, `psycopg2-binary`, and greenlet (transitive) from the runtime image. The adapter now talks to Postgres through `psycopg` (psycopg3) exclusively. (DB migration P07)
- `okta_agent_proxy/storage/postgres.py`, `okta_agent_proxy/storage/models.py`, and the `alembic/` directory.
- `_deprecated_backends`, `_deprecated_backend_audit_log`, and `_deprecated_agent_backend_access` tables. Migration `004__deprecated_backend_tables.*.sql` is deleted. The admin-API auth columns (`paths`, `auth_method`, `auth_config`, encrypted `auth_secret_*`, `timeout_seconds`, `registration_strategy`, `managed_connection_id`, `managed_connection_scopes`, `created_by`, `updated_by`) now live on the unified `resources` table.

### Added
- Raw-SQL migration runner (`python -m okta_agent_proxy.storage.migrate upgrade`) and `okta-adapter-migrate` console script — replaces `alembic upgrade head`. (DB migration P03)
- `RUN_DB_BOOTSTRAP` env var (default `true`) controls whether the AWS ECS and Azure ACA deploy pipelines run the role bootstrap (`bootstrap_roles.sql`) plus schema migrations as part of deploy. Set to `false` (or pass `--no-bootstrap` / `--skip-migrate`) to hand off to a DBA — the script prints a copy-pasteable handoff block with the real secret ARNs, cluster names, and job names filled in. (DB migration P15)
- `--migrate-only` flag on both deploy scripts (alias of the existing `--migrate` on AWS): skips infra/apps and only runs the bootstrap step. Useful when a new release ships migrations but no infra change.
- `DB_BOOTSTRAP_FORCE_LOCAL=true` forces the bootstrap helper to skip the cloud-native one-shot job (ECS RunTask / ACA Container Apps Job) and run `psql` + the migration runner from the deploy host. Default auto-detects: cloud-job when the cloud CLI is installed and authenticated, local-exec otherwise.
- `deploy/shell-lib/db_bootstrap.sh` — cross-cloud shell library sourced by both AWS and Azure deploy scripts. Handles path selection, post-condition verification (schema version), and the off-mode handoff block. (DB migration P15)
- **Pluggable Redis credential providers** (`redis_credential_providers/`) for authenticating to Redis/Valkey with short-lived cloud-native credentials instead of static passwords. Providers: `static`, `aws-iam` (ElastiCache IAM), `azure-entra` (Entra Managed Identity). Factory dispatches on `REDIS_AUTH_MODE`. (Redis creds P01–P08)
- Credential lifecycle with scheduled refresh inside a configurable safety window; refresh failures emit `redis.credential.refresh.failed` and fail-open to let the existing client run to natural expiry, while auth failures fail-closed.
- Startup preflight mints credentials once before the adapter accepts traffic; state is surfaced at `/health` under `redis_credentials`. Preflight failure degrades `/health` to 503. (Redis creds P08)
- New audit events for SIEM consumers: `redis.credential.minted`, `redis.credential.refresh.success`, `redis.credential.refresh.failed`, `redis.auth.failure`, `redis.static_password.used`. (Redis creds P11)
- Phase 2 architecture doc (`docs/REDIS_CREDENTIAL_ARCHITECTURE-1.md`), implementation prompts, and security-review summary (`docs/redis-credentials-security-summary.md`). (Redis creds P12)

### Changed
- `STORAGE_BACKEND` env var is now accepted only for diagnostic logging; psycopg3 is the only supported backend.
- `run_migrations.sh` invokes the new runner instead of Alembic; Docker-compose workflow is preserved.
- AWS ECS Terraform (`deploy/aws-ecs/`) switches the adapter task to ElastiCache IAM by default — task role gets `elasticache:Connect` against the cache and IAM-enabled user; `REDIS_URL` becomes a plain env var (host:port only, no password); the `aws_secretsmanager_secret.redis` resource is removed. (Redis creds P09)
- Azure ACA Bicep (`deploy/azure-aca/`) switches the adapter container to Entra Managed Identity for Redis — `REDIS_AUTH_MODE=azure-entra`, `REDIS_AZURE_USE_MSI=true`, `REDIS_AZURE_CLIENT_ID` set to the app UAMI client ID. (Redis creds P10)

### Security
- **Admin API is now Okta-OAuth-only.** The legacy `POST /api/admin/login` username/password endpoint and its HS256 JWT fallback in the admin middleware have been removed. The adapter accepts only Okta OAuth access tokens issued by the Admin UI's OIDC app (`Authorization: Bearer <token>`). Eliminates the hardcoded-default credential risk (`admin/admin123`) and the shared `ADMIN_JWT_SECRET` that would otherwise need to be synchronized across every replica. See `docs/OPERATIONS.md` § "Admin API Authentication" for how to obtain a token for API testing. Follow-up hardening (audience pinning to `ADMIN_UI_OKTA_CLIENT_ID`, group/scope enforcement) tracked in `reports/security-audit.md`.
- Resolves CWE-121 stack-based buffer overflow in `src/greenlet/TStackState.cpp:259`. Greenlet shipped transitively with SQLAlchemy; both are gone.
- Static Redis passwords are now gated behind `ALLOW_STATIC_REDIS_PASSWORD` (default `false`). Production deployments must authenticate with a cloud-native provider (`aws-iam` or `azure-entra`); single-pod dev / docker-compose set the gate to `true` explicitly. Grep-friendly for security review. (Redis creds P02)

### Breaking
- **Admin API callers must use an Okta access token.** Any script, CI job, or tool that was hitting `POST /api/admin/login` to mint an HS256 JWT must switch to sending `Authorization: Bearer <okta_access_token>`, where the token is issued by the Admin UI's Okta OIDC app. `ADMIN_USERNAME` / `ADMIN_PASSWORD` / `ADMIN_JWT_SECRET` must be removed from env files, Secrets Manager entries, Key Vault entries, Terraform variables, and Bicep params. Deploy wizards (`setup.sh`, `deploy/aws-ec2`, `deploy/aws-ecs`, `deploy/azure-aca`, `deploy/azure-aks`, `deploy/bundle`) have been updated; operator scripts (`ops_scripts/test_round_trip.py`, `ops_scripts/test_xaa_smoke.sh`) and `examples/05-deploy-server/seed_deploy_backend.py` now read `OKTA_ADMIN_TOKEN` from the environment. See `docs/OPERATIONS.md` § "Admin API Authentication".
- Downstream code must no longer import from `okta_agent_proxy.storage.postgres` or `okta_agent_proxy.storage.models` — use `okta_agent_proxy.storage.psycopg_store.PsycopgResourceStore` and `okta_agent_proxy.storage.repositories.resource_repo.ResourceRepository`.
- **Resources table unified.** The historical split between the sync-populated `resources` table and the admin-API-populated `_deprecated_backends` table has been removed. All resource CRUD, the Okta-sync importer, the router, and the linkage junction now read and write one `resources` table. **No in-place upgrade is provided** — operators must drop and recreate the database:
  1. Export agent + resource configs via the Admin API (`GET /api/admin/agents`, `GET /api/admin/resources`) before upgrade.
  2. `docker compose down -v && docker compose up -d postgres` (or the equivalent for your deploy).
  3. Run `python -m okta_agent_proxy.storage.migrate upgrade`.
  4. Re-import configs via the Admin API (or re-run Okta import).
- `ResourceRepository`'s admin-API methods have been renamed (`list_all` → `admin_list`, `get_by_name` → `admin_get`, `create` → `admin_create`, `update` → `admin_update`, `delete` → `admin_delete`, `set_enabled` → `admin_set_enabled`) to disambiguate from the sync-side Resource-object methods absorbed from the former `linkage_repo.ResourceStore` class. Callers via `PsycopgResourceStore` / the `ResourceConfigStore` ABC are unaffected.

## [0.14.10] - 2026-04-27

### Changed
- DCR redirect-pattern validator now accepts single-word private-use schemes (e.g. `cursor://`, `vscode://`, `windsurf://`) used by real-world MCP clients. The strict RFC 8252 §7.1 reverse-DNS shape rule previously rejected these.
- `DANGEROUS_SCHEMES` denylist expanded to explicitly block network-protocol schemes unsuitable as redirect targets: `ftp`, `ftps`, `gopher`, `telnet`, `ssh`, `ws`, `wss`, `mailto`, `tel`, `sms`, `ldap`, `ldaps`.

### Migration
- No action required. Existing redirect patterns continue to validate. Admins can now register IDE patterns like `cursor://anysphere.cursor-mcp/oauth/callback` via the DCR settings page.

## [0.14.9] - 2026-04-26

### Added
- Full port configurability across all deployment profiles. Every component port now has a canonical env var that flows from `.env` through Dockerfiles, compose, ECS Terraform, AKS/ACA manifests, and health checks.
- New env vars: `ADMIN_UI_PORT`, `HR_BACKEND_PORT`, `DEPLOY_SERVER_PORT`, `DCR_CALLBACK_PORT`, plus `*_HOST_PORT` variants for docker-compose host-side remapping.
- New Terraform variables for ECS: `gateway_port`, `admin_ui_port` (core), `hr_backend_port` (examples).
- Azure ACA Bicep parameters: `gatewayPort`, `adminUiPort`, `hrBackendPort`, `deployServerPort`.
- Port validation with warnings for privileged ports (<1024).
- New audit event: `config.port.validation_warning`.
- Port Configuration section in `docs/OPERATIONS.md` with troubleshooting guide.
- `docs/DEPRECATIONS.md` deprecation log.
- New `deploy/aws-ecs-examples/` Terraform project for opt-in example MCP servers (HR backend), separated from core so a failed example never blocks core adapter deploys.
- Port Configuration sections in `deploy/aws-ecs/README.md` and `deploy/aws-ecs-examples/README.md`.

### Changed
- CodeBuild is now the default image-build path for `deploy/aws-ecs` (core). Pass `--use-local-docker` to opt into local Docker builds. Eliminates the Mac Silicon → Fargate ARM/AMD footgun and aligns with `deploy/aws-ecs-examples`, which already defaulted to CodeBuild. `TF_VAR_enable_codebuild` default flipped from `false` to `true`.

### Deprecated
- `SERVER_PORT` env var for HR backend and deploy server. Use `HR_BACKEND_PORT` / `DEPLOY_SERVER_PORT` instead. Removal in v2.0.0.
- `deploy/aws-ecs/deploy.sh --use-codebuild` flag. CodeBuild is now the default; use `--use-local-docker` for local builds.

### Migration
- No action required for existing deployments. All port defaults are unchanged. To override a port, set the corresponding env var before running `docker compose up` or `terraform apply`.
- If your CI/CD wrapped `./deploy.sh --use-codebuild`, drop the flag — CodeBuild is the default. If you relied on local Docker builds, add `--use-local-docker` to preserve prior behavior.
