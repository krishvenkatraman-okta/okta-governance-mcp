#!/usr/bin/env bash
set -euo pipefail

# ============================================================
# setup.sh — Bootstrap the Okta MCP Adapter local dev environment
#
# Usage:
#   ./setup.sh                         # Standard setup
#   ./setup.sh --help                  # Show help
# ============================================================

# --- Colors ---------------------------------------------------------------
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
CYAN='\033[0;36m'
BOLD='\033[1m'
NC='\033[0m' # No Color

# --- Helpers --------------------------------------------------------------
info()  { echo -e "${CYAN}→${NC} $*"; }
ok()    { echo -e "${GREEN}✓${NC} $*"; }
warn()  { echo -e "${YELLOW}⚠${NC} $*"; }
fail()  { echo -e "${RED}✗${NC} $*"; }
die()   { fail "$*"; exit 1; }

# --- Parse arguments ------------------------------------------------------

while [[ $# -gt 0 ]]; do
    case "$1" in
        --help|-h)
            echo "Usage: $0 [OPTIONS]"
            echo ""
            echo "Options:"
            echo "  --help, -h         Show this help"
            echo ""
            echo "The script will:"
            echo "  1. Validate .env configuration"
            echo "  2. Generate ENCRYPTION_KEY if missing"
            echo "  3. Build and start Docker containers"
            echo "  4. Run smoke tests"
            exit 0 ;;
        *)
            die "Unknown option: $1. Use --help for usage." ;;
    esac
done

# --- Ctrl+C handler ------------------------------------------------------
cleanup() {
    echo ""
    warn "Interrupted. Containers may still be running — use 'docker compose down' to stop."
    exit 130
}
trap cleanup INT

# --- Resolve docker compose command ---------------------------------------
if docker compose version &>/dev/null; then
    DC="docker compose"
elif command -v docker-compose &>/dev/null; then
    DC="docker-compose"
else
    DC=""
fi

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"

echo ""
echo -e "${BOLD}Okta MCP Adapter — Local Setup${NC}"
echo "============================================"
echo ""

# ==================================================================
# 1. PREFLIGHT CHECKS
# ==================================================================
info "Running preflight checks..."

# Docker
command -v docker &>/dev/null || die "docker is not installed. Install Docker Desktop: https://docs.docker.com/get-docker/"
[[ -n "$DC" ]] || die "docker compose is not available. Update Docker Desktop or install docker-compose."
ok "Docker and docker compose available"

# Python (needed for key generation)
command -v python3 &>/dev/null || die "python3 is required for key generation."

# .env file
if [[ ! -f .env ]]; then
    if [[ -f .env.example ]]; then
        cp .env.example .env
        warn ".env not found — created from .env.example"
        echo ""
        fail "You must edit .env and set your Okta values before continuing."
        echo "  Open .env and replace the OKTA_DOMAIN placeholder, then re-run this script."
        echo ""
        exit 1
    else
        die ".env not found and no .env.example to copy from."
    fi
fi
ok ".env file exists"

# Source .env (skip comments and blank lines)
set +u  # Allow empty values during sourcing
set -a
eval "$(grep -v '^\s*#' .env | grep -v '^\s*$')"
set +a
set -u

# Validate required Okta values
check_okta_var() {
    local var_name="$1"
    local placeholder="$2"
    local value="${!var_name:-}"

    if [[ -z "$value" || "$value" == *"$placeholder"* ]]; then
        fail "$var_name is not set (still has placeholder value)."
        echo "  Edit .env and set $var_name to your Okta value."
        exit 1
    fi
}

check_okta_var "OKTA_DOMAIN"                    "XXXXX"
ok "Okta configuration values set"

# ==================================================================
# 2. ENCRYPTION KEY
# ==================================================================
if [[ -z "${ENCRYPTION_KEY:-}" ]]; then
    info "ENCRYPTION_KEY is empty — generating one..."
    NEW_KEY=$(python3 -c "import os,base64; print(base64.b64encode(os.urandom(32)).decode())")

    # Replace the ENCRYPTION_KEY= line in .env
    if grep -q '^ENCRYPTION_KEY=' .env; then
        sed -i.bak "s|^ENCRYPTION_KEY=.*|ENCRYPTION_KEY=${NEW_KEY}|" .env && rm -f .env.bak
    else
        echo "ENCRYPTION_KEY=${NEW_KEY}" >> .env
    fi

    # Export so downstream steps see it
    export ENCRYPTION_KEY="$NEW_KEY"
    ok "ENCRYPTION_KEY generated and saved to .env"
else
    ok "ENCRYPTION_KEY already set"
fi


# ==================================================================
# 3. v0.15.0 SCHEMA COMPATIBILITY CHECK
# ==================================================================
# v0.15.0 unified the `resources` and `_deprecated_backends` tables and
# dropped in-place migration support. A postgres volume from an older
# release will cause the migration runner to abort at startup. Detect
# that case before we build, and offer to wipe the volume.
check_legacy_schema() {
    # Any project-prefixed postgres_data volume belonging to this repo.
    local vol
    vol="$(docker volume ls --format '{{.Name}}' 2>/dev/null \
        | grep -E '_postgres_data$' | head -n1)"
    [[ -z "$vol" ]] && return 0

    info "Existing Postgres volume detected ($vol) — checking schema compatibility..."

    # Bring postgres up in isolation so we can probe its schema. Using the
    # named service avoids building the adapter image just to read one row.
    if ! $DC up -d postgres &>/dev/null; then
        warn "Could not start postgres to probe schema — continuing without check."
        return 0
    fi

    local pg_user="${POSTGRES_USER:-gateway_user}"
    local pg_db="${POSTGRES_DB:-gateway_db}"
    local i
    for i in $(seq 1 15); do
        if $DC exec -T postgres pg_isready -U "$pg_user" -d "$pg_db" &>/dev/null; then
            break
        fi
        sleep 1
    done

    local has_legacy
    has_legacy="$($DC exec -T postgres psql -U "$pg_user" -d "$pg_db" -tAc \
        "SELECT 1 FROM information_schema.tables WHERE table_name = '_deprecated_backends' LIMIT 1;" \
        2>/dev/null | tr -d '[:space:]')"

    if [[ "$has_legacy" != "1" ]]; then
        ok "Postgres schema is compatible with v0.15.0"
        return 0
    fi

    echo ""
    warn "v0.15.0 upgrade: your postgres volume contains a pre-v0.15 schema."
    echo "  v0.15.0 unified the 'resources' and '_deprecated_backends' tables."
    echo "  There is no in-place migration path — the database must be dropped."
    echo ""
    echo "  To preserve configs, start the old version briefly and export first:"
    echo "    curl -s http://localhost:${GATEWAY_PORT:-8000}/api/admin/agents    > backup_agents.json"
    echo "    curl -s http://localhost:${GATEWAY_PORT:-8000}/api/admin/resources > backup_resources.json"
    echo ""
    read -r -p "Wipe the volume now and continue? [y/N] " reply
    case "$reply" in
        [Yy]|[Yy][Ee][Ss])
            info "Running '$DC down -v'..."
            $DC down -v || die "Failed to remove volumes. Run '$DC down -v' manually and re-run setup."
            ok "Volume wiped — continuing with a fresh database."
            ;;
        *)
            die "Aborted. Back up your data, run '$DC down -v', then re-run setup."
            ;;
    esac
}
check_legacy_schema

# ==================================================================
# 4. BUILD & START
# ==================================================================
echo ""
info "Building containers..."
$DC build || die "docker compose build failed"
ok "Build complete"

info "Starting containers..."
$DC up -d || die "docker compose up failed"
ok "Containers started"

# Wait for PostgreSQL
info "Waiting for PostgreSQL to be healthy..."
PG_TIMEOUT=30
for i in $(seq 1 "$PG_TIMEOUT"); do
    if $DC ps --format json 2>/dev/null | grep -q '"postgres".*healthy' 2>/dev/null || \
       $DC ps 2>/dev/null | grep -q 'postgres.*healthy'; then
        ok "PostgreSQL is healthy"
        break
    fi
    if [[ $i -eq $PG_TIMEOUT ]]; then
        die "PostgreSQL did not become healthy within ${PG_TIMEOUT}s"
    fi
    sleep 1
done

# Wait for Redis (if enabled)
if [[ "${CACHE_PROVIDER:-redis}" == "redis" ]]; then
    info "Waiting for Redis to be healthy..."
    REDIS_TIMEOUT=15
    for i in $(seq 1 "$REDIS_TIMEOUT"); do
        if $DC ps --format json 2>/dev/null | grep -q '"redis".*healthy' 2>/dev/null || \
           $DC ps 2>/dev/null | grep -q 'redis.*healthy'; then
            ok "Redis is healthy"
            break
        fi
        if [[ $i -eq $REDIS_TIMEOUT ]]; then
            warn "Redis did not become healthy within ${REDIS_TIMEOUT}s — gateway will use in-memory cache"
            break
        fi
        sleep 1
    done
fi

# Wait for adapter
info "Waiting for gateway to be healthy..."
GW_PORT="${GATEWAY_PORT:-8000}"
GW_TIMEOUT=45
for i in $(seq 1 "$GW_TIMEOUT"); do
    if curl -sf "http://localhost:${GW_PORT}/.well-known/oauth-protected-resource" &>/dev/null; then
        ok "Gateway is healthy"
        break
    fi
    if [[ $i -eq $GW_TIMEOUT ]]; then
        die "Gateway did not become healthy within ${GW_TIMEOUT}s. Check logs: $DC logs adapter"
    fi
    sleep 1
done

# Wait for admin UI
info "Waiting for admin UI to be healthy..."
ADMIN_UI_PORT="${ADMIN_UI_PORT:-3001}"
ADMIN_UI_TIMEOUT=30
for i in $(seq 1 "$ADMIN_UI_TIMEOUT"); do
    if curl -sf "http://localhost:${ADMIN_UI_PORT}/" &>/dev/null; then
        ok "Admin UI is healthy"
        break
    fi
    if [[ $i -eq $ADMIN_UI_TIMEOUT ]]; then
        warn "Admin UI did not become healthy within ${ADMIN_UI_TIMEOUT}s. Check logs: $DC logs admin-ui"
        break
    fi
    sleep 1
done

# ==================================================================
# 5. SMOKE TEST
# ==================================================================
echo ""
info "Running smoke tests..."
SMOKE_PASS=0
SMOKE_FAIL=0

# Health / metadata endpoint
if curl -sf "http://localhost:${GW_PORT}/.well-known/oauth-protected-resource" &>/dev/null; then
    ok "Metadata endpoint responded"
    SMOKE_PASS=$((SMOKE_PASS + 1))
else
    fail "Metadata endpoint did not respond"
    SMOKE_FAIL=$((SMOKE_FAIL + 1))
fi

# Admin API reachability — password login was removed in v0.15.x, so we just
# confirm that a bearer-less request is rejected with 401 (auth is wired).
ADMIN_STATUS=$(curl -s -o /dev/null -w '%{http_code}' "http://localhost:${GW_PORT}/api/admin/agents" 2>/dev/null || echo "000")
if [[ "$ADMIN_STATUS" == "401" ]]; then
    ok "Admin API rejects unauthenticated requests (401)"
    SMOKE_PASS=$((SMOKE_PASS + 1))
else
    fail "Admin API unexpected status: ${ADMIN_STATUS} (expected 401)"
    SMOKE_FAIL=$((SMOKE_FAIL + 1))
fi

echo ""
if [[ $SMOKE_FAIL -eq 0 ]]; then
    ok "All smoke tests passed (${SMOKE_PASS}/${SMOKE_PASS})"
else
    warn "Smoke tests: ${SMOKE_PASS} passed, ${SMOKE_FAIL} failed"
fi

# ==================================================================
# 6. SUMMARY
# ==================================================================
echo ""
echo -e "${BOLD}╔══════════════════════════════════════════════════════════╗${NC}"
echo -e "${BOLD}║              Setup Complete                             ║${NC}"
echo -e "${BOLD}╚══════════════════════════════════════════════════════════╝${NC}"
echo ""
echo -e "  ${YELLOW}Note: v0.15.0 requires a fresh database. The 'resources' and${NC}"
echo -e "  ${YELLOW}'_deprecated_backends' tables were unified — there is no${NC}"
echo -e "  ${YELLOW}in-place migration. Use '$DC down -v' before upgrading from${NC}"
echo -e "  ${YELLOW}v0.14.x or earlier.${NC}"
echo ""
echo -e "  ${GREEN}✓${NC} PostgreSQL running on localhost:5432"
echo -e "  ${GREEN}✓${NC} Redis running on localhost:${REDIS_PORT:-6379}"
echo -e "  ${GREEN}✓${NC} Gateway running on localhost:${GW_PORT}"
echo -e "  ${GREEN}✓${NC} Admin UI running on localhost:${ADMIN_UI_PORT:-3001}"
echo ""
echo -e "  To also start the example resource servers:"
echo "    docker compose -f docker-compose.yml -f docker-compose.examples.yml up -d"

echo ""
echo -e "  ${BOLD}Admin Console:${NC}"
echo ""
echo -e "  Open your browser to: ${CYAN}http://localhost:${ADMIN_UI_PORT:-3001}${NC}"
echo "  Sign in with your Okta account (the OIDC app you configured in"
echo "  ADMIN_UI_OKTA_DOMAIN / ADMIN_UI_OKTA_CLIENT_ID)."
echo ""
echo -e "  ${BOLD}Connect Claude Code (CIMD — easiest):${NC}"
echo ""
echo "  Just add the gateway URL — CIMD auto-discovers the client:"
echo "     claude mcp add --transport http okta-gateway http://localhost:${GW_PORT}"
echo ""
echo "  Inside Claude Code, run: /mcp"
echo ""
echo -e "  ${BOLD}Connect VS Code (CIMD — easiest):${NC}"
echo ""
echo "  Add to your VS Code settings.json (Cmd+Shift+P > MCP: Add Server):"
echo "     {\"servers\": {\"okta-gateway\": {\"type\": \"http\", \"url\": \"http://localhost:${GW_PORT}\"}}}"
echo ""
echo -e "  ${BOLD}CIMD Trust & Resource Access:${NC}"
echo -e "  Trusted domains: ${CYAN}${CIMD_TRUSTED_DOMAINS:-localhost,host.docker.internal}${NC}"
echo "  CIMD clients get resource access based on trust tier (configurable in .env)"
echo "  Auto-provisioned agents appear in the Admin UI for per-client management."
echo ""
echo "  To add trusted domains, edit .env:"
echo -e "    ${CYAN}CIMD_TRUSTED_DOMAINS${NC}=localhost,host.docker.internal,claude.ai,your-domain.com"
echo ""
echo -e "  ${BOLD}Alternative: Pre-registered Agent (manual):${NC}"
echo ""
echo "  1. Update agent client_id to match your Okta app:"
echo "     curl -X PUT http://localhost:${GW_PORT}/api/admin/agents/claude-code \\"
echo "       -H \"Authorization: Bearer \$TOKEN\" \\"
echo "       -H \"Content-Type: application/json\" \\"
echo "       -d '{\"client_id\": \"<your-okta-client-id>\"}'"
echo ""
echo "  2. Register the MCP server with credentials:"
echo "     MCP_CLIENT_SECRET='<okta-client-secret>' \\"
echo "       claude mcp add --transport http \\"
echo "       --client-id <okta-client-id> \\"
echo "       --client-secret \\"
DCR_CALLBACK_PORT="${DCR_CALLBACK_PORT:-3000}"
echo "       --callback-port ${DCR_CALLBACK_PORT} \\"
echo "       --header \"X-MCP-Agent: claude-code\" \\"
echo "       okta-gateway http://localhost:${GW_PORT}"
echo ""
echo -e "  ${YELLOW}Note: Okta app redirect URI must include http://localhost:${DCR_CALLBACK_PORT}/callback${NC}"
echo ""
echo -e "  ${CYAN}Useful commands:${NC}"
echo "    $DC logs -f okta-agent-mcp-adapter    # Follow gateway logs"
echo "    $DC logs -f admin-ui                  # Follow admin UI logs"
echo "    $DC down                              # Stop everything"
echo "    $DC ps                                # Check container status"
echo ""
