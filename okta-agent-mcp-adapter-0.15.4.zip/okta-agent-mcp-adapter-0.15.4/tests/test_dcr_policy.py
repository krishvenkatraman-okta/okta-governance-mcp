"""
Tests for the DCR (Dynamic Client Registration) Policy Engine.

Validates that registration requests are properly checked against
configurable rules including rate limiting, redirect URI patterns,
grant types, and scope intersection.
"""

import pytest
from okta_agent_proxy.auth.dcr_policy import DCRPolicy, DCRPolicyResult


def _valid_request(**overrides):
    """Build a valid DCR request body with optional overrides."""
    body = {
        "client_name": "Test MCP Client",
        "redirect_uris": ["http://localhost:9999/callback"],
        "grant_types": ["authorization_code"],
        "response_types": ["code"],
        "token_endpoint_auth_method": "client_secret_basic",
    }
    body.update(overrides)
    return body


def _policy(**kwargs):
    """Create a DCRPolicy with DCR enabled by default."""
    kwargs.setdefault("enabled", True)
    return DCRPolicy(**kwargs)


class TestDCRPolicyBasic:
    async def test_valid_request_allowed(self):
        """Valid request with all required fields is approved."""
        policy = _policy()
        result = await policy.validate(_valid_request(), source_ip="10.0.0.1")
        assert result.allowed is True
        assert result.sanitized_body is not None
        assert result.sanitized_body["client_name"] == "Test MCP Client"
        assert result.sanitized_body["redirect_uris"] == ["http://localhost:9999/callback"]

    async def test_dcr_disabled_rejected(self):
        """Registration rejected when DCR is disabled."""
        policy = _policy(enabled=False)
        result = await policy.validate(_valid_request(), source_ip="10.0.0.1")
        assert result.allowed is False
        assert "disabled" in result.reason.lower()
        assert result.sanitized_body is None

    async def test_sanitized_body_has_defaults(self):
        """Sanitized body includes defaulted fields."""
        policy = _policy()
        body = {"client_name": "Test", "redirect_uris": ["http://localhost:8080/callback"]}
        result = await policy.validate(body, source_ip="10.0.0.1")
        assert result.allowed is True
        assert result.sanitized_body["grant_types"] == ["authorization_code"]
        assert result.sanitized_body["application_type"] == "web"
        assert result.sanitized_body["response_types"] == ["code"]
        assert result.sanitized_body["token_endpoint_auth_method"] == "client_secret_basic"


class TestDCRPolicyRateLimiting:
    async def test_rate_limit_exceeded_rejected(self):
        """Registration rejected when rate limit is exceeded."""
        policy = _policy(
            max_registrations_per_hour=5,
            registration_counter=lambda ip: 5,
        )
        result = await policy.validate(_valid_request(), source_ip="10.0.0.1")
        assert result.allowed is False
        assert "rate limit" in result.reason.lower()

    async def test_rate_limit_not_exceeded_allowed(self):
        """Registration allowed when under rate limit."""
        policy = _policy(
            max_registrations_per_hour=10,
            registration_counter=lambda ip: 3,
        )
        result = await policy.validate(_valid_request(), source_ip="10.0.0.1")
        assert result.allowed is True

    async def test_rate_limit_at_boundary(self):
        """Registration rejected at exact boundary."""
        policy = _policy(
            max_registrations_per_hour=10,
            registration_counter=lambda ip: 10,
        )
        result = await policy.validate(_valid_request(), source_ip="10.0.0.1")
        assert result.allowed is False


class TestDCRPolicyClientName:
    async def test_missing_client_name_rejected(self):
        """Registration rejected when client_name is missing."""
        policy = _policy()
        body = _valid_request()
        del body["client_name"]
        result = await policy.validate(body, source_ip="10.0.0.1")
        assert result.allowed is False
        assert "client_name" in result.reason

    async def test_empty_client_name_rejected(self):
        """Registration rejected when client_name is empty."""
        policy = _policy()
        result = await policy.validate(
            _valid_request(client_name=""), source_ip="10.0.0.1"
        )
        assert result.allowed is False
        assert "client_name" in result.reason

    async def test_long_client_name_rejected(self):
        """Registration rejected when client_name exceeds 255 chars."""
        policy = _policy()
        result = await policy.validate(
            _valid_request(client_name="x" * 256), source_ip="10.0.0.1"
        )
        assert result.allowed is False
        assert "255" in result.reason


class TestDCRPolicyRedirectURIs:
    async def test_invalid_redirect_uri_rejected(self):
        """Registration rejected for redirect_uri that doesn't match patterns."""
        policy = _policy()
        result = await policy.validate(
            _valid_request(redirect_uris=["https://evil.com/callback"]),
            source_ip="10.0.0.1",
        )
        assert result.allowed is False
        assert "redirect_uri" in result.reason

    async def test_missing_redirect_uris_rejected(self):
        """Registration rejected when redirect_uris is missing."""
        policy = _policy()
        body = _valid_request()
        del body["redirect_uris"]
        result = await policy.validate(body, source_ip="10.0.0.1")
        assert result.allowed is False
        assert "redirect_uris" in result.reason

    async def test_empty_redirect_uris_rejected(self):
        """Registration rejected when redirect_uris is empty list."""
        policy = _policy()
        result = await policy.validate(
            _valid_request(redirect_uris=[]), source_ip="10.0.0.1"
        )
        assert result.allowed is False
        assert "redirect_uris" in result.reason

    async def test_localhost_redirect_allowed(self):
        """Localhost redirect URIs with any port are allowed by default."""
        policy = _policy()
        result = await policy.validate(
            _valid_request(redirect_uris=["http://localhost:12345/callback"]),
            source_ip="10.0.0.1",
        )
        assert result.allowed is True

    async def test_127001_redirect_allowed(self):
        """127.0.0.1 redirect URIs with any port are allowed by default."""
        policy = _policy()
        result = await policy.validate(
            _valid_request(redirect_uris=["http://127.0.0.1:54321/callback"]),
            source_ip="10.0.0.1",
        )
        assert result.allowed is True

    async def test_custom_patterns(self):
        """Custom redirect patterns are respected."""
        policy = _policy(
            allowed_redirect_patterns=["https://myapp.example.com/callback"]
        )
        result = await policy.validate(
            _valid_request(redirect_uris=["https://myapp.example.com/callback"]),
            source_ip="10.0.0.1",
        )
        assert result.allowed is True

        # Default localhost should be rejected with custom patterns
        result2 = await policy.validate(
            _valid_request(redirect_uris=["http://localhost:9999/callback"]),
            source_ip="10.0.0.1",
        )
        assert result2.allowed is False


class TestDCRPolicyGrantTypes:
    async def test_unsupported_grant_type_rejected(self):
        """Registration rejected for unsupported grant_type."""
        policy = _policy()
        result = await policy.validate(
            _valid_request(grant_types=["client_credentials"]),
            source_ip="10.0.0.1",
        )
        assert result.allowed is False
        assert "grant_type" in result.reason

    async def test_mixed_grant_types_rejected_on_bad(self):
        """Rejects when any grant_type is unsupported."""
        policy = _policy()
        result = await policy.validate(
            _valid_request(grant_types=["authorization_code", "implicit"]),
            source_ip="10.0.0.1",
        )
        assert result.allowed is False
        assert "implicit" in result.reason

    async def test_refresh_token_grant_allowed(self):
        """refresh_token grant is allowed by default."""
        policy = _policy()
        result = await policy.validate(
            _valid_request(grant_types=["authorization_code", "refresh_token"]),
            source_ip="10.0.0.1",
        )
        assert result.allowed is True


class TestDCRPolicyAppType:
    async def test_unsupported_app_type_rejected(self):
        """Registration rejected for unsupported application_type."""
        policy = _policy()
        result = await policy.validate(
            _valid_request(application_type="service"),
            source_ip="10.0.0.1",
        )
        assert result.allowed is False
        assert "application_type" in result.reason

    async def test_native_app_type_allowed(self):
        """'native' application_type is allowed by default."""
        policy = _policy()
        result = await policy.validate(
            _valid_request(application_type="native"),
            source_ip="10.0.0.1",
        )
        assert result.allowed is True

    async def test_native_app_defaults_to_none_auth(self):
        """Native apps default to token_endpoint_auth_method='none'."""
        policy = _policy()
        body = _valid_request(application_type="native")
        del body["token_endpoint_auth_method"]
        result = await policy.validate(body, source_ip="10.0.0.1")
        assert result.allowed is True
        assert result.sanitized_body["token_endpoint_auth_method"] == "none"


class TestDCRPolicyScopeIntersection:
    async def test_scope_intersection_filters_unsupported(self):
        """Requested scopes are intersected with supported set."""
        policy = _policy()
        result = await policy.validate(
            _valid_request(scope="openid admin:write"),
            source_ip="10.0.0.1",
        )
        assert result.allowed is True
        assert result.sanitized_body["scope"] == "openid"

    async def test_all_supported_scopes_kept(self):
        """All supported scopes are preserved."""
        policy = _policy()
        result = await policy.validate(
            _valid_request(scope="openid profile email offline_access"),
            source_ip="10.0.0.1",
        )
        assert result.allowed is True
        scopes = set(result.sanitized_body["scope"].split())
        assert scopes == {"openid", "profile", "email", "offline_access"}

    async def test_empty_scope_omitted(self):
        """No scope field in sanitized body when no valid scopes."""
        policy = _policy()
        result = await policy.validate(
            _valid_request(scope="admin:write custom:scope"),
            source_ip="10.0.0.1",
        )
        assert result.allowed is True
        assert "scope" not in result.sanitized_body

    async def test_no_scope_field(self):
        """Missing scope field is handled gracefully."""
        policy = _policy()
        body = _valid_request()
        result = await policy.validate(body, source_ip="10.0.0.1")
        assert result.allowed is True


class TestDCRPolicyAccessToken:
    async def test_token_required_and_missing_rejected(self):
        """Registration rejected when initial access token is required but missing."""
        policy = _policy(
            require_initial_access_token=True,
            initial_access_token="secret-token-123",
        )
        result = await policy.validate(_valid_request(), source_ip="10.0.0.1")
        assert result.allowed is False
        assert "token" in result.reason.lower()

    async def test_token_required_and_invalid_rejected(self):
        """Registration rejected when initial access token is wrong."""
        policy = _policy(
            require_initial_access_token=True,
            initial_access_token="secret-token-123",
        )
        result = await policy.validate(
            _valid_request(), source_ip="10.0.0.1", bearer_token="wrong-token"
        )
        assert result.allowed is False
        assert "invalid" in result.reason.lower()

    async def test_token_required_and_valid_allowed(self):
        """Registration allowed when correct initial access token is provided."""
        policy = _policy(
            require_initial_access_token=True,
            initial_access_token="secret-token-123",
        )
        result = await policy.validate(
            _valid_request(), source_ip="10.0.0.1", bearer_token="secret-token-123"
        )
        assert result.allowed is True

    async def test_token_not_required_skips_check(self):
        """Token check is skipped when not required."""
        policy = _policy(require_initial_access_token=False)
        result = await policy.validate(_valid_request(), source_ip="10.0.0.1")
        assert result.allowed is True


class TestDCRPolicyProperties:
    def test_provision_okta_app_property(self):
        policy = _policy(provision_okta_app=True)
        assert policy.provision_okta_app is True

    def test_auto_enable_agent_property(self):
        policy = _policy(auto_enable_agent=True)
        assert policy.auto_enable_agent is True

    def test_default_resource_access_property(self):
        policy = _policy(default_resource_access=["hr-system", "finance"])
        assert policy.default_resource_access == ["hr-system", "finance"]

    def test_default_resource_access_empty(self):
        policy = _policy(default_resource_access=[])
        assert policy.default_resource_access == []


# ============================================================================
# Dynamic pattern loading from gateway_config store
# ============================================================================

class _FakeStore:
    """Minimal dict-backed store implementing get/set_gateway_config."""

    def __init__(self):
        self._data: dict = {}

    def get_gateway_config(self, key: str):
        return self._data.get(key)

    def set_gateway_config(self, key: str, value, **kwargs):
        self._data[key] = value


class TestDCRPolicyDynamicPatterns:
    """Tests for store-backed dynamic redirect pattern loading."""

    def _make_policy(self, store=None, env_patterns=None, ttl=300.0):
        patterns = env_patterns if env_patterns is not None else [
            "http://localhost:*/callback",
            "http://127.0.0.1:*/callback",
        ]
        return DCRPolicy(
            enabled=True,
            store=store,
            allowed_redirect_patterns=patterns,
            pattern_cache_ttl_seconds=ttl,
        )

    async def test_store_empty_seeds_from_env(self):
        """When store is empty and env fallback is populated, first call seeds the store."""
        store = _FakeStore()
        policy = self._make_policy(store=store)
        result = await policy.validate(_valid_request(), source_ip="10.0.0.1")
        assert result.allowed is True
        # Store should now contain the seeded patterns
        from okta_agent_proxy.auth.dcr_policy import GATEWAY_CONFIG_KEY_REDIRECT_PATTERNS
        stored = store.get_gateway_config(GATEWAY_CONFIG_KEY_REDIRECT_PATTERNS)
        assert stored == ["http://localhost:*/callback", "http://127.0.0.1:*/callback"]

    async def test_store_patterns_used_over_env(self):
        """When store has patterns, those are used instead of env fallback."""
        store = _FakeStore()
        from okta_agent_proxy.auth.dcr_policy import GATEWAY_CONFIG_KEY_REDIRECT_PATTERNS
        store.set_gateway_config(
            GATEWAY_CONFIG_KEY_REDIRECT_PATTERNS,
            ["https://myapp.example.com/callback"],
        )
        policy = self._make_policy(store=store)
        # localhost should be rejected since store overrides env
        result = await policy.validate(
            _valid_request(redirect_uris=["http://localhost:9999/callback"]),
            source_ip="10.0.0.1",
        )
        assert result.allowed is False
        # The store pattern should work
        result2 = await policy.validate(
            _valid_request(redirect_uris=["https://myapp.example.com/callback"]),
            source_ip="10.0.0.1",
        )
        assert result2.allowed is True

    async def test_invalid_stored_patterns_dropped(self):
        """Invalid patterns in the store are silently dropped."""
        store = _FakeStore()
        from okta_agent_proxy.auth.dcr_policy import GATEWAY_CONFIG_KEY_REDIRECT_PATTERNS
        # Mix of valid and invalid patterns
        store.set_gateway_config(
            GATEWAY_CONFIG_KEY_REDIRECT_PATTERNS,
            [
                "http://localhost:*/callback",    # valid
                "javascript:alert(1)",            # invalid (dangerous scheme)
                "",                               # invalid (empty)
                "http://127.0.0.1:*/callback",    # valid
            ],
        )
        policy = self._make_policy(store=store)
        # Valid localhost pattern should still work
        result = await policy.validate(
            _valid_request(redirect_uris=["http://localhost:8080/callback"]),
            source_ip="10.0.0.1",
        )
        assert result.allowed is True

    async def test_l1_cache_avoids_repeated_store_reads(self):
        """Consecutive validate() calls within TTL only read the store once."""
        from unittest.mock import MagicMock
        from okta_agent_proxy.auth.dcr_policy import GATEWAY_CONFIG_KEY_REDIRECT_PATTERNS

        store = _FakeStore()
        store.set_gateway_config(
            GATEWAY_CONFIG_KEY_REDIRECT_PATTERNS,
            ["http://localhost:*/callback"],
        )
        store.get_gateway_config = MagicMock(wraps=store.get_gateway_config)

        policy = self._make_policy(store=store, ttl=300.0)

        # First call loads from store
        await policy.validate(_valid_request(), source_ip="10.0.0.1")
        count_after_first = store.get_gateway_config.call_count

        # Subsequent calls should use L1 cache
        await policy.validate(_valid_request(), source_ip="10.0.0.1")
        await policy.validate(_valid_request(), source_ip="10.0.0.1")
        assert store.get_gateway_config.call_count == count_after_first

    async def test_invalidate_forces_store_reread(self):
        """After invalidate_pattern_cache(), the next validate() re-reads the store."""
        from unittest.mock import MagicMock
        from okta_agent_proxy.auth.dcr_policy import GATEWAY_CONFIG_KEY_REDIRECT_PATTERNS

        store = _FakeStore()
        store.set_gateway_config(
            GATEWAY_CONFIG_KEY_REDIRECT_PATTERNS,
            ["http://localhost:*/callback"],
        )
        store.get_gateway_config = MagicMock(wraps=store.get_gateway_config)

        policy = self._make_policy(store=store, ttl=300.0)

        # First call
        await policy.validate(_valid_request(), source_ip="10.0.0.1")
        count_after_first = store.get_gateway_config.call_count

        # Invalidate
        policy.invalidate_pattern_cache()

        # Next call should re-read
        await policy.validate(_valid_request(), source_ip="10.0.0.1")
        assert store.get_gateway_config.call_count == count_after_first + 1

    async def test_malformed_stored_pattern_does_not_raise(self):
        """A malformed pattern in the store does not cause validate() to raise."""
        store = _FakeStore()
        from okta_agent_proxy.auth.dcr_policy import GATEWAY_CONFIG_KEY_REDIRECT_PATTERNS
        # Write a pattern that bypasses the validator (directly to store)
        store._data[GATEWAY_CONFIG_KEY_REDIRECT_PATTERNS] = [
            "not a valid uri at all !!!",
            "http://localhost:*/callback",
        ]
        policy = self._make_policy(store=store)
        # Should not raise — invalid pattern is dropped
        result = await policy.validate(_valid_request(), source_ip="10.0.0.1")
        assert result.allowed is True


# ============================================================================
# Pub/sub subscriber tests
# ============================================================================

class _FakeEventBus:
    """Minimal event bus for testing pub/sub registration."""

    def __init__(self):
        self.callbacks: dict[str, list] = {}

    async def subscribe(self, channel: str, callback):
        self.callbacks.setdefault(channel, []).append(callback)

    async def publish(self, channel: str, message: str):
        for cb in self.callbacks.get(channel, []):
            await cb(message)


class TestDCRPolicyPubSubSubscriber:
    """Tests for pub/sub-based pattern cache invalidation."""

    async def test_publish_invalidates_cache(self):
        """Publishing an invalidation event clears the L1 cache."""
        from okta_agent_proxy.auth.dcr_policy import GATEWAY_CONFIG_KEY_REDIRECT_PATTERNS
        from okta_agent_proxy.cache.pubsub import CHANNEL_DCR_PATTERNS_INVALIDATE

        store = _FakeStore()
        store.set_gateway_config(
            GATEWAY_CONFIG_KEY_REDIRECT_PATTERNS,
            ["http://localhost:*/callback"],
        )
        bus = _FakeEventBus()
        policy = DCRPolicy(
            enabled=True, store=store, event_bus=bus,
            allowed_redirect_patterns=["http://localhost:*/callback"],
        )

        await policy.register_pubsub_subscriber()

        # Populate L1 cache
        await policy.validate(_valid_request(), source_ip="10.0.0.1")
        assert policy._cached_patterns is not None

        # Publish invalidation event
        await bus.publish(
            CHANNEL_DCR_PATTERNS_INVALIDATE,
            '{"user":"admin","ts":"2025-01-01T00:00:00Z"}',
        )
        assert policy._cached_patterns is None

    async def test_register_is_idempotent(self):
        """Calling register_pubsub_subscriber twice only registers one callback."""
        from okta_agent_proxy.cache.pubsub import CHANNEL_DCR_PATTERNS_INVALIDATE

        bus = _FakeEventBus()
        policy = DCRPolicy(
            enabled=True, event_bus=bus,
            allowed_redirect_patterns=["http://localhost:*/callback"],
        )

        await policy.register_pubsub_subscriber()
        await policy.register_pubsub_subscriber()
        assert len(bus.callbacks.get(CHANNEL_DCR_PATTERNS_INVALIDATE, [])) == 1

    async def test_invalidation_event_forces_store_reread(self):
        """After an invalidation event, the next validate() re-reads the store."""
        from unittest.mock import MagicMock
        from okta_agent_proxy.auth.dcr_policy import GATEWAY_CONFIG_KEY_REDIRECT_PATTERNS
        from okta_agent_proxy.cache.pubsub import CHANNEL_DCR_PATTERNS_INVALIDATE

        store = _FakeStore()
        store.set_gateway_config(
            GATEWAY_CONFIG_KEY_REDIRECT_PATTERNS,
            ["http://localhost:*/callback"],
        )
        store.get_gateway_config = MagicMock(wraps=store.get_gateway_config)

        bus = _FakeEventBus()
        policy = DCRPolicy(
            enabled=True, store=store, event_bus=bus,
            allowed_redirect_patterns=["http://localhost:*/callback"],
            pattern_cache_ttl_seconds=300.0,
        )

        await policy.register_pubsub_subscriber()

        # First validate populates L1
        await policy.validate(_valid_request(), source_ip="10.0.0.1")
        count_after_first = store.get_gateway_config.call_count

        # Invalidation event
        await bus.publish(CHANNEL_DCR_PATTERNS_INVALIDATE, '{}')

        # Next validate should re-read
        await policy.validate(_valid_request(), source_ip="10.0.0.1")
        assert store.get_gateway_config.call_count == count_after_first + 1

    async def test_no_event_bus_register_is_noop(self):
        """With event_bus=None, register_pubsub_subscriber is a no-op."""
        policy = DCRPolicy(
            enabled=True, event_bus=None,
            allowed_redirect_patterns=["http://localhost:*/callback"],
        )
        # Should not raise
        await policy.register_pubsub_subscriber()
        assert policy._pubsub_registered is False
