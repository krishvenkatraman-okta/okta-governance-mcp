"""
Tests for app lifecycle wiring of Resource Map components.

As of DB migration P07 these tests depend on the removed SQLAlchemy
models (``storage/models.py``) and the legacy ``ResourceMapStore`` that
took a ``sessionmaker``.  The equivalent lifecycle wiring now uses the
psycopg3 ``DatabasePool``; coverage of the remaining behaviour lives in
``tests/test_postgres_repository.py`` and the integration suite.
"""

import pytest

pytest.skip(
    "Superseded by P07 — SQLAlchemy models removed; rewrite against "
    "psycopg3 fixtures if needed.",
    allow_module_level=True,
)

from unittest.mock import MagicMock  # noqa: E402
from sqlalchemy import create_engine  # noqa: E402
from sqlalchemy.orm import sessionmaker  # noqa: E402

from okta_agent_proxy.storage.models import Base  # noqa: E402
from okta_agent_proxy.storage.postgres import ResourceMapStore  # noqa: E402
from okta_agent_proxy.resources.models import (
    OktaConnectionType,
    OktaScopeCondition,
    ResourceMapEntry,
)
from okta_agent_proxy.resources.local_syncer import LocalResourceMapSyncer


# ============================================================================
# Fixtures
# ============================================================================


@pytest.fixture
def local_engine():
    engine = create_engine(
        "sqlite:///:memory:",
        connect_args={"check_same_thread": False},
        echo=False,
    )
    Base.metadata.create_all(engine)
    yield engine
    Base.metadata.drop_all(engine)
    engine.dispose()


@pytest.fixture
def local_store(local_engine):
    factory = sessionmaker(bind=local_engine)
    store = ResourceMapStore(factory)
    store.create(ResourceMapEntry(
        resource_id="aus001",
        name="hr-system",
        mcp_url="https://hr.example.com/mcp",
    ))
    store.create(ResourceMapEntry(
        resource_id="sec002",
        name="finance-api",
        mcp_url="https://finance.example.com/mcp",
        protocol="a2a",
    ))
    store.load_cache()
    return store


@pytest.fixture
def local_syncer(local_store):
    return LocalResourceMapSyncer(resource_map_store=local_store)


# ============================================================================
# LocalResourceMapSyncer
# ============================================================================


class TestLocalResourceMapSyncer:

    @pytest.mark.asyncio
    async def test_start_builds_resources(self, local_syncer):
        await local_syncer.start()
        resources = local_syncer.get_all_resources()
        assert len(resources) == 2

    @pytest.mark.asyncio
    async def test_get_resource_by_name(self, local_syncer):
        await local_syncer.start()
        hr = local_syncer.get_resource("hr-system")
        assert hr is not None
        assert hr.mcp_url == "https://hr.example.com/mcp"
        assert hr.resource_id == "aus001"

    @pytest.mark.asyncio
    async def test_get_resource_unknown(self, local_syncer):
        await local_syncer.start()
        assert local_syncer.get_resource("nonexistent") is None

    @pytest.mark.asyncio
    async def test_protocol_preserved(self, local_syncer):
        await local_syncer.start()
        finance = local_syncer.get_resource("finance-api")
        assert finance.protocol == "a2a"

    @pytest.mark.asyncio
    async def test_default_connection_type(self, local_syncer):
        await local_syncer.start()
        hr = local_syncer.get_resource("hr-system")
        assert hr.connection_type == OktaConnectionType.IDENTITY_ASSERTION_CUSTOM_AS
        assert hr.scope_condition == OktaScopeCondition.ALLOW_ALL

    @pytest.mark.asyncio
    async def test_connection_id_has_local_prefix(self, local_syncer):
        await local_syncer.start()
        hr = local_syncer.get_resource("hr-system")
        assert hr.connection_id.startswith("local:")

    @pytest.mark.asyncio
    async def test_unresolved_always_empty(self, local_syncer):
        await local_syncer.start()
        assert local_syncer.get_unresolved() == []

    @pytest.mark.asyncio
    async def test_is_stale_always_false(self, local_syncer):
        assert local_syncer.is_stale() is False

    @pytest.mark.asyncio
    async def test_sync_status(self, local_syncer):
        await local_syncer.start()
        status = local_syncer.get_sync_status()
        assert status["status"] == "local"
        assert status["resources_count"] == 2
        assert status["is_stale"] is False

    @pytest.mark.asyncio
    async def test_sync_reloads_from_store(self, local_syncer, local_store):
        await local_syncer.start()
        assert len(local_syncer.get_all_resources()) == 2

        # Add a new entry to the store
        local_store.create(ResourceMapEntry(
            resource_id="new001",
            name="new-svc",
            mcp_url="https://new.example.com/mcp",
        ))
        local_store.load_cache()

        await local_syncer.sync()
        assert len(local_syncer.get_all_resources()) == 3

    @pytest.mark.asyncio
    async def test_on_resource_changed_reloads(self, local_syncer, local_store):
        await local_syncer.start()
        assert len(local_syncer.get_all_resources()) == 2

        local_store.create(ResourceMapEntry(
            resource_id="added001",
            name="added-svc",
            mcp_url="https://added.example.com/mcp",
        ))

        await local_syncer._on_resource_changed("update")
        assert len(local_syncer.get_all_resources()) == 3

    @pytest.mark.asyncio
    async def test_stop_is_noop(self, local_syncer):
        await local_syncer.start()
        await local_syncer.stop()
        # Should not raise or change state


# ============================================================================
# Config fields
# ============================================================================


class TestConfigFields:

    def test_default_sync_interval(self, monkeypatch):
        monkeypatch.setenv("OKTA_DOMAIN", "dev-test.okta.com")
        from okta_agent_proxy.config import GatewaySettings
        settings = GatewaySettings()
        assert settings.okta_sync_interval_seconds == 300

    def test_default_stale_threshold(self, monkeypatch):
        monkeypatch.setenv("OKTA_DOMAIN", "dev-test.okta.com")
        from okta_agent_proxy.config import GatewaySettings
        settings = GatewaySettings()
        assert settings.okta_sync_stale_threshold == 1800

    def test_default_poll_interval(self, monkeypatch):
        monkeypatch.setenv("OKTA_DOMAIN", "dev-test.okta.com")
        from okta_agent_proxy.config import GatewaySettings
        settings = GatewaySettings()
        assert settings.cache_poll_interval_seconds == 30

    def test_custom_values(self, monkeypatch):
        monkeypatch.setenv("OKTA_DOMAIN", "dev-test.okta.com")
        monkeypatch.setenv("OKTA_SYNC_INTERVAL_SECONDS", "60")
        monkeypatch.setenv("OKTA_SYNC_STALE_THRESHOLD", "600")
        monkeypatch.setenv("CACHE_POLL_INTERVAL_SECONDS", "10")
        from okta_agent_proxy.config import GatewaySettings
        settings = GatewaySettings()
        assert settings.okta_sync_interval_seconds == 60
        assert settings.okta_sync_stale_threshold == 600
        assert settings.cache_poll_interval_seconds == 10

    def test_agent_id_default_empty(self, monkeypatch):
        monkeypatch.setenv("OKTA_DOMAIN", "dev-test.okta.com")
        from okta_agent_proxy.config import GatewaySettings
        settings = GatewaySettings()
        assert settings.okta_ai_agent_id == ""

    def test_service_token_default_empty(self, monkeypatch):
        monkeypatch.setenv("OKTA_DOMAIN", "dev-test.okta.com")
        from okta_agent_proxy.config import GatewaySettings
        settings = GatewaySettings()
        assert settings.okta_service_token == ""
