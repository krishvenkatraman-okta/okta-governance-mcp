"""
Tests for the /oauth/pre-consent route (standalone pre-consent flow).

Tests (Prompt 3):
- Missing agent_id → 400
- Unknown agent_id → 404
- Disabled agent → 404
- Agent missing Okta credentials → 400
- Happy path → 302 redirect to Okta
- Target resource param stored on session
- Scopes list format → space-joined in URL
- Scopes string format → passed through
- Audit event emitted

Tests (Prompt 4):
- Callback dispatches pre-consent vs relay
- Unknown state falls through to relay
- Pre-consent callback no matching resources
- Pre-consent callback creates standalone transaction
- Pre-consent callback sets session cookie and redirects
- Pre-consent callback emits authenticated audit event
- Pre-consent callback emits tx_created with standalone mode
- Pre-consent callback agent deleted between init and callback
- Pre-consent callback token exchange failure
- OAuth return tx_created includes mode field

Tests (Prompt 5):
- Interstitial standalone title
- Interstitial oauth_return title (regression)
- Consent complete standalone returns HTML
- Consent complete standalone renders summary
- Consent complete standalone deletes cookie
- Consent complete standalone no gateway code issued
- Consent complete standalone emits audit with mode
- Consent complete oauth_return still redirects (regression)
- Consent complete oauth_return audit includes mode (regression)
- Preconsent nothing to verify renders safely (XSS)
- Preconsent complete HTML singular/plural
"""

import pytest
from unittest.mock import AsyncMock, MagicMock, patch
from urllib.parse import urlparse, parse_qs

from starlette.applications import Starlette
from starlette.routing import Route
from starlette.requests import Request
from starlette.responses import JSONResponse
from starlette.testclient import TestClient

from okta_agent_proxy.audit.events import AuditEventType
from okta_agent_proxy.auth.confidential_relay import RelayError


# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

AGENT_ID = "test-agent"
CLIENT_ID = "0oaTestClientId"
CLIENT_SECRET = "testClientSecret123"
OKTA_DOMAIN = "dev-test.okta.com"
OKTA_AUTHORIZE_URL = f"https://{OKTA_DOMAIN}/oauth2/v1/authorize"


def _make_agent_config(
    agent_id=AGENT_ID,
    client_id=CLIENT_ID,
    client_secret=CLIENT_SECRET,
    enabled=True,
    scopes=None,
):
    cfg = {
        "agent_id": agent_id,
        "client_id": client_id,
        "client_secret": client_secret,
        "enabled": enabled,
        "resource_access": ["hr-system"],
    }
    if scopes is not None:
        cfg["scopes"] = scopes
    return cfg


# ---------------------------------------------------------------------------
# Minimal app builder — mirrors the real route logic but with injected deps
# ---------------------------------------------------------------------------

def _build_app(store_mock, relay_mock, audit_mock):
    """Build a minimal Starlette app with the /oauth/pre-consent route."""
    from starlette.responses import RedirectResponse

    async def oauth_pre_consent(request: Request):
        agent_id = request.query_params.get("agent_id", "").strip()
        target_resource = request.query_params.get("resource") or None

        if not agent_id:
            return JSONResponse(
                {"error": "invalid_request", "error_description": "Missing agent_id"},
                status_code=400,
            )

        agent_config = store_mock.get_agent(agent_id, enabled_only=True)
        if not agent_config:
            return JSONResponse(
                {"error": "unknown_agent", "error_description": f"No enabled agent found for agent_id={agent_id}"},
                status_code=404,
            )

        relay_client_id = agent_config.get("client_id", "")
        relay_client_secret = agent_config.get("client_secret", "")
        if not relay_client_id or not relay_client_secret:
            return JSONResponse(
                {
                    "error": "agent_not_configured",
                    "error_description": "Agent has no Okta client credentials configured",
                },
                status_code=400,
            )

        scopes_list = agent_config.get("scopes", ["openid", "profile", "email"])
        if isinstance(scopes_list, str):
            scopes_str = scopes_list
        else:
            scopes_str = " ".join(scopes_list)

        await audit_mock(
            AuditEventType.STS_PRECONSENT_INITIATED,
            details={
                "agent_id": agent_id,
                "target_resource": target_resource,
                "ip_address": request.client.host if request.client else "",
                "user_agent": request.headers.get("user-agent", "")[:256],
            },
        )

        try:
            okta_url = await relay_mock.start_preconsent_authorization(
                agent_id=agent_id,
                relay_client_id=relay_client_id,
                relay_client_secret=relay_client_secret,
                scopes=scopes_str,
                target_resource=target_resource,
            )
        except RelayError as e:
            return JSONResponse(
                {"error": "relay_error", "error_description": str(e)},
                status_code=500,
            )

        return RedirectResponse(url=okta_url, status_code=302)

    app = Starlette(
        routes=[Route("/oauth/pre-consent", oauth_pre_consent, methods=["GET"])],
    )
    return app


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

@pytest.fixture()
def mock_store():
    s = MagicMock()
    s.get_agent.return_value = _make_agent_config()
    return s


@pytest.fixture()
def mock_relay():
    relay = MagicMock()
    relay.start_preconsent_authorization = AsyncMock(
        return_value=(
            f"{OKTA_AUTHORIZE_URL}?client_id={CLIENT_ID}"
            f"&response_type=code&scope=openid+profile+email"
            f"&code_challenge_method=S256&state=abc123"
        )
    )
    relay._preconsent_sessions_by_state = {}
    return relay


@pytest.fixture()
def mock_audit():
    return AsyncMock()


@pytest.fixture()
def client(mock_store, mock_relay, mock_audit):
    app = _build_app(mock_store, mock_relay, mock_audit)
    return TestClient(app, raise_server_exceptions=False)


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------


class TestPreConsentRoute:
    def test_pre_consent_missing_agent_id(self, client):
        """GET /oauth/pre-consent without agent_id returns 400."""
        resp = client.get("/oauth/pre-consent")
        assert resp.status_code == 400
        body = resp.json()
        assert body["error"] == "invalid_request"
        assert "Missing" in body["error_description"]

    def test_pre_consent_unknown_agent_id(self, mock_store, mock_relay, mock_audit):
        """Unknown agent_id returns 404 with error: unknown_agent."""
        mock_store.get_agent.return_value = None
        app = _build_app(mock_store, mock_relay, mock_audit)
        client = TestClient(app, raise_server_exceptions=False)
        resp = client.get("/oauth/pre-consent?agent_id=nonexistent")
        assert resp.status_code == 404
        assert resp.json()["error"] == "unknown_agent"

    def test_pre_consent_disabled_agent(self, mock_store, mock_relay, mock_audit):
        """Disabled agent returns 404 because get_agent is called with enabled_only=True."""
        mock_store.get_agent.return_value = None
        app = _build_app(mock_store, mock_relay, mock_audit)
        client = TestClient(app, raise_server_exceptions=False)
        resp = client.get(f"/oauth/pre-consent?agent_id={AGENT_ID}")
        assert resp.status_code == 404
        mock_store.get_agent.assert_called_with(AGENT_ID, enabled_only=True)

    def test_pre_consent_agent_missing_okta_credentials(self, mock_store, mock_relay, mock_audit):
        """Agent with empty client_id or client_secret returns 400."""
        mock_store.get_agent.return_value = _make_agent_config(client_id="", client_secret="")
        app = _build_app(mock_store, mock_relay, mock_audit)
        client = TestClient(app, raise_server_exceptions=False)
        resp = client.get(f"/oauth/pre-consent?agent_id={AGENT_ID}")
        assert resp.status_code == 400
        assert resp.json()["error"] == "agent_not_configured"

    def test_pre_consent_happy_path_redirects_to_okta(self, client, mock_relay):
        """Valid agent_id returns 302 redirect to Okta authorize endpoint."""
        resp = client.get(
            f"/oauth/pre-consent?agent_id={AGENT_ID}",
            follow_redirects=False,
        )
        assert resp.status_code == 302
        location = resp.headers["location"]
        assert OKTA_DOMAIN in location
        assert f"client_id={CLIENT_ID}" in location
        assert "response_type=code" in location
        assert "code_challenge_method=S256" in location

        mock_relay.start_preconsent_authorization.assert_awaited_once()
        call_kwargs = mock_relay.start_preconsent_authorization.call_args
        assert call_kwargs.kwargs["agent_id"] == AGENT_ID
        assert call_kwargs.kwargs["relay_client_id"] == CLIENT_ID
        assert call_kwargs.kwargs["relay_client_secret"] == CLIENT_SECRET

    def test_pre_consent_with_target_resource(self, client, mock_relay):
        """Query param resource=Y is passed to start_preconsent_authorization."""
        resp = client.get(
            f"/oauth/pre-consent?agent_id={AGENT_ID}&resource=hr-system",
            follow_redirects=False,
        )
        assert resp.status_code == 302
        call_kwargs = mock_relay.start_preconsent_authorization.call_args
        assert call_kwargs.kwargs["target_resource"] == "hr-system"

    def test_pre_consent_scopes_list_format(self, mock_store, mock_relay, mock_audit):
        """Agent config with scopes as list produces space-joined scope string."""
        mock_store.get_agent.return_value = _make_agent_config(
            scopes=["openid", "profile", "email"]
        )
        app = _build_app(mock_store, mock_relay, mock_audit)
        client = TestClient(app, raise_server_exceptions=False)
        resp = client.get(
            f"/oauth/pre-consent?agent_id={AGENT_ID}",
            follow_redirects=False,
        )
        assert resp.status_code == 302
        call_kwargs = mock_relay.start_preconsent_authorization.call_args
        assert call_kwargs.kwargs["scopes"] == "openid profile email"

    def test_pre_consent_scopes_string_format(self, mock_store, mock_relay, mock_audit):
        """Agent config with scopes as string passes through unchanged."""
        mock_store.get_agent.return_value = _make_agent_config(
            scopes="openid profile"
        )
        app = _build_app(mock_store, mock_relay, mock_audit)
        client = TestClient(app, raise_server_exceptions=False)
        resp = client.get(
            f"/oauth/pre-consent?agent_id={AGENT_ID}",
            follow_redirects=False,
        )
        assert resp.status_code == 302
        call_kwargs = mock_relay.start_preconsent_authorization.call_args
        assert call_kwargs.kwargs["scopes"] == "openid profile"

    def test_pre_consent_emits_audit_event(self, client, mock_audit):
        """STS_PRECONSENT_INITIATED audit event is emitted with agent_id, ip, user_agent."""
        resp = client.get(
            f"/oauth/pre-consent?agent_id={AGENT_ID}",
            follow_redirects=False,
        )
        assert resp.status_code == 302

        mock_audit.assert_awaited()
        audit_calls = [
            c for c in mock_audit.call_args_list
            if c.args and c.args[0] == AuditEventType.STS_PRECONSENT_INITIATED
        ]
        assert len(audit_calls) == 1
        details = audit_calls[0].kwargs["details"]
        assert details["agent_id"] == AGENT_ID
        assert "ip_address" in details
        assert "user_agent" in details


# ===========================================================================
# Prompt 4 — Callback dispatcher and pre-consent callback handler
# ===========================================================================

# Fake ConsentTransaction for testing
class _FakeTransaction:
    def __init__(self, transaction_id="tx-1234", session_id="sess-abcd", mode="standalone"):
        self.transaction_id = transaction_id
        self.session_id = session_id
        self.mode = mode


def _build_callback_app(
    store_mock,
    relay_mock,
    audit_mock,
    consent_store_mock,
    consent_service_mock,
):
    """Build a minimal Starlette app with /oauth/callback that mirrors
    the dispatch logic from app.py (pre-consent vs relay)."""
    from starlette.responses import HTMLResponse, RedirectResponse
    from urllib.parse import urlencode
    import hashlib as _hashlib
    import asyncio

    async def oauth_callback(request: Request):
        code = request.query_params.get("code")
        state = request.query_params.get("state")

        if not code or not state:
            return JSONResponse(
                {"error": "invalid_request", "error_description": "Missing code or state parameter"},
                status_code=400,
            )

        # Dispatch: pre-consent sessions have their own handler path.
        if relay_mock.is_preconsent_state(state):
            return await _handle_preconsent_callback(request, code, state)

        # Normal relay flow
        try:
            callback_result = await relay_mock.handle_callback_tokens_only(state, code)
        except RelayError as e:
            return JSONResponse(
                {"error": "relay_error", "error_description": str(e)},
                status_code=400,
            )

        original_client_id = callback_result["original_client_id"]
        agent_config = None
        agent_id = None
        try:
            agent_config = store_mock.get_agent(original_client_id, enabled_only=True)
            if agent_config:
                agent_id = agent_config.get("agent_id", "")
        except Exception:
            pass

        has_sts = False
        target_resource = callback_result.get("target_resource")
        sts_resources = []
        if agent_config and agent_id:
            sts_resources = consent_service_mock.get_sts_resources(agent_id, agent_config)
            matching_resources = consent_service_mock.filter_resources_by_target(
                sts_resources, target_resource
            )
            has_sts = len(matching_resources) > 0

        if not has_sts:
            redirect_params = {"code": "gw-code", "state": callback_result["original_state"]}
            redirect_url = f"{callback_result['original_redirect_uri']}?{urlencode(redirect_params)}"
            return RedirectResponse(url=redirect_url, status_code=302)

        # STS connections exist
        ua_hash = _hashlib.sha256(
            request.headers.get("user-agent", "").encode()
        ).hexdigest()[:16]

        transaction = consent_store_mock.create(
            original_redirect_uri=callback_result["original_redirect_uri"],
            original_state=callback_result["original_state"],
            original_client_id=original_client_id,
            id_token=callback_result["id_token"],
            access_token=callback_result["access_token"],
            refresh_token=callback_result.get("refresh_token"),
            okta_expires_in=callback_result.get("expires_in"),
            agent_id=agent_id,
            agent_config=agent_config,
            ip_address=request.client.host if request.client else "",
            user_agent_hash=ua_hash,
            relay_client_id=callback_result.get("relay_client_id", ""),
            relay_client_secret=callback_result.get("relay_client_secret", ""),
            target_resource=callback_result.get("target_resource"),
        )

        await audit_mock(
            AuditEventType.STS_CONSENT_TX_CREATED,
            details={
                "transaction_id": transaction.transaction_id,
                "agent_id": agent_id,
                "client_id": original_client_id,
                "mode": "oauth_return",
                "sts_resource_count": len(sts_resources),
                "target_resource": callback_result.get("target_resource"),
            },
        )

        asyncio.create_task(consent_service_mock.verify_all(transaction))

        response = RedirectResponse(
            url=f"/oauth/consent-verify?tx={transaction.transaction_id}",
            status_code=302,
        )
        response.set_cookie(
            "__okta_consent_session",
            value=transaction.session_id,
            httponly=True,
            secure=request.url.hostname not in ("localhost", "127.0.0.1"),
            samesite="lax",
            path="/oauth",
            max_age=600,
        )
        return response

    async def _handle_preconsent_callback(request, code, state):
        try:
            result = await relay_mock.handle_preconsent_callback(state, code)
        except RelayError as e:
            return JSONResponse(
                {"error": "relay_error", "error_description": str(e)},
                status_code=400,
            )

        agent_id = result["agent_id"]
        id_token = result["id_token"]
        target_resource = result.get("target_resource")

        agent_config = store_mock.get_agent(agent_id, enabled_only=True)
        if not agent_config:
            return JSONResponse({"error": "unknown_agent"}, status_code=404)

        await audit_mock(
            AuditEventType.STS_PRECONSENT_AUTHENTICATED,
            details={
                "agent_id": agent_id,
                "ip_address": request.client.host if request.client else "",
                "user_agent": request.headers.get("user-agent", "")[:256],
            },
        )

        sts_resources = consent_service_mock.get_sts_resources(agent_id, agent_config)
        matching_resources = consent_service_mock.filter_resources_by_target(
            sts_resources, target_resource
        )

        if not matching_resources:
            return HTMLResponse(
                "<!DOCTYPE html><html><head><title>All Set</title></head>"
                f"<body><h1>Nothing to authorize</h1>"
                f"<p>No STS-managed connections require verification for this agent. "
                f"You can close this tab and return to your client.</p></body></html>"
            )

        ua_hash = _hashlib.sha256(
            request.headers.get("user-agent", "").encode()
        ).hexdigest()[:16]

        transaction = consent_store_mock.create(
            mode="standalone",
            id_token=id_token,
            agent_id=agent_id,
            agent_config=agent_config,
            target_resource=target_resource,
            ip_address=request.client.host if request.client else "",
            user_agent_hash=ua_hash,
            original_client_id="",
            original_redirect_uri="",
            original_state="",
            access_token="",
            refresh_token=None,
            okta_expires_in=None,
            relay_client_id="",
            relay_client_secret="",
        )

        await audit_mock(
            AuditEventType.STS_CONSENT_TX_CREATED,
            details={
                "transaction_id": transaction.transaction_id,
                "agent_id": agent_id,
                "client_id": "",
                "mode": "standalone",
                "sts_resource_count": len(matching_resources),
                "target_resource": target_resource,
            },
        )

        asyncio.create_task(consent_service_mock.verify_all(transaction))

        response = RedirectResponse(
            url=f"/oauth/consent-verify?tx={transaction.transaction_id}",
            status_code=302,
        )
        response.set_cookie(
            "__okta_consent_session",
            value=transaction.session_id,
            httponly=True,
            secure=request.url.hostname not in ("localhost", "127.0.0.1"),
            samesite="lax",
            path="/oauth",
            max_age=600,
        )
        return response

    app = Starlette(
        routes=[Route("/oauth/callback", oauth_callback, methods=["GET"])],
    )
    return app


def _make_relay_callback_result(**overrides):
    """Build a normal relay callback_result dict."""
    defaults = {
        "original_client_id": CLIENT_ID,
        "original_redirect_uri": "http://localhost:9999/callback",
        "original_state": "orig-state-xyz",
        "access_token": "at-abc123",
        "id_token": "idt-abc123",
        "refresh_token": "rt-abc123",
        "expires_in": 3600,
        "relay_client_id": "relay-cid",
        "relay_client_secret": "relay-cs",
        "target_resource": None,
    }
    defaults.update(overrides)
    return defaults


@pytest.fixture()
def mock_consent_store():
    cs = MagicMock()
    cs.create.return_value = _FakeTransaction()
    return cs


@pytest.fixture()
def mock_consent_service():
    svc = MagicMock()
    svc.get_sts_resources.return_value = []
    svc.filter_resources_by_target.return_value = []
    svc.verify_all = AsyncMock()
    return svc


@pytest.fixture()
def callback_relay():
    """Relay mock configured for callback tests."""
    relay = MagicMock()
    relay.is_preconsent_state = MagicMock(return_value=False)
    relay.handle_callback_tokens_only = AsyncMock(return_value=_make_relay_callback_result())
    relay.handle_preconsent_callback = AsyncMock(return_value={
        "id_token": "idt-preconsent-123",
        "agent_id": AGENT_ID,
        "target_resource": None,
    })
    relay._preconsent_sessions_by_state = {}
    return relay


@pytest.fixture()
def callback_client(mock_store, callback_relay, mock_audit, mock_consent_store, mock_consent_service):
    app = _build_callback_app(mock_store, callback_relay, mock_audit, mock_consent_store, mock_consent_service)
    return TestClient(app, raise_server_exceptions=False)


class TestCallbackDispatch:
    """Prompt 4 tests for /oauth/callback dispatcher and pre-consent callback handler."""

    def test_callback_dispatches_preconsent_vs_relay(
        self, mock_store, callback_relay, mock_audit, mock_consent_store, mock_consent_service
    ):
        """Pre-consent state dispatches to pre-consent handler; relay state goes to relay path."""
        # Pre-consent state
        callback_relay.is_preconsent_state.side_effect = lambda s: s == "preconsent-state"
        callback_relay.handle_preconsent_callback = AsyncMock(return_value={
            "id_token": "idt-pc",
            "agent_id": AGENT_ID,
            "target_resource": None,
        })
        callback_relay.handle_callback_tokens_only = AsyncMock(return_value=_make_relay_callback_result())

        app = _build_callback_app(mock_store, callback_relay, mock_audit, mock_consent_store, mock_consent_service)
        client = TestClient(app, raise_server_exceptions=False)

        # Hit with pre-consent state → should call handle_preconsent_callback
        client.get("/oauth/callback?code=abc&state=preconsent-state", follow_redirects=False)
        callback_relay.handle_preconsent_callback.assert_awaited_once_with("preconsent-state", "abc")
        callback_relay.handle_callback_tokens_only.assert_not_awaited()

        # Reset
        callback_relay.handle_preconsent_callback.reset_mock()
        callback_relay.handle_callback_tokens_only.reset_mock()

        # Hit with relay state → should call handle_callback_tokens_only
        client.get("/oauth/callback?code=def&state=relay-state", follow_redirects=False)
        callback_relay.handle_callback_tokens_only.assert_awaited_once_with("relay-state", "def")
        callback_relay.handle_preconsent_callback.assert_not_awaited()

    def test_callback_unknown_state_falls_through_to_relay(
        self, mock_store, callback_relay, mock_audit, mock_consent_store, mock_consent_service
    ):
        """Unknown state (neither pre-consent nor known relay) falls through to relay handler."""
        callback_relay.is_preconsent_state.return_value = False
        callback_relay.handle_callback_tokens_only = AsyncMock(
            side_effect=RelayError("Unknown relay session")
        )
        app = _build_callback_app(mock_store, callback_relay, mock_audit, mock_consent_store, mock_consent_service)
        client = TestClient(app, raise_server_exceptions=False)

        resp = client.get("/oauth/callback?code=xyz&state=unknown-state", follow_redirects=False)
        # Relay handler is called (and errors) — not the pre-consent handler
        callback_relay.handle_callback_tokens_only.assert_awaited_once()
        callback_relay.handle_preconsent_callback.assert_not_awaited()
        assert resp.status_code == 400
        assert resp.json()["error"] == "relay_error"

    def test_preconsent_callback_no_matching_resources(
        self, mock_store, callback_relay, mock_audit, mock_consent_store, mock_consent_service
    ):
        """Agent with zero STS resources returns HTML 'Nothing to authorize', no transaction."""
        callback_relay.is_preconsent_state.return_value = True
        mock_consent_service.get_sts_resources.return_value = []
        mock_consent_service.filter_resources_by_target.return_value = []

        app = _build_callback_app(mock_store, callback_relay, mock_audit, mock_consent_store, mock_consent_service)
        client = TestClient(app, raise_server_exceptions=False)

        resp = client.get("/oauth/callback?code=abc&state=pc-state", follow_redirects=False)
        assert resp.status_code == 200
        assert "Nothing to authorize" in resp.text
        mock_consent_store.create.assert_not_called()

    def test_preconsent_callback_creates_standalone_transaction(
        self, mock_store, callback_relay, mock_audit, mock_consent_store, mock_consent_service
    ):
        """Agent with STS resources creates a transaction with mode=standalone and empty OAuth-return fields."""
        callback_relay.is_preconsent_state.return_value = True
        mock_consent_service.get_sts_resources.return_value = [{"name": "jira"}]
        mock_consent_service.filter_resources_by_target.return_value = [{"name": "jira"}]

        app = _build_callback_app(mock_store, callback_relay, mock_audit, mock_consent_store, mock_consent_service)
        client = TestClient(app, raise_server_exceptions=False)

        resp = client.get("/oauth/callback?code=abc&state=pc-state", follow_redirects=False)
        assert resp.status_code == 302

        mock_consent_store.create.assert_called_once()
        call_kwargs = mock_consent_store.create.call_args.kwargs
        assert call_kwargs["mode"] == "standalone"
        assert call_kwargs["id_token"] == "idt-preconsent-123"
        assert call_kwargs["agent_id"] == AGENT_ID
        assert call_kwargs["original_client_id"] == ""
        assert call_kwargs["original_redirect_uri"] == ""
        assert call_kwargs["original_state"] == ""
        assert call_kwargs["access_token"] == ""
        assert call_kwargs["relay_client_id"] == ""
        assert call_kwargs["relay_client_secret"] == ""

    def test_preconsent_callback_sets_session_cookie_and_redirects(
        self, mock_store, callback_relay, mock_audit, mock_consent_store, mock_consent_service
    ):
        """Response is 302 to /oauth/consent-verify?tx=..., sets __okta_consent_session cookie."""
        callback_relay.is_preconsent_state.return_value = True
        mock_consent_service.get_sts_resources.return_value = [{"name": "jira"}]
        mock_consent_service.filter_resources_by_target.return_value = [{"name": "jira"}]
        mock_consent_store.create.return_value = _FakeTransaction(
            transaction_id="tx-ABCD", session_id="sess-XYZ"
        )

        app = _build_callback_app(mock_store, callback_relay, mock_audit, mock_consent_store, mock_consent_service)
        client = TestClient(app, raise_server_exceptions=False)

        resp = client.get("/oauth/callback?code=abc&state=pc-state", follow_redirects=False)
        assert resp.status_code == 302
        assert "/oauth/consent-verify?tx=tx-ABCD" in resp.headers["location"]

        cookie = resp.cookies.get("__okta_consent_session")
        assert cookie == "sess-XYZ"
        # Verify cookie attributes from the raw Set-Cookie header
        set_cookie = resp.headers.get("set-cookie", "")
        assert "httponly" in set_cookie.lower()
        assert "samesite=lax" in set_cookie.lower()
        assert "path=/oauth" in set_cookie.lower()

    def test_preconsent_callback_emits_authenticated_audit_event(
        self, mock_store, callback_relay, mock_audit, mock_consent_store, mock_consent_service
    ):
        """STS_PRECONSENT_AUTHENTICATED fires with agent_id, ip_address, user_agent."""
        callback_relay.is_preconsent_state.return_value = True
        # No STS resources — so we hit the "nothing to verify" path and still emit the event
        mock_consent_service.get_sts_resources.return_value = []
        mock_consent_service.filter_resources_by_target.return_value = []

        app = _build_callback_app(mock_store, callback_relay, mock_audit, mock_consent_store, mock_consent_service)
        client = TestClient(app, raise_server_exceptions=False)

        resp = client.get("/oauth/callback?code=abc&state=pc-state", follow_redirects=False)
        assert resp.status_code == 200  # HTML page

        auth_calls = [
            c for c in mock_audit.call_args_list
            if c.args and c.args[0] == AuditEventType.STS_PRECONSENT_AUTHENTICATED
        ]
        assert len(auth_calls) == 1
        details = auth_calls[0].kwargs["details"]
        assert details["agent_id"] == AGENT_ID
        assert "ip_address" in details
        assert "user_agent" in details

    def test_preconsent_callback_emits_tx_created_with_standalone_mode(
        self, mock_store, callback_relay, mock_audit, mock_consent_store, mock_consent_service
    ):
        """STS_CONSENT_TX_CREATED fires with mode=standalone."""
        callback_relay.is_preconsent_state.return_value = True
        mock_consent_service.get_sts_resources.return_value = [{"name": "jira"}]
        mock_consent_service.filter_resources_by_target.return_value = [{"name": "jira"}]

        app = _build_callback_app(mock_store, callback_relay, mock_audit, mock_consent_store, mock_consent_service)
        client = TestClient(app, raise_server_exceptions=False)

        resp = client.get("/oauth/callback?code=abc&state=pc-state", follow_redirects=False)
        assert resp.status_code == 302

        tx_calls = [
            c for c in mock_audit.call_args_list
            if c.args and c.args[0] == AuditEventType.STS_CONSENT_TX_CREATED
        ]
        assert len(tx_calls) == 1
        details = tx_calls[0].kwargs["details"]
        assert details["mode"] == "standalone"
        assert details["sts_resource_count"] == 1

    def test_preconsent_callback_agent_deleted_between_init_and_callback(
        self, mock_store, callback_relay, mock_audit, mock_consent_store, mock_consent_service
    ):
        """If agent is disabled/deleted after /oauth/pre-consent but before callback, return 404."""
        callback_relay.is_preconsent_state.return_value = True
        mock_store.get_agent.return_value = None  # Agent gone

        app = _build_callback_app(mock_store, callback_relay, mock_audit, mock_consent_store, mock_consent_service)
        client = TestClient(app, raise_server_exceptions=False)

        resp = client.get("/oauth/callback?code=abc&state=pc-state", follow_redirects=False)
        assert resp.status_code == 404
        assert resp.json()["error"] == "unknown_agent"
        mock_consent_store.create.assert_not_called()

    def test_preconsent_callback_token_exchange_failure(
        self, mock_store, callback_relay, mock_audit, mock_consent_store, mock_consent_service
    ):
        """Okta returns 401 on token exchange → 400 error, no transaction created."""
        callback_relay.is_preconsent_state.return_value = True
        callback_relay.handle_preconsent_callback = AsyncMock(
            side_effect=RelayError("Pre-consent token exchange failed: 401 Unauthorized")
        )

        app = _build_callback_app(mock_store, callback_relay, mock_audit, mock_consent_store, mock_consent_service)
        client = TestClient(app, raise_server_exceptions=False)

        resp = client.get("/oauth/callback?code=abc&state=pc-state", follow_redirects=False)
        assert resp.status_code == 400
        assert resp.json()["error"] == "relay_error"
        assert "401" in resp.json()["error_description"]
        mock_consent_store.create.assert_not_called()

    def test_oauth_return_tx_created_includes_mode_field(
        self, mock_store, callback_relay, mock_audit, mock_consent_store, mock_consent_service
    ):
        """Regression: the existing relay flow's STS_CONSENT_TX_CREATED includes mode=oauth_return."""
        callback_relay.is_preconsent_state.return_value = False
        callback_relay.handle_callback_tokens_only = AsyncMock(
            return_value=_make_relay_callback_result()
        )
        # Agent has STS resources
        mock_store.get_agent.return_value = _make_agent_config()
        mock_consent_service.get_sts_resources.return_value = [{"name": "jira"}]
        mock_consent_service.filter_resources_by_target.return_value = [{"name": "jira"}]

        app = _build_callback_app(mock_store, callback_relay, mock_audit, mock_consent_store, mock_consent_service)
        client = TestClient(app, raise_server_exceptions=False)

        resp = client.get("/oauth/callback?code=abc&state=relay-state", follow_redirects=False)
        assert resp.status_code == 302

        tx_calls = [
            c for c in mock_audit.call_args_list
            if c.args and c.args[0] == AuditEventType.STS_CONSENT_TX_CREATED
        ]
        assert len(tx_calls) == 1
        details = tx_calls[0].kwargs["details"]
        assert details["mode"] == "oauth_return"


# ===========================================================================
# Prompt 5 — Interstitial mode awareness and standalone completion
# ===========================================================================

import hashlib
import time

from okta_agent_proxy.auth.consent_transaction import (
    ConsentConnectionStatus,
    ConsentTransaction,
    ConsentTransactionStore,
)
def _ensure_app_imported():
    """Ensure okta_agent_proxy.app is fully importable by mocking the DB if needed."""
    import sys
    mod = sys.modules.get("okta_agent_proxy.app")
    if mod is not None and hasattr(mod, "_build_consent_interstitial_html"):
        return

    sys.modules.pop("okta_agent_proxy.app", None)

    import okta_agent_proxy.database as _db_mod
    _orig_get = _db_mod.get_config_store
    _orig_store = _db_mod._config_store
    _mock_store = MagicMock()
    _mock_store.get_all_resources.return_value = []
    _mock_store.get_all_agents.return_value = []
    _db_mod.get_config_store = lambda **kw: _mock_store
    _db_mod._config_store = _mock_store
    try:
        import importlib
        import okta_agent_proxy.app
        importlib.reload(okta_agent_proxy.app)
    except Exception:
        sys.modules.pop("okta_agent_proxy.app", None)
        raise
    finally:
        _db_mod.get_config_store = _orig_get
        _db_mod._config_store = _orig_store


def _import_html_builders():
    """Import HTML builders from app.py, mocking DB if needed."""
    _ensure_app_imported()
    from okta_agent_proxy.app import (
        _build_consent_interstitial_html,
        _build_preconsent_nothing_to_verify_html,
        _build_preconsent_complete_html,
    )
    return (
        _build_consent_interstitial_html,
        _build_preconsent_nothing_to_verify_html,
        _build_preconsent_complete_html,
    )


def _ua_hash(ua: str = "testclient") -> str:
    return hashlib.sha256(ua.encode()).hexdigest()[:16]


def _build_consent_complete_app(
    consent_store,
    code_manager_mock=None,
    audit_mock=None,
):
    """Build a minimal Starlette app with consent-verify and consent-complete routes."""
    from starlette.responses import HTMLResponse, RedirectResponse
    from urllib.parse import urlencode

    (
        _build_consent_interstitial_html,
        _build_preconsent_nothing_to_verify_html,
        _build_preconsent_complete_html,
    ) = _import_html_builders()

    async def consent_verify(request: Request):
        tx_id = request.query_params.get("tx", "")
        session_id = request.cookies.get("__okta_consent_session", "")

        if not tx_id or not session_id:
            return HTMLResponse("<h1>Invalid</h1>", status_code=400)

        ua_hash = hashlib.sha256(
            request.headers.get("user-agent", "").encode()
        ).hexdigest()[:16]

        tx = consent_store.validate_session(
            session_id=session_id,
            ip_address=request.client.host if request.client else "",
            user_agent_hash=ua_hash,
        )

        if not tx or tx.transaction_id != tx_id:
            return HTMLResponse("<h1>Session Invalid</h1>", status_code=403)

        html = _build_consent_interstitial_html(
            tx_id,
            is_standalone=(tx.mode == "standalone"),
        )
        return HTMLResponse(html)

    async def consent_complete(request: Request):
        form = await request.form()
        tx_id = form.get("tx", "")
        session_id = request.cookies.get("__okta_consent_session", "")

        if not tx_id or not session_id:
            return JSONResponse({"error": "invalid_request"}, status_code=400)

        ua_hash = hashlib.sha256(
            request.headers.get("user-agent", "").encode()
        ).hexdigest()[:16]

        tx = consent_store.validate_session(
            session_id=session_id,
            ip_address=request.client.host if request.client else "",
            user_agent_hash=ua_hash,
        )

        if not tx or tx.transaction_id != tx_id:
            return HTMLResponse(
                "<h1>Session Expired</h1>", status_code=400,
            )

        # Branch by mode
        if tx.mode == "standalone":
            verified = sum(1 for c in tx.connections if c.status == "verified")
            skipped = sum(1 for c in tx.connections if c.status in ("skipped", "consent_required"))
            errors = sum(1 for c in tx.connections if c.status == "error")

            if audit_mock:
                await audit_mock(
                    AuditEventType.STS_CONSENT_TX_COMPLETED,
                    details={
                        "transaction_id": tx.transaction_id,
                        "agent_id": tx.agent_id,
                        "client_id": "",
                        "mode": "standalone",
                        "verified_count": verified,
                        "skipped_count": skipped,
                        "error_count": errors,
                    },
                )

            consent_store.remove(tx.transaction_id)

            response = HTMLResponse(
                _build_preconsent_complete_html(verified, skipped, errors)
            )
            response.delete_cookie("__okta_consent_session", path="/oauth")
            return response

        # --- oauth_return mode ---
        gateway_code = "gw-code-xyz"
        if code_manager_mock:
            gateway_code = code_manager_mock.issue_code(
                client_id=tx.original_client_id,
                tokens={
                    "access_token": tx.access_token,
                    "id_token": tx.id_token,
                    "refresh_token": tx.refresh_token,
                    "expires_in": tx.okta_expires_in,
                },
            )

        redirect_params = {"code": gateway_code, "state": tx.original_state}
        redirect_url = f"{tx.original_redirect_uri}?{urlencode(redirect_params)}"

        if audit_mock:
            await audit_mock(
                AuditEventType.STS_CONSENT_TX_COMPLETED,
                details={
                    "transaction_id": tx.transaction_id,
                    "agent_id": tx.agent_id,
                    "client_id": tx.original_client_id,
                    "mode": "oauth_return",
                    "verified_count": sum(1 for c in tx.connections if c.status == "verified"),
                    "skipped_count": sum(1 for c in tx.connections if c.status in ("skipped", "consent_required")),
                    "error_count": sum(1 for c in tx.connections if c.status == "error"),
                },
            )

        consent_store.remove(tx.transaction_id)

        response = RedirectResponse(url=redirect_url, status_code=302)
        response.delete_cookie("__okta_consent_session", path="/oauth")
        return response

    return Starlette(routes=[
        Route("/oauth/consent-verify", consent_verify, methods=["GET"]),
        Route("/oauth/consent-complete", consent_complete, methods=["POST"]),
    ])


def _create_standalone_tx(store, connections=None):
    """Create a standalone transaction and return (tx, session_id)."""
    tx = store.create(
        mode="standalone",
        id_token="idt-standalone",
        agent_id="test-agent",
        agent_config={"client_id": "0oa_xyz"},
        ip_address="testclient",
        user_agent_hash=_ua_hash(),
        original_client_id="",
        original_redirect_uri="",
        original_state="",
        access_token="",
        refresh_token=None,
        okta_expires_in=None,
        relay_client_id="",
        relay_client_secret="",
    )
    if connections:
        tx.connections = connections
    return tx


def _create_oauth_return_tx(store, connections=None):
    """Create an oauth_return transaction and return it."""
    tx = store.create(
        mode="oauth_return",
        id_token="idt-return",
        access_token="at-return",
        refresh_token="rt-return",
        okta_expires_in=3600,
        agent_id="test-agent",
        agent_config={"client_id": "0oa_xyz"},
        ip_address="testclient",
        user_agent_hash=_ua_hash(),
        original_client_id="https://app.example.com/oauth.json",
        original_redirect_uri="http://localhost:9999/callback",
        original_state="orig-state-abc",
        relay_client_id="relay-cid",
        relay_client_secret="relay-cs",
    )
    if connections:
        tx.connections = connections
    return tx


class TestInterstitialModeAwareness:
    """Prompt 5 — interstitial title/copy varies by tx.mode."""

    def test_interstitial_standalone_title(self):
        """Standalone transaction shows 'Authorize New Connections' and 'Finish'."""
        store = ConsentTransactionStore()
        tx = _create_standalone_tx(store)

        app = _build_consent_complete_app(store)
        client = TestClient(app)
        client.cookies.set("__okta_consent_session", tx.session_id)

        resp = client.get(f"/oauth/consent-verify?tx={tx.transaction_id}")
        assert resp.status_code == 200
        assert "Authorize New Connections" in resp.text
        assert "finish" in resp.text.lower()

    def test_interstitial_oauth_return_title(self):
        """Regression: oauth_return flow shows 'Verifying Access' and 'Continue'."""
        store = ConsentTransactionStore()
        tx = _create_oauth_return_tx(store)

        app = _build_consent_complete_app(store)
        client = TestClient(app)
        client.cookies.set("__okta_consent_session", tx.session_id)

        resp = client.get(f"/oauth/consent-verify?tx={tx.transaction_id}")
        assert resp.status_code == 200
        assert "Verifying Access" in resp.text
        assert "continue" in resp.text.lower()
        # Should NOT contain standalone copy
        assert "Authorize New Connections" not in resp.text


class TestConsentCompleteModeBranching:
    """Prompt 5 — consent-complete branches on tx.mode."""

    def test_consent_complete_standalone_returns_html(self):
        """Completing a standalone transaction returns HTML 200, not a 302 redirect."""
        store = ConsentTransactionStore()
        connections = [
            ConsentConnectionStatus(
                connection_id="c1", resource_name="github",
                provider="GitHub", resource_indicator="orn:1",
                status="verified",
            ),
        ]
        tx = _create_standalone_tx(store, connections=connections)

        app = _build_consent_complete_app(store)
        client = TestClient(app, raise_server_exceptions=False)
        client.cookies.set("__okta_consent_session", tx.session_id)

        resp = client.post(
            "/oauth/consent-complete",
            data={"tx": tx.transaction_id},
            follow_redirects=False,
        )
        assert resp.status_code == 200
        assert "text/html" in resp.headers["content-type"]

    def test_consent_complete_standalone_renders_summary(self):
        """Response body contains 'You're all set' and counts."""
        store = ConsentTransactionStore()
        connections = [
            ConsentConnectionStatus(
                connection_id="c1", resource_name="github",
                provider="GitHub", resource_indicator="orn:1",
                status="verified",
            ),
            ConsentConnectionStatus(
                connection_id="c2", resource_name="jira",
                provider="Jira", resource_indicator="orn:2",
                status="consent_required",
            ),
            ConsentConnectionStatus(
                connection_id="c3", resource_name="slack",
                provider="Slack", resource_indicator="orn:3",
                status="error",
            ),
        ]
        tx = _create_standalone_tx(store, connections=connections)

        app = _build_consent_complete_app(store)
        client = TestClient(app, raise_server_exceptions=False)
        client.cookies.set("__okta_consent_session", tx.session_id)

        resp = client.post(
            "/oauth/consent-complete",
            data={"tx": tx.transaction_id},
            follow_redirects=False,
        )
        assert resp.status_code == 200
        body = resp.text
        assert "You&#x27;re all set" in body or "You're all set" in body
        assert "1 authorized" in body
        assert "1 skipped" in body
        assert "1 error" in body

    def test_consent_complete_standalone_deletes_cookie(self):
        """Response deletes __okta_consent_session cookie."""
        store = ConsentTransactionStore()
        tx = _create_standalone_tx(store)

        app = _build_consent_complete_app(store)
        client = TestClient(app, raise_server_exceptions=False)
        client.cookies.set("__okta_consent_session", tx.session_id)

        resp = client.post(
            "/oauth/consent-complete",
            data={"tx": tx.transaction_id},
            follow_redirects=False,
        )
        assert resp.status_code == 200
        # Check set-cookie header deletes the cookie
        set_cookie = resp.headers.get("set-cookie", "")
        assert "__okta_consent_session" in set_cookie
        # Deletion is done by setting max-age=0 or expires in the past
        assert 'max-age=0' in set_cookie.lower() or "expires=" in set_cookie.lower()

    def test_consent_complete_standalone_no_gateway_code_issued(self):
        """After standalone completion, no gateway code is issued."""
        store = ConsentTransactionStore()
        tx = _create_standalone_tx(store)

        code_manager = MagicMock()
        code_manager.issue_code.return_value = "gw-code-should-not-be-issued"

        app = _build_consent_complete_app(store, code_manager_mock=code_manager)
        client = TestClient(app, raise_server_exceptions=False)
        client.cookies.set("__okta_consent_session", tx.session_id)

        resp = client.post(
            "/oauth/consent-complete",
            data={"tx": tx.transaction_id},
            follow_redirects=False,
        )
        assert resp.status_code == 200
        code_manager.issue_code.assert_not_called()

    def test_consent_complete_standalone_emits_audit_with_mode(self):
        """STS_CONSENT_TX_COMPLETED fires with mode: 'standalone' and count fields."""
        store = ConsentTransactionStore()
        connections = [
            ConsentConnectionStatus(
                connection_id="c1", resource_name="github",
                provider="GitHub", resource_indicator="orn:1",
                status="verified",
            ),
            ConsentConnectionStatus(
                connection_id="c2", resource_name="jira",
                provider="Jira", resource_indicator="orn:2",
                status="consent_required",
            ),
        ]
        tx = _create_standalone_tx(store, connections=connections)

        audit = AsyncMock()
        app = _build_consent_complete_app(store, audit_mock=audit)
        client = TestClient(app, raise_server_exceptions=False)
        client.cookies.set("__okta_consent_session", tx.session_id)

        resp = client.post(
            "/oauth/consent-complete",
            data={"tx": tx.transaction_id},
            follow_redirects=False,
        )
        assert resp.status_code == 200

        audit.assert_awaited_once()
        call_args = audit.call_args
        assert call_args.args[0] == AuditEventType.STS_CONSENT_TX_COMPLETED
        details = call_args.kwargs["details"]
        assert details["mode"] == "standalone"
        assert details["verified_count"] == 1
        assert details["skipped_count"] == 1
        assert details["error_count"] == 0
        assert details["client_id"] == ""

    def test_consent_complete_oauth_return_still_redirects(self):
        """Regression: oauth_return flow still issues a gateway code and returns 302."""
        store = ConsentTransactionStore()
        tx = _create_oauth_return_tx(store)

        code_manager = MagicMock()
        code_manager.issue_code.return_value = "gw-code-123"

        app = _build_consent_complete_app(store, code_manager_mock=code_manager)
        client = TestClient(app, raise_server_exceptions=False)
        client.cookies.set("__okta_consent_session", tx.session_id)

        resp = client.post(
            "/oauth/consent-complete",
            data={"tx": tx.transaction_id},
            follow_redirects=False,
        )
        assert resp.status_code == 302
        location = resp.headers["location"]
        assert "code=gw-code-123" in location
        assert "state=orig-state-abc" in location
        assert "localhost:9999/callback" in location
        code_manager.issue_code.assert_called_once()

    def test_consent_complete_oauth_return_audit_includes_mode(self):
        """Regression: STS_CONSENT_TX_COMPLETED for oauth_return includes mode field."""
        store = ConsentTransactionStore()
        tx = _create_oauth_return_tx(store)

        audit = AsyncMock()
        app = _build_consent_complete_app(store, audit_mock=audit)
        client = TestClient(app, raise_server_exceptions=False)
        client.cookies.set("__okta_consent_session", tx.session_id)

        resp = client.post(
            "/oauth/consent-complete",
            data={"tx": tx.transaction_id},
            follow_redirects=False,
        )
        assert resp.status_code == 302

        audit.assert_awaited_once()
        details = audit.call_args.kwargs["details"]
        assert details["mode"] == "oauth_return"
        assert details["client_id"] == "https://app.example.com/oauth.json"


class TestHtmlBuildersSafety:
    """Prompt 5 — HTML builder edge cases."""

    def test_preconsent_nothing_to_verify_renders_safely(self):
        """_build_preconsent_nothing_to_verify_html escapes agent_id to prevent XSS."""
        _, _build_preconsent_nothing_to_verify_html, _ = _import_html_builders()
        html = _build_preconsent_nothing_to_verify_html('<script>alert(1)</script>')
        assert "<script>alert(1)</script>" not in html
        assert "&lt;script&gt;" in html
        assert "Nothing to authorize" in html

    def test_preconsent_complete_html_singular_plural(self):
        """Verify correct singular/plural forms in completion page."""
        _, _, _build_preconsent_complete_html = _import_html_builders()
        # 1 connection → singular
        html1 = _build_preconsent_complete_html(1, 0, 0)
        assert "1 authorized" in html1
        assert "1 connection" in html1
        assert "connections" not in html1

        # 2 connections → plural
        html2 = _build_preconsent_complete_html(2, 0, 0)
        assert "2 authorized" in html2
        assert "2 connections" in html2

        # mixed with error singular
        html3 = _build_preconsent_complete_html(1, 0, 1)
        assert "1 authorized" in html3
        assert "1 error" in html3
        assert "2 connections" in html3

        # errors plural
        html4 = _build_preconsent_complete_html(0, 0, 2)
        assert "2 errors" in html4
