"""Tests for the psycopg3 :class:`SyncStateRepository`."""

from __future__ import annotations

import pytest

from okta_agent_proxy.storage.repositories.sync_state_repo import (
    SyncStateRepository,
)


def _reset_sync_state(pool):
    with pool.connection() as conn:
        with conn.cursor() as cur:
            cur.execute("DELETE FROM okta_sync_state")
        conn.commit()


@pytest.fixture
def psycopg_pool(postgres_url):
    from okta_agent_proxy.storage.credentials import StaticUrlCredentialProvider
    from okta_agent_proxy.storage.pool import DatabasePool

    pool = DatabasePool(StaticUrlCredentialProvider(postgres_url))
    _reset_sync_state(pool)
    try:
        yield pool
    finally:
        _reset_sync_state(pool)
        pool.close()


def test_sync_state_empty_returns_none(psycopg_pool):
    repo = SyncStateRepository(psycopg_pool, encryption_service=None)
    assert repo.get_latest() is None


def test_sync_state_save_returns_latest(psycopg_pool):
    repo = SyncStateRepository(psycopg_pool, encryption_service=None)
    repo.save(status="success", resources_count=3, duration_ms=42)
    repo.save(status="failed", resources_count=0, unresolved_count=1, duration_ms=17)

    latest = repo.get_latest()
    assert latest is not None
    assert latest["status"] == "failed"
    assert latest["resources_count"] == 0
    assert latest["unresolved_count"] == 1
    assert latest["sync_duration_ms"] == 17
    assert latest["last_sync_at"] is not None


def test_sync_state_accepts_legacy_backends_count_kwarg(psycopg_pool):
    repo = SyncStateRepository(psycopg_pool, encryption_service=None)
    repo.save(status="success", backends_count=7)
    latest = repo.get_latest()
    assert latest["resources_count"] == 7
