"""
Tests for path uniqueness validation.

Ensures that path routes are unique across resources — no two resources
can silently claim the same path.
"""
import pytest
from okta_agent_proxy.routing.router import ResourceRouter
from okta_agent_proxy.config import ResourceConfig, ResourceAuthConfig


def make_resource(name, paths=None, url="http://localhost:9000"):
    return ResourceConfig(
        name=name, url=url, paths=paths or [],
        auth_method="pre-shared-key",
        auth_config=ResourceAuthConfig(key="test"),
    )


class TestPathConflictDetection:

    def test_no_conflict_when_paths_are_unique(self):
        resources = {"a": make_resource("a", paths=["/alpha"])}
        router = ResourceRouter(resources)
        assert router.get_path_conflicts("b", ["/beta"]) == []

    def test_conflict_detected_when_path_taken(self):
        resources = {"a": make_resource("a", paths=["/shared"])}
        router = ResourceRouter(resources)
        conflicts = router.get_path_conflicts("b", ["/shared"])
        assert len(conflicts) == 1
        assert conflicts[0]["path"] == "/shared"
        assert conflicts[0]["owned_by"] == "a"

    def test_no_conflict_with_own_paths(self):
        resources = {"a": make_resource("a", paths=["/alpha"])}
        router = ResourceRouter(resources)
        # Updating resource 'a' with its own path should not conflict
        assert router.get_path_conflicts("a", ["/alpha"]) == []

    def test_multiple_conflicts_reported(self):
        resources = {
            "a": make_resource("a", paths=["/one"]),
            "b": make_resource("b", paths=["/two"]),
        }
        router = ResourceRouter(resources)
        conflicts = router.get_path_conflicts("c", ["/one", "/two", "/three"])
        assert len(conflicts) == 2
        paths = [c["path"] for c in conflicts]
        assert "/one" in paths
        assert "/two" in paths

    def test_register_resource_warns_on_overwrite(self, caplog):
        resources = {"a": make_resource("a", paths=["/shared"])}
        router = ResourceRouter(resources)
        import logging
        with caplog.at_level(logging.WARNING):
            router.register_resource("b", make_resource("b", paths=["/shared"]))
        assert "Route conflict" in caplog.text
        assert "'a'" in caplog.text
        assert "'b'" in caplog.text

    def test_empty_paths_no_conflict(self):
        resources = {"a": make_resource("a", paths=["/alpha"])}
        router = ResourceRouter(resources)
        assert router.get_path_conflicts("b", []) == []
