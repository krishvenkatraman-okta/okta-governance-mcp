"""Tests for the psycopg3 connection pool and credential-provider stub (P02).

Pool tests require a reachable Postgres instance; they use the locally running
docker-compose Postgres at ``localhost:5432`` by default. Override via the
``TEST_POSTGRES_URL`` env var. Tests that need a live database are skipped
when one is not reachable so the suite stays portable.
"""

from __future__ import annotations

import os
from typing import Iterator

import psycopg
import pytest

from okta_agent_proxy.audit.events import AuditEventType
from okta_agent_proxy.storage.credentials import (
    DatabaseCredential,
    DatabaseCredentialProvider,
    StaticUrlCredentialProvider,
    get_credential_provider,
)
from okta_agent_proxy.storage.pool import DatabasePool


DEFAULT_POSTGRES_URL = "postgresql://gateway_user:gateway_pass@localhost:5432/gateway_db"


def _postgres_url() -> str:
    return os.environ.get("TEST_POSTGRES_URL", DEFAULT_POSTGRES_URL)


def _postgres_reachable(url: str) -> bool:
    try:
        with psycopg.connect(url, connect_timeout=2) as conn:
            with conn.cursor() as cur:
                cur.execute("SELECT 1")
                cur.fetchone()
        return True
    except Exception:
        return False


@pytest.fixture(scope="module")
def postgres_url() -> str:
    url = _postgres_url()
    if not _postgres_reachable(url):
        pytest.skip(f"No reachable Postgres at {url}")
    return url


@pytest.fixture()
def static_pool(postgres_url: str, monkeypatch) -> Iterator[DatabasePool]:
    monkeypatch.setenv("DATABASE_URL", postgres_url)
    monkeypatch.delenv("DB_CREDENTIAL_PROVIDER", raising=False)
    provider = StaticUrlCredentialProvider()
    pool = DatabasePool(provider, min_size=1, max_size=2, timeout=10.0)
    try:
        yield pool
    finally:
        pool.close()


# ---------------------------------------------------------------------------
# Pure unit tests — no live database required
# ---------------------------------------------------------------------------


def test_static_url_provider_parses_database_url():
    provider = StaticUrlCredentialProvider(
        "postgresql://alice:wonder@db.example.com:6543/orders"
    )
    cred = provider.get_credential()
    assert cred.username == "alice"
    assert cred.password == "wonder"
    assert cred.host == "db.example.com"
    assert cred.port == 6543
    assert cred.dbname == "orders"
    assert cred.ttl_seconds is None
    assert provider.supports_rotation() is False
    assert provider.name == "static_url"


def test_static_url_provider_parses_sslmode_from_query():
    provider = StaticUrlCredentialProvider(
        "postgresql://u:p@h/db?sslmode=verify-full&sslrootcert=/tmp/ca.pem"
    )
    cred = provider.get_credential()
    assert cred.sslmode == "verify-full"
    assert cred.sslrootcert == "/tmp/ca.pem"


def test_static_url_provider_url_encoded_password():
    # DATABASE_URL with %21 in password should decode to '!'
    provider = StaticUrlCredentialProvider(
        "postgresql://user:p%40ss%21word@host:5432/db"
    )
    cred = provider.get_credential()
    assert cred.password == "p@ss!word"


def test_static_url_provider_missing_url_raises(monkeypatch):
    monkeypatch.delenv("DATABASE_URL", raising=False)
    with pytest.raises(RuntimeError, match="DATABASE_URL not set"):
        StaticUrlCredentialProvider()


def test_static_url_provider_bad_scheme_raises():
    with pytest.raises(RuntimeError, match="Unsupported scheme"):
        StaticUrlCredentialProvider("mysql://u:p@h/db")


def test_static_url_provider_from_env_requires_gate(monkeypatch):
    monkeypatch.setenv("DATABASE_URL", "postgresql://u:p@h:5432/db")
    monkeypatch.delenv("ALLOW_STATIC_DATABASE_PASSWORD", raising=False)
    with pytest.raises(RuntimeError, match="ALLOW_STATIC_DATABASE_PASSWORD=true"):
        StaticUrlCredentialProvider.from_env()


def test_static_url_provider_from_env_rejects_non_true_gate(monkeypatch):
    monkeypatch.setenv("DATABASE_URL", "postgresql://u:p@h:5432/db")
    monkeypatch.setenv("ALLOW_STATIC_DATABASE_PASSWORD", "yes")  # must be exactly "true"
    with pytest.raises(RuntimeError, match="ALLOW_STATIC_DATABASE_PASSWORD=true"):
        StaticUrlCredentialProvider.from_env()


def test_static_url_provider_from_env_accepts_gate(monkeypatch):
    monkeypatch.setenv("DATABASE_URL", "postgresql://u:p@h:5432/db")
    monkeypatch.setenv("ALLOW_STATIC_DATABASE_PASSWORD", "TRUE")  # case-insensitive
    provider = StaticUrlCredentialProvider.from_env()
    assert provider.name == "static_url"
    assert provider.get_credential().host == "h"


def test_static_url_provider_direct_construct_bypasses_gate(monkeypatch):
    # Direct construction (used by tests and programmatic callers) must not
    # require the env gate, so unit tests can exercise the parser freely.
    monkeypatch.delenv("ALLOW_STATIC_DATABASE_PASSWORD", raising=False)
    provider = StaticUrlCredentialProvider("postgresql://u:p@h:5432/db")
    assert provider.get_credential().host == "h"


def test_get_credential_provider_static_enforces_gate(monkeypatch):
    from okta_agent_proxy.storage.credentials import get_credential_provider

    monkeypatch.setenv("DATABASE_URL", "postgresql://u:p@h:5432/db")
    monkeypatch.delenv("DB_CREDENTIAL_PROVIDER", raising=False)  # defaults to static
    monkeypatch.delenv("ALLOW_STATIC_DATABASE_PASSWORD", raising=False)
    with pytest.raises(RuntimeError, match="ALLOW_STATIC_DATABASE_PASSWORD=true"):
        get_credential_provider()


def test_database_credential_to_conninfo_quotes_special_chars():
    cred = DatabaseCredential(
        username="alice",
        password="p ass'word",
        host="db.example.com",
        port=5432,
        dbname="orders",
        sslmode="require",
    )
    conninfo = cred.to_conninfo()
    # psycopg's make_conninfo must escape whitespace and single quotes so the
    # string is parseable by libpq.
    parsed = psycopg.conninfo.conninfo_to_dict(conninfo)
    assert parsed["password"] == "p ass'word"
    assert parsed["user"] == "alice"
    assert parsed["host"] == "db.example.com"
    assert parsed["dbname"] == "orders"
    assert parsed["sslmode"] == "require"


def test_database_credential_to_url_round_trip():
    cred = DatabaseCredential(
        username="svc",
        password="p@ss!word",
        host="h.example",
        port=5432,
        dbname="db",
        sslmode="require",
        sslrootcert="/opt/ca.pem",
    )
    url = cred.to_url()
    assert url.startswith("postgresql://svc:")
    # Special chars must be percent-encoded in the URL form.
    assert "%40" in url and "%21" in url
    assert "sslmode=require" in url
    assert "sslrootcert=" in url


def test_database_credential_defaults():
    cred = DatabaseCredential(
        username="u",
        password="p",
        host="h",
        port=5432,
        dbname="db",
    )
    assert cred.sslmode == "prefer"
    assert cred.sslrootcert is None
    assert cred.ttl_seconds is None


def test_get_credential_provider_default_is_static(monkeypatch):
    monkeypatch.delenv("DB_CREDENTIAL_PROVIDER", raising=False)
    monkeypatch.setenv("DATABASE_URL", "postgresql://u:p@h/db")
    monkeypatch.setenv("ALLOW_STATIC_DATABASE_PASSWORD", "true")
    provider = get_credential_provider()
    assert isinstance(provider, StaticUrlCredentialProvider)


def test_get_credential_provider_non_static_kinds_implemented(monkeypatch):
    # All three non-static providers are now real. rds_iam landed in P10,
    # azure_entra in P11, vault in P12. Positive coverage for each lives
    # in tests/test_credentials_{rds,azure,vault}.py; here we only assert
    # that the factory does not fall through to NotImplementedError.
    monkeypatch.setenv("DB_CREDENTIAL_PROVIDER", "vault")
    # Missing env vars trigger RuntimeError from the provider's own
    # validation — that's the real-provider error surface, not the old
    # stub's NotImplementedError.
    with pytest.raises(RuntimeError) as exc:
        get_credential_provider()
    assert "NotImplementedError" not in type(exc.value).__name__
    assert "HashiCorp Vault" in str(exc.value) or "VAULT_" in str(exc.value)


def test_get_credential_provider_unknown_kind_raises_runtime_error(monkeypatch):
    monkeypatch.setenv("DB_CREDENTIAL_PROVIDER", "gcp_cloud_sql")
    with pytest.raises(RuntimeError, match="Unknown DB_CREDENTIAL_PROVIDER"):
        get_credential_provider()


def test_db_lifecycle_audit_event_types_registered():
    # P02 adds the db.* audit event types; later prompts emit them.
    assert AuditEventType.DB_POOL_OPENED.value == "db.pool.opened"
    assert AuditEventType.DB_POOL_CLOSED.value == "db.pool.closed"
    assert AuditEventType.DB_CREDENTIAL_ROTATED.value == "db.credential.rotated"
    assert AuditEventType.DB_SCHEMA_VERSION_CHECKED.value == "db.schema.version_checked"
    assert (
        AuditEventType.DB_SCHEMA_VERSION_MISMATCH.value
        == "db.schema.version_mismatch"
    )
    assert AuditEventType.DB_MIGRATION_APPLIED.value == "db.migration.applied"
    assert AuditEventType.DB_MIGRATION_FAILED.value == "db.migration.failed"


class _FakeRotatingProvider(DatabaseCredentialProvider):
    name = "fake_rotating"

    def __init__(self, cred: DatabaseCredential):
        self._cred = cred

    def get_credential(self) -> DatabaseCredential:
        return self._cred

    def supports_rotation(self) -> bool:
        return True


# ---------------------------------------------------------------------------
# Pool tests — require a reachable Postgres instance
# ---------------------------------------------------------------------------


def test_pool_open_close(static_pool: DatabasePool):
    assert static_pool.provider_name == "static_url"
    # Verify we can acquire and release a connection.
    with static_pool.connection() as conn:
        assert conn.closed is False


def test_pool_executes_simple_query(static_pool: DatabasePool):
    with static_pool.connection() as conn:
        with conn.cursor() as cur:
            cur.execute("SELECT 1 AS answer")
            row = cur.fetchone()
    assert row == {"answer": 1}


def test_pool_returns_dict_rows(static_pool: DatabasePool):
    with static_pool.connection() as conn:
        with conn.cursor() as cur:
            cur.execute("SELECT current_database() AS db, 42 AS n")
            row = cur.fetchone()
    assert isinstance(row, dict)
    assert row["n"] == 42
    assert "db" in row


def test_pool_sets_application_name(static_pool: DatabasePool):
    with static_pool.connection() as conn:
        with conn.cursor() as cur:
            cur.execute("SHOW application_name")
            row = cur.fetchone()
    # dict_row is enabled, so SHOW returns {"application_name": "okta-mcp-adapter"}.
    assert "okta-mcp-adapter" in str(row.values())


def test_pool_close_is_idempotent(postgres_url: str, monkeypatch):
    monkeypatch.setenv("DATABASE_URL", postgres_url)
    pool = DatabasePool(StaticUrlCredentialProvider(), min_size=1, max_size=1)
    pool.close()
    pool.close()  # must not raise
    with pytest.raises(RuntimeError, match="not initialized"):
        pool.connection()
