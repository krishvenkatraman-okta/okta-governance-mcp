"""
Tests for ResourceRouter handling of vault-secret and sts-service-account
auth methods alongside okta-cross-app.

Covers:
- _get_vault_secret_token: retrieves secret via OktaVaultSecretExchanger, caches with shared key
- _get_sts_service_account_token: retrieves creds via exchanger, returns Basic auth, caches
- get_resource_token dispatches to correct method based on auth_method
- Cache key pattern: "secret:{resource}:{connection_id}" (shared across users)
- Error handling when exchanger fails
- Error handling when agent credentials are missing
- ResolvedResourceConfigAdapter.metadata property
"""

import base64
import pytest
from datetime import datetime, timedelta
from unittest.mock import AsyncMock, MagicMock, patch, PropertyMock

from okta_agent_proxy.routing.router import ResourceRouter, ResolvedResourceConfigAdapter


# ============================================================================
# Fixtures
# ============================================================================

@pytest.fixture
def mock_resolved_resource():
    """Create a mock ResolvedResource for wrapping in adapter."""
    def _make(auth_method="vault-secret", connection_id="conn-123",
              resource_id="res-456", name="test-backend",
              mcp_url="https://example.com", metadata=None):
        rb = MagicMock()
        rb.name = name
        rb.mcp_url = mcp_url
        rb.auth_method = auth_method
        rb.resource_id = resource_id
        rb.connection_id = connection_id
        rb.connection_type = MagicMock(value=auth_method)
        rb.protocol = "mcp"
        rb.description = "test"
        rb.scopes = []
        rb.scope_condition = MagicMock(value="ALLOW_ALL")
        rb.metadata = metadata or {}
        return rb
    return _make


@pytest.fixture
def router():
    """Create a ResourceRouter with minimal config."""
    return ResourceRouter(resources_config={})


@pytest.fixture
def agent_config():
    return {
        "agent_id": "test-agent",
        "client_id": "0oaXXXX",
        "private_key": '{"kty":"RSA","n":"test","e":"AQAB","d":"test"}',
        "principal_id": "wlpTestAgent",
        "okta_ai_agent_id": "agt-okta-123",
    }


FAKE_USER_TOKEN = "eyJ.fake.id-token"


def _mock_exchanger(exchange_result=None, svc_result=None):
    """Create a mock OktaVaultSecretExchanger."""
    exchanger = MagicMock()
    exchanger.exchange_vault_secret = AsyncMock(return_value=exchange_result)
    exchanger.exchange_service_account = AsyncMock(return_value=svc_result)
    return exchanger


# ============================================================================
# ResolvedResourceConfigAdapter.metadata
# ============================================================================

class TestAdapterMetadata:

    def test_metadata_exposed(self, mock_resolved_resource):
        rb = mock_resolved_resource(metadata={"secret_name": "api-key"})
        adapter = ResolvedResourceConfigAdapter(rb)
        assert adapter.metadata == {"secret_name": "api-key"}

    def test_metadata_empty_default(self, mock_resolved_resource):
        rb = mock_resolved_resource(metadata={})
        adapter = ResolvedResourceConfigAdapter(rb)
        assert adapter.metadata == {}


# ============================================================================
# _get_vault_secret_token
# ============================================================================

class TestGetVaultSecretToken:

    @pytest.mark.asyncio
    async def test_retrieves_and_caches(self, router, mock_resolved_resource, agent_config):
        rb = mock_resolved_resource(auth_method="vault-secret", connection_id="conn-vs-1")
        adapter = ResolvedResourceConfigAdapter(rb)

        exchanger = _mock_exchanger(exchange_result={
            "status": "success", "access_token": "s3cret-api-key",
            "token_type": "Bearer", "expires_in": 300, "provider": "test-backend",
        })

        with patch("okta_agent_proxy.routing.router.OktaVaultSecretExchanger", return_value=exchanger) as mock_cls:
            result = await router._get_vault_secret_token(
                "test-backend", adapter, agent_config, FAKE_USER_TOKEN
            )

        assert result == "s3cret-api-key"
        exchanger.exchange_vault_secret.assert_called_once()

    @pytest.mark.asyncio
    async def test_uses_cache(self, router, mock_resolved_resource, agent_config):
        rb = mock_resolved_resource(auth_method="vault-secret", connection_id="conn-vs-1")
        adapter = ResolvedResourceConfigAdapter(rb)

        # Pre-populate cache
        router.resource_token_cache.set(
            "secret:test-backend", "conn-vs-1",
            {"token": "cached-secret", "expires_at": datetime.now() + timedelta(seconds=300)},
            ttl_seconds=300,
        )

        result = await router._get_vault_secret_token(
            "test-backend", adapter, agent_config, FAKE_USER_TOKEN
        )
        assert result == "cached-secret"

    @pytest.mark.asyncio
    async def test_fails_without_user_id_token(self, router, mock_resolved_resource, agent_config):
        rb = mock_resolved_resource(auth_method="vault-secret")
        adapter = ResolvedResourceConfigAdapter(rb)

        result = await router._get_vault_secret_token("test-backend", adapter, agent_config)
        assert result is None

    @pytest.mark.asyncio
    async def test_fails_without_agent_config(self, router, mock_resolved_resource):
        rb = mock_resolved_resource(auth_method="vault-secret")
        adapter = ResolvedResourceConfigAdapter(rb)

        result = await router._get_vault_secret_token(
            "test-backend", adapter, None, FAKE_USER_TOKEN
        )
        assert result is None

    @pytest.mark.asyncio
    async def test_fails_when_exchange_returns_none(self, router, mock_resolved_resource, agent_config):
        rb = mock_resolved_resource(auth_method="vault-secret", connection_id="conn-1")
        adapter = ResolvedResourceConfigAdapter(rb)

        exchanger = _mock_exchanger(exchange_result=None)

        with patch("okta_agent_proxy.routing.router.OktaVaultSecretExchanger", return_value=exchanger):
            result = await router._get_vault_secret_token(
                "test-backend", adapter, agent_config, FAKE_USER_TOKEN
            )

        assert result is None

    @pytest.mark.asyncio
    async def test_fails_for_non_resolved_resource(self, router, agent_config):
        """vault-secret only works with ResolvedResourceConfigAdapter."""
        plain_config = MagicMock()
        plain_config.auth_method = "vault-secret"

        result = await router._get_vault_secret_token(
            "test-backend", plain_config, agent_config, FAKE_USER_TOKEN
        )
        assert result is None

    @pytest.mark.asyncio
    async def test_consent_required_returns_none(self, router, mock_resolved_resource, agent_config):
        rb = mock_resolved_resource(auth_method="vault-secret", connection_id="conn-1")
        adapter = ResolvedResourceConfigAdapter(rb)

        exchanger = _mock_exchanger(exchange_result={
            "status": "consent_required", "interaction_uri": "https://okta.com/consent",
            "provider": "test-backend",
        })

        with patch("okta_agent_proxy.routing.router.OktaVaultSecretExchanger", return_value=exchanger):
            result = await router._get_vault_secret_token(
                "test-backend", adapter, agent_config, FAKE_USER_TOKEN
            )

        assert result is None

    @pytest.mark.asyncio
    async def test_uses_resource_indicator_from_metadata(self, router, mock_resolved_resource, agent_config):
        rb = mock_resolved_resource(
            auth_method="vault-secret", connection_id="conn-1",
            metadata={"resource_indicator": "orn:okta:pam:00o:secrets:abc123"},
        )
        adapter = ResolvedResourceConfigAdapter(rb)

        exchanger = _mock_exchanger(exchange_result={
            "status": "success", "access_token": "secret-val",
            "expires_in": 300, "provider": "test-backend",
        })

        with patch("okta_agent_proxy.routing.router.OktaVaultSecretExchanger", return_value=exchanger):
            await router._get_vault_secret_token(
                "test-backend", adapter, agent_config, FAKE_USER_TOKEN
            )

        call_args = exchanger.exchange_vault_secret.call_args
        assert call_args[0][1] == "orn:okta:pam:00o:secrets:abc123"


# ============================================================================
# _get_sts_service_account_token
# ============================================================================

class TestGetStsServiceAccountToken:

    @pytest.mark.asyncio
    async def test_retrieves_and_returns_basic_auth(self, router, mock_resolved_resource, agent_config):
        rb = mock_resolved_resource(auth_method="sts-service-account", connection_id="conn-sa-1")
        adapter = ResolvedResourceConfigAdapter(rb)

        exchanger = _mock_exchanger(svc_result={
            "status": "success", "username": "svc-user", "password": "svc-pass",
            "provider": "test-backend",
        })

        with patch("okta_agent_proxy.routing.router.OktaVaultSecretExchanger", return_value=exchanger):
            result = await router._get_sts_service_account_token(
                "test-backend", adapter, agent_config, FAKE_USER_TOKEN
            )

        expected = base64.b64encode(b"svc-user:svc-pass").decode()
        assert result == f"Basic {expected}"

    @pytest.mark.asyncio
    async def test_uses_cache(self, router, mock_resolved_resource, agent_config):
        rb = mock_resolved_resource(auth_method="sts-service-account", connection_id="conn-sa-1")
        adapter = ResolvedResourceConfigAdapter(rb)

        expected = f"Basic {base64.b64encode(b'u:p').decode()}"
        router.resource_token_cache.set(
            "secret:test-backend", "conn-sa-1",
            {"token": expected, "expires_at": datetime.now() + timedelta(seconds=300)},
            ttl_seconds=300,
        )

        result = await router._get_sts_service_account_token(
            "test-backend", adapter, agent_config, FAKE_USER_TOKEN
        )
        assert result == expected

    @pytest.mark.asyncio
    async def test_fails_without_user_id_token(self, router, mock_resolved_resource, agent_config):
        rb = mock_resolved_resource(auth_method="sts-service-account")
        adapter = ResolvedResourceConfigAdapter(rb)

        result = await router._get_sts_service_account_token(
            "test-backend", adapter, agent_config
        )
        assert result is None

    @pytest.mark.asyncio
    async def test_fails_when_exchange_returns_none(self, router, mock_resolved_resource, agent_config):
        rb = mock_resolved_resource(auth_method="sts-service-account", connection_id="conn-1")
        adapter = ResolvedResourceConfigAdapter(rb)

        exchanger = _mock_exchanger(svc_result=None)

        with patch("okta_agent_proxy.routing.router.OktaVaultSecretExchanger", return_value=exchanger):
            result = await router._get_sts_service_account_token(
                "test-backend", adapter, agent_config, FAKE_USER_TOKEN
            )

        assert result is None

    @pytest.mark.asyncio
    async def test_bearer_fallback_when_no_username_password(self, router, mock_resolved_resource, agent_config):
        """When exchange returns access_token but no username/password, use Bearer."""
        rb = mock_resolved_resource(auth_method="sts-service-account", connection_id="conn-1")
        adapter = ResolvedResourceConfigAdapter(rb)

        exchanger = _mock_exchanger(svc_result={
            "status": "success", "access_token": "tok-123",
            "token_type": "Bearer", "expires_in": 300, "provider": "test-backend",
        })

        with patch("okta_agent_proxy.routing.router.OktaVaultSecretExchanger", return_value=exchanger):
            result = await router._get_sts_service_account_token(
                "test-backend", adapter, agent_config, FAKE_USER_TOKEN
            )

        assert result == "Bearer tok-123"


# ============================================================================
# get_resource_token dispatch
# ============================================================================

class TestGetResourceTokenDispatch:

    @pytest.mark.asyncio
    async def test_dispatches_vault_secret(self, router, mock_resolved_resource, agent_config):
        rb = mock_resolved_resource(auth_method="vault-secret", connection_id="conn-1", name="vs-resource")
        syncer = MagicMock()
        syncer.get_resource.return_value = rb
        syncer.get_all_resources.return_value = [rb]
        router.syncer = syncer

        exchanger = _mock_exchanger(exchange_result={
            "status": "success", "access_token": "secret123",
            "expires_in": 300, "provider": "vs-resource",
        })

        with patch("okta_agent_proxy.routing.router.OktaVaultSecretExchanger", return_value=exchanger):
            result = await router.get_resource_token(
                "user-1", "vs-resource", "id-token", agent_config=agent_config
            )

        assert result == "secret123"

    @pytest.mark.asyncio
    async def test_dispatches_sts_service_account(self, router, mock_resolved_resource, agent_config):
        rb = mock_resolved_resource(auth_method="sts-service-account", connection_id="conn-1", name="sa-resource")
        syncer = MagicMock()
        syncer.get_resource.return_value = rb
        syncer.get_all_resources.return_value = [rb]
        router.syncer = syncer

        exchanger = _mock_exchanger(svc_result={
            "status": "success", "username": "u", "password": "p",
            "provider": "sa-resource",
        })

        with patch("okta_agent_proxy.routing.router.OktaVaultSecretExchanger", return_value=exchanger):
            result = await router.get_resource_token(
                "user-1", "sa-resource", "id-token", agent_config=agent_config
            )

        expected = f"Basic {base64.b64encode(b'u:p').decode()}"
        assert result == expected

    @pytest.mark.asyncio
    async def test_non_xaa_returns_user_token(self, router):
        """Resources with unknown auth methods fall through to user token passthrough."""
        mock_config = MagicMock()
        mock_config.auth_method = "pre-shared-key"
        router.resources["psk-backend"] = mock_config

        result = await router.get_resource_token("user-1", "psk-backend", "user-token")
        assert result == "user-token"


# ============================================================================
# Cache key pattern
# ============================================================================

class TestCacheKeyPattern:

    @pytest.mark.asyncio
    async def test_shared_cache_key_across_users(self, router, mock_resolved_resource, agent_config):
        """Vault secret cache uses secret:{resource}:{connection_id}, not user-scoped."""
        rb = mock_resolved_resource(auth_method="vault-secret", connection_id="conn-shared")
        adapter = ResolvedResourceConfigAdapter(rb)

        exchanger = _mock_exchanger(exchange_result={
            "status": "success", "access_token": "shared-secret",
            "expires_in": 300, "provider": "test-backend",
        })

        with patch("okta_agent_proxy.routing.router.OktaVaultSecretExchanger", return_value=exchanger):
            # First call populates cache
            result1 = await router._get_vault_secret_token(
                "test-backend", adapter, agent_config, FAKE_USER_TOKEN
            )
            assert result1 == "shared-secret"

        # Second call should use cache (no new exchanger call)
        result2 = await router._get_vault_secret_token(
            "test-backend", adapter, agent_config, FAKE_USER_TOKEN
        )
        assert result2 == "shared-secret"
        # Only one call to exchanger
        exchanger.exchange_vault_secret.assert_called_once()
