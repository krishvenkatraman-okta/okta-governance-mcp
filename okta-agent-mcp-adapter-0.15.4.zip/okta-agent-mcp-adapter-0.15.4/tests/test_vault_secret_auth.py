"""
Tests for OktaVaultSecretExchanger — SDK-based token exchange for vault secrets.

Covers:
- Constructor credential resolution (domain normalization, placeholder key fallback)
- exchange_vault_secret: success, consent_required, errors, logging
- exchange_service_account: success, credential extraction, errors
- _is_placeholder_key static method
- TokenExchangeFlow is instantiated per call (single-use)
- Correct token types and resource ORN passed to SDK
"""

import json
import logging
import pytest
from unittest.mock import AsyncMock, MagicMock, patch

from okta_agent_proxy.auth.okta_vault_exchanger import (
    OktaVaultSecretExchanger,
    REQUESTED_TOKEN_TYPE_VAULT,
)


# ---------------------------------------------------------------------------
# Test RSA key (2048-bit, for testing only — same as test_okta_sts_exchanger)
# ---------------------------------------------------------------------------
TEST_JWK = json.dumps({
    "kty": "RSA",
    "kid": "test-kid-001",
    "alg": "RS256",
    "use": "sig",
    "n": "vdGMa1NIq7z4D8Os_NNrsFBCa1MWPBgumMntXgLML8-Wx5T4lHf5x_ReAWHOb7O_tQboNDMbmzuakZ6jxth92Y_YdpkiOzl69cPtb29sbiRt-51JUHWvIv-KV6uLKfzZ8Z_cDMf_Bd8e92bgap803YwNBRoxkWMiQBc1gVY1cag4MH0c0CTlQLRqiKgtHGopjZvRi13xNF7Wefoe9xjvpFbSZ3kj85Sd_KUGy3PvL49QdWYnixfvTNV6WNT3EVOL-IdE6Hu7uEiJ_Fs0yHXH6-1e_7qrhCm05Iq8WQ2pARpKQqhpI7q8WIWGJuVedqqaBYzER66NivJv2aE37YVRFQ",
    "e": "AQAB",
    "d": "D5wjdZIISGNGbRl06OfEE-BNzgCrs-5zKop0lEYbn5TtO-WC2cbSCkEM2AVAkkwQaGU0hFJto0LwD6ihpFEabGFZdktals8_zuU5afAaVSZ2yvng1RaQfArSyCnpzF6oV6gDUyPBU6zJIaRasTn9gXiqe3BvghrKbsXZ1xSNWZbM4C0SiNpl3nGWVYxIS0sfvD2ritEYrunuBXPOuhxm4vyVrUms5-myLXqGLgrVSF607pn_pYpfpsmeIBYZDreHRw62Myy-ZBPIbrI6NtAHUe1YaJG-tgid4h8Q5Fy9eEnZ9wSb3xOLer3lOeWdTBg59cuPggdIMym6qJJ8r2i78Q",
    "p": "-GZS0CnNvLHeUFIztnVFb1O9Cgmvd_tcet7J1NpIlrBFrbzGL7lrn_9dEEAh6SIlTHJEptF9dsKAE_pX4aMnfT1kwqSAN8FSQGaGGeg1KWBi8VtG5LF3XD_8oLI3Zvp6HXBZAghnyGFsEtSmvH_xvq_xFPkyQ6zbz7T0DdrqFVk",
    "q": "w6BeLtLNrv1k5bH_DTMnJgh_q9zBeTLOHHX7DrfMqpZHsF6imtoog0oH-S1jlUc-3x0wEs8GW4KmS86Z6MQABoiAJHV62_dtxcxUsZEtcmVqEKRTgtBahewp1dqtOeDZHYJRKl6Wco_vlLk1PgOqJyqw7THOPRGnGsX6jZDdVh0",
    "dp": "aP4vIMeaq5hvBHpKW2PkLnMxoy2G2msHovPKUcrWBcOKIC57gq6YHC--8WB6NOV26IIgHHbN1kXOByO4w6nHxjsN_Ou1OlvfXVM4eXjaB5wzFhtjssSEVBzDtlS98CwNM6ZKKP7OhzcOjEMQGvrlfpk1iIzwPwSwgHHW-og-izk",
    "dq": "tLp5iISUJTBQgKw613UEm-yKFrqxu0imhkCxGl3PpWGFBXnIe4tEllZUm23FbGoPuYx7l0TPuMcw3yQVqKc65s5ApG4sfP9P2Mb3D7zx4Zezr4BA7r-Sgds2oy2Nj8UckFiOp7gPAfPcAOhCOfKkxd546glzYZPnb6Kr4RGOijk",
    "qi": "lnKIAVNxIgrTTWUCDDNFM36vbG8jPB55ksex8xEkCAi2oTGqin_Y1IGNTgFIbwmmZuzJ2-8AviUZylHkQhPIKu4fLP-CfLP_RzUimv2TnIg3_2qY8wRChmDLzefvZNc8qBM0UvnMG3AaK5H6Go1p28v8-emVKNtT1Fw231l67HY",
})

VAULT_ORN = "orn:okta:pam:00o123:secrets:abc-456"
FAKE_ID_TOKEN = "eyJ.fake.id-token"


def _make_exchanger(**overrides):
    """Create an OktaVaultSecretExchanger with test defaults."""
    defaults = {
        "agent_id": "test-agent",
        "client_id": "0oa_test_client",
        "agent_private_key": TEST_JWK,
        "okta_domain": "https://dev-test.okta.com",
        "principal_id": "agt_test_principal",
    }
    defaults.update(overrides)
    return OktaVaultSecretExchanger(**defaults)


def _vault_response(**overrides):
    """Build a mock Okta vault secret response body."""
    base = {"access_token": "vault-secret-xyz", "token_type": "Bearer", "expires_in": 28800}
    base.update(overrides)
    return base


# ============================================================================
# Initialization tests
# ============================================================================

class TestInit:

    def test_init_with_valid_credentials(self):
        exchanger = _make_exchanger()
        assert exchanger.agent_id == "test-agent"
        assert exchanger.client_id == "0oa_test_client"
        assert exchanger.principal_id == "agt_test_principal"
        assert exchanger.okta_domain == "https://dev-test.okta.com"
        assert exchanger._private_key is not None
        assert exchanger.token_endpoint == "https://dev-test.okta.com/oauth2/v1/token"

    def test_init_requires_principal_id(self):
        with pytest.raises(ValueError, match="principal_id is required"):
            _make_exchanger(principal_id=None)

    def test_init_normalizes_okta_domain(self):
        exchanger = _make_exchanger(okta_domain="dev-test.okta.com")
        assert exchanger.okta_domain == "https://dev-test.okta.com"

    def test_init_normalizes_http_to_https(self):
        exchanger = _make_exchanger(okta_domain="http://dev-test.okta.com")
        assert exchanger.okta_domain == "https://dev-test.okta.com"

    def test_init_placeholder_key_falls_back_to_gateway(self, monkeypatch):
        monkeypatch.setenv("OKTA_AI_AGENT_PRIVATE_KEY", TEST_JWK)
        monkeypatch.setenv("OKTA_AI_AGENT_CLIENT_ID", "0oa_gateway")
        monkeypatch.setenv("OKTA_AI_AGENT_ID", "agt_gateway")

        exchanger = _make_exchanger(agent_private_key="PLACEHOLDER")
        assert exchanger._using_gateway_key is True
        assert exchanger.client_id == "0oa_gateway"

    def test_init_placeholder_key_gateway_env_vars(self, monkeypatch):
        monkeypatch.setenv("OKTA_AI_AGENT_PRIVATE_KEY", TEST_JWK)
        monkeypatch.setenv("OKTA_AI_AGENT_CLIENT_ID", "0oa_gw_client")
        monkeypatch.setenv("OKTA_AI_AGENT_ID", "agt_gw_agent")

        exchanger = _make_exchanger(agent_private_key=None)
        assert exchanger._using_gateway_key is True
        assert exchanger.agent_id == "agt_gw_agent"
        assert exchanger.principal_id == "agt_gw_agent"
        assert exchanger._oauth2_client is not None

    def test_init_placeholder_key_cimd_fallback(self, monkeypatch):
        monkeypatch.delenv("OKTA_AI_AGENT_PRIVATE_KEY", raising=False)
        monkeypatch.delenv("OKTA_AI_AGENT_CLIENT_ID", raising=False)
        monkeypatch.delenv("OKTA_AI_AGENT_ID", raising=False)

        mock_adapter = MagicMock()
        mock_adapter._private_jwk = json.loads(TEST_JWK)

        with patch("okta_agent_proxy.auth.okta_vault_exchanger.AdapterCIMDServer", return_value=mock_adapter):
            exchanger = _make_exchanger(agent_private_key="PLACEHOLDER")
            assert exchanger._using_gateway_key is True
            assert exchanger._oauth2_client is not None

    def test_init_no_credentials_disables_exchange(self, monkeypatch):
        monkeypatch.delenv("OKTA_AI_AGENT_PRIVATE_KEY", raising=False)
        monkeypatch.delenv("OKTA_AI_AGENT_CLIENT_ID", raising=False)
        monkeypatch.delenv("OKTA_AI_AGENT_ID", raising=False)

        with patch("okta_agent_proxy.auth.okta_vault_exchanger.AdapterCIMDServer", side_effect=Exception("no key")):
            exchanger = _make_exchanger(agent_private_key=None)
            assert exchanger._oauth2_client is None


# ============================================================================
# exchange_vault_secret tests
# ============================================================================

class TestExchangeVaultSecret:

    @pytest.mark.asyncio
    async def test_success(self):
        exchanger = _make_exchanger()
        with patch.object(exchanger, "_raw_exchange", new_callable=AsyncMock, return_value=_vault_response()):
            result = await exchanger.exchange_vault_secret(FAKE_ID_TOKEN, VAULT_ORN, resource_name="api-key")

        assert result is not None
        assert result["status"] == "success"
        assert result["access_token"] == "vault-secret-xyz"
        assert result["expires_in"] == 28800
        assert result["provider"] == "api-key"

    @pytest.mark.asyncio
    async def test_returns_none_when_disabled(self):
        exchanger = _make_exchanger()
        exchanger._private_key = None

        result = await exchanger.exchange_vault_secret(FAKE_ID_TOKEN, VAULT_ORN)
        assert result is None

    @pytest.mark.asyncio
    async def test_interaction_required(self):
        exchanger = _make_exchanger()
        body = {"error": "interaction_required", "interaction_uri": "https://okta.com/consent/abc", "error_description": "User consent needed"}
        with patch.object(exchanger, "_raw_exchange", new_callable=AsyncMock, return_value=body):
            result = await exchanger.exchange_vault_secret(FAKE_ID_TOKEN, VAULT_ORN, resource_name="slack-key")

        assert result["status"] == "consent_required"
        assert result["interaction_uri"] == "https://okta.com/consent/abc"
        assert result["provider"] == "slack-key"

    @pytest.mark.asyncio
    async def test_unexpected_error_returns_none(self):
        exchanger = _make_exchanger()
        with patch.object(exchanger, "_raw_exchange", new_callable=AsyncMock, side_effect=RuntimeError("connection refused")):
            result = await exchanger.exchange_vault_secret(FAKE_ID_TOKEN, VAULT_ORN)
        assert result is None

    @pytest.mark.asyncio
    async def test_timeout_returns_none(self):
        exchanger = _make_exchanger()
        with patch.object(exchanger, "_raw_exchange", new_callable=AsyncMock, side_effect=TimeoutError("timed out")):
            result = await exchanger.exchange_vault_secret(FAKE_ID_TOKEN, VAULT_ORN)
        assert result is None

    @pytest.mark.asyncio
    async def test_uses_correct_token_endpoint(self):
        exchanger = _make_exchanger(okta_domain="https://custom.oktapreview.com")
        assert exchanger.token_endpoint == "https://custom.oktapreview.com/oauth2/v1/token"

    @pytest.mark.asyncio
    async def test_resource_orn_passed(self):
        exchanger = _make_exchanger()
        with patch.object(exchanger, "_raw_exchange", new_callable=AsyncMock, return_value=_vault_response()) as mock_raw:
            await exchanger.exchange_vault_secret(FAKE_ID_TOKEN, VAULT_ORN)

        mock_raw.assert_called_once_with(FAKE_ID_TOKEN, VAULT_ORN, REQUESTED_TOKEN_TYPE_VAULT)

    @pytest.mark.asyncio
    async def test_raw_exchange_returns_none(self):
        exchanger = _make_exchanger()
        with patch.object(exchanger, "_raw_exchange", new_callable=AsyncMock, return_value=None):
            result = await exchanger.exchange_vault_secret(FAKE_ID_TOKEN, VAULT_ORN)
        assert result is None

    @pytest.mark.asyncio
    async def test_secret_field_fallback(self):
        """Okta may return the secret in 'secret' or 'value' field instead of 'access_token'."""
        exchanger = _make_exchanger()
        body = {"secret": "my-api-key", "expires_in": 300}
        with patch.object(exchanger, "_raw_exchange", new_callable=AsyncMock, return_value=body):
            result = await exchanger.exchange_vault_secret(FAKE_ID_TOKEN, VAULT_ORN)

        assert result["status"] == "success"
        assert result["access_token"] == "my-api-key"

    @pytest.mark.asyncio
    async def test_structured_logging_on_success(self, caplog):
        exchanger = _make_exchanger()
        with patch.object(exchanger, "_raw_exchange", new_callable=AsyncMock, return_value=_vault_response()):
            with caplog.at_level(logging.DEBUG, logger="okta_agent_proxy.auth.okta_vault_exchanger"):
                await exchanger.exchange_vault_secret(FAKE_ID_TOKEN, VAULT_ORN, resource_name="test-secret")

        siem_records = [r for r in caplog.records if r.getMessage() == "vault_secret_exchange"]
        assert len(siem_records) >= 1
        assert siem_records[0].__dict__.get("status") == "success"

    @pytest.mark.asyncio
    async def test_structured_logging_on_error(self, caplog):
        exchanger = _make_exchanger()
        with patch.object(exchanger, "_raw_exchange", new_callable=AsyncMock, side_effect=RuntimeError("boom")):
            with caplog.at_level(logging.DEBUG, logger="okta_agent_proxy.auth.okta_vault_exchanger"):
                await exchanger.exchange_vault_secret(FAKE_ID_TOKEN, VAULT_ORN)

        error_records = [r for r in caplog.records if r.levelno >= logging.ERROR]
        assert len(error_records) >= 1
        assert "boom" in error_records[0].getMessage()


# ============================================================================
# exchange_service_account tests
# ============================================================================

class TestExchangeServiceAccount:

    @pytest.mark.asyncio
    async def test_success_with_token_fallback(self):
        exchanger = _make_exchanger()
        body = {"access_token": "opaque-token-123", "token_type": "Bearer", "expires_in": 300}
        with patch.object(exchanger, "_raw_exchange", new_callable=AsyncMock, return_value=body):
            result = await exchanger.exchange_service_account(FAKE_ID_TOKEN, VAULT_ORN, resource_name="jira-bot")

        assert result["status"] == "success"
        assert result["access_token"] == "opaque-token-123"
        assert result["provider"] == "jira-bot"

    @pytest.mark.asyncio
    async def test_returns_none_when_disabled(self):
        exchanger = _make_exchanger()
        exchanger._private_key = None
        result = await exchanger.exchange_service_account(FAKE_ID_TOKEN, VAULT_ORN)
        assert result is None

    @pytest.mark.asyncio
    async def test_error_handling(self):
        exchanger = _make_exchanger()
        with patch.object(exchanger, "_raw_exchange", new_callable=AsyncMock, side_effect=RuntimeError("network error")):
            result = await exchanger.exchange_service_account(FAKE_ID_TOKEN, VAULT_ORN)
        assert result is None

    @pytest.mark.asyncio
    async def test_direct_username_password(self):
        """When Okta returns username/password directly in the response."""
        exchanger = _make_exchanger()
        body = {"username": "svc-user", "password": "svc-pass"}
        with patch.object(exchanger, "_raw_exchange", new_callable=AsyncMock, return_value=body):
            result = await exchanger.exchange_service_account(FAKE_ID_TOKEN, VAULT_ORN)

        assert result["status"] == "success"
        assert result["username"] == "svc-user"
        assert result["password"] == "svc-pass"


# ============================================================================
# Credential resolution tests
# ============================================================================

class TestIsPlaceholderKey:

    def test_none(self):
        assert OktaVaultSecretExchanger._is_placeholder_key(None) is True

    def test_placeholder_string(self):
        assert OktaVaultSecretExchanger._is_placeholder_key("PLACEHOLDER") is True

    def test_contains_placeholder(self):
        assert OktaVaultSecretExchanger._is_placeholder_key('{"n":"PLACEHOLDER"}') is True

    def test_placeholder_dict(self):
        assert OktaVaultSecretExchanger._is_placeholder_key({"n": "PLACEHOLDER", "kty": "RSA"}) is True

    def test_valid_jwk_string(self):
        assert OktaVaultSecretExchanger._is_placeholder_key(TEST_JWK) is False

    def test_valid_jwk_dict(self):
        assert OktaVaultSecretExchanger._is_placeholder_key(json.loads(TEST_JWK)) is False

    def test_empty_string(self):
        assert OktaVaultSecretExchanger._is_placeholder_key("") is True


# ============================================================================
# Constants
# ============================================================================

class TestConstants:

    def test_requested_token_type_vault(self):
        assert REQUESTED_TOKEN_TYPE_VAULT == "urn:okta:params:oauth:token-type:vaulted-secret"
