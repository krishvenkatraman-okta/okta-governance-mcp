"""Tests for ALLOW_ALL sync-time scope expansion from AS metadata.

When an Okta Managed Connection has `scopeCondition = ALLOW_ALL`, the syncer
should fetch scopes_supported from the target authorization server's
.well-known/openid-configuration, filter out OIDC and blocklisted scopes, and
use that list as the effective scopes on the ResolvedResource.
"""

import os
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from okta_agent_proxy.resources.models import (
    OktaConnectionType,
    OktaScopeCondition,
    ResourceMapEntry,
)
from okta_agent_proxy.resources.syncer import OktaConnectionSyncer


# ============================================================================
# Fixtures
# ============================================================================

ALLOW_ALL_CONN = {
    "id": "conn-ia-allow-all",
    "connectionType": "IDENTITY_ASSERTION_CUSTOM_AS",
    "status": "ACTIVE",
    "name": "bedrock-connection",
    "authorizationServer": {
        "orn": "orn:okta:idp:00oabc:authorization_servers:ausAllowAll",
        "issuerUrl": "https://dev-test.okta.com/oauth2/ausAllowAll",
    },
    "resourceIndicator": "orn:okta:idp:00oabc:authorization_servers:ausAllowAll",
    "scopes": [],
    "scopeCondition": "ALLOW_ALL",
}

INCLUDE_ONLY_CONN = {
    "id": "conn-ia-include",
    "connectionType": "IDENTITY_ASSERTION_CUSTOM_AS",
    "status": "ACTIVE",
    "name": "bedrock-include",
    "authorizationServer": {
        "orn": "orn:okta:idp:00oabc:authorization_servers:ausInclude",
        "issuerUrl": "https://dev-test.okta.com/oauth2/ausInclude",
    },
    "resourceIndicator": "orn:okta:idp:00oabc:authorization_servers:ausInclude",
    "scopes": ["mcp:read"],
    "scopeCondition": "INCLUDE_ONLY",
}

AS_METADATA_RESPONSE = {
    "issuer": "https://dev-test.okta.com/oauth2/ausAllowAll",
    "scopes_supported": [
        "openid", "profile", "email", "offline_access",
        "interclient_access",
        "bedrock:InvokeAgent", "s3:Read",
    ],
}


def _find_by_name(resolved: dict, name: str):
    for r in resolved.values():
        if r.name == name:
            return r
    return None


def _mock_store(entries_by_id: dict):
    store = MagicMock()
    store.get_by_id = lambda rid: entries_by_id.get(rid, [])
    store.get_linkages_for_connection = lambda agent_id, conn_id: []
    store.admin_update = MagicMock()
    return store


def _make_syncer(store):
    bus = MagicMock()
    syncer = OktaConnectionSyncer(
        okta_domain="https://dev-test.okta.com",
        api_token="tok",
        resource_map_store=store,
        event_bus=bus,
    )
    return syncer


# ============================================================================
# _fetch_as_supported_scopes
# ============================================================================

class TestFetchASSupportedScopes:

    @pytest.mark.asyncio
    async def test_returns_scopes_on_200(self):
        syncer = _make_syncer(_mock_store({}))
        mock_resp = MagicMock()
        mock_resp.status_code = 200
        mock_resp.json = MagicMock(return_value=AS_METADATA_RESPONSE)
        mock_client = MagicMock()
        mock_client.get = AsyncMock(return_value=mock_resp)
        syncer._http_client = mock_client

        result = await syncer._fetch_as_supported_scopes(
            "https://dev-test.okta.com/oauth2/ausAllowAll"
        )
        assert result == AS_METADATA_RESPONSE["scopes_supported"]
        mock_client.get.assert_awaited_once_with(
            "https://dev-test.okta.com/oauth2/ausAllowAll/.well-known/openid-configuration",
            timeout=10.0,
        )

    @pytest.mark.asyncio
    async def test_returns_none_on_404(self):
        syncer = _make_syncer(_mock_store({}))
        mock_resp = MagicMock()
        mock_resp.status_code = 404
        mock_client = MagicMock()
        mock_client.get = AsyncMock(return_value=mock_resp)
        syncer._http_client = mock_client

        result = await syncer._fetch_as_supported_scopes(
            "https://dev-test.okta.com/oauth2/ausNotFound"
        )
        assert result is None

    @pytest.mark.asyncio
    async def test_returns_none_on_network_error(self):
        syncer = _make_syncer(_mock_store({}))
        mock_client = MagicMock()
        mock_client.get = AsyncMock(side_effect=ConnectionError("boom"))
        syncer._http_client = mock_client

        result = await syncer._fetch_as_supported_scopes(
            "https://unreachable.example.com/oauth2/x"
        )
        assert result is None

    @pytest.mark.asyncio
    async def test_returns_none_when_scopes_supported_missing(self):
        syncer = _make_syncer(_mock_store({}))
        mock_resp = MagicMock()
        mock_resp.status_code = 200
        mock_resp.json = MagicMock(return_value={"issuer": "x"})
        mock_client = MagicMock()
        mock_client.get = AsyncMock(return_value=mock_resp)
        syncer._http_client = mock_client

        result = await syncer._fetch_as_supported_scopes(
            "https://dev-test.okta.com/oauth2/ausEmpty"
        )
        assert result is None

    @pytest.mark.asyncio
    async def test_no_http_client_returns_none(self):
        syncer = _make_syncer(_mock_store({}))
        syncer._http_client = None
        result = await syncer._fetch_as_supported_scopes("https://x.com")
        assert result is None


# ============================================================================
# _prefetch_allow_all_scopes
# ============================================================================

class TestPrefetchAllowAllScopes:

    @pytest.mark.asyncio
    async def test_populates_cache_for_allow_all(self):
        os.environ.pop("OKTA_SCOPE_BLOCKLIST", None)
        syncer = _make_syncer(_mock_store({}))
        mock_resp = MagicMock()
        mock_resp.status_code = 200
        mock_resp.json = MagicMock(return_value=AS_METADATA_RESPONSE)
        mock_client = MagicMock()
        mock_client.get = AsyncMock(return_value=mock_resp)
        syncer._http_client = mock_client

        await syncer._prefetch_allow_all_scopes([ALLOW_ALL_CONN])

        issuer = "https://dev-test.okta.com/oauth2/ausAllowAll"
        assert issuer in syncer._as_scopes_cache
        assert syncer._as_scopes_cache[issuer] == ["bedrock:InvokeAgent", "s3:Read"]

    @pytest.mark.asyncio
    async def test_skips_include_only_connections(self):
        syncer = _make_syncer(_mock_store({}))
        mock_client = MagicMock()
        mock_client.get = AsyncMock()
        syncer._http_client = mock_client

        await syncer._prefetch_allow_all_scopes([INCLUDE_ONLY_CONN])

        mock_client.get.assert_not_awaited()
        assert syncer._as_scopes_cache == {}

    @pytest.mark.asyncio
    async def test_dedupes_by_issuer_url(self):
        os.environ.pop("OKTA_SCOPE_BLOCKLIST", None)
        syncer = _make_syncer(_mock_store({}))
        mock_resp = MagicMock()
        mock_resp.status_code = 200
        mock_resp.json = MagicMock(return_value=AS_METADATA_RESPONSE)
        mock_client = MagicMock()
        mock_client.get = AsyncMock(return_value=mock_resp)
        syncer._http_client = mock_client

        conn_dup = dict(ALLOW_ALL_CONN)
        conn_dup["id"] = "conn-ia-allow-all-2"
        await syncer._prefetch_allow_all_scopes([ALLOW_ALL_CONN, conn_dup])

        # Same issuer_url for both connections -> single HTTP call
        assert mock_client.get.await_count == 1

    @pytest.mark.asyncio
    async def test_fetch_failure_does_not_populate_cache(self):
        syncer = _make_syncer(_mock_store({}))
        mock_client = MagicMock()
        mock_client.get = AsyncMock(side_effect=RuntimeError("boom"))
        syncer._http_client = mock_client

        await syncer._prefetch_allow_all_scopes([ALLOW_ALL_CONN])

        issuer = "https://dev-test.okta.com/oauth2/ausAllowAll"
        assert issuer not in syncer._as_scopes_cache


# ============================================================================
# _merge_connections ALLOW_ALL expansion (pre-populated cache)
# ============================================================================

@pytest.mark.skip(
    reason="_merge_connections now requires agent context + DB-backed store; "
    "covered by integration tests in test_syncer_collapsed_schema.py"
)
class TestMergeALLOW_ALLExpansion:

    def test_allow_all_uses_prefetched_scopes(self):
        os.environ.pop("OKTA_SCOPE_BLOCKLIST", None)
        entries = {
            "ausAllowAll": [ResourceMapEntry(
                resource_id="ausAllowAll",
                name="bedrock-resource",
                mcp_url="https://bedrock.example.com",
            )],
        }
        syncer = _make_syncer(_mock_store(entries))
        syncer._as_scopes_cache = {
            "https://dev-test.okta.com/oauth2/ausAllowAll": [
                "bedrock:InvokeAgent", "s3:Read",
            ],
        }

        resolved, unresolved = syncer._merge_connections([ALLOW_ALL_CONN])

        bedrock = _find_by_name(resolved, "bedrock-resource")
        assert bedrock is not None
        assert bedrock.scopes == ["bedrock:InvokeAgent", "s3:Read"]
        assert bedrock.scope_condition == OktaScopeCondition.ALLOW_ALL

    def test_allow_all_with_empty_cache_falls_back(self):
        os.environ.pop("OKTA_SCOPE_BLOCKLIST", None)
        entries = {
            "ausAllowAll": [ResourceMapEntry(
                resource_id="ausAllowAll",
                name="bedrock-resource",
                mcp_url="https://bedrock.example.com",
            )],
        }
        syncer = _make_syncer(_mock_store(entries))
        syncer._as_scopes_cache = {}

        resolved, _ = syncer._merge_connections([ALLOW_ALL_CONN])

        # No expansion happened -> Okta's raw (empty) scopes list is used.
        bedrock = _find_by_name(resolved, "bedrock-resource")
        assert bedrock is not None
        assert bedrock.scopes == []
        assert bedrock.scope_condition == OktaScopeCondition.ALLOW_ALL

    def test_include_only_not_affected_by_cache(self):
        # INCLUDE_ONLY connections should keep their Okta-declared scopes, even
        # if the cache contains expanded scopes for the same AS.
        entries = {
            "ausInclude": [ResourceMapEntry(
                resource_id="ausInclude",
                name="include-resource",
                mcp_url="https://include.example.com",
            )],
        }
        syncer = _make_syncer(_mock_store(entries))
        syncer._as_scopes_cache = {
            "https://dev-test.okta.com/oauth2/ausInclude": ["should:not:appear"],
        }

        resolved, _ = syncer._merge_connections([INCLUDE_ONLY_CONN])

        r = _find_by_name(resolved, "include-resource")
        assert r is not None
        assert r.scopes == ["mcp:read"]
        assert r.scope_condition == OktaScopeCondition.INCLUDE_ONLY

    def test_allow_all_persists_expanded_scopes_to_store(self):
        os.environ.pop("OKTA_SCOPE_BLOCKLIST", None)
        entries = {
            "ausAllowAll": [ResourceMapEntry(
                resource_id="ausAllowAll",
                name="bedrock-resource",
                mcp_url="https://bedrock.example.com",
            )],
        }
        store = _mock_store(entries)
        syncer = _make_syncer(store)
        syncer._as_scopes_cache = {
            "https://dev-test.okta.com/oauth2/ausAllowAll": [
                "bedrock:InvokeAgent", "s3:Read",
            ],
        }

        syncer._merge_connections([ALLOW_ALL_CONN])

        # admin_update called with the expanded list
        assert store.admin_update.called
        call_args = store.admin_update.call_args
        updates = call_args[0][1]
        assert updates["managed_connection_scopes"] == ["bedrock:InvokeAgent", "s3:Read"]
        assert updates["managed_connection_scope_condition"] == "ALLOW_ALL"
