"""
Tests for BFF token capture — access_token → id_token mapping.

Tests:
- capture_token_mapping stores correctly and is non-fatal
- Agent receives Okta's real access_token (not the id_token)
- Agent receives all three tokens (access_token, id_token, refresh_token)
- Capture failure is non-fatal
- Missing id_token skips capture
- Unified/proxy handlers check cid for agent fallback
"""

import base64
import json
import inspect
import pytest
from unittest.mock import patch, MagicMock

from okta_agent_proxy.auth.user_token_store import (
    capture_token_mapping,
    UserTokenStore,
)


# ============================================================================
# Sample data
# ============================================================================

# Build a valid (but unsigned) JWT id_token for testing
_ID_TOKEN_HEADER = base64.urlsafe_b64encode(b'{"alg":"none"}').rstrip(b"=").decode()
_ID_TOKEN_PAYLOAD = base64.urlsafe_b64encode(
    json.dumps({"sub": "user@example.com", "aud": "0oaXXX", "iss": "https://dev.okta.com"}).encode()
).rstrip(b"=").decode()
SAMPLE_ID_TOKEN = f"{_ID_TOKEN_HEADER}.{_ID_TOKEN_PAYLOAD}."

OKTA_TOKEN_RESPONSE = {
    "access_token": "real-okta-access-token-xyz",
    "id_token": SAMPLE_ID_TOKEN,
    "refresh_token": "rt-refresh-token-xyz",
    "token_type": "Bearer",
    "expires_in": 3600,
}


# ============================================================================
# capture_token_mapping unit tests
# ============================================================================


class TestCaptureTokenMapping:
    def test_capture_stores_mapping(self):
        """Verify store.store() is called with access_token as key."""
        mock_store = MagicMock(spec=UserTokenStore)
        with patch(
            "okta_agent_proxy.auth.user_token_store.get_user_token_store",
            return_value=mock_store,
        ):
            capture_token_mapping(
                access_token="at-123",
                id_token=SAMPLE_ID_TOKEN,
                refresh_token="rt-456",
                client_id="0oaXXX",
                expires_in=3600,
            )
        mock_store.store.assert_called_once()
        kw = mock_store.store.call_args[1]
        assert kw["access_token"] == "at-123"
        assert kw["id_token"] == SAMPLE_ID_TOKEN
        assert kw["refresh_token"] == "rt-456"
        assert kw["agent_id"] == "0oaXXX"
        assert kw["expires_in"] == 3600
        assert kw["user_sub"] == "user@example.com"

    def test_no_access_token_skips(self):
        """No access_token → store not called."""
        mock_store = MagicMock(spec=UserTokenStore)
        with patch(
            "okta_agent_proxy.auth.user_token_store.get_user_token_store",
            return_value=mock_store,
        ):
            capture_token_mapping(None, SAMPLE_ID_TOKEN, "rt", "client", 3600)
        mock_store.store.assert_not_called()

    def test_no_id_token_skips_capture(self):
        """No id_token → store not called."""
        mock_store = MagicMock(spec=UserTokenStore)
        with patch(
            "okta_agent_proxy.auth.user_token_store.get_user_token_store",
            return_value=mock_store,
        ):
            capture_token_mapping("at-123", None, "rt", "client", 3600)
        mock_store.store.assert_not_called()

    def test_capture_failure_nonfatal(self):
        """If store.store() raises, the function does NOT raise."""
        mock_store = MagicMock(spec=UserTokenStore)
        mock_store.store.side_effect = RuntimeError("Redis exploded")
        with patch(
            "okta_agent_proxy.auth.user_token_store.get_user_token_store",
            return_value=mock_store,
        ):
            # Should not raise
            capture_token_mapping("at-123", SAMPLE_ID_TOKEN, "rt", "client", 3600)

    def test_invalid_id_token_nonfatal(self):
        """If id_token is not a valid JWT, capture is non-fatal (does not raise)."""
        capture_token_mapping("at-123", "not-a-jwt", "rt", "client", 3600)

    def test_extracts_sub_from_id_token(self):
        """Verify user_sub is extracted from id_token claims."""
        mock_store = MagicMock(spec=UserTokenStore)
        # Build id_token with specific sub
        payload = base64.urlsafe_b64encode(
            json.dumps({"sub": "jane@corp.com"}).encode()
        ).rstrip(b"=").decode()
        header = base64.urlsafe_b64encode(b'{"alg":"none"}').rstrip(b"=").decode()
        id_token = f"{header}.{payload}."

        with patch(
            "okta_agent_proxy.auth.user_token_store.get_user_token_store",
            return_value=mock_store,
        ):
            capture_token_mapping("at-x", id_token, "rt-x", "agent-x", 300)
        kw = mock_store.store.call_args[1]
        assert kw["user_sub"] == "jane@corp.com"

    def test_missing_sub_defaults_to_unknown(self):
        """If id_token has no sub claim, user_sub defaults to 'unknown'."""
        mock_store = MagicMock(spec=UserTokenStore)
        payload = base64.urlsafe_b64encode(
            json.dumps({"aud": "test"}).encode()  # no sub
        ).rstrip(b"=").decode()
        header = base64.urlsafe_b64encode(b'{"alg":"none"}').rstrip(b"=").decode()
        id_token = f"{header}.{payload}."

        with patch(
            "okta_agent_proxy.auth.user_token_store.get_user_token_store",
            return_value=mock_store,
        ):
            capture_token_mapping("at-x", id_token, "rt-x", "agent-x", 300)
        kw = mock_store.store.call_args[1]
        assert kw["user_sub"] == "unknown"

    def test_none_refresh_token_stored_as_empty(self):
        """If refresh_token is None, it's stored as empty string."""
        mock_store = MagicMock(spec=UserTokenStore)
        with patch(
            "okta_agent_proxy.auth.user_token_store.get_user_token_store",
            return_value=mock_store,
        ):
            capture_token_mapping("at-x", SAMPLE_ID_TOKEN, None, "agent", 300)
        kw = mock_store.store.call_args[1]
        assert kw["refresh_token"] == ""


# ============================================================================
# BFF response structure tests (source inspection — no app.py import needed)
# ============================================================================


class TestBFFResponseStructure:
    """Verify app.py code returns real access_token and calls capture.

    Since app.py can't be imported without psycopg2/database, we verify
    the source code directly.
    """

    @pytest.fixture(autouse=True)
    def _load_source(self):
        """Read app.py source once for all tests in this class."""
        with open("okta_agent_proxy/app.py") as f:
            self.app_source = f.read()

    def test_no_id_token_as_access_token_rewrite(self):
        """Verify the id_token-as-access_token rewrite has been removed.

        The old pattern was:
            response_to_client["access_token"] = id_token
        The new pattern is:
            response_to_client["access_token"] = token_response.get("access_token")
        """
        # Old pattern should NOT be present
        assert 'response_to_client["access_token"] = id_token' not in self.app_source, (
            "id_token-as-access_token rewrite should be removed"
        )

    def test_returns_real_access_token(self):
        """Verify BFF returns Okta's real access_token."""
        assert '"access_token": token_response.get("access_token")' in self.app_source, (
            "BFF should return Okta's real access_token"
        )

    def test_capture_called_in_auth_code(self):
        """Verify _capture_token_mapping is called in _proxy_authorization_code."""
        # Find the function body
        idx = self.app_source.find("async def _proxy_authorization_code")
        next_func = self.app_source.find("\nasync def ", idx + 1)
        func_body = self.app_source[idx:next_func]
        assert "_capture_token_mapping(" in func_body, (
            "_capture_token_mapping should be called in _proxy_authorization_code"
        )

    def test_capture_called_in_refresh(self):
        """Verify _capture_token_mapping is called in _proxy_refresh_token."""
        idx = self.app_source.find("async def _proxy_refresh_token")
        next_func = self.app_source.find("\nasync def ", idx + 1)
        if next_func == -1:
            next_func = len(self.app_source)
        func_body = self.app_source[idx:next_func]
        assert "_capture_token_mapping(" in func_body, (
            "_capture_token_mapping should be called in _proxy_refresh_token"
        )

    def test_id_token_returned_separately(self):
        """Verify id_token is returned as its own field (not replacing access_token)."""
        assert 'response_to_client["id_token"] = id_token' in self.app_source

    def test_refresh_token_returned(self):
        """Verify refresh_token is included in the response."""
        assert 'response_to_client["refresh_token"]' in self.app_source


# ============================================================================
# Agent fallback by cid claim — source code verification
# ============================================================================


class TestAgentFallbackByCid:
    """Verify unified handler and proxy handler check cid for agent lookup."""

    def test_unified_handler_checks_cid_in_fallback(self):
        """The unified handler's _authenticate should check cid claim."""
        from okta_agent_proxy.mcp.unified_handler import UnifiedMCPHandler

        source = inspect.getsource(UnifiedMCPHandler._authenticate)
        assert "cid" in source, "Unified handler _authenticate should check cid claim"

    def test_proxy_handler_checks_cid_in_fallback(self):
        """The proxy handler's proxy_request should check cid claim."""
        from okta_agent_proxy.proxy.handler import ProxyHandler

        source = inspect.getsource(ProxyHandler.proxy_request)
        assert "cid" in source, "Proxy handler should check cid claim in agent fallback"


# ============================================================================
# OktaTokenValidator compatibility with access_tokens
# ============================================================================


class TestValidatorAccessTokenCompat:
    """Verify OktaTokenValidator can validate access_tokens (aud + cid checks)."""

    def test_validator_checks_both_aud_and_cid(self):
        """validate_token should check both aud and cid claims."""
        from okta_agent_proxy.auth.okta_validator import OktaTokenValidator

        source = inspect.getsource(OktaTokenValidator.validate_token)
        assert 'token_cid = unverified.get("cid")' in source, (
            "Validator should extract cid claim from tokens"
        )
        assert "token_cid" in source, "Validator should use cid in audience checks"

    def test_validator_disables_aud_verification(self):
        """JWT decode should have verify_aud=False (manual validation above)."""
        from okta_agent_proxy.auth.okta_validator import OktaTokenValidator

        source = inspect.getsource(OktaTokenValidator.validate_token)
        assert '"verify_aud": False' in source, (
            "Validator should disable automatic aud verification (manual check instead)"
        )
