"""
Tests for agent support and multi-agent configuration.

Tests agent CRUD operations, agent-resource access control,
and agent configuration loading from PostgreSQL.
"""

import pytest
import json
from datetime import datetime

from okta_agent_proxy.config import AgentConfig


@pytest.fixture
def cursor_agent_data():
    """Create cursor agent test data."""
    return {
        "agent_id": "cursor",
        "client_id": "0oa_cursor",
        "client_secret": "cursor_secret",
        "private_key": json.dumps({
            "kty": "RSA",
            "use": "sig",
            "kid": "cursor-key-id",
            "n": "cursor-n-value",
            "e": "AQAB",
            "d": "cursor-d-value"
        }),
        "scopes": ["mcp:read", "mcp:write"],
        "resource_access": ["employees", "finance"],
        "enabled": True
    }


@pytest.fixture
def claude_code_agent_data():
    """Create claude-code agent test data."""
    return {
        "agent_id": "claude-code",
        "client_id": "0oa_claude_code",
        "client_secret": "claude_secret",
        "private_key": json.dumps({
            "kty": "RSA",
            "use": "sig",
            "kid": "claude-key-id",
            "n": "claude-n-value",
            "e": "AQAB",
            "d": "claude-d-value"
        }),
        "scopes": ["mcp:read"],
        "resource_access": ["partners"],
        "enabled": True
    }


@pytest.fixture
def employees_resource_data():
    """Create employees resource test data."""
    return {
        "name": "employees",
        "url": "http://localhost:9001",
        "paths": ["/employees"],
        "auth_method": "okta-cross-app",
        "auth_config": {
            "id_jag_mode": "static",
            "target_authorization_server": "https://test.okta.com/oauth2/default",
            "target_audience": "https://test.mcp.example.com",
            "target_client_secret": "employees_resource_secret"
        },
        "description": "Employee MCP",
        "enabled": True
    }


class TestAgentLoading:
    """Test agent loading from PostgreSQL."""

    def test_load_agents_from_database(self, postgres_store, cursor_agent_data, claude_code_agent_data):
        """Test loading agents from database."""
        # Create two agents
        postgres_store.create_agent(cursor_agent_data["agent_id"], cursor_agent_data, user="test_user")
        postgres_store.create_agent(claude_code_agent_data["agent_id"], claude_code_agent_data, user="test_user")

        # Load all agents
        agents = postgres_store.get_all_agents(enabled_only=False)
        assert len(agents) == 2

        agent_ids = {a["agent_id"] for a in agents}
        assert agent_ids == {"cursor", "claude-code"}

    def test_agent_config_fields(self, postgres_store, cursor_agent_data):
        """Test that agent config has all required fields."""
        postgres_store.create_agent(cursor_agent_data["agent_id"], cursor_agent_data, user="test_user")

        agent = postgres_store.get_agent("cursor")
        assert agent is not None
        assert agent["client_id"] == "0oa_cursor"
        assert agent["scopes"] == ["mcp:read", "mcp:write"]
        assert agent["enabled"] is True

        # Check timestamps are present
        assert "created_at" in agent
        assert "updated_at" in agent


class TestAgentCRUD:
    """Test agent CRUD operations."""

    def test_get_agent(self, postgres_store, cursor_agent_data):
        """Test getting a specific agent."""
        postgres_store.create_agent(cursor_agent_data["agent_id"], cursor_agent_data, user="test_user")

        agent = postgres_store.get_agent("cursor")
        assert agent is not None
        assert agent["agent_id"] == "cursor"
        assert agent["client_id"] == "0oa_cursor"

    def test_get_agent_not_found(self, postgres_store):
        """Test getting a non-existent agent returns None."""
        agent = postgres_store.get_agent("nonexistent")
        assert agent is None

    def test_get_agent_disabled(self, postgres_store, cursor_agent_data):
        """Test disabled agents not returned by default."""
        postgres_store.create_agent(cursor_agent_data["agent_id"], cursor_agent_data, user="test_user")

        # Disable agent
        postgres_store.disable_agent("cursor", user="test_user")

        # Should not be returned by default
        agent = postgres_store.get_agent("cursor")
        assert agent is None

        # But should be returned when enabled_only=False
        agent = postgres_store.get_agent("cursor", enabled_only=False)
        assert agent is not None
        assert agent["enabled"] is False

    def test_create_agent(self, postgres_store):
        """Test creating a new agent."""
        config = {
            "agent_id": "new-agent",
            "client_id": "0oa_new_agent",
            "client_secret": "new_secret",
            "private_key": json.dumps({
                "kty": "RSA",
                "use": "sig",
                "kid": "new-key-id",
                "n": "new-n-value",
                "e": "AQAB",
                "d": "new-d-value"
            }),
            "scopes": ["mcp:read"],
        }

        success = postgres_store.create_agent("new-agent", config, user="test_user")
        assert success is True

        agent = postgres_store.get_agent("new-agent")
        assert agent is not None
        assert agent["client_id"] == "0oa_new_agent"
        assert agent["created_by"] == "test_user"

    def test_create_duplicate_agent(self, postgres_store, cursor_agent_data):
        """Test creating duplicate agent returns False."""
        postgres_store.create_agent(cursor_agent_data["agent_id"], cursor_agent_data, user="test_user")

        config = {
            "client_id": "0oa_duplicate",
            "private_key": "key"
        }

        success = postgres_store.create_agent("cursor", config, user="test_user")
        assert success is False  # cursor already exists

    def test_update_agent(self, postgres_store, cursor_agent_data):
        """Test updating an agent."""
        postgres_store.create_agent(cursor_agent_data["agent_id"], cursor_agent_data, user="test_user")

        updates = {
            "scopes": ["mcp:admin"],
        }

        success = postgres_store.update_agent("cursor", updates, user="test_user")
        assert success is True

        agent = postgres_store.get_agent("cursor")
        assert agent["scopes"] == ["mcp:admin"]
        assert agent["updated_by"] == "test_user"

    def test_update_nonexistent_agent(self, postgres_store):
        """Test updating non-existent agent returns False."""
        success = postgres_store.update_agent("nonexistent", {}, user="test_user")
        assert success is False

    def test_delete_agent(self, postgres_store, cursor_agent_data):
        """Test deleting an agent."""
        postgres_store.create_agent(cursor_agent_data["agent_id"], cursor_agent_data, user="test_user")

        assert postgres_store.get_agent("cursor") is not None

        success = postgres_store.delete_agent("cursor", user="test_user")
        assert success is True

        agent = postgres_store.get_agent("cursor", enabled_only=False)
        assert agent is None  # Agent actually deleted

    def test_delete_nonexistent_agent(self, postgres_store):
        """Test deleting non-existent agent returns False."""
        success = postgres_store.delete_agent("nonexistent", user="test_user")
        assert success is False


class TestAgentEnableDisable:
    """Test agent enable/disable operations."""

    def test_enable_agent(self, postgres_store, cursor_agent_data):
        """Test enabling an agent."""
        postgres_store.create_agent(cursor_agent_data["agent_id"], cursor_agent_data, user="test_user")

        # First disable
        postgres_store.disable_agent("cursor", user="test_user")
        agent = postgres_store.get_agent("cursor", enabled_only=False)
        assert agent["enabled"] is False

        # Now enable
        success = postgres_store.enable_agent("cursor", user="test_user")
        assert success is True

        agent = postgres_store.get_agent("cursor")
        assert agent is not None
        assert agent["enabled"] is True

    def test_disable_agent(self, postgres_store, cursor_agent_data):
        """Test disabling an agent."""
        postgres_store.create_agent(cursor_agent_data["agent_id"], cursor_agent_data, user="test_user")

        success = postgres_store.disable_agent("cursor", user="test_user")
        assert success is True

        agent = postgres_store.get_agent("cursor")
        assert agent is None  # Disabled, so not returned

        agent = postgres_store.get_agent("cursor", enabled_only=False)
        assert agent["enabled"] is False

    def test_enable_already_enabled_agent(self, postgres_store, cursor_agent_data):
        """Test enabling already enabled agent succeeds."""
        postgres_store.create_agent(cursor_agent_data["agent_id"], cursor_agent_data, user="test_user")

        agent = postgres_store.get_agent("cursor")
        assert agent["enabled"] is True

        # Try to enable again
        success = postgres_store.enable_agent("cursor", user="test_user")
        assert success is True  # Still succeeds

    def test_disable_already_disabled_agent(self, postgres_store, cursor_agent_data):
        """Test disabling already disabled agent succeeds."""
        postgres_store.create_agent(cursor_agent_data["agent_id"], cursor_agent_data, user="test_user")

        postgres_store.disable_agent("cursor", user="test_user")

        # Try to disable again
        success = postgres_store.disable_agent("cursor", user="test_user")
        assert success is True  # Still succeeds


class TestAgentResourceAccess:
    """Test agent resource access control.

    Note: list_agent_resources() now returns all enabled resources
    (authorization is handled by the syncer/resource store, not per-agent lists).
    """

    def test_list_agent_resources_returns_list(self, postgres_store, cursor_agent_data):
        """Test listing resources returns a list (may be empty if no resources in new table)."""
        postgres_store.create_agent(cursor_agent_data["agent_id"], cursor_agent_data, user="test_user")

        resources = postgres_store.list_agent_resources("cursor")
        assert isinstance(resources, list)

    def test_no_resources_when_none_exist(self, postgres_store):
        """Test empty list when no resources exist."""
        resources = postgres_store.list_agent_resources("cursor")
        assert resources == []

    def test_nonexistent_agent_resources(self, postgres_store):
        """Test listing resources for non-existent agent returns all enabled resources."""
        resources = postgres_store.list_agent_resources("nonexistent")
        assert resources == []


class TestAgentAuditLog:
    """Test agent audit logging."""

    def test_get_agent_audit_log(self, postgres_store, cursor_agent_data):
        """Test getting agent audit log."""
        postgres_store.create_agent(cursor_agent_data["agent_id"], cursor_agent_data, user="test_user")

        # Note: We currently return empty list as we don't have agent audit table yet
        log = postgres_store.get_agent_audit_log("cursor")
        assert isinstance(log, list)


class TestAgentPersistence:
    """Test agent persistence in PostgreSQL."""

    def test_agent_persistence_across_operations(self, postgres_store, cursor_agent_data):
        """Test that agents persist in database across operations."""
        # Create agent
        postgres_store.create_agent(cursor_agent_data["agent_id"], cursor_agent_data, user="test_user")

        # Update agent
        postgres_store.update_agent("cursor", {"scopes": ["mcp:admin"]}, user="test_user")

        # Retrieve and verify
        agent = postgres_store.get_agent("cursor")
        assert agent is not None
        assert agent["scopes"] == ["mcp:admin"]
        assert agent["client_id"] == "0oa_cursor"

    def test_multiple_agents_persistence(self, postgres_store, cursor_agent_data, claude_code_agent_data):
        """Test persisting multiple agents."""
        # Create multiple agents
        postgres_store.create_agent(cursor_agent_data["agent_id"], cursor_agent_data, user="test_user")
        postgres_store.create_agent(claude_code_agent_data["agent_id"], claude_code_agent_data, user="test_user")

        # Retrieve all and verify
        agents = postgres_store.get_all_agents(enabled_only=False)
        assert len(agents) == 2

        agent_ids = {a["agent_id"] for a in agents}
        assert agent_ids == {"cursor", "claude-code"}


class TestAgentConfig:
    """Test AgentConfig model."""

    def test_agent_config_validation(self):
        """Test AgentConfig Pydantic model validation."""
        config = AgentConfig(
            agent_id="test",
            client_id="0oa_test",
            client_secret="test_secret",
            private_key="test_key",
            resource_access=["employees"]
        )

        assert config.agent_id == "test"
        assert config.client_id == "0oa_test"
        assert config.private_key == "test_key"
        assert config.resource_access == ["employees"]

    def test_agent_config_defaults(self):
        """Test AgentConfig default values."""
        config = AgentConfig(
            agent_id="test",
            client_id="0oa_test",
            client_secret="test_secret",
            private_key="test_key"
        )

        assert config.agent_id == "test"
        assert config.resource_access == []


class TestGetAllAgents:
    """Test getting all agents."""

    def test_get_all_agents_enabled_only(self, postgres_store, cursor_agent_data, claude_code_agent_data):
        """Test getting only enabled agents."""
        postgres_store.create_agent(cursor_agent_data["agent_id"], cursor_agent_data, user="test_user")
        postgres_store.create_agent(claude_code_agent_data["agent_id"], claude_code_agent_data, user="test_user")

        # Disable one agent
        postgres_store.disable_agent("claude-code", user="test_user")

        agents = postgres_store.get_all_agents(enabled_only=True)
        assert len(agents) == 1
        assert agents[0]["agent_id"] == "cursor"

    def test_get_all_agents_including_disabled(self, postgres_store, cursor_agent_data, claude_code_agent_data):
        """Test getting all agents including disabled."""
        postgres_store.create_agent(cursor_agent_data["agent_id"], cursor_agent_data, user="test_user")
        postgres_store.create_agent(claude_code_agent_data["agent_id"], claude_code_agent_data, user="test_user")

        postgres_store.disable_agent("claude-code", user="test_user")

        agents = postgres_store.get_all_agents(enabled_only=False)
        assert len(agents) == 2

        agent_ids = {a["agent_id"] for a in agents}
        assert agent_ids == {"cursor", "claude-code"}

    def test_get_all_agents_empty(self, postgres_store):
        """Test getting all agents when database is empty."""
        agents = postgres_store.get_all_agents()
        assert agents == []

