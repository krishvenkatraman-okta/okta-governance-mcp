"""
Tests for OktaConnectionSyncer.

Covers:
- sync() with mock Okta API returning all 3 connection types
- ORN parsing: valid, invalid, preview vs production
- Merge: connection matches Resource Map → ResolvedResource created
- Unresolved: connection has no Resource Map entry
- Inactive connections skipped
- Okta API error: keeps last-known-good, status = "error"
- Okta API timeout: graceful
- Diff detection: added, removed, modified across syncs
- Event bus integration: sync publishes okta:sync event
- _on_resource_changed: re-merges without calling Okta API
- Scope conditions: INCLUDE_ONLY, DISALLOW, null → ALLOW_ALL
- Stale detection
- Sync state persisted to okta_sync_state table
"""

import pytest

pytest.skip(
    "Superseded by P07 — relies on SQLAlchemy ResourceMapStore; rewrite "
    "against psycopg3 ResourceStore if needed.",
    allow_module_level=True,
)

import time  # noqa: E402
from datetime import datetime, timedelta  # noqa: E402
from unittest.mock import AsyncMock, MagicMock, patch  # noqa: E402

import httpx  # noqa: E402

from sqlalchemy import create_engine  # noqa: E402
from sqlalchemy.orm import sessionmaker  # noqa: E402

from okta_agent_proxy.storage.models import Base  # noqa: E402
from okta_agent_proxy.storage.postgres import ResourceMapStore  # noqa: E402
from okta_agent_proxy.resources.event_bus import (
    CacheEventBus,
    CHANNEL_OKTA_SYNC,
    CHANNEL_RESOURCE_CHANGED,
)
from okta_agent_proxy.resources.models import (
    OktaConnectionType,
    OktaScopeCondition,
    ResourceMapEntry,
    ResolvedResource,
)
from okta_agent_proxy.resources.syncer import OktaConnectionSyncer


# ============================================================================
# Fixtures
# ============================================================================

# Default agent ID returned by _get_imported_agent_ids in tests
_TEST_AGENT_IDS = ["agt-test-001"]


@pytest.fixture
def syncer_engine():
    engine = create_engine(
        "sqlite:///:memory:",
        connect_args={"check_same_thread": False},
        echo=False,
    )
    Base.metadata.create_all(engine)
    yield engine
    Base.metadata.drop_all(engine)
    engine.dispose()


@pytest.fixture
def syncer_session_factory(syncer_engine):
    return sessionmaker(bind=syncer_engine)


@pytest.fixture
def rm_store(syncer_session_factory):
    store = ResourceMapStore(syncer_session_factory)
    # Pre-populate with resource map entries
    store.create(ResourceMapEntry(
        resource_id="ausvpuw0yn",
        name="hr-system",
        mcp_url="https://hr.example.com/mcp",
    ))
    store.create(ResourceMapEntry(
        resource_id="secret123",
        name="api-keys",
        mcp_url="https://keys.example.com/mcp",
    ))
    store.create(ResourceMapEntry(
        resource_id="sa456",
        name="deploy-bot",
        mcp_url="https://deploy.example.com/mcp",
        protocol="a2a",
    ))
    store.load_cache()
    return store


@pytest.fixture
def event_bus():
    return CacheEventBus(redis_url=None)


@pytest.fixture
def syncer(rm_store, event_bus):
    return OktaConnectionSyncer(
        okta_domain="dev-12345.okta.com",
        api_token="test-token",
        resource_map_store=rm_store,
        event_bus=event_bus,
        stale_threshold=1800,
    )


def _make_connection(
    conn_type, conn_id="conn-1", status="ACTIVE",
    orn=None, secret_id=None, sa_id=None,
    scopes=None, scope_condition=None,
):
    """Helper to build a mock Okta connection dict."""
    conn = {
        "id": conn_id,
        "type": conn_type,
        "status": status,
    }
    if orn:
        conn["orn"] = orn
    if secret_id:
        conn["secretId"] = secret_id
    if sa_id:
        conn["serviceAccountId"] = sa_id
    if scopes is not None:
        conn["scopes"] = scopes
    if scope_condition is not None:
        conn["scopeCondition"] = scope_condition
    return conn


def _mock_okta_response(connections, status_code=200):
    """Build an httpx.Response mock for the Okta API."""
    resp = MagicMock(spec=httpx.Response)
    resp.status_code = status_code
    resp.json.return_value = connections
    resp.text = str(connections)
    resp.request = MagicMock(spec=httpx.Request)
    return resp


def _patch_agent_ids(syncer, agent_ids=None):
    """Return a context manager that patches _get_imported_agents.

    Builds agent info dicts from the agent IDs for compatibility with
    the connection-scoped identity model.
    """
    ids = agent_ids or _TEST_AGENT_IDS
    agents = [
        {"okta_ai_agent_id": aid, "agent_id": aid, "agent_name": aid}
        for aid in ids
    ]
    return patch.object(syncer, "_get_imported_agents", return_value=agents)


# ============================================================================
# ORN Parsing
# ============================================================================


class TestORNParsing:

    def test_valid_preview_orn(self):
        orn = "orn:oktapreview:idp:00oabc:authorization_servers:ausvpuw0yn"
        assert OktaConnectionSyncer.parse_orn(orn) == "ausvpuw0yn"

    def test_valid_production_orn(self):
        orn = "orn:okta:idp:00odef:authorization_servers:aus999"
        assert OktaConnectionSyncer.parse_orn(orn) == "aus999"

    def test_orn_with_long_as_id(self):
        orn = "orn:okta:idp:org1:authorization_servers:ausAbCdEfGhIjKlMnOp"
        assert OktaConnectionSyncer.parse_orn(orn) == "ausAbCdEfGhIjKlMnOp"

    def test_invalid_orn_missing_prefix(self):
        assert OktaConnectionSyncer.parse_orn("not:an:orn") is None

    def test_invalid_orn_no_as_section(self):
        assert OktaConnectionSyncer.parse_orn("orn:okta:idp:org1:other:val") is None

    def test_invalid_orn_empty(self):
        assert OktaConnectionSyncer.parse_orn("") is None

    def test_invalid_orn_truncated(self):
        orn = "orn:okta:idp:org1:authorization_servers"
        assert OktaConnectionSyncer.parse_orn(orn) is None


# ============================================================================
# sync() — all 3 connection types
# ============================================================================


class TestSyncAllTypes:

    @pytest.mark.asyncio
    async def test_sync_all_three_connection_types(self, syncer):
        connections = [
            _make_connection(
                "IDENTITY_ASSERTION_CUSTOM_AS", "conn-1",
                orn="orn:okta:idp:org1:authorization_servers:ausvpuw0yn",
            ),
            _make_connection(
                "SECRET", "conn-2", secret_id="secret123",
            ),
            _make_connection(
                "SERVICE_ACCOUNT", "conn-3", sa_id="sa456",
            ),
        ]
        resp = _mock_okta_response(connections)

        await syncer.start()
        with _patch_agent_ids(syncer), \
             patch.object(syncer._http_client, "get", return_value=resp):
            result = await syncer.sync(publish=False)

        assert result.total == 3
        assert len(result.unresolved) == 0
        assert len(syncer.get_all_resources()) == 3
        await syncer.stop()

    @pytest.mark.asyncio
    async def test_identity_assertion_creates_okta_cross_app(self, syncer):
        connections = [
            _make_connection(
                "IDENTITY_ASSERTION_CUSTOM_AS", "conn-1",
                orn="orn:okta:idp:org1:authorization_servers:ausvpuw0yn",
            ),
        ]
        resp = _mock_okta_response(connections)

        await syncer.start()
        with _patch_agent_ids(syncer), \
             patch.object(syncer._http_client, "get", return_value=resp):
            await syncer.sync(publish=False)

        resolved = syncer.get_resource("hr-system")
        assert resolved is not None
        assert resolved.auth_method == "okta-cross-app"
        assert resolved.connection_type == OktaConnectionType.IDENTITY_ASSERTION_CUSTOM_AS
        await syncer.stop()

    @pytest.mark.asyncio
    async def test_secret_creates_pre_shared_key(self, syncer):
        connections = [
            _make_connection("SECRET", "conn-2", secret_id="secret123"),
        ]
        resp = _mock_okta_response(connections)

        await syncer.start()
        with _patch_agent_ids(syncer), \
             patch.object(syncer._http_client, "get", return_value=resp):
            await syncer.sync(publish=False)

        resolved = syncer.get_resource("api-keys")
        assert resolved is not None
        assert resolved.auth_method == "vault-secret"
        await syncer.stop()

    @pytest.mark.asyncio
    async def test_service_account_creates_sts_service_account(self, syncer):
        connections = [
            _make_connection("SERVICE_ACCOUNT", "conn-3", sa_id="sa456"),
        ]
        resp = _mock_okta_response(connections)

        await syncer.start()
        with _patch_agent_ids(syncer), \
             patch.object(syncer._http_client, "get", return_value=resp):
            await syncer.sync(publish=False)

        resolved = syncer.get_resource("deploy-bot")
        assert resolved is not None
        assert resolved.auth_method == "sts-service-account"
        assert resolved.protocol == "a2a"
        await syncer.stop()


# ============================================================================
# Merge — resolved vs. unresolved
# ============================================================================


class TestMergeResolution:

    @pytest.mark.asyncio
    async def test_unresolved_when_no_resource_map_entry(self, syncer):
        connections = [
            _make_connection(
                "IDENTITY_ASSERTION_CUSTOM_AS", "conn-1",
                orn="orn:okta:idp:org1:authorization_servers:unknown-as-id",
            ),
        ]
        resp = _mock_okta_response(connections)

        await syncer.start()
        with _patch_agent_ids(syncer), \
             patch.object(syncer._http_client, "get", return_value=resp):
            result = await syncer.sync(publish=False)

        assert result.total == 0
        assert "unknown-as-id" in result.unresolved
        assert syncer.get_unresolved() == ["unknown-as-id"]
        await syncer.stop()

    @pytest.mark.asyncio
    async def test_inactive_connections_skipped(self, syncer):
        connections = [
            _make_connection(
                "IDENTITY_ASSERTION_CUSTOM_AS", "conn-1", status="INACTIVE",
                orn="orn:okta:idp:org1:authorization_servers:ausvpuw0yn",
            ),
        ]
        resp = _mock_okta_response(connections)

        await syncer.start()
        with _patch_agent_ids(syncer), \
             patch.object(syncer._http_client, "get", return_value=resp):
            result = await syncer.sync(publish=False)

        assert result.total == 0
        assert len(syncer.get_all_resources()) == 0
        await syncer.stop()

    @pytest.mark.asyncio
    async def test_unknown_connection_type_skipped(self, syncer):
        connections = [{"id": "c1", "type": "UNKNOWN_TYPE", "status": "ACTIVE"}]
        resp = _mock_okta_response(connections)

        await syncer.start()
        with _patch_agent_ids(syncer), \
             patch.object(syncer._http_client, "get", return_value=resp):
            result = await syncer.sync(publish=False)

        assert result.total == 0
        await syncer.stop()


# ============================================================================
# Okta API errors
# ============================================================================


class TestOktaAPIErrors:

    @pytest.mark.asyncio
    async def test_api_error_keeps_last_known_good(self, syncer):
        # First sync succeeds
        good_connections = [
            _make_connection(
                "SECRET", "conn-2", secret_id="secret123",
            ),
        ]
        good_resp = _mock_okta_response(good_connections)

        await syncer.start()
        with _patch_agent_ids(syncer), \
             patch.object(syncer._http_client, "get", return_value=good_resp):
            result1 = await syncer.sync(publish=False)
        assert result1.total == 1

        # Second sync fails — last-known-good preserved
        bad_resp = _mock_okta_response([], status_code=500)
        with _patch_agent_ids(syncer), \
             patch.object(syncer._http_client, "get", return_value=bad_resp):
            result2 = await syncer.sync(publish=False)

        # Partial status because agent failed but we kept last-known data
        assert syncer._last_sync_status in ("error", "partial")
        # Resources from first sync still there
        assert len(syncer.get_all_resources()) == 1
        await syncer.stop()

    @pytest.mark.asyncio
    async def test_api_timeout_graceful(self, syncer):
        await syncer.start()
        with _patch_agent_ids(syncer), \
             patch.object(
                syncer._http_client, "get",
                side_effect=httpx.TimeoutException("timeout"),
             ):
            result = await syncer.sync(publish=False)

        assert syncer._last_sync_status == "error"
        assert result.total == 0  # no previous data
        await syncer.stop()

    @pytest.mark.asyncio
    async def test_api_connection_error(self, syncer):
        await syncer.start()
        with _patch_agent_ids(syncer), \
             patch.object(
                syncer._http_client, "get",
                side_effect=httpx.ConnectError("refused"),
             ):
            result = await syncer.sync(publish=False)

        assert syncer._last_sync_status == "error"
        await syncer.stop()


# ============================================================================
# Diff detection across syncs
# ============================================================================


class TestDiffDetection:

    @pytest.mark.asyncio
    async def test_added_on_first_sync(self, syncer):
        connections = [
            _make_connection("SECRET", "conn-2", secret_id="secret123"),
        ]
        resp = _mock_okta_response(connections)

        await syncer.start()
        with _patch_agent_ids(syncer), \
             patch.object(syncer._http_client, "get", return_value=resp):
            result = await syncer.sync(publish=False)

        assert result.added == ["api-keys"]
        assert result.removed == []
        assert result.modified == []
        await syncer.stop()

    @pytest.mark.asyncio
    async def test_removed_on_second_sync(self, syncer):
        # First sync: 2 resources
        conn1 = [
            _make_connection("SECRET", "conn-2", secret_id="secret123"),
            _make_connection("SERVICE_ACCOUNT", "conn-3", sa_id="sa456"),
        ]
        resp1 = _mock_okta_response(conn1)

        await syncer.start()
        with _patch_agent_ids(syncer), \
             patch.object(syncer._http_client, "get", return_value=resp1):
            await syncer.sync(publish=False)

        # Second sync: 1 resource (deploy-bot removed)
        conn2 = [
            _make_connection("SECRET", "conn-2", secret_id="secret123"),
        ]
        resp2 = _mock_okta_response(conn2)
        with _patch_agent_ids(syncer), \
             patch.object(syncer._http_client, "get", return_value=resp2):
            result = await syncer.sync(publish=False)

        assert result.removed == ["deploy-bot"]
        await syncer.stop()

    @pytest.mark.asyncio
    async def test_modified_on_scope_change(self, syncer):
        # First sync
        conn1 = [
            _make_connection(
                "SECRET", "conn-2", secret_id="secret123",
                scopes=["read"],
            ),
        ]
        resp1 = _mock_okta_response(conn1)

        await syncer.start()
        with _patch_agent_ids(syncer), \
             patch.object(syncer._http_client, "get", return_value=resp1):
            await syncer.sync(publish=False)

        # Second sync: scopes changed
        conn2 = [
            _make_connection(
                "SECRET", "conn-2", secret_id="secret123",
                scopes=["read", "write"],
            ),
        ]
        resp2 = _mock_okta_response(conn2)
        with _patch_agent_ids(syncer), \
             patch.object(syncer._http_client, "get", return_value=resp2):
            result = await syncer.sync(publish=False)

        assert result.modified == ["api-keys"]
        await syncer.stop()


# ============================================================================
# Event bus integration
# ============================================================================


class TestEventBusIntegration:

    @pytest.mark.asyncio
    async def test_sync_publishes_okta_sync_event(self, syncer, event_bus):
        event_bus.publish = AsyncMock()
        connections = [
            _make_connection("SECRET", "conn-2", secret_id="secret123"),
        ]
        resp = _mock_okta_response(connections)

        await syncer.start()
        with _patch_agent_ids(syncer), \
             patch.object(syncer._http_client, "get", return_value=resp):
            await syncer.sync(publish=True)

        event_bus.publish.assert_called_once_with(
            CHANNEL_OKTA_SYNC, "sync-complete"
        )
        await syncer.stop()

    @pytest.mark.asyncio
    async def test_sync_publish_false_does_not_publish(self, syncer, event_bus):
        event_bus.publish = AsyncMock()
        connections = [
            _make_connection("SECRET", "conn-2", secret_id="secret123"),
        ]
        resp = _mock_okta_response(connections)

        await syncer.start()
        with _patch_agent_ids(syncer), \
             patch.object(syncer._http_client, "get", return_value=resp):
            await syncer.sync(publish=False)

        event_bus.publish.assert_not_called()
        await syncer.stop()


# ============================================================================
# _on_resource_changed — re-merge without Okta API call
# ============================================================================


class TestResourceChangedHandler:

    @pytest.mark.asyncio
    async def test_re_merge_resolves_previously_unresolved(self, syncer, rm_store):
        # First sync: "new-as-id" is unresolved
        connections = [
            _make_connection(
                "IDENTITY_ASSERTION_CUSTOM_AS", "conn-1",
                orn="orn:okta:idp:org1:authorization_servers:new-as-id",
            ),
        ]
        resp = _mock_okta_response(connections)

        await syncer.start()
        with _patch_agent_ids(syncer), \
             patch.object(syncer._http_client, "get", return_value=resp):
            result = await syncer.sync(publish=False)
        assert "new-as-id" in result.unresolved

        # Admin adds the resource map entry
        rm_store.create(ResourceMapEntry(
            resource_id="new-as-id",
            name="new-service",
            mcp_url="https://new.example.com/mcp",
        ))
        rm_store.load_cache()

        # Resource changed event triggers re-merge (no Okta API call)
        with patch.object(syncer._http_client, "get") as mock_get:
            await syncer._on_resource_changed("update")
            mock_get.assert_not_called()

        assert syncer.get_resource("new-service") is not None
        assert "new-as-id" not in syncer.get_unresolved()
        await syncer.stop()

    @pytest.mark.asyncio
    async def test_re_merge_with_no_prior_connections(self, syncer):
        """Re-merge when no sync has happened yet does nothing."""
        await syncer.start()
        await syncer._on_resource_changed("update")
        assert syncer.get_all_resources() == []
        await syncer.stop()


# ============================================================================
# Scope conditions
# ============================================================================


class TestScopeConditions:

    @pytest.mark.asyncio
    async def test_include_only_scope_condition(self, syncer):
        connections = [
            _make_connection(
                "SECRET", "conn-2", secret_id="secret123",
                scopes=["mcp:read"], scope_condition="INCLUDE_ONLY",
            ),
        ]
        resp = _mock_okta_response(connections)

        await syncer.start()
        with _patch_agent_ids(syncer), \
             patch.object(syncer._http_client, "get", return_value=resp):
            await syncer.sync(publish=False)

        resolved = syncer.get_resource("api-keys")
        assert resolved.scope_condition == OktaScopeCondition.INCLUDE_ONLY
        assert resolved.scopes == ["mcp:read"]
        await syncer.stop()

    @pytest.mark.asyncio
    async def test_disallow_scope_condition(self, syncer):
        connections = [
            _make_connection(
                "SECRET", "conn-2", secret_id="secret123",
                scopes=["admin"], scope_condition="DISALLOW",
            ),
        ]
        resp = _mock_okta_response(connections)

        await syncer.start()
        with _patch_agent_ids(syncer), \
             patch.object(syncer._http_client, "get", return_value=resp):
            await syncer.sync(publish=False)

        resolved = syncer.get_resource("api-keys")
        assert resolved.scope_condition == OktaScopeCondition.DISALLOW
        await syncer.stop()

    @pytest.mark.asyncio
    async def test_null_scope_condition_defaults_to_allow_all(self, syncer):
        connections = [
            _make_connection(
                "SECRET", "conn-2", secret_id="secret123",
            ),
        ]
        resp = _mock_okta_response(connections)

        await syncer.start()
        with _patch_agent_ids(syncer), \
             patch.object(syncer._http_client, "get", return_value=resp):
            await syncer.sync(publish=False)

        resolved = syncer.get_resource("api-keys")
        assert resolved.scope_condition == OktaScopeCondition.ALLOW_ALL
        await syncer.stop()

    @pytest.mark.asyncio
    async def test_invalid_scope_condition_defaults_to_allow_all(self, syncer):
        connections = [
            _make_connection(
                "SECRET", "conn-2", secret_id="secret123",
                scope_condition="BOGUS_VALUE",
            ),
        ]
        resp = _mock_okta_response(connections)

        await syncer.start()
        with _patch_agent_ids(syncer), \
             patch.object(syncer._http_client, "get", return_value=resp):
            await syncer.sync(publish=False)

        resolved = syncer.get_resource("api-keys")
        assert resolved.scope_condition == OktaScopeCondition.ALLOW_ALL
        await syncer.stop()


# ============================================================================
# Stale detection
# ============================================================================


class TestStaleDetection:

    def test_is_stale_when_never_synced(self, syncer):
        assert syncer.is_stale() is True

    @pytest.mark.asyncio
    async def test_not_stale_after_sync(self, syncer):
        connections = [
            _make_connection("SECRET", "conn-2", secret_id="secret123"),
        ]
        resp = _mock_okta_response(connections)

        await syncer.start()
        with _patch_agent_ids(syncer), \
             patch.object(syncer._http_client, "get", return_value=resp):
            await syncer.sync(publish=False)

        assert syncer.is_stale() is False
        await syncer.stop()

    def test_is_stale_when_threshold_exceeded(self, syncer):
        syncer._last_sync_at = datetime.utcnow() - timedelta(seconds=2000)
        syncer._stale_threshold = 1800
        assert syncer.is_stale() is True

    def test_not_stale_within_threshold(self, syncer):
        syncer._last_sync_at = datetime.utcnow() - timedelta(seconds=100)
        syncer._stale_threshold = 1800
        assert syncer.is_stale() is False


# ============================================================================
# Sync status
# ============================================================================


class TestSyncStatus:

    def test_initial_sync_status(self, syncer):
        status = syncer.get_sync_status()
        assert status["status"] == "never"
        assert status["last_sync_at"] is None
        assert status["is_stale"] is True
        assert status["resources_count"] == 0
        assert status["unresolved_count"] == 0

    @pytest.mark.asyncio
    async def test_sync_status_after_success(self, syncer):
        connections = [
            _make_connection("SECRET", "conn-2", secret_id="secret123"),
        ]
        resp = _mock_okta_response(connections)

        await syncer.start()
        with _patch_agent_ids(syncer), \
             patch.object(syncer._http_client, "get", return_value=resp):
            await syncer.sync(publish=False)

        status = syncer.get_sync_status()
        assert status["status"] == "success"
        assert status["last_sync_at"] is not None
        assert status["resources_count"] == 1
        await syncer.stop()


# ============================================================================
# Sync state persisted to DB
# ============================================================================


class TestSyncStatePersistence:

    @pytest.mark.asyncio
    async def test_sync_persists_state_on_success(self, syncer, rm_store):
        connections = [
            _make_connection("SECRET", "conn-2", secret_id="secret123"),
        ]
        resp = _mock_okta_response(connections)

        await syncer.start()
        with _patch_agent_ids(syncer), \
             patch.object(syncer._http_client, "get", return_value=resp):
            await syncer.sync(publish=False)

        state = rm_store.get_latest_sync_state()
        assert state is not None
        assert state["status"] == "success"
        assert state["resources_count"] == 1
        assert state["unresolved_count"] == 0
        await syncer.stop()

    @pytest.mark.asyncio
    async def test_sync_persists_state_on_error(self, syncer, rm_store):
        await syncer.start()
        with _patch_agent_ids(syncer), \
             patch.object(
                syncer._http_client, "get",
                side_effect=httpx.ConnectError("refused"),
             ):
            await syncer.sync(publish=False)

        state = rm_store.get_latest_sync_state()
        assert state is not None
        assert state["status"] == "error"
        await syncer.stop()


# ============================================================================
# Lifecycle
# ============================================================================


class TestLifecycle:

    @pytest.mark.asyncio
    async def test_start_creates_http_client(self, syncer):
        assert syncer._http_client is None
        await syncer.start()
        assert syncer._http_client is not None
        await syncer.stop()

    @pytest.mark.asyncio
    async def test_stop_closes_http_client(self, syncer):
        await syncer.start()
        client = syncer._http_client
        await syncer.stop()
        assert syncer._http_client is None

    @pytest.mark.asyncio
    async def test_okta_domain_normalized(self):
        s = OktaConnectionSyncer(
            okta_domain="dev-123.okta.com",
            api_token="x",
            resource_map_store=MagicMock(),
            event_bus=MagicMock(),
        )
        assert s._okta_domain == "https://dev-123.okta.com"

    @pytest.mark.asyncio
    async def test_okta_domain_with_https(self):
        s = OktaConnectionSyncer(
            okta_domain="https://dev-123.okta.com",
            api_token="x",
            resource_map_store=MagicMock(),
            event_bus=MagicMock(),
        )
        assert s._okta_domain == "https://dev-123.okta.com"

    @pytest.mark.asyncio
    async def test_okta_domain_trailing_slash(self):
        s = OktaConnectionSyncer(
            okta_domain="https://dev-123.okta.com/",
            api_token="x",
            resource_map_store=MagicMock(),
            event_bus=MagicMock(),
        )
        assert s._okta_domain == "https://dev-123.okta.com"


# ============================================================================
# Okta API response formats
# ============================================================================


class TestAPIResponseFormats:

    @pytest.mark.asyncio
    async def test_response_as_list(self, syncer):
        connections = [
            _make_connection("SECRET", "conn-2", secret_id="secret123"),
        ]
        resp = _mock_okta_response(connections)

        await syncer.start()
        with _patch_agent_ids(syncer), \
             patch.object(syncer._http_client, "get", return_value=resp):
            result = await syncer.sync(publish=False)

        assert result.total == 1
        await syncer.stop()

    @pytest.mark.asyncio
    async def test_response_as_dict_with_connections_key(self, syncer):
        resp = _mock_okta_response({
            "connections": [
                _make_connection("SECRET", "conn-2", secret_id="secret123"),
            ]
        })

        await syncer.start()
        with _patch_agent_ids(syncer), \
             patch.object(syncer._http_client, "get", return_value=resp):
            result = await syncer.sync(publish=False)

        assert result.total == 1
        await syncer.stop()

    @pytest.mark.asyncio
    async def test_response_as_dict_with_items_key(self, syncer):
        resp = _mock_okta_response({
            "items": [
                _make_connection("SECRET", "conn-2", secret_id="secret123"),
            ]
        })

        await syncer.start()
        with _patch_agent_ids(syncer), \
             patch.object(syncer._http_client, "get", return_value=resp):
            result = await syncer.sync(publish=False)

        assert result.total == 1
        await syncer.stop()


# ============================================================================
# No imported agents
# ============================================================================


class TestNoImportedAgents:

    @pytest.mark.asyncio
    async def test_sync_with_no_imported_agents(self, rm_store, event_bus):
        """When no agents have been imported, sync succeeds with 0 resources."""
        s = OktaConnectionSyncer(
            okta_domain="dev-12345.okta.com",
            api_token="test-token",
            resource_map_store=rm_store,
            event_bus=event_bus,
            stale_threshold=1800,
        )
        await s.start()

        # Patch _get_imported_agent_ids to return empty list
        s._get_imported_agent_ids = lambda: []

        result = await s.sync(publish=False)

        assert result.total == 0
        assert s._last_sync_status == "success"
        await s.stop()
