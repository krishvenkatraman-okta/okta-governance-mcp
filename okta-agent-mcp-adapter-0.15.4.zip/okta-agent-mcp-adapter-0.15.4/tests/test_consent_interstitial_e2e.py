"""
End-to-end integration tests for the STS consent interstitial flow.

Wires up ConfidentialRelay, ConsentTransactionStore, ConsentVerificationService,
and GatewayCodeManager with a mini Starlette app exercising the full lifecycle.
"""

import asyncio
import hashlib
import json
import time
import pytest
from unittest.mock import AsyncMock, MagicMock, patch
from urllib.parse import urlparse, parse_qs, urlencode

import httpx
from starlette.applications import Starlette
from starlette.routing import Route
from starlette.requests import Request
from starlette.responses import JSONResponse, RedirectResponse, HTMLResponse
from starlette.testclient import TestClient

from okta_agent_proxy.auth.confidential_relay import ConfidentialRelay, RelayError
from okta_agent_proxy.auth.client_registry import ClientRegistry
from okta_agent_proxy.auth.consent_transaction import (
    ConsentConnectionStatus,
    ConsentTransaction,
    ConsentTransactionStore,
)
from okta_agent_proxy.auth.consent_verification import ConsentVerificationService
from okta_agent_proxy.auth.gateway_code_manager import GatewayCodeManager, GatewayCodeNotFound


# ---------------------------------------------------------------------------
# Shared test data
# ---------------------------------------------------------------------------

CIMD_CLIENT_ID = "https://testapp.example.com/oauth.json"
REDIRECT_URI = "http://localhost:9999/callback"
OKTA_TOKEN_RESPONSE = {
    "access_token": "at_okta_xyz",
    "id_token": "idt_okta_xyz",
    "refresh_token": "rt_okta_xyz",
    "token_type": "Bearer",
    "expires_in": 3600,
}


def _okta_mock_transport():
    def handler(request: httpx.Request) -> httpx.Response:
        return httpx.Response(
            200,
            content=json.dumps(OKTA_TOKEN_RESPONSE).encode(),
            headers={"content-type": "application/json"},
        )
    return httpx.MockTransport(handler)


def _make_sts_resource(name, connection_id=None, metadata=None):
    rc = MagicMock()
    rc.name = name
    rc.auth_method = "okta-sts"
    rc.connection_id = connection_id or f"conn-{name}"
    rc.metadata = metadata or {
        "app_instance_name": f"{name} Provider",
        "resource_indicator": f"orn:okta:test:{name}",
    }
    return rc


def _make_xaa_resource(name):
    rc = MagicMock()
    rc.name = name
    rc.auth_method = "okta-cross-app"
    rc.connection_id = f"conn-{name}"
    rc.metadata = {}
    return rc


# ---------------------------------------------------------------------------
# Mini test app builder
# ---------------------------------------------------------------------------

def _build_e2e_app(
    relay,
    consent_store,
    consent_service,
    client_info_mock,
    capture_fn=None,
    audit_events=None,
):
    """Build a Starlette app with callback, interstitial, status, complete, recheck, skip, and token endpoint."""
    _capture = capture_fn or MagicMock()
    _audit = audit_events if audit_events is not None else []

    async def _audit_emit(event_type, severity=None, details=None):
        _audit.append({"event_type": event_type, "details": details or {}})

    async def oauth_callback(request):
        code = request.query_params.get("code")
        state = request.query_params.get("state")
        if not code or not state:
            return JSONResponse({"error": "missing params"}, status_code=400)

        try:
            callback_result = await relay.handle_callback_tokens_only(state, code)
            original_client_id = callback_result["original_client_id"]

            agent_config = None
            agent_id = None
            if client_info_mock and client_info_mock.agent_config:
                agent_config = client_info_mock.agent_config
                agent_id = agent_config.get("agent_id", "")

            has_sts = False
            if agent_config and agent_id:
                sts_resources = consent_service.get_sts_resources(agent_id, agent_config)
                has_sts = len(sts_resources) > 0

            if not has_sts:
                gateway_code = relay._code_manager.issue_code(
                    client_id=original_client_id,
                    tokens={
                        "access_token": callback_result["access_token"],
                        "id_token": callback_result["id_token"],
                        "refresh_token": callback_result.get("refresh_token"),
                        "expires_in": callback_result.get("expires_in"),
                    },
                    extra={
                        "relay_client_id": callback_result.get("relay_client_id", ""),
                        "relay_client_secret": callback_result.get("relay_client_secret", ""),
                    },
                )
                redirect_params = {"code": gateway_code, "state": callback_result["original_state"]}
                redirect_url = f"{callback_result['original_redirect_uri']}?{urlencode(redirect_params)}"
                return RedirectResponse(url=redirect_url, status_code=302)

            ua_hash = hashlib.sha256(
                request.headers.get("user-agent", "").encode()
            ).hexdigest()[:16]

            transaction = consent_store.create(
                original_redirect_uri=callback_result["original_redirect_uri"],
                original_state=callback_result["original_state"],
                original_client_id=original_client_id,
                id_token=callback_result["id_token"],
                access_token=callback_result["access_token"],
                refresh_token=callback_result.get("refresh_token"),
                okta_expires_in=callback_result.get("expires_in"),
                agent_id=agent_id,
                agent_config=agent_config,
                ip_address=request.client.host if request.client else "",
                user_agent_hash=ua_hash,
                relay_client_id=callback_result.get("relay_client_id", ""),
                relay_client_secret=callback_result.get("relay_client_secret", ""),
            )

            await _audit_emit("sts.consent.tx.created", details={
                "transaction_id": transaction.transaction_id,
                "sts_resource_count": len(sts_resources),
            })

            asyncio.ensure_future(consent_service.verify_all(transaction))

            response = RedirectResponse(
                url=f"/oauth/consent-verify?tx={transaction.transaction_id}",
                status_code=302,
            )
            response.set_cookie(
                "__okta_consent_session",
                value=transaction.session_id,
                httponly=True, samesite="lax", path="/oauth", max_age=600,
            )
            return response

        except RelayError as e:
            return JSONResponse({"error": str(e)}, status_code=400)

    async def consent_verify(request):
        tx_id = request.query_params.get("tx", "")
        session_id = request.cookies.get("__okta_consent_session", "")
        if not tx_id or not session_id:
            return HTMLResponse("<h1>Bad</h1>", status_code=400)
        ua_hash = hashlib.sha256(request.headers.get("user-agent", "").encode()).hexdigest()[:16]
        tx = consent_store.validate_session(session_id, request.client.host if request.client else "", ua_hash)
        if not tx or tx.transaction_id != tx_id:
            return HTMLResponse("<h1>Invalid</h1>", status_code=403)
        return HTMLResponse(f"<html><body>TX={tx_id}</body></html>")

    async def consent_status(request):
        tx_id = request.query_params.get("tx", "")
        session_id = request.cookies.get("__okta_consent_session", "")
        if not tx_id or not session_id:
            return JSONResponse({"error": "invalid_request"}, status_code=400)
        ua_hash = hashlib.sha256(request.headers.get("user-agent", "").encode()).hexdigest()[:16]
        tx = consent_store.validate_session(session_id, request.client.host if request.client else "", ua_hash)
        if not tx or tx.transaction_id != tx_id:
            return JSONResponse({"error": "session_invalid"}, status_code=403)
        if tx.is_expired:
            return JSONResponse({"error": "session_expired"}, status_code=410)
        return JSONResponse({
            "status": tx.status,
            "connections": [
                {"resource_name": c.resource_name, "provider": c.provider,
                 "status": c.status, "interaction_uri": c.interaction_uri if c.status == "consent_required" else None}
                for c in tx.connections
            ],
        })

    async def consent_complete(request):
        form = await request.form()
        tx_id = form.get("tx", "")
        session_id = request.cookies.get("__okta_consent_session", "")
        if not tx_id or not session_id:
            return JSONResponse({"error": "invalid_request"}, status_code=400)
        ua_hash = hashlib.sha256(request.headers.get("user-agent", "").encode()).hexdigest()[:16]
        tx = consent_store.validate_session(session_id, request.client.host if request.client else "", ua_hash)
        if not tx or tx.transaction_id != tx_id:
            return HTMLResponse("<h1>Expired</h1>", status_code=400)

        gateway_code = relay._code_manager.issue_code(
            client_id=tx.original_client_id,
            tokens={"access_token": tx.access_token, "id_token": tx.id_token,
                    "refresh_token": tx.refresh_token, "expires_in": tx.okta_expires_in},
            extra={"relay_client_id": tx.relay_client_id, "relay_client_secret": tx.relay_client_secret},
        )
        redirect_params = {"code": gateway_code, "state": tx.original_state}
        redirect_url = f"{tx.original_redirect_uri}?{urlencode(redirect_params)}"

        await _audit_emit("sts.consent.tx.completed", details={
            "transaction_id": tx.transaction_id,
            "verified_count": sum(1 for c in tx.connections if c.status == "verified"),
        })

        consent_store.remove(tx.transaction_id)
        response = RedirectResponse(url=redirect_url, status_code=302)
        response.delete_cookie("__okta_consent_session", path="/oauth")
        return response

    async def consent_recheck(request):
        form = await request.form()
        tx_id = form.get("tx", "")
        session_id = request.cookies.get("__okta_consent_session", "")
        if not tx_id or not session_id:
            return JSONResponse({"error": "invalid_request"}, status_code=400)
        ua_hash = hashlib.sha256(request.headers.get("user-agent", "").encode()).hexdigest()[:16]
        tx = consent_store.validate_session(session_id, request.client.host if request.client else "", ua_hash)
        if not tx or tx.transaction_id != tx_id:
            return JSONResponse({"error": "session_invalid"}, status_code=403)
        await consent_service.recheck_pending(tx)
        return JSONResponse({"status": tx.status})

    async def consent_skip(request):
        form = await request.form()
        tx_id = form.get("tx", "")
        session_id = request.cookies.get("__okta_consent_session", "")
        if not tx_id or not session_id:
            return JSONResponse({"error": "invalid_request"}, status_code=400)
        ua_hash = hashlib.sha256(request.headers.get("user-agent", "").encode()).hexdigest()[:16]
        tx = consent_store.validate_session(session_id, request.client.host if request.client else "", ua_hash)
        if not tx or tx.transaction_id != tx_id:
            return JSONResponse({"error": "session_invalid"}, status_code=403)
        for conn in tx.connections:
            if conn.status == "consent_required":
                conn.status = "skipped"
        tx.skip_requested = True
        tx.status = "complete"
        await _audit_emit("sts.consent.tx.skipped")
        return JSONResponse({"status": "complete"})

    async def token_endpoint(request):
        body = dict(await request.form())
        grant_type = body.get("grant_type")
        client_id = body.get("client_id", "")
        if grant_type == "authorization_code" and client_id:
            code = body.get("code")
            if code:
                try:
                    tokens = await relay.exchange_code(code, client_id)
                    if tokens.get("access_token") and tokens.get("id_token"):
                        _capture(tokens["access_token"], tokens["id_token"],
                                 tokens.get("refresh_token"), client_id,
                                 tokens.get("expires_in", 3600))
                    return JSONResponse(tokens)
                except RelayError as e:
                    return JSONResponse({"error": "invalid_grant", "error_description": str(e)}, status_code=400)
        return JSONResponse({"error": "unsupported"}, status_code=400)

    return Starlette(routes=[
        Route("/oauth/callback", oauth_callback, methods=["GET"]),
        Route("/oauth/consent-verify", consent_verify, methods=["GET"]),
        Route("/oauth/consent-status", consent_status, methods=["GET"]),
        Route("/oauth/consent-complete", consent_complete, methods=["POST"]),
        Route("/oauth/consent-recheck", consent_recheck, methods=["POST"]),
        Route("/oauth/consent-skip", consent_skip, methods=["POST"]),
        Route("/oauth2/v1/token", token_endpoint, methods=["POST"]),
    ])


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _make_client_info(agent_id="agent-1", with_sts=True):
    info = MagicMock()
    info.registration_source = "cimd"
    info.agent_config = {
        "agent_id": agent_id,
        "client_id": "0oa_xyz",
        "private_key": "PLACEHOLDER",
        "principal_id": "pid_abc",
    }
    return info


def _make_router(resources):
    router = MagicMock()
    resource_map = {rc.name: rc for rc in resources}
    router.list_resources.return_value = resource_map
    router.resolve_resource.side_effect = lambda name, agent_id=None: resource_map.get(name)
    return router


def _start_auth_and_callback(relay, client, auth_state="client_state_abc"):
    """Start authorization and hit callback, return response."""
    from okta_agent_proxy.auth.cimd_fetcher import CIMDMetadata
    from datetime import datetime, timezone

    metadata = CIMDMetadata(
        client_id=CIMD_CLIENT_ID, client_name="Test",
        redirect_uris=[REDIRECT_URI], grant_types=["authorization_code"],
        response_types=["code"], token_endpoint_auth_method="none",
        jwks_uri=None, logo_uri=None, client_uri=None, scope=None,
        domain="testapp.example.com", fetched_at=datetime.now(timezone.utc), raw_json={},
    )

    loop = asyncio.new_event_loop()
    try:
        okta_url = loop.run_until_complete(relay.start_authorization(
            metadata,
            {"redirect_uri": REDIRECT_URI, "state": auth_state, "scope": "openid"},
            relay_client_id="relay_cid", relay_client_secret="relay_secret",
        ))
    finally:
        loop.close()
    relay_state = parse_qs(urlparse(okta_url).query)["state"][0]

    resp = client.get(
        f"/oauth/callback?code=okta_code&state={relay_state}",
        follow_redirects=False,
    )
    return resp


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------


class TestE2ENoSTS:
    def test_e2e_no_sts_connections_fast_path(self):
        """No STS resources → direct redirect to agent, code works."""
        relay = ConfidentialRelay(
            gateway_base_url="http://localhost:8000",
            okta_domain="dev-test.okta.com",
            transport=_okta_mock_transport(),
        )
        store = ConsentTransactionStore()
        router = _make_router([_make_xaa_resource("hr-system")])
        token_cache = MagicMock()
        svc = ConsentVerificationService(router, token_cache)
        client_info = _make_client_info()

        app = _build_e2e_app(relay, store, svc, client_info)
        tc = TestClient(app, raise_server_exceptions=False)

        resp = _start_auth_and_callback(relay, tc)

        assert resp.status_code == 302
        location = resp.headers["location"]
        assert location.startswith(REDIRECT_URI)
        params = parse_qs(urlparse(location).query)
        gateway_code = params["code"][0]
        assert params["state"] == ["client_state_abc"]

        # Exchange the code
        token_resp = tc.post("/oauth2/v1/token", data={
            "grant_type": "authorization_code",
            "code": gateway_code,
            "client_id": CIMD_CLIENT_ID,
        })
        assert token_resp.status_code == 200
        assert token_resp.json()["access_token"] == "at_okta_xyz"


class TestE2EAllVerified:
    @patch("okta_agent_proxy.auth.okta_sts_exchanger.OktaSTSTokenExchanger")
    def test_e2e_all_consents_verified(self, MockExchanger):
        """All STS consents verified → complete → redirect → exchange."""
        mock_instance = AsyncMock()
        mock_instance.exchange.return_value = {
            "status": "success",
            "access_token": "isv_tok",
            "expires_in": 3600,
        }
        MockExchanger.return_value = mock_instance

        relay = ConfidentialRelay(
            gateway_base_url="http://localhost:8000",
            okta_domain="dev-test.okta.com",
            transport=_okta_mock_transport(),
        )
        store = ConsentTransactionStore()
        resources = [_make_sts_resource("github"), _make_sts_resource("jira")]
        router = _make_router(resources)
        token_cache = MagicMock()
        svc = ConsentVerificationService(router, token_cache)
        client_info = _make_client_info()
        audit = []

        app = _build_e2e_app(relay, store, svc, client_info, audit_events=audit)
        tc = TestClient(app, raise_server_exceptions=False)

        resp = _start_auth_and_callback(relay, tc)

        assert resp.status_code == 302
        assert "/oauth/consent-verify" in resp.headers["location"]
        cookie_header = resp.headers.get("set-cookie", "")
        assert "__okta_consent_session=" in cookie_header
        session_cookie = cookie_header.split("__okta_consent_session=")[1].split(";")[0]

        tx_id = parse_qs(urlparse(resp.headers["location"]).query)["tx"][0]
        tc.cookies.set("__okta_consent_session", session_cookie)

        # Allow async verify_all to complete
        time.sleep(0.15)

        # Poll status
        status_resp = tc.get(f"/oauth/consent-status?tx={tx_id}")
        assert status_resp.status_code == 200
        data = status_resp.json()
        assert data["status"] == "complete"
        assert len(data["connections"]) == 2

        # Complete
        complete_resp = tc.post(
            "/oauth/consent-complete", data={"tx": tx_id},
            follow_redirects=False,
        )
        assert complete_resp.status_code == 302
        location = complete_resp.headers["location"]
        assert location.startswith(REDIRECT_URI)
        gateway_code = parse_qs(urlparse(location).query)["code"][0]

        # Exchange
        token_resp = tc.post("/oauth2/v1/token", data={
            "grant_type": "authorization_code",
            "code": gateway_code,
            "client_id": CIMD_CLIENT_ID,
        })
        assert token_resp.status_code == 200
        assert token_resp.json()["access_token"] == "at_okta_xyz"

        # Verify tokens were cached
        assert token_cache.set_sts_token.call_count == 2


class TestE2EConsentRequired:
    @patch("okta_agent_proxy.auth.okta_sts_exchanger.OktaSTSTokenExchanger")
    def test_e2e_consent_required_then_recheck(self, MockExchanger):
        """consent_required → recheck → verified → complete."""
        call_count = [0]

        async def exchange_side_effect(*args, **kwargs):
            call_count[0] += 1
            if call_count[0] <= 1:
                return {"status": "consent_required", "interaction_uri": "https://okta/consent"}
            return {"status": "success", "access_token": "isv_tok", "expires_in": 3600}

        mock_instance = AsyncMock()
        mock_instance.exchange.side_effect = exchange_side_effect
        MockExchanger.return_value = mock_instance

        relay = ConfidentialRelay(
            gateway_base_url="http://localhost:8000",
            okta_domain="dev-test.okta.com",
            transport=_okta_mock_transport(),
        )
        store = ConsentTransactionStore()
        router = _make_router([_make_sts_resource("github")])
        token_cache = MagicMock()
        svc = ConsentVerificationService(router, token_cache)
        client_info = _make_client_info()

        app = _build_e2e_app(relay, store, svc, client_info)
        tc = TestClient(app, raise_server_exceptions=False)

        resp = _start_auth_and_callback(relay, tc)

        assert resp.status_code == 302
        tx_id = parse_qs(urlparse(resp.headers["location"]).query)["tx"][0]
        session_cookie = resp.headers.get("set-cookie", "").split("=")[1].split(";")[0]
        tc.cookies.set("__okta_consent_session", session_cookie)

        time.sleep(0.15)

        # Status should show consent_required
        status_resp = tc.get(f"/oauth/consent-status?tx={tx_id}")
        data = status_resp.json()
        assert data["status"] == "consents_required"
        assert data["connections"][0]["interaction_uri"] == "https://okta/consent"

        # Recheck
        recheck_resp = tc.post("/oauth/consent-recheck", data={"tx": tx_id})
        assert recheck_resp.status_code == 200
        assert recheck_resp.json()["status"] == "complete"

        # Complete
        complete_resp = tc.post(
            "/oauth/consent-complete", data={"tx": tx_id},
            follow_redirects=False,
        )
        assert complete_resp.status_code == 302
        gateway_code = parse_qs(urlparse(complete_resp.headers["location"]).query)["code"][0]

        token_resp = tc.post("/oauth2/v1/token", data={
            "grant_type": "authorization_code",
            "code": gateway_code,
            "client_id": CIMD_CLIENT_ID,
        })
        assert token_resp.status_code == 200


class TestE2ESkip:
    @patch("okta_agent_proxy.auth.okta_sts_exchanger.OktaSTSTokenExchanger")
    def test_e2e_skip_consents(self, MockExchanger):
        """Skip consents → complete → redirect → exchange."""
        mock_instance = AsyncMock()
        mock_instance.exchange.return_value = {
            "status": "consent_required",
            "interaction_uri": "https://okta/consent",
        }
        MockExchanger.return_value = mock_instance

        relay = ConfidentialRelay(
            gateway_base_url="http://localhost:8000",
            okta_domain="dev-test.okta.com",
            transport=_okta_mock_transport(),
        )
        store = ConsentTransactionStore()
        router = _make_router([_make_sts_resource("github")])
        token_cache = MagicMock()
        svc = ConsentVerificationService(router, token_cache)
        client_info = _make_client_info()

        app = _build_e2e_app(relay, store, svc, client_info)
        tc = TestClient(app, raise_server_exceptions=False)

        resp = _start_auth_and_callback(relay, tc)

        tx_id = parse_qs(urlparse(resp.headers["location"]).query)["tx"][0]
        session_cookie = resp.headers.get("set-cookie", "").split("=")[1].split(";")[0]
        tc.cookies.set("__okta_consent_session", session_cookie)
        time.sleep(0.15)

        # Skip
        skip_resp = tc.post("/oauth/consent-skip", data={"tx": tx_id})
        assert skip_resp.json()["status"] == "complete"

        # Complete
        complete_resp = tc.post(
            "/oauth/consent-complete", data={"tx": tx_id},
            follow_redirects=False,
        )
        assert complete_resp.status_code == 302
        gateway_code = parse_qs(urlparse(complete_resp.headers["location"]).query)["code"][0]

        token_resp = tc.post("/oauth2/v1/token", data={
            "grant_type": "authorization_code",
            "code": gateway_code,
            "client_id": CIMD_CLIENT_ID,
        })
        assert token_resp.status_code == 200


class TestE2ESessionSecurity:
    def test_e2e_expired_session(self):
        """Expired transaction → 403 on status poll."""
        store = ConsentTransactionStore()
        tx = store.create(
            original_redirect_uri=REDIRECT_URI,
            original_state="s",
            original_client_id=CIMD_CLIENT_ID,
            id_token="idt", access_token="at",
            ip_address="testclient",
            user_agent_hash=hashlib.sha256(b"testclient").hexdigest()[:16],
        )
        # Expire immediately
        tx.created_at = time.monotonic() - 700

        relay = ConfidentialRelay(gateway_base_url="http://localhost:8000", okta_domain="test.okta.com")
        svc = MagicMock()
        svc.get_sts_resources.return_value = []
        app = _build_e2e_app(relay, store, svc, MagicMock())
        tc = TestClient(app, raise_server_exceptions=False)
        tc.cookies.set("__okta_consent_session", tx.session_id)

        resp = tc.get(f"/oauth/consent-status?tx={tx.transaction_id}")
        # Expired tx gets removed by get_by_id, validate_session returns None → 403
        assert resp.status_code == 403

    def test_e2e_ip_mismatch_rejected(self):
        """IP mismatch → 403."""
        store = ConsentTransactionStore()
        tx = store.create(
            original_redirect_uri=REDIRECT_URI,
            original_state="s",
            original_client_id=CIMD_CLIENT_ID,
            id_token="idt", access_token="at",
            ip_address="1.2.3.4",
            user_agent_hash=hashlib.sha256(b"testclient").hexdigest()[:16],
        )

        relay = ConfidentialRelay(gateway_base_url="http://localhost:8000", okta_domain="test.okta.com")
        svc = MagicMock()
        svc.get_sts_resources.return_value = []
        app = _build_e2e_app(relay, store, svc, MagicMock())
        tc = TestClient(app, raise_server_exceptions=False)
        tc.cookies.set("__okta_consent_session", tx.session_id)

        # TestClient sends from "testclient" IP, tx expects "1.2.3.4"
        resp = tc.get(f"/oauth/consent-status?tx={tx.transaction_id}")
        assert resp.status_code == 403


class TestE2EGatewayCode:
    @patch("okta_agent_proxy.auth.okta_sts_exchanger.OktaSTSTokenExchanger")
    def test_e2e_gateway_code_one_time(self, MockExchanger):
        """Code can only be exchanged once."""
        mock_instance = AsyncMock()
        mock_instance.exchange.return_value = {"status": "success", "access_token": "isv", "expires_in": 3600}
        MockExchanger.return_value = mock_instance

        relay = ConfidentialRelay(
            gateway_base_url="http://localhost:8000",
            okta_domain="dev-test.okta.com",
            transport=_okta_mock_transport(),
        )
        store = ConsentTransactionStore()
        router = _make_router([_make_sts_resource("github")])
        token_cache = MagicMock()
        svc = ConsentVerificationService(router, token_cache)
        client_info = _make_client_info()

        app = _build_e2e_app(relay, store, svc, client_info)
        tc = TestClient(app, raise_server_exceptions=False)

        resp = _start_auth_and_callback(relay, tc)
        tx_id = parse_qs(urlparse(resp.headers["location"]).query)["tx"][0]
        session_cookie = resp.headers.get("set-cookie", "").split("=")[1].split(";")[0]
        tc.cookies.set("__okta_consent_session", session_cookie)
        time.sleep(0.15)

        complete_resp = tc.post("/oauth/consent-complete", data={"tx": tx_id}, follow_redirects=False)
        gateway_code = parse_qs(urlparse(complete_resp.headers["location"]).query)["code"][0]

        # First exchange works
        r1 = tc.post("/oauth2/v1/token", data={
            "grant_type": "authorization_code",
            "code": gateway_code,
            "client_id": CIMD_CLIENT_ID,
        })
        assert r1.status_code == 200

        # Replay fails
        r2 = tc.post("/oauth2/v1/token", data={
            "grant_type": "authorization_code",
            "code": gateway_code,
            "client_id": CIMD_CLIENT_ID,
        })
        assert r2.status_code == 400
        assert r2.json()["error"] == "invalid_grant"


class TestE2ETokenMapping:
    @patch("okta_agent_proxy.auth.okta_sts_exchanger.OktaSTSTokenExchanger")
    def test_e2e_token_mapping_captured(self, MockExchanger):
        """After full flow, capture_fn called with correct token mapping."""
        mock_instance = AsyncMock()
        mock_instance.exchange.return_value = {"status": "success", "access_token": "isv", "expires_in": 3600}
        MockExchanger.return_value = mock_instance

        relay = ConfidentialRelay(
            gateway_base_url="http://localhost:8000",
            okta_domain="dev-test.okta.com",
            transport=_okta_mock_transport(),
        )
        store = ConsentTransactionStore()
        router = _make_router([_make_sts_resource("github")])
        token_cache = MagicMock()
        svc = ConsentVerificationService(router, token_cache)
        client_info = _make_client_info()
        capture = MagicMock()

        app = _build_e2e_app(relay, store, svc, client_info, capture_fn=capture)
        tc = TestClient(app, raise_server_exceptions=False)

        resp = _start_auth_and_callback(relay, tc)
        tx_id = parse_qs(urlparse(resp.headers["location"]).query)["tx"][0]
        session_cookie = resp.headers.get("set-cookie", "").split("=")[1].split(";")[0]
        tc.cookies.set("__okta_consent_session", session_cookie)
        time.sleep(0.15)

        complete_resp = tc.post("/oauth/consent-complete", data={"tx": tx_id}, follow_redirects=False)
        gateway_code = parse_qs(urlparse(complete_resp.headers["location"]).query)["code"][0]

        tc.post("/oauth2/v1/token", data={
            "grant_type": "authorization_code",
            "code": gateway_code,
            "client_id": CIMD_CLIENT_ID,
        })

        capture.assert_called_once_with(
            "at_okta_xyz", "idt_okta_xyz", "rt_okta_xyz", CIMD_CLIENT_ID, 3600,
        )


class TestE2EAuditEvents:
    @patch("okta_agent_proxy.auth.okta_sts_exchanger.OktaSTSTokenExchanger")
    def test_e2e_audit_events(self, MockExchanger):
        """Full flow emits expected audit events."""
        mock_instance = AsyncMock()
        mock_instance.exchange.return_value = {"status": "success", "access_token": "isv", "expires_in": 3600}
        MockExchanger.return_value = mock_instance

        relay = ConfidentialRelay(
            gateway_base_url="http://localhost:8000",
            okta_domain="dev-test.okta.com",
            transport=_okta_mock_transport(),
        )
        store = ConsentTransactionStore()
        router = _make_router([_make_sts_resource("github")])
        token_cache = MagicMock()
        svc = ConsentVerificationService(router, token_cache)
        client_info = _make_client_info()
        audit = []

        app = _build_e2e_app(relay, store, svc, client_info, audit_events=audit)
        tc = TestClient(app, raise_server_exceptions=False)

        resp = _start_auth_and_callback(relay, tc)
        tx_id = parse_qs(urlparse(resp.headers["location"]).query)["tx"][0]
        session_cookie = resp.headers.get("set-cookie", "").split("=")[1].split(";")[0]
        tc.cookies.set("__okta_consent_session", session_cookie)
        time.sleep(0.15)

        tc.post("/oauth/consent-complete", data={"tx": tx_id}, follow_redirects=False)

        event_types = [e["event_type"] for e in audit]
        assert "sts.consent.tx.created" in event_types
        assert "sts.consent.tx.completed" in event_types
