"""Integration tests for credential automation — end-to-end flows with real config store."""

import json
import logging
from unittest.mock import AsyncMock, MagicMock, patch

import httpx
import pytest
from jose import jwt as jose_jwt
from starlette.applications import Starlette
from starlette.routing import Route
from starlette.testclient import TestClient

from okta_agent_proxy.okta_admin.client import OktaAPIClient
from okta_agent_proxy.okta_admin.exceptions import (
    OktaAdminAPIError,
    OktaAdminAuthError,
    OktaAdminForbiddenError,
)
from okta_agent_proxy.okta_admin.service import CredentialAutomationService
from okta_agent_proxy.admin import credential_routes as cr_module

FAKE_TOKEN = "integration-admin-token"
OKTA_AGENT_ID = "agtINTEG123"
APP_ID = "0oaINTEGApp"


def _make_response(json_body, status_code=200):
    return httpx.Response(
        status_code=status_code,
        json=json_body,
        request=httpx.Request("GET", "https://dev.okta.com"),
    )


def _mock_api_client():
    client = MagicMock(spec=OktaAPIClient)
    client.get = AsyncMock()
    client.post = AsyncMock()
    return client


def _mock_store(agent_data=None):
    """Build a mock config store for HTTP route tests."""
    store = MagicMock()
    store.get_agent.return_value = agent_data
    store.update_agent.return_value = True
    return store


def _agent_data(**overrides):
    base = {
        "agent_id": "test-agent",
        "agent_name": "test-agent",
        "client_id": "0oaTestClient",
        "client_secret": None,
        "private_key": None,
        "okta_ai_agent_id": OKTA_AGENT_ID,
        "enabled": True,
    }
    base.update(overrides)
    return base


def _build_app(service):
    cr_module.wire_credential_routes(service)
    return Starlette(routes=[
        Route("/api/admin/agents/{agent_id}/credentials/fetch-secret", cr_module.fetch_secret, methods=["POST"]),
        Route("/api/admin/agents/{agent_id}/credentials/generate-keypair", cr_module.generate_keypair, methods=["POST"]),
        Route("/api/admin/agents/{agent_id}/credentials/status", cr_module.credential_status, methods=["GET"]),
    ])


@pytest.fixture
def mock_admin_auth():
    async def _valid(token):
        return {"username": "admin-integ", "role": "admin", "token_type": "okta_oauth"}
    with patch("okta_agent_proxy.admin.middleware.verify_okta_token", _valid):
        yield


# ── Full flow: create agent → set okta_agent_id → fetch secret ──────────

@pytest.mark.asyncio
async def test_full_flow_fetch_secret(postgres_store):
    """Create agent, set okta_agent_id, fetch secret, verify config store updated."""
    api = _mock_api_client()

    postgres_store.create_agent("flow-agent", {
        "agent_id": "flow-agent",
        "client_id": "0oaFlowClient",
        "private_key": json.dumps({"kty": "RSA", "n": "test", "e": "AQAB"}),
        "okta_ai_agent_id": OKTA_AGENT_ID,
    }, user="test")

    svc = CredentialAutomationService(api, postgres_store)

    api.get.side_effect = [
        _make_response({"credentials": {"oauthClient": {"client_id": APP_ID}}}),
        _make_response([{
            "id": "s1", "status": "ACTIVE",
            "client_secret": "real-secret-from-okta",
            "created": "2026-03-01T00:00:00Z",
        }]),
    ]

    result = await svc.fetch_client_secret("flow-agent", FAKE_TOKEN)
    assert result["status"] == "success"
    assert result["source"] == "fetched_existing"

    agent = postgres_store.get_agent("flow-agent", enabled_only=False)
    assert agent["client_secret"] == "real-secret-from-okta"


# ── Full flow: create agent → generate key → verify JWT signature ───────

@pytest.mark.asyncio
async def test_full_flow_generate_key_produces_valid_jwt(postgres_store):
    """Generate key pair, store private key, verify it can sign valid JWTs."""
    api = _mock_api_client()

    postgres_store.create_agent("key-agent", {
        "agent_id": "key-agent",
        "client_id": "0oaKeyClient",
        "private_key": json.dumps({"kty": "RSA", "n": "placeholder", "e": "AQAB"}),
        "okta_ai_agent_id": OKTA_AGENT_ID,
    }, user="test")

    svc = CredentialAutomationService(api, postgres_store)
    api.post.return_value = _make_response({"status": "ACTIVE"})

    result = await svc.generate_key_pair("key-agent", FAKE_TOKEN)
    assert result["status"] == "success"
    kid = result["kid"]

    agent = postgres_store.get_agent("key-agent", enabled_only=False)
    stored_jwk = json.loads(agent["private_key"])
    assert stored_jwk["kid"] == kid
    assert "d" in stored_jwk

    # Verify the stored key can produce valid JWT signatures
    token = jose_jwt.encode(
        {"sub": "key-agent", "iss": "test"},
        stored_jwk,
        algorithm="RS256",
        headers={"kid": kid},
    )
    pub_jwk = {k: v for k, v in stored_jwk.items() if k not in ("d", "p", "q", "dp", "dq", "qi")}
    claims = jose_jwt.decode(token, pub_jwk, algorithms=["RS256"], options={"verify_aud": False})
    assert claims["sub"] == "key-agent"


# ── Full flow: fetch secret + generate key → both configured ────────────

@pytest.mark.asyncio
async def test_full_flow_both_credentials(postgres_store):
    """Fetch secret then generate key, verify both are configured."""
    api = _mock_api_client()

    postgres_store.create_agent("both-agent", {
        "agent_id": "both-agent",
        "client_id": "0oaBothClient",
        "private_key": json.dumps({"kty": "RSA", "n": "placeholder", "e": "AQAB"}),
        "okta_ai_agent_id": OKTA_AGENT_ID,
    }, user="test")

    svc = CredentialAutomationService(api, postgres_store)

    # Fetch secret
    api.get.side_effect = [
        _make_response({"credentials": {"oauthClient": {"client_id": APP_ID}}}),
        _make_response([{"id": "s1", "status": "ACTIVE", "client_secret": "sec-val", "created": "2026-01-01T00:00:00Z"}]),
    ]
    await svc.fetch_client_secret("both-agent", FAKE_TOKEN)

    # Generate key
    api.get.side_effect = None
    api.post.return_value = _make_response({"status": "ACTIVE"})
    await svc.generate_key_pair("both-agent", FAKE_TOKEN)

    # Check status
    api.get.return_value = _make_response([])
    status = await svc.get_credential_status("both-agent", FAKE_TOKEN)
    assert status["has_client_secret"] is True
    assert status["has_private_key"] is True


# ── Credential status reflects actual state ──────────────────────────────

@pytest.mark.asyncio
async def test_status_reflects_state_before_and_after(postgres_store):
    api = _mock_api_client()

    postgres_store.create_agent("status-agent", {
        "agent_id": "status-agent",
        "client_id": "0oaStatusClient",
        "private_key": json.dumps({"kty": "RSA", "n": "x", "e": "AQAB"}),
        "okta_ai_agent_id": OKTA_AGENT_ID,
    }, user="test")

    svc = CredentialAutomationService(api, postgres_store)
    api.get.return_value = _make_response([])

    status = await svc.get_credential_status("status-agent", FAKE_TOKEN)
    assert status["has_client_secret"] is False

    postgres_store.update_agent("status-agent", {"client_secret": "a-secret"}, user="test")

    status = await svc.get_credential_status("status-agent", FAKE_TOKEN)
    assert status["has_client_secret"] is True


# ── Encrypted storage: private key in DB is encrypted ────────────────────

@pytest.mark.asyncio
async def test_private_key_stored_encrypted(postgres_store):
    """Verify that update_agent encrypts the private key (not plaintext in DB)."""
    api = _mock_api_client()

    postgres_store.create_agent("enc-agent", {
        "agent_id": "enc-agent",
        "client_id": "0oaEncClient",
        "private_key": json.dumps({"kty": "RSA", "n": "placeholder", "e": "AQAB"}),
        "okta_ai_agent_id": OKTA_AGENT_ID,
    }, user="test")

    svc = CredentialAutomationService(api, postgres_store)
    api.post.return_value = _make_response({"status": "ACTIVE"})

    result = await svc.generate_key_pair("enc-agent", FAKE_TOKEN)
    assert result["status"] == "success"

    agent = postgres_store.get_agent("enc-agent", enabled_only=False)
    priv = json.loads(agent["private_key"])
    assert priv["kid"] == result["kid"]
    assert "d" in priv


# ── Agent without okta_agent_id returns clear error ──────────────────────

@pytest.mark.asyncio
async def test_no_okta_agent_id_returns_error(postgres_store):
    api = _mock_api_client()

    postgres_store.create_agent("noid-agent", {
        "agent_id": "noid-agent",
        "client_id": "0oaNoIdClient",
        "private_key": json.dumps({"kty": "RSA", "n": "x", "e": "AQAB"}),
    }, user="test")

    svc = CredentialAutomationService(api, postgres_store)

    result = await svc.fetch_client_secret("noid-agent", FAKE_TOKEN)
    assert result["status"] == "error"
    assert "Okta AI Agent ID" in result["message"]

    result = await svc.generate_key_pair("noid-agent", FAKE_TOKEN)
    assert result["status"] == "error"
    assert "Okta AI Agent ID" in result["message"]


# ── Secrets never in logs during integration flow ────────────────────────

@pytest.mark.asyncio
async def test_secrets_not_in_logs_integration(postgres_store, caplog):
    api = _mock_api_client()

    postgres_store.create_agent("log-agent", {
        "agent_id": "log-agent",
        "client_id": "0oaLogClient",
        "private_key": json.dumps({"kty": "RSA", "n": "placeholder", "e": "AQAB"}),
        "okta_ai_agent_id": OKTA_AGENT_ID,
    }, user="test")

    svc = CredentialAutomationService(api, postgres_store)

    api.get.side_effect = [
        _make_response({"credentials": {"oauthClient": {"client_id": APP_ID}}}),
        _make_response([{"id": "s1", "status": "ACTIVE", "client_secret": "TOP-SECRET-XYZ", "created": "2026-01-01T00:00:00Z"}]),
    ]

    with caplog.at_level(logging.DEBUG):
        await svc.fetch_client_secret("log-agent", FAKE_TOKEN)

    for record in caplog.records:
        msg = record.getMessage()
        assert "TOP-SECRET-XYZ" not in msg
        assert FAKE_TOKEN not in msg


# ══════════════════════════════════════════════════════════════════════════
# HTTP route tests — use mock config store (avoids DB fixture ordering)
# ══════════════════════════════════════════════════════════════════════════

def test_token_passthrough_via_http(mock_admin_auth):
    """Verify admin token from HTTP request reaches Okta API mock."""
    api = _mock_api_client()
    store = _mock_store(_agent_data())
    svc = CredentialAutomationService(api, store)
    app = _build_app(svc)
    client = TestClient(app)

    api.post.return_value = _make_response({"status": "ACTIVE"})

    client.post(
        "/api/admin/agents/test-agent/credentials/generate-keypair",
        headers={"Authorization": f"Bearer {FAKE_TOKEN}"},
    )

    assert api.post.called
    call_token = api.post.call_args[0][1]
    assert call_token == FAKE_TOKEN


def test_okta_401_propagates_as_401(mock_admin_auth):
    api = _mock_api_client()
    store = _mock_store(_agent_data())
    svc = CredentialAutomationService(api, store)
    app = _build_app(svc)
    client = TestClient(app)

    api.get.side_effect = OktaAdminAuthError("token expired")

    resp = client.post(
        "/api/admin/agents/test-agent/credentials/fetch-secret",
        headers={"Authorization": f"Bearer {FAKE_TOKEN}"},
    )
    assert resp.status_code == 401


def test_okta_403_propagates_as_403(mock_admin_auth):
    api = _mock_api_client()
    store = _mock_store(_agent_data())
    svc = CredentialAutomationService(api, store)
    app = _build_app(svc)
    client = TestClient(app)

    api.post.side_effect = OktaAdminForbiddenError("insufficient scope")

    resp = client.post(
        "/api/admin/agents/test-agent/credentials/generate-keypair",
        headers={"Authorization": f"Bearer {FAKE_TOKEN}"},
    )
    assert resp.status_code == 403
    assert "okta.aiAgents.manage" in resp.json()["message"]


def test_http_404_for_unknown_agent(mock_admin_auth):
    api = _mock_api_client()
    store = _mock_store(None)  # agent not found
    svc = CredentialAutomationService(api, store)
    app = _build_app(svc)
    client = TestClient(app)

    resp = client.post(
        "/api/admin/agents/nonexistent/credentials/fetch-secret",
        headers={"Authorization": f"Bearer {FAKE_TOKEN}"},
    )
    assert resp.status_code == 404


def test_http_400_for_no_okta_agent_id(mock_admin_auth):
    api = _mock_api_client()
    store = _mock_store(_agent_data(okta_ai_agent_id=None))
    svc = CredentialAutomationService(api, store)
    app = _build_app(svc)
    client = TestClient(app)

    resp = client.post(
        "/api/admin/agents/test-agent/credentials/fetch-secret",
        headers={"Authorization": f"Bearer {FAKE_TOKEN}"},
    )
    assert resp.status_code == 400


def test_status_endpoint_http(mock_admin_auth):
    api = _mock_api_client()
    store = _mock_store(_agent_data(
        client_secret="enc-secret",
        private_key='{"kty":"RSA"}',
    ))
    svc = CredentialAutomationService(api, store)
    app = _build_app(svc)
    client = TestClient(app)

    api.get.return_value = _make_response([{"kid": "k1", "alg": "RS256"}])

    resp = client.get(
        "/api/admin/agents/test-agent/credentials/status",
        headers={"Authorization": f"Bearer {FAKE_TOKEN}"},
    )
    assert resp.status_code == 200
    body = resp.json()
    assert body["has_client_secret"] is True
    assert body["has_private_key"] is True
    assert body["registered_keys"][0]["kid"] == "k1"
    assert "enc-secret" not in json.dumps(body)


def test_okta_api_error_becomes_502(mock_admin_auth):
    api = _mock_api_client()
    store = _mock_store(_agent_data())
    svc = CredentialAutomationService(api, store)
    app = _build_app(svc)
    client = TestClient(app)

    api.get.side_effect = OktaAdminAPIError("Okta down", status_code=503, error_description="service unavailable")

    resp = client.post(
        "/api/admin/agents/test-agent/credentials/fetch-secret",
        headers={"Authorization": f"Bearer {FAKE_TOKEN}"},
    )
    assert resp.status_code == 502
