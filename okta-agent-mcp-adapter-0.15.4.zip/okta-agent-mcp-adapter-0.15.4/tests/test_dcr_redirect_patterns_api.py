"""Tests for DCR redirect patterns admin API endpoints.

Validates:
- GET /api/admin/dcr/policy/redirect-patterns
- PUT /api/admin/dcr/policy/redirect-patterns
- Auth requirements, validation, persistence, cache invalidation, pub/sub, audit
"""

import json
import sys
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from okta_agent_proxy.audit.events import AuditEventType
from okta_agent_proxy.auth.dcr_policy import (
    DEFAULT_REDIRECT_PATTERNS,
    GATEWAY_CONFIG_KEY_REDIRECT_PATTERNS,
)
from okta_agent_proxy.cache.pubsub import CHANNEL_DCR_PATTERNS_INVALIDATE


# ---------------------------------------------------------------------------
# App import helper (same pattern as test_dcr_admin_routes.py)
# ---------------------------------------------------------------------------

def _ensure_app_imported():
    mod = sys.modules.get("okta_agent_proxy.app")
    if mod is not None and hasattr(mod, "client_registry"):
        return

    sys.modules.pop("okta_agent_proxy.app", None)

    import okta_agent_proxy.database as _db_mod
    _orig_get = _db_mod.get_config_store
    _orig_store = _db_mod._config_store
    _mock_store = MagicMock()
    _mock_store.get_all_resources.return_value = []
    _mock_store.get_all_agents.return_value = []
    _db_mod.get_config_store = lambda **kw: _mock_store
    _db_mod._config_store = _mock_store
    try:
        import importlib
        import okta_agent_proxy.app
        importlib.reload(okta_agent_proxy.app)
    except Exception:
        sys.modules.pop("okta_agent_proxy.app", None)
        raise
    finally:
        _db_mod.get_config_store = _orig_get
        _db_mod._config_store = _orig_store


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

class _FakeStore:
    """Minimal dict-backed store for testing."""

    def __init__(self):
        self._data = {}
        self._meta = {}

    def get_gateway_config(self, key):
        return self._data.get(key)

    def get_gateway_config_entry(self, key):
        if key not in self._data:
            return None
        return {
            "value": self._data[key],
            "updated_at": self._meta.get(key, {}).get("updated_at"),
            "updated_by": self._meta.get(key, {}).get("updated_by"),
        }

    def set_gateway_config(self, key, value, user="admin", **kwargs):
        self._data[key] = value
        self._meta[key] = {"updated_at": "2026-04-09T12:00:00", "updated_by": user}


def _mock_request(body=None, admin_user="admin"):
    """Build a mock Starlette Request with admin auth."""
    req = MagicMock()
    req.state = MagicMock()
    req.state.admin_payload = {"username": admin_user}
    req.client = MagicMock()
    req.client.host = "127.0.0.1"
    req.headers = {"user-agent": "test-agent"}

    async def _json():
        return body

    req.json = _json
    return req


def _mock_request_no_auth():
    """Build a mock request without admin auth."""
    req = MagicMock()
    req.method = "PUT"
    req.url = MagicMock()
    req.url.path = "/api/admin/dcr/policy/redirect-patterns"
    req.headers = {"authorization": ""}
    req.state = MagicMock(spec=[])
    return req


# ---------------------------------------------------------------------------
# GET tests
# ---------------------------------------------------------------------------

class TestGetDCRRedirectPatterns:

    @pytest.fixture(autouse=True)
    def setup(self):
        _ensure_app_imported()

    @patch("okta_agent_proxy.admin.dcr_routes.get_store")
    async def test_get_no_stored_value_returns_defaults(self, mock_get_store):
        """GET returns source=default and seed defaults when store is empty."""
        store = _FakeStore()
        mock_get_store.return_value = store

        from okta_agent_proxy.admin.dcr_routes import get_dcr_redirect_patterns
        req = _mock_request()
        resp = await get_dcr_redirect_patterns.__wrapped__(req)

        assert resp.status_code == 200
        body = json.loads(resp.body)
        assert body["source"] == "default"
        assert body["patterns"] == list(DEFAULT_REDIRECT_PATTERNS)
        assert body["updated_at"] is None
        assert body["updated_by"] is None

    @patch("okta_agent_proxy.admin.dcr_routes.get_store")
    async def test_get_stored_value_returns_database(self, mock_get_store):
        """GET returns source=database after PUT has stored patterns."""
        store = _FakeStore()
        store.set_gateway_config(
            GATEWAY_CONFIG_KEY_REDIRECT_PATTERNS,
            ["https://myapp.example.com/callback"],
            user="admin-user",
        )
        mock_get_store.return_value = store

        from okta_agent_proxy.admin.dcr_routes import get_dcr_redirect_patterns
        req = _mock_request()
        resp = await get_dcr_redirect_patterns.__wrapped__(req)

        assert resp.status_code == 200
        body = json.loads(resp.body)
        assert body["source"] == "database"
        assert body["patterns"] == ["https://myapp.example.com/callback"]
        assert body["updated_by"] == "admin-user"


# ---------------------------------------------------------------------------
# PUT tests
# ---------------------------------------------------------------------------

class TestUpdateDCRRedirectPatterns:

    @pytest.fixture(autouse=True)
    def setup(self):
        _ensure_app_imported()

    @patch("okta_agent_proxy.admin.dcr_routes.emit_audit_event", new_callable=AsyncMock)
    @patch("okta_agent_proxy.admin.dcr_routes.get_store")
    async def test_put_valid_patterns_persists(self, mock_get_store, mock_audit):
        """PUT with valid patterns persists and subsequent GET returns them."""
        store = _FakeStore()
        mock_get_store.return_value = store

        mock_policy = MagicMock()
        mock_bus = MagicMock()
        mock_bus.publish = AsyncMock()

        from okta_agent_proxy.admin.dcr_routes import update_dcr_redirect_patterns

        with patch("okta_agent_proxy.app.get_dcr_policy", return_value=mock_policy):
            with patch("okta_agent_proxy.app.get_event_bus", return_value=mock_bus):
                req = _mock_request(body={"patterns": ["http://localhost:*/callback"]})
                resp = await update_dcr_redirect_patterns.__wrapped__(req)

        assert resp.status_code == 200
        body = json.loads(resp.body)
        assert body["source"] == "database"
        assert body["patterns"] == ["http://localhost:*/callback"]

        # Verify persisted
        assert store.get_gateway_config(GATEWAY_CONFIG_KEY_REDIRECT_PATTERNS) == [
            "http://localhost:*/callback"
        ]

    @patch("okta_agent_proxy.admin.dcr_routes.emit_audit_event", new_callable=AsyncMock)
    @patch("okta_agent_proxy.admin.dcr_routes.get_store")
    async def test_put_invalid_pattern_returns_400(self, mock_get_store, mock_audit):
        """PUT with an invalid pattern returns 400 and does not persist."""
        store = _FakeStore()
        mock_get_store.return_value = store

        from okta_agent_proxy.admin.dcr_routes import update_dcr_redirect_patterns
        req = _mock_request(body={"patterns": ["javascript:alert(1)"]})
        resp = await update_dcr_redirect_patterns.__wrapped__(req)

        assert resp.status_code == 400
        body = json.loads(resp.body)
        assert body["error"] == "invalid_pattern"
        # Nothing persisted
        assert store.get_gateway_config(GATEWAY_CONFIG_KEY_REDIRECT_PATTERNS) is None

    async def test_put_without_auth_returns_401(self):
        """PUT without admin auth returns 401."""
        from okta_agent_proxy.admin.dcr_routes import update_dcr_redirect_patterns

        with patch("okta_agent_proxy.admin.dcr_routes.get_store"):
            with patch("okta_agent_proxy.admin.middleware.require_admin_token", new_callable=AsyncMock, return_value=None):
                req = _mock_request_no_auth()
                resp = await update_dcr_redirect_patterns(req)

        assert resp.status_code == 401

    @patch("okta_agent_proxy.admin.dcr_routes.emit_audit_event", new_callable=AsyncMock)
    @patch("okta_agent_proxy.admin.dcr_routes.get_store")
    async def test_put_non_list_body_returns_400(self, mock_get_store, mock_audit):
        """PUT with non-list patterns returns 400."""
        mock_get_store.return_value = _FakeStore()

        from okta_agent_proxy.admin.dcr_routes import update_dcr_redirect_patterns
        req = _mock_request(body={"patterns": "not-a-list"})
        resp = await update_dcr_redirect_patterns.__wrapped__(req)

        assert resp.status_code == 400
        body = json.loads(resp.body)
        assert "list" in body["message"].lower()

    @patch("okta_agent_proxy.admin.dcr_routes.emit_audit_event", new_callable=AsyncMock)
    @patch("okta_agent_proxy.admin.dcr_routes.get_store")
    async def test_put_over_50_patterns_returns_400(self, mock_get_store, mock_audit):
        """PUT with more than 50 patterns returns 400."""
        mock_get_store.return_value = _FakeStore()

        patterns = [f"http://localhost:{i}/callback" for i in range(51)]
        from okta_agent_proxy.admin.dcr_routes import update_dcr_redirect_patterns
        req = _mock_request(body={"patterns": patterns})
        resp = await update_dcr_redirect_patterns.__wrapped__(req)

        assert resp.status_code == 400
        body = json.loads(resp.body)
        assert "50" in body["message"]

    @patch("okta_agent_proxy.admin.dcr_routes.emit_audit_event", new_callable=AsyncMock)
    @patch("okta_agent_proxy.admin.dcr_routes.get_store")
    async def test_put_emits_audit_event(self, mock_get_store, mock_audit):
        """PUT emits DCR_REDIRECT_PATTERNS_UPDATED audit event."""
        store = _FakeStore()
        mock_get_store.return_value = store

        mock_policy = MagicMock()
        mock_bus = MagicMock()
        mock_bus.publish = AsyncMock()

        from okta_agent_proxy.admin.dcr_routes import update_dcr_redirect_patterns

        with patch("okta_agent_proxy.app.get_dcr_policy", return_value=mock_policy):
            with patch("okta_agent_proxy.app.get_event_bus", return_value=mock_bus):
                req = _mock_request(
                    body={"patterns": ["http://localhost:*/callback"]},
                    admin_user="test-admin",
                )
                resp = await update_dcr_redirect_patterns.__wrapped__(req)

        assert resp.status_code == 200
        mock_audit.assert_awaited_once()
        call_args = mock_audit.call_args
        assert call_args[0][0] == AuditEventType.DCR_REDIRECT_PATTERNS_UPDATED
        assert call_args[1]["details"]["user"] == "test-admin"
        assert call_args[1]["details"]["pattern_count"] == 1

    @patch("okta_agent_proxy.admin.dcr_routes.emit_audit_event", new_callable=AsyncMock)
    @patch("okta_agent_proxy.admin.dcr_routes.get_store")
    async def test_put_invalidates_local_cache(self, mock_get_store, mock_audit):
        """PUT calls invalidate_pattern_cache on the DCRPolicy."""
        store = _FakeStore()
        mock_get_store.return_value = store

        mock_policy = MagicMock()
        mock_bus = MagicMock()
        mock_bus.publish = AsyncMock()

        from okta_agent_proxy.admin.dcr_routes import update_dcr_redirect_patterns

        with patch("okta_agent_proxy.app.get_dcr_policy", return_value=mock_policy):
            with patch("okta_agent_proxy.app.get_event_bus", return_value=mock_bus):
                req = _mock_request(body={"patterns": ["http://localhost:*/callback"]})
                await update_dcr_redirect_patterns.__wrapped__(req)

        mock_policy.invalidate_pattern_cache.assert_called_once()

    @patch("okta_agent_proxy.admin.dcr_routes.emit_audit_event", new_callable=AsyncMock)
    @patch("okta_agent_proxy.admin.dcr_routes.get_store")
    async def test_put_publishes_invalidation_event(self, mock_get_store, mock_audit):
        """PUT publishes invalidation event to event bus."""
        store = _FakeStore()
        mock_get_store.return_value = store

        mock_policy = MagicMock()
        mock_bus = MagicMock()
        mock_bus.publish = AsyncMock()

        from okta_agent_proxy.admin.dcr_routes import update_dcr_redirect_patterns

        with patch("okta_agent_proxy.app.get_dcr_policy", return_value=mock_policy):
            with patch("okta_agent_proxy.app.get_event_bus", return_value=mock_bus):
                req = _mock_request(
                    body={"patterns": ["http://localhost:*/callback"]},
                    admin_user="pub-admin",
                )
                await update_dcr_redirect_patterns.__wrapped__(req)

        mock_bus.publish.assert_awaited_once()
        call_args = mock_bus.publish.call_args
        assert call_args[0][0] == CHANNEL_DCR_PATTERNS_INVALIDATE
        payload = json.loads(call_args[0][1])
        assert payload["user"] == "pub-admin"
        assert "ts" in payload

    @patch("okta_agent_proxy.admin.dcr_routes.emit_audit_event", new_callable=AsyncMock)
    @patch("okta_agent_proxy.admin.dcr_routes.get_store")
    async def test_put_succeeds_even_if_publish_raises(self, mock_get_store, mock_audit):
        """PUT returns 200 even if event bus publish raises."""
        store = _FakeStore()
        mock_get_store.return_value = store

        mock_policy = MagicMock()
        mock_bus = MagicMock()
        mock_bus.publish = AsyncMock(side_effect=RuntimeError("Redis down"))

        from okta_agent_proxy.admin.dcr_routes import update_dcr_redirect_patterns

        with patch("okta_agent_proxy.app.get_dcr_policy", return_value=mock_policy):
            with patch("okta_agent_proxy.app.get_event_bus", return_value=mock_bus):
                req = _mock_request(body={"patterns": ["http://localhost:*/callback"]})
                resp = await update_dcr_redirect_patterns.__wrapped__(req)

        assert resp.status_code == 200
        # Audit event should still be emitted
        mock_audit.assert_awaited_once()
