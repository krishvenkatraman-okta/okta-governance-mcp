"""Tests for OktaAIAgentClient."""

import json
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from okta_agent_proxy.auth.okta_ai_agent_client import OktaAIAgentClient
from okta_agent_proxy.auth.okta_service_auth import OktaServiceAuth


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _mock_response(status_code=200, json_data=None, text="", headers=None):
    resp = MagicMock()
    resp.status_code = status_code
    resp.json.return_value = json_data if json_data is not None else {}
    resp.text = text or json.dumps(json_data or {})
    resp.headers = headers or {}
    return resp


def _make_client(monkeypatch, service_token="svc_tok_123"):
    """Create an OktaAIAgentClient with mocked service auth."""
    monkeypatch.setenv("OKTA_DOMAIN", "dev-test.okta.com")
    monkeypatch.delenv("OKTA_AI_AGENT_ID", raising=False)

    mock_service = AsyncMock(spec=OktaServiceAuth)
    mock_service.get_access_token = AsyncMock(return_value=service_token)
    return OktaAIAgentClient(service_auth=mock_service)


# ---------------------------------------------------------------------------
# Auth header construction
# ---------------------------------------------------------------------------

class TestAuthHeaders:
    """_get_auth_headers picks the right token source."""

    @pytest.mark.asyncio
    async def test_forwarded_user_token(self, monkeypatch):
        client = _make_client(monkeypatch)
        headers = await client._get_auth_headers(okta_token="user_tok_abc")
        assert headers["Authorization"] == "Bearer user_tok_abc"

    @pytest.mark.asyncio
    async def test_service_token_fallback(self, monkeypatch):
        client = _make_client(monkeypatch, service_token="svc_tok_xyz")
        headers = await client._get_auth_headers()
        assert headers["Authorization"] == "Bearer svc_tok_xyz"

    @pytest.mark.asyncio
    async def test_no_auth_available(self, monkeypatch):
        client = _make_client(monkeypatch, service_token=None)
        headers = await client._get_auth_headers()
        assert "Authorization" not in headers

    @pytest.mark.asyncio
    async def test_agent_id_header(self, monkeypatch):
        client = _make_client(monkeypatch)
        monkeypatch.setenv("OKTA_AI_AGENT_ID", "agt_12345")
        headers = await client._get_auth_headers()
        assert headers["X-Okta-Agent-Id"] == "agt_12345"

    @pytest.mark.asyncio
    async def test_no_agent_id_header(self, monkeypatch):
        monkeypatch.delenv("OKTA_AI_AGENT_ID", raising=False)
        client = _make_client(monkeypatch)
        headers = await client._get_auth_headers()
        assert "X-Okta-Agent-Id" not in headers


# ---------------------------------------------------------------------------
# list_agents
# ---------------------------------------------------------------------------

class TestListAgents:
    """list_agents returns agents and handles pagination."""

    @pytest.mark.asyncio
    async def test_list_agents_success(self, monkeypatch):
        client = _make_client(monkeypatch)
        agents_data = [{"id": "agt1", "name": "Agent 1"}, {"id": "agt2", "name": "Agent 2"}]
        resp = _mock_response(200, agents_data)

        mock_http = AsyncMock()
        mock_http.get = AsyncMock(return_value=resp)
        mock_http.__aenter__ = AsyncMock(return_value=mock_http)
        mock_http.__aexit__ = AsyncMock(return_value=False)

        with patch("okta_agent_proxy.auth.okta_ai_agent_client.httpx") as mock_httpx:
            mock_httpx.AsyncClient.return_value = mock_http
            result = await client.list_agents(okta_token="tok")

        assert len(result) == 2
        assert result[0]["id"] == "agt1"

    @pytest.mark.asyncio
    async def test_list_agents_pagination(self, monkeypatch):
        client = _make_client(monkeypatch)

        page1 = [{"id": "agt1"}]
        page2 = [{"id": "agt2"}]
        resp1 = _mock_response(
            200, page1,
            headers={"Link": '<https://dev-test.okta.com/next?after=x>; rel="next"'},
        )
        resp2 = _mock_response(200, page2)

        mock_http = AsyncMock()
        mock_http.get = AsyncMock(side_effect=[resp1, resp2])
        mock_http.__aenter__ = AsyncMock(return_value=mock_http)
        mock_http.__aexit__ = AsyncMock(return_value=False)

        with patch("okta_agent_proxy.auth.okta_ai_agent_client.httpx") as mock_httpx:
            mock_httpx.AsyncClient.return_value = mock_http
            result = await client.list_agents()

        assert len(result) == 2
        assert result[0]["id"] == "agt1"
        assert result[1]["id"] == "agt2"
        assert mock_http.get.call_count == 2

    @pytest.mark.asyncio
    async def test_list_agents_error(self, monkeypatch):
        client = _make_client(monkeypatch)
        resp = _mock_response(500, text="Internal Server Error")

        mock_http = AsyncMock()
        mock_http.get = AsyncMock(return_value=resp)
        mock_http.__aenter__ = AsyncMock(return_value=mock_http)
        mock_http.__aexit__ = AsyncMock(return_value=False)

        with patch("okta_agent_proxy.auth.okta_ai_agent_client.httpx") as mock_httpx:
            mock_httpx.AsyncClient.return_value = mock_http
            result = await client.list_agents()

        assert result == []

    @pytest.mark.asyncio
    async def test_list_agents_no_domain(self, monkeypatch):
        monkeypatch.delenv("OKTA_DOMAIN", raising=False)
        mock_service = AsyncMock(spec=OktaServiceAuth)
        client = OktaAIAgentClient(service_auth=mock_service)
        result = await client.list_agents()
        assert result == []


# ---------------------------------------------------------------------------
# get_agent
# ---------------------------------------------------------------------------

class TestGetAgent:
    """get_agent returns agent dict or None."""

    @pytest.mark.asyncio
    async def test_get_agent_200(self, monkeypatch):
        client = _make_client(monkeypatch)
        agent_data = {"id": "agt1", "name": "Test Agent", "status": "ACTIVE"}
        resp = _mock_response(200, agent_data)

        mock_http = AsyncMock()
        mock_http.get = AsyncMock(return_value=resp)
        mock_http.__aenter__ = AsyncMock(return_value=mock_http)
        mock_http.__aexit__ = AsyncMock(return_value=False)

        with patch("okta_agent_proxy.auth.okta_ai_agent_client.httpx") as mock_httpx:
            mock_httpx.AsyncClient.return_value = mock_http
            result = await client.get_agent("agt1")

        assert result is not None
        assert result["id"] == "agt1"
        # Verify URL
        call_url = mock_http.get.call_args[0][0]
        assert call_url.endswith("/workload-principals/api/v1/ai-agents/agt1")

    @pytest.mark.asyncio
    async def test_get_agent_404(self, monkeypatch):
        client = _make_client(monkeypatch)
        resp = _mock_response(404)

        mock_http = AsyncMock()
        mock_http.get = AsyncMock(return_value=resp)
        mock_http.__aenter__ = AsyncMock(return_value=mock_http)
        mock_http.__aexit__ = AsyncMock(return_value=False)

        with patch("okta_agent_proxy.auth.okta_ai_agent_client.httpx") as mock_httpx:
            mock_httpx.AsyncClient.return_value = mock_http
            result = await client.get_agent("nonexistent")

        assert result is None

    @pytest.mark.asyncio
    async def test_get_agent_network_error(self, monkeypatch):
        client = _make_client(monkeypatch)

        mock_http = AsyncMock()
        mock_http.get = AsyncMock(side_effect=Exception("Connection timeout"))
        mock_http.__aenter__ = AsyncMock(return_value=mock_http)
        mock_http.__aexit__ = AsyncMock(return_value=False)

        with patch("okta_agent_proxy.auth.okta_ai_agent_client.httpx") as mock_httpx:
            mock_httpx.AsyncClient.return_value = mock_http
            result = await client.get_agent("agt1")

        assert result is None


# ---------------------------------------------------------------------------
# get_agent_credentials
# ---------------------------------------------------------------------------

class TestGetAgentCredentials:
    @pytest.mark.asyncio
    async def test_credentials_success(self, monkeypatch):
        client = _make_client(monkeypatch)
        jwks = {"keys": [{"kty": "RSA", "kid": "key1", "n": "abc", "e": "AQAB"}]}
        resp = _mock_response(200, jwks)

        mock_http = AsyncMock()
        mock_http.get = AsyncMock(return_value=resp)
        mock_http.__aenter__ = AsyncMock(return_value=mock_http)
        mock_http.__aexit__ = AsyncMock(return_value=False)

        with patch("okta_agent_proxy.auth.okta_ai_agent_client.httpx") as mock_httpx:
            mock_httpx.AsyncClient.return_value = mock_http
            result = await client.get_agent_credentials("agt1")

        assert len(result) == 1
        assert result[0]["kid"] == "key1"

    @pytest.mark.asyncio
    async def test_credentials_error(self, monkeypatch):
        client = _make_client(monkeypatch)
        resp = _mock_response(403)

        mock_http = AsyncMock()
        mock_http.get = AsyncMock(return_value=resp)
        mock_http.__aenter__ = AsyncMock(return_value=mock_http)
        mock_http.__aexit__ = AsyncMock(return_value=False)

        with patch("okta_agent_proxy.auth.okta_ai_agent_client.httpx") as mock_httpx:
            mock_httpx.AsyncClient.return_value = mock_http
            result = await client.get_agent_credentials("agt1")

        assert result == []


# ---------------------------------------------------------------------------
# get_agent_connections
# ---------------------------------------------------------------------------

class TestGetAgentConnections:
    @pytest.mark.asyncio
    async def test_connections_success(self, monkeypatch):
        client = _make_client(monkeypatch)
        conns = [{"id": "conn1", "authServerId": "aus123"}]
        resp = _mock_response(200, conns)

        mock_http = AsyncMock()
        mock_http.get = AsyncMock(return_value=resp)
        mock_http.__aenter__ = AsyncMock(return_value=mock_http)
        mock_http.__aexit__ = AsyncMock(return_value=False)

        with patch("okta_agent_proxy.auth.okta_ai_agent_client.httpx") as mock_httpx:
            mock_httpx.AsyncClient.return_value = mock_http
            result = await client.get_agent_connections("agt1")

        assert len(result) == 1
        assert result[0]["authServerId"] == "aus123"


# ---------------------------------------------------------------------------
# get_linked_app
# ---------------------------------------------------------------------------

class TestGetLinkedApp:
    @pytest.mark.asyncio
    async def test_get_app_success(self, monkeypatch):
        client = _make_client(monkeypatch)
        app_data = {"id": "0oa123", "label": "My App", "status": "ACTIVE"}
        resp = _mock_response(200, app_data)

        mock_http = AsyncMock()
        mock_http.get = AsyncMock(return_value=resp)
        mock_http.__aenter__ = AsyncMock(return_value=mock_http)
        mock_http.__aexit__ = AsyncMock(return_value=False)

        with patch("okta_agent_proxy.auth.okta_ai_agent_client.httpx") as mock_httpx:
            mock_httpx.AsyncClient.return_value = mock_http
            result = await client.get_linked_app("0oa123")

        assert result is not None
        assert result["label"] == "My App"

    @pytest.mark.asyncio
    async def test_get_app_404(self, monkeypatch):
        client = _make_client(monkeypatch)
        resp = _mock_response(404)

        mock_http = AsyncMock()
        mock_http.get = AsyncMock(return_value=resp)
        mock_http.__aenter__ = AsyncMock(return_value=mock_http)
        mock_http.__aexit__ = AsyncMock(return_value=False)

        with patch("okta_agent_proxy.auth.okta_ai_agent_client.httpx") as mock_httpx:
            mock_httpx.AsyncClient.return_value = mock_http
            result = await client.get_linked_app("0oa_nonexistent")

        assert result is None


# ---------------------------------------------------------------------------
# get_org_info
# ---------------------------------------------------------------------------

class TestGetOrgInfo:
    @pytest.mark.asyncio
    async def test_org_info_success(self, monkeypatch):
        client = _make_client(monkeypatch)
        org_data = {"id": "00o123", "pipeline": "idx"}
        resp = _mock_response(200, org_data)

        mock_http = AsyncMock()
        mock_http.get = AsyncMock(return_value=resp)
        mock_http.__aenter__ = AsyncMock(return_value=mock_http)
        mock_http.__aexit__ = AsyncMock(return_value=False)

        with patch("okta_agent_proxy.auth.okta_ai_agent_client.httpx") as mock_httpx:
            mock_httpx.AsyncClient.return_value = mock_http
            result = await client.get_org_info()

        assert result["id"] == "00o123"

    @pytest.mark.asyncio
    async def test_org_info_error(self, monkeypatch):
        client = _make_client(monkeypatch)
        resp = _mock_response(500)

        mock_http = AsyncMock()
        mock_http.get = AsyncMock(return_value=resp)
        mock_http.__aenter__ = AsyncMock(return_value=mock_http)
        mock_http.__aexit__ = AsyncMock(return_value=False)

        with patch("okta_agent_proxy.auth.okta_ai_agent_client.httpx") as mock_httpx:
            mock_httpx.AsyncClient.return_value = mock_http
            result = await client.get_org_info()

        assert result == {}


# ---------------------------------------------------------------------------
# check_token_scopes
# ---------------------------------------------------------------------------

class TestCheckTokenScopes:
    """check_token_scopes returns scope status for the given token."""

    @pytest.mark.asyncio
    async def test_200_has_scopes(self, monkeypatch):
        client = _make_client(monkeypatch)
        resp = _mock_response(200, [])

        mock_http = AsyncMock()
        mock_http.get = AsyncMock(return_value=resp)
        mock_http.__aenter__ = AsyncMock(return_value=mock_http)
        mock_http.__aexit__ = AsyncMock(return_value=False)

        with patch("okta_agent_proxy.auth.okta_ai_agent_client.httpx") as mock_httpx:
            mock_httpx.AsyncClient.return_value = mock_http
            result = await client.check_token_scopes("valid_token")

        assert result["has_ai_agent_scopes"] is True

    @pytest.mark.asyncio
    async def test_403_missing_scopes(self, monkeypatch):
        client = _make_client(monkeypatch)
        resp = _mock_response(403)

        mock_http = AsyncMock()
        mock_http.get = AsyncMock(return_value=resp)
        mock_http.__aenter__ = AsyncMock(return_value=mock_http)
        mock_http.__aexit__ = AsyncMock(return_value=False)

        with patch("okta_agent_proxy.auth.okta_ai_agent_client.httpx") as mock_httpx:
            mock_httpx.AsyncClient.return_value = mock_http
            result = await client.check_token_scopes("no_scope_token")

        assert result["has_ai_agent_scopes"] is False
        assert "okta.aiAgents.read" in result["error"]

    @pytest.mark.asyncio
    async def test_401_expired_token(self, monkeypatch):
        client = _make_client(monkeypatch)
        resp = _mock_response(401)

        mock_http = AsyncMock()
        mock_http.get = AsyncMock(return_value=resp)
        mock_http.__aenter__ = AsyncMock(return_value=mock_http)
        mock_http.__aexit__ = AsyncMock(return_value=False)

        with patch("okta_agent_proxy.auth.okta_ai_agent_client.httpx") as mock_httpx:
            mock_httpx.AsyncClient.return_value = mock_http
            result = await client.check_token_scopes("expired_token")

        assert result["has_ai_agent_scopes"] is False
        assert "expired" in result["error"].lower() or "invalid" in result["error"].lower()

    @pytest.mark.asyncio
    async def test_no_domain(self, monkeypatch):
        monkeypatch.delenv("OKTA_DOMAIN", raising=False)
        mock_service = AsyncMock(spec=OktaServiceAuth)
        client = OktaAIAgentClient(service_auth=mock_service)
        result = await client.check_token_scopes("any_token")
        assert result["has_ai_agent_scopes"] is False
        assert "OKTA_DOMAIN" in result["error"]

    @pytest.mark.asyncio
    async def test_network_error(self, monkeypatch):
        client = _make_client(monkeypatch)

        mock_http = AsyncMock()
        mock_http.get = AsyncMock(side_effect=Exception("DNS resolution failed"))
        mock_http.__aenter__ = AsyncMock(return_value=mock_http)
        mock_http.__aexit__ = AsyncMock(return_value=False)

        with patch("okta_agent_proxy.auth.okta_ai_agent_client.httpx") as mock_httpx:
            mock_httpx.AsyncClient.return_value = mock_http
            result = await client.check_token_scopes("any_token")

        assert result["has_ai_agent_scopes"] is False
        assert "DNS" in result["error"]


# ---------------------------------------------------------------------------
# Link header parsing
# ---------------------------------------------------------------------------

class TestParseLinkHeader:
    """_parse_next_link extracts rel=next URL."""

    def test_single_next_link(self):
        header = '<https://okta.com/api?after=abc>; rel="next"'
        assert OktaAIAgentClient._parse_next_link(header) == "https://okta.com/api?after=abc"

    def test_multiple_links(self):
        header = (
            '<https://okta.com/api?after=abc>; rel="next", '
            '<https://okta.com/api>; rel="self"'
        )
        assert OktaAIAgentClient._parse_next_link(header) == "https://okta.com/api?after=abc"

    def test_no_next_link(self):
        header = '<https://okta.com/api>; rel="self"'
        assert OktaAIAgentClient._parse_next_link(header) is None

    def test_none_header(self):
        assert OktaAIAgentClient._parse_next_link(None) is None

    def test_empty_header(self):
        assert OktaAIAgentClient._parse_next_link("") is None
