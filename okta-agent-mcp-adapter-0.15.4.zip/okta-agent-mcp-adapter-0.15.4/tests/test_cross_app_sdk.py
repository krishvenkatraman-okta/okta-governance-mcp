"""
Tests for OktaCrossAppAccessManager using the official okta-client-python SDK.

Covers:
- Constructor creates OAuth2Client with correct configuration
- _get_or_create_flow creates CrossAppAccessFlow with correct target
- exchange_id_token_to_mcp_token with mocked CrossAppAccessFlow
- Flow cache invalidation after each exchange
- apply_scope_condition for all scope condition types
- Gateway key fallback when agent has no private key
- principal_id required (ValueError on missing)
- Private key parsing (JSON string and dict)
- Error handling when flow.start() or flow.resume() raises
- Credential source verification (DB vs env vars)
"""

import pytest
import os
import json
from unittest.mock import patch, MagicMock, AsyncMock, PropertyMock


SAMPLE_JWK = {
    "kty": "RSA",
    "n": "test-n-value",
    "e": "AQAB",
    "d": "test-d-value",
    "kid": "test-key-1",
    "use": "sig",
    "alg": "RS256",
}

SAMPLE_JWK_STR = json.dumps(SAMPLE_JWK)


@pytest.fixture(autouse=True)
def clean_env(monkeypatch):
    """Ensure env vars don't leak between tests."""
    monkeypatch.delenv("OKTA_AI_AGENT_ID", raising=False)
    monkeypatch.delenv("OKTA_AI_AGENT_PRIVATE_KEY", raising=False)
    monkeypatch.delenv("OKTA_AI_AGENT_CLIENT_ID", raising=False)
    monkeypatch.setenv("OKTA_DOMAIN", "dev-test.okta.com")


# ---------------------------------------------------------------------------
# Patching helpers
# ---------------------------------------------------------------------------

def _patch_sdk():
    """Return a dict of patches for all SDK classes."""
    return {
        "OAuth2Client": patch("okta_agent_proxy.auth.cross_app_access.OAuth2Client"),
        "OAuth2ClientConfiguration": patch("okta_agent_proxy.auth.cross_app_access.OAuth2ClientConfiguration"),
        "ClientAssertionAuthorization": patch("okta_agent_proxy.auth.cross_app_access.ClientAssertionAuthorization"),
        "JWTBearerClaims": patch("okta_agent_proxy.auth.cross_app_access.JWTBearerClaims"),
        "LocalKeyProvider": patch("okta_agent_proxy.auth.cross_app_access.LocalKeyProvider"),
        "CrossAppAccessFlow": patch("okta_agent_proxy.auth.cross_app_access.CrossAppAccessFlow"),
        "CrossAppAccessTarget": patch("okta_agent_proxy.auth.cross_app_access.CrossAppAccessTarget"),
    }


def _create_manager(patches, **kwargs):
    """Create an OktaCrossAppAccessManager with all SDK classes patched."""
    from okta_agent_proxy.auth.cross_app_access import OktaCrossAppAccessManager

    defaults = {
        "agent_id": "claude-code",
        "client_id": "0oaXXXX",
        "agent_private_key": SAMPLE_JWK_STR,
        "okta_domain": "dev-test.okta.com",
        "target_auth_server_id": "ausXXXX",
        "principal_id": "agt1234567890",
    }
    defaults.update(kwargs)
    return OktaCrossAppAccessManager(**defaults)


# ============================================================================
# Constructor tests
# ============================================================================

class TestConstructor:

    def test_creates_oauth2_client(self):
        """Constructor creates OAuth2Client with correct configuration."""
        with patch("okta_agent_proxy.auth.cross_app_access.OAuth2Client") as mock_client, \
             patch("okta_agent_proxy.auth.cross_app_access.OAuth2ClientConfiguration") as mock_config, \
             patch("okta_agent_proxy.auth.cross_app_access.ClientAssertionAuthorization") as mock_auth, \
             patch("okta_agent_proxy.auth.cross_app_access.JWTBearerClaims") as mock_claims, \
             patch("okta_agent_proxy.auth.cross_app_access.LocalKeyProvider") as mock_kp:
            from okta_agent_proxy.auth.cross_app_access import OktaCrossAppAccessManager

            manager = OktaCrossAppAccessManager(
                agent_id="claude-code",
                client_id="0oaXXXX",
                agent_private_key=SAMPLE_JWK_STR,
                okta_domain="dev-test.okta.com",
                target_auth_server_id="ausXXXX",
                principal_id="agt1234567890",
            )

            mock_client.assert_called_once()
            assert mock_client.call_args.kwargs["configuration"] == mock_config.return_value

    def test_creates_local_key_provider_with_parsed_jwk(self):
        """LocalKeyProvider receives the parsed JWK dict, not the raw JSON string."""
        with patch("okta_agent_proxy.auth.cross_app_access.OAuth2Client"), \
             patch("okta_agent_proxy.auth.cross_app_access.OAuth2ClientConfiguration"), \
             patch("okta_agent_proxy.auth.cross_app_access.ClientAssertionAuthorization"), \
             patch("okta_agent_proxy.auth.cross_app_access.JWTBearerClaims"), \
             patch("okta_agent_proxy.auth.cross_app_access.LocalKeyProvider") as mock_kp:
            from okta_agent_proxy.auth.cross_app_access import OktaCrossAppAccessManager

            OktaCrossAppAccessManager(
                agent_id="claude-code",
                client_id="0oaXXXX",
                agent_private_key=SAMPLE_JWK_STR,
                okta_domain="dev-test.okta.com",
                target_auth_server_id="ausXXXX",
                principal_id="agt123",
            )

            kp_call = mock_kp.call_args
            assert kp_call.kwargs["key"] == SAMPLE_JWK  # parsed dict, not string
            assert kp_call.kwargs["algorithm"] == "RS256"
            assert kp_call.kwargs["key_id"] == "test-key-1"

    def test_creates_jwt_bearer_claims_with_principal_id(self):
        """JWTBearerClaims uses principal_id as issuer and subject."""
        with patch("okta_agent_proxy.auth.cross_app_access.OAuth2Client"), \
             patch("okta_agent_proxy.auth.cross_app_access.OAuth2ClientConfiguration"), \
             patch("okta_agent_proxy.auth.cross_app_access.ClientAssertionAuthorization"), \
             patch("okta_agent_proxy.auth.cross_app_access.JWTBearerClaims") as mock_claims, \
             patch("okta_agent_proxy.auth.cross_app_access.LocalKeyProvider"):
            from okta_agent_proxy.auth.cross_app_access import OktaCrossAppAccessManager

            OktaCrossAppAccessManager(
                agent_id="claude-code",
                client_id="0oaXXXX",
                agent_private_key=SAMPLE_JWK_STR,
                okta_domain="dev-test.okta.com",
                target_auth_server_id="ausXXXX",
                principal_id="agt1234567890",
            )

            claims_call = mock_claims.call_args
            assert claims_call.kwargs["issuer"] == "agt1234567890"
            assert claims_call.kwargs["subject"] == "agt1234567890"
            assert claims_call.kwargs["audience"] == "https://dev-test.okta.com/oauth2/v1/token"
            assert claims_call.kwargs["expires_in"] == 300

    def test_private_key_as_json_string(self):
        """Constructor parses private key from JSON string (DB format)."""
        with patch("okta_agent_proxy.auth.cross_app_access.OAuth2Client"), \
             patch("okta_agent_proxy.auth.cross_app_access.OAuth2ClientConfiguration"), \
             patch("okta_agent_proxy.auth.cross_app_access.ClientAssertionAuthorization"), \
             patch("okta_agent_proxy.auth.cross_app_access.JWTBearerClaims"), \
             patch("okta_agent_proxy.auth.cross_app_access.LocalKeyProvider"):
            from okta_agent_proxy.auth.cross_app_access import OktaCrossAppAccessManager

            manager = OktaCrossAppAccessManager(
                agent_id="test",
                client_id="0oaXXXX",
                agent_private_key=SAMPLE_JWK_STR,
                okta_domain="dev-test.okta.com",
                target_auth_server_id="ausXXXX",
                principal_id="agt123",
            )

            assert manager.agent_private_key == SAMPLE_JWK
            assert isinstance(manager.agent_private_key, dict)

    def test_private_key_as_dict(self):
        """Constructor accepts private key as dict (already parsed)."""
        with patch("okta_agent_proxy.auth.cross_app_access.OAuth2Client"), \
             patch("okta_agent_proxy.auth.cross_app_access.OAuth2ClientConfiguration"), \
             patch("okta_agent_proxy.auth.cross_app_access.ClientAssertionAuthorization"), \
             patch("okta_agent_proxy.auth.cross_app_access.JWTBearerClaims"), \
             patch("okta_agent_proxy.auth.cross_app_access.LocalKeyProvider"):
            from okta_agent_proxy.auth.cross_app_access import OktaCrossAppAccessManager

            manager = OktaCrossAppAccessManager(
                agent_id="test",
                client_id="0oaXXXX",
                agent_private_key=SAMPLE_JWK,
                okta_domain="dev-test.okta.com",
                target_auth_server_id="ausXXXX",
                principal_id="agt123",
            )

            assert manager.agent_private_key == SAMPLE_JWK

    def test_principal_id_required(self):
        """Missing principal_id raises ValueError."""
        from okta_agent_proxy.auth.cross_app_access import OktaCrossAppAccessManager

        with pytest.raises(ValueError, match="principal_id is required"):
            OktaCrossAppAccessManager(
                agent_id="test",
                client_id="0oaXXXX",
                agent_private_key=SAMPLE_JWK_STR,
                okta_domain="dev-test.okta.com",
                target_auth_server_id="ausXXXX",
                principal_id=None,
            )

    def test_okta_domain_required(self, monkeypatch):
        """Missing OKTA_DOMAIN raises ValueError."""
        monkeypatch.delenv("OKTA_DOMAIN", raising=False)

        from okta_agent_proxy.auth.cross_app_access import OktaCrossAppAccessManager

        with pytest.raises(ValueError, match="OKTA_DOMAIN"):
            OktaCrossAppAccessManager(
                agent_id="test",
                client_id="0oaXXXX",
                agent_private_key=SAMPLE_JWK_STR,
                okta_domain=None,
                target_auth_server_id="ausXXXX",
                principal_id="agt123",
            )

    def test_domain_normalization_https(self):
        """Bare domain is normalized to https://."""
        with patch("okta_agent_proxy.auth.cross_app_access.OAuth2Client"), \
             patch("okta_agent_proxy.auth.cross_app_access.OAuth2ClientConfiguration"), \
             patch("okta_agent_proxy.auth.cross_app_access.ClientAssertionAuthorization"), \
             patch("okta_agent_proxy.auth.cross_app_access.JWTBearerClaims"), \
             patch("okta_agent_proxy.auth.cross_app_access.LocalKeyProvider"):
            from okta_agent_proxy.auth.cross_app_access import OktaCrossAppAccessManager

            manager = OktaCrossAppAccessManager(
                agent_id="test",
                client_id="0oaXXXX",
                agent_private_key=SAMPLE_JWK_STR,
                okta_domain="dev-test.okta.com",
                target_auth_server_id="ausXXXX",
                principal_id="agt123",
            )

            assert manager.okta_domain == "https://dev-test.okta.com"

    def test_domain_normalization_http_to_https(self):
        """http:// domain is converted to https://."""
        with patch("okta_agent_proxy.auth.cross_app_access.OAuth2Client"), \
             patch("okta_agent_proxy.auth.cross_app_access.OAuth2ClientConfiguration"), \
             patch("okta_agent_proxy.auth.cross_app_access.ClientAssertionAuthorization"), \
             patch("okta_agent_proxy.auth.cross_app_access.JWTBearerClaims"), \
             patch("okta_agent_proxy.auth.cross_app_access.LocalKeyProvider"):
            from okta_agent_proxy.auth.cross_app_access import OktaCrossAppAccessManager

            manager = OktaCrossAppAccessManager(
                agent_id="test",
                client_id="0oaXXXX",
                agent_private_key=SAMPLE_JWK_STR,
                okta_domain="http://dev-test.okta.com",
                target_auth_server_id="ausXXXX",
                principal_id="agt123",
            )

            assert manager.okta_domain == "https://dev-test.okta.com"

    def test_disabled_when_credentials_missing(self):
        """Manager disables exchange when credentials are incomplete."""
        with patch("okta_agent_proxy.auth.cross_app_access.AdapterCIMDServer", side_effect=Exception("no key")):
            from okta_agent_proxy.auth.cross_app_access import OktaCrossAppAccessManager

            manager = OktaCrossAppAccessManager(
                agent_id="test",
                client_id="0oaXXXX",
                agent_private_key=None,
                okta_domain="dev-test.okta.com",
                target_auth_server_id="ausXXXX",
                principal_id="agt123",
            )

            assert manager._oauth2_client is None
            assert manager._flow_cache == {}


# ============================================================================
# Credential source tests
# ============================================================================

class TestCredentialSources:

    def test_no_env_calls_when_agent_has_real_key(self, monkeypatch):
        """When agent has a real private key, no OKTA_AI_AGENT_* env vars are read."""
        env_calls = []
        original_getenv = os.getenv

        def tracking_getenv(key, default=None):
            if key.startswith("OKTA_AI_AGENT_"):
                env_calls.append(key)
            return original_getenv(key, default)

        with patch("okta_agent_proxy.auth.cross_app_access.OAuth2Client"), \
             patch("okta_agent_proxy.auth.cross_app_access.OAuth2ClientConfiguration"), \
             patch("okta_agent_proxy.auth.cross_app_access.ClientAssertionAuthorization"), \
             patch("okta_agent_proxy.auth.cross_app_access.JWTBearerClaims"), \
             patch("okta_agent_proxy.auth.cross_app_access.LocalKeyProvider"), \
             patch("os.getenv", side_effect=tracking_getenv):
            from okta_agent_proxy.auth.cross_app_access import OktaCrossAppAccessManager

            OktaCrossAppAccessManager(
                agent_id="test",
                client_id="0oaXXXX",
                agent_private_key=SAMPLE_JWK_STR,
                okta_domain="dev-test.okta.com",
                target_auth_server_id="ausXXXX",
                principal_id="agt123",
            )

        # _resolve_gateway_credentials() should NOT have been called
        assert len(env_calls) == 0

    def test_resolve_gateway_credentials_called_for_placeholder(self, monkeypatch):
        """_resolve_gateway_credentials() is called when key is PLACEHOLDER."""
        monkeypatch.setenv("OKTA_AI_AGENT_PRIVATE_KEY", SAMPLE_JWK_STR)
        monkeypatch.setenv("OKTA_AI_AGENT_CLIENT_ID", "0oaGateway")
        monkeypatch.setenv("OKTA_AI_AGENT_ID", "agtGateway")

        with patch("okta_agent_proxy.auth.cross_app_access.OAuth2Client"), \
             patch("okta_agent_proxy.auth.cross_app_access.OAuth2ClientConfiguration"), \
             patch("okta_agent_proxy.auth.cross_app_access.ClientAssertionAuthorization"), \
             patch("okta_agent_proxy.auth.cross_app_access.JWTBearerClaims"), \
             patch("okta_agent_proxy.auth.cross_app_access.LocalKeyProvider"):
            from okta_agent_proxy.auth.cross_app_access import OktaCrossAppAccessManager

            manager = OktaCrossAppAccessManager(
                agent_id="some-agent",
                client_id="0oaOldClient",
                agent_private_key="PLACEHOLDER",
                okta_domain="dev-test.okta.com",
                target_auth_server_id="ausXXXX",
                principal_id="agt123",
            )

        assert manager._using_gateway_key is True
        assert manager.client_id == "0oaGateway"
        assert manager.principal_id == "agtGateway"
        assert manager.agent_id == "agtGateway"

    def test_gateway_credentials_override_client_and_principal(self, monkeypatch):
        """Gateway fallback overrides client_id, agent_id, and principal_id."""
        monkeypatch.setenv("OKTA_AI_AGENT_PRIVATE_KEY", SAMPLE_JWK_STR)
        monkeypatch.setenv("OKTA_AI_AGENT_CLIENT_ID", "0oaGW")
        monkeypatch.setenv("OKTA_AI_AGENT_ID", "agtGW")

        with patch("okta_agent_proxy.auth.cross_app_access.OAuth2Client"), \
             patch("okta_agent_proxy.auth.cross_app_access.OAuth2ClientConfiguration"), \
             patch("okta_agent_proxy.auth.cross_app_access.ClientAssertionAuthorization"), \
             patch("okta_agent_proxy.auth.cross_app_access.JWTBearerClaims"), \
             patch("okta_agent_proxy.auth.cross_app_access.LocalKeyProvider"):
            from okta_agent_proxy.auth.cross_app_access import OktaCrossAppAccessManager

            manager = OktaCrossAppAccessManager(
                agent_id="original-agent",
                client_id="0oaOriginal",
                agent_private_key=None,
                okta_domain="dev-test.okta.com",
                target_auth_server_id="ausXXXX",
                principal_id="agtOriginal",
            )

        assert manager.client_id == "0oaGW"
        assert manager.agent_id == "agtGW"
        assert manager.principal_id == "agtGW"


# ============================================================================
# Flow creation tests
# ============================================================================

class TestFlowCreation:

    def test_get_or_create_flow_creates_correct_target(self):
        """_get_or_create_flow creates CrossAppAccessTarget with correct issuer."""
        with patch("okta_agent_proxy.auth.cross_app_access.OAuth2Client"), \
             patch("okta_agent_proxy.auth.cross_app_access.OAuth2ClientConfiguration"), \
             patch("okta_agent_proxy.auth.cross_app_access.ClientAssertionAuthorization"), \
             patch("okta_agent_proxy.auth.cross_app_access.JWTBearerClaims"), \
             patch("okta_agent_proxy.auth.cross_app_access.LocalKeyProvider"), \
             patch("okta_agent_proxy.auth.cross_app_access.CrossAppAccessTarget") as mock_target, \
             patch("okta_agent_proxy.auth.cross_app_access.CrossAppAccessFlow") as mock_flow:
            from okta_agent_proxy.auth.cross_app_access import OktaCrossAppAccessManager

            manager = OktaCrossAppAccessManager(
                agent_id="test",
                client_id="0oaXXXX",
                agent_private_key=SAMPLE_JWK_STR,
                okta_domain="dev-test.okta.com",
                target_auth_server_id="ausXXXX",
                principal_id="agt123",
            )

            flow = manager._get_or_create_flow("my-resource", "aus1234")
            mock_target.assert_called_once_with(issuer="https://dev-test.okta.com/oauth2/aus1234")
            mock_flow.assert_called_once()

    def test_get_or_create_flow_caches(self):
        """Flow is cached by resource:auth_server key."""
        with patch("okta_agent_proxy.auth.cross_app_access.OAuth2Client"), \
             patch("okta_agent_proxy.auth.cross_app_access.OAuth2ClientConfiguration"), \
             patch("okta_agent_proxy.auth.cross_app_access.ClientAssertionAuthorization"), \
             patch("okta_agent_proxy.auth.cross_app_access.JWTBearerClaims"), \
             patch("okta_agent_proxy.auth.cross_app_access.LocalKeyProvider"), \
             patch("okta_agent_proxy.auth.cross_app_access.CrossAppAccessTarget"), \
             patch("okta_agent_proxy.auth.cross_app_access.CrossAppAccessFlow") as mock_flow:
            from okta_agent_proxy.auth.cross_app_access import OktaCrossAppAccessManager

            manager = OktaCrossAppAccessManager(
                agent_id="test",
                client_id="0oaXXXX",
                agent_private_key=SAMPLE_JWK_STR,
                okta_domain="dev-test.okta.com",
                target_auth_server_id="ausXXXX",
                principal_id="agt123",
            )

            flow1 = manager._get_or_create_flow("test-resource", "aus1234")
            flow2 = manager._get_or_create_flow("test-resource", "aus1234")
            assert flow1 is flow2
            assert mock_flow.call_count == 1

    def test_get_or_create_flow_extracts_auth_server_from_url(self):
        """Full URL auth server ID is extracted correctly."""
        with patch("okta_agent_proxy.auth.cross_app_access.OAuth2Client"), \
             patch("okta_agent_proxy.auth.cross_app_access.OAuth2ClientConfiguration"), \
             patch("okta_agent_proxy.auth.cross_app_access.ClientAssertionAuthorization"), \
             patch("okta_agent_proxy.auth.cross_app_access.JWTBearerClaims"), \
             patch("okta_agent_proxy.auth.cross_app_access.LocalKeyProvider"), \
             patch("okta_agent_proxy.auth.cross_app_access.CrossAppAccessTarget") as mock_target, \
             patch("okta_agent_proxy.auth.cross_app_access.CrossAppAccessFlow"):
            from okta_agent_proxy.auth.cross_app_access import OktaCrossAppAccessManager

            manager = OktaCrossAppAccessManager(
                agent_id="test",
                client_id="0oaXXXX",
                agent_private_key=SAMPLE_JWK_STR,
                okta_domain="dev-test.okta.com",
                target_auth_server_id="ausXXXX",
                principal_id="agt123",
            )

            manager._get_or_create_flow("test-resource", "https://dev-test.okta.com/oauth2/aus5678")
            mock_target.assert_called_once_with(issuer="https://dev-test.okta.com/oauth2/aus5678")

    def test_flow_returns_none_when_disabled(self):
        """_get_or_create_flow returns None when OAuth2Client is not configured."""
        with patch("okta_agent_proxy.auth.cross_app_access.AdapterCIMDServer", side_effect=Exception("no key")):
            from okta_agent_proxy.auth.cross_app_access import OktaCrossAppAccessManager

            manager = OktaCrossAppAccessManager(
                agent_id="test",
                client_id="0oaXXXX",
                agent_private_key=None,
                okta_domain="dev-test.okta.com",
                target_auth_server_id="ausXXXX",
                principal_id="agt123",
            )

            assert manager._get_or_create_flow("test-resource", "aus1234") is None


# ============================================================================
# Token exchange tests
# ============================================================================

class TestTokenExchange:

    @pytest.mark.asyncio
    async def test_exchange_success(self):
        """Successful token exchange returns access_token dict."""
        with patch("okta_agent_proxy.auth.cross_app_access.OAuth2Client"), \
             patch("okta_agent_proxy.auth.cross_app_access.OAuth2ClientConfiguration"), \
             patch("okta_agent_proxy.auth.cross_app_access.ClientAssertionAuthorization"), \
             patch("okta_agent_proxy.auth.cross_app_access.JWTBearerClaims"), \
             patch("okta_agent_proxy.auth.cross_app_access.LocalKeyProvider"), \
             patch("okta_agent_proxy.auth.cross_app_access.CrossAppAccessTarget"), \
             patch("okta_agent_proxy.auth.cross_app_access.CrossAppAccessFlow") as mock_flow_cls:
            from okta_agent_proxy.auth.cross_app_access import OktaCrossAppAccessManager

            # Configure mock flow
            mock_flow = MagicMock()
            mock_flow.start = AsyncMock(return_value=MagicMock(resume_assertion_claims=None))
            mock_flow.context.id_jag_token.expires_in = 300
            mock_flow.context.id_jag_token.access_token = "id-jag-token-xxx"

            mock_resource_result = MagicMock()
            mock_resource_result.access_token = "resource-access-token-xxx"
            mock_resource_result.token_type = "Bearer"
            mock_resource_result.expires_in = 3600
            mock_resource_result.scope = "mcp:read"
            mock_flow.resume = AsyncMock(return_value=mock_resource_result)

            mock_flow_cls.return_value = mock_flow

            manager = OktaCrossAppAccessManager(
                agent_id="test",
                client_id="0oaXXXX",
                agent_private_key=SAMPLE_JWK_STR,
                okta_domain="dev-test.okta.com",
                target_auth_server_id="ausXXXX",
                principal_id="agt123",
            )

            result = await manager.exchange_id_token_to_mcp_token(
                user_id_token="user-id-token",
                resource_name="my-resource",
                target_auth_server_id="aus1234",
                scopes=["mcp:read"],
            )

            assert result is not None
            assert result["access_token"] == "resource-access-token-xxx"
            assert result["token_type"] == "Bearer"
            assert result["expires_in"] == 3600
            assert result["scope"] == "mcp:read"

            mock_flow.start.assert_called_once_with(token="user-id-token", scope=["mcp:read"])
            mock_flow.resume.assert_called_once()

    @pytest.mark.asyncio
    async def test_flow_cache_invalidated_after_exchange(self):
        """Flow is removed from cache after successful exchange."""
        with patch("okta_agent_proxy.auth.cross_app_access.OAuth2Client"), \
             patch("okta_agent_proxy.auth.cross_app_access.OAuth2ClientConfiguration"), \
             patch("okta_agent_proxy.auth.cross_app_access.ClientAssertionAuthorization"), \
             patch("okta_agent_proxy.auth.cross_app_access.JWTBearerClaims"), \
             patch("okta_agent_proxy.auth.cross_app_access.LocalKeyProvider"), \
             patch("okta_agent_proxy.auth.cross_app_access.CrossAppAccessTarget"), \
             patch("okta_agent_proxy.auth.cross_app_access.CrossAppAccessFlow") as mock_flow_cls:
            from okta_agent_proxy.auth.cross_app_access import OktaCrossAppAccessManager

            mock_flow = MagicMock()
            mock_flow.start = AsyncMock(return_value=MagicMock())
            mock_flow.context.id_jag_token.expires_in = 300
            mock_flow.resume = AsyncMock(return_value=MagicMock(
                access_token="token", expires_in=3600, token_type="Bearer", scope="mcp:read"
            ))
            mock_flow_cls.return_value = mock_flow

            manager = OktaCrossAppAccessManager(
                agent_id="test",
                client_id="0oaXXXX",
                agent_private_key=SAMPLE_JWK_STR,
                okta_domain="dev-test.okta.com",
                target_auth_server_id="ausXXXX",
                principal_id="agt123",
            )

            await manager.exchange_id_token_to_mcp_token(
                user_id_token="token",
                resource_name="test-resource",
                target_auth_server_id="aus1234",
            )

            # Flow cache should be empty after exchange
            assert "test-resource:aus1234" not in manager._flow_cache

    @pytest.mark.asyncio
    async def test_exchange_returns_none_when_disabled(self):
        """Exchange returns None when OAuth2Client is not configured."""
        with patch("okta_agent_proxy.auth.cross_app_access.AdapterCIMDServer", side_effect=Exception("no")):
            from okta_agent_proxy.auth.cross_app_access import OktaCrossAppAccessManager

            manager = OktaCrossAppAccessManager(
                agent_id="test",
                client_id="0oaXXXX",
                agent_private_key=None,
                okta_domain="dev-test.okta.com",
                target_auth_server_id="ausXXXX",
                principal_id="agt123",
            )

            result = await manager.exchange_id_token_to_mcp_token(
                user_id_token="token",
                resource_name="test-resource",
                target_auth_server_id="aus1234",
            )
            assert result is None

    @pytest.mark.asyncio
    async def test_error_on_flow_start(self):
        """Exchange returns None and clears cache when flow.start() raises."""
        with patch("okta_agent_proxy.auth.cross_app_access.OAuth2Client"), \
             patch("okta_agent_proxy.auth.cross_app_access.OAuth2ClientConfiguration"), \
             patch("okta_agent_proxy.auth.cross_app_access.ClientAssertionAuthorization"), \
             patch("okta_agent_proxy.auth.cross_app_access.JWTBearerClaims"), \
             patch("okta_agent_proxy.auth.cross_app_access.LocalKeyProvider"), \
             patch("okta_agent_proxy.auth.cross_app_access.CrossAppAccessTarget"), \
             patch("okta_agent_proxy.auth.cross_app_access.CrossAppAccessFlow") as mock_flow_cls:
            from okta_agent_proxy.auth.cross_app_access import OktaCrossAppAccessManager

            mock_flow = MagicMock()
            mock_flow.start = AsyncMock(side_effect=Exception("token exchange failed"))
            mock_flow_cls.return_value = mock_flow

            manager = OktaCrossAppAccessManager(
                agent_id="test",
                client_id="0oaXXXX",
                agent_private_key=SAMPLE_JWK_STR,
                okta_domain="dev-test.okta.com",
                target_auth_server_id="ausXXXX",
                principal_id="agt123",
            )

            result = await manager.exchange_id_token_to_mcp_token(
                user_id_token="token",
                resource_name="test-resource",
                target_auth_server_id="aus1234",
            )

            assert result is None
            assert "test-resource:aus1234" not in manager._flow_cache

    @pytest.mark.asyncio
    async def test_error_on_flow_resume(self):
        """Exchange returns None and clears cache when flow.resume() raises."""
        with patch("okta_agent_proxy.auth.cross_app_access.OAuth2Client"), \
             patch("okta_agent_proxy.auth.cross_app_access.OAuth2ClientConfiguration"), \
             patch("okta_agent_proxy.auth.cross_app_access.ClientAssertionAuthorization"), \
             patch("okta_agent_proxy.auth.cross_app_access.JWTBearerClaims"), \
             patch("okta_agent_proxy.auth.cross_app_access.LocalKeyProvider"), \
             patch("okta_agent_proxy.auth.cross_app_access.CrossAppAccessTarget"), \
             patch("okta_agent_proxy.auth.cross_app_access.CrossAppAccessFlow") as mock_flow_cls:
            from okta_agent_proxy.auth.cross_app_access import OktaCrossAppAccessManager

            mock_flow = MagicMock()
            mock_flow.start = AsyncMock(return_value=MagicMock())
            mock_flow.context.id_jag_token.expires_in = 300
            mock_flow.resume = AsyncMock(side_effect=Exception("resume failed"))
            mock_flow_cls.return_value = mock_flow

            manager = OktaCrossAppAccessManager(
                agent_id="test",
                client_id="0oaXXXX",
                agent_private_key=SAMPLE_JWK_STR,
                okta_domain="dev-test.okta.com",
                target_auth_server_id="ausXXXX",
                principal_id="agt123",
            )

            result = await manager.exchange_id_token_to_mcp_token(
                user_id_token="token",
                resource_name="test-resource",
                target_auth_server_id="aus1234",
            )

            assert result is None
            assert "test-resource:aus1234" not in manager._flow_cache

    @pytest.mark.asyncio
    async def test_exchange_timeout_error(self):
        """Timeout errors are logged with specific message."""
        with patch("okta_agent_proxy.auth.cross_app_access.OAuth2Client"), \
             patch("okta_agent_proxy.auth.cross_app_access.OAuth2ClientConfiguration"), \
             patch("okta_agent_proxy.auth.cross_app_access.ClientAssertionAuthorization"), \
             patch("okta_agent_proxy.auth.cross_app_access.JWTBearerClaims"), \
             patch("okta_agent_proxy.auth.cross_app_access.LocalKeyProvider"), \
             patch("okta_agent_proxy.auth.cross_app_access.CrossAppAccessTarget"), \
             patch("okta_agent_proxy.auth.cross_app_access.CrossAppAccessFlow") as mock_flow_cls:
            from okta_agent_proxy.auth.cross_app_access import OktaCrossAppAccessManager

            mock_flow = MagicMock()
            mock_flow.start = AsyncMock(return_value=MagicMock())
            mock_flow.context.id_jag_token.expires_in = 300
            mock_flow.resume = AsyncMock(side_effect=Exception("Connection timeout reached"))
            mock_flow_cls.return_value = mock_flow

            manager = OktaCrossAppAccessManager(
                agent_id="test",
                client_id="0oaXXXX",
                agent_private_key=SAMPLE_JWK_STR,
                okta_domain="dev-test.okta.com",
                target_auth_server_id="ausXXXX",
                principal_id="agt123",
            )

            result = await manager.exchange_id_token_to_mcp_token(
                user_id_token="token",
                resource_name="test-resource",
                target_auth_server_id="aus1234",
            )

            assert result is None


# ============================================================================
# Scope condition tests
# ============================================================================

class TestScopeCondition:
    """apply_scope_condition semantics (see cross_app_access.py for full spec)."""

    def test_allow_all_union(self):
        from okta_agent_proxy.auth.cross_app_access import OktaCrossAppAccessManager
        # ALLOW_ALL merges caller-requested + configured, no filtering.
        result = OktaCrossAppAccessManager.apply_scope_condition(
            ["mcp:read", "mcp:write"], ["mcp:read"], "ALLOW_ALL"
        )
        assert result == ["mcp:read", "mcp:write"]

    def test_allow_all_empty_requested_uses_configured(self):
        from okta_agent_proxy.auth.cross_app_access import OktaCrossAppAccessManager
        # Caller didn't request scopes; connection has a list → use connection list.
        result = OktaCrossAppAccessManager.apply_scope_condition(
            None, ["bedrock:InvokeAgent", "repo:read"], "ALLOW_ALL"
        )
        assert result == ["bedrock:InvokeAgent", "repo:read"]

    def test_allow_all_both_empty_returns_empty(self):
        from okta_agent_proxy.auth.cross_app_access import OktaCrossAppAccessManager
        # Nothing requested, nothing configured → omit scope on wire.
        result = OktaCrossAppAccessManager.apply_scope_condition(None, None, "ALLOW_ALL")
        assert result == []

    def test_none_condition_treated_as_allow_all(self):
        from okta_agent_proxy.auth.cross_app_access import OktaCrossAppAccessManager
        result = OktaCrossAppAccessManager.apply_scope_condition(
            ["mcp:read", "mcp:write"], None, None
        )
        assert result == ["mcp:read", "mcp:write"]

    def test_include_only_intersection(self):
        from okta_agent_proxy.auth.cross_app_access import OktaCrossAppAccessManager
        # Narrow caller request to configured list.
        result = OktaCrossAppAccessManager.apply_scope_condition(
            ["mcp:read", "mcp:write"], ["mcp:read"], "INCLUDE_ONLY"
        )
        assert result == ["mcp:read"]

    def test_include_only_no_requested_returns_configured(self):
        from okta_agent_proxy.auth.cross_app_access import OktaCrossAppAccessManager
        result = OktaCrossAppAccessManager.apply_scope_condition(
            None, ["bedrock:InvokeAgent"], "INCLUDE_ONLY"
        )
        assert result == ["bedrock:InvokeAgent"]

    def test_disallow_subtracts_configured_block_list(self):
        from okta_agent_proxy.auth.cross_app_access import OktaCrossAppAccessManager
        result = OktaCrossAppAccessManager.apply_scope_condition(
            ["mcp:read", "mcp:write", "mcp:admin"], ["mcp:admin"], "DISALLOW"
        )
        assert result == ["mcp:read", "mcp:write"]

    def test_disallow_all_requested_returns_empty(self):
        from okta_agent_proxy.auth.cross_app_access import OktaCrossAppAccessManager
        # Everything requested was blocked → empty (omit scope on wire).
        result = OktaCrossAppAccessManager.apply_scope_condition(
            ["mcp:read"], ["mcp:read"], "DISALLOW"
        )
        assert result == []

    def test_exclude_is_alias_of_disallow(self):
        from okta_agent_proxy.auth.cross_app_access import OktaCrossAppAccessManager
        # EXCLUDE was previously a silent no-op; now behaves like DISALLOW.
        result = OktaCrossAppAccessManager.apply_scope_condition(
            ["mcp:read", "mcp:admin"], ["mcp:admin"], "EXCLUDE"
        )
        assert result == ["mcp:read"]

    def test_none_scopes_returns_empty_not_mcp_read(self):
        from okta_agent_proxy.auth.cross_app_access import OktaCrossAppAccessManager
        # Previously returned ["mcp:read"] by default — that fallback is gone.
        result = OktaCrossAppAccessManager.apply_scope_condition(None, None, None)
        assert result == []

    def test_unknown_condition_returns_empty(self):
        from okta_agent_proxy.auth.cross_app_access import OktaCrossAppAccessManager
        result = OktaCrossAppAccessManager.apply_scope_condition(
            ["mcp:read"], ["repo:read"], "NOT_A_REAL_CONDITION"
        )
        assert result == []


# ============================================================================
# Placeholder key detection tests
# ============================================================================

class TestPlaceholderKey:

    def test_none_is_placeholder(self):
        from okta_agent_proxy.auth.cross_app_access import OktaCrossAppAccessManager
        assert OktaCrossAppAccessManager._is_placeholder_key(None) is True

    def test_empty_string_is_placeholder(self):
        from okta_agent_proxy.auth.cross_app_access import OktaCrossAppAccessManager
        assert OktaCrossAppAccessManager._is_placeholder_key("") is True

    def test_placeholder_string(self):
        from okta_agent_proxy.auth.cross_app_access import OktaCrossAppAccessManager
        assert OktaCrossAppAccessManager._is_placeholder_key("PLACEHOLDER") is True

    def test_placeholder_in_string(self):
        from okta_agent_proxy.auth.cross_app_access import OktaCrossAppAccessManager
        assert OktaCrossAppAccessManager._is_placeholder_key('{"n":"PLACEHOLDER"}') is True

    def test_placeholder_dict(self):
        from okta_agent_proxy.auth.cross_app_access import OktaCrossAppAccessManager
        assert OktaCrossAppAccessManager._is_placeholder_key({"n": "PLACEHOLDER"}) is True

    def test_real_key_is_not_placeholder(self):
        from okta_agent_proxy.auth.cross_app_access import OktaCrossAppAccessManager
        assert OktaCrossAppAccessManager._is_placeholder_key(SAMPLE_JWK_STR) is False

    def test_real_dict_is_not_placeholder(self):
        from okta_agent_proxy.auth.cross_app_access import OktaCrossAppAccessManager
        assert OktaCrossAppAccessManager._is_placeholder_key(SAMPLE_JWK) is False
