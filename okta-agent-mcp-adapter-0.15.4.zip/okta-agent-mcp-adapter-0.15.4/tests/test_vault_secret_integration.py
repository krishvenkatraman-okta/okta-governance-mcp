"""
Integration tests for vault-secret and sts-service-account auth dispatch
through the ResourceRouter and UnifiedMCPHandler.

Covers:
- Router dispatches to OktaVaultSecretExchanger for vault-secret/sts-service-account
- User ID token is passed through to the exchanger
- Resource ORN extracted from metadata
- Token caching (hit, miss, expiry)
- Unified handler constructs correct auth headers
- End-to-end flow from ResolvedResource → router → exchanger → auth handler → headers
"""

import base64
import pytest
from datetime import datetime, timedelta
from unittest.mock import AsyncMock, MagicMock, patch

from okta_agent_proxy.routing.router import ResourceRouter, ResolvedResourceConfigAdapter
from okta_agent_proxy.resources.models import OktaConnectionType, _CONNECTION_TYPE_TO_AUTH_METHOD


# ============================================================================
# Fixtures
# ============================================================================

FAKE_USER_TOKEN = "eyJ.fake.id-token"
VAULT_ORN = "orn:okta:pam:00o123:secrets:abc-456"
SA_ORN = "orn:okta:pam:00o123:service_accounts:sa-789"

AGENT_CONFIG = {
    "agent_id": "test-agent",
    "client_id": "0oa_test",
    "private_key": '{"kty":"RSA","kid":"k1","n":"test","e":"AQAB","d":"test"}',
    "principal_id": "wlpTestAgent",
    "okta_ai_agent_id": "agtTest123",
}


def _make_resolved_resource(auth_method="vault-secret", connection_id="conn-vs-1",
                            resource_id="res-1", name="vault-resource",
                            mcp_url="https://mcp.example.com", metadata=None):
    rb = MagicMock()
    rb.name = name
    rb.mcp_url = mcp_url
    rb.auth_method = auth_method
    rb.resource_id = resource_id
    rb.connection_id = connection_id
    rb.connection_type = MagicMock(value=auth_method)
    rb.protocol = "mcp"
    rb.description = "test"
    rb.scopes = []
    rb.scope_condition = MagicMock(value="ALLOW_ALL")
    rb.metadata = metadata or {}
    rb.enabled = True
    rb.url = mcp_url
    return rb


def _mock_exchanger(vault_result=None, sa_result=None):
    exchanger = MagicMock()
    exchanger.exchange_vault_secret = AsyncMock(return_value=vault_result)
    exchanger.exchange_service_account = AsyncMock(return_value=sa_result)
    return exchanger


def _vault_success(access_token="vault-secret-xyz", expires_in=300):
    return {
        "status": "success",
        "access_token": access_token,
        "token_type": "Bearer",
        "expires_in": expires_in,
        "provider": "vault-resource",
    }


def _sa_success_basic(username="svc-user", password="svc-pass"):
    return {
        "status": "success",
        "username": username,
        "password": password,
        "provider": "sa-resource",
    }


def _sa_success_bearer(access_token="sa-token-123"):
    return {
        "status": "success",
        "access_token": access_token,
        "token_type": "Bearer",
        "expires_in": 300,
        "provider": "sa-resource",
    }


# ============================================================================
# Router dispatch tests
# ============================================================================

class TestRouterVaultSecretDispatch:

    @pytest.mark.asyncio
    async def test_dispatches_to_exchanger(self):
        router = ResourceRouter(resources_config={})
        rb = _make_resolved_resource(metadata={"resource_indicator": VAULT_ORN})
        adapter = ResolvedResourceConfigAdapter(rb)
        exchanger = _mock_exchanger(vault_result=_vault_success())

        with patch("okta_agent_proxy.routing.router.OktaVaultSecretExchanger", return_value=exchanger):
            result = await router._get_vault_secret_token(
                "vault-resource", adapter, AGENT_CONFIG, FAKE_USER_TOKEN
            )

        assert result == "vault-secret-xyz"
        exchanger.exchange_vault_secret.assert_called_once()

    @pytest.mark.asyncio
    async def test_passes_user_id_token(self):
        router = ResourceRouter(resources_config={})
        rb = _make_resolved_resource(metadata={"resource_indicator": VAULT_ORN})
        adapter = ResolvedResourceConfigAdapter(rb)
        exchanger = _mock_exchanger(vault_result=_vault_success())

        with patch("okta_agent_proxy.routing.router.OktaVaultSecretExchanger", return_value=exchanger):
            await router._get_vault_secret_token(
                "vault-resource", adapter, AGENT_CONFIG, FAKE_USER_TOKEN
            )

        call_args = exchanger.exchange_vault_secret.call_args
        assert call_args[0][0] == FAKE_USER_TOKEN

    @pytest.mark.asyncio
    async def test_extracts_resource_orn_from_metadata(self):
        router = ResourceRouter(resources_config={})
        rb = _make_resolved_resource(metadata={"resource_indicator": VAULT_ORN})
        adapter = ResolvedResourceConfigAdapter(rb)
        exchanger = _mock_exchanger(vault_result=_vault_success())

        with patch("okta_agent_proxy.routing.router.OktaVaultSecretExchanger", return_value=exchanger):
            await router._get_vault_secret_token(
                "vault-resource", adapter, AGENT_CONFIG, FAKE_USER_TOKEN
            )

        call_args = exchanger.exchange_vault_secret.call_args
        assert call_args[0][1] == VAULT_ORN

    @pytest.mark.asyncio
    async def test_caches_result(self):
        router = ResourceRouter(resources_config={})
        rb = _make_resolved_resource(metadata={"resource_indicator": VAULT_ORN})
        adapter = ResolvedResourceConfigAdapter(rb)
        exchanger = _mock_exchanger(vault_result=_vault_success())

        with patch("okta_agent_proxy.routing.router.OktaVaultSecretExchanger", return_value=exchanger):
            result1 = await router._get_vault_secret_token(
                "vault-resource", adapter, AGENT_CONFIG, FAKE_USER_TOKEN
            )

        # Second call should use cache — no new exchanger needed
        result2 = await router._get_vault_secret_token(
            "vault-resource", adapter, AGENT_CONFIG, FAKE_USER_TOKEN
        )
        assert result1 == result2 == "vault-secret-xyz"
        exchanger.exchange_vault_secret.assert_called_once()

    @pytest.mark.asyncio
    async def test_cache_miss_after_expiry(self):
        router = ResourceRouter(resources_config={})
        rb = _make_resolved_resource(connection_id="conn-exp", metadata={"resource_indicator": VAULT_ORN})
        adapter = ResolvedResourceConfigAdapter(rb)

        # Pre-populate cache with expired entry
        router.resource_token_cache.set(
            "secret:vault-resource", "conn-exp",
            {"token": "old-secret", "expires_at": datetime.now() - timedelta(seconds=1)},
            ttl_seconds=1,
        )

        exchanger = _mock_exchanger(vault_result=_vault_success(access_token="fresh-secret"))

        with patch("okta_agent_proxy.routing.router.OktaVaultSecretExchanger", return_value=exchanger):
            result = await router._get_vault_secret_token(
                "vault-resource", adapter, AGENT_CONFIG, FAKE_USER_TOKEN
            )

        assert result == "fresh-secret"
        exchanger.exchange_vault_secret.assert_called_once()

    @pytest.mark.asyncio
    async def test_returns_none_on_failure(self):
        router = ResourceRouter(resources_config={})
        rb = _make_resolved_resource(metadata={"resource_indicator": VAULT_ORN})
        adapter = ResolvedResourceConfigAdapter(rb)
        exchanger = _mock_exchanger(vault_result=None)

        with patch("okta_agent_proxy.routing.router.OktaVaultSecretExchanger", return_value=exchanger):
            result = await router._get_vault_secret_token(
                "vault-resource", adapter, AGENT_CONFIG, FAKE_USER_TOKEN
            )

        assert result is None

    @pytest.mark.asyncio
    async def test_sts_service_account_dispatches_to_exchanger(self):
        router = ResourceRouter(resources_config={})
        rb = _make_resolved_resource(
            auth_method="sts-service-account", connection_id="conn-sa-1",
            name="sa-resource", metadata={"resource_indicator": SA_ORN},
        )
        adapter = ResolvedResourceConfigAdapter(rb)
        exchanger = _mock_exchanger(sa_result=_sa_success_basic())

        with patch("okta_agent_proxy.routing.router.OktaVaultSecretExchanger", return_value=exchanger):
            result = await router._get_sts_service_account_token(
                "sa-resource", adapter, AGENT_CONFIG, FAKE_USER_TOKEN
            )

        expected = f"Basic {base64.b64encode(b'svc-user:svc-pass').decode()}"
        assert result == expected
        exchanger.exchange_service_account.assert_called_once()

    @pytest.mark.asyncio
    async def test_sts_service_account_returns_basic_auth(self):
        router = ResourceRouter(resources_config={})
        rb = _make_resolved_resource(
            auth_method="sts-service-account", connection_id="conn-sa-2",
            name="sa-resource", metadata={"resource_indicator": SA_ORN},
        )
        adapter = ResolvedResourceConfigAdapter(rb)
        exchanger = _mock_exchanger(sa_result=_sa_success_basic("admin", "p@ss"))

        with patch("okta_agent_proxy.routing.router.OktaVaultSecretExchanger", return_value=exchanger):
            result = await router._get_sts_service_account_token(
                "sa-resource", adapter, AGENT_CONFIG, FAKE_USER_TOKEN
            )

        expected = f"Basic {base64.b64encode(b'admin:p@ss').decode()}"
        assert result == expected


# ============================================================================
# Unified handler dispatch tests
# ============================================================================

class TestUnifiedHandlerVaultSecret:

    def _make_handler(self):
        from okta_agent_proxy.mcp.unified_handler import UnifiedMCPHandler
        from okta_agent_proxy.cache.token_cache import TokenCache
        from okta_agent_proxy.auth.resource_token_resolver import ResourceTokenResolver
        router = MagicMock()
        token_cache = TokenCache(max_size=100, ttl_seconds=3600)
        router.resolver = ResourceTokenResolver(token_cache)
        router.get_token_cache.return_value = token_cache
        validator = MagicMock()
        store = MagicMock()
        return UnifiedMCPHandler(router=router, validator=validator, store=store)

    def _make_resource_config(self, auth_method="vault-secret", metadata=None,
                              auth_config=None, connection_id="conn-1"):
        rc = MagicMock()
        rc.auth_method = auth_method
        rc.metadata = metadata or {"resource_indicator": VAULT_ORN}
        rc.connection_id = connection_id
        rc.enabled = True
        rc.url = "https://mcp.example.com"
        if auth_config:
            ac = MagicMock()
            ac.model_dump.return_value = auth_config
            rc.auth_config = ac
        else:
            ac = MagicMock()
            ac.model_dump.return_value = {}
            rc.auth_config = ac
        return rc

    @pytest.mark.asyncio
    async def test_vault_secret_auth_headers(self):
        handler = self._make_handler()
        rc = self._make_resource_config()
        exchanger = _mock_exchanger(vault_result=_vault_success(access_token="my-secret"))

        with patch("okta_agent_proxy.auth.okta_vault_exchanger.OktaVaultSecretExchanger", return_value=exchanger):
            headers = await handler._get_resource_auth_headers(
                "vault-resource", rc, AGENT_CONFIG, "user-1", FAKE_USER_TOKEN
            )

        assert headers is not None
        assert headers["Authorization"] == "Bearer my-secret"

    @pytest.mark.asyncio
    async def test_vault_secret_custom_header(self):
        handler = self._make_handler()
        rc = self._make_resource_config(auth_config={
            "header_name": "X-API-Key",
            "header_prefix": "",
        })
        exchanger = _mock_exchanger(vault_result=_vault_success(access_token="api-key-value"))

        with patch("okta_agent_proxy.auth.okta_vault_exchanger.OktaVaultSecretExchanger", return_value=exchanger):
            headers = await handler._get_resource_auth_headers(
                "vault-resource", rc, AGENT_CONFIG, "user-1", FAKE_USER_TOKEN
            )

        assert headers is not None
        assert "X-API-Key" in headers
        assert headers["X-API-Key"] == "api-key-value"

    @pytest.mark.asyncio
    async def test_vault_secret_missing_exchanger(self):
        handler = self._make_handler()
        rc = self._make_resource_config()

        with patch("okta_agent_proxy.auth.okta_vault_exchanger.OktaVaultSecretExchanger", side_effect=ValueError("no principal")):
            headers = await handler._get_resource_auth_headers(
                "vault-resource", rc, AGENT_CONFIG, "user-1", FAKE_USER_TOKEN
            )

        assert headers is None

    @pytest.mark.asyncio
    async def test_sts_service_account_auth_headers(self):
        handler = self._make_handler()
        rc = self._make_resource_config(
            auth_method="sts-service-account",
            metadata={"resource_indicator": SA_ORN},
        )
        exchanger = _mock_exchanger(sa_result=_sa_success_basic("u", "p"))

        with patch("okta_agent_proxy.auth.okta_vault_exchanger.OktaVaultSecretExchanger", return_value=exchanger):
            headers = await handler._get_resource_auth_headers(
                "sa-resource", rc, AGENT_CONFIG, "user-1", FAKE_USER_TOKEN
            )

        assert headers is not None
        expected = base64.b64encode(b"u:p").decode()
        assert headers["Authorization"] == f"Basic {expected}"

    @pytest.mark.asyncio
    async def test_vault_secret_caching(self):
        handler = self._make_handler()
        rc = self._make_resource_config()

        # First call — exchanger used
        exchanger = _mock_exchanger(vault_result=_vault_success())
        with patch("okta_agent_proxy.auth.okta_vault_exchanger.OktaVaultSecretExchanger", return_value=exchanger):
            h1 = await handler._get_resource_auth_headers(
                "vault-resource", rc, AGENT_CONFIG, "user-1", FAKE_USER_TOKEN
            )
        assert h1 is not None

    @pytest.mark.asyncio
    async def test_vault_secret_no_resource_orn(self):
        handler = self._make_handler()
        rc = self._make_resource_config(metadata={})
        # Remove connection_id too
        rc.connection_id = None

        with patch("okta_agent_proxy.auth.okta_vault_exchanger.OktaVaultSecretExchanger", return_value=_mock_exchanger()):
            headers = await handler._get_resource_auth_headers(
                "vault-resource", rc, AGENT_CONFIG, "user-1", FAKE_USER_TOKEN
            )

        # Should fail because no resource_orn can be resolved
        assert headers is None


# ============================================================================
# End-to-end flow tests
# ============================================================================

class TestEndToEnd:

    @pytest.mark.asyncio
    async def test_vault_secret_e2e_resolved_resource(self):
        """Full chain: ResolvedResource → adapter → router → exchanger → result."""
        router = ResourceRouter(resources_config={})
        rb = _make_resolved_resource(
            auth_method="vault-secret",
            connection_id="conn-e2e",
            metadata={"resource_indicator": VAULT_ORN},
        )
        adapter = ResolvedResourceConfigAdapter(rb)
        exchanger = _mock_exchanger(vault_result=_vault_success(access_token="e2e-secret"))

        with patch("okta_agent_proxy.routing.router.OktaVaultSecretExchanger", return_value=exchanger):
            token = await router._get_vault_secret_token(
                "vault-resource", adapter, AGENT_CONFIG, FAKE_USER_TOKEN
            )

        assert token == "e2e-secret"

        # Verify exchanger was called with correct params
        exchanger.exchange_vault_secret.assert_called_once_with(
            FAKE_USER_TOKEN, VAULT_ORN, resource_name="vault-resource"
        )

    @pytest.mark.asyncio
    async def test_sts_service_account_e2e_resolved_resource(self):
        """Full chain for STS_SERVICE_ACCOUNT."""
        router = ResourceRouter(resources_config={})
        rb = _make_resolved_resource(
            auth_method="sts-service-account",
            connection_id="conn-sa-e2e",
            name="sa-resource",
            metadata={"resource_indicator": SA_ORN},
        )
        adapter = ResolvedResourceConfigAdapter(rb)
        exchanger = _mock_exchanger(sa_result=_sa_success_basic("admin", "secret"))

        with patch("okta_agent_proxy.routing.router.OktaVaultSecretExchanger", return_value=exchanger):
            token = await router._get_sts_service_account_token(
                "sa-resource", adapter, AGENT_CONFIG, FAKE_USER_TOKEN
            )

        expected = f"Basic {base64.b64encode(b'admin:secret').decode()}"
        assert token == expected

    def test_vault_secret_auth_method_auto_derived(self):
        """Verify OktaConnectionType.STS_VAULT_SECRET maps to 'vault-secret'."""
        assert _CONNECTION_TYPE_TO_AUTH_METHOD[OktaConnectionType.STS_VAULT_SECRET] == "vault-secret"
        assert _CONNECTION_TYPE_TO_AUTH_METHOD[OktaConnectionType.STS_SERVICE_ACCOUNT] == "sts-service-account"
