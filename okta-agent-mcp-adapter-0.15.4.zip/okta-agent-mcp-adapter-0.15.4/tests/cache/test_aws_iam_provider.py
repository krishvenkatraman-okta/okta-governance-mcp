"""Tests for AwsIamElastiCacheProvider (P06)."""

import datetime
from unittest.mock import MagicMock, patch

import pytest

from okta_agent_proxy.cache.redis_credential_providers.aws_iam import (
    CACHE_NAME_ENV,
    REGION_ENV,
    SERVERLESS_ENV,
    TOKEN_LIFETIME_SECONDS,
    USER_ID_ENV,
    AwsIamElastiCacheProvider,
)
from okta_agent_proxy.cache.redis_credentials import CredentialUnavailableError

# AWS example credentials from public docs — not real secrets.
FAKE_ACCESS_KEY = "AKIAIOSFODNN7EXAMPLE"
FAKE_SECRET_KEY = "wJalrXUtnFEMI/K7MDENG/bPxRfiCYEXAMPLEKEY"


def _clear_env(monkeypatch):
    for key in (USER_ID_ENV, CACHE_NAME_ENV, REGION_ENV, SERVERLESS_ENV):
        monkeypatch.delenv(key, raising=False)


def _set_aws_creds(monkeypatch):
    monkeypatch.setenv("AWS_ACCESS_KEY_ID", FAKE_ACCESS_KEY)
    monkeypatch.setenv("AWS_SECRET_ACCESS_KEY", FAKE_SECRET_KEY)


def test_from_env_raises_when_user_id_missing(monkeypatch):
    _clear_env(monkeypatch)
    monkeypatch.setenv(CACHE_NAME_ENV, "my-cache")
    monkeypatch.setenv(REGION_ENV, "us-east-1")
    with pytest.raises(CredentialUnavailableError) as exc:
        AwsIamElastiCacheProvider.from_env()
    assert USER_ID_ENV in str(exc.value)


def test_from_env_raises_when_cache_name_missing(monkeypatch):
    _clear_env(monkeypatch)
    monkeypatch.setenv(USER_ID_ENV, "okta-mcp-adapter")
    monkeypatch.setenv(REGION_ENV, "us-east-1")
    with pytest.raises(CredentialUnavailableError) as exc:
        AwsIamElastiCacheProvider.from_env()
    assert CACHE_NAME_ENV in str(exc.value)


def test_from_env_raises_when_region_missing(monkeypatch):
    _clear_env(monkeypatch)
    monkeypatch.setenv(USER_ID_ENV, "okta-mcp-adapter")
    monkeypatch.setenv(CACHE_NAME_ENV, "my-cache")
    with pytest.raises(CredentialUnavailableError) as exc:
        AwsIamElastiCacheProvider.from_env()
    assert REGION_ENV in str(exc.value)


def test_from_env_succeeds_with_all_required(monkeypatch):
    _clear_env(monkeypatch)
    monkeypatch.setenv(USER_ID_ENV, "okta-mcp-adapter")
    monkeypatch.setenv(CACHE_NAME_ENV, "my-cache")
    monkeypatch.setenv(REGION_ENV, "us-east-1")
    provider = AwsIamElastiCacheProvider.from_env()
    assert provider._user_id == "okta-mcp-adapter"
    assert provider._cache_name == "my-cache"
    assert provider._region == "us-east-1"


def test_from_env_serverless_defaults_to_true(monkeypatch):
    _clear_env(monkeypatch)
    monkeypatch.setenv(USER_ID_ENV, "u")
    monkeypatch.setenv(CACHE_NAME_ENV, "c")
    monkeypatch.setenv(REGION_ENV, "r")
    assert AwsIamElastiCacheProvider.from_env()._is_serverless is True


def test_from_env_serverless_false_when_explicitly_set(monkeypatch):
    _clear_env(monkeypatch)
    monkeypatch.setenv(USER_ID_ENV, "u")
    monkeypatch.setenv(CACHE_NAME_ENV, "c")
    monkeypatch.setenv(REGION_ENV, "r")
    monkeypatch.setenv(SERVERLESS_ENV, "false")
    assert AwsIamElastiCacheProvider.from_env()._is_serverless is False


@pytest.mark.asyncio
async def test_get_credentials_returns_user_id_as_username(monkeypatch):
    _set_aws_creds(monkeypatch)
    provider = AwsIamElastiCacheProvider(
        user_id="okta-mcp-adapter", cache_name="my-cache", region="us-east-1"
    )
    creds = await provider.get_credentials()
    assert creds.username == "okta-mcp-adapter"


@pytest.mark.asyncio
async def test_get_credentials_password_is_not_empty(monkeypatch):
    _set_aws_creds(monkeypatch)
    provider = AwsIamElastiCacheProvider(
        user_id="u", cache_name="my-cache", region="us-east-1"
    )
    creds = await provider.get_credentials()
    assert creds.password
    assert len(creds.password) > 100  # signed URL is not short


@pytest.mark.asyncio
async def test_get_credentials_password_does_not_contain_aws_secret_key(monkeypatch):
    _set_aws_creds(monkeypatch)
    provider = AwsIamElastiCacheProvider(
        user_id="u", cache_name="my-cache", region="us-east-1"
    )
    creds = await provider.get_credentials()
    # SigV4 signs WITH the secret but the signature is opaque — the raw
    # secret must not appear in the token.
    assert FAKE_SECRET_KEY not in creds.password


@pytest.mark.asyncio
async def test_get_credentials_expires_at_is_15_minutes_from_now(monkeypatch):
    _set_aws_creds(monkeypatch)
    provider = AwsIamElastiCacheProvider(
        user_id="u", cache_name="c", region="us-east-1"
    )
    before = datetime.datetime.now(datetime.timezone.utc)
    creds = await provider.get_credentials()
    after = datetime.datetime.now(datetime.timezone.utc)
    delta_from_before = (creds.expires_at - before).total_seconds()
    delta_from_after = (creds.expires_at - after).total_seconds()
    assert 895 <= delta_from_before <= 905
    assert 895 <= delta_from_after <= 905
    assert TOKEN_LIFETIME_SECONDS == 900


@pytest.mark.asyncio
async def test_get_credentials_principal_includes_access_key(monkeypatch):
    _set_aws_creds(monkeypatch)
    provider = AwsIamElastiCacheProvider(
        user_id="u", cache_name="c", region="us-east-1"
    )
    creds = await provider.get_credentials()
    assert FAKE_ACCESS_KEY in creds.principal


def test_refresh_safety_window_is_2_minutes_30_seconds():
    provider = AwsIamElastiCacheProvider(
        user_id="u", cache_name="c", region="r"
    )
    assert provider.refresh_safety_window() == datetime.timedelta(
        minutes=2, seconds=30
    )


@pytest.mark.asyncio
async def test_get_credentials_raises_when_aws_creds_chain_empty():
    mock_session = MagicMock()
    mock_session.get_credentials.return_value = None
    provider = AwsIamElastiCacheProvider(
        user_id="u", cache_name="c", region="us-east-1", session=mock_session
    )
    with pytest.raises(CredentialUnavailableError) as exc:
        await provider.get_credentials()
    assert "credential chain" in str(exc.value).lower()


@pytest.mark.asyncio
async def test_get_credentials_wraps_botocore_errors_in_credential_unavailable(monkeypatch):
    _set_aws_creds(monkeypatch)
    provider = AwsIamElastiCacheProvider(
        user_id="u", cache_name="c", region="us-east-1"
    )
    with patch(
        "okta_agent_proxy.cache.redis_credential_providers.aws_iam.SigV4QueryAuth"
    ) as mock_signer:
        mock_signer.side_effect = RuntimeError("signing blew up")
        with pytest.raises(CredentialUnavailableError) as exc:
            await provider.get_credentials()
        assert "signing blew up" in str(exc.value)
        assert isinstance(exc.value.__cause__, RuntimeError)


def test_init_rejects_empty_user_id():
    with pytest.raises(ValueError, match="user_id"):
        AwsIamElastiCacheProvider(user_id="", cache_name="c", region="r")


def test_init_rejects_empty_cache_name():
    with pytest.raises(ValueError, match="cache_name"):
        AwsIamElastiCacheProvider(user_id="u", cache_name="", region="r")


def test_init_rejects_empty_region():
    with pytest.raises(ValueError, match="region"):
        AwsIamElastiCacheProvider(user_id="u", cache_name="c", region="")
