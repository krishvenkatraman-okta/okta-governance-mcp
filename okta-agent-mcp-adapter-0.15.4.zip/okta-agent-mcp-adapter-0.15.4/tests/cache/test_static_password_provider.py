"""Tests for StaticPasswordProvider (P02)."""

from unittest.mock import AsyncMock

import pytest

from okta_agent_proxy.audit.events import AuditEventType, AuditSeverity
from okta_agent_proxy.cache.redis_credential_providers.static import (
    GATE_ENV,
    PASSWORD_ENV,
    USERNAME_ENV,
    StaticPasswordProvider,
)
from okta_agent_proxy.cache.redis_credentials import CredentialUnavailableError


def _clear_env(monkeypatch):
    """Clear all env vars the provider reads."""
    for key in (GATE_ENV, PASSWORD_ENV, USERNAME_ENV):
        monkeypatch.delenv(key, raising=False)


def test_from_env_raises_when_gate_unset(monkeypatch):
    _clear_env(monkeypatch)
    with pytest.raises(CredentialUnavailableError) as exc:
        StaticPasswordProvider.from_env()
    msg = str(exc.value)
    assert "aws-iam" in msg
    assert "azure-entra" in msg
    assert "mtls" in msg
    assert "vault" in msg
    assert GATE_ENV in msg


def test_from_env_raises_when_gate_is_false(monkeypatch):
    _clear_env(monkeypatch)
    monkeypatch.setenv(GATE_ENV, "false")
    with pytest.raises(CredentialUnavailableError):
        StaticPasswordProvider.from_env()


@pytest.mark.parametrize("value", ["1", "yes", "TrueButNotExactly", "on", ""])
def test_from_env_raises_when_gate_is_anything_other_than_true(monkeypatch, value):
    _clear_env(monkeypatch)
    monkeypatch.setenv(GATE_ENV, value)
    with pytest.raises(CredentialUnavailableError):
        StaticPasswordProvider.from_env()


def test_from_env_succeeds_with_gate_true_lowercase(monkeypatch):
    _clear_env(monkeypatch)
    monkeypatch.setenv(GATE_ENV, "true")
    monkeypatch.setenv(PASSWORD_ENV, "secret")
    provider = StaticPasswordProvider.from_env()
    assert isinstance(provider, StaticPasswordProvider)
    assert provider._password == "secret"


def test_from_env_succeeds_with_gate_true_uppercase(monkeypatch):
    _clear_env(monkeypatch)
    monkeypatch.setenv(GATE_ENV, "TRUE")
    monkeypatch.setenv(PASSWORD_ENV, "secret")
    assert StaticPasswordProvider.from_env()._password == "secret"


def test_from_env_succeeds_with_gate_true_padded(monkeypatch):
    _clear_env(monkeypatch)
    monkeypatch.setenv(GATE_ENV, "  true  ")
    monkeypatch.setenv(PASSWORD_ENV, "secret")
    assert StaticPasswordProvider.from_env()._password == "secret"


def test_from_env_warns_when_password_empty(monkeypatch, caplog):
    _clear_env(monkeypatch)
    monkeypatch.setenv(GATE_ENV, "true")
    with caplog.at_level("WARNING"):
        provider = StaticPasswordProvider.from_env()
    assert provider._password is None
    assert any(PASSWORD_ENV in rec.getMessage() for rec in caplog.records)


def test_from_env_picks_up_username_when_set(monkeypatch):
    _clear_env(monkeypatch)
    monkeypatch.setenv(GATE_ENV, "true")
    monkeypatch.setenv(USERNAME_ENV, "alice")
    monkeypatch.setenv(PASSWORD_ENV, "secret")
    provider = StaticPasswordProvider.from_env()
    assert provider._username == "alice"


@pytest.mark.asyncio
async def test_get_credentials_returns_static_principal(monkeypatch):
    _clear_env(monkeypatch)
    monkeypatch.setenv(GATE_ENV, "true")
    monkeypatch.setenv(PASSWORD_ENV, "secret")
    provider = StaticPasswordProvider.from_env()
    monkeypatch.setattr("okta_agent_proxy.audit.emit_audit_event", AsyncMock())
    creds = await provider.get_credentials()
    assert creds.principal == "static"


@pytest.mark.asyncio
async def test_get_credentials_returns_expires_at_none(monkeypatch):
    _clear_env(monkeypatch)
    monkeypatch.setenv(GATE_ENV, "true")
    monkeypatch.setenv(PASSWORD_ENV, "secret")
    provider = StaticPasswordProvider.from_env()
    monkeypatch.setattr("okta_agent_proxy.audit.emit_audit_event", AsyncMock())
    creds = await provider.get_credentials()
    assert creds.expires_at is None
    assert creds.is_expiring() is False


@pytest.mark.asyncio
async def test_get_credentials_emits_audit_only_on_first_call(monkeypatch):
    _clear_env(monkeypatch)
    monkeypatch.setenv(GATE_ENV, "true")
    monkeypatch.setenv(PASSWORD_ENV, "secret")
    provider = StaticPasswordProvider.from_env()
    mock_emit = AsyncMock()
    monkeypatch.setattr("okta_agent_proxy.audit.emit_audit_event", mock_emit)
    await provider.get_credentials()
    await provider.get_credentials()
    await provider.get_credentials()
    assert mock_emit.call_count == 1


@pytest.mark.asyncio
async def test_get_credentials_emits_critical_severity_event(monkeypatch):
    _clear_env(monkeypatch)
    monkeypatch.setenv(GATE_ENV, "true")
    monkeypatch.setenv(PASSWORD_ENV, "secret")
    provider = StaticPasswordProvider.from_env()
    mock_emit = AsyncMock()
    monkeypatch.setattr("okta_agent_proxy.audit.emit_audit_event", mock_emit)
    await provider.get_credentials()
    assert mock_emit.call_count == 1
    args, kwargs = mock_emit.call_args
    # The provider calls emit_audit_event(event_type, severity, ...) positionally.
    assert args[0] == AuditEventType.REDIS_STATIC_PASSWORD_USED
    assert args[1] == AuditSeverity.CRITICAL


@pytest.mark.asyncio
async def test_get_credentials_does_not_raise_when_audit_emit_fails(monkeypatch):
    _clear_env(monkeypatch)
    monkeypatch.setenv(GATE_ENV, "true")
    monkeypatch.setenv(PASSWORD_ENV, "secret")
    provider = StaticPasswordProvider.from_env()

    async def _boom(*_a, **_kw):
        raise RuntimeError("audit sink down")

    monkeypatch.setattr("okta_agent_proxy.audit.emit_audit_event", _boom)
    # Should not propagate — we swallow to keep startup resilient.
    creds = await provider.get_credentials()
    assert creds.principal == "static"


@pytest.mark.asyncio
async def test_loud_warning_logged_on_first_call(monkeypatch, caplog):
    _clear_env(monkeypatch)
    monkeypatch.setenv(GATE_ENV, "true")
    monkeypatch.setenv(PASSWORD_ENV, "secret")
    provider = StaticPasswordProvider.from_env()
    monkeypatch.setattr("okta_agent_proxy.audit.emit_audit_event", AsyncMock())
    with caplog.at_level("WARNING"):
        await provider.get_credentials()
    joined = "\n".join(rec.getMessage() for rec in caplog.records)
    assert "NOT FOR PRODUCTION" in joined
