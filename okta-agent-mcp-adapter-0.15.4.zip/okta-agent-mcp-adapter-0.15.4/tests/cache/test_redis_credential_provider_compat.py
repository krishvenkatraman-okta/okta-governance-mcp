"""Backward-compatibility matrix for the Redis credential provider seam (P04).

Each test pins a specific env shape and asserts the right adapter behaviour —
these are the shapes security reviewers and deployers care about.
"""

from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from okta_agent_proxy.cache.cache_service import CacheService
from okta_agent_proxy.cache.memory_provider import MemoryCacheProvider
from okta_agent_proxy.cache.redis_credentials import (
    CredentialUnavailableError,
    RedisCredentialProvider,
    RedisCredentials,
    get_redis_credential_provider,
)
from okta_agent_proxy.cache.redis_provider import RedisCacheProvider


REDIS_ENV_VARS = (
    "CACHE_PROVIDER",
    "REDIS_URL",
    "REDIS_PASSWORD",
    "REDIS_USERNAME",
    "REDIS_AUTH_MODE",
    "REDIS_TLS_ENABLED",
    "REDIS_KEY_PREFIX",
    "ALLOW_STATIC_REDIS_PASSWORD",
)


@pytest.fixture(autouse=True)
def clean_redis_env(monkeypatch):
    for name in REDIS_ENV_VARS:
        monkeypatch.delenv(name, raising=False)
    yield


class FakeProvider(RedisCredentialProvider):
    name = "fake"

    async def get_credentials(self) -> RedisCredentials:
        return RedisCredentials(
            username=None,
            password="fake",
            expires_at=None,
            ssl_context=None,
            principal="fake-principal",
        )


def test_default_env_uses_memory_cache_no_provider_constructed(monkeypatch):
    """CACHE_PROVIDER unset + REDIS_URL unset → MemoryCacheProvider."""
    with patch(
        "okta_agent_proxy.cache.redis_credentials.get_redis_credential_provider"
    ) as factory_mock:
        svc = CacheService.create_from_env()

    assert isinstance(svc.l2, MemoryCacheProvider)
    factory_mock.assert_not_called()


def test_legacy_compose_with_gate_works(monkeypatch):
    """Legacy docker-compose shape + gate set → provider constructs cleanly."""
    monkeypatch.setenv("CACHE_PROVIDER", "redis")
    monkeypatch.setenv("REDIS_URL", "redis://redis:6379")
    monkeypatch.setenv("REDIS_PASSWORD", "foo")
    monkeypatch.setenv("ALLOW_STATIC_REDIS_PASSWORD", "true")

    provider = get_redis_credential_provider()
    assert provider.name == "static"


def test_legacy_compose_without_gate_raises(monkeypatch):
    """Legacy docker-compose shape but no gate → CredentialUnavailableError."""
    monkeypatch.setenv("CACHE_PROVIDER", "redis")
    monkeypatch.setenv("REDIS_URL", "redis://redis:6379")
    monkeypatch.setenv("REDIS_PASSWORD", "foo")

    with pytest.raises(CredentialUnavailableError) as exc_info:
        get_redis_credential_provider()

    msg = str(exc_info.value)
    assert "ALLOW_STATIC_REDIS_PASSWORD" in msg


@pytest.mark.asyncio
async def test_redis_url_with_embedded_password_is_stripped_when_provider_set(monkeypatch):
    """URL embedded creds must be stripped; provider creds are the source of truth."""
    monkeypatch.setenv("ALLOW_STATIC_REDIS_PASSWORD", "true")
    monkeypatch.setenv("REDIS_PASSWORD", "from-env")

    provider = get_redis_credential_provider()
    cache = RedisCacheProvider(
        redis_url="redis://x:y@host:6379/0",
        credential_provider=provider,
    )

    fake_client = MagicMock()
    with patch("redis.asyncio.from_url", return_value=fake_client) as from_url_mock, \
         patch("okta_agent_proxy.audit.emit_audit_event", new=AsyncMock()):
        await cache._get_redis()

    call_args, call_kwargs = from_url_mock.call_args
    assert call_args[0] == "redis://host:6379/0"
    # Provider is what supplies password; env-read value wins over URL
    assert call_kwargs["password"] == "from-env"


def test_unsupported_auth_mode_lists_supported_modes(monkeypatch):
    """mtls/vault are Phase 3 — error must list them as unsupported."""
    monkeypatch.setenv("REDIS_AUTH_MODE", "mtls")

    with pytest.raises(ValueError) as exc_info:
        get_redis_credential_provider()

    msg = str(exc_info.value)
    assert "static" in msg
    assert "aws-iam" in msg
    assert "azure-entra" in msg
    assert "mtls" in msg
    assert "vault" in msg


def test_provider_constructed_once_when_app_starts(monkeypatch):
    """app.py builds the provider once and injects it into CacheService.

    CacheService.create_from_env(credential_provider=<existing>) must NOT
    re-invoke the factory when a provider is supplied.
    """
    monkeypatch.setenv("CACHE_PROVIDER", "redis")
    monkeypatch.setenv("REDIS_URL", "redis://host:6379")

    fake_provider = FakeProvider()
    with patch(
        "okta_agent_proxy.cache.redis_credentials.get_redis_credential_provider"
    ) as factory_mock:
        svc = CacheService.create_from_env(credential_provider=fake_provider)

    assert isinstance(svc.l2, RedisCacheProvider)
    factory_mock.assert_not_called()


# ============================================================================
# Phase 2 additions (P08): aws-iam + azure-entra compat
# ============================================================================


def test_compat_aws_iam_with_complete_env_constructs(monkeypatch):
    """CACHE_PROVIDER=redis + REDIS_AUTH_MODE=aws-iam + full AWS env → provider
    resolves and CacheService builds Redis-backed."""
    monkeypatch.setenv("CACHE_PROVIDER", "redis")
    monkeypatch.setenv("REDIS_URL", "rediss://my-cache.amazonaws.com:6379/0")
    monkeypatch.setenv("REDIS_AUTH_MODE", "aws-iam")
    monkeypatch.setenv("REDIS_AWS_USER_ID", "test-user")
    monkeypatch.setenv("REDIS_AWS_CACHE_NAME", "test-cache")
    monkeypatch.setenv("AWS_REGION", "us-west-2")
    monkeypatch.setenv("AWS_ACCESS_KEY_ID", "AKIAIOSFODNN7EXAMPLE")
    monkeypatch.setenv(
        "AWS_SECRET_ACCESS_KEY", "wJalrXUtnFEMI/K7MDENG/bPxRfiCYEXAMPLEKEY"
    )

    provider = get_redis_credential_provider()
    assert provider.name == "aws-iam"

    # CacheService accepts the provider and wires a RedisCacheProvider.
    svc = CacheService.create_from_env(credential_provider=provider)
    assert isinstance(svc.l2, RedisCacheProvider)


def test_compat_aws_iam_missing_env_fails_fast(monkeypatch):
    """aws-iam without REDIS_AWS_USER_ID raises CredentialUnavailableError."""
    monkeypatch.setenv("CACHE_PROVIDER", "redis")
    monkeypatch.setenv("REDIS_URL", "rediss://my-cache.amazonaws.com:6379/0")
    monkeypatch.setenv("REDIS_AUTH_MODE", "aws-iam")
    monkeypatch.delenv("REDIS_AWS_USER_ID", raising=False)

    with pytest.raises(CredentialUnavailableError):
        get_redis_credential_provider()


def test_compat_azure_entra_constructs(monkeypatch):
    """azure-entra resolves to EntraManagedIdentityProvider without IMDS contact."""
    monkeypatch.setenv("CACHE_PROVIDER", "redis")
    monkeypatch.setenv("REDIS_URL", "rediss://redis.azure.com:6380/0")
    monkeypatch.setenv("REDIS_AUTH_MODE", "azure-entra")
    monkeypatch.setenv("REDIS_AZURE_USE_MSI", "false")

    with patch(
        "okta_agent_proxy.cache.redis_credential_providers.azure_entra.DefaultAzureCredential"
    ):
        provider = get_redis_credential_provider()

    assert provider.name == "azure-entra"


def test_compat_aws_iam_does_not_require_static_gate(monkeypatch):
    """ALLOW_STATIC_REDIS_PASSWORD must not be required for non-static modes."""
    monkeypatch.setenv("CACHE_PROVIDER", "redis")
    monkeypatch.setenv("REDIS_URL", "rediss://my-cache.amazonaws.com:6379/0")
    monkeypatch.setenv("REDIS_AUTH_MODE", "aws-iam")
    monkeypatch.setenv("REDIS_AWS_USER_ID", "test-user")
    monkeypatch.setenv("REDIS_AWS_CACHE_NAME", "test-cache")
    monkeypatch.setenv("AWS_REGION", "us-west-2")
    monkeypatch.setenv("AWS_ACCESS_KEY_ID", "AKIAIOSFODNN7EXAMPLE")
    monkeypatch.setenv(
        "AWS_SECRET_ACCESS_KEY", "wJalrXUtnFEMI/K7MDENG/bPxRfiCYEXAMPLEKEY"
    )
    monkeypatch.delenv("ALLOW_STATIC_REDIS_PASSWORD", raising=False)

    provider = get_redis_credential_provider()
    assert provider.name == "aws-iam"

    svc = CacheService.create_from_env(credential_provider=provider)
    assert isinstance(svc.l2, RedisCacheProvider)
