"""Tests for RedisCacheProvider scheduled-refresh seam (P06)."""

import asyncio
import datetime
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from okta_agent_proxy.audit.events import AuditEventType, AuditSeverity
from okta_agent_proxy.cache.redis_credentials import (
    RedisCredentialProvider,
    RedisCredentials,
)
from okta_agent_proxy.cache.redis_provider import RedisCacheProvider


class FakeExpiringProvider(RedisCredentialProvider):
    """Returns short-lived credentials. Tracks mint count."""

    name = "fake-expiring"

    def __init__(self, ttl_seconds: float = 30.0, window_seconds: float = 10.0,
                 raise_on_call: int = -1):
        self._ttl = ttl_seconds
        self._window = window_seconds
        self._raise_on_call = raise_on_call
        self.call_count = 0

    async def get_credentials(self) -> RedisCredentials:
        self.call_count += 1
        if self._raise_on_call >= 0 and self.call_count > self._raise_on_call:
            raise RuntimeError("boom")
        return RedisCredentials(
            username="u",
            password=f"pw-{self.call_count}",
            expires_at=datetime.datetime.now(datetime.timezone.utc)
            + datetime.timedelta(seconds=self._ttl),
            ssl_context=None,
            principal="fake",
        )

    def refresh_safety_window(self) -> datetime.timedelta:
        return datetime.timedelta(seconds=self._window)


class NonExpiringProvider(RedisCredentialProvider):
    name = "static-like"

    async def get_credentials(self) -> RedisCredentials:
        return RedisCredentials(
            username=None,
            password="pw",
            expires_at=None,
            ssl_context=None,
            principal="static",
        )


def _mock_aioredis_client():
    """Returns (patch_target, mock_client) for redis.asyncio.from_url."""
    client = MagicMock()
    client.aclose = AsyncMock()
    return client


@pytest.mark.asyncio
async def test_refresh_task_scheduled_when_credential_expires():
    provider = FakeExpiringProvider(ttl_seconds=2.0, window_seconds=0.5)
    cache = RedisCacheProvider(redis_url="redis://h:6379", credential_provider=provider)

    client = _mock_aioredis_client()
    with patch("redis.asyncio.from_url", return_value=client):
        await cache._get_redis()
        assert len(cache._refresh_tasks) == 1

        # Sleep past the refresh horizon (2s ttl - 0.5s window = 1.5s).
        await asyncio.sleep(2.0)

        # Refresh task popped client from cache and called aclose.
        assert client.aclose.await_count >= 1
        # Next _get_redis rebuilds — provider called again.
        with patch("redis.asyncio.from_url", return_value=client):
            await cache._get_redis()
        assert provider.call_count >= 2

    # Cancel any remaining tasks to prevent leaks.
    cache.close()


@pytest.mark.asyncio
async def test_refresh_task_not_scheduled_for_non_expiring_creds():
    provider = NonExpiringProvider()
    cache = RedisCacheProvider(redis_url="redis://h:6379", credential_provider=provider)

    client = _mock_aioredis_client()
    with patch("redis.asyncio.from_url", return_value=client):
        await cache._get_redis()

    assert len(cache._refresh_tasks) == 0
    cache.close()


@pytest.mark.asyncio
async def test_refresh_failure_emits_warning_audit():
    # First call (initial mint) succeeds; the refresh task body will call
    # _emit_refresh_audit directly if the sleep-close-audit chain blows up.
    # We simulate by forcing a refresh task that raises inside its body.
    provider = FakeExpiringProvider(ttl_seconds=2.0, window_seconds=0.5)
    cache = RedisCacheProvider(redis_url="redis://h:6379", credential_provider=provider)

    client = _mock_aioredis_client()
    # Make aclose raise so the refresh body's try-block goes to except.
    client.aclose = AsyncMock(side_effect=RuntimeError("close blew up"))

    captured = []

    async def fake_emit(event_type, severity, **kwargs):
        captured.append((event_type, severity, kwargs))

    with patch("redis.asyncio.from_url", return_value=client), \
         patch("okta_agent_proxy.audit.emit_audit_event", side_effect=fake_emit):
        await cache._get_redis()
        await asyncio.sleep(2.0)

    # Look for either refresh-success (if aclose error was swallowed) or
    # refresh-failed. Both indicate the audit path fires.
    refresh_events = [e for e in captured if e[0] in (
        AuditEventType.REDIS_CREDENTIAL_REFRESH_SUCCESS,
        AuditEventType.REDIS_CREDENTIAL_REFRESH_FAILED,
    )]
    assert len(refresh_events) >= 1
    cache.close()


@pytest.mark.asyncio
async def test_close_cancels_pending_refresh_tasks():
    provider = FakeExpiringProvider(ttl_seconds=60.0, window_seconds=5.0)
    cache = RedisCacheProvider(redis_url="redis://h:6379", credential_provider=provider)

    client = _mock_aioredis_client()
    with patch("redis.asyncio.from_url", return_value=client):
        await cache._get_redis()

    task = next(iter(cache._refresh_tasks.values()))
    assert not task.done()

    cache.close()
    # Give cancellation a tick to propagate.
    await asyncio.sleep(0)
    assert task.cancelled() or task.done()
    assert cache._refresh_tasks == {}


@pytest.mark.asyncio
async def test_refresh_emits_success_audit():
    provider = FakeExpiringProvider(ttl_seconds=1.5, window_seconds=0.3)
    cache = RedisCacheProvider(redis_url="redis://h:6379", credential_provider=provider)

    client = _mock_aioredis_client()
    captured = []

    async def fake_emit(event_type, severity, **kwargs):
        captured.append((event_type, severity, kwargs))

    with patch("redis.asyncio.from_url", return_value=client), \
         patch("okta_agent_proxy.audit.emit_audit_event", side_effect=fake_emit):
        await cache._get_redis()
        await asyncio.sleep(1.8)

    success = [
        e for e in captured
        if e[0] == AuditEventType.REDIS_CREDENTIAL_REFRESH_SUCCESS
    ]
    assert len(success) >= 1
    assert success[0][1] == AuditSeverity.INFO
    cache.close()


class _TwoStepExpiringProvider(RedisCredentialProvider):
    """First call returns short-lived creds; subsequent calls return long-lived.

    Used to verify the refresh audit captures the NEW credential's expiry, not
    the expiring one.
    """

    name = "two-step"

    def __init__(
        self,
        first_ttl_seconds: float = 2.0,
        second_ttl_seconds: float = 900.0,
        window_seconds: float = 0.5,
        first_principal: str = "old-principal",
        second_principal: str = "new-principal",
    ):
        self._first_ttl = first_ttl_seconds
        self._second_ttl = second_ttl_seconds
        self._window = window_seconds
        self._first_principal = first_principal
        self._second_principal = second_principal
        self.call_count = 0

    async def get_credentials(self) -> RedisCredentials:
        self.call_count += 1
        ttl = self._first_ttl if self.call_count == 1 else self._second_ttl
        principal = (
            self._first_principal if self.call_count == 1 else self._second_principal
        )
        return RedisCredentials(
            username="u",
            password=f"pw-{self.call_count}",
            expires_at=datetime.datetime.now(datetime.timezone.utc)
            + datetime.timedelta(seconds=ttl),
            ssl_context=None,
            principal=principal,
        )

    def refresh_safety_window(self) -> datetime.timedelta:
        return datetime.timedelta(seconds=self._window)


class _PeekFailingProvider(RedisCredentialProvider):
    """First call succeeds; second call (the refresh peek) raises."""

    name = "peek-fail"

    def __init__(self, ttl_seconds: float = 2.0, window_seconds: float = 0.5):
        self._ttl = ttl_seconds
        self._window = window_seconds
        self.call_count = 0

    async def get_credentials(self) -> RedisCredentials:
        self.call_count += 1
        if self.call_count >= 2:
            raise RuntimeError("peek failed")
        return RedisCredentials(
            username="u",
            password="pw",
            expires_at=datetime.datetime.now(datetime.timezone.utc)
            + datetime.timedelta(seconds=self._ttl),
            ssl_context=None,
            principal="p",
        )

    def refresh_safety_window(self) -> datetime.timedelta:
        return datetime.timedelta(seconds=self._window)


@pytest.mark.asyncio
async def test_refresh_success_audit_includes_new_expires_at():
    provider = _TwoStepExpiringProvider(
        first_ttl_seconds=2.0, second_ttl_seconds=900.0, window_seconds=0.5
    )
    cache = RedisCacheProvider(redis_url="redis://h:6379", credential_provider=provider)

    client = _mock_aioredis_client()
    captured = []

    async def fake_emit(event_type, severity, **kwargs):
        captured.append((event_type, severity, kwargs))

    with patch("redis.asyncio.from_url", return_value=client), \
         patch("okta_agent_proxy.audit.emit_audit_event", side_effect=fake_emit):
        await cache._get_redis()
        await asyncio.sleep(2.0)

    success = [
        e for e in captured
        if e[0] == AuditEventType.REDIS_CREDENTIAL_REFRESH_SUCCESS
    ]
    assert len(success) >= 1
    details = success[0][2]["details"]
    assert "expires_at" in details
    # Rough window: the second credential's TTL is 900s.
    assert "expires_in_seconds" in details
    assert 800 < details["expires_in_seconds"] < 920
    cache.close()


@pytest.mark.asyncio
async def test_refresh_success_audit_includes_new_principal():
    provider = _TwoStepExpiringProvider(
        first_ttl_seconds=2.0,
        second_ttl_seconds=900.0,
        window_seconds=0.5,
        first_principal="old-p",
        second_principal="new-p",
    )
    cache = RedisCacheProvider(redis_url="redis://h:6379", credential_provider=provider)

    client = _mock_aioredis_client()
    captured = []

    async def fake_emit(event_type, severity, **kwargs):
        captured.append((event_type, severity, kwargs))

    with patch("redis.asyncio.from_url", return_value=client), \
         patch("okta_agent_proxy.audit.emit_audit_event", side_effect=fake_emit):
        await cache._get_redis()
        await asyncio.sleep(2.0)

    success = [
        e for e in captured
        if e[0] == AuditEventType.REDIS_CREDENTIAL_REFRESH_SUCCESS
    ]
    assert len(success) >= 1
    assert success[0][2]["details"]["principal"] == "new-p"
    cache.close()


@pytest.mark.asyncio
async def test_refresh_success_audit_includes_expires_in_seconds():
    provider = _TwoStepExpiringProvider(
        first_ttl_seconds=2.0, second_ttl_seconds=900.0, window_seconds=0.5
    )
    cache = RedisCacheProvider(redis_url="redis://h:6379", credential_provider=provider)

    client = _mock_aioredis_client()
    captured = []

    async def fake_emit(event_type, severity, **kwargs):
        captured.append((event_type, severity, kwargs))

    with patch("redis.asyncio.from_url", return_value=client), \
         patch("okta_agent_proxy.audit.emit_audit_event", side_effect=fake_emit):
        await cache._get_redis()
        await asyncio.sleep(2.0)

    success = [
        e for e in captured
        if e[0] == AuditEventType.REDIS_CREDENTIAL_REFRESH_SUCCESS
    ]
    assert len(success) >= 1
    details = success[0][2]["details"]
    assert isinstance(details.get("expires_in_seconds"), float)
    assert details["expires_in_seconds"] > 0
    cache.close()


@pytest.mark.asyncio
async def test_refresh_peek_failure_does_not_fail_refresh():
    """If the peek-for-audit get_credentials raises, the refresh still
    emits a SUCCESS event (without new_expires_at / new_principal /
    expires_in_seconds) — the expiring client has been closed and the
    next _get_redis() handles the real error if it persists."""
    provider = _PeekFailingProvider(ttl_seconds=2.0, window_seconds=0.5)
    cache = RedisCacheProvider(redis_url="redis://h:6379", credential_provider=provider)

    client = _mock_aioredis_client()
    captured = []

    async def fake_emit(event_type, severity, **kwargs):
        captured.append((event_type, severity, kwargs))

    with patch("redis.asyncio.from_url", return_value=client), \
         patch("okta_agent_proxy.audit.emit_audit_event", side_effect=fake_emit):
        await cache._get_redis()
        await asyncio.sleep(2.0)

    success = [
        e for e in captured
        if e[0] == AuditEventType.REDIS_CREDENTIAL_REFRESH_SUCCESS
    ]
    assert len(success) >= 1
    details = success[0][2]["details"]
    assert "expires_at" not in details
    assert "expires_in_seconds" not in details
    assert "principal" not in details
    cache.close()


@pytest.mark.asyncio
async def test_refresh_failure_audit_omits_expires_fields():
    """A refresh that fails entirely emits a FAILED event with provider
    and error only — no expires_at / expires_in_seconds / principal."""
    provider = FakeExpiringProvider(ttl_seconds=2.0, window_seconds=0.5)
    cache = RedisCacheProvider(redis_url="redis://h:6379", credential_provider=provider)

    client = _mock_aioredis_client()
    # Force the refresh body to hit its except branch by making aclose AND the
    # post-aclose peek raise together.
    client.aclose = AsyncMock(side_effect=RuntimeError("close blew up"))

    captured = []

    async def fake_emit(event_type, severity, **kwargs):
        captured.append((event_type, severity, kwargs))

    # Patch the provider's get_credentials after initial mint to raise too,
    # so any peek inside the success path propagates out of the try block.
    original_get = provider.get_credentials

    call_count = {"n": 0}

    async def counted_get():
        call_count["n"] += 1
        if call_count["n"] >= 2:
            raise RuntimeError("mint blew up")
        return await original_get()

    with patch.object(provider, "get_credentials", counted_get), \
         patch("redis.asyncio.from_url", return_value=client), \
         patch("okta_agent_proxy.audit.emit_audit_event", side_effect=fake_emit):
        await cache._get_redis()
        await asyncio.sleep(2.0)

    # Only look at refresh events; either success (peek failed silently) or
    # failure (outer except). In either case, no expires fields should be set.
    refresh_events = [
        e for e in captured
        if e[0] in (
            AuditEventType.REDIS_CREDENTIAL_REFRESH_SUCCESS,
            AuditEventType.REDIS_CREDENTIAL_REFRESH_FAILED,
        )
    ]
    assert len(refresh_events) >= 1
    for _, _, kwargs in refresh_events:
        details = kwargs["details"]
        assert "expires_at" not in details
        assert "expires_in_seconds" not in details
        assert "principal" not in details
    cache.close()
