"""Contract tests for the Redis credential provider abstraction (P01)."""

import datetime

import pytest

from okta_agent_proxy.audit.events import AuditEventType
from okta_agent_proxy.cache.redis_credentials import (
    CredentialUnavailableError,
    RedisCredentialProvider,
    RedisCredentials,
    get_redis_credential_provider,
)


class _FakeProvider(RedisCredentialProvider):
    name = "fake"

    def __init__(self, raise_exc: bool = False):
        self._raise = raise_exc

    async def get_credentials(self) -> RedisCredentials:
        if self._raise:
            raise CredentialUnavailableError("stub failure")
        return RedisCredentials(
            username=None,
            password="test",
            expires_at=None,
            ssl_context=None,
            principal="fake",
        )


def test_redis_credentials_is_expiring_true_when_expires_at_set():
    creds = RedisCredentials(
        username=None,
        password="p",
        expires_at=datetime.datetime(2030, 1, 1),
        ssl_context=None,
        principal="x",
    )
    assert creds.is_expiring() is True


def test_redis_credentials_is_expiring_false_when_none():
    creds = RedisCredentials(
        username=None,
        password="p",
        expires_at=None,
        ssl_context=None,
        principal="x",
    )
    assert creds.is_expiring() is False


def test_credential_unavailable_error_is_runtime_error():
    assert issubclass(CredentialUnavailableError, RuntimeError)


def test_provider_default_refresh_safety_window_is_60_seconds():
    provider = _FakeProvider()
    assert provider.refresh_safety_window() == datetime.timedelta(seconds=60)


@pytest.mark.asyncio
async def test_provider_health_check_returns_true_when_get_credentials_succeeds():
    provider = _FakeProvider(raise_exc=False)
    assert await provider.health_check() is True


@pytest.mark.asyncio
async def test_provider_health_check_returns_false_when_get_credentials_raises():
    provider = _FakeProvider(raise_exc=True)
    assert await provider.health_check() is False


def test_factory_unknown_mode_raises_valueerror_listing_supported_modes(monkeypatch):
    monkeypatch.setenv("REDIS_AUTH_MODE", "bogus")
    with pytest.raises(ValueError) as exc:
        get_redis_credential_provider()
    msg = str(exc.value)
    assert "bogus" in msg
    assert "static" in msg
    assert "aws-iam" in msg
    assert "azure-entra" in msg
    assert "mtls" in msg
    assert "vault" in msg


def test_factory_unsupported_mode_lists_phase_3_modes(monkeypatch):
    """mtls and vault are Phase 3; factory must name them in the error."""
    monkeypatch.setenv("REDIS_AUTH_MODE", "mtls")
    with pytest.raises(ValueError) as exc:
        get_redis_credential_provider()
    msg = str(exc.value)
    # Supported now
    assert "static" in msg
    assert "aws-iam" in msg
    assert "azure-entra" in msg
    # Phase 3
    assert "mtls" in msg
    assert "vault" in msg


def test_factory_default_mode_is_static(monkeypatch):
    monkeypatch.delenv("REDIS_AUTH_MODE", raising=False)
    sentinel = object()
    from okta_agent_proxy.cache.redis_credential_providers import static as static_mod

    monkeypatch.setattr(
        static_mod.StaticPasswordProvider,
        "from_env",
        classmethod(lambda cls: sentinel),
    )
    result = get_redis_credential_provider()
    assert result is sentinel


def test_factory_aws_iam_constructs_provider_when_env_complete(monkeypatch):
    """With all required AWS env vars set, factory returns AwsIamElastiCacheProvider."""
    monkeypatch.setenv("REDIS_AUTH_MODE", "aws-iam")
    monkeypatch.setenv("REDIS_AWS_USER_ID", "test-user")
    monkeypatch.setenv("REDIS_AWS_CACHE_NAME", "test-cache")
    monkeypatch.setenv("AWS_REGION", "us-west-2")
    monkeypatch.setenv("AWS_ACCESS_KEY_ID", "AKIAIOSFODNN7EXAMPLE")
    monkeypatch.setenv(
        "AWS_SECRET_ACCESS_KEY", "wJalrXUtnFEMI/K7MDENG/bPxRfiCYEXAMPLEKEY"
    )

    provider = get_redis_credential_provider()
    assert provider.name == "aws-iam"


def test_factory_aws_iam_raises_credential_unavailable_when_env_missing(monkeypatch):
    """aws-iam without REDIS_AWS_USER_ID raises CredentialUnavailableError."""
    monkeypatch.setenv("REDIS_AUTH_MODE", "aws-iam")
    monkeypatch.delenv("REDIS_AWS_USER_ID", raising=False)
    monkeypatch.setenv("REDIS_AWS_CACHE_NAME", "test-cache")
    monkeypatch.setenv("AWS_REGION", "us-west-2")

    with pytest.raises(CredentialUnavailableError):
        get_redis_credential_provider()


def test_factory_azure_entra_constructs_provider(monkeypatch):
    """azure-entra mode constructs EntraManagedIdentityProvider.

    Construction of azure-identity credential classes reaches for aiohttp
    via the async transport — mock them so the test is purely about factory
    dispatch, not azure-identity internals.
    """
    import unittest.mock

    monkeypatch.setenv("REDIS_AUTH_MODE", "azure-entra")
    monkeypatch.setenv("REDIS_AZURE_USE_MSI", "false")

    with unittest.mock.patch(
        "okta_agent_proxy.cache.redis_credential_providers.azure_entra.DefaultAzureCredential"
    ):
        provider = get_redis_credential_provider()

    assert provider.name == "azure-entra"


def test_audit_event_types_include_five_new_redis_events():
    values = {e.value for e in AuditEventType}
    assert "redis.credential.minted" in values
    assert "redis.credential.refresh.success" in values
    assert "redis.credential.refresh.failed" in values
    assert "redis.auth.failure" in values
    assert "redis.static_password.used" in values
