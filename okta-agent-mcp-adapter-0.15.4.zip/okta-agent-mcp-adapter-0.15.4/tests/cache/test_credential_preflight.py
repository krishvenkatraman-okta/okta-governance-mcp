"""Tests for the Redis credential startup preflight (P08).

The preflight runs once at app startup, mints a credential through whatever
provider is wired, records the outcome in a module-level dict, and emits
an audit event (success → REDIS_CREDENTIAL_MINTED with preflight=true;
failure → REDIS_CREDENTIAL_REFRESH_FAILED with preflight=true).

We exercise the preflight coroutine directly and assert the recorded state
and the audit emission. The actual Starlette wiring is exercised in
tests/test_health_endpoint_redis.py.
"""

import datetime
import sys
from unittest.mock import AsyncMock, MagicMock

import pytest

from okta_agent_proxy.audit.events import AuditEventType, AuditSeverity
from okta_agent_proxy.cache.redis_credentials import (
    CredentialUnavailableError,
    RedisCredentialProvider,
    RedisCredentials,
)


def _ensure_app_imported():
    mod = sys.modules.get("okta_agent_proxy.app")
    if mod is not None and hasattr(mod, "_redis_credential_preflight"):
        return

    sys.modules.pop("okta_agent_proxy.app", None)

    import okta_agent_proxy.database as _db_mod
    _orig_get = _db_mod.get_config_store
    _orig_store = _db_mod._config_store
    _mock_store = MagicMock()
    _mock_store.get_all_resources.return_value = []
    _mock_store.get_all_agents.return_value = []
    _db_mod.get_config_store = lambda **kw: _mock_store
    _db_mod._config_store = _mock_store
    try:
        import importlib
        import okta_agent_proxy.app
        importlib.reload(okta_agent_proxy.app)
    except Exception:
        sys.modules.pop("okta_agent_proxy.app", None)
        raise
    finally:
        _db_mod.get_config_store = _orig_get
        _db_mod._config_store = _orig_store


@pytest.fixture
def app_mod(monkeypatch):
    """Return the app module with a fresh preflight result dict."""
    _ensure_app_imported()
    from okta_agent_proxy import app as _app
    _app._redis_preflight_result.update({
        "ok": None,
        "provider": None,
        "principal": None,
        "expires_at": None,
        "error": None,
        "checked_at": None,
    })
    return _app


class _FakeStaticProvider(RedisCredentialProvider):
    name = "static"

    async def get_credentials(self) -> RedisCredentials:
        return RedisCredentials(
            username=None,
            password="pw",
            expires_at=None,
            ssl_context=None,
            principal="static",
        )


class _FakeExpiringProvider(RedisCredentialProvider):
    """Returns credentials with fixed known principal and expiry."""

    name = "fake-expiring"

    def __init__(
        self,
        principal: str = "arn:aws:iam::1234:role/test",
        expires_in: int = 900,
    ):
        self._principal = principal
        self._expires_in = expires_in

    async def get_credentials(self) -> RedisCredentials:
        return RedisCredentials(
            username="some-user",
            password="pw",
            expires_at=datetime.datetime.now(datetime.timezone.utc)
            + datetime.timedelta(seconds=self._expires_in),
            ssl_context=None,
            principal=self._principal,
        )


class _FakeFailingProvider(RedisCredentialProvider):
    name = "fake-failing"

    async def get_credentials(self) -> RedisCredentials:
        raise CredentialUnavailableError("boom")


@pytest.mark.asyncio
async def test_preflight_with_memory_cache_marks_ok(app_mod, monkeypatch):
    """CACHE_PROVIDER=memory — provider is None, preflight still marks ok."""
    monkeypatch.setattr(app_mod, "_redis_credential_provider", None)

    await app_mod._redis_credential_preflight()

    assert app_mod._redis_preflight_result["ok"] is True
    assert app_mod._redis_preflight_result["provider"] == "memory"
    assert app_mod._redis_preflight_result["checked_at"] is not None


@pytest.mark.asyncio
async def test_preflight_with_static_provider_marks_ok(app_mod, monkeypatch):
    provider = _FakeStaticProvider()
    monkeypatch.setattr(app_mod, "_redis_credential_provider", provider)
    # Swallow audit emission to keep the test focused on state recording
    monkeypatch.setattr(
        "okta_agent_proxy.audit.emit_audit_event", AsyncMock()
    )

    await app_mod._redis_credential_preflight()

    assert app_mod._redis_preflight_result["ok"] is True
    assert app_mod._redis_preflight_result["provider"] == "static"
    assert app_mod._redis_preflight_result["principal"] == "static"
    assert app_mod._redis_preflight_result["expires_at"] is None


@pytest.mark.asyncio
async def test_preflight_records_principal_and_expires_at(app_mod, monkeypatch):
    provider = _FakeExpiringProvider(
        principal="arn:aws:iam::1234:role/fixed", expires_in=900
    )
    monkeypatch.setattr(app_mod, "_redis_credential_provider", provider)
    monkeypatch.setattr(
        "okta_agent_proxy.audit.emit_audit_event", AsyncMock()
    )

    await app_mod._redis_credential_preflight()

    result = app_mod._redis_preflight_result
    assert result["ok"] is True
    assert result["provider"] == "fake-expiring"
    assert result["principal"] == "arn:aws:iam::1234:role/fixed"
    assert result["expires_at"] is not None


@pytest.mark.asyncio
async def test_preflight_failure_does_not_raise(app_mod, monkeypatch):
    provider = _FakeFailingProvider()
    monkeypatch.setattr(app_mod, "_redis_credential_provider", provider)
    monkeypatch.setattr(
        "okta_agent_proxy.audit.emit_audit_event", AsyncMock()
    )

    # Must NOT raise — preflight failure is recorded, not propagated.
    await app_mod._redis_credential_preflight()

    result = app_mod._redis_preflight_result
    assert result["ok"] is False
    assert result["provider"] == "fake-failing"
    assert "boom" in (result["error"] or "")


@pytest.mark.asyncio
async def test_preflight_failure_emits_warning_audit(app_mod, monkeypatch):
    provider = _FakeFailingProvider()
    monkeypatch.setattr(app_mod, "_redis_credential_provider", provider)

    emit = AsyncMock()
    monkeypatch.setattr("okta_agent_proxy.audit.emit_audit_event", emit)

    await app_mod._redis_credential_preflight()

    assert emit.await_count == 1
    call_args = emit.await_args
    # Positional args: (event_type, severity)
    assert call_args.args[0] == AuditEventType.REDIS_CREDENTIAL_REFRESH_FAILED
    assert call_args.args[1] == AuditSeverity.WARNING
    details = call_args.kwargs["details"]
    assert details["preflight"] is True
    assert details["provider"] == "fake-failing"
    assert "boom" in details["error"]


@pytest.mark.asyncio
async def test_preflight_success_emits_info_audit(app_mod, monkeypatch):
    provider = _FakeExpiringProvider(principal="principal-x", expires_in=900)
    monkeypatch.setattr(app_mod, "_redis_credential_provider", provider)

    emit = AsyncMock()
    monkeypatch.setattr("okta_agent_proxy.audit.emit_audit_event", emit)

    await app_mod._redis_credential_preflight()

    assert emit.await_count == 1
    call_args = emit.await_args
    assert call_args.args[0] == AuditEventType.REDIS_CREDENTIAL_MINTED
    assert call_args.args[1] == AuditSeverity.INFO
    details = call_args.kwargs["details"]
    assert details["preflight"] is True
    assert details["provider"] == "fake-expiring"
    assert details["principal"] == "principal-x"


@pytest.mark.asyncio
async def test_preflight_success_audit_includes_expires_in_seconds(app_mod, monkeypatch):
    """Expiring provider → preflight mint audit carries pre-computed TTL."""
    provider = _FakeExpiringProvider(principal="p", expires_in=900)
    monkeypatch.setattr(app_mod, "_redis_credential_provider", provider)

    emit = AsyncMock()
    monkeypatch.setattr("okta_agent_proxy.audit.emit_audit_event", emit)

    await app_mod._redis_credential_preflight()

    details = emit.await_args.kwargs["details"]
    assert "expires_in_seconds" in details
    assert 890 < details["expires_in_seconds"] < 910


@pytest.mark.asyncio
async def test_preflight_static_provider_omits_expires_in_seconds(app_mod, monkeypatch):
    """Static provider has expires_at=None → expires_in_seconds is absent."""
    provider = _FakeStaticProvider()
    monkeypatch.setattr(app_mod, "_redis_credential_provider", provider)

    emit = AsyncMock()
    monkeypatch.setattr("okta_agent_proxy.audit.emit_audit_event", emit)

    await app_mod._redis_credential_preflight()

    details = emit.await_args.kwargs["details"]
    assert details["preflight"] is True
    assert "expires_in_seconds" not in details
    assert details["expires_at"] is None
