"""Tests for RedisCacheProvider + ResourceMapEventBus credential-provider wiring (P03)."""

import datetime
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from okta_agent_proxy.cache.redis_credentials import (
    RedisCredentialProvider,
    RedisCredentials,
)
from okta_agent_proxy.cache.redis_provider import RedisCacheProvider
from okta_agent_proxy.resources.event_bus import CacheEventBus


class FakeProvider(RedisCredentialProvider):
    name = "fake"

    def __init__(self, username=None, password="fake-pass"):
        self._username = username
        self._password = password

    async def get_credentials(self) -> RedisCredentials:
        return RedisCredentials(
            username=self._username,
            password=self._password,
            expires_at=None,
            ssl_context=None,
            principal="fake-principal",
        )


# ---------------------------------------------------------------------------
# RedisCacheProvider
# ---------------------------------------------------------------------------


def test_redis_provider_strips_url_credentials_when_provider_set():
    stripped = RedisCacheProvider._strip_url_credentials(
        "redis://user:pass@host:6379/0"
    )
    assert stripped == "redis://host:6379/0"


def test_redis_provider_strips_only_password():
    stripped = RedisCacheProvider._strip_url_credentials("redis://:pw@host:6379")
    assert stripped == "redis://host:6379"


def test_redis_provider_noop_when_no_credentials_in_url():
    url = "redis://host:6379/0"
    assert RedisCacheProvider._strip_url_credentials(url) == url


@pytest.mark.asyncio
async def test_redis_provider_passes_username_password_from_provider_to_aioredis():
    provider = FakeProvider(username="alice", password="sekret")
    cache = RedisCacheProvider(
        redis_url="redis://old:ignored@host:6379/0",
        credential_provider=provider,
    )

    fake_client = MagicMock()
    with patch("redis.asyncio.from_url", return_value=fake_client) as from_url_mock, \
         patch("okta_agent_proxy.audit.emit_audit_event", new=AsyncMock()):
        client = await cache._get_redis()

    assert client is fake_client
    from_url_mock.assert_called_once()
    call_args, call_kwargs = from_url_mock.call_args
    # URL has credentials stripped
    assert call_args[0] == "redis://host:6379/0"
    assert call_kwargs["username"] == "alice"
    assert call_kwargs["password"] == "sekret"


@pytest.mark.asyncio
async def test_redis_provider_emits_mint_audit_on_first_get_redis():
    provider = FakeProvider()
    cache = RedisCacheProvider(
        redis_url="redis://host:6379",
        credential_provider=provider,
    )

    fake_client = MagicMock()
    emit_mock = AsyncMock()
    with patch("redis.asyncio.from_url", return_value=fake_client), \
         patch("okta_agent_proxy.audit.emit_audit_event", new=emit_mock):
        await cache._get_redis()

    assert emit_mock.call_count == 1
    args, kwargs = emit_mock.call_args
    # First positional is event type
    from okta_agent_proxy.audit.events import AuditEventType
    assert args[0] == AuditEventType.REDIS_CREDENTIAL_MINTED


@pytest.mark.asyncio
async def test_redis_provider_does_not_re_emit_mint_audit_on_subsequent_calls():
    provider = FakeProvider()
    cache = RedisCacheProvider(
        redis_url="redis://host:6379",
        credential_provider=provider,
    )

    fake_client = MagicMock()
    emit_mock = AsyncMock()
    with patch("redis.asyncio.from_url", return_value=fake_client), \
         patch("okta_agent_proxy.audit.emit_audit_event", new=emit_mock):
        await cache._get_redis()
        await cache._get_redis()
        await cache._get_redis()

    assert emit_mock.call_count == 1


class _ExpiringProvider(RedisCredentialProvider):
    """Returns credentials with a fixed expiry from now."""

    name = "expiring"

    def __init__(self, expires_in_seconds: int = 900, principal: str = "p"):
        self._expires_in = expires_in_seconds
        self._principal = principal

    async def get_credentials(self) -> RedisCredentials:
        return RedisCredentials(
            username="u",
            password="pw",
            expires_at=datetime.datetime.now(datetime.timezone.utc)
            + datetime.timedelta(seconds=self._expires_in),
            ssl_context=None,
            principal=self._principal,
        )


@pytest.mark.asyncio
async def test_redis_provider_mint_audit_includes_expires_in_seconds():
    """SIEM alerting needs expires_in_seconds pre-computed at emit time."""
    provider = _ExpiringProvider(expires_in_seconds=900)
    cache = RedisCacheProvider(
        redis_url="redis://host:6379",
        credential_provider=provider,
    )

    captured: list[dict] = []

    async def fake_emit(event_type, severity, **kwargs):
        captured.append(kwargs.get("details") or {})

    fake_client = MagicMock()
    with patch("redis.asyncio.from_url", return_value=fake_client), \
         patch("okta_agent_proxy.audit.emit_audit_event", side_effect=fake_emit):
        await cache._get_redis()

    assert len(captured) == 1
    details = captured[0]
    assert "expires_in_seconds" in details
    # Clamp loosely — we target ~900s with scheduling jitter.
    assert 890 < details["expires_in_seconds"] < 910
    assert details["expires_at"] is not None


@pytest.mark.asyncio
async def test_redis_provider_mint_audit_omits_expires_in_seconds_for_static():
    """Static provider has expires_at=None → expires_in_seconds is absent."""
    provider = FakeProvider()  # expires_at=None
    cache = RedisCacheProvider(
        redis_url="redis://host:6379",
        credential_provider=provider,
    )

    captured: list[dict] = []

    async def fake_emit(event_type, severity, **kwargs):
        captured.append(kwargs.get("details") or {})

    fake_client = MagicMock()
    with patch("redis.asyncio.from_url", return_value=fake_client), \
         patch("okta_agent_proxy.audit.emit_audit_event", side_effect=fake_emit):
        await cache._get_redis()

    assert len(captured) == 1
    details = captured[0]
    assert "expires_in_seconds" not in details
    assert details["expires_at"] is None


@pytest.mark.asyncio
async def test_redis_provider_legacy_url_only_still_works():
    """Backward-compat: no provider → existing URL-only path still works."""
    cache = RedisCacheProvider(
        redis_url="redis://host:6379",
        credential_provider=None,
    )

    fake_client = MagicMock()
    emit_mock = AsyncMock()
    with patch("redis.asyncio.from_url", return_value=fake_client) as from_url_mock, \
         patch("okta_agent_proxy.audit.emit_audit_event", new=emit_mock):
        client = await cache._get_redis()

    assert client is fake_client
    # No username/password kwargs were injected
    _, call_kwargs = from_url_mock.call_args
    assert "username" not in call_kwargs
    assert "password" not in call_kwargs
    # No mint audit was emitted
    assert emit_mock.call_count == 0


# ---------------------------------------------------------------------------
# ResourceMapEventBus
# ---------------------------------------------------------------------------


def test_event_bus_strips_url_credentials_when_provider_set():
    stripped = CacheEventBus._strip_url_credentials("redis://user:pw@host:6379/0")
    assert stripped == "redis://host:6379/0"


@pytest.mark.asyncio
async def test_event_bus_passes_username_password_from_provider():
    provider = FakeProvider(username="bob", password="bobpw")
    bus = CacheEventBus(
        redis_url="redis://old:ignored@host:6379/0",
        credential_provider=provider,
    )

    fake_client = MagicMock()
    with patch("redis.asyncio.from_url", return_value=fake_client) as from_url_mock:
        client = await bus._build_redis_client()

    assert client is fake_client
    call_args, call_kwargs = from_url_mock.call_args
    assert call_args[0] == "redis://host:6379/0"
    assert call_kwargs["username"] == "bob"
    assert call_kwargs["password"] == "bobpw"
