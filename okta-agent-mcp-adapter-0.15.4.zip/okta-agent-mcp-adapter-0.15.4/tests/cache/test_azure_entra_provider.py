"""Tests for EntraManagedIdentityProvider (P07)."""

import datetime
from unittest.mock import AsyncMock, MagicMock, patch

import jwt as _jwt
import pytest
from azure.core.exceptions import ClientAuthenticationError

from okta_agent_proxy.cache.redis_credential_providers.azure_entra import (
    CLIENT_ID_ENV,
    PRINCIPAL_OID_ENV,
    REDIS_SCOPE,
    USE_MSI_ENV,
    EntraManagedIdentityProvider,
)
from okta_agent_proxy.cache.redis_credentials import CredentialUnavailableError


def _clear_env(monkeypatch):
    for key in (USE_MSI_ENV, CLIENT_ID_ENV, PRINCIPAL_OID_ENV):
        monkeypatch.delenv(key, raising=False)


def _make_fake_token(
    oid: str = "00000000-0000-0000-0000-000000000001",
    appid: str = "test-app-id",
    sub: str = "test-sub",
    expires_in: int = 3600,
    include_oid: bool = True,
    include_appid: bool = True,
    include_sub: bool = True,
) -> str:
    payload: dict = {
        "exp": int(
            (datetime.datetime.now() + datetime.timedelta(seconds=expires_in)).timestamp()
        ),
    }
    if include_oid:
        payload["oid"] = oid
    if include_appid:
        payload["appid"] = appid
    if include_sub:
        payload["sub"] = sub
    return _jwt.encode(payload, "dummy", algorithm="HS256")


def _make_access_token(token_str: str, expires_in: int = 3600):
    """Build an object mimicking azure.core.credentials.AccessToken."""
    obj = MagicMock()
    obj.token = token_str
    obj.expires_on = int(
        (datetime.datetime.now() + datetime.timedelta(seconds=expires_in)).timestamp()
    )
    return obj


# ---------- from_env ----------


def test_from_env_defaults_to_msi(monkeypatch):
    _clear_env(monkeypatch)
    with patch(
        "okta_agent_proxy.cache.redis_credential_providers.azure_entra.ManagedIdentityCredential"
    ) as mic:
        provider = EntraManagedIdentityProvider.from_env()
    assert isinstance(provider, EntraManagedIdentityProvider)
    mic.assert_called_once_with()


def test_from_env_with_msi_false_uses_default_chain(monkeypatch):
    _clear_env(monkeypatch)
    monkeypatch.setenv(USE_MSI_ENV, "false")
    with patch(
        "okta_agent_proxy.cache.redis_credential_providers.azure_entra.DefaultAzureCredential"
    ) as dac:
        provider = EntraManagedIdentityProvider.from_env()
    assert isinstance(provider, EntraManagedIdentityProvider)
    dac.assert_called_once_with()


def test_from_env_picks_up_client_id_for_user_assigned_mi(monkeypatch):
    _clear_env(monkeypatch)
    monkeypatch.setenv(CLIENT_ID_ENV, "my-uami-client-id")
    with patch(
        "okta_agent_proxy.cache.redis_credential_providers.azure_entra.ManagedIdentityCredential"
    ) as mic:
        EntraManagedIdentityProvider.from_env()
    mic.assert_called_once_with(client_id="my-uami-client-id")


def test_from_env_uses_pre_set_principal_oid_when_provided(monkeypatch):
    _clear_env(monkeypatch)
    monkeypatch.setenv(PRINCIPAL_OID_ENV, "preset-oid-1234")
    with patch(
        "okta_agent_proxy.cache.redis_credential_providers.azure_entra.ManagedIdentityCredential"
    ):
        provider = EntraManagedIdentityProvider.from_env()
    assert provider._principal_oid == "preset-oid-1234"


# ---------- get_credentials — happy paths ----------


@pytest.mark.asyncio
async def test_get_credentials_returns_oid_as_username():
    token = _make_fake_token(oid="abc-123")
    fake_cred = MagicMock()
    fake_cred.get_token = AsyncMock(return_value=_make_access_token(token))
    provider = EntraManagedIdentityProvider.__new__(EntraManagedIdentityProvider)
    provider._cred = fake_cred
    provider._principal_oid = None

    creds = await provider.get_credentials()
    assert creds.username == "abc-123"


@pytest.mark.asyncio
async def test_get_credentials_falls_back_to_appid_when_no_oid():
    token = _make_fake_token(appid="app-id-xyz", include_oid=False)
    fake_cred = MagicMock()
    fake_cred.get_token = AsyncMock(return_value=_make_access_token(token))
    provider = EntraManagedIdentityProvider.__new__(EntraManagedIdentityProvider)
    provider._cred = fake_cred
    provider._principal_oid = None

    creds = await provider.get_credentials()
    assert creds.username == "app-id-xyz"


@pytest.mark.asyncio
async def test_get_credentials_falls_back_to_sub_when_no_oid_no_appid():
    token = _make_fake_token(sub="sub-fallback", include_oid=False, include_appid=False)
    fake_cred = MagicMock()
    fake_cred.get_token = AsyncMock(return_value=_make_access_token(token))
    provider = EntraManagedIdentityProvider.__new__(EntraManagedIdentityProvider)
    provider._cred = fake_cred
    provider._principal_oid = None

    creds = await provider.get_credentials()
    assert creds.username == "sub-fallback"


@pytest.mark.asyncio
async def test_get_credentials_raises_when_no_oid_appid_or_sub():
    token = _make_fake_token(
        include_oid=False, include_appid=False, include_sub=False
    )
    fake_cred = MagicMock()
    fake_cred.get_token = AsyncMock(return_value=_make_access_token(token))
    provider = EntraManagedIdentityProvider.__new__(EntraManagedIdentityProvider)
    provider._cred = fake_cred
    provider._principal_oid = None

    with pytest.raises(CredentialUnavailableError) as exc:
        await provider.get_credentials()
    assert "oid" in str(exc.value) or "appid" in str(exc.value) or "sub" in str(exc.value)


@pytest.mark.asyncio
async def test_get_credentials_password_is_token_string():
    token = _make_fake_token()
    fake_cred = MagicMock()
    fake_cred.get_token = AsyncMock(return_value=_make_access_token(token))
    provider = EntraManagedIdentityProvider.__new__(EntraManagedIdentityProvider)
    provider._cred = fake_cred
    provider._principal_oid = None

    creds = await provider.get_credentials()
    assert creds.password == token


@pytest.mark.asyncio
async def test_get_credentials_expires_at_matches_token_exp():
    token = _make_fake_token(expires_in=3600)
    fake_cred = MagicMock()
    fake_cred.get_token = AsyncMock(return_value=_make_access_token(token, expires_in=3600))
    provider = EntraManagedIdentityProvider.__new__(EntraManagedIdentityProvider)
    provider._cred = fake_cred
    provider._principal_oid = None

    creds = await provider.get_credentials()
    now = datetime.datetime.now(datetime.timezone.utc)
    delta = (creds.expires_at - now) - datetime.timedelta(hours=1)
    assert abs(delta.total_seconds()) < 5


@pytest.mark.asyncio
async def test_get_credentials_caches_oid_after_first_call():
    token = _make_fake_token(oid="cached-oid")
    fake_cred = MagicMock()
    fake_cred.get_token = AsyncMock(return_value=_make_access_token(token))
    provider = EntraManagedIdentityProvider.__new__(EntraManagedIdentityProvider)
    provider._cred = fake_cred
    provider._principal_oid = None

    with patch(
        "okta_agent_proxy.cache.redis_credential_providers.azure_entra.jwt.decode",
        wraps=_jwt.decode,
    ) as decode_spy:
        await provider.get_credentials()
        await provider.get_credentials()

    assert fake_cred.get_token.await_count == 2
    assert decode_spy.call_count == 1
    assert provider._principal_oid == "cached-oid"


# ---------- error wrapping ----------


@pytest.mark.asyncio
async def test_get_credentials_wraps_client_authentication_error():
    fake_cred = MagicMock()
    fake_cred.get_token = AsyncMock(
        side_effect=ClientAuthenticationError("IMDS unreachable")
    )
    provider = EntraManagedIdentityProvider.__new__(EntraManagedIdentityProvider)
    provider._cred = fake_cred
    provider._principal_oid = None

    with pytest.raises(CredentialUnavailableError) as exc:
        await provider.get_credentials()
    assert "Entra credential acquisition failed" in str(exc.value)


@pytest.mark.asyncio
async def test_get_credentials_wraps_unexpected_errors():
    fake_cred = MagicMock()
    fake_cred.get_token = AsyncMock(side_effect=RuntimeError("boom"))
    provider = EntraManagedIdentityProvider.__new__(EntraManagedIdentityProvider)
    provider._cred = fake_cred
    provider._principal_oid = None

    with pytest.raises(CredentialUnavailableError) as exc:
        await provider.get_credentials()
    assert "Unexpected error acquiring Entra token" in str(exc.value)


# ---------- misc ----------


def test_refresh_safety_window_is_5_minutes():
    with patch(
        "okta_agent_proxy.cache.redis_credential_providers.azure_entra.ManagedIdentityCredential"
    ):
        provider = EntraManagedIdentityProvider()
    assert provider.refresh_safety_window() == datetime.timedelta(minutes=5)


@pytest.mark.asyncio
async def test_health_check_returns_true_on_success():
    token = _make_fake_token()
    fake_cred = MagicMock()
    fake_cred.get_token = AsyncMock(return_value=_make_access_token(token))
    provider = EntraManagedIdentityProvider.__new__(EntraManagedIdentityProvider)
    provider._cred = fake_cred
    provider._principal_oid = None

    assert await provider.health_check() is True


@pytest.mark.asyncio
async def test_health_check_returns_false_on_failure():
    fake_cred = MagicMock()
    fake_cred.get_token = AsyncMock(side_effect=ClientAuthenticationError("no IMDS"))
    provider = EntraManagedIdentityProvider.__new__(EntraManagedIdentityProvider)
    provider._cred = fake_cred
    provider._principal_oid = None

    assert await provider.health_check() is False


def test_scope_constant_matches_azure_redis_scope():
    assert REDIS_SCOPE == "https://redis.azure.com/.default"
