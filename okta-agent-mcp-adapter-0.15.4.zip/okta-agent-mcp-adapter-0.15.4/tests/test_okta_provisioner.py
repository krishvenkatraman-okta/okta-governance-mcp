"""
Tests for the Okta Client Provisioner.

Validates OIDC application creation and deletion via the Okta Management API
using mocked HTTP transports.
"""

import json
import time
import pytest

import httpx

from okta_agent_proxy.auth.okta_provisioner import (
    OktaClientProvisioner,
    OktaAppResult,
    OktaProvisionerError,
    OktaProvisionerAuthError,
    OktaProvisionerForbiddenError,
    OktaProvisionerRateLimitError,
    OktaProvisionerValidationError,
)


def _sanitized_body(**overrides):
    """Build a sanitized DCR body (output of DCRPolicy.validate)."""
    body = {
        "client_name": "Test MCP Client",
        "redirect_uris": ["http://localhost:9999/callback"],
        "grant_types": ["authorization_code", "refresh_token"],
        "response_types": ["code"],
        "application_type": "web",
        "token_endpoint_auth_method": "client_secret_basic",
    }
    body.update(overrides)
    return body


def _okta_success_transport(
    client_id="0oa_test_123",
    client_secret="secret_xyz",
    issued_at=None,
):
    """Mock transport returning a successful Okta /oauth2/v1/clients response."""
    issued = issued_at or int(time.time())
    response_body = {
        "client_id": client_id,
        "client_secret": client_secret,
        "client_id_issued_at": issued,
        "client_secret_expires_at": 0,
        "client_name": "Test MCP Client",
        "redirect_uris": ["http://localhost:9999/callback"],
        "response_types": ["code"],
        "grant_types": ["authorization_code", "refresh_token"],
        "token_endpoint_auth_method": "client_secret_basic",
        "consent_method": "TRUSTED",
        "application_type": "web",
    }

    def handler(request: httpx.Request) -> httpx.Response:
        return httpx.Response(
            201,
            content=json.dumps(response_body).encode(),
            headers={"content-type": "application/json"},
        )

    return httpx.MockTransport(handler)


def _okta_error_transport(status_code, error_body=None):
    """Mock transport returning an Okta error response."""
    body = error_body or {"errorCode": "E0000001", "errorSummary": "Api error"}

    def handler(request: httpx.Request) -> httpx.Response:
        return httpx.Response(
            status_code,
            content=json.dumps(body).encode(),
            headers={"content-type": "application/json"},
        )

    return httpx.MockTransport(handler)


def _okta_delete_transport(status_code=204):
    """Mock transport for DELETE /oauth2/v1/clients/{id}."""
    def handler(request: httpx.Request) -> httpx.Response:
        return httpx.Response(status_code)

    return httpx.MockTransport(handler)


def _capture_transport(status_code=201, response_body=None):
    """Mock transport that captures the request for assertion."""
    captured = {}
    body = response_body or {
        "client_id": "0oa_captured",
        "client_secret": "sec_captured",
        "client_id_issued_at": int(time.time()),
        "client_secret_expires_at": 0,
    }

    def handler(request: httpx.Request) -> httpx.Response:
        captured["method"] = request.method
        captured["url"] = str(request.url)
        captured["headers"] = dict(request.headers)
        captured["body"] = json.loads(request.content.decode())
        return httpx.Response(
            status_code,
            content=json.dumps(body).encode(),
            headers={"content-type": "application/json"},
        )

    return httpx.MockTransport(handler), captured


class TestOktaProvisionerCreate:
    async def test_successful_creation(self):
        """Successful OIDC app creation returns OktaAppResult."""
        provisioner = OktaClientProvisioner(
            okta_domain="dev-test.okta.com",
            api_token="SSWS_test_token",
            transport=_okta_success_transport(),
        )
        result = await provisioner.create_oidc_app(_sanitized_body())
        assert isinstance(result, OktaAppResult)
        assert result.client_id == "0oa_test_123"
        assert result.client_secret == "secret_xyz"
        assert result.client_secret_expires_at == 0
        assert result.okta_app_id == "0oa_test_123"

    async def test_consent_method_trusted_in_request(self):
        """Verify consent_method=TRUSTED is included in the Okta request."""
        transport, captured = _capture_transport()
        provisioner = OktaClientProvisioner(
            okta_domain="dev-test.okta.com",
            api_token="SSWS_test_token",
            transport=transport,
        )
        await provisioner.create_oidc_app(_sanitized_body())
        assert captured["body"]["consent_method"] == "TRUSTED"

    async def test_ssws_authorization_header(self):
        """Verify SSWS token is sent in Authorization header."""
        transport, captured = _capture_transport()
        provisioner = OktaClientProvisioner(
            okta_domain="dev-test.okta.com",
            api_token="my_ssws_token",
            transport=transport,
        )
        await provisioner.create_oidc_app(_sanitized_body())
        assert captured["headers"]["authorization"] == "SSWS my_ssws_token"

    async def test_correct_okta_url(self):
        """Verify the correct Okta endpoint is called."""
        transport, captured = _capture_transport()
        provisioner = OktaClientProvisioner(
            okta_domain="dev-test.okta.com",
            api_token="token",
            transport=transport,
        )
        await provisioner.create_oidc_app(_sanitized_body())
        assert captured["url"] == "https://dev-test.okta.com/oauth2/v1/clients"

    async def test_request_body_fields(self):
        """Verify the request body includes all expected fields."""
        transport, captured = _capture_transport()
        provisioner = OktaClientProvisioner(
            okta_domain="dev-test.okta.com",
            api_token="token",
            transport=transport,
        )
        await provisioner.create_oidc_app(_sanitized_body(
            client_name="My App",
            redirect_uris=["http://localhost:3000/callback"],
        ))
        body = captured["body"]
        assert body["client_name"] == "My App"
        assert body["redirect_uris"] == ["http://localhost:3000/callback"]
        assert body["response_types"] == ["code"]
        assert body["grant_types"] == ["authorization_code", "refresh_token"]
        assert body["consent_method"] == "TRUSTED"

    async def test_400_validation_error(self):
        """400 from Okta raises OktaProvisionerValidationError."""
        provisioner = OktaClientProvisioner(
            okta_domain="dev-test.okta.com",
            api_token="token",
            transport=_okta_error_transport(400),
        )
        with pytest.raises(OktaProvisionerValidationError):
            await provisioner.create_oidc_app(_sanitized_body())

    async def test_401_auth_error(self):
        """401 from Okta raises OktaProvisionerAuthError."""
        provisioner = OktaClientProvisioner(
            okta_domain="dev-test.okta.com",
            api_token="bad_token",
            transport=_okta_error_transport(401),
        )
        with pytest.raises(OktaProvisionerAuthError):
            await provisioner.create_oidc_app(_sanitized_body())

    async def test_403_forbidden_error(self):
        """403 from Okta raises OktaProvisionerForbiddenError."""
        provisioner = OktaClientProvisioner(
            okta_domain="dev-test.okta.com",
            api_token="token",
            transport=_okta_error_transport(403),
        )
        with pytest.raises(OktaProvisionerForbiddenError):
            await provisioner.create_oidc_app(_sanitized_body())

    async def test_429_rate_limit_error(self):
        """429 from Okta raises OktaProvisionerRateLimitError."""
        provisioner = OktaClientProvisioner(
            okta_domain="dev-test.okta.com",
            api_token="token",
            transport=_okta_error_transport(429),
        )
        with pytest.raises(OktaProvisionerRateLimitError):
            await provisioner.create_oidc_app(_sanitized_body())

    async def test_500_generic_error(self):
        """500 from Okta raises generic OktaProvisionerError."""
        provisioner = OktaClientProvisioner(
            okta_domain="dev-test.okta.com",
            api_token="token",
            transport=_okta_error_transport(500),
        )
        with pytest.raises(OktaProvisionerError):
            await provisioner.create_oidc_app(_sanitized_body())


class TestOktaProvisionerDelete:
    async def test_successful_deletion(self):
        """Successful deletion returns True."""
        provisioner = OktaClientProvisioner(
            okta_domain="dev-test.okta.com",
            api_token="token",
            transport=_okta_delete_transport(204),
        )
        result = await provisioner.delete_oidc_app("0oa_test_123")
        assert result is True

    async def test_deletion_200_also_succeeds(self):
        """200 response on delete also returns True."""
        provisioner = OktaClientProvisioner(
            okta_domain="dev-test.okta.com",
            api_token="token",
            transport=_okta_delete_transport(200),
        )
        result = await provisioner.delete_oidc_app("0oa_test_123")
        assert result is True

    async def test_deletion_401_raises(self):
        """401 on deletion raises auth error."""
        provisioner = OktaClientProvisioner(
            okta_domain="dev-test.okta.com",
            api_token="bad_token",
            transport=_okta_error_transport(401),
        )
        with pytest.raises(OktaProvisionerAuthError):
            await provisioner.delete_oidc_app("0oa_test_123")

    async def test_deletion_429_raises(self):
        """429 on deletion raises rate limit error."""
        provisioner = OktaClientProvisioner(
            okta_domain="dev-test.okta.com",
            api_token="token",
            transport=_okta_error_transport(429),
        )
        with pytest.raises(OktaProvisionerRateLimitError):
            await provisioner.delete_oidc_app("0oa_test_123")

    async def test_delete_url_includes_client_id(self):
        """Verify the delete URL includes the client_id."""
        transport, captured = _capture_transport(status_code=204, response_body={})

        # Override handler for DELETE
        def handler(request: httpx.Request) -> httpx.Response:
            captured["method"] = request.method
            captured["url"] = str(request.url)
            return httpx.Response(204)

        delete_transport = httpx.MockTransport(handler)
        provisioner = OktaClientProvisioner(
            okta_domain="dev-test.okta.com",
            api_token="token",
            transport=delete_transport,
        )
        await provisioner.delete_oidc_app("0oa_abc_789")
        assert captured["url"] == "https://dev-test.okta.com/oauth2/v1/clients/0oa_abc_789"
        assert captured["method"] == "DELETE"
