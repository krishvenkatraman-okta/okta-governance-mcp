"""Tests for the WebhookSink audit sink."""

import asyncio
import json
from datetime import datetime, timezone
from unittest.mock import AsyncMock, MagicMock, patch

import httpx
import pytest

from okta_agent_proxy.audit.events import AuditEvent, AuditEventType, AuditSeverity
from okta_agent_proxy.audit.sinks.webhook import WebhookSink


def _make_event(event_type=AuditEventType.MCP_TOOL_CALL, agent_id="test-agent"):
    return AuditEvent(
        event_type=event_type,
        severity=AuditSeverity.INFO,
        correlation_id="test-corr-123",
        timestamp=datetime(2026, 3, 5, 12, 0, 0, tzinfo=timezone.utc),
        agent_id=agent_id,
        details={"tool_name": "hr-system__get_employee"},
        outcome="success",
    )


class TestWebhookSinkInit:
    def test_properties(self):
        sink = WebhookSink(url="https://splunk:8088/services/collector", token="tok123")
        assert sink.name == "webhook"
        assert sink._url == "https://splunk:8088/services/collector"
        assert sink._token == "tok123"
        assert sink._batch_size == 100
        assert sink._retry_max == 3

    def test_custom_params(self):
        sink = WebhookSink(
            url="https://example.com",
            batch_size=50,
            flush_interval_ms=2000,
            timeout_ms=10000,
            retry_max=5,
        )
        assert sink._batch_size == 50
        assert sink._flush_interval == 2.0
        assert sink._timeout == 10.0
        assert sink._retry_max == 5


class TestNdjsonFormat:
    def test_single_event(self):
        sink = WebhookSink(url="https://example.com")
        event = _make_event()
        body = sink._format_ndjson([event])
        parsed = json.loads(body)
        assert parsed["sourcetype"] == "okta:mcp:audit"
        assert parsed["event"]["event_type"] == "mcp.tool.call"
        assert parsed["event"]["actor"]["agent_id"] == "test-agent"
        assert "time" in parsed

    def test_multiple_events(self):
        sink = WebhookSink(url="https://example.com")
        events = [_make_event(agent_id=f"agent-{i}") for i in range(3)]
        body = sink._format_ndjson(events)
        lines = body.strip().split("\n")
        assert len(lines) == 3
        for i, line in enumerate(lines):
            parsed = json.loads(line)
            assert parsed["event"]["actor"]["agent_id"] == f"agent-{i}"


class TestSendBatch:
    @pytest.mark.asyncio
    async def test_success(self):
        sink = WebhookSink(url="https://example.com", token="tok")
        mock_response = httpx.Response(200, request=httpx.Request("POST", "https://example.com"))
        mock_client = AsyncMock(spec=httpx.AsyncClient)
        mock_client.post = AsyncMock(return_value=mock_response)
        mock_client.is_closed = False
        sink._client = mock_client

        events = [_make_event()]
        await sink._send_batch(events)

        mock_client.post.assert_called_once()
        call_kwargs = mock_client.post.call_args
        assert call_kwargs[0][0] == "https://example.com"
        body = call_kwargs[1]["content"]
        parsed = json.loads(body)
        assert parsed["sourcetype"] == "okta:mcp:audit"

    @pytest.mark.asyncio
    async def test_server_error_retries(self):
        sink = WebhookSink(url="https://example.com", retry_max=3)
        responses = [
            httpx.Response(500, request=httpx.Request("POST", "https://example.com")),
            httpx.Response(503, request=httpx.Request("POST", "https://example.com")),
            httpx.Response(200, request=httpx.Request("POST", "https://example.com")),
        ]
        mock_client = AsyncMock(spec=httpx.AsyncClient)
        mock_client.post = AsyncMock(side_effect=responses)
        mock_client.is_closed = False
        sink._client = mock_client

        with patch("asyncio.sleep", new_callable=AsyncMock):
            await sink._send_batch([_make_event()])

        assert mock_client.post.call_count == 3

    @pytest.mark.asyncio
    async def test_client_error_no_retry(self):
        sink = WebhookSink(url="https://example.com", retry_max=3)
        mock_response = httpx.Response(
            401, request=httpx.Request("POST", "https://example.com")
        )
        mock_client = AsyncMock(spec=httpx.AsyncClient)
        mock_client.post = AsyncMock(return_value=mock_response)
        mock_client.is_closed = False
        sink._client = mock_client

        await sink._send_batch([_make_event()])
        assert mock_client.post.call_count == 1

    @pytest.mark.asyncio
    async def test_network_error_retries(self):
        sink = WebhookSink(url="https://example.com", retry_max=2)
        mock_client = AsyncMock(spec=httpx.AsyncClient)
        mock_client.post = AsyncMock(
            side_effect=httpx.ConnectError("connection refused")
        )
        mock_client.is_closed = False
        sink._client = mock_client

        with patch("asyncio.sleep", new_callable=AsyncMock):
            await sink._send_batch([_make_event()])

        assert mock_client.post.call_count == 2

    @pytest.mark.asyncio
    async def test_all_retries_exhausted_logs_error(self):
        sink = WebhookSink(url="https://example.com", retry_max=2)
        mock_client = AsyncMock(spec=httpx.AsyncClient)
        mock_client.post = AsyncMock(
            side_effect=httpx.ConnectError("down")
        )
        mock_client.is_closed = False
        sink._client = mock_client

        with patch("asyncio.sleep", new_callable=AsyncMock):
            with patch("okta_agent_proxy.audit.sinks.webhook.logger") as mock_logger:
                await sink._send_batch([_make_event(), _make_event()])
                mock_logger.error.assert_called_once()
                assert "2 events dropped" in mock_logger.error.call_args[0][0] % mock_logger.error.call_args[0][1:]


class TestWriteAndBatching:
    @pytest.mark.asyncio
    async def test_write_buffers_until_batch_size(self):
        sink = WebhookSink(url="https://example.com", batch_size=3)
        sink._send_batch = AsyncMock()

        await sink.write(_make_event())
        await sink.write(_make_event())
        sink._send_batch.assert_not_called()

        await sink.write(_make_event())
        sink._send_batch.assert_called_once()
        assert len(sink._send_batch.call_args[0][0]) == 3

    @pytest.mark.asyncio
    async def test_flush_sends_partial_batch(self):
        sink = WebhookSink(url="https://example.com", batch_size=100)
        sink._send_batch = AsyncMock()

        await sink.write(_make_event())
        await sink.write(_make_event())
        sink._send_batch.assert_not_called()

        await sink.flush()
        sink._send_batch.assert_called_once()
        assert len(sink._send_batch.call_args[0][0]) == 2

    @pytest.mark.asyncio
    async def test_flush_empty_buffer_noop(self):
        sink = WebhookSink(url="https://example.com")
        sink._send_batch = AsyncMock()
        await sink.flush()
        sink._send_batch.assert_not_called()

    @pytest.mark.asyncio
    async def test_write_batch_method(self):
        sink = WebhookSink(url="https://example.com", batch_size=5)
        sink._send_batch = AsyncMock()

        events = [_make_event() for _ in range(5)]
        await sink.write_batch(events)
        sink._send_batch.assert_called_once()
        assert len(sink._send_batch.call_args[0][0]) == 5


class TestLifecycle:
    @pytest.mark.asyncio
    async def test_close_flushes_and_closes_client(self):
        sink = WebhookSink(url="https://example.com")
        sink._send_batch = AsyncMock()
        mock_client = AsyncMock(spec=httpx.AsyncClient)
        mock_client.is_closed = False
        sink._client = mock_client

        await sink.write(_make_event())
        await sink.close()

        sink._send_batch.assert_called_once()
        mock_client.aclose.assert_called_once()

    @pytest.mark.asyncio
    async def test_ensure_client_creates_client(self):
        sink = WebhookSink(url="https://example.com", token="tok")
        client = await sink._ensure_client()
        assert isinstance(client, httpx.AsyncClient)
        assert client.headers["authorization"] == "Splunk tok"
        await client.aclose()

    @pytest.mark.asyncio
    async def test_ensure_client_no_token(self):
        sink = WebhookSink(url="https://example.com")
        client = await sink._ensure_client()
        assert "authorization" not in client.headers
        await client.aclose()


class TestInitAuditEmitterWebhook:
    @pytest.mark.asyncio
    async def test_webhook_sink_created_from_env(self):
        env = {
            "AUDIT_ENABLED": "true",
            "AUDIT_SINKS": "webhook",
            "AUDIT_WEBHOOK_URL": "https://splunk:8088/services/collector",
            "AUDIT_WEBHOOK_TOKEN": "test-token",
            "AUDIT_WEBHOOK_BATCH_SIZE": "50",
            "AUDIT_WEBHOOK_FLUSH_INTERVAL_MS": "2000",
            "AUDIT_WEBHOOK_TIMEOUT_MS": "10000",
            "AUDIT_WEBHOOK_RETRY_MAX": "5",
        }
        with patch.dict("os.environ", env, clear=False):
            # Patch the start method to avoid background tasks in tests
            with patch.object(WebhookSink, "start", new_callable=AsyncMock):
                from okta_agent_proxy.audit import init_audit_emitter, shutdown_audit_emitter
                emitter = await init_audit_emitter()
                try:
                    webhook_sinks = [s for s in emitter.sinks if s.name == "webhook"]
                    assert len(webhook_sinks) == 1
                    ws = webhook_sinks[0]
                    assert ws._url == "https://splunk:8088/services/collector"
                    assert ws._token == "test-token"
                    assert ws._batch_size == 50
                    assert ws._flush_interval == 2.0
                    assert ws._timeout == 10.0
                    assert ws._retry_max == 5
                finally:
                    await shutdown_audit_emitter()

    @pytest.mark.asyncio
    async def test_webhook_skipped_without_url(self):
        env = {
            "AUDIT_ENABLED": "true",
            "AUDIT_SINKS": "webhook",
        }
        # Remove AUDIT_WEBHOOK_URL if present
        with patch.dict("os.environ", env, clear=False):
            with patch.dict("os.environ", {"AUDIT_WEBHOOK_URL": ""}, clear=False):
                from okta_agent_proxy.audit import init_audit_emitter, shutdown_audit_emitter
                emitter = await init_audit_emitter()
                try:
                    webhook_sinks = [s for s in emitter.sinks if s.name == "webhook"]
                    assert len(webhook_sinks) == 0
                finally:
                    await shutdown_audit_emitter()
