"""Tests for the audit event system."""

import json
import os
from datetime import datetime, timezone

import pytest

from okta_agent_proxy.audit.events import AuditEvent, AuditEventType, AuditSeverity
from okta_agent_proxy.audit.context import (
    clear_request_context,
    create_audit_event,
    get_correlation_id,
    get_request_context,
    set_request_context,
)


@pytest.fixture(autouse=True)
def _clean_context():
    """Ensure context is clean before and after each test."""
    clear_request_context()
    yield
    clear_request_context()


# --- AuditEvent creation and serialization ---


class TestAuditEvent:
    def test_basic_creation(self):
        event = AuditEvent(
            event_type=AuditEventType.MCP_TOOL_CALL,
            severity=AuditSeverity.INFO,
            correlation_id="req-123",
        )
        assert event.event_type == AuditEventType.MCP_TOOL_CALL
        assert event.severity == AuditSeverity.INFO
        assert event.correlation_id == "req-123"
        assert event.outcome == "success"
        assert event.details == {}
        assert event.agent_id is None

    def test_frozen(self):
        event = AuditEvent(
            event_type=AuditEventType.MCP_TOOL_CALL,
            severity=AuditSeverity.INFO,
            correlation_id="req-123",
        )
        with pytest.raises(AttributeError):
            event.outcome = "failure"  # type: ignore[misc]

    def test_full_creation(self):
        ts = datetime(2026, 1, 1, tzinfo=timezone.utc)
        event = AuditEvent(
            event_type=AuditEventType.AUTH_JWT_REJECTED,
            severity=AuditSeverity.WARNING,
            correlation_id="req-456",
            timestamp=ts,
            agent_id="claude-code",
            user_id="user@example.com",
            client_id="0oa_xxx",
            resource_name="hr-system",
            ip_address="10.0.0.1",
            user_agent="Claude/1.0",
            details={"reason": "expired"},
            outcome="failure",
        )
        assert event.agent_id == "claude-code"
        assert event.resource_name == "hr-system"
        assert event.timestamp == ts

    def test_to_dict_structure(self):
        ts = datetime(2026, 3, 1, 12, 0, 0, tzinfo=timezone.utc)
        event = AuditEvent(
            event_type=AuditEventType.AUTHZ_ACCESS_GRANTED,
            severity=AuditSeverity.INFO,
            correlation_id="corr-1",
            timestamp=ts,
            agent_id="cursor",
            user_id="alice",
            details={"resource": "hr"},
            outcome="success",
        )
        d = event.to_dict()
        assert d["schema_version"] == "1.0"
        assert d["event_type"] == "authz.access.granted"
        assert d["severity"] == "info"
        assert d["severity_id"] == 1
        assert d["time"] == ts.isoformat()
        assert d["correlation_id"] == "corr-1"
        assert d["source"]["service"] == "okta-mcp-adapter"
        assert d["source"]["version"] == "1.0.0"
        assert d["actor"]["agent_id"] == "cursor"
        assert d["actor"]["user_id"] == "alice"
        assert d["details"] == {"resource": "hr"}
        assert d["outcome"] == "success"

    def test_to_dict_omits_none_actor_fields(self):
        event = AuditEvent(
            event_type=AuditEventType.MCP_TOOL_LIST,
            severity=AuditSeverity.INFO,
            correlation_id="corr-2",
            agent_id="claude-code",
        )
        d = event.to_dict()
        assert "agent_id" in d["actor"]
        assert "user_id" not in d["actor"]
        assert "client_id" not in d["actor"]
        assert "ip_address" not in d["actor"]
        assert "user_agent" not in d["actor"]

    def test_to_dict_empty_actor(self):
        event = AuditEvent(
            event_type=AuditEventType.MCP_TOOL_LIST,
            severity=AuditSeverity.INFO,
            correlation_id="corr-3",
        )
        assert event.to_dict()["actor"] == {}

    def test_to_dict_instance_id_from_env(self, monkeypatch):
        monkeypatch.setenv("INSTANCE_ID", "gw-01")
        event = AuditEvent(
            event_type=AuditEventType.MCP_TOOL_CALL,
            severity=AuditSeverity.INFO,
            correlation_id="corr-4",
        )
        assert event.to_dict()["source"]["instance_id"] == "gw-01"

    def test_to_dict_instance_id_default(self, monkeypatch):
        monkeypatch.delenv("INSTANCE_ID", raising=False)
        event = AuditEvent(
            event_type=AuditEventType.MCP_TOOL_CALL,
            severity=AuditSeverity.INFO,
            correlation_id="corr-5",
        )
        assert event.to_dict()["source"]["instance_id"] == "unknown"

    def test_to_json(self):
        event = AuditEvent(
            event_type=AuditEventType.TOKEN_CACHE_HIT,
            severity=AuditSeverity.INFO,
            correlation_id="corr-6",
            agent_id="copilot",
        )
        j = event.to_json()
        parsed = json.loads(j)
        assert parsed["event_type"] == "token.cache.hit"
        assert parsed["actor"]["agent_id"] == "copilot"

    def test_to_json_compact(self):
        event = AuditEvent(
            event_type=AuditEventType.MCP_TOOL_CALL,
            severity=AuditSeverity.INFO,
            correlation_id="c",
        )
        j = event.to_json()
        assert "\n" not in j

    def test_severity_ids(self):
        for sev, expected_id in [
            (AuditSeverity.INFO, 1),
            (AuditSeverity.WARNING, 2),
            (AuditSeverity.CRITICAL, 3),
        ]:
            event = AuditEvent(
                event_type=AuditEventType.MCP_TOOL_CALL,
                severity=sev,
                correlation_id="s",
            )
            assert event.to_dict()["severity_id"] == expected_id


# --- Enum serialization ---


class TestEnumSerialization:
    def test_all_event_types_serializable(self):
        for et in AuditEventType:
            event = AuditEvent(
                event_type=et,
                severity=AuditSeverity.INFO,
                correlation_id="enum-test",
            )
            d = event.to_dict()
            assert isinstance(d["event_type"], str)
            j = event.to_json()
            parsed = json.loads(j)
            assert parsed["event_type"] == et.value

    def test_all_severities_serializable(self):
        for sev in AuditSeverity:
            event = AuditEvent(
                event_type=AuditEventType.MCP_TOOL_CALL,
                severity=sev,
                correlation_id="sev-test",
            )
            d = event.to_dict()
            assert isinstance(d["severity"], str)


# --- Context vars ---


class TestAuditContext:
    def test_default_correlation_id(self):
        assert get_correlation_id() == ""

    def test_set_and_get_context(self):
        set_request_context(
            correlation_id="ctx-1",
            agent_id="claude-code",
            user_id="bob",
            client_id="0oa_abc",
            ip_address="192.168.1.1",
            user_agent="TestAgent/2.0",
        )
        assert get_correlation_id() == "ctx-1"
        ctx = get_request_context()
        assert ctx["correlation_id"] == "ctx-1"
        assert ctx["agent_id"] == "claude-code"
        assert ctx["user_id"] == "bob"
        assert ctx["client_id"] == "0oa_abc"
        assert ctx["ip_address"] == "192.168.1.1"
        assert ctx["user_agent"] == "TestAgent/2.0"

    def test_clear_context(self):
        set_request_context(
            correlation_id="ctx-2",
            agent_id="cursor",
            user_id="alice",
        )
        clear_request_context()
        assert get_correlation_id() == ""
        ctx = get_request_context()
        assert ctx["agent_id"] is None
        assert ctx["user_id"] is None

    def test_partial_context(self):
        set_request_context(correlation_id="ctx-3", agent_id="copilot")
        ctx = get_request_context()
        assert ctx["correlation_id"] == "ctx-3"
        assert ctx["agent_id"] == "copilot"
        assert ctx["user_id"] is None
        assert ctx["client_id"] is None


# --- create_audit_event factory ---


class TestCreateAuditEvent:
    def test_populates_from_context(self):
        set_request_context(
            correlation_id="factory-1",
            agent_id="claude-code",
            user_id="eve",
            client_id="0oa_xyz",
            ip_address="10.1.1.1",
            user_agent="Claude/3.0",
        )
        event = create_audit_event(
            AuditEventType.MCP_TOOL_CALL,
            resource_name="hr-system",
            details={"tool": "get_employee"},
        )
        assert event.correlation_id == "factory-1"
        assert event.agent_id == "claude-code"
        assert event.user_id == "eve"
        assert event.client_id == "0oa_xyz"
        assert event.ip_address == "10.1.1.1"
        assert event.user_agent == "Claude/3.0"
        assert event.resource_name == "hr-system"
        assert event.details == {"tool": "get_employee"}
        assert event.outcome == "success"
        assert event.severity == AuditSeverity.INFO

    def test_custom_severity_and_outcome(self):
        set_request_context(correlation_id="factory-2")
        event = create_audit_event(
            AuditEventType.AUTHZ_ACCESS_DENIED,
            severity=AuditSeverity.WARNING,
            outcome="denied",
        )
        assert event.severity == AuditSeverity.WARNING
        assert event.outcome == "denied"

    def test_empty_context(self):
        event = create_audit_event(AuditEventType.ADMIN_LOGIN)
        assert event.correlation_id == ""
        assert event.agent_id is None
        assert event.user_id is None

    def test_factory_event_serializable(self):
        set_request_context(correlation_id="factory-3", agent_id="test")
        event = create_audit_event(
            AuditEventType.TOKEN_EXCHANGE_SUCCESS,
            resource_name="finance",
            details={"exchange_time_ms": 42},
        )
        parsed = json.loads(event.to_json())
        assert parsed["event_type"] == "token.exchange.success"
        assert parsed["actor"]["agent_id"] == "test"
        assert parsed["details"]["exchange_time_ms"] == 42
