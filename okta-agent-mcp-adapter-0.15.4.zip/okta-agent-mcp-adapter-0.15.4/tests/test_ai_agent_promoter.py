"""
Tests for the AI Agent Promoter.

Validates:
- Promotion success → agent record updated with okta_ai_agent_id
- Promotion with Okta API error → returns None, no crash
- Feature disabled → returns None immediately
- Adapter registration check → success path
- Adapter registration check → agent not found → logged as error
"""

from unittest.mock import AsyncMock, MagicMock, patch

import httpx
import pytest

from okta_agent_proxy.auth.ai_agent_promoter import AIAgentPromoter


def _mock_request(method="POST", url="https://okta.test/api/v1/ai-agents"):
    return httpx.Request(method, url)


def _mock_store():
    store = MagicMock()
    store.update_agent = MagicMock()
    store.update_dcr_registration_ai_agent_id = MagicMock()
    return store


def _promoter(*, auto_register=True, store=None, agent_id="adapter-001",
              owner="owner-uid", api_token="ssws-token"):
    env = {
        "OKTA_AI_AGENT_AUTO_REGISTER": str(auto_register).lower(),
        "OKTA_AI_AGENT_ID": agent_id,
        "OKTA_AI_AGENT_DEFAULT_OWNER": owner,
        "OKTA_API_TOKEN": api_token,
        "OKTA_DOMAIN": "dev-test.okta.com",
    }
    with patch.dict("os.environ", env, clear=False):
        return AIAgentPromoter(store=store or _mock_store())


def _mock_httpx(**responses):
    """Create a mock httpx client that returns configured responses by method."""
    mock_http = AsyncMock()

    if "post" in responses:
        mock_http.post = AsyncMock(return_value=responses["post"])
    else:
        # Default success response
        mock_http.post = AsyncMock(return_value=httpx.Response(
            201,
            json={"id": "agt_promoted_123", "status": "STAGED"},
            request=_mock_request(),
        ))

    if "get" in responses:
        mock_http.get = AsyncMock(return_value=responses["get"])

    mock_http.__aenter__ = AsyncMock(return_value=mock_http)
    mock_http.__aexit__ = AsyncMock(return_value=False)
    return mock_http


class TestAIAgentPromoterPromotion:
    """Tests for promote_to_okta."""

    async def test_promotion_success(self):
        """Successful promotion creates agent and updates store."""
        store = _mock_store()
        promoter = _promoter(store=store)

        # Mock: create agent returns 201, owner assign returns 200
        mock_http = AsyncMock()
        call_count = 0

        async def _route_post(url, **kwargs):
            nonlocal call_count
            call_count += 1
            if "ai-agents" in str(url) and "owners" not in str(url) and "credentials" not in str(url):
                return httpx.Response(
                    201,
                    json={"id": "agt_promoted_123", "status": "STAGED"},
                    request=_mock_request(),
                )
            return httpx.Response(200, json={}, request=_mock_request())

        mock_http.post = AsyncMock(side_effect=_route_post)
        mock_http.__aenter__ = AsyncMock(return_value=mock_http)
        mock_http.__aexit__ = AsyncMock(return_value=False)

        with patch("okta_agent_proxy.auth.ai_agent_promoter.httpx.AsyncClient",
                    return_value=mock_http):
            result = await promoter.promote_to_okta("dcr-test", "Test MCP Client")

        assert result == "agt_promoted_123"
        store.update_agent.assert_called_once_with(
            "dcr-test",
            {"okta_ai_agent_id": "agt_promoted_123"},
            user="ai-agent-promoter",
        )

    async def test_promotion_with_public_jwk(self):
        """Promotion with public_jwk calls credentials endpoint."""
        store = _mock_store()
        promoter = _promoter(store=store)

        mock_http = AsyncMock()
        post_calls = []

        async def _track_post(url, **kwargs):
            post_calls.append(str(url))
            if "credentials" in str(url):
                return httpx.Response(201, json={}, request=_mock_request())
            if "owners" in str(url):
                return httpx.Response(200, json={}, request=_mock_request())
            return httpx.Response(
                201,
                json={"id": "agt_with_cred", "status": "STAGED"},
                request=_mock_request(),
            )

        mock_http.post = AsyncMock(side_effect=_track_post)
        mock_http.__aenter__ = AsyncMock(return_value=mock_http)
        mock_http.__aexit__ = AsyncMock(return_value=False)

        with patch("okta_agent_proxy.auth.ai_agent_promoter.httpx.AsyncClient",
                    return_value=mock_http):
            result = await promoter.promote_to_okta(
                "dcr-test", "Test Client",
                public_jwk={"kty": "RSA", "n": "abc", "e": "AQAB"},
            )

        assert result == "agt_with_cred"
        # Should have called: create, owners, credentials
        assert any("credentials" in url for url in post_calls)

    async def test_promotion_api_error_returns_none(self):
        """Okta API error returns None without crashing."""
        promoter = _promoter()

        error_resp = httpx.Response(
            500,
            json={"errorCode": "E0000009"},
            request=_mock_request(),
        )
        mock_http = _mock_httpx(post=error_resp)

        with patch("okta_agent_proxy.auth.ai_agent_promoter.httpx.AsyncClient",
                    return_value=mock_http):
            result = await promoter.promote_to_okta("dcr-test", "Test Client")

        assert result is None

    async def test_promotion_auto_register_disabled(self):
        """Auto-register disabled returns None."""
        promoter = _promoter(auto_register=False)
        result = await promoter.promote_to_okta("dcr-test", "Test Client")
        assert result is None

    async def test_promotion_network_error(self):
        """Network errors are handled gracefully."""
        promoter = _promoter()

        mock_http = AsyncMock()
        mock_http.post = AsyncMock(side_effect=httpx.ConnectError("connection refused"))
        mock_http.__aenter__ = AsyncMock(return_value=mock_http)
        mock_http.__aexit__ = AsyncMock(return_value=False)

        with patch("okta_agent_proxy.auth.ai_agent_promoter.httpx.AsyncClient",
                    return_value=mock_http):
            result = await promoter.promote_to_okta("dcr-test", "Test Client")

        assert result is None


class TestAIAgentPromoterAdapterCheck:
    """Tests for check_adapter_registration."""

    async def test_adapter_check_success(self):
        """Adapter AI Agent found and active."""
        promoter = _promoter()

        success_resp = httpx.Response(
            200,
            json={"id": "adapter-001", "status": "ACTIVE"},
            request=_mock_request("GET"),
        )
        mock_http = _mock_httpx(get=success_resp)

        with patch("okta_agent_proxy.auth.ai_agent_promoter.httpx.AsyncClient",
                    return_value=mock_http):
            result = await promoter.check_adapter_registration()

        assert result is True

    async def test_adapter_check_not_found(self):
        """Adapter AI Agent not found returns False."""
        promoter = _promoter()

        not_found_resp = httpx.Response(
            404,
            json={"errorCode": "E0000007"},
            request=_mock_request("GET"),
        )
        mock_http = _mock_httpx(get=not_found_resp)

        with patch("okta_agent_proxy.auth.ai_agent_promoter.httpx.AsyncClient",
                    return_value=mock_http):
            result = await promoter.check_adapter_registration()

        assert result is False

    async def test_adapter_check_deactivated(self):
        """Deactivated adapter agent returns False."""
        promoter = _promoter()

        deactivated_resp = httpx.Response(
            200,
            json={"id": "adapter-001", "status": "DEACTIVATED"},
            request=_mock_request("GET"),
        )
        mock_http = _mock_httpx(get=deactivated_resp)

        with patch("okta_agent_proxy.auth.ai_agent_promoter.httpx.AsyncClient",
                    return_value=mock_http):
            result = await promoter.check_adapter_registration()

        assert result is False

    async def test_adapter_check_no_agent_id(self):
        """Missing OKTA_AI_AGENT_ID returns False."""
        promoter = _promoter(agent_id="")
        result = await promoter.check_adapter_registration()
        assert result is False
