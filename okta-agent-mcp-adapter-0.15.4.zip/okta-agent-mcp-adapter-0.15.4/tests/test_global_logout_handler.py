"""Tests for GlobalLogoutHandler orchestrator."""

import asyncio
from typing import List
from unittest.mock import AsyncMock

import pytest

from okta_agent_proxy.audit.events import AuditEvent, AuditEventType, AuditSeverity
from okta_agent_proxy.audit.emitter import AuditEventEmitter
from okta_agent_proxy.audit.sinks.base import AuditSink
from okta_agent_proxy.audit.context import clear_request_context
from okta_agent_proxy.auth.global_logout import (
    GlobalLogoutHandler,
    get_global_logout_handler,
    reset_global_logout_handler,
)


class CaptureSink(AuditSink):
    def __init__(self):
        self.events: List[AuditEvent] = []

    async def write(self, event: AuditEvent) -> None:
        self.events.append(event)

    @property
    def name(self) -> str:
        return "capture"


@pytest.fixture(autouse=True)
def _clean():
    clear_request_context()
    reset_global_logout_handler()
    yield
    clear_request_context()
    reset_global_logout_handler()


@pytest.fixture
async def capture_emitter():
    sink = CaptureSink()
    emitter = AuditEventEmitter(sinks=[sink], flush_interval=0.05)
    await emitter.start()

    import okta_agent_proxy.audit as audit_mod
    old = audit_mod._emitter
    audit_mod._emitter = emitter
    yield sink
    audit_mod._emitter = old
    await emitter.stop()


def _make_handler(tokens_revoked=0, backends=None, relay_revoked=0, unified_terminated=0):
    store = AsyncMock()
    store.aremove_by_user = AsyncMock(return_value=tokens_revoked)

    cache = AsyncMock()
    cache.ainvalidate_all_for_user = AsyncMock(return_value=None)

    sm = AsyncMock()
    sm.terminate_all_for_user = AsyncMock(return_value=backends or {})

    relay = AsyncMock()
    relay.arevoke_by_user = AsyncMock(return_value=relay_revoked)

    registry = AsyncMock()
    registry.revoke = AsyncMock(return_value=None)

    unified = AsyncMock()
    unified.terminate_all_for_user = AsyncMock(return_value=unified_terminated)

    handler = GlobalLogoutHandler(
        token_store=store,
        token_cache=cache,
        session_manager=sm,
        relay=relay,
        revocation_registry=registry,
        unified_handler=unified,
    )
    return handler, store, cache, sm, relay, registry, unified


async def _wait_for(predicate, timeout: float = 1.0, step: float = 0.02):
    end = asyncio.get_event_loop().time() + timeout
    while asyncio.get_event_loop().time() < end:
        if predicate():
            return True
        await asyncio.sleep(step)
    return False


# ---------------- parse_iss_sub_subject ----------------

def test_parse_iss_sub_happy_path():
    iss, sub = GlobalLogoutHandler.parse_iss_sub_subject(
        {"format": "iss_sub", "iss": "https://example.okta.com", "sub": "00u1"}
    )
    assert iss == "https://example.okta.com"
    assert sub == "00u1"


def test_parse_iss_sub_rejects_email_format():
    with pytest.raises(ValueError, match="unsupported subject format"):
        GlobalLogoutHandler.parse_iss_sub_subject(
            {"format": "email", "email": "j@x.com"}
        )


def test_parse_iss_sub_rejects_missing_format():
    with pytest.raises(ValueError, match="missing required 'format'"):
        GlobalLogoutHandler.parse_iss_sub_subject(
            {"iss": "https://x", "sub": "1"}
        )


def test_parse_iss_sub_rejects_missing_iss():
    with pytest.raises(ValueError, match="'iss'"):
        GlobalLogoutHandler.parse_iss_sub_subject(
            {"format": "iss_sub", "sub": "1"}
        )


def test_parse_iss_sub_rejects_missing_sub():
    with pytest.raises(ValueError, match="'sub'"):
        GlobalLogoutHandler.parse_iss_sub_subject(
            {"format": "iss_sub", "iss": "https://x"}
        )


def test_parse_iss_sub_rejects_empty_iss():
    with pytest.raises(ValueError, match="'iss'"):
        GlobalLogoutHandler.parse_iss_sub_subject(
            {"format": "iss_sub", "iss": "   ", "sub": "1"}
        )


def test_parse_iss_sub_rejects_empty_sub():
    with pytest.raises(ValueError, match="'sub'"):
        GlobalLogoutHandler.parse_iss_sub_subject(
            {"format": "iss_sub", "iss": "https://x", "sub": ""}
        )


def test_parse_iss_sub_rejects_non_dict_input():
    with pytest.raises(ValueError, match="JSON object"):
        GlobalLogoutHandler.parse_iss_sub_subject("not-a-dict")


# ---------------- revoke_user ----------------

@pytest.mark.asyncio
async def test_revoke_user_happy_path(capture_emitter):
    handler, store, cache, sm, relay, registry, unified = _make_handler(
        tokens_revoked=2, backends={"hr": True, "finance": True}, relay_revoked=3,
    )
    summary = await handler.revoke_user("00u1", "corr-1")
    await asyncio.sleep(0.15)

    assert summary["tokens_revoked"] == 2
    assert summary["cache_swept"] is True
    assert summary["sessions_terminated"] == 2
    assert summary["sessions_failed"] == 0
    assert summary["backends"] == {"hr": True, "finance": True}
    assert summary["relay_tokens_revoked"] == 3
    assert summary["sub_marked_revoked"] is True

    store.aremove_by_user.assert_awaited_once_with("00u1")
    cache.ainvalidate_all_for_user.assert_awaited_once_with("00u1")
    sm.terminate_all_for_user.assert_awaited_once_with("00u1")
    relay.arevoke_by_user.assert_awaited_once_with("00u1")
    registry.revoke.assert_awaited_once_with("00u1")

    completed = [
        e for e in capture_emitter.events
        if e.event_type == AuditEventType.GLOBAL_LOGOUT_COMPLETED
    ]
    assert len(completed) == 1
    assert completed[0].outcome == "success"
    assert completed[0].severity == AuditSeverity.INFO

    not_found = [
        e for e in capture_emitter.events
        if e.event_type == AuditEventType.GLOBAL_LOGOUT_SUBJECT_NOT_FOUND
    ]
    assert not_found == []


@pytest.mark.asyncio
async def test_revoke_user_no_active_sessions(capture_emitter):
    handler, store, cache, sm, relay, registry, unified = _make_handler(tokens_revoked=2, backends={})
    summary = await handler.revoke_user("00u1", "corr-1")
    await asyncio.sleep(0.15)

    assert summary["tokens_revoked"] == 2
    assert summary["sessions_terminated"] == 0

    not_found = [
        e for e in capture_emitter.events
        if e.event_type == AuditEventType.GLOBAL_LOGOUT_SUBJECT_NOT_FOUND
    ]
    assert not_found == []


@pytest.mark.asyncio
async def test_revoke_user_zero_tokens_zero_sessions_emits_subject_not_found(
    capture_emitter,
):
    handler, _store, _cache, _sm, _relay, _registry, _unified = _make_handler(tokens_revoked=0, backends={})
    summary = await handler.revoke_user("00uUnknown", "corr-nf")
    await asyncio.sleep(0.15)

    assert summary["tokens_revoked"] == 0
    assert summary["sessions_terminated"] == 0

    not_found = [
        e for e in capture_emitter.events
        if e.event_type == AuditEventType.GLOBAL_LOGOUT_SUBJECT_NOT_FOUND
    ]
    assert len(not_found) == 1
    assert not_found[0].details.get("user_sub") == "00uUnknown"


@pytest.mark.asyncio
async def test_revoke_user_partial_session_failure(capture_emitter):
    handler, _store, _cache, _sm, _relay, _registry, _unified = _make_handler(
        tokens_revoked=1, backends={"hr": True, "finance": False}
    )
    summary = await handler.revoke_user("00u1", "corr-part")
    await asyncio.sleep(0.15)

    assert summary["sessions_terminated"] == 1
    assert summary["sessions_failed"] == 1
    assert summary["backends"] == {"hr": True, "finance": False}


@pytest.mark.asyncio
async def test_revoke_user_token_store_raises_emits_failure_and_reraises(
    capture_emitter,
):
    handler, store, cache, sm, relay, registry, unified = _make_handler()
    store.aremove_by_user = AsyncMock(side_effect=RuntimeError("boom"))

    with pytest.raises(RuntimeError, match="boom"):
        await handler.revoke_user("00u1", "corr-err")

    await asyncio.sleep(0.15)

    cache.ainvalidate_all_for_user.assert_not_awaited()
    sm.terminate_all_for_user.assert_not_awaited()

    failure = [
        e for e in capture_emitter.events
        if e.event_type == AuditEventType.GLOBAL_LOGOUT_COMPLETED
        and e.outcome == "failure"
    ]
    assert len(failure) == 1
    assert failure[0].severity == AuditSeverity.WARNING
    assert failure[0].details.get("step") == "token_store"


@pytest.mark.asyncio
async def test_revoke_user_token_cache_raises_emits_failure_and_reraises(
    capture_emitter,
):
    handler, store, cache, sm, relay, registry, unified = _make_handler(tokens_revoked=3)
    cache.ainvalidate_all_for_user = AsyncMock(side_effect=RuntimeError("cache down"))

    with pytest.raises(RuntimeError, match="cache down"):
        await handler.revoke_user("00u1", "corr-err")

    await asyncio.sleep(0.15)

    sm.terminate_all_for_user.assert_not_awaited()

    failure = [
        e for e in capture_emitter.events
        if e.event_type == AuditEventType.GLOBAL_LOGOUT_COMPLETED
        and e.outcome == "failure"
    ]
    assert len(failure) == 1
    assert failure[0].details.get("step") == "token_cache"
    assert failure[0].details.get("tokens_revoked") == 3


@pytest.mark.asyncio
async def test_revoke_user_session_manager_raises_does_not_reraise(capture_emitter):
    handler, _store, _cache, sm, _relay, _registry, _unified = _make_handler(tokens_revoked=2)
    sm.terminate_all_for_user = AsyncMock(side_effect=RuntimeError("sm boom"))

    # Must NOT re-raise — the user is already cut off at Layer 2.
    summary = await handler.revoke_user("00u1", "corr-sm")
    await asyncio.sleep(0.15)

    assert summary["tokens_revoked"] == 2
    assert summary["cache_swept"] is True
    assert summary["sessions_terminated"] == 0
    assert summary["backends"] == {}

    completed_success = [
        e for e in capture_emitter.events
        if e.event_type == AuditEventType.GLOBAL_LOGOUT_COMPLETED
        and e.outcome == "success"
    ]
    assert len(completed_success) == 1


@pytest.mark.asyncio
async def test_revoke_user_relay_failure_does_not_reraise(capture_emitter):
    """Relay purge failure must not break revocation — the user is already cut off."""
    handler, _store, _cache, _sm, relay, registry, _unified = _make_handler(tokens_revoked=1)
    relay.arevoke_by_user = AsyncMock(side_effect=RuntimeError("relay down"))

    summary = await handler.revoke_user("00u1", "corr-r")
    await asyncio.sleep(0.15)

    # Registry is still marked; overall outcome is success.
    assert summary["relay_tokens_revoked"] == 0
    assert summary["sub_marked_revoked"] is True
    registry.revoke.assert_awaited_once_with("00u1")

    completed_success = [
        e for e in capture_emitter.events
        if e.event_type == AuditEventType.GLOBAL_LOGOUT_COMPLETED
        and e.outcome == "success"
    ]
    assert len(completed_success) == 1


@pytest.mark.asyncio
async def test_revoke_user_registry_failure_does_not_reraise(capture_emitter):
    """Registry failure must not break revocation."""
    handler, _store, _cache, _sm, relay, registry, _unified = _make_handler(tokens_revoked=1)
    registry.revoke = AsyncMock(side_effect=RuntimeError("registry down"))

    summary = await handler.revoke_user("00u1", "corr-reg")
    await asyncio.sleep(0.15)

    assert summary["sub_marked_revoked"] is False
    relay.arevoke_by_user.assert_awaited_once_with("00u1")


@pytest.mark.asyncio
async def test_revoke_user_counts_unified_sessions(capture_emitter):
    """Unified handler terminations count toward sessions_terminated."""
    handler, _store, _cache, _sm, _relay, _registry, unified = _make_handler(
        tokens_revoked=1, backends={"hr": True}, unified_terminated=4,
    )
    summary = await handler.revoke_user("00u1", "corr-u")
    await asyncio.sleep(0.15)

    # 1 from MCPSessionManager + 4 from UnifiedMCPHandler
    assert summary["sessions_terminated"] == 5
    unified.terminate_all_for_user.assert_awaited_once_with("00u1")


@pytest.mark.asyncio
async def test_revoke_user_unified_termination_failure_does_not_reraise(capture_emitter):
    handler, _store, _cache, _sm, _relay, _registry, unified = _make_handler(tokens_revoked=1)
    unified.terminate_all_for_user = AsyncMock(side_effect=RuntimeError("unified down"))

    summary = await handler.revoke_user("00u1", "corr-uf")
    await asyncio.sleep(0.15)

    # path-based still counted (0 here); no re-raise
    assert summary["sub_marked_revoked"] is True


def test_singleton_accessor_returns_same_instance():
    h1 = get_global_logout_handler()
    h2 = get_global_logout_handler()
    assert h1 is h2


def test_reset_singleton():
    h1 = get_global_logout_handler()
    reset_global_logout_handler()
    h2 = get_global_logout_handler()
    assert h1 is not h2
