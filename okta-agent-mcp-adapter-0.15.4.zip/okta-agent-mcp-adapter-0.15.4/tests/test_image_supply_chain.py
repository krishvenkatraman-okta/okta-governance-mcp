"""Supply-chain test: the runtime image must not contain SQLA/greenlet.

CHANGELOG v0.15.0 removed SQLAlchemy, Alembic, psycopg2, and greenlet to
eliminate the CWE-121 stack-overflow finding in
``greenlet/TStackState.cpp``. This test asserts the invariant by
delegating to ``scripts/verify_image_clean.sh``.

Skips cleanly if ``docker`` isn't on PATH or if the image hasn't been
built on this host — so developers without docker can still run
``pytest tests/`` without spurious failures. CI must build the image
before this test runs for the assertion to be meaningful.

Override the image tag via ``OKTA_ADAPTER_IMAGE`` env var; default is
``okta-agent-mcp-adapter:latest``.
"""

from __future__ import annotations

import os
import shutil
import subprocess
from pathlib import Path

import pytest


_SCRIPT = (
    Path(__file__).resolve().parents[1] / "scripts" / "verify_image_clean.sh"
)
_DEFAULT_IMAGE = "okta-agent-mcp-adapter:latest"


def _image_tag() -> str:
    return os.environ.get("OKTA_ADAPTER_IMAGE", _DEFAULT_IMAGE)


def _docker_available() -> bool:
    if shutil.which("docker") is None:
        return False
    result = subprocess.run(
        ["docker", "image", "inspect", _image_tag()],
        capture_output=True,
    )
    return result.returncode == 0


@pytest.fixture(scope="module")
def image_tag() -> str:
    if not _SCRIPT.exists():
        pytest.skip(f"verify script not found: {_SCRIPT}")
    if not _docker_available():
        pytest.skip(
            f"docker CLI unavailable or image '{_image_tag()}' not built on this host"
        )
    return _image_tag()


def test_runtime_image_has_no_sqla_or_greenlet(image_tag: str):
    """Image must exit 0 from verify_image_clean.sh."""
    result = subprocess.run(
        [str(_SCRIPT), image_tag],
        capture_output=True,
        text=True,
    )
    if result.returncode != 0:
        # Surface the script's output so CI logs show which probe failed.
        pytest.fail(
            f"verify_image_clean.sh exited {result.returncode}.\n"
            f"--- stdout ---\n{result.stdout}\n"
            f"--- stderr ---\n{result.stderr}"
        )
