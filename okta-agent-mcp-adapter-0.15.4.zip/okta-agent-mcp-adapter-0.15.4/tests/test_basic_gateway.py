"""
Basic gateway tests for Phase 1
Tests routing, caching, and configuration
"""

import pytest
from okta_agent_proxy.routing import ResourceRouter
from okta_agent_proxy.cache import TokenCache
from okta_agent_proxy.config import ResourceConfig, GatewayConfig


class TestTokenCache:
    """Tests for TokenCache"""
    
    def test_cache_initialization(self, token_cache):
        """Test cache initialization"""
        assert token_cache.max_size == 100
        assert token_cache.ttl_seconds == 3600
        assert len(token_cache.cache) == 0
    
    def test_cache_set_and_get(self, token_cache):
        """Test setting and getting a token"""
        user_id = "user123"
        resource = "employees"
        token = "test_token_xyz"

        token_cache.set(user_id, resource, token)
        retrieved = token_cache.get(user_id, resource)

        assert retrieved == token

    def test_cache_miss(self, token_cache):
        """Test cache miss returns None"""
        result = token_cache.get("nonexistent", "resource")
        assert result is None

    def test_cache_invalidate_single(self, token_cache):
        """Test invalidating a single token"""
        user_id = "user123"
        resource = "employees"

        token_cache.set(user_id, resource, "token1")
        token_cache.set(user_id, "partners", "token2")

        token_cache.invalidate(user_id, resource)

        assert token_cache.get(user_id, resource) is None
        assert token_cache.get(user_id, "partners") is not None
    
    def test_cache_invalidate_all_user(self, token_cache):
        """Test invalidating all tokens for a user"""
        user_id = "user123"
        
        token_cache.set(user_id, "employees", "token1")
        token_cache.set(user_id, "partners", "token2")
        
        token_cache.invalidate(user_id)
        
        assert token_cache.get(user_id, "employees") is None
        assert token_cache.get(user_id, "partners") is None
    
    def test_cache_stats(self, token_cache):
        """Test cache statistics"""
        token_cache.set("user1", "backend1", "token1")
        token_cache.set("user2", "backend2", "token2")
        
        stats = token_cache.stats()
        
        assert stats["current_size"] == 2
        assert stats["max_size"] == 100
        assert stats["usage_percent"] == 2.0
        assert stats["ttl_seconds"] == 3600
    
    def test_cache_clear(self, token_cache):
        """Test clearing the cache"""
        token_cache.set("user1", "backend1", "token1")
        token_cache.set("user2", "backend2", "token2")
        
        token_cache.clear()
        
        assert token_cache.get("user1", "backend1") is None
        assert token_cache.get("user2", "backend2") is None


class TestTokenCacheWithService:
    """Tests for TokenCache backed by CacheService"""

    @pytest.fixture
    def service_token_cache(self, cache_service, encryption_service):
        """Create a TokenCache backed by CacheService with encryption."""
        return TokenCache(
            max_size=100,
            ttl_seconds=3600,
            cache_service=cache_service,
            encryption_service=encryption_service,
        )

    def test_set_and_get(self, service_token_cache):
        """Test setting and getting a token via CacheService"""
        service_token_cache.set("user1", "backend1", "tok_abc")
        assert service_token_cache.get("user1", "backend1") == "tok_abc"

    def test_cache_miss(self, service_token_cache):
        """Test cache miss returns None"""
        assert service_token_cache.get("nobody", "backend1") is None

    def test_invalidate_single(self, service_token_cache):
        """Test invalidating a single token via CacheService"""
        service_token_cache.set("user1", "backend1", "tok1")
        service_token_cache.set("user1", "backend2", "tok2")
        service_token_cache.invalidate("user1", "backend1")
        assert service_token_cache.get("user1", "backend1") is None
        assert service_token_cache.get("user1", "backend2") == "tok2"

    def test_invalidate_all_user(self, service_token_cache):
        """Test invalidating all tokens for a user via CacheService"""
        service_token_cache.set("user1", "backend1", "tok1")
        service_token_cache.set("user1", "backend2", "tok2")
        service_token_cache.invalidate("user1")
        assert service_token_cache.get("user1", "backend1") is None
        assert service_token_cache.get("user1", "backend2") is None

    def test_clear(self, service_token_cache):
        """Test clearing the cache via CacheService"""
        service_token_cache.set("user1", "backend1", "tok1")
        service_token_cache.set("user2", "backend2", "tok2")
        service_token_cache.clear()
        assert service_token_cache.get("user1", "backend1") is None
        assert service_token_cache.get("user2", "backend2") is None

    def test_stats_still_works(self, service_token_cache):
        """Stats reports local cache info (not service-level)"""
        stats = service_token_cache.stats()
        assert "current_size" in stats
        assert "max_size" in stats

    def test_encrypted_round_trip(self, service_token_cache):
        """Token should survive encrypt→store→retrieve→decrypt"""
        token = "eyJhbGciOiJSUzI1NiJ9.sensitive_payload.signature"
        service_token_cache.set("user1", "backend1", token)
        assert service_token_cache.get("user1", "backend1") == token

    def test_without_encryption(self, cache_service):
        """CacheService without encryption_service should still work"""
        tc = TokenCache(
            max_size=100,
            ttl_seconds=3600,
            cache_service=cache_service,
            encryption_service=None,
        )
        tc.set("user1", "b1", "plain_token")
        assert tc.get("user1", "b1") == "plain_token"


class TestResourceRouter:
    """Tests for ResourceRouter"""

    def test_router_initialization(self, resource_router):
        """Test router initialization with resources"""
        resources_list = resource_router.list_resources()
        assert "test_backend" in resources_list
        assert resources_list["test_backend"]["url"] == "http://localhost:8001"

    def test_get_resource_for_path(self, resource_router):
        """Test getting resource for a path"""
        resource = resource_router.get_resource_for_path("/test")
        assert resource == "test_backend"

    def test_get_resource_for_path_not_found(self, resource_router):
        """Test resource not found for path"""
        resource = resource_router.get_resource_for_path("/nonexistent")
        assert resource is None

    def test_get_resource_config(self, resource_router, resource_config):
        """Test getting resource configuration"""
        config = resource_router.get_resource_config("test_backend")
        assert config == resource_config
        assert config.url == "http://localhost:8001"

    def test_get_resource_url(self, resource_router):
        """Test getting resource URL"""
        url = resource_router.get_resource_url("test_backend")
        assert url == "http://localhost:8001"

    def test_list_routes(self, resource_router):
        """Test listing all routes"""
        routes = resource_router.list_routes()
        assert routes["/test"] == "test_backend"

    def test_path_with_mcp_suffix(self, mock_env_vars):
        """Test path matching with /mcp suffix"""
        from unittest.mock import patch
        res_config = ResourceConfig(
            name="test",
            url="http://localhost:8001",
            paths=["/hr"],
            description="Test"
        )
        router = ResourceRouter({"test": res_config})

        # Should match /hr and /hr/mcp
        assert router.get_resource_for_path("/hr") == "test"
        assert router.get_resource_for_path("/hr/mcp") == "test"


class TestGatewayConfig:
    """Tests for gateway configuration"""
    
    def test_gateway_config_creation(self, gateway_config):
        """Test creating gateway configuration"""
        assert gateway_config.name == "Okta MCP Gateway"
        assert "test_backend" in gateway_config.resources
    
    def test_gateway_settings_from_env(self, gateway_settings):
        """Test loading settings from environment"""
        assert gateway_settings.okta_domain == "dev-12345.okta.com"
        assert gateway_settings.gateway_port == 8000
    
    def test_resource_config_creation(self, resource_config):
        """Test creating resource configuration"""
        assert resource_config.name == "test_backend"
        assert resource_config.url == "http://localhost:8001"
        assert "/test" in resource_config.paths

