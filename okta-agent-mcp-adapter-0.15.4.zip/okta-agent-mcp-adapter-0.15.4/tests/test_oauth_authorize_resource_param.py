"""Tests for RFC 8707 resource parameter forwarding through oauth_authorize.

Validates that the `resource` query parameter is forwarded into
start_authorization's auth_params for both CIMD and DCR flows.
"""

import sys
from datetime import datetime, timezone
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from okta_agent_proxy.auth.cimd_fetcher import CIMDMetadata
from okta_agent_proxy.auth.client_registry import ClientInfo


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _cimd_client_info(client_id="https://example.com/oauth.json"):
    return ClientInfo(
        client_id=client_id,
        client_name="CIMD Client",
        registration_source="cimd",
        redirect_uris=["http://localhost:9999/callback"],
        grant_types=["authorization_code"],
        response_types=["code"],
        token_endpoint_auth_method="none",
        jwks_uri=None,
        scope=None,
        trust_level="trusted",
        agent_config={"client_id": "0oa_cimd", "client_secret": "cimd_secret"},
        cimd_metadata=CIMDMetadata(
            client_id=client_id,
            client_name="CIMD Client",
            redirect_uris=["http://localhost:9999/callback"],
            grant_types=["authorization_code"],
            response_types=["code"],
            token_endpoint_auth_method="none",
            jwks_uri=None,
            logo_uri=None,
            client_uri=None,
            scope=None,
            domain="example.com",
            fetched_at=datetime.now(timezone.utc),
            raw_json={},
        ),
        resource_access=[],
    )


def _dcr_client_info(client_id="dcr_abc123", agent_config=None):
    return ClientInfo(
        client_id=client_id,
        client_name="DCR Client",
        registration_source="dcr",
        redirect_uris=["http://localhost:9999/callback"],
        grant_types=["authorization_code"],
        response_types=["code"],
        token_endpoint_auth_method="none",
        jwks_uri=None,
        scope=None,
        trust_level=None,
        agent_config=agent_config,
        cimd_metadata=None,
        resource_access=[],
    )


def _mock_request(query_params):
    req = MagicMock()
    req.query_params = query_params

    async def _form():
        return {}

    req.form = _form
    return req


# ---------------------------------------------------------------------------
# Fixture: import app with mocked DB, patch handlers
# ---------------------------------------------------------------------------

def _ensure_app_imported():
    mod = sys.modules.get("okta_agent_proxy.app")
    if mod is not None and hasattr(mod, "client_registry"):
        return

    sys.modules.pop("okta_agent_proxy.app", None)
    import okta_agent_proxy.database as _db_mod
    _orig_get = _db_mod.get_config_store
    _orig_store = _db_mod._config_store
    _mock_store = MagicMock()
    _mock_store.get_all_resources.return_value = []
    _mock_store.get_all_agents.return_value = []
    _db_mod.get_config_store = lambda **kw: _mock_store
    _db_mod._config_store = _mock_store
    try:
        import importlib
        import okta_agent_proxy.app
        importlib.reload(okta_agent_proxy.app)
    except Exception:
        sys.modules.pop("okta_agent_proxy.app", None)
        raise
    finally:
        _db_mod.get_config_store = _orig_get
        _db_mod._config_store = _orig_store


@pytest.fixture
def patched():
    _ensure_app_imported()

    patches_to_start = [
        patch("okta_agent_proxy.app.client_registry"),
        patch("okta_agent_proxy.app.confidential_relay"),
        patch("okta_agent_proxy.app.dcr_handler"),
        patch("okta_agent_proxy.app.emit_audit_event", new_callable=AsyncMock),
        patch("okta_agent_proxy.app.cache_service"),
        patch("okta_agent_proxy.app.config"),
        patch("okta_agent_proxy.app.cimd_fetcher"),
    ]

    started = [p.start() for p in patches_to_start]
    mocks = {
        "registry": started[0],
        "relay": started[1],
        "dcr": started[2],
        "audit": started[3],
        "cache": started[4],
        "config": started[5],
        "cimd_fetcher": started[6],
    }

    mocks["registry"].resolve = AsyncMock(return_value=None)
    mocks["registry"]._resolve_dcr = MagicMock(return_value=None)
    mocks["registry"]._is_cimd_url = staticmethod(
        lambda cid: cid.startswith("https://") or cid.startswith("http://localhost")
    )
    mocks["relay"].start_authorization = AsyncMock(
        return_value="https://okta.example.com/authorize?x=1"
    )
    mocks["dcr"].get_selectable_agents = MagicMock(return_value=[])
    mocks["dcr"].link_to_agent = AsyncMock(return_value=(True, "Linked"))

    yield mocks

    for p in patches_to_start:
        p.stop()


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------

class TestCIMDResourceParam:
    """CIMD flow forwards resource param into auth_params."""

    async def test_resource_param_forwarded_to_relay(self, patched):
        from okta_agent_proxy.app import oauth_authorize

        cimd_info = _cimd_client_info()
        patched["registry"].resolve = AsyncMock(return_value=cimd_info)

        qs = {
            "client_id": "https://example.com/oauth.json",
            "redirect_uri": "http://localhost:9999/callback",
            "state": "s1",
            "scope": "openid",
            "response_type": "code",
            "resource": "https://gateway.example.com/hr",
        }
        req = _mock_request(qs)
        await oauth_authorize(req)

        patched["relay"].start_authorization.assert_awaited_once()
        call_args = patched["relay"].start_authorization.call_args
        auth_params = call_args[0][1]  # second positional arg
        assert auth_params["resource"] == "https://gateway.example.com/hr"

    async def test_resource_param_omitted_not_in_auth_params(self, patched):
        from okta_agent_proxy.app import oauth_authorize

        cimd_info = _cimd_client_info()
        patched["registry"].resolve = AsyncMock(return_value=cimd_info)

        qs = {
            "client_id": "https://example.com/oauth.json",
            "redirect_uri": "http://localhost:9999/callback",
            "state": "s1",
            "scope": "openid",
            "response_type": "code",
        }
        req = _mock_request(qs)
        await oauth_authorize(req)

        patched["relay"].start_authorization.assert_awaited_once()
        call_args = patched["relay"].start_authorization.call_args
        auth_params = call_args[0][1]
        assert "resource" not in auth_params


class TestDCRResourceParam:
    """DCR flow forwards resource param into auth_params."""

    async def test_resource_param_forwarded_for_linked_dcr(self, patched):
        from okta_agent_proxy.app import oauth_authorize

        patched["registry"]._is_cimd_url = staticmethod(lambda cid: False)
        dcr_info = _dcr_client_info(
            agent_config={
                "client_id": "0oa_real",
                "client_secret": "real_secret",
                "agent_name": "test-agent",
            },
        )
        patched["registry"]._resolve_dcr = MagicMock(return_value=dcr_info)

        qs = {
            "client_id": "dcr_abc123",
            "redirect_uri": "http://localhost:9999/callback",
            "state": "s1",
            "scope": "openid",
            "response_type": "code",
            "resource": "https://gateway.example.com/github",
        }
        req = _mock_request(qs)
        await oauth_authorize(req)

        patched["relay"].start_authorization.assert_awaited_once()
        call_args = patched["relay"].start_authorization.call_args
        auth_params = call_args[0][1]
        assert auth_params["resource"] == "https://gateway.example.com/github"

    async def test_resource_param_omitted_not_in_dcr_auth_params(self, patched):
        from okta_agent_proxy.app import oauth_authorize

        patched["registry"]._is_cimd_url = staticmethod(lambda cid: False)
        dcr_info = _dcr_client_info(
            agent_config={
                "client_id": "0oa_real",
                "client_secret": "real_secret",
                "agent_name": "test-agent",
            },
        )
        patched["registry"]._resolve_dcr = MagicMock(return_value=dcr_info)

        qs = {
            "client_id": "dcr_abc123",
            "redirect_uri": "http://localhost:9999/callback",
            "state": "s1",
            "scope": "openid",
            "response_type": "code",
        }
        req = _mock_request(qs)
        await oauth_authorize(req)

        patched["relay"].start_authorization.assert_awaited_once()
        call_args = patched["relay"].start_authorization.call_args
        auth_params = call_args[0][1]
        assert "resource" not in auth_params
