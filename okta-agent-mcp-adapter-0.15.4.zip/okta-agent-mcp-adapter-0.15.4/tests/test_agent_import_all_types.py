"""
Tests for Okta Agent Import handling of all three connection types
with nested response shapes.

Covers:
- _match_connections_to_resources for IDENTITY_ASSERTION_CUSTOM_AS (nested authorizationServer)
- _match_connections_to_resources for STS_VAULT_SECRET (nested secret)
- _match_connections_to_resources for STS_SERVICE_ACCOUNT (nested serviceAccount + app)
- Mixed connection types in a single import
- connections_by_type on ImportableAgent
- Explicit resource_mapping override
- Resource Map store matching for all types
"""

import pytest
from unittest.mock import MagicMock, AsyncMock, patch
from dataclasses import asdict

from okta_agent_proxy.auth.okta_agent_import import (
    OktaAgentImport,
    ImportableAgent,
    ImportResult,
)
from okta_agent_proxy.resources.models import ResourceMapEntry


# ============================================================================
# Fixtures
# ============================================================================

IDENTITY_ASSERTION_CONN = {
    "id": "conn-ia-1",
    "connectionType": "IDENTITY_ASSERTION_CUSTOM_AS",
    "status": "ACTIVE",
    "authorizationServer": {
        "orn": "orn:okta:idp:00o:authorization_servers:aus123",
        "issuerUrl": "https://dev-test.okta.com/oauth2/aus123",
    },
    "resourceIndicator": "orn:okta:idp:00o:authorization_servers:aus123",
    "scopes": ["mcp:read"],
    "scopeCondition": "INCLUDE_ONLY",
}

VAULT_SECRET_CONN = {
    "id": "conn-vs-1",
    "connectionType": "STS_VAULT_SECRET",
    "status": "ACTIVE",
    "secret": {
        "orn": "orn:okta:pam:00o:secrets:uuid-secret-1",
        "name": "slack-api-key",
        "path": "/vault/slack",
    },
    "resourceIndicator": "orn:okta:pam:00o:secrets:uuid-secret-1",
}

SERVICE_ACCOUNT_CONN = {
    "id": "conn-sa-1",
    "connectionType": "STS_SERVICE_ACCOUNT",
    "status": "ACTIVE",
    "serviceAccount": {
        "orn": "orn:okta:pam:00o:service_accounts:uuid-sa-1",
        "name": "jira-bot",
    },
    "app": {
        "orn": "orn:okta:idp:00o:apps:jira:0oa999",
    },
    "resourceIndicator": "orn:okta:pam:00o:apps:jira:0oa999:service_accounts:uuid-sa-1",
}


def _mock_store(resources=None, agents=None, rm_entries=None):
    """Create a mock ResourceConfigStore."""
    store = MagicMock()
    store.get_all_resources.return_value = resources or []
    store.get_all_agents.return_value = agents or []
    store.get_agent.return_value = None
    store.create_agent.return_value = {"agent_id": "test-agent"}
    store.update_agent.return_value = True
    return store


def _mock_rm_store(entries_by_id=None):
    """Create a mock ResourceMapStore."""
    rm = MagicMock()
    entries_by_id = entries_by_id or {}

    def get_by_id(resource_id):
        return entries_by_id.get(resource_id, [])

    rm.get_by_id = get_by_id
    return rm


def _make_importer(store=None, rm_store=None):
    client = MagicMock(spec=["list_agents", "get_agent", "get_agent_connections", "get_linked_app", "check_token_scopes"])
    store = store or _mock_store()
    return OktaAgentImport(client=client, store=store, resource_map_store=rm_store)


# ============================================================================
# _match_connections_to_resources
# ============================================================================

class TestMatchConnectionsAllTypes:

    def test_identity_assertion_via_resource_map(self):
        """IDENTITY_ASSERTION_CUSTOM_AS matched via resource_map store."""
        rm_store = _mock_rm_store({
            "aus123": [ResourceMapEntry(
                resource_id="aus123", name="deploy-server",
                mcp_url="https://deploy.example.com",
            )],
        })
        importer = _make_importer(rm_store=rm_store)
        result = importer._match_connections_to_resources([IDENTITY_ASSERTION_CONN], {})
        assert "deploy-server" in result

    def test_vault_secret_via_resource_map(self):
        """STS_VAULT_SECRET matched via resource_map store."""
        rm_store = _mock_rm_store({
            "uuid-secret-1": [ResourceMapEntry(
                resource_id="uuid-secret-1", name="slack-resource",
                mcp_url="https://slack.example.com",
            )],
        })
        importer = _make_importer(rm_store=rm_store)
        result = importer._match_connections_to_resources([VAULT_SECRET_CONN], {})
        assert "slack-resource" in result

    def test_service_account_via_resource_map(self):
        """STS_SERVICE_ACCOUNT matched via resource_map store."""
        rm_store = _mock_rm_store({
            "uuid-sa-1": [ResourceMapEntry(
                resource_id="uuid-sa-1", name="jira-resource",
                mcp_url="https://jira.example.com",
            )],
        })
        importer = _make_importer(rm_store=rm_store)
        result = importer._match_connections_to_resources([SERVICE_ACCOUNT_CONN], {})
        assert "jira-resource" in result

    def test_mixed_types_all_matched(self):
        """All three connection types matched in a single call."""
        rm_store = _mock_rm_store({
            "aus123": [ResourceMapEntry(
                resource_id="aus123", name="deploy-server",
                mcp_url="https://deploy.example.com",
            )],
            "uuid-secret-1": [ResourceMapEntry(
                resource_id="uuid-secret-1", name="slack-resource",
                mcp_url="https://slack.example.com",
            )],
            "uuid-sa-1": [ResourceMapEntry(
                resource_id="uuid-sa-1", name="jira-resource",
                mcp_url="https://jira.example.com",
            )],
        })
        importer = _make_importer(rm_store=rm_store)
        result = importer._match_connections_to_resources(
            [IDENTITY_ASSERTION_CONN, VAULT_SECRET_CONN, SERVICE_ACCOUNT_CONN], {}
        )
        assert len(result) == 3
        assert "deploy-server" in result
        assert "slack-resource" in result
        assert "jira-resource" in result

    def test_explicit_mapping_override(self):
        """resource_mapping takes priority over auto-matching."""
        conn = {**VAULT_SECRET_CONN, "name": "my-secret-conn"}
        # No RM store needed — mapping takes priority
        importer = _make_importer(rm_store=MagicMock(get_by_id=lambda _: []))
        result = importer._match_connections_to_resources(
            [conn], {"my-secret-conn": "custom-resource"}
        )
        assert result == ["custom-resource"]

    def test_unresolved_connection_returns_empty(self):
        """Connection with no matching resource_map entry returns empty."""
        rm_store = _mock_rm_store({})
        importer = _make_importer(rm_store=rm_store)
        result = importer._match_connections_to_resources([VAULT_SECRET_CONN], {})
        assert result == []

    def test_identity_assertion_legacy_fallback(self):
        """IDENTITY_ASSERTION_CUSTOM_AS falls back to auth_config matching when no RM store."""
        store = _mock_store(resources=[{
            "name": "legacy-resource",
            "auth_config": {"target_authorization_server": "https://dev.okta.com/oauth2/aus123"},
        }])
        # rm_store returns empty — forces legacy fallback
        rm_store = _mock_rm_store({})
        importer = _make_importer(store, rm_store=rm_store)
        result = importer._match_connections_to_resources([IDENTITY_ASSERTION_CONN], {})
        assert "legacy-resource" in result

    def test_no_duplicates(self):
        """One-to-many resource map returns all entries."""
        rm_store = _mock_rm_store({
            "aus123": [
                ResourceMapEntry(resource_id="aus123", name="deploy-server", mcp_url="https://a.com"),
                ResourceMapEntry(resource_id="aus123", name="deploy-server-v2", mcp_url="https://b.com"),
            ],
        })
        importer = _make_importer(rm_store=rm_store)
        result = importer._match_connections_to_resources([IDENTITY_ASSERTION_CONN], {})
        assert "deploy-server" in result
        assert "deploy-server-v2" in result
        assert len(result) == 2


# ============================================================================
# ImportableAgent.connections_by_type
# ============================================================================

class TestConnectionsByType:

    def test_connections_by_type_populated(self):
        agent = ImportableAgent(
            okta_agent_id="agt1",
            name="Test Agent",
            description="",
            status="ACTIVE",
            app_id="0oa1",
            linked_app_client_id="cid1",
            connections_count=3,
            already_imported=False,
            connections_by_type={
                "IDENTITY_ASSERTION_CUSTOM_AS": 1,
                "STS_VAULT_SECRET": 1,
                "STS_SERVICE_ACCOUNT": 1,
            },
        )

        d = asdict(agent)
        assert d["connections_by_type"]["IDENTITY_ASSERTION_CUSTOM_AS"] == 1
        assert d["connections_by_type"]["STS_VAULT_SECRET"] == 1
        assert d["connections_by_type"]["STS_SERVICE_ACCOUNT"] == 1

    def test_connections_by_type_default_empty(self):
        agent = ImportableAgent(
            okta_agent_id="agt1",
            name="Test",
            description="",
            status="ACTIVE",
            app_id=None,
            linked_app_client_id=None,
            connections_count=0,
            already_imported=False,
        )
        assert agent.connections_by_type == {}

    @pytest.mark.asyncio
    async def test_list_importable_populates_connections_by_type(self):
        """list_importable_agents counts connections by type."""
        client = MagicMock()
        client.list_agents = AsyncMock(return_value=[
            {"id": "agt1", "profile": {"name": "Agent 1"}, "status": "ACTIVE"},
        ])
        client.get_agent_connections = AsyncMock(return_value=[
            {"connectionType": "IDENTITY_ASSERTION_CUSTOM_AS", "id": "c1"},
            {"connectionType": "STS_VAULT_SECRET", "id": "c2"},
            {"connectionType": "STS_VAULT_SECRET", "id": "c3"},
        ])
        client.get_linked_app = AsyncMock(return_value=None)

        store = _mock_store()
        importer = OktaAgentImport(client=client, store=store)

        agents = await importer.list_importable_agents("tok")

        assert len(agents) == 1
        assert agents[0].connections_by_type == {
            "IDENTITY_ASSERTION_CUSTOM_AS": 1,
            "STS_VAULT_SECRET": 2,
        }
        assert agents[0].connections_count == 3


# ============================================================================
# get_agent_detail — connection matching for all types
# ============================================================================

class TestGetAgentDetailAllTypes:

    def test_connection_matching_handles_all_types(self):
        """The import module handles all types gracefully with no RM store."""
        # rm_store=None and no app import — should not crash
        rm_store = _mock_rm_store({})
        importer = _make_importer(rm_store=rm_store)
        result = importer._match_connections_to_resources(
            [IDENTITY_ASSERTION_CONN, VAULT_SECRET_CONN, SERVICE_ACCOUNT_CONN],
            {},
        )
        assert isinstance(result, list)
