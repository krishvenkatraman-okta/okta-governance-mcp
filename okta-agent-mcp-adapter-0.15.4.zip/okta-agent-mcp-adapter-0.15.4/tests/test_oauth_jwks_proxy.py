"""Tests for /oauth2/v1/keys JWKS proxy (R4).

Validates:
- 200 + correct body shape from validator.fetch_jwks()
- Cache-Control header with TTL
- application/json content type
- 503 + {"error": "jwks_unavailable"} on upstream failure (never empty keys)
- OAUTH_JWKS_PROXY_HIT on cache hit, OAUTH_JWKS_PROXY_MISS on cache miss
- OAUTH_JWKS_PROXY_MISS (WARNING) on upstream failure
- No extra cache layer wrapping the validator (underlying httpx call happens
  at most once across many requests — the validator's TTLCache owns caching)
- Non-GET methods return 405
"""

import asyncio
import json
import sys
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from okta_agent_proxy.audit.events import AuditEventType, AuditSeverity


SAMPLE_JWKS = {
    "keys": [
        {
            "kty": "RSA",
            "alg": "RS256",
            "use": "sig",
            "kid": "test-kid-1",
            "n": "AQAB-base64-modulus",
            "e": "AQAB",
        }
    ]
}


# ---------------------------------------------------------------------------
# App import fixture (mirrors test_oauth_discovery.py)
# ---------------------------------------------------------------------------

def _ensure_app_imported():
    mod = sys.modules.get("okta_agent_proxy.app")
    if mod is not None and hasattr(mod, "oauth_jwks"):
        return

    sys.modules.pop("okta_agent_proxy.app", None)

    import okta_agent_proxy.database as _db_mod
    _orig_get = _db_mod.get_config_store
    _orig_store = _db_mod._config_store
    _mock_store = MagicMock()
    _mock_store.get_all_resources.return_value = []
    _mock_store.get_all_agents.return_value = []
    _db_mod.get_config_store = lambda **kw: _mock_store
    _db_mod._config_store = _mock_store
    try:
        import importlib
        import okta_agent_proxy.app
        importlib.reload(okta_agent_proxy.app)
    except Exception:
        sys.modules.pop("okta_agent_proxy.app", None)
        raise
    finally:
        _db_mod.get_config_store = _orig_get
        _db_mod._config_store = _orig_store


@pytest.fixture
def patched(monkeypatch):
    """Patch app.validator and app.emit_audit_event for handler-level tests."""
    _ensure_app_imported()

    patches = [
        patch("okta_agent_proxy.app.emit_audit_event", new_callable=AsyncMock),
        patch("okta_agent_proxy.app.validator"),
    ]
    started = [p.start() for p in patches]
    mocks = {"audit": started[0], "validator": started[1]}

    mocks["validator"].fetch_jwks = AsyncMock(return_value=SAMPLE_JWKS)
    mocks["validator"].jwks_cache = {}
    mocks["validator"]._jwks_cache_ttl = 3600

    yield mocks

    for p in patches:
        p.stop()


def _mock_request():
    req = MagicMock()
    req.method = "GET"
    req.client = MagicMock()
    req.client.host = "1.2.3.4"
    headers = MagicMock()
    headers.get = MagicMock(side_effect=lambda k, d="": d)
    req.headers = headers
    return req


async def _call_handler(request):
    from okta_agent_proxy import app as _app
    response = await _app.oauth_jwks(request)
    try:
        body = json.loads(bytes(response.body).decode("utf-8"))
    except Exception:
        body = None
    return response, body


# ---------------------------------------------------------------------------
# Response shape + headers
# ---------------------------------------------------------------------------

class TestResponseShape:

    async def test_returns_200_with_keys_array(self, patched):
        response, body = await _call_handler(_mock_request())
        assert response.status_code == 200
        assert "keys" in body
        assert isinstance(body["keys"], list)
        assert len(body["keys"]) >= 1

    async def test_returned_jwks_matches_validator_output(self, patched):
        _, body = await _call_handler(_mock_request())
        # No transformation — we re-serve exactly what fetch_jwks returned
        assert body == SAMPLE_JWKS

    async def test_cache_control_header_matches_validator_ttl(self, patched):
        patched["validator"]._jwks_cache_ttl = 7200
        response, _ = await _call_handler(_mock_request())
        assert response.headers["cache-control"] == "public, max-age=7200"

    async def test_content_type_is_application_json(self, patched):
        response, _ = await _call_handler(_mock_request())
        assert response.headers["content-type"].startswith("application/json")


# ---------------------------------------------------------------------------
# Upstream failure handling
# ---------------------------------------------------------------------------

class TestUpstreamFailure:

    async def test_returns_503_on_fetch_failure(self, patched):
        patched["validator"].fetch_jwks.side_effect = RuntimeError("okta unreachable")
        response, body = await _call_handler(_mock_request())
        assert response.status_code == 503
        assert body == {"error": "jwks_unavailable"}

    async def test_failure_does_not_return_empty_keys(self, patched):
        patched["validator"].fetch_jwks.side_effect = RuntimeError("okta down")
        _, body = await _call_handler(_mock_request())
        # Critical: MUST NOT synthesize {"keys": []}
        assert "keys" not in body

    async def test_failure_emits_miss_with_warning_severity(self, patched):
        patched["validator"].fetch_jwks.side_effect = RuntimeError("timeout")
        await _call_handler(_mock_request())
        patched["audit"].assert_called_once()
        call = patched["audit"].call_args
        assert call.args[0] == AuditEventType.OAUTH_JWKS_PROXY_MISS
        assert call.kwargs["severity"] == AuditSeverity.WARNING
        assert call.kwargs.get("outcome") == "failure"


# ---------------------------------------------------------------------------
# Audit emission on hit / miss
# ---------------------------------------------------------------------------

class TestAuditEmission:

    async def test_emits_hit_when_cache_prepopulated(self, patched):
        patched["validator"].jwks_cache = {"jwks": SAMPLE_JWKS}
        await _call_handler(_mock_request())
        patched["audit"].assert_called_once()
        call = patched["audit"].call_args
        assert call.args[0] == AuditEventType.OAUTH_JWKS_PROXY_HIT
        assert call.kwargs["details"]["cache_hit"] is True

    async def test_emits_miss_when_cache_empty(self, patched):
        patched["validator"].jwks_cache = {}
        await _call_handler(_mock_request())
        patched["audit"].assert_called_once()
        call = patched["audit"].call_args
        assert call.args[0] == AuditEventType.OAUTH_JWKS_PROXY_MISS
        assert call.kwargs["details"]["cache_hit"] is False


# ---------------------------------------------------------------------------
# No extra cache layer: handler delegates to validator's TTLCache
# ---------------------------------------------------------------------------

class TestNoExtraCacheLayer:
    """The handler MUST NOT wrap the validator in a second cache.

    The validator's own cachetools.TTLCache already deduplicates upstream
    Okta fetches: once jwks_cache["jwks"] is populated, fetch_jwks returns
    it without any httpx traffic. We verify that property still holds when
    driven through the handler — i.e., many sequential requests result in
    exactly one upstream fetch.
    """

    async def test_many_requests_issue_single_upstream_fetch(self):
        """With a real validator + mocked httpx, 10 handler calls == 1 GET."""
        _ensure_app_imported()

        from okta_agent_proxy.auth.okta_validator import OktaTokenValidator
        from okta_agent_proxy import app as _app

        real_validator = OktaTokenValidator(
            okta_domain="dev-test.okta.com",
            issuer="https://dev-test.okta.com",
            jwks_cache_ttl=3600,
        )

        upstream_response = MagicMock()
        upstream_response.json.return_value = SAMPLE_JWKS
        upstream_response.raise_for_status.return_value = None

        async_client = AsyncMock()
        async_client.get = AsyncMock(return_value=upstream_response)

        async_client_ctx = MagicMock()
        async_client_ctx.__aenter__ = AsyncMock(return_value=async_client)
        async_client_ctx.__aexit__ = AsyncMock(return_value=None)

        with patch("okta_agent_proxy.app.validator", real_validator), \
             patch("okta_agent_proxy.app.emit_audit_event", new_callable=AsyncMock), \
             patch(
                 "okta_agent_proxy.auth.okta_validator.httpx.AsyncClient",
                 return_value=async_client_ctx,
             ):
            for _ in range(10):
                response, body = await _call_handler(_mock_request())
                assert response.status_code == 200
                assert body == SAMPLE_JWKS

            assert async_client.get.await_count == 1, (
                f"Expected exactly 1 upstream fetch across 10 handler calls, "
                f"got {async_client.get.await_count}"
            )


# ---------------------------------------------------------------------------
# HTTP method restrictions (routed through TestClient so Starlette enforces 405)
# ---------------------------------------------------------------------------

class TestMethodRestrictions:

    async def test_non_get_returns_405(self):
        _ensure_app_imported()
        from starlette.testclient import TestClient
        from okta_agent_proxy import app as _app

        with patch("okta_agent_proxy.app.validator") as mock_validator, \
             patch("okta_agent_proxy.app.emit_audit_event", new_callable=AsyncMock):
            mock_validator.fetch_jwks = AsyncMock(return_value=SAMPLE_JWKS)
            mock_validator.jwks_cache = {}
            mock_validator._jwks_cache_ttl = 3600

            client = TestClient(_app.app)
            # PUT/DELETE/PATCH aren't accepted by the specific route or the
            # catch-all (/{path:path} only allows GET/POST), so Starlette
            # returns 405. POST is intentionally excluded — the catch-all
            # handler intercepts it and performs MCP proxy-level validation.
            for method in ("PUT", "DELETE", "PATCH"):
                resp = client.request(method, "/oauth2/v1/keys")
                assert resp.status_code == 405, (
                    f"{method} /oauth2/v1/keys should be 405, got {resp.status_code}"
                )
