"""
Tests for agent-scoped tool catalogs in UnifiedMCPHandler.

Verifies that:
- Different agents get different tool catalogs
- Tool catalog cache is scoped per agent_id
- tools/call resolves resources with agent_id
- Agents without connections see no tools for that resource
- Invalidating one agent's catalog doesn't affect another's
"""

import pytest
from unittest.mock import AsyncMock, MagicMock, patch

import cachetools

from okta_agent_proxy.mcp.unified_handler import UnifiedMCPHandler, _TOOL_CACHE_PREFIX


# ============================================================================
# Helpers
# ============================================================================


def _make_handler(router=None, validator=None, store=None, cache_service=None):
    """Create a UnifiedMCPHandler with mocked dependencies."""
    router = router or MagicMock()
    router.resolver = MagicMock()
    router.list_resources.return_value = {}

    validator = validator or MagicMock()
    store = store or MagicMock()
    store.get_all_agents.return_value = []

    handler = UnifiedMCPHandler(
        router=router,
        validator=validator,
        store=store,
        cache_service=cache_service,
    )
    return handler


def _make_resource_config(name, url="https://example.com/mcp", auth_method="pre-shared-key"):
    """Mock resource config returned by resolve_resource."""
    config = MagicMock()
    config.name = name
    config.url = url
    config.auth_method = auth_method
    config.enabled = True
    config.agent_id = None
    config.connection_id = None
    return config


# ============================================================================
# Tests
# ============================================================================


class TestToolCatalogIsolation:

    @pytest.mark.asyncio
    async def test_different_agents_get_different_tool_catalogs(self):
        """Two agents calling tools/list get independently built catalogs."""
        router = MagicMock()
        router.resolver = MagicMock()
        router.list_resources.return_value = {"hr-system": {"url": "https://hr.example.com/mcp"}}

        # Agent A sees hr-system, Agent B does not
        def resolve_side_effect(resource_name, agent_id=None):
            if agent_id == "agent-a" and resource_name == "hr-system":
                return _make_resource_config("hr-system")
            return None

        router.resolve_resource.side_effect = resolve_side_effect

        handler = _make_handler(router=router)

        # Mock auth headers + tool discovery
        with patch.object(handler, "_get_resource_auth_headers", new_callable=AsyncMock) as mock_auth, \
             patch.object(handler, "_discover_tools", new_callable=AsyncMock) as mock_discover, \
             patch("okta_agent_proxy.mcp.unified_handler.emit_audit_event", new_callable=AsyncMock):

            mock_auth.return_value = {"Authorization": "Bearer tok"}
            mock_discover.return_value = [{"name": "get_employee", "description": "Get employee", "inputSchema": {}}]

            # Agent A gets tools
            body_a, status_a, _ = await handler._handle_tools_list("req-1", "agent-a", {}, "user-1", "tok")
            tools_a = body_a["result"]["tools"]
            assert len(tools_a) == 1
            assert tools_a[0]["name"] == "hr-system__get_employee"

            # Clear caches between agents
            handler._tool_cache.clear()

            # Agent B gets no tools (resolve_resource returns None for B)
            body_b, status_b, _ = await handler._handle_tools_list("req-2", "agent-b", {}, "user-1", "tok")
            tools_b = body_b["result"]["tools"]
            assert len(tools_b) == 0

    @pytest.mark.asyncio
    async def test_tool_catalog_cache_scoped_to_agent(self):
        """Agent A's cached catalog is NOT served to Agent B."""
        handler = _make_handler()

        # Pre-populate cache for agent-a
        catalog_a = {
            "tools": [{"name": "hr-system__get_employee"}],
            "tool_map": {"hr-system__get_employee": ("hr-system", "get_employee")},
        }
        handler._tool_cache["agent-a"] = catalog_a

        # Agent A gets cached result
        cached_a = await handler._get_tool_catalog("agent-a")
        assert cached_a is not None
        assert len(cached_a["tools"]) == 1

        # Agent B gets nothing (different cache key)
        cached_b = await handler._get_tool_catalog("agent-b")
        assert cached_b is None

    @pytest.mark.asyncio
    async def test_tools_call_uses_agent_scoped_resource(self):
        """tools/call passes agent_id to resolve_resource."""
        router = MagicMock()
        router.resolver = MagicMock()
        config = _make_resource_config("hr-system")
        router.resolve_resource.return_value = config

        handler = _make_handler(router=router)

        with patch.object(handler, "_get_resource_auth_headers", new_callable=AsyncMock) as mock_auth, \
             patch("okta_agent_proxy.mcp.unified_handler.emit_audit_event", new_callable=AsyncMock), \
             patch("okta_agent_proxy.mcp.unified_handler.httpx.AsyncClient") as mock_client_cls, \
             patch("okta_agent_proxy.auth.agent_authz.check_agent_can_access_resource", new_callable=AsyncMock):

            mock_auth.return_value = {"Authorization": "Bearer tok"}

            # Mock HTTP response
            mock_response = MagicMock()
            mock_response.status_code = 200
            mock_response.headers = {"content-type": "application/json"}
            mock_response.json.return_value = {
                "jsonrpc": "2.0", "id": "1",
                "result": {"content": [{"type": "text", "text": "OK"}]},
            }
            mock_client = AsyncMock()
            mock_client.post.return_value = mock_response
            mock_client_cls.return_value.__aenter__ = AsyncMock(return_value=mock_client)
            mock_client_cls.return_value.__aexit__ = AsyncMock(return_value=None)

            # Mock session
            with patch.object(handler, "_get_resource_session", new_callable=AsyncMock, return_value="sess-1"):
                await handler._handle_tools_call(
                    "req-1",
                    {"name": "hr-system__get_employee", "arguments": {}},
                    "agent-a", {"agent_id": "agent-a"}, "user-1", "tok"
                )

        # Verify resolve_resource was called with agent_id
        router.resolve_resource.assert_called_once_with("hr-system", agent_id="agent-a")

    @pytest.mark.asyncio
    async def test_agent_without_connection_sees_no_tools_for_resource(self):
        """Agent without a connection to a resource gets 0 tools from it."""
        router = MagicMock()
        router.resolver = MagicMock()
        router.list_resources.return_value = {"hr-system": {"url": "https://hr.example.com/mcp"}}
        router.resolve_resource.return_value = None  # Agent has no access

        handler = _make_handler(router=router)

        with patch("okta_agent_proxy.mcp.unified_handler.emit_audit_event", new_callable=AsyncMock):
            body, status, _ = await handler._handle_tools_list("req-1", "agent-no-access", {}, "user-1", "tok")

        tools = body["result"]["tools"]
        assert len(tools) == 0

    @pytest.mark.asyncio
    async def test_tool_catalog_invalidation_scoped(self):
        """Invalidating Agent A's catalog doesn't affect Agent B's."""
        handler = _make_handler()

        # Pre-populate caches for both agents
        handler._tool_cache["agent-a"] = {"tools": [{"name": "tool-a"}], "tool_map": {}}
        handler._tool_cache["agent-b"] = {"tools": [{"name": "tool-b"}], "tool_map": {}}

        # Invalidate only agent-a
        handler.invalidate_tool_cache(agent_id="agent-a")

        assert "agent-a" not in handler._tool_cache
        assert "agent-b" in handler._tool_cache
        assert handler._tool_cache["agent-b"]["tools"][0]["name"] == "tool-b"

    @pytest.mark.asyncio
    async def test_tool_catalog_invalidation_all(self):
        """Invalidating without agent_id clears all catalogs."""
        handler = _make_handler()

        handler._tool_cache["agent-a"] = {"tools": [{"name": "tool-a"}], "tool_map": {}}
        handler._tool_cache["agent-b"] = {"tools": [{"name": "tool-b"}], "tool_map": {}}

        handler.invalidate_tool_cache()

        assert len(handler._tool_cache) == 0

    @pytest.mark.asyncio
    async def test_cache_service_key_includes_agent_id(self):
        """CacheService key for tool catalog includes agent_id."""
        cache_service = AsyncMock()
        cache_service.get.return_value = None
        cache_service.set = AsyncMock()

        handler = _make_handler(cache_service=cache_service)

        # Try to get catalog — should use agent_id in key
        await handler._get_tool_catalog("agent-xyz")
        cache_service.get.assert_called_once_with(f"{_TOOL_CACHE_PREFIX}agent-xyz")

        # Store catalog — should use agent_id in key
        catalog = {"tools": [], "tool_map": {}}
        await handler._set_tool_catalog("agent-xyz", catalog)
        cache_service.set.assert_called_once()
        call_args = cache_service.set.call_args
        assert call_args[0][0] == f"{_TOOL_CACHE_PREFIX}agent-xyz"
