"""
Tests for ConsentTransaction model and ConsentTransactionStore.
"""

import time
import uuid
import pytest

from okta_agent_proxy.auth.consent_transaction import (
    ConsentConnectionStatus,
    ConsentTransaction,
    ConsentTransactionStore,
)


def _make_store():
    return ConsentTransactionStore()


def _create_tx(store, **overrides):
    defaults = dict(
        original_redirect_uri="http://localhost:9999/callback",
        original_state="state_abc",
        original_client_id="https://app.example.com/oauth.json",
        id_token="idt_123",
        access_token="at_123",
        refresh_token="rt_123",
        agent_id="agent-1",
        agent_config={"client_id": "0oa_xyz"},
        ip_address="192.168.1.1",
        user_agent_hash="abcdef1234567890",
    )
    defaults.update(overrides)
    return store.create(**defaults)


class TestConsentTransactionStore:
    def test_create_generates_uuid_and_session_id(self):
        store = _make_store()
        tx = _create_tx(store)

        # transaction_id is a valid UUID
        uuid.UUID(tx.transaction_id)
        # session_id is a non-empty urlsafe string
        assert len(tx.session_id) > 20
        assert tx.status == "verifying"
        assert tx.original_client_id == "https://app.example.com/oauth.json"

    def test_get_by_id_returns_transaction(self):
        store = _make_store()
        tx = _create_tx(store)

        result = store.get_by_id(tx.transaction_id)
        assert result is tx

    def test_get_by_id_returns_none_for_unknown(self):
        store = _make_store()
        assert store.get_by_id("nonexistent") is None

    def test_get_by_id_returns_none_and_removes_expired(self):
        store = _make_store()
        tx = _create_tx(store)

        # Expire by backdating created_at
        tx.created_at = time.monotonic() - 700

        assert store.get_by_id(tx.transaction_id) is None
        # Should be removed from both indices
        assert tx.transaction_id not in store._by_id
        assert tx.session_id not in store._by_session

    def test_get_by_session_returns_transaction(self):
        store = _make_store()
        tx = _create_tx(store)

        result = store.get_by_session(tx.session_id)
        assert result is tx

    def test_validate_session_success(self):
        store = _make_store()
        tx = _create_tx(store)

        result = store.validate_session(tx.session_id, "192.168.1.1", "abcdef1234567890")
        assert result is tx

    def test_validate_session_ip_mismatch_returns_none(self):
        store = _make_store()
        tx = _create_tx(store)

        result = store.validate_session(tx.session_id, "10.0.0.99", "abcdef1234567890")
        assert result is None

    def test_validate_session_ua_mismatch_returns_none(self):
        store = _make_store()
        tx = _create_tx(store)

        result = store.validate_session(tx.session_id, "192.168.1.1", "different_hash_xx")
        assert result is None

    def test_validate_session_expired_returns_none(self):
        store = _make_store()
        tx = _create_tx(store)
        tx.created_at = time.monotonic() - 700

        result = store.validate_session(tx.session_id, "192.168.1.1", "abcdef1234567890")
        assert result is None

    def test_validate_session_unknown_returns_none(self):
        store = _make_store()
        assert store.validate_session("unknown_session", "1.2.3.4", "hash") is None

    def test_remove_clears_both_indices(self):
        store = _make_store()
        tx = _create_tx(store)

        store.remove(tx.transaction_id)

        assert store.get_by_id(tx.transaction_id) is None
        assert store.get_by_session(tx.session_id) is None

    def test_cleanup_removes_expired(self):
        store = _make_store()
        tx1 = _create_tx(store)
        tx2 = _create_tx(store)

        # Expire tx1
        tx1.created_at = time.monotonic() - 700

        # Creating a new tx triggers cleanup
        tx3 = _create_tx(store)

        assert store.get_by_id(tx1.transaction_id) is None
        assert store.get_by_id(tx2.transaction_id) is tx2
        assert store.get_by_id(tx3.transaction_id) is tx3

    def test_create_stores_target_resource(self):
        store = _make_store()
        tx = _create_tx(store, target_resource="https://gateway.example.com/hr")
        assert tx.target_resource == "https://gateway.example.com/hr"

    def test_create_target_resource_defaults_to_none(self):
        store = _make_store()
        tx = _create_tx(store)
        assert tx.target_resource is None


class TestConsentTransactionProperties:
    def test_pending_consents_property(self):
        tx = ConsentTransaction(
            transaction_id="tx-1",
            session_id="sess-1",
            original_redirect_uri="http://localhost/cb",
            original_state="s",
            original_client_id="cid",
            id_token="idt",
            access_token="at",
            connections=[
                ConsentConnectionStatus(
                    connection_id="c1", resource_name="r1",
                    provider="GitHub", resource_indicator="orn:1",
                    status="verified",
                ),
                ConsentConnectionStatus(
                    connection_id="c2", resource_name="r2",
                    provider="Jira", resource_indicator="orn:2",
                    status="consent_required",
                    interaction_uri="https://okta.example.com/consent",
                ),
                ConsentConnectionStatus(
                    connection_id="c3", resource_name="r3",
                    provider="Slack", resource_indicator="orn:3",
                    status="consent_required",
                ),
            ],
        )

        pending = tx.pending_consents
        assert len(pending) == 2
        assert pending[0].connection_id == "c2"
        assert pending[1].connection_id == "c3"

    def test_all_resolved_property(self):
        tx = ConsentTransaction(
            transaction_id="tx-1",
            session_id="sess-1",
            original_redirect_uri="http://localhost/cb",
            original_state="s",
            original_client_id="cid",
            id_token="idt",
            access_token="at",
            connections=[
                ConsentConnectionStatus(
                    connection_id="c1", resource_name="r1",
                    provider="GitHub", resource_indicator="orn:1",
                    status="verified",
                ),
                ConsentConnectionStatus(
                    connection_id="c2", resource_name="r2",
                    provider="Jira", resource_indicator="orn:2",
                    status="skipped",
                ),
                ConsentConnectionStatus(
                    connection_id="c3", resource_name="r3",
                    provider="Slack", resource_indicator="orn:3",
                    status="error",
                    error_message="timeout",
                ),
            ],
        )
        assert tx.all_resolved is True

        # Add a pending one — should not be resolved
        tx.connections.append(
            ConsentConnectionStatus(
                connection_id="c4", resource_name="r4",
                provider="Box", resource_indicator="orn:4",
                status="pending",
            )
        )
        assert tx.all_resolved is False

    def test_is_expired_property(self):
        tx = ConsentTransaction(
            transaction_id="tx-1",
            session_id="sess-1",
            original_redirect_uri="http://localhost/cb",
            original_state="s",
            original_client_id="cid",
            id_token="idt",
            access_token="at",
            ttl_seconds=600,
        )
        assert tx.is_expired is False

        tx.created_at = time.monotonic() - 700
        assert tx.is_expired is True


class TestConsentTransactionMode:
    def test_create_defaults_to_oauth_return_mode(self):
        store = _make_store()
        tx = _create_tx(store)
        assert tx.mode == "oauth_return"

    def test_create_standalone_mode(self):
        store = _make_store()
        tx = _create_tx(store, mode="standalone")
        assert tx.mode == "standalone"

    def test_standalone_mode_allows_empty_oauth_return_fields(self):
        store = _make_store()
        tx = store.create(
            mode="standalone",
            original_client_id="",
            original_redirect_uri="",
            original_state="",
            access_token="",
            refresh_token=None,
            okta_expires_in=None,
            relay_client_id="",
            relay_client_secret="",
            id_token="idt_standalone",
            agent_id="agent-1",
        )
        assert tx.mode == "standalone"
        assert tx.original_client_id == ""
        assert tx.original_redirect_uri == ""
        assert tx.original_state == ""
        assert tx.access_token == ""
        assert tx.relay_client_id == ""
        assert tx.relay_client_secret == ""

    def test_mode_field_round_trips_through_store(self):
        store = _make_store()
        tx = _create_tx(store, mode="standalone")
        retrieved = store.get_by_id(tx.transaction_id)
        assert retrieved is not None
        assert retrieved.mode == "standalone"

        tx2 = _create_tx(store)
        retrieved2 = store.get_by_id(tx2.transaction_id)
        assert retrieved2 is not None
        assert retrieved2.mode == "oauth_return"
