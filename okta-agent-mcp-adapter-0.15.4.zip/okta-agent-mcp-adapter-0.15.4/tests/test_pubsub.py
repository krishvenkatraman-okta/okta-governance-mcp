"""
Tests for CacheEventBus pub/sub layer.

Verifies:
- Memory provider mode is a silent no-op (no errors)
- Redis mode correctly publishes and dispatches to callbacks
- Listener lifecycle (start/stop) works cleanly
"""

import asyncio
import pytest
from unittest.mock import AsyncMock, MagicMock, patch

from okta_agent_proxy.cache.pubsub import (
    CacheEventBus,
    CHANNEL_ROUTE_INVALIDATE,
    CHANNEL_AGENT_INVALIDATE,
    CHANNEL_TOOL_CATALOG_INVALIDATE,
    CHANNEL_USER_TOKEN_INVALIDATE,
    CHANNEL_RELAY_SESSION_INVALIDATE,
    CHANNEL_CONSENT_TX_INVALIDATE,
    CHANNEL_USER_LOGOUT,
    ALL_CHANNELS,
)
from okta_agent_proxy.cache.cache_service import CacheService
from okta_agent_proxy.cache.memory_provider import MemoryCacheProvider


class TestMemoryProviderNoOp:
    """With memory L2, all pub/sub operations should be silent no-ops."""

    @pytest.fixture
    def memory_bus(self, cache_service):
        return CacheEventBus(cache_service)

    def test_is_not_active(self, memory_bus):
        assert memory_bus.is_active is False

    @pytest.mark.asyncio
    async def test_publish_is_noop(self, memory_bus):
        # Should not raise
        await memory_bus.publish(CHANNEL_ROUTE_INVALIDATE, "test-backend")

    @pytest.mark.asyncio
    async def test_subscribe_stores_callback(self, memory_bus):
        cb = AsyncMock()
        await memory_bus.subscribe(CHANNEL_ROUTE_INVALIDATE, cb)
        # Callback is stored but never invoked without Redis
        assert CHANNEL_ROUTE_INVALIDATE in memory_bus._callbacks

    @pytest.mark.asyncio
    async def test_start_listener_is_noop(self, memory_bus):
        await memory_bus.start_listener()
        assert memory_bus._listener_task is None

    @pytest.mark.asyncio
    async def test_stop_listener_is_noop(self, memory_bus):
        await memory_bus.stop_listener()
        assert memory_bus._listener_task is None

    @pytest.mark.asyncio
    async def test_full_lifecycle_no_errors(self, memory_bus):
        """Subscribe, start, publish, stop — all no-ops without Redis."""
        cb = AsyncMock()
        await memory_bus.subscribe(CHANNEL_AGENT_INVALIDATE, cb)
        await memory_bus.start_listener()
        await memory_bus.publish(CHANNEL_AGENT_INVALIDATE, "test-agent")
        await memory_bus.stop_listener()
        cb.assert_not_called()


class TestChannelConstants:
    def test_all_channels_list(self):
        assert CHANNEL_ROUTE_INVALIDATE in ALL_CHANNELS
        assert CHANNEL_AGENT_INVALIDATE in ALL_CHANNELS
        assert CHANNEL_TOOL_CATALOG_INVALIDATE in ALL_CHANNELS
        assert CHANNEL_USER_TOKEN_INVALIDATE in ALL_CHANNELS
        assert CHANNEL_RELAY_SESSION_INVALIDATE in ALL_CHANNELS
        assert CHANNEL_CONSENT_TX_INVALIDATE in ALL_CHANNELS
        assert CHANNEL_USER_LOGOUT in ALL_CHANNELS
        assert len(ALL_CHANNELS) == 8


class TestRedisProviderMocked:
    """Test Redis pub/sub behavior using a mock Redis client."""

    @pytest.fixture
    def mock_redis(self):
        """Create a mock Redis client with pub/sub support."""
        redis_mock = AsyncMock()
        redis_mock.publish = AsyncMock(return_value=1)
        return redis_mock

    @pytest.fixture
    def redis_bus(self, mock_redis):
        """Create a CacheEventBus with a mocked Redis L2 provider."""
        l2 = MemoryCacheProvider(max_size=100, default_ttl=3600)
        svc = CacheService(l2_provider=l2)
        bus = CacheEventBus(svc)
        # Inject mock Redis client directly
        bus._redis = mock_redis
        return bus

    def test_is_active_with_redis(self, redis_bus):
        assert redis_bus.is_active is True

    @pytest.mark.asyncio
    async def test_publish_calls_redis(self, redis_bus, mock_redis):
        await redis_bus.publish(CHANNEL_ROUTE_INVALIDATE, "hr-system")
        mock_redis.publish.assert_awaited_once_with(CHANNEL_ROUTE_INVALIDATE, "hr-system")

    @pytest.mark.asyncio
    async def test_publish_error_is_swallowed(self, redis_bus, mock_redis):
        mock_redis.publish.side_effect = ConnectionError("Redis down")
        # Should not raise
        await redis_bus.publish(CHANNEL_ROUTE_INVALIDATE, "hr-system")

    @pytest.mark.asyncio
    async def test_subscribe_registers_callback(self, redis_bus):
        cb = AsyncMock()
        await redis_bus.subscribe(CHANNEL_AGENT_INVALIDATE, cb)
        assert cb in redis_bus._callbacks[CHANNEL_AGENT_INVALIDATE]

    @pytest.mark.asyncio
    async def test_subscribe_multiple_callbacks(self, redis_bus):
        cb1 = AsyncMock()
        cb2 = AsyncMock()
        await redis_bus.subscribe(CHANNEL_ROUTE_INVALIDATE, cb1)
        await redis_bus.subscribe(CHANNEL_ROUTE_INVALIDATE, cb2)
        assert len(redis_bus._callbacks[CHANNEL_ROUTE_INVALIDATE]) == 2

    @pytest.mark.asyncio
    async def test_listen_loop_dispatches_messages(self, redis_bus):
        """Simulate messages arriving on the pub/sub channel."""
        cb = AsyncMock()
        await redis_bus.subscribe(CHANNEL_ROUTE_INVALIDATE, cb)

        # Simulate a single message then cancel
        async def fake_listen():
            yield {"type": "subscribe", "channel": CHANNEL_ROUTE_INVALIDATE, "data": 1}
            yield {"type": "message", "channel": CHANNEL_ROUTE_INVALIDATE, "data": "hr-system"}
            # Give the loop a moment then cancel
            await asyncio.sleep(0.1)

        mock_pubsub = AsyncMock()
        mock_pubsub.listen = fake_listen
        mock_pubsub.subscribe = AsyncMock()
        mock_pubsub.unsubscribe = AsyncMock()
        mock_pubsub.aclose = AsyncMock()

        redis_bus._pubsub = mock_pubsub
        redis_bus._redis.pubsub = MagicMock(return_value=mock_pubsub)

        # Start listener
        redis_bus._listener_task = asyncio.create_task(redis_bus._listen_loop())

        # Wait for message processing
        await asyncio.sleep(0.2)

        cb.assert_awaited_once_with("hr-system")

        # Cleanup
        redis_bus._listener_task.cancel()
        try:
            await redis_bus._listener_task
        except asyncio.CancelledError:
            pass

    @pytest.mark.asyncio
    async def test_listen_loop_handles_bytes(self, redis_bus):
        """Verify bytes channel/data are decoded to str."""
        cb = AsyncMock()
        await redis_bus.subscribe(CHANNEL_AGENT_INVALIDATE, cb)

        async def fake_listen():
            yield {
                "type": "message",
                "channel": CHANNEL_AGENT_INVALIDATE.encode("utf-8"),
                "data": b"test-agent",
            }
            await asyncio.sleep(0.1)

        mock_pubsub = AsyncMock()
        mock_pubsub.listen = fake_listen
        redis_bus._pubsub = mock_pubsub

        redis_bus._listener_task = asyncio.create_task(redis_bus._listen_loop())
        await asyncio.sleep(0.2)

        cb.assert_awaited_once_with("test-agent")

        redis_bus._listener_task.cancel()
        try:
            await redis_bus._listener_task
        except asyncio.CancelledError:
            pass

    @pytest.mark.asyncio
    async def test_callback_error_does_not_crash_listener(self, redis_bus):
        """A failing callback should not stop the listener."""
        bad_cb = AsyncMock(side_effect=ValueError("boom"))
        good_cb = AsyncMock()
        await redis_bus.subscribe(CHANNEL_ROUTE_INVALIDATE, bad_cb)
        await redis_bus.subscribe(CHANNEL_ROUTE_INVALIDATE, good_cb)

        async def fake_listen():
            yield {"type": "message", "channel": CHANNEL_ROUTE_INVALIDATE, "data": "test"}
            await asyncio.sleep(0.1)

        mock_pubsub = AsyncMock()
        mock_pubsub.listen = fake_listen
        redis_bus._pubsub = mock_pubsub

        redis_bus._listener_task = asyncio.create_task(redis_bus._listen_loop())
        await asyncio.sleep(0.2)

        bad_cb.assert_awaited_once()
        good_cb.assert_awaited_once_with("test")

        redis_bus._listener_task.cancel()
        try:
            await redis_bus._listener_task
        except asyncio.CancelledError:
            pass

    @pytest.mark.asyncio
    async def test_stop_listener_cancels_task(self, redis_bus, mock_redis):
        """stop_listener should cancel the background task cleanly."""
        cb = AsyncMock()
        await redis_bus.subscribe(CHANNEL_ROUTE_INVALIDATE, cb)

        # Create a long-running fake listener
        async def fake_listen():
            while True:
                await asyncio.sleep(1)
                yield {"type": "message", "channel": CHANNEL_ROUTE_INVALIDATE, "data": "test"}

        mock_pubsub = AsyncMock()
        mock_pubsub.listen = fake_listen
        mock_pubsub.subscribe = AsyncMock()
        mock_pubsub.unsubscribe = AsyncMock()
        mock_pubsub.aclose = AsyncMock()

        redis_bus._pubsub = mock_pubsub
        mock_redis.pubsub = MagicMock(return_value=mock_pubsub)

        await redis_bus.start_listener()
        assert redis_bus._listener_task is not None

        await redis_bus.stop_listener()
        assert redis_bus._listener_task is None
        assert redis_bus._pubsub is None


class TestSyncCallbackSupport:
    """Verify that synchronous callbacks also work."""

    @pytest.fixture
    def redis_bus(self):
        l2 = MemoryCacheProvider(max_size=100, default_ttl=3600)
        svc = CacheService(l2_provider=l2)
        bus = CacheEventBus(svc)
        bus._redis = AsyncMock()
        return bus

    @pytest.mark.asyncio
    async def test_sync_callback_works(self, redis_bus):
        results = []

        def sync_cb(message):
            results.append(message)

        await redis_bus.subscribe(CHANNEL_ROUTE_INVALIDATE, sync_cb)

        async def fake_listen():
            yield {"type": "message", "channel": CHANNEL_ROUTE_INVALIDATE, "data": "sync-test"}
            await asyncio.sleep(0.1)

        mock_pubsub = AsyncMock()
        mock_pubsub.listen = fake_listen
        redis_bus._pubsub = mock_pubsub

        redis_bus._listener_task = asyncio.create_task(redis_bus._listen_loop())
        await asyncio.sleep(0.2)

        assert results == ["sync-test"]

        redis_bus._listener_task.cancel()
        try:
            await redis_bus._listener_task
        except asyncio.CancelledError:
            pass
