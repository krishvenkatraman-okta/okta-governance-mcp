"""
Tests for connection-scoped resource identity model.

Covers:
- ResolvedResource isolation_key computation with various field combinations
- Validation: connection_id with/without agent context
- Two agents with same resource name → different isolation_keys
- Same agent with different connections → different isolation_keys
- Syncer accessor: get_resolved_resources_for_agent() filtering
- Local resources (agent_id=None) visible to all agents
- Agent A cannot see Agent B's connections via the accessor
"""

import pytest
from unittest.mock import MagicMock, patch

from okta_agent_proxy.resources.models import (
    OktaConnectionType,
    OktaScopeCondition,
    ResolvedResource,
)
from okta_agent_proxy.resources.syncer import OktaConnectionSyncer


# ============================================================================
# ResolvedResource isolation_key tests
# ============================================================================


class TestIsolationKey:

    def test_isolation_key_with_agent_and_connection(self):
        """Full isolation key: agent_id:connection_id:resource_name."""
        r = ResolvedResource(
            resource_id="aus123",
            name="hr-system",
            mcp_url="https://hr.example.com/mcp",
            connection_id="conn-123",
            connection_type=OktaConnectionType.IDENTITY_ASSERTION_CUSTOM_AS,
            agent_id="agent-abc",
            agent_name="Agent ABC",
        )
        assert r.isolation_key == "agent-abc:conn-123:hr-system"

    def test_isolation_key_local_resource_no_agent(self):
        """Local resource (no agent context): connection_id:resource_name or just resource_name."""
        r = ResolvedResource(
            resource_id="aus123",
            name="hr-system",
            mcp_url="https://hr.example.com/mcp",
            connection_id="",
            connection_type=OktaConnectionType.IDENTITY_ASSERTION_CUSTOM_AS,
        )
        # No agent_id, empty connection_id → just name
        assert r.isolation_key == "hr-system"

    def test_isolation_key_agent_only_no_connection(self):
        """Agent set but no connection_id → agent_id:resource_name."""
        r = ResolvedResource(
            resource_id="aus123",
            name="hr-system",
            mcp_url="https://hr.example.com/mcp",
            connection_id="",
            connection_type=OktaConnectionType.IDENTITY_ASSERTION_CUSTOM_AS,
            agent_id="agent-abc",
        )
        assert r.isolation_key == "agent-abc:hr-system"

    def test_isolation_key_connection_only_no_agent(self):
        """Connection set but no agent → connection_id:resource_name."""
        r = ResolvedResource(
            resource_id="aus123",
            name="hr-system",
            mcp_url="https://hr.example.com/mcp",
            connection_id="conn-456",
            connection_type=OktaConnectionType.IDENTITY_ASSERTION_CUSTOM_AS,
        )
        assert r.isolation_key == "conn-456:hr-system"

    def test_two_agents_same_resource_different_keys(self):
        """Two agents connected to same resource → different isolation_keys."""
        base = dict(
            resource_id="aus123",
            name="hr-system",
            mcp_url="https://hr.example.com/mcp",
            connection_type=OktaConnectionType.IDENTITY_ASSERTION_CUSTOM_AS,
        )
        r1 = ResolvedResource(
            **base,
            connection_id="conn-a",
            agent_id="agent-alice",
            agent_name="Alice",
        )
        r2 = ResolvedResource(
            **base,
            connection_id="conn-b",
            agent_id="agent-bob",
            agent_name="Bob",
        )
        assert r1.isolation_key != r2.isolation_key
        assert r1.isolation_key == "agent-alice:conn-a:hr-system"
        assert r2.isolation_key == "agent-bob:conn-b:hr-system"

    def test_same_agent_different_connections_different_keys(self):
        """Same agent with two connections to same resource → different keys."""
        base = dict(
            resource_id="aus123",
            name="hr-system",
            mcp_url="https://hr.example.com/mcp",
            connection_type=OktaConnectionType.IDENTITY_ASSERTION_CUSTOM_AS,
            agent_id="agent-abc",
            agent_name="Agent ABC",
        )
        r1 = ResolvedResource(**base, connection_id="conn-111")
        r2 = ResolvedResource(**base, connection_id="conn-222")
        assert r1.isolation_key != r2.isolation_key
        assert "conn-111" in r1.isolation_key
        assert "conn-222" in r2.isolation_key

    def test_agent_fields_default_none(self):
        """New agent fields default to None for backward compatibility."""
        r = ResolvedResource(
            resource_id="aus123",
            name="hr-system",
            mcp_url="https://hr.example.com/mcp",
            connection_id="conn-1",
            connection_type=OktaConnectionType.IDENTITY_ASSERTION_CUSTOM_AS,
        )
        assert r.agent_id is None
        assert r.agent_name is None


# ============================================================================
# Syncer accessor tests
# ============================================================================


class TestSyncerAgentFiltering:
    """Tests for get_resolved_resources_for_agent() and get_all_resolved_resources_raw()."""

    def _make_syncer_with_resources(self, resources: dict):
        """Create a syncer with pre-populated _resources dict."""
        syncer = OktaConnectionSyncer.__new__(OktaConnectionSyncer)
        syncer._resources = resources
        syncer._unresolved = []
        syncer._last_sync_at = None
        syncer._last_sync_status = "never"
        syncer._last_connections = {}
        syncer._last_agent_info = {}
        syncer._raw_connections = []
        syncer._http_client = None
        syncer._okta_domain = "https://example.okta.com"
        syncer._api_token = ""
        syncer._store = MagicMock()
        syncer._event_bus = MagicMock()
        syncer._stale_threshold = 1800
        return syncer

    def _make_resolved(self, name, agent_id=None, agent_name=None, connection_id="conn-1"):
        return ResolvedResource(
            resource_id=f"aus-{name}",
            name=name,
            mcp_url=f"https://{name}.example.com/mcp",
            connection_id=connection_id,
            connection_type=OktaConnectionType.IDENTITY_ASSERTION_CUSTOM_AS,
            agent_id=agent_id,
            agent_name=agent_name,
        )

    def test_get_resolved_resources_for_agent_filters_correctly(self):
        """Only returns resources for the specified agent + local resources."""
        r_alice = self._make_resolved("hr-system", agent_id="alice", connection_id="conn-a")
        r_bob = self._make_resolved("hr-system", agent_id="bob", connection_id="conn-b")
        r_local = self._make_resolved("api-keys", agent_id=None, connection_id="")

        syncer = self._make_syncer_with_resources({
            r_alice.isolation_key: r_alice,
            r_bob.isolation_key: r_bob,
            r_local.isolation_key: r_local,
        })

        alice_resources = syncer.get_resolved_resources_for_agent("alice")
        assert "hr-system" in alice_resources
        assert alice_resources["hr-system"].agent_id == "alice"
        assert "api-keys" in alice_resources  # local resource visible
        assert len(alice_resources) == 2

    def test_local_resources_visible_to_all_agents(self):
        """Resources with agent_id=None are visible to any agent."""
        r_local = self._make_resolved("api-keys", agent_id=None, connection_id="")

        syncer = self._make_syncer_with_resources({
            r_local.isolation_key: r_local,
        })

        for agent_id in ["alice", "bob", "charlie"]:
            result = syncer.get_resolved_resources_for_agent(agent_id)
            assert "api-keys" in result

    def test_agent_a_cannot_see_agent_b_connections(self):
        """Agent A's resources are not visible to Agent B."""
        r_alice = self._make_resolved("finance-system", agent_id="alice", connection_id="conn-a")
        r_bob = self._make_resolved("deploy-bot", agent_id="bob", connection_id="conn-b")

        syncer = self._make_syncer_with_resources({
            r_alice.isolation_key: r_alice,
            r_bob.isolation_key: r_bob,
        })

        alice_resources = syncer.get_resolved_resources_for_agent("alice")
        assert "finance-system" in alice_resources
        assert "deploy-bot" not in alice_resources

        bob_resources = syncer.get_resolved_resources_for_agent("bob")
        assert "deploy-bot" in bob_resources
        assert "finance-system" not in bob_resources

    def test_get_all_resolved_resources_raw_returns_all(self):
        """get_all_resolved_resources_raw returns everything keyed by isolation_key."""
        r_alice = self._make_resolved("hr-system", agent_id="alice", connection_id="conn-a")
        r_bob = self._make_resolved("hr-system", agent_id="bob", connection_id="conn-b")
        r_local = self._make_resolved("api-keys", agent_id=None, connection_id="")

        resources = {
            r_alice.isolation_key: r_alice,
            r_bob.isolation_key: r_bob,
            r_local.isolation_key: r_local,
        }
        syncer = self._make_syncer_with_resources(resources)

        raw = syncer.get_all_resolved_resources_raw()
        assert len(raw) == 3
        assert r_alice.isolation_key in raw
        assert r_bob.isolation_key in raw
        assert r_local.isolation_key in raw

    def test_get_resource_by_name_with_isolation_keys(self):
        """get_resource(name) still works when dict is keyed by isolation_key."""
        r_alice = self._make_resolved("hr-system", agent_id="alice", connection_id="conn-a")

        syncer = self._make_syncer_with_resources({
            r_alice.isolation_key: r_alice,
        })

        result = syncer.get_resource("hr-system")
        assert result is not None
        assert result.name == "hr-system"
        assert result.agent_id == "alice"

    def test_get_resource_returns_none_for_nonexistent(self):
        """get_resource returns None when resource doesn't exist."""
        syncer = self._make_syncer_with_resources({})
        assert syncer.get_resource("nonexistent") is None

    def test_register_resolved_resource_uses_isolation_key(self):
        """register_resolved_resource stores by isolation_key."""
        syncer = self._make_syncer_with_resources({})
        r = self._make_resolved("hr-system", agent_id="alice", connection_id="conn-a")

        syncer.register_resolved_resource(r)

        assert r.isolation_key in syncer._resources
        assert syncer._resources[r.isolation_key] is r
