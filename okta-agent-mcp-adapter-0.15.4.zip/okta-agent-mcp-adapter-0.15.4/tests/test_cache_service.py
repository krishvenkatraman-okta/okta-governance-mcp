"""
Tests for the cache abstraction layer.

Tests:
- MemoryCacheProvider: get/set/delete/exists/clear_prefix/health_check
- CacheService: L1/L2 promotion, TTL behavior, prefix clearing
- Serializers: JSON round-trip, encrypted round-trip
- CacheService.create_from_env: fallback to memory when no REDIS_URL
"""

import asyncio
import json
import pytest
from datetime import datetime
from unittest.mock import patch

from okta_agent_proxy.cache.base import CacheProvider, CacheProviderConfig
from okta_agent_proxy.cache.memory_provider import MemoryCacheProvider
from okta_agent_proxy.cache.cache_service import CacheService
from okta_agent_proxy.cache.serializers import (
    serialize_json,
    deserialize_json,
    serialize_encrypted,
    deserialize_encrypted,
)


# ============================================================================
# MemoryCacheProvider Tests
# ============================================================================


class TestMemoryCacheProvider:
    @pytest.fixture
    def provider(self):
        return MemoryCacheProvider(max_size=100, default_ttl=3600)

    async def test_get_missing_key(self, provider):
        assert await provider.get("nonexistent") is None

    async def test_set_and_get(self, provider):
        await provider.set("key1", "value1")
        assert await provider.get("key1") == "value1"

    async def test_set_overwrite(self, provider):
        await provider.set("key1", "value1")
        await provider.set("key1", "value2")
        assert await provider.get("key1") == "value2"

    async def test_delete(self, provider):
        await provider.set("key1", "value1")
        await provider.delete("key1")
        assert await provider.get("key1") is None

    async def test_delete_nonexistent(self, provider):
        # Should not raise
        await provider.delete("nonexistent")

    async def test_exists_true(self, provider):
        await provider.set("key1", "value1")
        assert await provider.exists("key1") is True

    async def test_exists_false(self, provider):
        assert await provider.exists("nonexistent") is False

    async def test_clear_prefix(self, provider):
        await provider.set("user:1:token", "t1")
        await provider.set("user:1:session", "s1")
        await provider.set("user:2:token", "t2")
        await provider.set("other:key", "val")

        count = await provider.clear_prefix("user:1:")
        assert count == 2
        assert await provider.get("user:1:token") is None
        assert await provider.get("user:1:session") is None
        assert await provider.get("user:2:token") == "t2"
        assert await provider.get("other:key") == "val"

    async def test_clear_prefix_no_match(self, provider):
        await provider.set("key1", "value1")
        count = await provider.clear_prefix("nomatch:")
        assert count == 0
        assert await provider.get("key1") == "value1"

    async def test_health_check(self, provider):
        assert await provider.health_check() is True

    async def test_close(self, provider):
        await provider.set("key1", "value1")
        provider.close()
        # After close, cache is cleared
        assert await provider.get("key1") is None


# ============================================================================
# CacheService Tests
# ============================================================================


class TestCacheService:
    @pytest.fixture
    def service(self):
        l2 = MemoryCacheProvider(max_size=1000, default_ttl=3600)
        return CacheService(l2_provider=l2)

    async def test_set_and_get(self, service):
        await service.set("key1", "value1")
        assert await service.get("key1") == "value1"

    async def test_l1_hit(self, service):
        """Value should be in L1 after set."""
        await service.set("key1", "value1")
        assert await service.l1.get("key1") == "value1"

    async def test_l2_hit_promotes_to_l1(self, service):
        """Value only in L2 should be promoted to L1 on get."""
        # Write directly to L2 only
        await service.l2.set("key1", "value1")
        # L1 should miss
        assert await service.l1.get("key1") is None
        # CacheService get should find it in L2 and promote
        assert await service.get("key1") == "value1"
        # Now L1 should have it
        assert await service.l1.get("key1") == "value1"

    async def test_delete_removes_from_both(self, service):
        await service.set("key1", "value1")
        await service.delete("key1")
        assert await service.l1.get("key1") is None
        assert await service.l2.get("key1") is None

    async def test_exists(self, service):
        assert await service.exists("key1") is False
        await service.set("key1", "value1")
        assert await service.exists("key1") is True

    async def test_clear_prefix(self, service):
        await service.set("pfx:a", "1")
        await service.set("pfx:b", "2")
        await service.set("other:c", "3")
        count = await service.clear_prefix("pfx:")
        assert count == 2
        assert await service.get("pfx:a") is None
        assert await service.get("other:c") == "3"

    async def test_health_check_memory(self, service):
        assert await service.health_check() is True

    async def test_close(self, service):
        await service.set("key1", "value1")
        service.close()
        assert await service.l1.get("key1") is None

    async def test_set_with_ttl(self, service):
        await service.set("key1", "value1", ttl_seconds=60)
        assert await service.get("key1") == "value1"


class TestCacheServiceCreate:
    def test_create_memory_provider(self):
        config = CacheProviderConfig(provider="memory", default_ttl=1800)
        service = CacheService.create(config)
        assert isinstance(service.l2, MemoryCacheProvider)
        service.close()

    def test_create_from_env_no_redis(self, monkeypatch):
        """Without REDIS_URL, should fall back to memory."""
        monkeypatch.delenv("REDIS_URL", raising=False)
        monkeypatch.delenv("CACHE_PROVIDER", raising=False)
        service = CacheService.create_from_env()
        assert isinstance(service.l2, MemoryCacheProvider)
        service.close()

    def test_create_from_env_with_cache_provider_memory(self, monkeypatch):
        monkeypatch.setenv("CACHE_PROVIDER", "memory")
        monkeypatch.delenv("REDIS_URL", raising=False)
        service = CacheService.create_from_env()
        assert isinstance(service.l2, MemoryCacheProvider)
        service.close()


# ============================================================================
# CacheProviderConfig Tests
# ============================================================================


class TestCacheProviderConfig:
    def test_defaults(self):
        config = CacheProviderConfig()
        assert config.provider == "memory"
        assert config.key_prefix == "okta-mcp:"
        assert config.default_ttl == 3600

    def test_custom_values(self):
        config = CacheProviderConfig(provider="redis", key_prefix="test:", default_ttl=600)
        assert config.provider == "redis"
        assert config.key_prefix == "test:"
        assert config.default_ttl == 600


# ============================================================================
# Serializer Tests
# ============================================================================


class TestSerializers:
    def test_json_round_trip_dict(self):
        data = {"key": "value", "number": 42, "nested": {"a": [1, 2, 3]}}
        serialized = serialize_json(data)
        result = deserialize_json(serialized)
        assert result == data

    def test_json_round_trip_list(self):
        data = [1, "two", 3.0, None, True]
        serialized = serialize_json(data)
        result = deserialize_json(serialized, list)
        assert result == data

    def test_json_datetime_handling(self):
        data = {"timestamp": datetime(2026, 1, 15, 10, 30, 0)}
        serialized = serialize_json(data)
        result = deserialize_json(serialized)
        assert result["timestamp"] == "2026-01-15T10:30:00"

    def test_json_string(self):
        data = "just a string"
        serialized = serialize_json(data)
        result = deserialize_json(serialized, str)
        assert result == data

    def test_encrypted_round_trip(self, encryption_service):
        data = {"secret": "my-api-key", "tokens": [1, 2, 3]}
        encrypted = serialize_encrypted(data, encryption_service)
        # Encrypted value should be a base64 string, not readable JSON
        assert "my-api-key" not in encrypted
        result = deserialize_encrypted(encrypted, encryption_service)
        assert result == data

    def test_encrypted_round_trip_string(self, encryption_service):
        data = "simple-secret"
        encrypted = serialize_encrypted(data, encryption_service)
        result = deserialize_encrypted(encrypted, encryption_service)
        assert result == data

    def test_encrypted_different_outputs(self, encryption_service):
        """Two encryptions of the same data should produce different ciphertexts (random IV)."""
        data = {"key": "value"}
        enc1 = serialize_encrypted(data, encryption_service)
        enc2 = serialize_encrypted(data, encryption_service)
        assert enc1 != enc2
        # But both should decrypt to the same value
        assert deserialize_encrypted(enc1, encryption_service) == data
        assert deserialize_encrypted(enc2, encryption_service) == data


# ============================================================================
# Abstract Base Class Tests
# ============================================================================


class TestCacheProviderABC:
    def test_cannot_instantiate_abstract(self):
        with pytest.raises(TypeError):
            CacheProvider()
