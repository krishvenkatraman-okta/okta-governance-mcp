"""Tests for admin config change audit events, ip_address/user_agent flow, and audit log endpoints."""

import asyncio
import sys
from typing import List
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from okta_agent_proxy.audit.events import AuditEvent, AuditEventType, AuditSeverity
from okta_agent_proxy.audit.context import set_request_context, clear_request_context
from okta_agent_proxy.audit.emitter import AuditEventEmitter
from okta_agent_proxy.audit.sinks.base import AuditSink


# --- Helper: capture sink ---


class CaptureSink(AuditSink):
    def __init__(self):
        self.events: List[AuditEvent] = []

    async def write(self, event: AuditEvent) -> None:
        self.events.append(event)

    @property
    def name(self) -> str:
        return "capture"


@pytest.fixture(autouse=True)
def _clean():
    clear_request_context()
    yield
    clear_request_context()


@pytest.fixture
async def capture_emitter():
    sink = CaptureSink()
    emitter = AuditEventEmitter(sinks=[sink], flush_interval=0.05)
    await emitter.start()

    import okta_agent_proxy.audit as audit_mod
    old = audit_mod._emitter
    audit_mod._emitter = emitter
    yield sink
    audit_mod._emitter = old
    await emitter.stop()


def _mock_request(method="POST", path="/api/admin/agents", body=None,
                  ip="10.0.0.1", user_agent_str="TestClient/1.0"):
    """Create a mock Starlette request."""
    request = AsyncMock()
    request.method = method
    request.url.path = path
    request.json = AsyncMock(return_value=body or {})
    request.headers = {
        "authorization": "Bearer fake-admin-token",
        "user-agent": user_agent_str,
    }
    request.query_params = {}
    request.path_params = {}
    request.state = MagicMock()
    request.state.admin_payload = {"username": "admin-user"}
    request.state.admin_user = "admin-user"
    client = MagicMock()
    client.host = ip
    request.client = client
    return request


def _mock_store():
    """Create a mock ResourceConfigStore with all needed methods."""
    store = MagicMock()
    store.get_agent.return_value = None
    store.get_all_agents.return_value = []
    store.get_resource.return_value = None
    store.get_all_resources.return_value = []
    store.create_agent.return_value = True
    store.update_agent.return_value = True
    store.delete_agent.return_value = True
    store.create_resource.return_value = True
    store.update_resource.return_value = True
    store.delete_resource.return_value = True
    store.get_audit_log.return_value = []
    store.get_agent_audit_log.return_value = []
    return store


# ============================================================================
# Test 1: Admin config events emitted on agent CRUD
# ============================================================================


class TestAgentConfigAuditEvents:
    @pytest.mark.asyncio
    async def test_create_agent_emits_config_event(self, capture_emitter):
        from okta_agent_proxy.admin.routes import create_agent

        request = _mock_request(body={
            "agent_id": "new-agent",
            "client_id": "cid-123",
            "private_key": '{"kty":"RSA"}',
        })

        store = _mock_store()
        store.get_agent.side_effect = [None, {"agent_id": "new-agent"}]

        set_request_context(correlation_id="cfg-agent-create-1")

        with patch("okta_agent_proxy.admin.routes.get_store", return_value=store):
            with patch("okta_agent_proxy.admin.routes._publish_event",
                       new_callable=AsyncMock):
                response = await create_agent.__wrapped__(request)

        assert response.status_code == 201
        await asyncio.sleep(0.15)

        events = [e for e in capture_emitter.events
                  if e.event_type == AuditEventType.CONFIG_AGENT_CREATED]
        assert len(events) == 1
        assert events[0].details["agent_id"] == "new-agent"
        assert events[0].details["source"] == "manual"

    @pytest.mark.asyncio
    async def test_update_agent_emits_config_event(self, capture_emitter):
        from okta_agent_proxy.admin.routes import update_agent

        request = _mock_request(method="PUT", path="/api/admin/agents/test-agent",
                                body={"enabled": False})
        request.path_params = {"agent_id": "test-agent"}

        store = _mock_store()
        store.get_agent.side_effect = [
            {"agent_id": "test-agent"},  # exists check
            {"agent_id": "test-agent", "enabled": False},  # after update
        ]

        set_request_context(correlation_id="cfg-agent-update-1")

        with patch("okta_agent_proxy.admin.routes.get_store", return_value=store):
            with patch("okta_agent_proxy.admin.routes._publish_event",
                       new_callable=AsyncMock):
                response = await update_agent.__wrapped__(request)

        assert response.status_code == 200
        await asyncio.sleep(0.15)

        events = [e for e in capture_emitter.events
                  if e.event_type == AuditEventType.CONFIG_AGENT_UPDATED]
        assert len(events) == 1
        assert events[0].details["agent_id"] == "test-agent"

    @pytest.mark.asyncio
    async def test_delete_agent_emits_config_event(self, capture_emitter):
        from okta_agent_proxy.admin.routes import delete_agent

        request = _mock_request(method="DELETE", path="/api/admin/agents/old-agent")
        request.path_params = {"agent_id": "old-agent"}

        store = _mock_store()
        store.get_agent.return_value = {"agent_id": "old-agent"}

        set_request_context(correlation_id="cfg-agent-delete-1")

        with patch("okta_agent_proxy.admin.routes.get_store", return_value=store):
            with patch("okta_agent_proxy.admin.routes._publish_event",
                       new_callable=AsyncMock):
                response = await delete_agent.__wrapped__(request)

        assert response.status_code == 200
        await asyncio.sleep(0.15)

        events = [e for e in capture_emitter.events
                  if e.event_type == AuditEventType.CONFIG_AGENT_DELETED]
        assert len(events) == 1
        assert events[0].severity == AuditSeverity.WARNING
        assert events[0].details["agent_id"] == "old-agent"


# ============================================================================
# Test 3: ip_address and user_agent flow into store calls
# ============================================================================


class TestIpAndUserAgentFlow:
    @pytest.mark.asyncio
    async def test_create_agent_passes_ip_and_ua(self, capture_emitter):
        from okta_agent_proxy.admin.routes import create_agent

        request = _mock_request(
            body={"agent_id": "ip-test", "client_id": "cid", "private_key": "{}"},
            ip="192.168.1.42",
            user_agent_str="AdminUI/2.0",
        )

        store = _mock_store()
        store.get_agent.side_effect = [None, {"agent_id": "ip-test"}]

        with patch("okta_agent_proxy.admin.routes.get_store", return_value=store):
            with patch("okta_agent_proxy.admin.routes._publish_event",
                       new_callable=AsyncMock):
                await create_agent.__wrapped__(request)

        store.create_agent.assert_called_once()
        call_kwargs = store.create_agent.call_args
        assert call_kwargs.kwargs.get("ip_address") == "192.168.1.42"
        assert call_kwargs.kwargs.get("user_agent") == "AdminUI/2.0"

    @pytest.mark.asyncio
    async def test_delete_agent_passes_ip_and_ua(self, capture_emitter):
        from okta_agent_proxy.admin.routes import delete_agent

        request = _mock_request(
            method="DELETE",
            ip="172.16.0.5",
            user_agent_str="Postman/10.0",
        )
        request.path_params = {"agent_id": "del-test"}

        store = _mock_store()
        store.get_agent.return_value = {"agent_id": "del-test"}

        with patch("okta_agent_proxy.admin.routes.get_store", return_value=store):
            with patch("okta_agent_proxy.admin.routes._publish_event",
                       new_callable=AsyncMock):
                await delete_agent.__wrapped__(request)

        store.delete_agent.assert_called_once()
        call_kwargs = store.delete_agent.call_args
        assert call_kwargs.kwargs.get("ip_address") == "172.16.0.5"
        assert call_kwargs.kwargs.get("user_agent") == "Postman/10.0"


# ============================================================================
# Test 4: Audit log query endpoints
# ============================================================================


class TestAuditLogEndpoints:
    @pytest.mark.asyncio
    async def test_get_audit_log_returns_entries(self, capture_emitter):
        from okta_agent_proxy.admin.routes import get_audit_log

        request = _mock_request(method="GET", path="/api/admin/audit")
        request.query_params = {}

        fake_entries = [
            {"entity_type": "agent", "entity_id": "a1", "action": "created",
             "changed_by": "admin", "changed_at": "2026-01-01T00:00:00"},
            {"entity_type": "resource", "entity_id": "b1", "action": "updated",
             "changed_by": "admin", "changed_at": "2026-01-01T01:00:00"},
        ]

        store = _mock_store()
        store.get_audit_log.return_value = fake_entries

        with patch("okta_agent_proxy.admin.routes.get_store", return_value=store):
            response = await get_audit_log.__wrapped__(request)

        assert response.status_code == 200
        import json
        body = json.loads(response.body)
        assert len(body["audit_log"]) == 2

    @pytest.mark.asyncio
    async def test_get_audit_log_with_entity_type_filter(self, capture_emitter):
        from okta_agent_proxy.admin.routes import get_audit_log

        request = _mock_request(method="GET", path="/api/admin/audit")
        request.query_params = {"entity_type": "agent", "limit": "50"}

        fake_entries = [
            {"entity_type": "agent", "entity_id": "a1", "action": "created"},
            {"entity_type": "resource", "entity_id": "b1", "action": "updated"},
        ]

        store = _mock_store()
        store.get_audit_log.return_value = fake_entries

        with patch("okta_agent_proxy.admin.routes.get_store", return_value=store):
            response = await get_audit_log.__wrapped__(request)

        assert response.status_code == 200
        import json
        body = json.loads(response.body)
        # Should filter to only agent entries
        assert len(body["audit_log"]) == 1
        assert body["audit_log"][0]["entity_type"] == "agent"

    @pytest.mark.asyncio
    async def test_get_agent_audit_log(self, capture_emitter):
        from okta_agent_proxy.admin.routes import get_agent_audit_log

        request = _mock_request(method="GET", path="/api/admin/agents/claude-code/audit")
        request.path_params = {"agent_id": "claude-code"}
        request.query_params = {"limit": "25"}

        fake_entries = [
            {"entity_type": "agent", "entity_id": "claude-code", "action": "created"},
        ]

        store = _mock_store()
        store.get_agent_audit_log.return_value = fake_entries

        with patch("okta_agent_proxy.admin.routes.get_store", return_value=store):
            response = await get_agent_audit_log.__wrapped__(request)

        assert response.status_code == 200
        import json
        body = json.loads(response.body)
        assert len(body["audit_log"]) == 1

        store.get_agent_audit_log.assert_called_once_with("claude-code", limit=25)

    @pytest.mark.asyncio
    async def test_get_resource_audit_log(self, capture_emitter):
        from okta_agent_proxy.admin.routes import get_resource_audit_log

        request = _mock_request(method="GET", path="/api/admin/resources/hr-system/audit")
        request.path_params = {"name": "hr-system"}
        request.query_params = {}

        fake_entries = [
            {"entity_type": "resource", "entity_id": "hr-system", "action": "updated"},
        ]

        store = _mock_store()
        store.get_audit_log.return_value = fake_entries

        with patch("okta_agent_proxy.admin.routes.get_store", return_value=store):
            response = await get_resource_audit_log.__wrapped__(request)

        assert response.status_code == 200
        import json
        body = json.loads(response.body)
        assert len(body["audit_log"]) == 1

        store.get_audit_log.assert_called_once_with(resource_name="hr-system", limit=100)

    @pytest.mark.asyncio
    async def test_get_agent_audit_log_missing_id(self, capture_emitter):
        from okta_agent_proxy.admin.routes import get_agent_audit_log

        request = _mock_request(method="GET")
        request.path_params = {"agent_id": ""}
        request.query_params = {}

        with patch("okta_agent_proxy.admin.routes.get_store", return_value=_mock_store()):
            response = await get_agent_audit_log.__wrapped__(request)

        assert response.status_code == 400


# ============================================================================
# Test 5: CachedResourceStore passes ip_address/user_agent through
# ============================================================================


class TestCachedStorePassThrough:
    def test_cached_store_passes_ip_ua_to_create_agent(self):
        from okta_agent_proxy.storage.cached_store import CachedResourceStore

        inner = _mock_store()
        cache_service = MagicMock()
        cached = CachedResourceStore(inner, cache_service)

        cached.create_agent("test", {"client_id": "c"}, user="admin",
                            ip_address="1.2.3.4", user_agent="Test/1.0")

        inner.create_agent.assert_called_once_with(
            "test", {"client_id": "c"}, "admin",
            ip_address="1.2.3.4", user_agent="Test/1.0"
        )

    def test_cached_store_passes_ip_ua_to_delete_resource(self):
        from okta_agent_proxy.storage.cached_store import CachedResourceStore

        inner = _mock_store()
        cache_service = MagicMock()
        cached = CachedResourceStore(inner, cache_service)

        cached.delete_resource("hr", user="admin",
                              ip_address="5.6.7.8", user_agent="CLI/2.0")

        inner.delete_resource.assert_called_once_with(
            "hr", "admin",
            ip_address="5.6.7.8", user_agent="CLI/2.0"
        )
