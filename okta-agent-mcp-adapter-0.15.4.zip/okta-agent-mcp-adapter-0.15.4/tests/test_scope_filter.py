"""Unit tests for okta_agent_proxy.auth.scope_filter."""

import os
from unittest.mock import patch

from okta_agent_proxy.auth.scope_filter import (
    OIDC_SCOPES,
    filter_as_scopes,
    get_scope_blocklist,
)


class TestOIDCScopes:
    def test_contains_expected_scopes(self):
        assert "openid" in OIDC_SCOPES
        assert "profile" in OIDC_SCOPES
        assert "email" in OIDC_SCOPES
        assert "address" in OIDC_SCOPES
        assert "phone" in OIDC_SCOPES
        assert "offline_access" in OIDC_SCOPES

    def test_frozen(self):
        assert isinstance(OIDC_SCOPES, frozenset)


class TestGetScopeBlocklist:
    def test_default_blocks_interclient_access_and_device_sso(self):
        with patch.dict(os.environ, {}, clear=False):
            os.environ.pop("OKTA_SCOPE_BLOCKLIST", None)
            assert get_scope_blocklist() == frozenset(
                {"interclient_access", "device_sso"}
            )

    def test_custom_comma_separated(self):
        with patch.dict(os.environ, {"OKTA_SCOPE_BLOCKLIST": "a,b,c"}):
            assert get_scope_blocklist() == frozenset({"a", "b", "c"})

    def test_whitespace_trimmed(self):
        with patch.dict(os.environ, {"OKTA_SCOPE_BLOCKLIST": "  foo , bar  "}):
            assert get_scope_blocklist() == frozenset({"foo", "bar"})

    def test_empty_string_disables_blocklist(self):
        with patch.dict(os.environ, {"OKTA_SCOPE_BLOCKLIST": ""}):
            assert get_scope_blocklist() == frozenset()

    def test_single_value_no_comma(self):
        with patch.dict(os.environ, {"OKTA_SCOPE_BLOCKLIST": "only_one"}):
            assert get_scope_blocklist() == frozenset({"only_one"})


class TestFilterAsScopes:
    def _blocklist_default(self):
        os.environ.pop("OKTA_SCOPE_BLOCKLIST", None)

    def test_strips_oidc(self):
        self._blocklist_default()
        result = filter_as_scopes(["openid", "profile", "bedrock:InvokeAgent"])
        assert result == ["bedrock:InvokeAgent"]

    def test_strips_interclient_access_by_default(self):
        self._blocklist_default()
        result = filter_as_scopes(["interclient_access", "bedrock:InvokeAgent"])
        assert result == ["bedrock:InvokeAgent"]

    def test_strips_device_sso_by_default(self):
        self._blocklist_default()
        result = filter_as_scopes(["device_sso", "bedrock:InvokeAgent"])
        assert result == ["bedrock:InvokeAgent"]

    def test_strips_all_noise(self):
        self._blocklist_default()
        input_scopes = [
            "openid", "profile", "email", "offline_access",
            "interclient_access", "bedrock:InvokeAgent", "s3:Read",
        ]
        assert filter_as_scopes(input_scopes) == [
            "bedrock:InvokeAgent", "s3:Read",
        ]

    def test_preserves_order(self):
        self._blocklist_default()
        result = filter_as_scopes(["b", "a", "c"])
        assert result == ["b", "a", "c"]

    def test_dedupes(self):
        self._blocklist_default()
        result = filter_as_scopes(["bedrock:A", "bedrock:A", "bedrock:B"])
        assert result == ["bedrock:A", "bedrock:B"]

    def test_custom_blocklist_env(self):
        with patch.dict(os.environ, {"OKTA_SCOPE_BLOCKLIST": "bedrock:A"}):
            result = filter_as_scopes(["bedrock:A", "bedrock:B"])
            assert result == ["bedrock:B"]

    def test_empty_input(self):
        self._blocklist_default()
        assert filter_as_scopes([]) == []

    def test_none_input_is_safe(self):
        self._blocklist_default()
        assert filter_as_scopes(None) == []  # type: ignore[arg-type]

    def test_all_scopes_stripped_returns_empty(self):
        self._blocklist_default()
        result = filter_as_scopes(["openid", "profile", "interclient_access"])
        assert result == []
