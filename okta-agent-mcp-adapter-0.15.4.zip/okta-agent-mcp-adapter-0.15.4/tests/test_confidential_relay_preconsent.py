"""
Tests for ConfidentialRelay pre-consent extensions.

Tests:
- start_preconsent_authorization builds correct Okta URL with PKCE
- start_preconsent_authorization rejects empty client_id
- is_preconsent_state returns True/False for correct session types
- handle_preconsent_callback exchanges code and returns id_token
- handle_preconsent_callback rejects unknown state, expired sessions
- handle_preconsent_callback handles exchange failures and missing id_token
- Pre-consent and relay sessions are isolated from each other
"""

import json
import pytest
from datetime import datetime, timezone, timedelta
from urllib.parse import urlparse, parse_qs

import httpx

from okta_agent_proxy.auth.cimd_fetcher import CIMDMetadata
from okta_agent_proxy.auth.confidential_relay import (
    ConfidentialRelay,
    PreConsentSession,
    RelayError,
)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

AGENT_ID = "test-agent"
AGENT_CLIENT_ID = "0oa_agent_test"
AGENT_CLIENT_SECRET = "agent_secret_xyz"
SCOPES = "openid profile email"

CLIENT_ID_URL = "https://myapp.example.com/oauth.json"
REDIRECT_URI = "http://localhost:8080/callback"


def _make_relay(transport=None):
    return ConfidentialRelay(
        gateway_base_url="http://localhost:8000",
        okta_domain="dev-test.okta.com",
        transport=transport,
    )


def _token_response_transport(
    access_token="at_test123",
    id_token="idt_test123",
    refresh_token="rt_test123",
    expires_in=3600,
    status_code=200,
    body_override=None,
):
    """Mock transport that returns a token response from Okta."""
    body = body_override or {
        "access_token": access_token,
        "id_token": id_token,
        "refresh_token": refresh_token,
        "token_type": "Bearer",
        "expires_in": expires_in,
    }

    def handler(request: httpx.Request) -> httpx.Response:
        return httpx.Response(
            status_code=status_code,
            content=json.dumps(body).encode(),
            headers={"content-type": "application/json"},
        )

    return httpx.MockTransport(handler)


def _metadata(client_id=CLIENT_ID_URL, redirect_uris=None):
    return CIMDMetadata(
        client_id=client_id,
        client_name="Test App",
        redirect_uris=redirect_uris or [REDIRECT_URI],
        grant_types=["authorization_code"],
        response_types=["code"],
        token_endpoint_auth_method="none",
        jwks_uri=None,
        logo_uri=None,
        client_uri=None,
        scope=None,
        domain=urlparse(client_id).hostname or "",
        fetched_at=datetime.now(timezone.utc),
        raw_json={},
    )


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_start_preconsent_authorization_builds_okta_url():
    """start_preconsent_authorization returns a URL with correct params and stores the session."""
    relay = _make_relay()

    url = await relay.start_preconsent_authorization(
        agent_id=AGENT_ID,
        relay_client_id=AGENT_CLIENT_ID,
        relay_client_secret=AGENT_CLIENT_SECRET,
        scopes=SCOPES,
    )

    parsed = urlparse(url)
    params = parse_qs(parsed.query)

    assert parsed.scheme == "https"
    assert "dev-test.okta.com" in parsed.netloc
    assert params["client_id"] == [AGENT_CLIENT_ID]
    assert params["response_type"] == ["code"]
    assert params["scope"] == [SCOPES]
    assert params["code_challenge_method"] == ["S256"]
    assert "code_challenge" in params
    assert "state" in params

    # Session was stored
    state = params["state"][0]
    assert state in relay._preconsent_sessions_by_state
    session = relay._preconsent_sessions_by_state[state]
    assert session.agent_id == AGENT_ID
    assert session.relay_client_id == AGENT_CLIENT_ID
    assert session.relay_client_secret == AGENT_CLIENT_SECRET
    assert session.scopes == SCOPES
    assert session.target_resource is None


@pytest.mark.asyncio
async def test_start_preconsent_authorization_requires_client_id():
    """Passing an empty relay_client_id raises RelayError."""
    relay = _make_relay()

    with pytest.raises(RelayError, match="No relay credentials"):
        await relay.start_preconsent_authorization(
            agent_id=AGENT_ID,
            relay_client_id="",
            relay_client_secret=AGENT_CLIENT_SECRET,
            scopes=SCOPES,
        )


@pytest.mark.asyncio
async def test_is_preconsent_state_true_for_preconsent_session():
    """After start_preconsent_authorization, is_preconsent_state returns True."""
    relay = _make_relay()

    url = await relay.start_preconsent_authorization(
        agent_id=AGENT_ID,
        relay_client_id=AGENT_CLIENT_ID,
        relay_client_secret=AGENT_CLIENT_SECRET,
        scopes=SCOPES,
    )

    state = parse_qs(urlparse(url).query)["state"][0]
    assert relay.is_preconsent_state(state) is True


@pytest.mark.asyncio
async def test_is_preconsent_state_false_for_relay_session():
    """After start_authorization (normal flow), is_preconsent_state returns False."""
    relay = _make_relay()

    url = await relay.start_authorization(
        cimd_metadata=_metadata(),
        auth_params={
            "redirect_uri": REDIRECT_URI,
            "state": "client_state_abc",
            "scope": "openid",
        },
        relay_client_id=AGENT_CLIENT_ID,
        relay_client_secret=AGENT_CLIENT_SECRET,
    )

    state = parse_qs(urlparse(url).query)["state"][0]
    assert relay.is_preconsent_state(state) is False


def test_is_preconsent_state_false_for_unknown():
    """Unknown state returns False."""
    relay = _make_relay()
    assert relay.is_preconsent_state("totally_unknown_state") is False


@pytest.mark.asyncio
async def test_handle_preconsent_callback_success():
    """Successful callback returns id_token, agent_id, target_resource and cleans up session."""
    transport = _token_response_transport(id_token="id_tok_abc123")
    relay = _make_relay(transport=transport)

    url = await relay.start_preconsent_authorization(
        agent_id=AGENT_ID,
        relay_client_id=AGENT_CLIENT_ID,
        relay_client_secret=AGENT_CLIENT_SECRET,
        scopes=SCOPES,
        target_resource="hr-system",
    )

    state = parse_qs(urlparse(url).query)["state"][0]

    result = await relay.handle_preconsent_callback(
        relay_state=state,
        authorization_code="authcode_xyz",
    )

    assert result["id_token"] == "id_tok_abc123"
    assert result["agent_id"] == AGENT_ID
    assert result["target_resource"] == "hr-system"

    # Session should be cleaned up
    assert state not in relay._preconsent_sessions_by_state


@pytest.mark.asyncio
async def test_handle_preconsent_callback_unknown_state():
    """Unknown state raises RelayError."""
    relay = _make_relay()

    with pytest.raises(RelayError, match="No pre-consent session found"):
        await relay.handle_preconsent_callback(
            relay_state="unknown_state_xyz",
            authorization_code="authcode_xyz",
        )


@pytest.mark.asyncio
async def test_handle_preconsent_callback_expired():
    """Expired session raises RelayError and is cleaned up."""
    relay = _make_relay()

    url = await relay.start_preconsent_authorization(
        agent_id=AGENT_ID,
        relay_client_id=AGENT_CLIENT_ID,
        relay_client_secret=AGENT_CLIENT_SECRET,
        scopes=SCOPES,
    )

    state = parse_qs(urlparse(url).query)["state"][0]

    # Manipulate created_at to be > 300 seconds ago
    session = relay._preconsent_sessions_by_state[state]
    session.created_at = datetime.now(timezone.utc) - timedelta(seconds=301)

    with pytest.raises(RelayError, match="Pre-consent session expired"):
        await relay.handle_preconsent_callback(
            relay_state=state,
            authorization_code="authcode_xyz",
        )

    # Session should be cleaned up
    assert state not in relay._preconsent_sessions_by_state


@pytest.mark.asyncio
async def test_handle_preconsent_callback_token_exchange_failure():
    """Token exchange failure raises RelayError and cleans up session."""
    transport = _token_response_transport(status_code=401)
    relay = _make_relay(transport=transport)

    url = await relay.start_preconsent_authorization(
        agent_id=AGENT_ID,
        relay_client_id=AGENT_CLIENT_ID,
        relay_client_secret=AGENT_CLIENT_SECRET,
        scopes=SCOPES,
    )

    state = parse_qs(urlparse(url).query)["state"][0]

    with pytest.raises(RelayError, match="Pre-consent token exchange failed"):
        await relay.handle_preconsent_callback(
            relay_state=state,
            authorization_code="authcode_xyz",
        )

    # Session should be cleaned up
    assert state not in relay._preconsent_sessions_by_state


@pytest.mark.asyncio
async def test_handle_preconsent_callback_missing_id_token():
    """Response with no id_token raises RelayError and cleans up session."""
    transport = _token_response_transport(
        body_override={"access_token": "at_only", "token_type": "Bearer"}
    )
    relay = _make_relay(transport=transport)

    url = await relay.start_preconsent_authorization(
        agent_id=AGENT_ID,
        relay_client_id=AGENT_CLIENT_ID,
        relay_client_secret=AGENT_CLIENT_SECRET,
        scopes=SCOPES,
    )

    state = parse_qs(urlparse(url).query)["state"][0]

    with pytest.raises(RelayError, match="no id_token"):
        await relay.handle_preconsent_callback(
            relay_state=state,
            authorization_code="authcode_xyz",
        )

    # Session should be cleaned up
    assert state not in relay._preconsent_sessions_by_state


@pytest.mark.asyncio
async def test_preconsent_and_relay_sessions_are_isolated():
    """Pre-consent and relay sessions don't appear in each other's stores."""
    relay = _make_relay()

    # Create a normal relay session
    relay_url = await relay.start_authorization(
        cimd_metadata=_metadata(),
        auth_params={
            "redirect_uri": REDIRECT_URI,
            "state": "client_state_abc",
            "scope": "openid",
        },
        relay_client_id=AGENT_CLIENT_ID,
        relay_client_secret=AGENT_CLIENT_SECRET,
    )
    relay_state = parse_qs(urlparse(relay_url).query)["state"][0]

    # Create a pre-consent session
    preconsent_url = await relay.start_preconsent_authorization(
        agent_id=AGENT_ID,
        relay_client_id=AGENT_CLIENT_ID,
        relay_client_secret=AGENT_CLIENT_SECRET,
        scopes=SCOPES,
    )
    preconsent_state = parse_qs(urlparse(preconsent_url).query)["state"][0]

    # Relay state is in _sessions_by_state but NOT in _preconsent_sessions_by_state
    assert relay_state in relay._sessions_by_state
    assert relay_state not in relay._preconsent_sessions_by_state

    # Pre-consent state is in _preconsent_sessions_by_state but NOT in _sessions_by_state
    assert preconsent_state in relay._preconsent_sessions_by_state
    assert preconsent_state not in relay._sessions_by_state

    # is_preconsent_state correctly distinguishes
    assert relay.is_preconsent_state(relay_state) is False
    assert relay.is_preconsent_state(preconsent_state) is True
