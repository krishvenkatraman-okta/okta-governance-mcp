"""
Tests for CIMD agent matching — step 2 of resolution order.

Verifies that pre-registered agents with cimd_client_id_url are matched
to incoming CIMD clients BEFORE the auto-provision fallback (step 3).
Also verifies that matched agent credentials flow correctly to ID-JAG exchange.
"""

import json
import os
import pytest
from unittest.mock import MagicMock, AsyncMock, patch

from okta_agent_proxy.auth.client_registry import ClientRegistry, ClientInfo
from okta_agent_proxy.auth.cimd_fetcher import CIMDFetcher, CIMDMetadata, CIMDFetchError
from okta_agent_proxy.auth.cimd_policy import CIMDTrustPolicy, CIMDTrustResult, TrustLevel
from okta_agent_proxy.auth.cross_app_access import OktaCrossAppAccessManager
from datetime import datetime, timezone


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

CIMD_URL = "https://claude.ai/oauth/client-metadata.json"

PREREGISTERED_AGENT = {
    "agent_id": "claude-code",
    "agent_name": "claude-code",
    "client_id": "0oa_real_okta_app",
    "client_secret": "real_secret",
    "private_key": json.dumps({
        "kty": "RSA", "n": "real-n-value", "e": "AQAB",
        "d": "real-d-value", "kid": "real-key-1",
    }),
    "cimd_client_id_url": CIMD_URL,
    "resource_access": ["hr-system", "deploy-server"],
    "enabled": True,
}


def _mock_store(agents=None, cimd_match=None):
    store = MagicMock()
    store.get_all_agents.return_value = agents or []
    store.get_agent_by_cimd_client_id.return_value = cimd_match
    del store.get_dcr_registration
    return store


def _mock_fetcher(error=None):
    fetcher = MagicMock(spec=CIMDFetcher)
    if error:
        fetcher.fetch_and_validate = AsyncMock(side_effect=error)
    else:
        metadata = CIMDMetadata(
            client_id=CIMD_URL,
            client_name="Claude Code",
            redirect_uris=["http://localhost:8080/callback"],
            grant_types=["authorization_code"],
            response_types=["code"],
            token_endpoint_auth_method="none",
            jwks_uri=None,
            logo_uri=None,
            client_uri=None,
            scope="openid",
            domain="claude.ai",
            fetched_at=datetime.now(timezone.utc),
            raw_json={},
        )
        fetcher.fetch_and_validate = AsyncMock(return_value=metadata)
    return fetcher


def _mock_policy(allowed=True, trust_level=TrustLevel.TRUSTED,
                  resource_access=None, auto_provision=False):
    policy = MagicMock(spec=CIMDTrustPolicy)
    result = CIMDTrustResult(
        allowed=allowed,
        trust_level=trust_level,
        domain="claude.ai",
        reason="test",
        redirect_uris_valid=True,
        resource_access=resource_access or [],
    )
    policy.evaluate = AsyncMock(return_value=result)
    policy.auto_provision_agent = auto_provision
    return policy


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------


class TestCIMDAgentMatching:
    async def test_cimd_url_matched_to_preregistered_agent(self):
        """Pre-registered agent with cimd_client_id_url is found and has real credentials."""
        store = _mock_store(cimd_match=PREREGISTERED_AGENT)
        fetcher = _mock_fetcher()
        policy = _mock_policy()
        registry = ClientRegistry(store, fetcher, policy)

        result = await registry.resolve(CIMD_URL)

        assert result is not None
        assert result.registration_source == "cimd-matched"
        assert result.agent_config is not None
        # Real Okta client_id (not the CIMD URL)
        assert result.agent_config["client_id"] == "0oa_real_okta_app"
        # Real private key (not PLACEHOLDER)
        pk = json.loads(result.agent_config["private_key"])
        assert pk["n"] == "real-n-value"
        assert pk["d"] == "real-d-value"
        # ClientInfo.client_id remains the CIMD URL (for relay handling)
        assert result.client_id == CIMD_URL
        # Fetcher should NOT have been called
        fetcher.fetch_and_validate.assert_not_called()

    async def test_cimd_url_no_match_falls_through_to_auto_provision(self):
        """No pre-registered agent for URL → falls through to CIMD auto-provision."""
        store = _mock_store(cimd_match=None)
        store.create_cimd_agent = MagicMock(return_value=True)
        store.get_agent_by_client_id = MagicMock(return_value=None)

        fetcher = _mock_fetcher()
        policy = _mock_policy(
            allowed=True,
            trust_level=TrustLevel.TRUSTED,
            resource_access=["hr-system"],
            auto_provision=True,
        )
        registry = ClientRegistry(store, fetcher, policy)

        result = await registry.resolve(CIMD_URL)

        assert result is not None
        # Falls through to step 3 (CIMD auto-provision)
        assert result.registration_source == "cimd"
        # Fetcher WAS called (step 3 fetches metadata)
        fetcher.fetch_and_validate.assert_called_once_with(CIMD_URL)

    async def test_cimd_match_takes_priority_over_auto_provision(self):
        """Pre-registered agent wins even when auto-provision is enabled."""
        store = _mock_store(cimd_match=PREREGISTERED_AGENT)
        store.create_cimd_agent = MagicMock(return_value=True)

        fetcher = _mock_fetcher()
        policy = _mock_policy(
            allowed=True,
            trust_level=TrustLevel.TRUSTED,
            resource_access=["hr-system"],
            auto_provision=True,
        )
        registry = ClientRegistry(store, fetcher, policy)

        result = await registry.resolve(CIMD_URL)

        assert result is not None
        assert result.registration_source == "cimd-matched"
        assert result.agent_config["client_id"] == "0oa_real_okta_app"
        # auto-provision should NOT have been called
        store.create_cimd_agent.assert_not_called()
        # Fetcher should NOT have been called
        fetcher.fetch_and_validate.assert_not_called()

    async def test_cimd_match_registration_source_is_cimd_matched(self):
        """Verify registration_source is 'cimd-matched' (distinct from 'manual' and 'cimd')."""
        store = _mock_store(cimd_match=PREREGISTERED_AGENT)
        fetcher = _mock_fetcher()
        policy = _mock_policy()
        registry = ClientRegistry(store, fetcher, policy)

        result = await registry.resolve(CIMD_URL)

        assert result.registration_source == "cimd-matched"
        # Not "manual" (that's for Okta client_id matches)
        assert result.registration_source != "manual"
        # Not "cimd" (that's for auto-provisioned)
        assert result.registration_source != "cimd"

    async def test_cimd_match_disabled_agent_not_returned(self):
        """Disabled pre-registered agent is not matched (enabled_only=True in store)."""
        # Store returns None because get_agent_by_cimd_client_id uses enabled_only=True
        store = _mock_store(cimd_match=None)
        fetcher = _mock_fetcher()
        policy = _mock_policy(
            allowed=True,
            trust_level=TrustLevel.TRUSTED,
            resource_access=["hr-system"],
            auto_provision=False,
        )
        registry = ClientRegistry(store, fetcher, policy)

        result = await registry.resolve(CIMD_URL)

        # Falls through to CIMD auto-provision path
        assert result is not None
        assert result.registration_source == "cimd"

    async def test_cimd_match_resource_access_from_agent(self):
        """Resource access comes from the pre-registered agent, not CIMD policy defaults."""
        agent = {**PREREGISTERED_AGENT, "resource_access": ["hr-system", "deploy-server", "finance"]}
        store = _mock_store(cimd_match=agent)
        fetcher = _mock_fetcher()
        # Policy would give different resources
        policy = _mock_policy(resource_access=["only-hr"])
        registry = ClientRegistry(store, fetcher, policy)

        result = await registry.resolve(CIMD_URL)

        assert result is not None
        assert result.resource_access == ["hr-system", "deploy-server", "finance"]

    async def test_cimd_match_trust_level_is_pre_registered(self):
        """Trust level for CIMD-matched agents is 'pre-registered'."""
        store = _mock_store(cimd_match=PREREGISTERED_AGENT)
        fetcher = _mock_fetcher()
        policy = _mock_policy()
        registry = ClientRegistry(store, fetcher, policy)

        result = await registry.resolve(CIMD_URL)

        assert result.trust_level == "pre-registered"

    async def test_cimd_match_store_error_falls_through(self):
        """If store.get_agent_by_cimd_client_id raises, falls through gracefully."""
        store = _mock_store()
        store.get_agent_by_cimd_client_id.side_effect = Exception("DB connection lost")
        fetcher = _mock_fetcher()
        policy = _mock_policy(
            allowed=True,
            trust_level=TrustLevel.TRUSTED,
            resource_access=["hr-system"],
            auto_provision=False,
        )
        registry = ClientRegistry(store, fetcher, policy)

        result = await registry.resolve(CIMD_URL)

        # Falls through to CIMD path despite the error
        assert result is not None
        assert result.registration_source == "cimd"

    async def test_non_cimd_url_skips_cimd_match(self):
        """Non-URL client_ids skip the CIMD URL match step entirely."""
        store = _mock_store(agents=[{
            "agent_id": "cursor",
            "agent_name": "cursor",
            "client_id": "0oa_cursor_app",
            "enabled": True,
            "resource_access": ["hr-system"],
        }])
        fetcher = _mock_fetcher()
        policy = _mock_policy()
        registry = ClientRegistry(store, fetcher, policy)

        result = await registry.resolve("0oa_cursor_app")

        assert result is not None
        assert result.registration_source == "manual"
        # CIMD URL match should NOT have been attempted
        store.get_agent_by_cimd_client_id.assert_not_called()


# ---------------------------------------------------------------------------
# Tests: CIMD-matched agent credentials flow to ID-JAG
# ---------------------------------------------------------------------------


class TestCIMDAgentCredentialsFlow:
    """Verify that CIMD-matched agents' real Okta credentials are used for ID-JAG exchange."""

    REAL_JWK = json.dumps({
        "kty": "RSA",
        "n": "0vx7agoebGcQSuuPiLJXZptN9nndrQmbXEps2aiAFbWhM",
        "e": "AQAB",
        "d": "X4cTteJY_gn4FYPsXB8rdXix5vwsg1FLN5E3EaG6RJoVH",
        "kid": "real-key-1",
    })

    async def test_matched_agent_credentials_used_for_id_jag(self):
        """OktaCrossAppAccessManager receives the pre-registered agent's real
        client_id and private_key (not PLACEHOLDER, not relay client_id)."""
        agent = {
            **PREREGISTERED_AGENT,
            "cimd_client_id_url": CIMD_URL,
        }
        store = _mock_store(cimd_match=agent)
        fetcher = _mock_fetcher()
        policy = _mock_policy()
        registry = ClientRegistry(store, fetcher, policy)

        result = await registry.resolve(CIMD_URL)

        assert result is not None
        assert result.registration_source == "cimd-matched"
        assert result.agent_config is not None

        # Verify the agent_config that would be passed to OktaCrossAppAccessManager
        config = result.agent_config
        assert config["client_id"] == "0oa_real_okta_app"  # Real Okta client_id
        assert config["agent_id"] == "claude-code"

        # Private key is real JWK (not PLACEHOLDER)
        pk = json.loads(config["private_key"])
        assert pk["kty"] == "RSA"
        assert pk["n"] == "real-n-value"
        assert pk["d"] == "real-d-value"
        assert "PLACEHOLDER" not in config["private_key"]

        # Construct OktaCrossAppAccessManager with these credentials
        # to verify _is_placeholder is False
        with patch.dict(os.environ, {"OKTA_DOMAIN": "dev-test.okta.com"}), \
             patch("okta_agent_proxy.auth.cross_app_access.OAuth2Client"), \
             patch("okta_agent_proxy.auth.cross_app_access.OAuth2ClientConfiguration"), \
             patch("okta_agent_proxy.auth.cross_app_access.ClientAssertionAuthorization"), \
             patch("okta_agent_proxy.auth.cross_app_access.JWTBearerClaims"), \
             patch("okta_agent_proxy.auth.cross_app_access.LocalKeyProvider"):
            manager = OktaCrossAppAccessManager(
                agent_id=config["agent_id"],
                client_id=config["client_id"],
                agent_private_key=config["private_key"],
                okta_domain="dev-test.okta.com",
                target_auth_server_id="aus_test123",
                principal_id="agt_test123",
            )
            assert manager._using_gateway_key is False
            assert manager.client_id == "0oa_real_okta_app"
            assert manager.agent_id == "claude-code"

    async def test_matched_agent_no_placeholder_fallback(self):
        """Pre-registered agent with real JWK does NOT trigger placeholder fallback."""
        agent = {
            **PREREGISTERED_AGENT,
            "private_key": self.REAL_JWK,
            "cimd_client_id_url": CIMD_URL,
        }
        store = _mock_store(cimd_match=agent)
        fetcher = _mock_fetcher()
        policy = _mock_policy()
        registry = ClientRegistry(store, fetcher, policy)

        result = await registry.resolve(CIMD_URL)
        config = result.agent_config

        with patch.dict(os.environ, {"OKTA_DOMAIN": "dev-test.okta.com"}), \
             patch("okta_agent_proxy.auth.cross_app_access.OAuth2Client") as mock_client, \
             patch("okta_agent_proxy.auth.cross_app_access.OAuth2ClientConfiguration"), \
             patch("okta_agent_proxy.auth.cross_app_access.ClientAssertionAuthorization"), \
             patch("okta_agent_proxy.auth.cross_app_access.JWTBearerClaims"), \
             patch("okta_agent_proxy.auth.cross_app_access.LocalKeyProvider"):
            manager = OktaCrossAppAccessManager(
                agent_id=config["agent_id"],
                client_id=config["client_id"],
                agent_private_key=config["private_key"],
                okta_domain="dev-test.okta.com",
                target_auth_server_id="aus_test123",
                principal_id="agt_test123",
            )
            # _using_gateway_key must be False — agent has its own key
            assert manager._using_gateway_key is False
            # OAuth2Client should be initialized (not None)
            assert manager._oauth2_client is not None

    async def test_relay_token_accepted_with_matched_agent(self):
        """CIMD tokens bypass JWT validation, so relay client_id audience
        mismatch with the matched agent's client_id is not an issue.

        The unified handler checks relay.lookup_token() BEFORE JWT validation.
        When a CIMD token is found, it skips validate_token() entirely and
        resolves the agent via ClientRegistry instead.
        """
        agent = {
            **PREREGISTERED_AGENT,
            "cimd_client_id_url": CIMD_URL,
        }
        store = _mock_store(cimd_match=agent)
        fetcher = _mock_fetcher()
        policy = _mock_policy()
        registry = ClientRegistry(store, fetcher, policy)

        result = await registry.resolve(CIMD_URL)

        assert result is not None
        assert result.registration_source == "cimd-matched"
        # The agent's Okta client_id is different from the relay's client_id
        assert result.agent_config["client_id"] == "0oa_real_okta_app"
        # But ClientInfo.client_id is the CIMD URL (used for relay token matching)
        assert result.client_id == CIMD_URL
        # This means: token audience = relay client_id, agent credentials = Okta app
        # No conflict because CIMD tokens skip JWT audience validation
