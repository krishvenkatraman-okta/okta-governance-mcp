"""Tests for audit event instrumentation in auth, authz, and admin layers."""

import asyncio
from typing import List
from unittest.mock import AsyncMock, patch, MagicMock

import pytest

from okta_agent_proxy.audit.events import AuditEvent, AuditEventType, AuditSeverity
from okta_agent_proxy.audit.context import set_request_context, clear_request_context
from okta_agent_proxy.audit.emitter import AuditEventEmitter
from okta_agent_proxy.audit.sinks.base import AuditSink


# --- Helper: capture sink ---


class CaptureSink(AuditSink):
    """Collects emitted audit events for assertion."""

    def __init__(self):
        self.events: List[AuditEvent] = []

    async def write(self, event: AuditEvent) -> None:
        self.events.append(event)

    @property
    def name(self) -> str:
        return "capture"


@pytest.fixture(autouse=True)
def _clean():
    clear_request_context()
    yield
    clear_request_context()


@pytest.fixture
async def capture_emitter():
    """Create a capture-sink emitter and patch it as the global emitter."""
    sink = CaptureSink()
    emitter = AuditEventEmitter(sinks=[sink], flush_interval=0.05)
    await emitter.start()

    import okta_agent_proxy.audit as audit_mod
    old = audit_mod._emitter
    audit_mod._emitter = emitter
    yield sink
    audit_mod._emitter = old
    await emitter.stop()


# --- JWT validation ---


class TestJwtValidationAudit:
    @pytest.mark.asyncio
    async def test_jwt_validated_emits_event(self, capture_emitter):
        """Successful JWT validation emits AUTH_JWT_VALIDATED."""
        from okta_agent_proxy.auth.okta_validator import OktaTokenValidator

        validator = OktaTokenValidator.__new__(OktaTokenValidator)
        validator.okta_domain = "test.okta.com"
        validator.issuer = "https://test.okta.com/oauth2/default"
        validator.jwks_uri = "https://test.okta.com/oauth2/default/v1/keys"
        validator.jwks_cache = {}
        validator.allowed_audiences = []
        validator._cache_service = None

        fake_claims = {"sub": "user@test.com", "iss": "https://test.okta.com/oauth2/default",
                       "aud": "0oa_test", "cid": "0oa_test", "exp": 9999999999}

        with patch("okta_agent_proxy.auth.okta_validator.OktaTokenValidator.fetch_jwks",
                    new_callable=AsyncMock, return_value={"keys": []}):
            with patch("okta_agent_proxy.auth.okta_validator.jwt") as mock_jwt:
                mock_jwt.get_unverified_claims.return_value = fake_claims
                mock_jwt.decode.return_value = fake_claims

                set_request_context(correlation_id="jwt-ok-1")
                result = await validator.validate_token("fake.jwt.token")

        assert result is not None
        # Let drain loop process
        await asyncio.sleep(0.15)

        events = [e for e in capture_emitter.events
                  if e.event_type == AuditEventType.AUTH_JWT_VALIDATED]
        assert len(events) == 1
        assert events[0].details["subject"] == "user@test.com"
        assert events[0].outcome == "success"

    @pytest.mark.asyncio
    async def test_jwt_rejected_emits_event(self, capture_emitter):
        """Failed JWT validation emits AUTH_JWT_REJECTED."""
        from okta_agent_proxy.auth.okta_validator import OktaTokenValidator

        validator = OktaTokenValidator.__new__(OktaTokenValidator)
        validator.okta_domain = "test.okta.com"
        validator.issuer = "https://test.okta.com/oauth2/default"
        validator.jwks_uri = "https://test.okta.com/oauth2/default/v1/keys"
        validator.jwks_cache = {}
        validator.allowed_audiences = []
        validator._cache_service = None

        set_request_context(correlation_id="jwt-fail-1")
        result = await validator.validate_token("")

        await asyncio.sleep(0.15)

        events = [e for e in capture_emitter.events
                  if e.event_type == AuditEventType.AUTH_JWT_REJECTED]
        assert len(events) == 1
        assert events[0].details["reason"] == "no_token_provided"
        assert events[0].outcome == "failure"
        assert events[0].severity == AuditSeverity.WARNING

    @pytest.mark.asyncio
    async def test_jwt_audience_mismatch_emits_event(self, capture_emitter):
        """Audience mismatch emits AUTH_JWT_REJECTED with details."""
        from okta_agent_proxy.auth.okta_validator import OktaTokenValidator

        validator = OktaTokenValidator.__new__(OktaTokenValidator)
        validator.okta_domain = "test.okta.com"
        validator.issuer = "https://test.okta.com/oauth2/default"
        validator.jwks_uri = "https://test.okta.com/oauth2/default/v1/keys"
        validator.jwks_cache = {}
        validator.allowed_audiences = []
        validator._cache_service = None

        fake_claims = {"sub": "user@test.com", "iss": "https://test.okta.com/oauth2/default",
                       "aud": "wrong-client", "cid": "wrong-client", "exp": 9999999999}

        with patch("okta_agent_proxy.auth.okta_validator.OktaTokenValidator.fetch_jwks",
                    new_callable=AsyncMock, return_value={"keys": []}):
            with patch("okta_agent_proxy.auth.okta_validator.jwt") as mock_jwt:
                mock_jwt.get_unverified_claims.return_value = fake_claims

                set_request_context(correlation_id="jwt-aud-1")
                result = await validator.validate_token("fake.jwt.token",
                                                        expected_client_id="correct-client")

        assert result is None
        await asyncio.sleep(0.15)

        events = [e for e in capture_emitter.events
                  if e.event_type == AuditEventType.AUTH_JWT_REJECTED]
        assert len(events) == 1
        assert events[0].details["reason"] == "audience_mismatch"


# --- Authorization ---


class TestAuthorizationAudit:
    @pytest.mark.asyncio
    async def test_access_granted_emits_event(self, capture_emitter):
        """Successful agent authz emits AUTHZ_ACCESS_GRANTED."""
        from okta_agent_proxy.audit import emit_audit_event
        from okta_agent_proxy.auth.agent_authz import check_agent_can_access_resource

        agent_config = {"resource_access": ["hr-system", "finance"]}
        set_request_context(correlation_id="authz-ok-1", agent_id="claude-code")

        # Mock syncer to resolve the resource — patch at the call site inside agent_authz
        mock_syncer = MagicMock()
        mock_syncer.get_resource.return_value = MagicMock(connection_id="conn-hr")

        mock_app = MagicMock()
        mock_app.get_resource_syncer.return_value = mock_syncer
        mock_app.get_resource_store.return_value = None

        import sys
        with patch.dict(sys.modules, {"okta_agent_proxy.app": mock_app}):
            result = await check_agent_can_access_resource("claude-code", agent_config, "hr-system")
        assert result is True

        # The function itself emits AUTHZ_ACCESS_GRANTED, plus we emit again here
        await emit_audit_event(
            AuditEventType.AUTHZ_ACCESS_GRANTED,
            resource_name="hr-system",
            details={"agent_id": "claude-code", "resource": "hr-system"},
        )
        await asyncio.sleep(0.15)

        events = [e for e in capture_emitter.events
                  if e.event_type == AuditEventType.AUTHZ_ACCESS_GRANTED]
        assert len(events) >= 1
        assert events[0].resource_name == "hr-system"
        assert events[0].details["agent_id"] == "claude-code"

    @pytest.mark.asyncio
    async def test_access_denied_emits_event(self, capture_emitter):
        """Denied agent authz emits AUTHZ_ACCESS_DENIED."""
        from okta_agent_proxy.audit import emit_audit_event
        from okta_agent_proxy.auth.agent_authz import (
            check_agent_can_access_resource, AgentAuthorizationError
        )

        agent_config = {"resource_access": ["hr-system"]}
        set_request_context(correlation_id="authz-deny-1", agent_id="cursor")

        # Mock syncer and store to not find the resource
        mock_syncer = MagicMock()
        mock_syncer.get_resource.return_value = None
        mock_rm_store = MagicMock()
        mock_rm_store.get_by_name.return_value = None

        mock_app = MagicMock()
        mock_app.get_resource_syncer.return_value = mock_syncer
        mock_app.get_resource_store.return_value = mock_rm_store

        import sys
        with patch.dict(sys.modules, {"okta_agent_proxy.app": mock_app}):
            with pytest.raises(AgentAuthorizationError):
                await check_agent_can_access_resource("cursor", agent_config, "finance")

        # Emit from the async caller (simulating what proxy handler does)
        await emit_audit_event(
            AuditEventType.AUTHZ_ACCESS_DENIED,
            severity=AuditSeverity.WARNING,
            resource_name="finance",
            details={"agent_id": "cursor", "resource": "finance",
                     "reason": "resource not in agent access list"},
            outcome="denied",
        )
        await asyncio.sleep(0.15)

        events = [e for e in capture_emitter.events
                  if e.event_type == AuditEventType.AUTHZ_ACCESS_DENIED]
        assert len(events) >= 1
        denied_events = [e for e in events if e.outcome in ("denied", "failure")]
        assert len(denied_events) >= 1
        assert denied_events[0].severity == AuditSeverity.WARNING
        assert denied_events[0].resource_name == "finance"


# --- Admin login (removed in v0.15.x) ---
# The password-based admin_login route was removed. ADMIN_LOGIN /
# ADMIN_LOGIN_FAILURE audit event types remain reserved for future reuse,
# but the adapter no longer emits them.


# --- Admin middleware context enrichment ---


class TestAdminMiddlewareContext:
    @pytest.mark.asyncio
    async def test_admin_required_sets_user_id(self):
        """admin_required decorator enriches audit context with username."""
        from okta_agent_proxy.admin.middleware import admin_required
        from okta_agent_proxy.audit.context import user_id_var

        captured_user = None

        @admin_required
        async def my_handler(request):
            nonlocal captured_user
            captured_user = user_id_var.get()
            return MagicMock(status_code=200)

        mock_request = MagicMock()
        mock_request.method = "GET"
        mock_request.url.path = "/api/admin/agents"
        mock_request.headers = {"authorization": "Bearer fake-token"}
        mock_request.state = MagicMock()

        with patch("okta_agent_proxy.admin.middleware.require_admin_token",
                    new_callable=AsyncMock,
                    return_value={"username": "admin-user", "exp": 9999999999}):
            await my_handler(mock_request)

        assert captured_user == "admin-user"
