"""Unit tests for the global-logout allowlist pub/sub invalidation hook."""

import pytest

from okta_agent_proxy.auth.global_logout_route import (
    _allowlist_cache,
    _reset_allowlist_cache,
    invalidate_agent_client_id_allowlist,
)


@pytest.fixture(autouse=True)
def _clean():
    _reset_allowlist_cache()
    yield
    _reset_allowlist_cache()


def test_invalidate_marks_cache_unloaded():
    _allowlist_cache["set"] = frozenset({"old"})
    _allowlist_cache["fetched_at"] = 9999.0
    _allowlist_cache["loaded"] = True
    invalidate_agent_client_id_allowlist()
    assert _allowlist_cache["loaded"] is False
    assert _allowlist_cache["fetched_at"] == 0.0
    # The set itself is preserved as last-known-good
    assert _allowlist_cache["set"] == frozenset({"old"})


def test_invalidate_is_idempotent_when_unloaded():
    """Invalidating an already-unloaded cache is a no-op."""
    invalidate_agent_client_id_allowlist()
    invalidate_agent_client_id_allowlist()  # second call must not raise
    assert _allowlist_cache["loaded"] is False
