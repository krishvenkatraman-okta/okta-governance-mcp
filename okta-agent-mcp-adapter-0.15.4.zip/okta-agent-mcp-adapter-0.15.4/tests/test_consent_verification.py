"""
Tests for ConsentVerificationService.

All tests use mocked router, token_cache, and STS exchanger.
"""

import base64
import json
import pytest
from unittest.mock import AsyncMock, MagicMock, patch, call

from okta_agent_proxy.auth.consent_transaction import (
    ConsentConnectionStatus,
    ConsentTransaction,
)
from okta_agent_proxy.auth.consent_verification import ConsentVerificationService


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _make_id_token(sub="user123"):
    """Create a minimal unsigned JWT with a sub claim."""
    header = base64.urlsafe_b64encode(json.dumps({"alg": "none"}).encode()).rstrip(b"=").decode()
    payload = base64.urlsafe_b64encode(json.dumps({"sub": sub}).encode()).rstrip(b"=").decode()
    return f"{header}.{payload}."


AGENT_CONFIG = {
    "agent_id": "agent-1",
    "client_id": "0oa_xyz",
    "private_key": "PLACEHOLDER",
    "principal_id": "pid_abc",
}


def _make_resource(name, auth_method="okta-sts", connection_id="conn-1", metadata=None):
    rc = MagicMock()
    rc.name = name
    rc.auth_method = auth_method
    rc.connection_id = connection_id
    rc.metadata = metadata or {
        "app_instance_name": f"{name} Provider",
        "resource_indicator": f"orn:okta:test:{name}",
    }
    return rc


def _make_router(resources):
    """Create a mock router with list_resources and resolve_resource."""
    router = MagicMock()
    resource_map = {rc.name: rc for rc in resources}
    router.list_resources.return_value = resource_map
    router.resolve_resource.side_effect = lambda name, agent_id=None: resource_map.get(name)
    return router


def _make_tx(**overrides):
    defaults = dict(
        transaction_id="tx-001",
        session_id="sess-001",
        original_redirect_uri="http://localhost:9999/callback",
        original_state="state_abc",
        original_client_id="https://app.example.com/oauth.json",
        id_token=_make_id_token("user123"),
        access_token="at_123",
        agent_id="agent-1",
        agent_config=AGENT_CONFIG,
    )
    defaults.update(overrides)
    return ConsentTransaction(**defaults)


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------


class TestGetSTSResources:
    def test_get_sts_resources_filters_by_auth_method(self):
        sts_resource = _make_resource("github", auth_method="okta-sts")
        xaa_resource = _make_resource("hr-system", auth_method="okta-cross-app")
        router = _make_router([sts_resource, xaa_resource])
        cache = MagicMock()

        svc = ConsentVerificationService(router, cache)
        result = svc.get_sts_resources("agent-1", AGENT_CONFIG)

        assert len(result) == 1
        assert result[0].name == "github"

    def test_get_sts_resources_empty_when_none(self):
        xaa_resource = _make_resource("hr-system", auth_method="okta-cross-app")
        router = _make_router([xaa_resource])
        cache = MagicMock()

        svc = ConsentVerificationService(router, cache)
        result = svc.get_sts_resources("agent-1", AGENT_CONFIG)

        assert result == []


class TestVerifyAll:
    @patch("okta_agent_proxy.auth.consent_verification.emit_audit_event")
    @patch("okta_agent_proxy.auth.okta_sts_exchanger.OktaSTSTokenExchanger")
    async def test_verify_all_all_verified(self, MockExchanger, mock_audit):
        """All connections verified → transaction complete, tokens cached."""
        mock_instance = AsyncMock()
        mock_instance.exchange.return_value = {
            "status": "success",
            "access_token": "isv_token_1",
            "expires_in": 3600,
        }
        MockExchanger.return_value = mock_instance

        r1 = _make_resource("github", connection_id="c1")
        r2 = _make_resource("jira", connection_id="c2")
        router = _make_router([r1, r2])
        cache = MagicMock()
        svc = ConsentVerificationService(router, cache)

        tx = _make_tx()
        await svc.verify_all(tx)

        assert tx.status == "complete"
        assert len(tx.connections) == 2
        assert all(c.status == "verified" for c in tx.connections)
        assert cache.set_sts_token.call_count == 2

    @patch("okta_agent_proxy.auth.consent_verification.emit_audit_event")
    @patch("okta_agent_proxy.auth.okta_sts_exchanger.OktaSTSTokenExchanger")
    async def test_verify_all_some_consent_required(self, MockExchanger, mock_audit):
        """Mix of success and consent_required → consents_required status."""
        mock_instance = AsyncMock()
        mock_instance.exchange.side_effect = [
            {"status": "success", "access_token": "tok1", "expires_in": 3600},
            {"status": "consent_required", "interaction_uri": "https://okta/consent"},
        ]
        MockExchanger.return_value = mock_instance

        r1 = _make_resource("github", connection_id="c1")
        r2 = _make_resource("jira", connection_id="c2")
        router = _make_router([r1, r2])
        cache = MagicMock()
        svc = ConsentVerificationService(router, cache)

        tx = _make_tx()
        await svc.verify_all(tx)

        assert tx.status == "consents_required"
        assert tx.connections[0].status == "verified"
        assert tx.connections[1].status == "consent_required"
        assert tx.connections[1].interaction_uri == "https://okta/consent"

    @patch("okta_agent_proxy.auth.consent_verification.emit_audit_event")
    @patch("okta_agent_proxy.auth.okta_sts_exchanger.OktaSTSTokenExchanger")
    async def test_verify_all_exchange_error(self, MockExchanger, mock_audit):
        """Exchanger throws → connection error, transaction still completes."""
        mock_instance = AsyncMock()
        mock_instance.exchange.side_effect = RuntimeError("STS unavailable")
        MockExchanger.return_value = mock_instance

        r1 = _make_resource("github", connection_id="c1")
        router = _make_router([r1])
        cache = MagicMock()
        svc = ConsentVerificationService(router, cache)

        tx = _make_tx()
        await svc.verify_all(tx)

        assert tx.status == "complete"
        assert tx.connections[0].status == "error"
        assert "STS unavailable" in tx.connections[0].error_message

    @patch("okta_agent_proxy.auth.consent_verification.emit_audit_event")
    async def test_verify_all_no_sts_resources(self, mock_audit):
        """No STS resources → immediate complete."""
        xaa_resource = _make_resource("hr", auth_method="okta-cross-app")
        router = _make_router([xaa_resource])
        cache = MagicMock()
        svc = ConsentVerificationService(router, cache)

        tx = _make_tx()
        await svc.verify_all(tx)

        assert tx.status == "complete"
        assert len(tx.connections) == 0


class TestRecheckPending:
    @patch("okta_agent_proxy.auth.consent_verification.emit_audit_event")
    @patch("okta_agent_proxy.auth.okta_sts_exchanger.OktaSTSTokenExchanger")
    async def test_recheck_pending_reattempts_consent_required(
        self, MockExchanger, mock_audit
    ):
        """After recheck, consent_required → verified."""
        mock_instance = AsyncMock()
        mock_instance.exchange.return_value = {
            "status": "success",
            "access_token": "isv_tok",
            "expires_in": 3600,
        }
        MockExchanger.return_value = mock_instance

        tx = _make_tx()
        tx.connections = [
            ConsentConnectionStatus(
                connection_id="c1", resource_name="github",
                provider="GitHub", resource_indicator="orn:okta:test:github",
                status="consent_required",
                interaction_uri="https://okta/consent",
            ),
        ]
        tx.status = "consents_required"

        router = MagicMock()
        cache = MagicMock()
        svc = ConsentVerificationService(router, cache)

        await svc.recheck_pending(tx)

        assert tx.connections[0].status == "verified"
        assert tx.status == "complete"

    @patch("okta_agent_proxy.auth.consent_verification.emit_audit_event")
    @patch("okta_agent_proxy.auth.okta_sts_exchanger.OktaSTSTokenExchanger")
    async def test_recheck_pending_skips_verified(self, MockExchanger, mock_audit):
        """Already verified connections are not re-checked."""
        mock_instance = AsyncMock()
        MockExchanger.return_value = mock_instance

        tx = _make_tx()
        tx.connections = [
            ConsentConnectionStatus(
                connection_id="c1", resource_name="github",
                provider="GitHub", resource_indicator="orn:1",
                status="verified",
            ),
        ]

        router = MagicMock()
        cache = MagicMock()
        svc = ConsentVerificationService(router, cache)

        await svc.recheck_pending(tx)

        mock_instance.exchange.assert_not_called()


class TestTokenCaching:
    @patch("okta_agent_proxy.auth.consent_verification.emit_audit_event")
    @patch("okta_agent_proxy.auth.okta_sts_exchanger.OktaSTSTokenExchanger")
    async def test_token_cached_on_success(self, MockExchanger, mock_audit):
        """Verify set_sts_token called with correct args."""
        mock_instance = AsyncMock()
        mock_instance.exchange.return_value = {
            "status": "success",
            "access_token": "isv_tok_github",
            "expires_in": 7200,
        }
        MockExchanger.return_value = mock_instance

        r1 = _make_resource("github", connection_id="c1", metadata={
            "app_instance_name": "GitHub",
            "resource_indicator": "orn:okta:test:github",
        })
        router = _make_router([r1])
        cache = MagicMock()
        svc = ConsentVerificationService(router, cache)

        tx = _make_tx()
        await svc.verify_all(tx)

        cache.set_sts_token.assert_called_once_with(
            "user123", "orn:okta:test:github", "isv_tok_github", 7200
        )

    def test_user_id_extracted_from_id_token(self):
        """Verify sub claim extraction."""
        id_token = _make_id_token("user_abc")
        user_id = ConsentVerificationService._extract_user_id(id_token)
        assert user_id == "user_abc"

    def test_user_id_fallback_on_invalid_token(self):
        user_id = ConsentVerificationService._extract_user_id("not.a.jwt")
        assert user_id == "unknown"


class TestFilterResourcesByTarget:
    def test_orn_match(self):
        r1 = _make_resource("github", metadata={"resource_indicator": "orn:okta:rsc456"})
        r2 = _make_resource("jira", metadata={"resource_indicator": "orn:okta:rsc789"})
        router = _make_router([r1, r2])
        svc = ConsentVerificationService(router, MagicMock())

        result = svc.filter_resources_by_target([r1, r2], "orn:okta:rsc456")
        assert len(result) == 1
        assert result[0].name == "github"

    def test_url_suffix_match(self):
        r1 = _make_resource("hr")
        r2 = _make_resource("github")
        svc = ConsentVerificationService(MagicMock(), MagicMock())

        result = svc.filter_resources_by_target([r1, r2], "https://gateway.example.com/hr")
        assert len(result) == 1
        assert result[0].name == "hr"

    def test_name_match(self):
        r1 = _make_resource("hr")
        r2 = _make_resource("github")
        svc = ConsentVerificationService(MagicMock(), MagicMock())

        result = svc.filter_resources_by_target([r1, r2], "hr")
        assert len(result) == 1
        assert result[0].name == "hr"

    def test_no_match_returns_empty(self):
        r1 = _make_resource("hr")
        r2 = _make_resource("github")
        svc = ConsentVerificationService(MagicMock(), MagicMock())

        result = svc.filter_resources_by_target([r1, r2], "https://gateway.example.com/nonexistent")
        assert result == []

    def test_none_returns_all(self):
        r1 = _make_resource("hr")
        r2 = _make_resource("github")
        svc = ConsentVerificationService(MagicMock(), MagicMock())

        result = svc.filter_resources_by_target([r1, r2], None)
        assert len(result) == 2


class TestVerifyAllPathScoped:
    @patch("okta_agent_proxy.auth.consent_verification.emit_audit_event")
    @patch("okta_agent_proxy.auth.okta_sts_exchanger.OktaSTSTokenExchanger")
    async def test_path_scoped_only_checks_target(self, MockExchanger, mock_audit):
        """With target_resource set, only the matching STS resource is checked."""
        mock_instance = AsyncMock()
        mock_instance.exchange.return_value = {
            "status": "success",
            "access_token": "isv_tok_hr",
            "expires_in": 3600,
        }
        MockExchanger.return_value = mock_instance

        r_hr = _make_resource("hr", connection_id="c1")
        r_github = _make_resource("github", connection_id="c2")
        router = _make_router([r_hr, r_github])
        cache = MagicMock()
        svc = ConsentVerificationService(router, cache)

        tx = _make_tx(target_resource="https://gateway.example.com/hr")
        await svc.verify_all(tx)

        assert tx.status == "complete"
        assert len(tx.connections) == 1
        assert tx.connections[0].resource_name == "hr"
        assert mock_instance.exchange.call_count == 1

    @patch("okta_agent_proxy.auth.consent_verification.emit_audit_event")
    @patch("okta_agent_proxy.auth.okta_sts_exchanger.OktaSTSTokenExchanger")
    async def test_multi_resource_checks_all(self, MockExchanger, mock_audit):
        """With target_resource=None, all STS resources are checked."""
        mock_instance = AsyncMock()
        mock_instance.exchange.return_value = {
            "status": "success",
            "access_token": "isv_tok",
            "expires_in": 3600,
        }
        MockExchanger.return_value = mock_instance

        r_hr = _make_resource("hr", connection_id="c1")
        r_github = _make_resource("github", connection_id="c2")
        router = _make_router([r_hr, r_github])
        cache = MagicMock()
        svc = ConsentVerificationService(router, cache)

        tx = _make_tx(target_resource=None)
        await svc.verify_all(tx)

        assert tx.status == "complete"
        assert len(tx.connections) == 2
        assert mock_instance.exchange.call_count == 2

    @patch("okta_agent_proxy.auth.consent_verification.emit_audit_event")
    async def test_path_scoped_no_match_completes_immediately(self, mock_audit):
        """target_resource matches no STS resources → complete with empty connections."""
        r_hr = _make_resource("hr", connection_id="c1")
        r_github = _make_resource("github", connection_id="c2")
        router = _make_router([r_hr, r_github])
        cache = MagicMock()
        svc = ConsentVerificationService(router, cache)

        tx = _make_tx(target_resource="https://gateway.example.com/nonexistent")
        await svc.verify_all(tx)

        assert tx.status == "complete"
        assert tx.connections == []
