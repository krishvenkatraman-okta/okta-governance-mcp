"""
Tests for UserTokenStore CacheService (L2) integration.

Tests:
- Standalone mode (no CacheService) -- sync behavior unchanged
- Two instances sharing one MemoryCacheProvider (cross-pod simulation)
- Encryption: L2 bytes don't contain raw id_token
- aremove_by_user clears L1 by user_sub and issues L2 clear_prefix
- L2 failure falls back to L1 without raising
- capture_token_mapping from async context schedules L2 write
"""

import asyncio
import pytest
from unittest.mock import AsyncMock, MagicMock, patch

from okta_agent_proxy.auth.user_token_store import (
    UserTokenStore,
    capture_token_mapping,
    reset_user_token_store,
    _USER_TOKEN_PREFIX,
)
from okta_agent_proxy.cache.cache_service import CacheService
from okta_agent_proxy.cache.memory_provider import MemoryCacheProvider


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _make_store(cache_service=None, encryption_service=None):
    return UserTokenStore(
        encryption_service=encryption_service,
        default_ttl=3600,
        max_size=100,
        cache_service=cache_service,
    )


def _shared_cache_service():
    """Create a CacheService backed by a single MemoryCacheProvider (shared L2)."""
    provider = MemoryCacheProvider(max_size=1000, default_ttl=3600)
    return CacheService(l2_provider=provider)


# ---------------------------------------------------------------------------
# 1. Standalone mode (no CacheService) -- existing sync behavior
# ---------------------------------------------------------------------------

class TestStandaloneMode:
    def test_store_and_lookup_sync(self):
        """store() + lookup() work without CacheService."""
        s = _make_store()
        s.store("tok_a", "id_a", "ref_a", "user1", "agent1")
        result = s.lookup("tok_a")
        assert result is not None
        assert result["id_token"] == "id_a"
        assert result["user_sub"] == "user1"

    def test_lookup_miss_returns_none(self):
        s = _make_store()
        assert s.lookup("nonexistent") is None

    def test_update_preserves_fields(self):
        s = _make_store()
        s.store("tok_b", "id_b", "ref_b", "user2", "agent2")
        s.update("tok_b", id_token="id_b_v2")
        result = s.lookup("tok_b")
        assert result["id_token"] == "id_b_v2"
        assert result["refresh_token"] == "ref_b"

    def test_remove(self):
        s = _make_store()
        s.store("tok_c", "id_c", "ref_c", "user3", "agent3")
        s.remove("tok_c")
        assert s.lookup("tok_c") is None

    def test_remove_by_user(self):
        s = _make_store()
        s.store("tok_d1", "id_d1", "ref_d1", "userX", "agent1")
        s.store("tok_d2", "id_d2", "ref_d2", "userX", "agent2")
        s.store("tok_d3", "id_d3", "ref_d3", "userY", "agent1")
        count = s.remove_by_user("userX")
        assert count == 2
        assert s.lookup("tok_d1") is None
        assert s.lookup("tok_d3") is not None

    def test_get_stats_shows_no_cache_service(self):
        s = _make_store()
        stats = s.get_stats()
        assert stats["cache_service"] is False


# ---------------------------------------------------------------------------
# 2. Cross-pod simulation: two instances sharing one MemoryCacheProvider
# ---------------------------------------------------------------------------

class TestCrossPodSimulation:
    @pytest.mark.asyncio
    async def test_astore_on_a_alookup_on_b(self):
        """astore on instance A, alookup on instance B returns same payload."""
        svc = _shared_cache_service()
        store_a = _make_store(cache_service=svc)
        store_b = _make_store(cache_service=svc)

        await store_a.astore("tok_x", "id_x", "ref_x", "user_cross", "agent_x")

        # Clear store_b's L1 to prove it reads from L2
        store_b._cache.clear()

        result = await store_b.alookup("tok_x")
        assert result is not None
        assert result["id_token"] == "id_x"
        assert result["user_sub"] == "user_cross"

    @pytest.mark.asyncio
    async def test_aupdate_visible_cross_pod(self):
        svc = _shared_cache_service()
        store_a = _make_store(cache_service=svc)
        store_b = _make_store(cache_service=svc)

        await store_a.astore("tok_u", "id_u", "ref_u", "user_u", "agent_u")
        await store_a.aupdate("tok_u", id_token="id_u_v2")

        store_b._cache.clear()
        result = await store_b.alookup("tok_u")
        assert result is not None
        assert result["id_token"] == "id_u_v2"

    @pytest.mark.asyncio
    async def test_aremove_visible_cross_pod(self):
        svc = _shared_cache_service()
        store_a = _make_store(cache_service=svc)
        store_b = _make_store(cache_service=svc)

        await store_a.astore("tok_r", "id_r", "ref_r", "user_r", "agent_r")
        await store_a.aremove("tok_r")

        store_b._cache.clear()
        result = await store_b.alookup("tok_r")
        assert result is None


# ---------------------------------------------------------------------------
# 3. Encryption: L2 stored bytes don't contain raw id_token
# ---------------------------------------------------------------------------

class TestEncryption:
    @pytest.mark.asyncio
    async def test_encrypted_l2_does_not_contain_raw_token(self):
        from okta_agent_proxy.crypto.encryption import EncryptionService
        import os
        key = os.urandom(32)
        enc = EncryptionService(key)

        provider = MemoryCacheProvider(max_size=100, default_ttl=3600)
        svc = CacheService(l2_provider=provider)
        store = _make_store(cache_service=svc, encryption_service=enc)

        await store.astore("tok_enc", "secret_id_token_value", "ref", "user_e", "agent_e")

        # Read raw bytes from L2 provider
        token_hash = UserTokenStore._hash_token("tok_enc")
        service_key = f"{_USER_TOKEN_PREFIX}{token_hash}"
        raw_l2 = await provider.get(service_key)
        assert raw_l2 is not None
        assert "secret_id_token_value" not in raw_l2

        # But alookup decrypts correctly
        result = await store.alookup("tok_enc")
        assert result["id_token"] == "secret_id_token_value"


# ---------------------------------------------------------------------------
# 4. aremove_by_user clears L1 by user_sub AND issues L2 clear_prefix
# ---------------------------------------------------------------------------

class TestRemoveByUser:
    @pytest.mark.asyncio
    async def test_aremove_by_user_clears_l1_and_l2(self):
        svc = _shared_cache_service()
        store = _make_store(cache_service=svc)

        await store.astore("tok_u1", "id_u1", "ref_u1", "target_user", "agent1")
        await store.astore("tok_u2", "id_u2", "ref_u2", "target_user", "agent2")
        await store.astore("tok_u3", "id_u3", "ref_u3", "other_user", "agent1")

        count = await store.aremove_by_user("target_user")
        assert count == 2

        # L1 cleared for target_user
        assert store.lookup("tok_u1") is None
        assert store.lookup("tok_u2") is None

        # other_user's L1 entry survives
        assert store.lookup("tok_u3") is not None


# ---------------------------------------------------------------------------
# 5. L2 failure falls back to L1 without raising
# ---------------------------------------------------------------------------

class TestL2Fallback:
    @pytest.mark.asyncio
    async def test_astore_survives_l2_failure(self):
        svc = MagicMock()
        svc.set = AsyncMock(side_effect=RuntimeError("Redis down"))
        svc.get = AsyncMock(side_effect=RuntimeError("Redis down"))
        store = _make_store(cache_service=svc)

        # Should NOT raise
        await store.astore("tok_fail", "id_f", "ref_f", "user_f", "agent_f")

        # L1 still works
        result = store.lookup("tok_fail")
        assert result is not None
        assert result["id_token"] == "id_f"

    @pytest.mark.asyncio
    async def test_alookup_falls_back_to_l1_on_l2_failure(self):
        svc = MagicMock()
        svc.get = AsyncMock(side_effect=RuntimeError("Redis down"))
        store = _make_store(cache_service=svc)

        # Pre-populate L1 via sync store
        store.store("tok_fb", "id_fb", "ref_fb", "user_fb", "agent_fb")

        # alookup should find it in L1 despite L2 error
        result = await store.alookup("tok_fb")
        assert result is not None
        assert result["id_token"] == "id_fb"

    @pytest.mark.asyncio
    async def test_aremove_survives_l2_failure(self):
        svc = MagicMock()
        svc.delete = AsyncMock(side_effect=RuntimeError("Redis down"))
        store = _make_store(cache_service=svc)

        store.store("tok_rm", "id_rm", "ref_rm", "user_rm", "agent_rm")
        # Should NOT raise
        await store.aremove("tok_rm")
        assert store.lookup("tok_rm") is None


# ---------------------------------------------------------------------------
# 6. capture_token_mapping from async context schedules L2 write
# ---------------------------------------------------------------------------

class TestCaptureTokenMapping:
    @pytest.mark.asyncio
    async def test_capture_from_async_context_uses_astore(self):
        reset_user_token_store()
        svc = _shared_cache_service()
        store = _make_store(cache_service=svc)

        # Patch the module-level singleton with our wired store
        with patch("okta_agent_proxy.auth.user_token_store._store", store), \
             patch("okta_agent_proxy.auth.user_token_store.get_user_token_store", return_value=store):

            # Build a minimal valid JWT for jose to parse (unverified)
            from jose import jwt as jose_jwt
            fake_id_token = jose_jwt.encode(
                {"sub": "user_capture", "iss": "test"},
                "secret",
                algorithm="HS256",
            )

            capture_token_mapping(
                access_token="tok_capture",
                id_token=fake_id_token,
                refresh_token="ref_capture",
                client_id="agent_capture",
                expires_in=3600,
            )

            # Give the scheduled task a chance to run
            await asyncio.sleep(0.1)

            # Verify L2 has the entry (clear L1 to prove)
            store._cache.clear()
            result = await store.alookup("tok_capture")
            assert result is not None
            assert result["user_sub"] == "user_capture"
            assert result["agent_id"] == "agent_capture"

        reset_user_token_store()

    def test_capture_from_sync_context_uses_store(self):
        """When no event loop is running, falls back to sync store()."""
        reset_user_token_store()
        store = _make_store()

        with patch("okta_agent_proxy.auth.user_token_store._store", store), \
             patch("okta_agent_proxy.auth.user_token_store.get_user_token_store", return_value=store):

            from jose import jwt as jose_jwt
            fake_id_token = jose_jwt.encode(
                {"sub": "user_sync", "iss": "test"},
                "secret",
                algorithm="HS256",
            )

            # Run outside async context
            capture_token_mapping(
                access_token="tok_sync",
                id_token=fake_id_token,
                refresh_token="ref_sync",
                client_id="agent_sync",
                expires_in=3600,
            )

            result = store.lookup("tok_sync")
            assert result is not None
            assert result["user_sub"] == "user_sync"

        reset_user_token_store()


# ---------------------------------------------------------------------------
# 7. get_stats reports cache_service presence
# ---------------------------------------------------------------------------

class TestGetStats:
    def test_stats_with_cache_service(self):
        svc = _shared_cache_service()
        store = _make_store(cache_service=svc)
        stats = store.get_stats()
        assert stats["cache_service"] is True

    def test_stats_without_cache_service(self):
        store = _make_store()
        stats = store.get_stats()
        assert stats["cache_service"] is False
