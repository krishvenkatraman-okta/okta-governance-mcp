"""
Tests for CachedResourceStore and ConfigCache.

Verifies:
- Cache hit avoids DB call
- Cache miss falls through to wrapped store
- Write operations invalidate cache
- Encrypted agent data round-trips correctly
"""

import pytest
import json
from unittest.mock import MagicMock

from okta_agent_proxy.storage.cached_store import CachedResourceStore
from okta_agent_proxy.cache.config_cache import ConfigCache


@pytest.fixture
def mock_store():
    """Mock ResourceConfigStore that simulates a database."""
    store = MagicMock()

    agent_data = {
        "agent_id": "test-agent",
        "agent_name": "test-agent",
        "client_id": "0oa_test",
        "client_secret": "secret-value",
        "private_key": json.dumps({"kty": "RSA", "n": "test", "e": "AQAB", "d": "priv"}),
        "resource_access": ["hr-system"],
        "enabled": True,
    }
    resource_data = {
        "name": "hr-system",
        "url": "http://localhost:8001/mcp",
        "paths": ["/hr"],
        "auth_method": "pre-shared-key",
        "auth_config": {"key": "test"},
        "enabled": True,
    }

    store.get_agent.return_value = agent_data
    store.get_agent_by_name.return_value = agent_data
    store.get_all_agents.return_value = [agent_data]
    store.get_resource.return_value = resource_data
    store.get_all_resources.return_value = [resource_data]
    store.create_agent.return_value = True
    store.update_agent.return_value = True
    store.delete_agent.return_value = True
    store.enable_agent.return_value = True
    store.disable_agent.return_value = True
    store.create_resource.return_value = True
    store.update_resource.return_value = True
    store.delete_resource.return_value = True
    store.enable_resource.return_value = True
    store.disable_resource.return_value = True
    store.get_audit_log.return_value = []
    store.get_agent_audit_log.return_value = []
    store.list_agent_resources.return_value = ["hr-system"]

    return store


@pytest.fixture
def cached_store(mock_store, cache_service):
    """CachedResourceStore wrapping a mock store (no encryption)."""
    return CachedResourceStore(mock_store, cache_service=cache_service, ttl_seconds=300)


@pytest.fixture
def cached_store_encrypted(mock_store, cache_service, encryption_service):
    """CachedResourceStore wrapping a mock store (with encryption)."""
    return CachedResourceStore(
        mock_store, cache_service=cache_service, ttl_seconds=300,
        encryption_service=encryption_service,
    )


class TestAgentCacheHit:
    def test_get_agent_caches_result(self, cached_store, mock_store):
        """First call hits DB, second call hits cache."""
        result1 = cached_store.get_agent("test-agent")
        assert result1 is not None
        assert result1["agent_id"] == "test-agent"
        assert mock_store.get_agent.call_count == 1

        result2 = cached_store.get_agent("test-agent")
        assert result2 == result1
        # Still only 1 DB call — second was served from cache
        assert mock_store.get_agent.call_count == 1

    def test_get_agent_by_name_caches_result(self, cached_store, mock_store):
        result1 = cached_store.get_agent_by_name("test-agent")
        assert result1 is not None
        assert mock_store.get_agent_by_name.call_count == 1

        result2 = cached_store.get_agent_by_name("test-agent")
        assert result2 == result1
        assert mock_store.get_agent_by_name.call_count == 1

    def test_get_all_agents_caches_result(self, cached_store, mock_store):
        # get_all_agents with enabled_only=False caches the result
        result1 = cached_store.get_all_agents(enabled_only=False)
        assert len(result1) == 1
        assert mock_store.get_all_agents.call_count == 1

        result2 = cached_store.get_all_agents(enabled_only=False)
        assert result2 == result1
        assert mock_store.get_all_agents.call_count == 1


class TestResourceCacheHit:
    def test_get_resource_caches_result(self, cached_store, mock_store):
        result1 = cached_store.get_resource("hr-system")
        assert result1["name"] == "hr-system"
        assert mock_store.get_resource.call_count == 1

        result2 = cached_store.get_resource("hr-system")
        assert result2 == result1
        assert mock_store.get_resource.call_count == 1

    def test_get_all_resources_caches_result(self, cached_store, mock_store):
        result1 = cached_store.get_all_resources()
        assert len(result1) == 1
        assert mock_store.get_all_resources.call_count == 1

        result2 = cached_store.get_all_resources()
        assert result2 == result1
        assert mock_store.get_all_resources.call_count == 1


class TestCacheMiss:
    def test_agent_not_found_not_cached(self, cached_store, mock_store):
        mock_store.get_agent.return_value = None
        result = cached_store.get_agent("nonexistent")
        assert result is None
        assert mock_store.get_agent.call_count == 1

        # Second call should still hit DB (None is not cached)
        cached_store.get_agent("nonexistent")
        assert mock_store.get_agent.call_count == 2

    def test_resource_not_found_not_cached(self, cached_store, mock_store):
        mock_store.get_resource.return_value = None
        result = cached_store.get_resource("nonexistent")
        assert result is None
        assert mock_store.get_resource.call_count == 1

        cached_store.get_resource("nonexistent")
        assert mock_store.get_resource.call_count == 2


class TestWriteInvalidation:
    def test_create_agent_invalidates_cache(self, cached_store, mock_store):
        # Populate cache
        cached_store.get_agent("test-agent")
        assert mock_store.get_agent.call_count == 1

        # Create triggers invalidation
        cached_store.create_agent("test-agent", {"agent_name": "test-agent"}, user="admin")

        # Next read should hit DB again
        cached_store.get_agent("test-agent")
        assert mock_store.get_agent.call_count == 2

    def test_update_agent_invalidates_cache(self, cached_store, mock_store):
        cached_store.get_agent("test-agent")
        assert mock_store.get_agent.call_count == 1

        cached_store.update_agent("test-agent", {"agent_name": "test-agent"}, user="admin")

        cached_store.get_agent("test-agent")
        assert mock_store.get_agent.call_count == 3  # 1 original + 1 for name lookup in update + 1 after invalidation

    def test_delete_agent_invalidates_cache(self, cached_store, mock_store):
        cached_store.get_agent("test-agent")
        assert mock_store.get_agent.call_count == 1

        cached_store.delete_agent("test-agent", user="admin")

        cached_store.get_agent("test-agent")
        assert mock_store.get_agent.call_count == 3  # 1 original + 1 for name lookup in delete + 1 after invalidation

    def test_update_resource_invalidates_cache(self, cached_store, mock_store):
        cached_store.get_resource("hr-system")
        assert mock_store.get_resource.call_count == 1

        cached_store.update_resource("hr-system", {}, user="admin")

        cached_store.get_resource("hr-system")
        assert mock_store.get_resource.call_count == 2

    def test_delete_resource_invalidates_cache(self, cached_store, mock_store):
        cached_store.get_resource("hr-system")
        assert mock_store.get_resource.call_count == 1

        cached_store.delete_resource("hr-system", user="admin")

        cached_store.get_resource("hr-system")
        assert mock_store.get_resource.call_count == 2


class TestEncryptedAgentRoundTrip:
    def test_agent_data_round_trips_with_encryption(self, cached_store_encrypted, mock_store):
        """Agent data with secrets survives serialize_encrypted -> deserialize_encrypted."""
        result1 = cached_store_encrypted.get_agent("test-agent")
        assert result1 is not None
        assert result1["client_secret"] == "secret-value"
        assert "priv" in result1["private_key"]  # private key contains "d": "priv"
        assert mock_store.get_agent.call_count == 1

        # Second call from cache — should decrypt correctly
        result2 = cached_store_encrypted.get_agent("test-agent")
        assert result2["client_secret"] == "secret-value"
        assert result2["private_key"] == result1["private_key"]
        assert mock_store.get_agent.call_count == 1

    def test_agent_by_name_round_trips_with_encryption(self, cached_store_encrypted, mock_store):
        result1 = cached_store_encrypted.get_agent_by_name("test-agent")
        assert result1["client_secret"] == "secret-value"
        assert mock_store.get_agent_by_name.call_count == 1

        result2 = cached_store_encrypted.get_agent_by_name("test-agent")
        assert result2["client_secret"] == "secret-value"
        assert mock_store.get_agent_by_name.call_count == 1

    def test_all_agents_round_trips_with_encryption(self, cached_store_encrypted, mock_store):
        result1 = cached_store_encrypted.get_all_agents(enabled_only=False)
        assert len(result1) == 1
        assert result1[0]["client_secret"] == "secret-value"
        assert mock_store.get_all_agents.call_count == 1

        result2 = cached_store_encrypted.get_all_agents(enabled_only=False)
        assert result2[0]["client_secret"] == "secret-value"
        assert mock_store.get_all_agents.call_count == 1


class TestPassThrough:
    def test_audit_log_passes_through(self, cached_store, mock_store):
        cached_store.get_audit_log(resource_name=None, limit=10)
        mock_store.get_audit_log.assert_called_once_with(None, 10)

    def test_agent_audit_log_passes_through(self, cached_store, mock_store):
        cached_store.get_agent_audit_log("test-agent", limit=5)
        mock_store.get_agent_audit_log.assert_called_once_with("test-agent", 5)

    def test_list_agent_resources_passes_through(self, cached_store, mock_store):
        result = cached_store.list_agent_resources("test-agent")
        assert result == ["hr-system"]
        mock_store.list_agent_resources.assert_called_once_with("test-agent")


class TestEnabledOnlyFiltering:
    def test_get_agent_respects_enabled_only(self, cached_store, mock_store):
        """Cached disabled agent should not be returned when enabled_only=True."""
        # Cache an agent
        cached_store.get_agent("test-agent", enabled_only=False)

        # Modify mock to return disabled agent (but cache already has it)
        mock_store.get_agent.return_value = {
            "agent_id": "test-agent", "enabled": False
        }

        # Should return from cache but filter by enabled
        # The cached data has enabled=True, so it should be returned
        result = cached_store.get_agent("test-agent", enabled_only=True)
        assert result is not None
