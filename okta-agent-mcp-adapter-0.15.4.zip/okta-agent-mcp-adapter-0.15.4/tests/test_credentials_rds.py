"""Tests for the AWS RDS IAM database credential provider (P10).

boto3 is mocked — these tests never touch AWS. End-to-end validation
against a real RDS instance is covered by the ECS smoke test in P13.
"""

from __future__ import annotations

from unittest.mock import MagicMock

import pytest

from okta_agent_proxy.storage.credentials import (
    DatabaseCredentialProvider,
    get_credential_provider,
)
from okta_agent_proxy.storage.credentials_rds import (
    _RDS_IAM_TOKEN_TTL_SECONDS,
    RdsIamCredentialProvider,
)
from okta_agent_proxy.storage.pool import DatabasePool


@pytest.fixture()
def rds_env(monkeypatch):
    """Populate the env vars the RDS IAM provider requires."""
    monkeypatch.setenv("DB_HOST", "my-db.abcdefg.us-east-1.rds.amazonaws.com")
    monkeypatch.setenv("DB_PORT", "5432")
    monkeypatch.setenv("DB_NAME", "gateway_db")
    monkeypatch.setenv("DB_USERNAME", "okta_adapter_app")
    monkeypatch.setenv("AWS_REGION", "us-east-1")
    monkeypatch.delenv("DB_SSLROOTCERT", raising=False)


@pytest.fixture()
def fake_rds_client():
    """A boto3-like RDS client that returns a synthetic token on each call."""
    client = MagicMock()
    # Each call returns a distinct token so we can assert freshness.
    client.generate_db_auth_token.side_effect = [
        f"token-{i}" for i in range(100)
    ]
    return client


def test_rds_provider_calls_generate_db_auth_token(rds_env, fake_rds_client):
    provider = RdsIamCredentialProvider(rds_client=fake_rds_client)
    provider.get_credential()

    fake_rds_client.generate_db_auth_token.assert_called_once_with(
        DBHostname="my-db.abcdefg.us-east-1.rds.amazonaws.com",
        Port=5432,
        DBUsername="okta_adapter_app",
        Region="us-east-1",
    )


def test_rds_provider_returns_credential_with_15min_ttl(rds_env, fake_rds_client):
    provider = RdsIamCredentialProvider(rds_client=fake_rds_client)
    cred = provider.get_credential()

    assert cred.ttl_seconds == 900
    assert cred.ttl_seconds == _RDS_IAM_TOKEN_TTL_SECONDS
    assert cred.password == "token-0"
    assert cred.username == "okta_adapter_app"
    assert cred.host == "my-db.abcdefg.us-east-1.rds.amazonaws.com"
    assert cred.port == 5432
    assert cred.dbname == "gateway_db"


def test_rds_provider_supports_rotation_true(rds_env, fake_rds_client):
    provider = RdsIamCredentialProvider(rds_client=fake_rds_client)
    assert provider.supports_rotation() is True
    assert provider.name == "rds_iam"
    # Verify the base-class contract too.
    assert isinstance(provider, DatabaseCredentialProvider)


def test_rds_provider_uses_verify_full_sslmode(rds_env, fake_rds_client):
    provider = RdsIamCredentialProvider(rds_client=fake_rds_client)
    cred = provider.get_credential()

    assert cred.sslmode == "verify-full"
    # Default CA path when DB_SSLROOTCERT not set.
    assert cred.sslrootcert == "/opt/rds-ca/global-bundle.pem"


def test_rds_provider_honors_custom_sslrootcert(rds_env, fake_rds_client, monkeypatch):
    monkeypatch.setenv("DB_SSLROOTCERT", "/etc/ssl/my-ca.pem")
    provider = RdsIamCredentialProvider(rds_client=fake_rds_client)
    cred = provider.get_credential()

    assert cred.sslrootcert == "/etc/ssl/my-ca.pem"


def test_get_credential_returns_fresh_token_each_call(rds_env, fake_rds_client):
    provider = RdsIamCredentialProvider(rds_client=fake_rds_client)

    cred1 = provider.get_credential()
    cred2 = provider.get_credential()

    assert cred1.password != cred2.password
    assert (cred1.password, cred2.password) == ("token-0", "token-1")
    assert fake_rds_client.generate_db_auth_token.call_count == 2


def test_pool_max_lifetime_respects_credential_ttl(
    rds_env, fake_rds_client, monkeypatch
):
    # Swap out psycopg_pool so we don't open real connections.
    captured: dict = {}

    class _FakePool:
        def __init__(self, *args, **kwargs):
            captured.update(kwargs)
            # Capture positional conninfo too for completeness.
            if args:
                captured["_conninfo_positional"] = args[0]

        def close(self):
            pass

    monkeypatch.setattr(
        "okta_agent_proxy.storage.pool.ConnectionPool", _FakePool
    )

    provider = RdsIamCredentialProvider(rds_client=fake_rds_client)
    pool = DatabasePool(provider, min_size=1, max_size=2, timeout=5.0)

    # 80% of 900s = 720s
    assert captured["max_lifetime"] == 720
    # Rotating providers must pass a callable so psycopg_pool re-resolves
    # conninfo on each new connection.
    assert callable(captured["conninfo"])
    # Calling the callable invokes the RDS token API afresh.
    first = captured["conninfo"]()
    second = captured["conninfo"]()
    assert first != second  # tokens differ ⇒ conninfo strings differ
    pool.close()


def test_missing_env_vars_raises_clear_error(monkeypatch):
    # Scrub every required var and assert the error names them.
    for var in ("DB_HOST", "DB_PORT", "DB_NAME", "DB_USERNAME", "AWS_REGION",
                "AWS_DEFAULT_REGION", "DB_SSLROOTCERT"):
        monkeypatch.delenv(var, raising=False)

    with pytest.raises(RuntimeError) as exc:
        RdsIamCredentialProvider(rds_client=MagicMock())

    msg = str(exc.value)
    assert "DB_HOST" in msg
    assert "DB_NAME" in msg
    assert "DB_USERNAME" in msg
    assert "AWS_REGION" in msg


def test_get_credential_provider_rds_iam_returns_rds_provider(
    rds_env, monkeypatch
):
    # P10 makes rds_iam a real provider, not a stub.
    monkeypatch.setenv("DB_CREDENTIAL_PROVIDER", "rds_iam")

    # Prevent real boto3 network activity — patch at import site.
    fake_boto = MagicMock()
    fake_boto.client.return_value = MagicMock()
    monkeypatch.setitem(__import__("sys").modules, "boto3", fake_boto)

    provider = get_credential_provider()
    assert isinstance(provider, RdsIamCredentialProvider)
    assert provider.supports_rotation() is True
    fake_boto.client.assert_called_once_with("rds", region_name="us-east-1")


def test_aws_default_region_fallback(rds_env, fake_rds_client, monkeypatch):
    monkeypatch.delenv("AWS_REGION", raising=False)
    monkeypatch.setenv("AWS_DEFAULT_REGION", "eu-west-2")

    provider = RdsIamCredentialProvider(rds_client=fake_rds_client)
    cred = provider.get_credential()

    # generate_db_auth_token is called with the fallback region.
    fake_rds_client.generate_db_auth_token.assert_called_once()
    kwargs = fake_rds_client.generate_db_auth_token.call_args.kwargs
    assert kwargs["Region"] == "eu-west-2"
    # Username/host preserved.
    assert cred.username == "okta_adapter_app"
