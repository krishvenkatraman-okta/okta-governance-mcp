"""
Tests for CIMD Trust Policy.

Tests:
- Trusted domain → allowed, trust_level=TRUSTED
- Blocked domain → rejected
- Unknown domain → allowed, trust_level=UNKNOWN
- CIMD disabled → rejected
- HTTP scheme with REQUIRE_HTTPS=true → rejected
- HTTP scheme with localhost → allowed (dev exception)
- Redirect URI matching patterns → allowed
- Redirect URI not matching → rejected
"""

import pytest
from datetime import datetime, timezone

from okta_agent_proxy.auth.cimd_fetcher import CIMDMetadata
from okta_agent_proxy.auth.cimd_policy import CIMDTrustPolicy, CIMDTrustResult, TrustLevel


def _metadata(
    client_id="https://example.com/oauth.json",
    redirect_uris=None,
    domain=None,
):
    """Create a CIMDMetadata for testing."""
    from urllib.parse import urlparse

    parsed = urlparse(client_id)
    return CIMDMetadata(
        client_id=client_id,
        client_name="Test App",
        redirect_uris=redirect_uris or ["http://localhost:8080/callback"],
        grant_types=["authorization_code"],
        response_types=["code"],
        token_endpoint_auth_method="none",
        jwks_uri=None,
        logo_uri=None,
        client_uri=None,
        scope=None,
        domain=domain or parsed.hostname or "",
        fetched_at=datetime.now(timezone.utc),
        raw_json={},
    )


class TestCIMDTrustPolicy:
    async def test_trusted_domain(self):
        policy = CIMDTrustPolicy(
            trusted_domains=["example.com"],
            blocked_domains=[],
            allowed_redirect_patterns=["http://localhost:*/callback"],
        )
        result = await policy.evaluate(_metadata())
        assert result.allowed is True
        assert result.trust_level == TrustLevel.TRUSTED
        assert result.reason == "domain is trusted"

    async def test_blocked_domain(self):
        policy = CIMDTrustPolicy(
            trusted_domains=[],
            blocked_domains=["evil.com"],
            allowed_redirect_patterns=["http://localhost:*/callback"],
        )
        result = await policy.evaluate(_metadata(
            client_id="https://evil.com/oauth.json",
            domain="evil.com",
        ))
        assert result.allowed is False
        assert result.trust_level == TrustLevel.BLOCKED
        assert result.reason == "domain blocked"

    async def test_unknown_domain(self):
        policy = CIMDTrustPolicy(
            trusted_domains=["other.com"],
            blocked_domains=["evil.com"],
            allowed_redirect_patterns=["http://localhost:*/callback"],
        )
        result = await policy.evaluate(_metadata())
        assert result.allowed is True
        assert result.trust_level == TrustLevel.UNKNOWN
        assert "not in trusted or blocked" in result.reason

    async def test_cimd_disabled(self):
        policy = CIMDTrustPolicy(enabled=False)
        result = await policy.evaluate(_metadata())
        assert result.allowed is False
        assert result.reason == "CIMD disabled"

    async def test_http_scheme_rejected_with_require_https(self):
        policy = CIMDTrustPolicy(
            require_https=True,
            allowed_redirect_patterns=["http://localhost:*/callback"],
        )
        result = await policy.evaluate(_metadata(
            client_id="http://example.com/oauth.json",
            domain="example.com",
        ))
        assert result.allowed is False
        assert "HTTPS" in result.reason or "HTTP" in result.reason

    async def test_http_localhost_allowed_with_require_https(self):
        policy = CIMDTrustPolicy(
            require_https=True,
            allowed_redirect_patterns=["http://localhost:*/callback"],
        )
        result = await policy.evaluate(_metadata(
            client_id="http://localhost:3000/oauth.json",
            domain="localhost",
        ))
        assert result.allowed is True

    async def test_redirect_uri_matching(self):
        policy = CIMDTrustPolicy(
            allowed_redirect_patterns=["https://app.example.com/callback"],
        )
        result = await policy.evaluate(_metadata(
            redirect_uris=["https://app.example.com/callback"],
        ))
        assert result.allowed is True
        assert result.redirect_uris_valid is True

    async def test_redirect_uri_not_matching(self):
        policy = CIMDTrustPolicy(
            allowed_redirect_patterns=["https://allowed.com/callback"],
        )
        result = await policy.evaluate(_metadata(
            redirect_uris=["https://evil.com/steal"],
        ))
        assert result.allowed is False
        assert result.redirect_uris_valid is False
        assert "redirect_uris" in result.reason

    async def test_redirect_uri_glob_pattern(self):
        policy = CIMDTrustPolicy(
            allowed_redirect_patterns=["http://localhost:*/callback", "http://127.0.0.1:*/callback"],
        )
        result = await policy.evaluate(_metadata(
            redirect_uris=["http://localhost:9999/callback"],
        ))
        assert result.allowed is True

    async def test_blocked_takes_precedence_over_trusted(self):
        """If domain is in both lists, blocked wins."""
        policy = CIMDTrustPolicy(
            trusted_domains=["example.com"],
            blocked_domains=["example.com"],
            allowed_redirect_patterns=["http://localhost:*/callback"],
        )
        result = await policy.evaluate(_metadata())
        assert result.allowed is False
        assert result.trust_level == TrustLevel.BLOCKED

    async def test_domain_extracted_from_metadata(self):
        policy = CIMDTrustPolicy(
            trusted_domains=["myapp.io"],
            allowed_redirect_patterns=["http://localhost:*/callback"],
        )
        result = await policy.evaluate(_metadata(
            client_id="https://myapp.io/.well-known/oauth.json",
            domain="myapp.io",
        ))
        assert result.domain == "myapp.io"
        assert result.trust_level == TrustLevel.TRUSTED


class TestCIMDResourceAccess:
    async def test_trusted_domain_gets_configured_resources(self, monkeypatch):
        monkeypatch.setenv("CIMD_TRUSTED_DOMAINS", "claude.ai")
        monkeypatch.setenv("CIMD_TRUSTED_BACKEND_ACCESS", "hr-system,finance-system")
        policy = CIMDTrustPolicy(
            allowed_redirect_patterns=["http://localhost:*/callback"],
        )
        result = await policy.evaluate(_metadata(
            client_id="https://claude.ai/oauth.json",
            domain="claude.ai",
        ))
        assert result.allowed is True
        assert result.trust_level == TrustLevel.TRUSTED
        assert result.resource_access == ["hr-system", "finance-system"]

    async def test_unknown_domain_gets_empty_resources_by_default(self, monkeypatch):
        monkeypatch.delenv("CIMD_UNKNOWN_BACKEND_ACCESS", raising=False)
        policy = CIMDTrustPolicy(
            trusted_domains=["other.com"],
            blocked_domains=[],
            allowed_redirect_patterns=["http://localhost:*/callback"],
        )
        result = await policy.evaluate(_metadata(
            client_id="https://random-app.com/oauth.json",
            domain="random-app.com",
        ))
        assert result.allowed is True
        assert result.trust_level == TrustLevel.UNKNOWN
        assert result.resource_access == []

    async def test_unknown_domain_gets_configured_resources(self, monkeypatch):
        monkeypatch.setenv("CIMD_UNKNOWN_BACKEND_ACCESS", "hr-system")
        policy = CIMDTrustPolicy(
            trusted_domains=["other.com"],
            blocked_domains=[],
            allowed_redirect_patterns=["http://localhost:*/callback"],
        )
        result = await policy.evaluate(_metadata(
            client_id="https://random-app.com/oauth.json",
            domain="random-app.com",
        ))
        assert result.allowed is True
        assert result.resource_access == ["hr-system"]

    async def test_blocked_domain_gets_empty_resources(self):
        policy = CIMDTrustPolicy(
            trusted_domains=[],
            blocked_domains=["evil.com"],
            allowed_redirect_patterns=["http://localhost:*/callback"],
        )
        result = await policy.evaluate(_metadata(
            client_id="https://evil.com/oauth.json",
            domain="evil.com",
        ))
        assert result.allowed is False
        assert result.resource_access == []

    async def test_empty_trusted_resource_access(self, monkeypatch):
        monkeypatch.delenv("CIMD_TRUSTED_BACKEND_ACCESS", raising=False)
        monkeypatch.setenv("CIMD_TRUSTED_DOMAINS", "claude.ai")
        policy = CIMDTrustPolicy(
            allowed_redirect_patterns=["http://localhost:*/callback"],
        )
        result = await policy.evaluate(_metadata(
            client_id="https://claude.ai/oauth.json",
            domain="claude.ai",
        ))
        assert result.allowed is True
        assert result.trust_level == TrustLevel.TRUSTED
        assert result.resource_access == []

    async def test_auto_provision_agent_property(self, monkeypatch):
        monkeypatch.setenv("CIMD_AUTO_PROVISION_AGENT", "true")
        policy = CIMDTrustPolicy()
        assert policy.auto_provision_agent is True

        monkeypatch.delenv("CIMD_AUTO_PROVISION_AGENT", raising=False)
        policy2 = CIMDTrustPolicy()
        assert policy2.auto_provision_agent is False
