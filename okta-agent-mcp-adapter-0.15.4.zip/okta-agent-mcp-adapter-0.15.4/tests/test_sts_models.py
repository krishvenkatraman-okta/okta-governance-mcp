"""
Tests for STS_ACCESS_TOKEN connection type support.

Covers:
- OktaConnectionType enum value
- _CONNECTION_TYPE_TO_AUTH_METHOD mapping
- extract_resource_id with STS_ACCESS_TOKEN connection
- extract_connection_metadata with STS_ACCESS_TOKEN connection
- parse_connection_type for STS_ACCESS_TOKEN
- _extract_from_resource_indicator with client-auth-settings ORN
"""

import pytest

from okta_agent_proxy.resources.models import (
    OktaConnectionType,
    _CONNECTION_TYPE_TO_AUTH_METHOD,
)
from okta_agent_proxy.resources.utils import (
    _extract_from_resource_indicator,
    extract_resource_id,
    extract_connection_metadata,
    parse_connection_type,
    extract_resource_id_from_connection,
)


# Real STS_ACCESS_TOKEN connection from the Okta API
STS_ACCESS_TOKEN_CONN = {
    "id": "mcnwecqhmwbcHp7ig1d7",
    "orn": "orn:oktapreview:idp:00oudv75opUSqDo3B1d7:connections:mcnwecqhmwbcHp7ig1d7",
    "resource": {
        "appInstanceId": "0oaweclvlpWSkuYXX1d7",
        "appInstanceName": "Github Enterprise Cloud - Organization",
        "orn": "orn:oktapreview:idp:00oudv75opUSqDo3B1d7:client-auth-settings:rscwecmwxmK9skZBD1d7",
        "resourceType": "APP_INSTANCE",
    },
    "resourceIndicator": "orn:oktapreview:idp:00oudv75opUSqDo3B1d7:client-auth-settings:rscwecmwxmK9skZBD1d7",
    "status": "ACTIVE",
    "connectionType": "STS_ACCESS_TOKEN",
}


class TestOktaConnectionTypeEnum:

    def test_sts_access_token_enum_value(self):
        assert OktaConnectionType.STS_ACCESS_TOKEN == "STS_ACCESS_TOKEN"
        assert OktaConnectionType.STS_ACCESS_TOKEN.value == "STS_ACCESS_TOKEN"

    def test_sts_access_token_from_string(self):
        assert OktaConnectionType("STS_ACCESS_TOKEN") == OktaConnectionType.STS_ACCESS_TOKEN


class TestAuthMethodMapping:

    def test_sts_access_token_maps_to_okta_sts(self):
        assert _CONNECTION_TYPE_TO_AUTH_METHOD[OktaConnectionType.STS_ACCESS_TOKEN] == "okta-sts"

    def test_existing_mappings_unchanged(self):
        assert _CONNECTION_TYPE_TO_AUTH_METHOD[OktaConnectionType.IDENTITY_ASSERTION_CUSTOM_AS] == "okta-cross-app"
        assert _CONNECTION_TYPE_TO_AUTH_METHOD[OktaConnectionType.STS_VAULT_SECRET] == "vault-secret"
        assert _CONNECTION_TYPE_TO_AUTH_METHOD[OktaConnectionType.STS_SERVICE_ACCOUNT] == "sts-service-account"


class TestExtractFromResourceIndicator:

    def test_client_auth_settings_orn(self):
        ri = "orn:oktapreview:idp:00oudv75opUSqDo3B1d7:client-auth-settings:rscwecmwxmK9skZBD1d7"
        result = _extract_from_resource_indicator(ri, OktaConnectionType.STS_ACCESS_TOKEN)
        assert result == "rscwecmwxmK9skZBD1d7"

    def test_no_client_auth_settings_returns_none(self):
        ri = "orn:oktapreview:idp:00o:some_other_type:abc123"
        result = _extract_from_resource_indicator(ri, OktaConnectionType.STS_ACCESS_TOKEN)
        assert result is None


class TestExtractResourceId:

    def test_from_resource_indicator(self):
        result = extract_resource_id(STS_ACCESS_TOKEN_CONN, OktaConnectionType.STS_ACCESS_TOKEN)
        assert result == "rscwecmwxmK9skZBD1d7"

    def test_fallback_to_resource_obj_orn(self):
        conn = {
            "id": "mcn1",
            "connectionType": "STS_ACCESS_TOKEN",
            "resource": {
                "appInstanceId": "0oa123",
                "orn": "orn:okta:idp:00o:client-auth-settings:rsc456",
            },
        }
        result = extract_resource_id(conn, OktaConnectionType.STS_ACCESS_TOKEN)
        assert result == "rsc456"

    def test_fallback_to_app_instance_id(self):
        conn = {
            "id": "mcn1",
            "connectionType": "STS_ACCESS_TOKEN",
            "resource": {
                "appInstanceId": "0oaFallback",
                "orn": "some-non-matching-orn",
            },
        }
        result = extract_resource_id(conn, OktaConnectionType.STS_ACCESS_TOKEN)
        assert result == "0oaFallback"

    def test_fallback_to_connection_id(self):
        conn = {
            "id": "mcn-fallback",
            "connectionType": "STS_ACCESS_TOKEN",
        }
        result = extract_resource_id(conn, OktaConnectionType.STS_ACCESS_TOKEN)
        assert result == "mcn-fallback"


class TestExtractConnectionMetadata:

    def test_full_metadata(self):
        metadata = extract_connection_metadata(STS_ACCESS_TOKEN_CONN, OktaConnectionType.STS_ACCESS_TOKEN)
        assert metadata["app_instance_id"] == "0oaweclvlpWSkuYXX1d7"
        assert metadata["app_instance_name"] == "Github Enterprise Cloud - Organization"
        assert metadata["resource_orn"] == "orn:oktapreview:idp:00oudv75opUSqDo3B1d7:client-auth-settings:rscwecmwxmK9skZBD1d7"
        assert metadata["resource_type"] == "APP_INSTANCE"
        assert metadata["resource_indicator"] == "orn:oktapreview:idp:00oudv75opUSqDo3B1d7:client-auth-settings:rscwecmwxmK9skZBD1d7"

    def test_no_resource_object(self):
        conn = {
            "id": "mcn1",
            "connectionType": "STS_ACCESS_TOKEN",
            "resourceIndicator": "orn:okta:idp:00o:client-auth-settings:rsc1",
        }
        metadata = extract_connection_metadata(conn, OktaConnectionType.STS_ACCESS_TOKEN)
        assert metadata["resource_indicator"] == "orn:okta:idp:00o:client-auth-settings:rsc1"
        assert "app_instance_id" not in metadata


class TestParseConnectionType:

    def test_parse_sts_access_token(self):
        conn = {"connectionType": "STS_ACCESS_TOKEN"}
        result = parse_connection_type(conn)
        assert result == OktaConnectionType.STS_ACCESS_TOKEN

    def test_parse_via_type_field(self):
        conn = {"type": "STS_ACCESS_TOKEN"}
        result = parse_connection_type(conn)
        assert result == OktaConnectionType.STS_ACCESS_TOKEN


class TestExtractResourceIdFromConnection:

    def test_full_connection(self):
        resource_id, conn_type = extract_resource_id_from_connection(STS_ACCESS_TOKEN_CONN)
        assert conn_type == OktaConnectionType.STS_ACCESS_TOKEN
        assert resource_id == "rscwecmwxmK9skZBD1d7"
