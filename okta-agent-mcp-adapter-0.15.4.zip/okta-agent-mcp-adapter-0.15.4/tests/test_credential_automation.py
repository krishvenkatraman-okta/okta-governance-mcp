"""Tests for credential automation — service layer and admin API routes."""

import json
import logging
from unittest.mock import AsyncMock, MagicMock, patch

import httpx
import pytest
import pytest_asyncio
from starlette.requests import Request
from starlette.testclient import TestClient

from okta_agent_proxy.okta_admin.client import OktaAPIClient
from okta_agent_proxy.okta_admin.exceptions import (
    OktaAdminAPIError,
    OktaAdminAuthError,
    OktaAdminForbiddenError,
    OktaAdminNotFoundError,
)
from okta_agent_proxy.okta_admin.service import CredentialAutomationService

FAKE_TOKEN = "admin-okta-token-xyz"
AGENT_ID = "claude-code"
OKTA_AGENT_ID = "agtABC123"
APP_ID = "0oaAPP456"


# ── Mock config store ────────────────────────────────────────────────────

def _make_store(agent_data=None):
    store = MagicMock()
    store.get_agent.return_value = agent_data
    store.update_agent.return_value = True
    return store


def _agent_with_okta_id(**overrides):
    base = {
        "agent_id": AGENT_ID,
        "agent_name": "claude-code",
        "client_id": "0oaClientXYZ",
        "client_secret": None,
        "private_key": None,
        "okta_ai_agent_id": OKTA_AGENT_ID,
        "enabled": True,
    }
    base.update(overrides)
    return base


def _agent_without_okta_id():
    return _agent_with_okta_id(okta_ai_agent_id=None)


def _make_api_client():
    client = MagicMock(spec=OktaAPIClient)
    client.get = AsyncMock()
    client.post = AsyncMock()
    return client


def _make_response(json_body, status_code=200):
    return httpx.Response(
        status_code=status_code,
        json=json_body,
        request=httpx.Request("GET", "https://dev.okta.com"),
    )


# ── Service: fetch_client_secret ─────────────────────────────────────────

@pytest.mark.asyncio
async def test_fetch_secret_success():
    api = _make_api_client()
    store = _make_store(_agent_with_okta_id())
    svc = CredentialAutomationService(api, store)

    # Mock agent lookup → app_id
    api.get.return_value = _make_response({
        "id": OKTA_AGENT_ID,
        "credentials": {"oauthClient": {"client_id": APP_ID}},
    })
    # Mock list secrets → one active secret
    api.get.side_effect = [
        # get_agent_linked_app_id
        _make_response({"credentials": {"oauthClient": {"client_id": APP_ID}}}),
        # list_app_secrets
        _make_response([{"id": "s1", "status": "ACTIVE", "client_secret": "sec123", "created": "2026-01-01T00:00:00Z"}]),
    ]

    result = await svc.fetch_client_secret(AGENT_ID, FAKE_TOKEN)
    assert result["status"] == "success"
    assert result["source"] == "fetched_existing"
    assert result["app_id"] == APP_ID
    # Secret must not be in response
    assert "client_secret" not in result
    assert "sec123" not in json.dumps(result)

    # Verify store was updated
    store.update_agent.assert_called_once()
    call_config = store.update_agent.call_args[0][1]
    assert call_config["client_secret"] == "sec123"


@pytest.mark.asyncio
async def test_fetch_secret_agent_not_found():
    api = _make_api_client()
    store = _make_store(None)
    svc = CredentialAutomationService(api, store)

    result = await svc.fetch_client_secret("missing-agent", FAKE_TOKEN)
    assert result["status"] == "error"
    assert "not found" in result["message"]


@pytest.mark.asyncio
async def test_fetch_secret_no_okta_agent_id():
    api = _make_api_client()
    store = _make_store(_agent_without_okta_id())
    svc = CredentialAutomationService(api, store)

    result = await svc.fetch_client_secret(AGENT_ID, FAKE_TOKEN)
    assert result["status"] == "error"
    assert "okta_agent_id" in result["message"].lower() or "Okta AI Agent ID" in result["message"]


@pytest.mark.asyncio
async def test_fetch_secret_okta_401():
    api = _make_api_client()
    store = _make_store(_agent_with_okta_id())
    svc = CredentialAutomationService(api, store)
    api.get.side_effect = OktaAdminAuthError("expired")

    with pytest.raises(OktaAdminAuthError):
        await svc.fetch_client_secret(AGENT_ID, FAKE_TOKEN)


@pytest.mark.asyncio
async def test_fetch_secret_okta_403():
    api = _make_api_client()
    store = _make_store(_agent_with_okta_id())
    svc = CredentialAutomationService(api, store)
    api.get.side_effect = OktaAdminForbiddenError("forbidden")

    with pytest.raises(OktaAdminForbiddenError):
        await svc.fetch_client_secret(AGENT_ID, FAKE_TOKEN)


@pytest.mark.asyncio
async def test_fetch_secret_okta_api_error():
    api = _make_api_client()
    store = _make_store(_agent_with_okta_id())
    svc = CredentialAutomationService(api, store)
    api.get.side_effect = OktaAdminAPIError("boom", status_code=500, error_description="internal")

    with pytest.raises(OktaAdminAPIError):
        await svc.fetch_client_secret(AGENT_ID, FAKE_TOKEN)


@pytest.mark.asyncio
async def test_fetch_secret_generates_when_no_active():
    api = _make_api_client()
    store = _make_store(_agent_with_okta_id())
    svc = CredentialAutomationService(api, store)

    api.get.side_effect = [
        _make_response({"credentials": {"oauthClient": {"client_id": APP_ID}}}),
        _make_response([]),  # no active secrets
    ]
    api.post.return_value = _make_response({
        "id": "s2", "status": "ACTIVE", "client_secret": "new-sec", "created": "2026-03-17T00:00:00Z"
    })

    result = await svc.fetch_client_secret(AGENT_ID, FAKE_TOKEN)
    assert result["source"] == "generated_new"


# ── Service: generate_key_pair ───────────────────────────────────────────

@pytest.mark.asyncio
async def test_generate_keypair_success():
    api = _make_api_client()
    store = _make_store(_agent_with_okta_id())
    svc = CredentialAutomationService(api, store)

    # Mock register_public_key
    api.post.return_value = _make_response({"status": "ACTIVE"})

    result = await svc.generate_key_pair(AGENT_ID, FAKE_TOKEN)
    assert result["status"] == "success"
    assert "kid" in result
    assert result["agent_id"] == AGENT_ID
    # Private key must NOT be in response
    assert "d" not in result
    assert "private" not in json.dumps(result).lower()

    # Verify store was updated with encrypted private key
    store.update_agent.assert_called_once()
    call_config = store.update_agent.call_args[0][1]
    assert "private_key" in call_config
    priv_jwk = json.loads(call_config["private_key"])
    assert "d" in priv_jwk  # private key was stored


@pytest.mark.asyncio
async def test_generate_keypair_agent_not_found():
    api = _make_api_client()
    store = _make_store(None)
    svc = CredentialAutomationService(api, store)

    result = await svc.generate_key_pair("missing", FAKE_TOKEN)
    assert result["status"] == "error"


@pytest.mark.asyncio
async def test_generate_keypair_no_okta_agent_id():
    api = _make_api_client()
    store = _make_store(_agent_without_okta_id())
    svc = CredentialAutomationService(api, store)

    result = await svc.generate_key_pair(AGENT_ID, FAKE_TOKEN)
    assert result["status"] == "error"
    assert "Okta AI Agent ID" in result["message"]


@pytest.mark.asyncio
async def test_generate_keypair_okta_401():
    api = _make_api_client()
    store = _make_store(_agent_with_okta_id())
    svc = CredentialAutomationService(api, store)
    api.post.side_effect = OktaAdminAuthError("expired")

    with pytest.raises(OktaAdminAuthError):
        await svc.generate_key_pair(AGENT_ID, FAKE_TOKEN)


@pytest.mark.asyncio
async def test_generate_keypair_okta_403():
    api = _make_api_client()
    store = _make_store(_agent_with_okta_id())
    svc = CredentialAutomationService(api, store)
    api.post.side_effect = OktaAdminForbiddenError("forbidden")

    with pytest.raises(OktaAdminForbiddenError):
        await svc.generate_key_pair(AGENT_ID, FAKE_TOKEN)


@pytest.mark.asyncio
async def test_generate_keypair_only_public_sent_to_okta():
    api = _make_api_client()
    store = _make_store(_agent_with_okta_id())
    svc = CredentialAutomationService(api, store)
    api.post.return_value = _make_response({"status": "ACTIVE"})

    await svc.generate_key_pair(AGENT_ID, FAKE_TOKEN)

    sent = api.post.call_args.kwargs.get("json")
    if sent is None:
        sent = api.post.call_args[0][2]
    private_fields = {"d", "p", "q", "dp", "dq", "qi"}
    assert private_fields.isdisjoint(sent.keys()), "Private key must not be sent to Okta"


# ── Service: get_credential_status ───────────────────────────────────────

@pytest.mark.asyncio
async def test_status_with_credentials():
    api = _make_api_client()
    agent = _agent_with_okta_id(client_secret="enc-secret", private_key='{"kty":"RSA"}')
    store = _make_store(agent)
    svc = CredentialAutomationService(api, store)

    api.get.return_value = _make_response([{"kid": "k1", "alg": "RS256"}])

    result = await svc.get_credential_status(AGENT_ID, FAKE_TOKEN)
    assert result["has_client_secret"] is True
    assert result["has_private_key"] is True
    assert result["okta_agent_id"] == OKTA_AGENT_ID
    assert len(result["registered_keys"]) == 1
    assert result["registered_keys"][0]["kid"] == "k1"
    # No actual secret values
    assert "enc-secret" not in json.dumps(result)


@pytest.mark.asyncio
async def test_status_without_credentials():
    api = _make_api_client()
    agent = _agent_with_okta_id(client_secret=None, private_key=None)
    store = _make_store(agent)
    svc = CredentialAutomationService(api, store)

    api.get.return_value = _make_response([])

    result = await svc.get_credential_status(AGENT_ID, FAKE_TOKEN)
    assert result["has_client_secret"] is False
    assert result["has_private_key"] is False
    assert result["registered_keys"] == []


@pytest.mark.asyncio
async def test_status_graceful_403_on_key_list():
    api = _make_api_client()
    store = _make_store(_agent_with_okta_id())
    svc = CredentialAutomationService(api, store)
    api.get.side_effect = OktaAdminForbiddenError("no scope")

    result = await svc.get_credential_status(AGENT_ID, FAKE_TOKEN)
    assert result["registered_keys"] == []


@pytest.mark.asyncio
async def test_status_agent_not_found():
    api = _make_api_client()
    store = _make_store(None)
    svc = CredentialAutomationService(api, store)

    result = await svc.get_credential_status("missing", FAKE_TOKEN)
    assert result["status"] == "error"


@pytest.mark.asyncio
async def test_status_no_okta_agent_id():
    api = _make_api_client()
    store = _make_store(_agent_without_okta_id())
    svc = CredentialAutomationService(api, store)

    result = await svc.get_credential_status(AGENT_ID, FAKE_TOKEN)
    assert result["okta_agent_id"] is None
    assert result["registered_keys"] == []


# ── Admin API Routes ─────────────────────────────────────────────────────
# Test the routes via the credential_routes module directly using a
# Starlette test client.

from starlette.applications import Starlette
from starlette.routing import Route
from okta_agent_proxy.admin import credential_routes as cr_module


def _build_test_app(service):
    """Build a minimal Starlette app with credential routes."""
    cr_module.wire_credential_routes(service)
    app = Starlette(routes=[
        Route("/api/admin/agents/{agent_id}/credentials/fetch-secret", cr_module.fetch_secret, methods=["POST"]),
        Route("/api/admin/agents/{agent_id}/credentials/generate-keypair", cr_module.generate_keypair, methods=["POST"]),
        Route("/api/admin/agents/{agent_id}/credentials/status", cr_module.credential_status, methods=["GET"]),
    ])
    return app


def _auth_headers():
    """Admin auth headers — we patch the middleware to accept these."""
    return {"Authorization": f"Bearer {FAKE_TOKEN}"}


def _make_service(store_agent=None):
    api = _make_api_client()
    store = _make_store(store_agent)
    return CredentialAutomationService(api, store), api, store


@pytest.fixture
def mock_admin_auth():
    """Patch admin auth to always succeed."""
    async def _always_valid(token):
        return {"username": "admin-test", "role": "admin", "token_type": "okta_oauth"}

    with patch("okta_agent_proxy.admin.middleware.verify_okta_token", _always_valid):
        yield


def test_route_fetch_secret_requires_auth():
    """Without a valid Okta access token, should get 401."""
    svc, _, _ = _make_service(_agent_with_okta_id())
    app = _build_test_app(svc)
    client = TestClient(app)

    async def _no_okta(token):
        return None

    with patch("okta_agent_proxy.admin.middleware.verify_okta_token", _no_okta):
        resp = client.post(
            f"/api/admin/agents/{AGENT_ID}/credentials/fetch-secret",
            headers={"Authorization": "Bearer bad-token"},
        )
        assert resp.status_code == 401


def test_route_fetch_secret_success(mock_admin_auth):
    svc, api, store = _make_service(_agent_with_okta_id())
    app = _build_test_app(svc)
    client = TestClient(app)

    api.get.side_effect = [
        _make_response({"credentials": {"oauthClient": {"client_id": APP_ID}}}),
        _make_response([{"id": "s1", "status": "ACTIVE", "client_secret": "sec", "created": "2026-01-01T00:00:00Z"}]),
    ]

    resp = client.post(
        f"/api/admin/agents/{AGENT_ID}/credentials/fetch-secret",
        headers=_auth_headers(),
    )
    assert resp.status_code == 200
    body = resp.json()
    assert body["status"] == "success"
    assert "sec" not in json.dumps(body)


def test_route_fetch_secret_404_agent(mock_admin_auth):
    svc, _, _ = _make_service(None)
    app = _build_test_app(svc)
    client = TestClient(app)

    resp = client.post(
        f"/api/admin/agents/missing/credentials/fetch-secret",
        headers=_auth_headers(),
    )
    assert resp.status_code == 404


def test_route_fetch_secret_okta_401(mock_admin_auth):
    svc, api, _ = _make_service(_agent_with_okta_id())
    app = _build_test_app(svc)
    client = TestClient(app)
    api.get.side_effect = OktaAdminAuthError("expired")

    resp = client.post(
        f"/api/admin/agents/{AGENT_ID}/credentials/fetch-secret",
        headers=_auth_headers(),
    )
    assert resp.status_code == 401
    assert "expired" in resp.json()["message"].lower() or "okta_auth_error" in resp.json()["error"]


def test_route_fetch_secret_okta_403(mock_admin_auth):
    svc, api, _ = _make_service(_agent_with_okta_id())
    app = _build_test_app(svc)
    client = TestClient(app)
    api.get.side_effect = OktaAdminForbiddenError("forbidden")

    resp = client.post(
        f"/api/admin/agents/{AGENT_ID}/credentials/fetch-secret",
        headers=_auth_headers(),
    )
    assert resp.status_code == 403
    assert "okta.apps.manage" in resp.json()["message"]


def test_route_fetch_secret_okta_502(mock_admin_auth):
    svc, api, _ = _make_service(_agent_with_okta_id())
    app = _build_test_app(svc)
    client = TestClient(app)
    api.get.side_effect = OktaAdminAPIError("boom", status_code=500, error_description="internal")

    resp = client.post(
        f"/api/admin/agents/{AGENT_ID}/credentials/fetch-secret",
        headers=_auth_headers(),
    )
    assert resp.status_code == 502


def test_route_generate_keypair_success(mock_admin_auth):
    svc, api, store = _make_service(_agent_with_okta_id())
    app = _build_test_app(svc)
    client = TestClient(app)
    api.post.return_value = _make_response({"status": "ACTIVE"})

    resp = client.post(
        f"/api/admin/agents/{AGENT_ID}/credentials/generate-keypair",
        headers=_auth_headers(),
    )
    assert resp.status_code == 200
    body = resp.json()
    assert body["status"] == "success"
    assert "kid" in body
    # Must not leak private key
    assert "d" not in body
    assert "private" not in json.dumps(body).lower()


def test_route_generate_keypair_403(mock_admin_auth):
    svc, api, _ = _make_service(_agent_with_okta_id())
    app = _build_test_app(svc)
    client = TestClient(app)
    api.post.side_effect = OktaAdminForbiddenError("forbidden")

    resp = client.post(
        f"/api/admin/agents/{AGENT_ID}/credentials/generate-keypair",
        headers=_auth_headers(),
    )
    assert resp.status_code == 403
    assert "okta.aiAgents.manage" in resp.json()["message"]


def test_route_credential_status_success(mock_admin_auth):
    agent = _agent_with_okta_id(client_secret="x", private_key='{"kty":"RSA"}')
    svc, api, _ = _make_service(agent)
    app = _build_test_app(svc)
    client = TestClient(app)
    api.get.return_value = _make_response([{"kid": "k1", "alg": "RS256"}])

    resp = client.get(
        f"/api/admin/agents/{AGENT_ID}/credentials/status",
        headers=_auth_headers(),
    )
    assert resp.status_code == 200
    body = resp.json()
    assert body["has_client_secret"] is True
    assert body["has_private_key"] is True
    assert body["okta_agent_id"] == OKTA_AGENT_ID


def test_route_credential_status_404(mock_admin_auth):
    svc, _, _ = _make_service(None)
    app = _build_test_app(svc)
    client = TestClient(app)

    resp = client.get(
        f"/api/admin/agents/missing/credentials/status",
        headers=_auth_headers(),
    )
    assert resp.status_code == 404


# ── Token extraction & pass-through ──────────────────────────────────────

def test_admin_token_passed_to_okta(mock_admin_auth):
    """Verify the admin's Bearer token is forwarded to Okta API calls."""
    svc, api, _ = _make_service(_agent_with_okta_id())
    app = _build_test_app(svc)
    client = TestClient(app)
    api.post.return_value = _make_response({"status": "ACTIVE"})

    client.post(
        f"/api/admin/agents/{AGENT_ID}/credentials/generate-keypair",
        headers={"Authorization": f"Bearer {FAKE_TOKEN}"},
    )

    # The api.post was called with the token
    call_args = api.post.call_args
    assert call_args[0][1] == FAKE_TOKEN


# ── Integration: fetch then verify config updated ────────────────────────

def test_integration_fetch_updates_config(mock_admin_auth):
    svc, api, store = _make_service(_agent_with_okta_id())
    app = _build_test_app(svc)
    client = TestClient(app)

    api.get.side_effect = [
        _make_response({"credentials": {"oauthClient": {"client_id": APP_ID}}}),
        _make_response([{"id": "s1", "status": "ACTIVE", "client_secret": "new-sec", "created": "2026-01-01T00:00:00Z"}]),
    ]

    resp = client.post(
        f"/api/admin/agents/{AGENT_ID}/credentials/fetch-secret",
        headers=_auth_headers(),
    )
    assert resp.status_code == 200

    # Config store must have been updated
    store.update_agent.assert_called_once()
    config_arg = store.update_agent.call_args[0][1]
    assert config_arg["client_secret"] == "new-sec"


def test_integration_generate_updates_config(mock_admin_auth):
    svc, api, store = _make_service(_agent_with_okta_id())
    app = _build_test_app(svc)
    client = TestClient(app)
    api.post.return_value = _make_response({"status": "ACTIVE"})

    resp = client.post(
        f"/api/admin/agents/{AGENT_ID}/credentials/generate-keypair",
        headers=_auth_headers(),
    )
    assert resp.status_code == 200

    store.update_agent.assert_called_once()
    config_arg = store.update_agent.call_args[0][1]
    priv_jwk = json.loads(config_arg["private_key"])
    assert "d" in priv_jwk
    assert "p" in priv_jwk


# ── Secrets never in logs ────────────────────────────────────────────────

@pytest.mark.asyncio
async def test_secrets_not_logged(caplog):
    api = _make_api_client()
    store = _make_store(_agent_with_okta_id())
    svc = CredentialAutomationService(api, store)

    api.get.side_effect = [
        _make_response({"credentials": {"oauthClient": {"client_id": APP_ID}}}),
        _make_response([{"id": "s1", "status": "ACTIVE", "client_secret": "SUPER-SECRET-123", "created": "2026-01-01T00:00:00Z"}]),
    ]

    with caplog.at_level(logging.DEBUG):
        await svc.fetch_client_secret(AGENT_ID, FAKE_TOKEN)

    for record in caplog.records:
        msg = record.getMessage()
        assert "SUPER-SECRET-123" not in msg, "Secret must never appear in logs"
        assert FAKE_TOKEN not in msg, "Admin token must never appear in logs"
