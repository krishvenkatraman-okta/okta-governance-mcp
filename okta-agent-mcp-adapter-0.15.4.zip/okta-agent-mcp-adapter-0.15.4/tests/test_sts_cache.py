"""
Tests for STS token cache functionality.

Covers:
- STS token cache set/get/expiry
- Cache key format: "sts:{hash}:{hash}"
- Cache miss returns None
- TTL calculation: min(expires_in - 60, 28800)
- Invalidation
- Isolation between users and resources
- CacheService integration (L2)
"""

import hashlib
import pytest
from unittest.mock import AsyncMock, MagicMock, patch

from okta_agent_proxy.cache.token_cache import TokenCache


# ============================================================================
# Key format
# ============================================================================


class TestStsCacheKeyFormat:

    def test_key_starts_with_sts_prefix(self):
        key = TokenCache._make_sts_key("user@example.com", "orn:okta:rsc123")
        assert key.startswith("sts:")

    def test_key_has_three_colon_separated_parts(self):
        key = TokenCache._make_sts_key("user@example.com", "orn:okta:rsc123")
        parts = key.split(":")
        assert len(parts) == 3

    def test_key_uses_sha256_hashes(self):
        user_id = "user@example.com"
        ri = "orn:okta:idp:00o:client-auth-settings:rsc123"
        key = TokenCache._make_sts_key(user_id, ri)

        expected_user_hash = hashlib.sha256(user_id.encode()).hexdigest()[:12]
        expected_ri_hash = hashlib.sha256(ri.encode()).hexdigest()[:12]
        assert key == f"sts:{expected_user_hash}:{expected_ri_hash}"

    def test_hash_parts_are_12_chars(self):
        key = TokenCache._make_sts_key("u", "r")
        parts = key.split(":")
        assert len(parts[1]) == 12
        assert len(parts[2]) == 12

    def test_different_users_produce_different_keys(self):
        k1 = TokenCache._make_sts_key("alice@example.com", "orn:okta:rsc1")
        k2 = TokenCache._make_sts_key("bob@example.com", "orn:okta:rsc1")
        assert k1 != k2

    def test_different_resources_produce_different_keys(self):
        k1 = TokenCache._make_sts_key("user@example.com", "orn:okta:rsc1")
        k2 = TokenCache._make_sts_key("user@example.com", "orn:okta:rsc2")
        assert k1 != k2

    def test_same_inputs_produce_same_key(self):
        k1 = TokenCache._make_sts_key("user@example.com", "orn:okta:rsc1")
        k2 = TokenCache._make_sts_key("user@example.com", "orn:okta:rsc1")
        assert k1 == k2


# ============================================================================
# Basic get/set/miss
# ============================================================================


class TestStsCacheBasics:

    def test_cache_miss_returns_none(self):
        cache = TokenCache(max_size=100, ttl_seconds=60)
        assert cache.get_sts_token("user1", "orn:okta:rsc1") is None

    def test_set_then_get(self):
        cache = TokenCache(max_size=100, ttl_seconds=60)
        cache.set_sts_token("user1", "orn:okta:rsc1", "gho_tok123", expires_in=3600)
        assert cache.get_sts_token("user1", "orn:okta:rsc1") == "gho_tok123"

    def test_set_overwrites_previous(self):
        cache = TokenCache(max_size=100, ttl_seconds=60)
        cache.set_sts_token("user1", "orn:okta:rsc1", "tok_old", expires_in=3600)
        cache.set_sts_token("user1", "orn:okta:rsc1", "tok_new", expires_in=3600)
        assert cache.get_sts_token("user1", "orn:okta:rsc1") == "tok_new"


# ============================================================================
# TTL calculation
# ============================================================================


class TestStsCacheTtl:

    def test_ttl_is_expires_in_minus_60(self):
        """For normal expires_in, TTL should be expires_in - 60."""
        cache = TokenCache(max_size=100, ttl_seconds=86400)
        # We can't directly inspect the TTL on the cachetools entry,
        # but we can verify the token is stored and retrievable
        cache.set_sts_token("u", "r", "tok", expires_in=3600)
        assert cache.get_sts_token("u", "r") == "tok"

    def test_ttl_clamped_to_28800_max(self):
        """TTL should never exceed 28800 (8 hours)."""
        cache = TokenCache(max_size=100, ttl_seconds=86400)
        # Very large expires_in should be clamped
        cache.set_sts_token("u", "r", "tok", expires_in=999999)
        assert cache.get_sts_token("u", "r") == "tok"

    def test_ttl_floor_is_60_seconds(self):
        """TTL should be at least 60 seconds even if expires_in is tiny."""
        cache = TokenCache(max_size=100, ttl_seconds=86400)
        # expires_in=30 → max(30-60, 60) = 60
        cache.set_sts_token("u", "r", "tok", expires_in=30)
        assert cache.get_sts_token("u", "r") == "tok"


# ============================================================================
# Invalidation
# ============================================================================


class TestStsCacheInvalidation:

    def test_invalidate_removes_token(self):
        cache = TokenCache(max_size=100, ttl_seconds=60)
        cache.set_sts_token("user1", "orn:okta:rsc1", "tok", expires_in=3600)
        cache.invalidate_sts_token("user1", "orn:okta:rsc1")
        assert cache.get_sts_token("user1", "orn:okta:rsc1") is None

    def test_invalidate_nonexistent_is_noop(self):
        cache = TokenCache(max_size=100, ttl_seconds=60)
        # Should not raise
        cache.invalidate_sts_token("nobody", "orn:okta:nothing")

    def test_invalidate_one_user_does_not_affect_other(self):
        cache = TokenCache(max_size=100, ttl_seconds=60)
        cache.set_sts_token("user1", "orn:okta:rsc1", "tok1", expires_in=3600)
        cache.set_sts_token("user2", "orn:okta:rsc1", "tok2", expires_in=3600)
        cache.invalidate_sts_token("user1", "orn:okta:rsc1")
        assert cache.get_sts_token("user1", "orn:okta:rsc1") is None
        assert cache.get_sts_token("user2", "orn:okta:rsc1") == "tok2"

    def test_invalidate_one_resource_does_not_affect_other(self):
        cache = TokenCache(max_size=100, ttl_seconds=60)
        cache.set_sts_token("user1", "orn:okta:rsc1", "tok1", expires_in=3600)
        cache.set_sts_token("user1", "orn:okta:rsc2", "tok2", expires_in=3600)
        cache.invalidate_sts_token("user1", "orn:okta:rsc1")
        assert cache.get_sts_token("user1", "orn:okta:rsc1") is None
        assert cache.get_sts_token("user1", "orn:okta:rsc2") == "tok2"


# ============================================================================
# User/resource isolation
# ============================================================================


class TestStsCacheIsolation:

    def test_different_users_isolated(self):
        cache = TokenCache(max_size=100, ttl_seconds=60)
        cache.set_sts_token("alice", "orn:okta:rsc1", "alice_tok", expires_in=3600)
        cache.set_sts_token("bob", "orn:okta:rsc1", "bob_tok", expires_in=3600)
        assert cache.get_sts_token("alice", "orn:okta:rsc1") == "alice_tok"
        assert cache.get_sts_token("bob", "orn:okta:rsc1") == "bob_tok"

    def test_different_resources_isolated(self):
        cache = TokenCache(max_size=100, ttl_seconds=60)
        cache.set_sts_token("user1", "orn:okta:github", "gh_tok", expires_in=3600)
        cache.set_sts_token("user1", "orn:okta:jira", "jira_tok", expires_in=3600)
        assert cache.get_sts_token("user1", "orn:okta:github") == "gh_tok"
        assert cache.get_sts_token("user1", "orn:okta:jira") == "jira_tok"

    def test_clear_removes_sts_tokens(self):
        cache = TokenCache(max_size=100, ttl_seconds=60)
        cache.set_sts_token("user1", "orn:okta:rsc1", "tok", expires_in=3600)
        cache.clear()
        assert cache.get_sts_token("user1", "orn:okta:rsc1") is None


# ============================================================================
# CacheService (L2) integration
# ============================================================================


class TestStsCacheWithCacheService:

    def test_get_delegates_to_cache_service(self):
        cache_service = MagicMock()
        cache_service.get = AsyncMock(return_value='"gho_from_l2"')
        cache = TokenCache(max_size=100, ttl_seconds=60, cache_service=cache_service)

        result = cache.get_sts_token("user1", "orn:okta:rsc1")
        assert result == "gho_from_l2"
        cache_service.get.assert_called_once()

    def test_set_delegates_to_cache_service(self):
        cache_service = MagicMock()
        cache_service.set = AsyncMock()
        cache = TokenCache(max_size=100, ttl_seconds=60, cache_service=cache_service)

        cache.set_sts_token("user1", "orn:okta:rsc1", "tok", expires_in=3600)
        cache_service.set.assert_called_once()

    def test_cache_service_failure_falls_back_to_local(self):
        cache_service = MagicMock()
        cache_service.get = AsyncMock(side_effect=Exception("Redis down"))
        cache_service.set = AsyncMock(side_effect=Exception("Redis down"))
        cache = TokenCache(max_size=100, ttl_seconds=60, cache_service=cache_service)

        # set should fall back to local
        cache.set_sts_token("user1", "orn:okta:rsc1", "tok_local", expires_in=3600)
        # get should also fall back to local
        result = cache.get_sts_token("user1", "orn:okta:rsc1")
        assert result == "tok_local"
