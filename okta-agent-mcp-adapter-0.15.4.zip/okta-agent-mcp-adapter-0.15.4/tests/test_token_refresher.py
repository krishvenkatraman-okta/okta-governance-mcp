"""
Tests for TokenRefresher — transparent id_token refresh for XAA.

Tests:
- Successful refresh updates old AT and stores new AT mapping
- invalid_grant removes entry and returns None
- No stored entry → returns None
- No refresh_token → returns None
- Network error → returns None, entry NOT removed
- Manual Basic auth header construction
- Missing agent config → returns None
"""

import base64
import json
import pytest
from unittest.mock import patch, MagicMock, AsyncMock

from okta_agent_proxy.auth.token_refresher import TokenRefresher, get_token_refresher, reset_token_refresher
from okta_agent_proxy.auth.user_token_store import UserTokenStore


# ============================================================================
# Sample data
# ============================================================================

STORED_ENTRY = {
    "id_token": "old-id-token",
    "refresh_token": "rt-stored-xyz",
    "user_sub": "jane@corp.com",
    "agent_id": "claude-code",
    "stored_at": "2026-03-10T12:00:00+00:00",
    "expires_in": 3600,
}

AGENT_CONFIG = {
    "agent_id": "claude-code",
    "client_id": "0oaABC123",
    "client_secret": "secret-xyz",
    "backend_access": ["hr-system"],
    "enabled": True,
}

OKTA_REFRESH_RESPONSE = {
    "access_token": "new-access-token-456",
    "id_token": "new-id-token-789",
    "refresh_token": "new-rt-abc",
    "token_type": "Bearer",
    "expires_in": 3600,
}


# ============================================================================
# Helpers
# ============================================================================


def _make_httpx_response(status_code: int, json_data: dict):
    """Create a mock httpx.Response."""
    mock_resp = MagicMock()
    mock_resp.status_code = status_code
    mock_resp.json.return_value = json_data
    return mock_resp


def _make_refresher():
    """Create a TokenRefresher with a real (in-memory) UserTokenStore."""
    store = UserTokenStore(encryption_service=None, default_ttl=3600, max_size=100)
    return TokenRefresher(token_store=store), store


# ============================================================================
# Tests
# ============================================================================


class TestRefreshSuccess:
    @pytest.mark.asyncio
    async def test_refresh_success(self):
        """Successful refresh returns new id_token and updates old AT entry."""
        refresher, store = _make_refresher()

        # Seed the store with an entry
        store.store(
            access_token="old-at-123",
            id_token="old-id-token",
            refresh_token="rt-stored-xyz",
            user_sub="jane@corp.com",
            agent_id="claude-code",
            expires_in=3600,
        )

        mock_resp = _make_httpx_response(200, OKTA_REFRESH_RESPONSE)

        with patch("okta_agent_proxy.auth.token_refresher.get_store") as mock_get_store, \
             patch("httpx.AsyncClient") as mock_client_cls:
            mock_store = MagicMock()
            mock_store.get_agent.return_value = AGENT_CONFIG
            mock_get_store.return_value = mock_store

            mock_client = AsyncMock()
            mock_client.post.return_value = mock_resp
            mock_client.__aenter__ = AsyncMock(return_value=mock_client)
            mock_client.__aexit__ = AsyncMock(return_value=False)
            mock_client_cls.return_value = mock_client

            result = await refresher.refresh_id_token("old-at-123")

        assert result == "new-id-token-789"

        # Old AT entry should be updated with new id_token
        old_entry = store.lookup("old-at-123")
        assert old_entry is not None
        assert old_entry["id_token"] == "new-id-token-789"
        assert old_entry["refresh_token"] == "new-rt-abc"

    @pytest.mark.asyncio
    async def test_refresh_stores_new_access_token_mapping(self):
        """After refresh, BOTH old and new access_token keys exist in store."""
        refresher, store = _make_refresher()

        store.store(
            access_token="old-at-123",
            id_token="old-id-token",
            refresh_token="rt-stored-xyz",
            user_sub="jane@corp.com",
            agent_id="claude-code",
            expires_in=3600,
        )

        mock_resp = _make_httpx_response(200, OKTA_REFRESH_RESPONSE)

        with patch("okta_agent_proxy.auth.token_refresher.get_store") as mock_get_store, \
             patch("httpx.AsyncClient") as mock_client_cls:
            mock_store = MagicMock()
            mock_store.get_agent.return_value = AGENT_CONFIG
            mock_get_store.return_value = mock_store

            mock_client = AsyncMock()
            mock_client.post.return_value = mock_resp
            mock_client.__aenter__ = AsyncMock(return_value=mock_client)
            mock_client.__aexit__ = AsyncMock(return_value=False)
            mock_client_cls.return_value = mock_client

            await refresher.refresh_id_token("old-at-123")

        # New AT entry should also exist
        new_entry = store.lookup("new-access-token-456")
        assert new_entry is not None
        assert new_entry["id_token"] == "new-id-token-789"
        assert new_entry["user_sub"] == "jane@corp.com"
        assert new_entry["agent_id"] == "claude-code"


class TestRefreshFailures:
    @pytest.mark.asyncio
    async def test_refresh_invalid_grant_removes_entry(self):
        """Okta 400 invalid_grant removes the entry and returns None."""
        refresher, store = _make_refresher()

        store.store(
            access_token="old-at-123",
            id_token="old-id-token",
            refresh_token="rt-expired",
            user_sub="jane@corp.com",
            agent_id="claude-code",
            expires_in=3600,
        )

        mock_resp = _make_httpx_response(400, {"error": "invalid_grant"})

        with patch("okta_agent_proxy.auth.token_refresher.get_store") as mock_get_store, \
             patch("httpx.AsyncClient") as mock_client_cls:
            mock_store = MagicMock()
            mock_store.get_agent.return_value = AGENT_CONFIG
            mock_get_store.return_value = mock_store

            mock_client = AsyncMock()
            mock_client.post.return_value = mock_resp
            mock_client.__aenter__ = AsyncMock(return_value=mock_client)
            mock_client.__aexit__ = AsyncMock(return_value=False)
            mock_client_cls.return_value = mock_client

            result = await refresher.refresh_id_token("old-at-123")

        assert result is None
        # Entry should be removed
        assert store.lookup("old-at-123") is None

    @pytest.mark.asyncio
    async def test_refresh_no_stored_entry(self):
        """No stored entry → returns None without calling Okta."""
        refresher, store = _make_refresher()

        result = await refresher.refresh_id_token("nonexistent-at")

        assert result is None

    @pytest.mark.asyncio
    async def test_refresh_no_refresh_token(self):
        """Entry exists but refresh_token is empty → returns None."""
        refresher, store = _make_refresher()

        store.store(
            access_token="old-at-123",
            id_token="old-id-token",
            refresh_token="",
            user_sub="jane@corp.com",
            agent_id="claude-code",
            expires_in=3600,
        )

        result = await refresher.refresh_id_token("old-at-123")

        assert result is None

    @pytest.mark.asyncio
    async def test_refresh_network_error(self):
        """Network error returns None but does NOT remove the entry."""
        import httpx as httpx_mod

        refresher, store = _make_refresher()

        store.store(
            access_token="old-at-123",
            id_token="old-id-token",
            refresh_token="rt-stored-xyz",
            user_sub="jane@corp.com",
            agent_id="claude-code",
            expires_in=3600,
        )

        with patch("okta_agent_proxy.auth.token_refresher.get_store") as mock_get_store, \
             patch("httpx.AsyncClient") as mock_client_cls:
            mock_store = MagicMock()
            mock_store.get_agent.return_value = AGENT_CONFIG
            mock_get_store.return_value = mock_store

            mock_client = AsyncMock()
            mock_client.post.side_effect = httpx_mod.ConnectTimeout("Connection timed out")
            mock_client.__aenter__ = AsyncMock(return_value=mock_client)
            mock_client.__aexit__ = AsyncMock(return_value=False)
            mock_client_cls.return_value = mock_client

            result = await refresher.refresh_id_token("old-at-123")

        assert result is None
        # Entry should still exist (transient failure)
        assert store.lookup("old-at-123") is not None

    @pytest.mark.asyncio
    async def test_refresh_agent_not_found(self):
        """Agent config not found → returns None."""
        refresher, store = _make_refresher()

        store.store(
            access_token="old-at-123",
            id_token="old-id-token",
            refresh_token="rt-stored-xyz",
            user_sub="jane@corp.com",
            agent_id="missing-agent",
            expires_in=3600,
        )

        with patch("okta_agent_proxy.auth.token_refresher.get_store") as mock_get_store:
            mock_store = MagicMock()
            mock_store.get_agent.return_value = None
            mock_get_store.return_value = mock_store

            result = await refresher.refresh_id_token("old-at-123")

        assert result is None


class TestBasicAuth:
    @pytest.mark.asyncio
    async def test_manual_basic_auth(self):
        """Verify Authorization header is manually constructed Basic auth."""
        refresher, store = _make_refresher()

        store.store(
            access_token="old-at-123",
            id_token="old-id-token",
            refresh_token="rt-stored-xyz",
            user_sub="jane@corp.com",
            agent_id="claude-code",
            expires_in=3600,
        )

        mock_resp = _make_httpx_response(200, OKTA_REFRESH_RESPONSE)
        captured_headers = {}

        with patch("okta_agent_proxy.auth.token_refresher.get_store") as mock_get_store, \
             patch("httpx.AsyncClient") as mock_client_cls:
            mock_store = MagicMock()
            mock_store.get_agent.return_value = AGENT_CONFIG
            mock_get_store.return_value = mock_store

            mock_client = AsyncMock()

            async def capture_post(url, headers=None, data=None):
                captured_headers.update(headers or {})
                return mock_resp

            mock_client.post = capture_post
            mock_client.__aenter__ = AsyncMock(return_value=mock_client)
            mock_client.__aexit__ = AsyncMock(return_value=False)
            mock_client_cls.return_value = mock_client

            await refresher.refresh_id_token("old-at-123")

        # Verify Basic auth header
        auth_header = captured_headers.get("Authorization", "")
        assert auth_header.startswith("Basic ")

        # Decode and verify credentials
        encoded = auth_header.split(" ", 1)[1]
        decoded = base64.b64decode(encoded).decode()
        assert decoded == "0oaABC123:secret-xyz"


class TestSingleton:
    def test_get_token_refresher_creates_instance(self):
        """get_token_refresher() creates and returns a TokenRefresher."""
        reset_token_refresher()

        with patch("okta_agent_proxy.auth.user_token_store.get_user_token_store") as mock_get:
            mock_store = MagicMock(spec=UserTokenStore)
            mock_get.return_value = mock_store

            refresher = get_token_refresher()

        assert isinstance(refresher, TokenRefresher)
        assert refresher._store is mock_store

    def test_get_token_refresher_returns_same_instance(self):
        """get_token_refresher() returns the same instance on subsequent calls."""
        reset_token_refresher()

        with patch("okta_agent_proxy.auth.user_token_store.get_user_token_store") as mock_get:
            mock_store = MagicMock(spec=UserTokenStore)
            mock_get.return_value = mock_store

            r1 = get_token_refresher()
            r2 = get_token_refresher()

        assert r1 is r2

    def test_reset_clears_singleton(self):
        """reset_token_refresher() clears the cached instance."""
        reset_token_refresher()

        with patch("okta_agent_proxy.auth.user_token_store.get_user_token_store") as mock_get:
            mock_store = MagicMock(spec=UserTokenStore)
            mock_get.return_value = mock_store

            r1 = get_token_refresher()
            reset_token_refresher()
            r2 = get_token_refresher()

        assert r1 is not r2
