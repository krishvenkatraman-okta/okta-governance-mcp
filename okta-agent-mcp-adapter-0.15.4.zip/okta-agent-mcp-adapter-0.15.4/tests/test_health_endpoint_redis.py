"""Tests for the /health endpoint's Redis credential preflight surface (P08).

The health handler must:
- Return 200 + status=healthy when preflight ok is True or None.
- Return 503 + status=degraded when preflight ok is False.
- Always include a "redis_credentials" block with the recorded state.
"""

import json
import sys
from unittest.mock import AsyncMock, MagicMock

import pytest


def _ensure_app_imported():
    mod = sys.modules.get("okta_agent_proxy.app")
    if mod is not None and hasattr(mod, "_redis_preflight_result"):
        return

    sys.modules.pop("okta_agent_proxy.app", None)

    import okta_agent_proxy.database as _db_mod
    _orig_get = _db_mod.get_config_store
    _orig_store = _db_mod._config_store
    _mock_store = MagicMock()
    _mock_store.get_all_resources.return_value = []
    _mock_store.get_all_agents.return_value = []
    _db_mod.get_config_store = lambda **kw: _mock_store
    _db_mod._config_store = _mock_store
    try:
        import importlib
        import okta_agent_proxy.app
        importlib.reload(okta_agent_proxy.app)
    except Exception:
        sys.modules.pop("okta_agent_proxy.app", None)
        raise
    finally:
        _db_mod.get_config_store = _orig_get
        _db_mod._config_store = _orig_store


@pytest.fixture
def app_mod(monkeypatch):
    _ensure_app_imported()
    from okta_agent_proxy import app as _app

    # Stub store methods used by health_check
    fake_store = MagicMock()
    fake_store.get_all_resources.return_value = []
    fake_store.get_all_agents.return_value = []
    monkeypatch.setattr(_app, "store", fake_store)

    # Stub cache_service.health_check to avoid real Redis
    fake_cache = MagicMock()
    fake_cache.l2 = MagicMock()
    fake_cache.health_check = AsyncMock(return_value=True)
    monkeypatch.setattr(_app, "cache_service", fake_cache)

    # Reset preflight state
    _app._redis_preflight_result.update({
        "ok": None,
        "provider": None,
        "principal": None,
        "expires_at": None,
        "error": None,
        "checked_at": None,
    })
    return _app


async def _call_health(app_mod):
    req = MagicMock()
    response = await app_mod.health_check(req)
    body = json.loads(bytes(response.body).decode("utf-8"))
    return response, body


@pytest.mark.asyncio
async def test_health_returns_200_when_preflight_ok(app_mod):
    app_mod._redis_preflight_result.update({
        "ok": True,
        "provider": "aws-iam",
        "principal": "arn:aws:iam::1234:role/test",
        "expires_at": "2030-01-01T00:00:00+00:00",
        "checked_at": "2026-05-02T00:00:00+00:00",
    })

    response, body = await _call_health(app_mod)

    assert response.status_code == 200
    assert body["status"] == "healthy"


@pytest.mark.asyncio
async def test_health_returns_503_when_preflight_failed(app_mod):
    app_mod._redis_preflight_result.update({
        "ok": False,
        "provider": "aws-iam",
        "error": "CredentialUnavailableError: missing IAM role",
        "checked_at": "2026-05-02T00:00:00+00:00",
    })

    response, body = await _call_health(app_mod)

    assert response.status_code == 503
    assert body["status"] == "degraded"
    assert body["redis_credentials"]["ok"] is False
    assert "missing IAM role" in body["redis_credentials"]["error"]


@pytest.mark.asyncio
async def test_health_returns_200_when_preflight_pending(app_mod):
    """ok=None (preflight still running) → 200 healthy."""
    app_mod._redis_preflight_result["ok"] = None

    response, body = await _call_health(app_mod)

    assert response.status_code == 200
    assert body["status"] == "healthy"


@pytest.mark.asyncio
async def test_health_includes_redis_credentials_block(app_mod):
    app_mod._redis_preflight_result.update({
        "ok": True,
        "provider": "memory",
        "checked_at": "2026-05-02T00:00:00+00:00",
    })

    response, body = await _call_health(app_mod)

    assert "redis_credentials" in body
    block = body["redis_credentials"]
    for field in ("ok", "provider", "principal", "expires_at", "error", "checked_at"):
        assert field in block
