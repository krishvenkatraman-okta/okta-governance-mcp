"""Tests for Prompt 1: DCR agent selection schema, audit events, and storage.

As of DB migration P07 these tests depend on the removed SQLAlchemy
``AgentModel`` and ``postgres_store.Session``; rewrite against the
psycopg3 fixture if the schema invariants need re-covering.
"""

import pytest

pytest.skip(
    "Superseded by P07 — SQLAlchemy AgentModel removed.",
    allow_module_level=True,
)

from okta_agent_proxy.audit.events import AuditEventType  # noqa: E402
from okta_agent_proxy.storage.models import AgentModel  # noqa: E402


class TestAgentModelDcrSelectable:
    """Verify dcr_selectable column and serialization."""

    def test_to_dict_includes_dcr_selectable_default(self, postgres_store, sample_agent_data):
        postgres_store.create_agent(sample_agent_data["agent_id"], sample_agent_data)
        agent = postgres_store.get_agent(sample_agent_data["agent_id"])
        assert "dcr_selectable" in agent
        assert agent["dcr_selectable"] is False

    def test_to_dict_dcr_selectable_true(self, postgres_store, sample_agent_data):
        postgres_store.create_agent(sample_agent_data["agent_id"], sample_agent_data)
        session = postgres_store.Session()
        try:
            model = session.query(AgentModel).filter_by(
                agent_name=sample_agent_data.get("agent_name", sample_agent_data["agent_id"])
            ).first()
            model.dcr_selectable = True
            session.commit()
        finally:
            session.close()
        agent = postgres_store.get_agent(sample_agent_data["agent_id"])
        assert agent["dcr_selectable"] is True


class TestDcrRegistrationModelLinkedAgent:
    """Verify linked_agent_name column and serialization."""

    def test_to_dict_includes_linked_agent_name(self, postgres_store):
        reg = postgres_store.create_dcr_registration(
            client_id="dcr-linked-test-1",
            client_name="Test DCR Client",
            redirect_uris=["http://localhost/callback"],
            grant_types=["authorization_code"],
            provision_mode="virtual",
        )
        assert "linked_agent_name" in reg
        assert reg["linked_agent_name"] is None

    def test_to_dict_linked_agent_name_set(self, postgres_store, sample_agent_data):
        agent_name = sample_agent_data.get("agent_name", sample_agent_data["agent_id"])
        postgres_store.create_agent(sample_agent_data["agent_id"], sample_agent_data)
        postgres_store.create_dcr_registration(
            client_id="dcr-linked-test-2",
            client_name="Test DCR Client",
            redirect_uris=["http://localhost/callback"],
            grant_types=["authorization_code"],
            provision_mode="virtual",
        )
        postgres_store.update_dcr_registration_linked_agent(
            "dcr-linked-test-2", agent_name
        )
        reg = postgres_store.get_dcr_registration("dcr-linked-test-2")
        assert reg["linked_agent_name"] == agent_name


class TestUpdateDcrRegistrationLinkedAgent:
    """Verify update_dcr_registration_linked_agent storage method."""

    def test_sets_linked_agent(self, postgres_store, sample_agent_data):
        agent_name = sample_agent_data.get("agent_name", sample_agent_data["agent_id"])
        postgres_store.create_agent(sample_agent_data["agent_id"], sample_agent_data)
        postgres_store.create_dcr_registration(
            client_id="dcr-set-link-test",
            client_name="Link Test",
            redirect_uris=["http://localhost/callback"],
            grant_types=["authorization_code"],
            provision_mode="virtual",
        )
        result = postgres_store.update_dcr_registration_linked_agent(
            "dcr-set-link-test", agent_name
        )
        assert result is True
        reg = postgres_store.get_dcr_registration("dcr-set-link-test")
        assert reg["linked_agent_name"] == agent_name

    def test_clears_linked_agent(self, postgres_store, sample_agent_data):
        agent_name = sample_agent_data.get("agent_name", sample_agent_data["agent_id"])
        postgres_store.create_agent(sample_agent_data["agent_id"], sample_agent_data)
        postgres_store.create_dcr_registration(
            client_id="dcr-clear-link-test",
            client_name="Clear Test",
            redirect_uris=["http://localhost/callback"],
            grant_types=["authorization_code"],
            provision_mode="virtual",
        )
        postgres_store.update_dcr_registration_linked_agent(
            "dcr-clear-link-test", agent_name
        )
        result = postgres_store.update_dcr_registration_linked_agent(
            "dcr-clear-link-test", None
        )
        assert result is True
        reg = postgres_store.get_dcr_registration("dcr-clear-link-test")
        assert reg["linked_agent_name"] is None

    def test_not_found_returns_false(self, postgres_store):
        result = postgres_store.update_dcr_registration_linked_agent(
            "nonexistent-client", "some-agent"
        )
        assert result is False


class TestNewAuditEventTypes:
    """Verify all new AuditEventType enum members exist."""

    @pytest.mark.parametrize(
        "member,value",
        [
            ("DCR_REGISTRATION_REJECTED", "dcr.registration.rejected"),
            ("DCR_AGENT_LINKED", "dcr.agent.linked"),
            ("DCR_AGENT_UNLINKED", "dcr.agent.unlinked"),
            ("DCR_AGENT_SELECTION_SHOWN", "dcr.agent.selection.shown"),
            ("DCR_AGENT_SELECTION_FAILED", "dcr.agent.selection.failed"),
            ("DCR_AUTHORIZE_RELAYED", "dcr.authorize.relayed"),
            ("DCR_AUTHORIZE_RELAY_FAILED", "dcr.authorize.relay.failed"),
            ("DCR_TOKEN_EXCHANGE_SUCCESS", "dcr.token.exchange.success"),
            ("DCR_TOKEN_EXCHANGE_FAILURE", "dcr.token.exchange.failure"),
        ],
    )
    def test_audit_event_type_exists(self, member, value):
        event_type = AuditEventType[member]
        assert event_type.value == value
