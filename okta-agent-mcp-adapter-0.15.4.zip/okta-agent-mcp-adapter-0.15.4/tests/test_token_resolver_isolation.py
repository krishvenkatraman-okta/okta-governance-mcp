"""
Tests for connection-scoped token exchange in ResourceTokenResolver.

Verifies that agent_id and connection_id are passed through to:
- Token cache get/set/invalidate calls
- Audit events
- Flow cache keys in OktaCrossAppAccessManager

Also verifies backward compatibility for resources without agent scoping.
"""

import pytest
from datetime import datetime, timedelta
from unittest.mock import AsyncMock, MagicMock, patch, call

from okta_agent_proxy.auth.resource_token_resolver import ResourceTokenResolver, ResourceAuthResult


# ============================================================================
# Helpers
# ============================================================================


def _make_resource_config(
    name="hr-system",
    auth_method="okta-cross-app",
    agent_id="agent-a",
    connection_id="conn-a1",
    resource_id="aus123",
    scopes=None,
):
    """Build a mock resource config that behaves like ResolvedResourceConfigAdapter."""
    config = MagicMock()
    config.name = name
    config.auth_method = auth_method
    config.agent_id = agent_id
    config.connection_id = connection_id
    config.resource_id = resource_id
    config.url = f"https://{name}.example.com/mcp"
    config.enabled = True
    config.scopes = scopes or []
    config.scope_condition = MagicMock()
    config.scope_condition.value = "ALLOW_ALL"
    config.metadata = {}
    config.config = {}

    # Make it look like ResolvedResourceConfigAdapter for isinstance checks
    config.__class__.__name__ = "ResolvedResourceConfigAdapter"
    auth_config_mock = MagicMock()
    auth_config_mock.model_dump.return_value = {"resource_id": resource_id}
    config.auth_config = auth_config_mock

    return config


def _make_local_config(name="legacy-api", auth_method="pre-shared-key"):
    """Build a mock resource config without agent_id (like plain BackendConfig)."""
    config = MagicMock()
    config.name = name
    config.auth_method = auth_method
    config.url = f"https://{name}.example.com"
    config.enabled = True
    # No agent_id or connection_id attributes
    del config.agent_id
    del config.connection_id
    auth_config_mock = MagicMock()
    auth_config_mock.model_dump.return_value = {"key": "secret-123", "header_name": "X-API-Key"}
    config.auth_config = auth_config_mock
    return config


# ============================================================================
# Cache isolation tests
# ============================================================================


class TestCacheLookupIsolation:

    @pytest.mark.asyncio
    async def test_cache_lookup_includes_agent_id(self):
        """Verify get() is called with agent_id and connection_id."""
        token_cache = MagicMock()
        token_cache.get.return_value = {
            "token": "cached-token-abc",
            "expires_at": datetime.now() + timedelta(hours=1),
        }
        resolver = ResourceTokenResolver(token_cache)

        resource_config = _make_resource_config(agent_id="agent-a", connection_id="conn-a1")

        # Mock to bypass actual exchange
        with patch("okta_agent_proxy.auth.resource_token_resolver.create_auth_handler") as mock_handler:
            mock_handler.return_value = AsyncMock()
            mock_handler.return_value.get_auth_headers = AsyncMock(return_value={"Authorization": "Bearer cached-token-abc"})

            result = await resolver.resolve_auth_headers(
                resource_name="hr-system",
                resource_config=resource_config,
                agent_config={"agent_id": "agent-a", "client_id": "0oa123", "private_key": "{}"},
                user_id="user-1",
                user_id_token="fake-token",
            )

        # Verify cache was called with isolation fields
        token_cache.get.assert_called_once_with(
            "user-1", "hr-system",
            agent_id="agent-a", connection_id="conn-a1",
        )
        assert result.ok

    @pytest.mark.asyncio
    async def test_cache_store_includes_agent_id(self):
        """Verify set() is called with agent_id and connection_id after exchange."""
        token_cache = MagicMock()
        token_cache.get.return_value = None  # Cache miss

        resolver = ResourceTokenResolver(token_cache)
        resource_config = _make_resource_config(agent_id="agent-a", connection_id="conn-a1")

        # Mock the cross-app exchange
        mock_exchange_result = {"access_token": "new-token-xyz", "expires_in": 3600}

        with patch("okta_agent_proxy.auth.resource_token_resolver.create_auth_handler") as mock_handler, \
             patch("okta_agent_proxy.auth.resource_token_resolver.ResourceTokenResolver._resolve_actual_id_token", return_value="id-token-123"), \
             patch("okta_agent_proxy.auth.cross_app_access.OktaCrossAppAccessManager") as MockManager, \
             patch("okta_agent_proxy.auth.resource_token_resolver.emit_audit_event", new_callable=AsyncMock), \
             patch.dict("os.environ", {"OKTA_DOMAIN": "dev-test.okta.com"}):

            mock_mgr_instance = MagicMock()
            mock_mgr_instance.exchange_id_token_to_mcp_token = AsyncMock(return_value=mock_exchange_result)
            MockManager.return_value = mock_mgr_instance

            mock_handler.return_value = AsyncMock()
            mock_handler.return_value.get_auth_headers = AsyncMock(return_value={"Authorization": "Bearer new-token-xyz"})

            result = await resolver.resolve_auth_headers(
                resource_name="hr-system",
                resource_config=resource_config,
                agent_config={"agent_id": "agent-a", "client_id": "0oa123", "private_key": "{}", "principal_id": "wlp123"},
                user_id="user-1",
                user_id_token="fake-token",
            )

        assert result.ok
        # Verify cache set was called with isolation fields
        token_cache.set.assert_called_once()
        set_call = token_cache.set.call_args
        assert set_call.kwargs.get("agent_id") == "agent-a"
        assert set_call.kwargs.get("connection_id") == "conn-a1"


class TestInvalidationIsolation:

    @pytest.mark.asyncio
    async def test_401_invalidation_scoped_to_agent(self):
        """Verify invalidate_resource_token passes agent_id and connection_id."""
        from okta_agent_proxy.cache.token_cache import TokenCache

        token_cache = TokenCache(max_size=100, ttl_seconds=3600)

        # Store tokens for two agents
        token_cache.set("user-1", "hr-system", "token-a", agent_id="agent-a", connection_id="conn-a1")
        token_cache.set("user-1", "hr-system", "token-b", agent_id="agent-b", connection_id="conn-b1")

        # Invalidate only agent-a
        token_cache.invalidate("user-1", "hr-system", agent_id="agent-a", connection_id="conn-a1")

        # agent-a should be gone, agent-b still present
        assert token_cache.get("user-1", "hr-system", agent_id="agent-a", connection_id="conn-a1") is None
        assert token_cache.get("user-1", "hr-system", agent_id="agent-b", connection_id="conn-b1") == "token-b"


class TestTwoAgentsExchangeIndependently:

    @pytest.mark.asyncio
    async def test_two_agents_get_separate_cache_entries(self):
        """Two agents exchanging for the same resource produce separate cache entries."""
        from okta_agent_proxy.cache.token_cache import TokenCache

        token_cache = TokenCache(max_size=100, ttl_seconds=3600)

        # Simulate two separate exchanges storing tokens
        token_data_a = {"token": "token-for-a", "expires_at": datetime.now() + timedelta(hours=1)}
        token_data_b = {"token": "token-for-b", "expires_at": datetime.now() + timedelta(hours=1)}

        token_cache.set("user-1", "hr-system", token_data_a, agent_id="agent-a", connection_id="conn-a")
        token_cache.set("user-1", "hr-system", token_data_b, agent_id="agent-b", connection_id="conn-b")

        # Each agent gets their own token
        cached_a = token_cache.get("user-1", "hr-system", agent_id="agent-a", connection_id="conn-a")
        cached_b = token_cache.get("user-1", "hr-system", agent_id="agent-b", connection_id="conn-b")

        assert cached_a == token_data_a
        assert cached_b == token_data_b
        assert cached_a != cached_b


class TestLocalResourceBackwardCompatibility:

    @pytest.mark.asyncio
    async def test_local_resource_no_agent_still_works(self):
        """Resource config without agent_id uses None, which falls back to legacy key."""
        token_cache = MagicMock()
        resolver = ResourceTokenResolver(token_cache)

        resource_config = _make_local_config(auth_method="pre-shared-key")

        with patch("okta_agent_proxy.auth.resource_token_resolver.create_auth_handler") as mock_handler:
            mock_handler.return_value = AsyncMock()
            mock_handler.return_value.get_auth_headers = AsyncMock(return_value={"X-API-Key": "secret-123"})

            result = await resolver.resolve_auth_headers(
                resource_name="legacy-api",
                resource_config=resource_config,
                agent_config={},
                user_id="user-1",
                user_id_token="fake-token",
            )

        assert result.ok
        # pre-shared-key doesn't hit the token cache at all (stateless)
        token_cache.get.assert_not_called()
        token_cache.set.assert_not_called()

    def test_extract_isolation_fields_with_adapter(self):
        """_extract_isolation_fields returns (agent_id, connection_id) from adapter."""
        config = _make_resource_config(agent_id="agent-x", connection_id="conn-y")
        agent_id, connection_id = ResourceTokenResolver._extract_isolation_fields(config)
        assert agent_id == "agent-x"
        assert connection_id == "conn-y"

    def test_extract_isolation_fields_without_adapter(self):
        """_extract_isolation_fields returns (None, None) for plain config."""
        config = _make_local_config()
        agent_id, connection_id = ResourceTokenResolver._extract_isolation_fields(config)
        assert agent_id is None
        assert connection_id is None


# ============================================================================
# Flow cache key tests
# ============================================================================


class TestFlowCacheKeyIsolation:

    def test_flow_cache_key_includes_agent(self):
        """Two managers for different agents produce different flow cache keys."""
        # We just verify the key format directly
        agent_a_key = f"{'agent-a' or 'default'}:hr-system:aus123"
        agent_b_key = f"{'agent-b' or 'default'}:hr-system:aus123"
        assert agent_a_key != agent_b_key
        assert agent_a_key == "agent-a:hr-system:aus123"
        assert agent_b_key == "agent-b:hr-system:aus123"

    def test_flow_cache_key_default_when_no_agent(self):
        """Agent ID of None uses 'default' in cache key."""
        agent_id = None
        cache_key = f"{agent_id or 'default'}:hr-system:aus123"
        assert cache_key == "default:hr-system:aus123"
