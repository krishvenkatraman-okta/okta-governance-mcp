"""
Tests for the Confidential Relay.

Tests:
- Full happy path: start_authorization -> handle_callback -> exchange_code
- Expired session -> RelaySessionExpired
- Client ID mismatch on code exchange -> RelayClientMismatch
- Replay (code used twice) -> error
- Invalid redirect_uri (not in CIMD metadata) -> error
- PKCE passthrough: code_challenge appears in Okta authorization URL
- CacheService (L2) cross-instance state sharing
"""

import json
import os
import pytest
from datetime import datetime, timezone, timedelta
from urllib.parse import urlparse, parse_qs

import httpx

from okta_agent_proxy.auth.cimd_fetcher import CIMDMetadata
from okta_agent_proxy.auth.confidential_relay import (
    ConfidentialRelay,
    RelayError,
    RelaySessionExpired,
    RelayClientMismatch,
    _RELAY_STATE_PREFIX,
    _PRECONSENT_STATE_PREFIX,
)
from okta_agent_proxy.cache.cache_service import CacheService
from okta_agent_proxy.cache.memory_provider import MemoryCacheProvider


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

CLIENT_ID_URL = "https://myapp.example.com/oauth.json"
REDIRECT_URI = "http://localhost:8080/callback"


def _metadata(client_id=CLIENT_ID_URL, redirect_uris=None):
    return CIMDMetadata(
        client_id=client_id,
        client_name="Test App",
        redirect_uris=redirect_uris or [REDIRECT_URI],
        grant_types=["authorization_code"],
        response_types=["code"],
        token_endpoint_auth_method="none",
        jwks_uri=None,
        logo_uri=None,
        client_uri=None,
        scope=None,
        domain=urlparse(client_id).hostname or "",
        fetched_at=datetime.now(timezone.utc),
        raw_json={},
    )


def _token_response_transport(
    access_token="at_test123",
    id_token="idt_test123",
    refresh_token="rt_test123",
    expires_in=3600,
    status_code=200,
):
    """Mock transport that returns a token response from Okta."""
    body = {
        "access_token": access_token,
        "id_token": id_token,
        "refresh_token": refresh_token,
        "token_type": "Bearer",
        "expires_in": expires_in,
    }

    def handler(request: httpx.Request) -> httpx.Response:
        return httpx.Response(
            status_code=status_code,
            content=json.dumps(body).encode(),
            headers={"content-type": "application/json"},
        )

    return httpx.MockTransport(handler)


TEST_RELAY_CLIENT_ID = "relay_client_id"
TEST_RELAY_CLIENT_SECRET = "relay_secret"


def _relay(**kwargs):
    """Create a ConfidentialRelay with test defaults."""
    defaults = dict(
        gateway_base_url="http://localhost:8000",
        okta_domain="dev-test.okta.com",
        okta_auth_server_id="default",
        transport=_token_response_transport(),
    )
    defaults.update(kwargs)
    return ConfidentialRelay(**defaults)


AUTH_PARAMS = {
    "redirect_uri": REDIRECT_URI,
    "state": "client_state_abc",
    "scope": "openid offline_access",
}


async def _start_auth(relay, metadata=None, auth_params=None, **kwargs):
    """Helper to call start_authorization with test credentials."""
    call_kwargs = {
        "relay_client_id": kwargs.get("relay_client_id", TEST_RELAY_CLIENT_ID),
        "relay_client_secret": kwargs.get("relay_client_secret", TEST_RELAY_CLIENT_SECRET),
    }
    if "custom_scopes" in kwargs:
        call_kwargs["custom_scopes"] = kwargs["custom_scopes"]
    return await relay.start_authorization(
        metadata or _metadata(),
        auth_params or AUTH_PARAMS,
        **call_kwargs,
    )


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------


class TestConfidentialRelayAuthorization:
    async def test_start_authorization_returns_okta_url(self):
        relay = _relay()
        url = await _start_auth(relay)

        parsed = urlparse(url)
        params = parse_qs(parsed.query)

        assert parsed.scheme == "https"
        assert parsed.hostname == "dev-test.okta.com"
        assert "/v1/authorize" in parsed.path
        assert params["client_id"] == ["relay_client_id"]
        assert params["redirect_uri"] == ["http://localhost:8000/oauth/callback"]
        assert params["response_type"] == ["code"]
        assert params["scope"] == ["openid offline_access"]
        # state should be the relay_state, not the client's state
        assert params["state"][0] != "client_state_abc"

    async def test_invalid_redirect_uri(self):
        relay = _relay()
        bad_params = {**AUTH_PARAMS, "redirect_uri": "https://evil.com/steal"}
        with pytest.raises(RelayError, match="not in the client's registered redirect_uris"):
            await _start_auth(relay, auth_params=bad_params)

    async def test_pkce_relay_generates_own(self):
        """Relay always generates its own PKCE for the Okta leg."""
        relay = _relay()
        params_with_pkce = {
            **AUTH_PARAMS,
            "code_challenge": "E9Melhoa2OwvFrEMTJguCHaoeK1t8URWbuGJSstw-cM",
            "code_challenge_method": "S256",
            "code_verifier": "dBjftJeZ4CVP-mB92K27uhbUJU1p1r_wW1gFWFOEjXk",
        }
        url = await _start_auth(relay, auth_params=params_with_pkce)

        parsed = urlparse(url)
        params = parse_qs(parsed.query)

        # Relay generates its own PKCE — client's challenge is NOT forwarded
        assert params["code_challenge_method"] == ["S256"]
        assert "code_challenge" in params
        assert params["code_challenge"] != ["E9Melhoa2OwvFrEMTJguCHaoeK1t8URWbuGJSstw-cM"]
        # code_verifier should NOT be in the URL
        assert "code_verifier" not in params


class TestConfidentialRelayCallback:
    async def test_handle_callback_exchanges_code(self):
        """Callback exchanges auth code at Okta and returns redirect URL."""
        relay = _relay()
        okta_url = await _start_auth(relay)

        # Extract relay_state from the Okta URL
        relay_state = parse_qs(urlparse(okta_url).query)["state"][0]

        redirect_url, gateway_code, original_client_id = await relay.handle_callback(
            relay_state, "okta_auth_code_123"
        )

        assert original_client_id == CLIENT_ID_URL
        assert len(gateway_code) == 64  # hex(32) = 64 chars
        assert redirect_url.startswith(REDIRECT_URI)
        parsed = parse_qs(urlparse(redirect_url).query)
        assert parsed["code"] == [gateway_code]
        assert parsed["state"] == ["client_state_abc"]

    async def test_callback_unknown_state(self):
        relay = _relay()
        with pytest.raises(RelayError, match="No relay session"):
            await relay.handle_callback("nonexistent_state", "code")

    async def test_callback_expired_session(self):
        relay = _relay()
        okta_url = await _start_auth(relay)
        relay_state = parse_qs(urlparse(okta_url).query)["state"][0]

        # Expire the session
        session = relay._sessions_by_state[relay_state]
        session.created_at = datetime.now(timezone.utc) - timedelta(seconds=600)

        with pytest.raises(RelaySessionExpired, match="expired"):
            await relay.handle_callback(relay_state, "code")

    async def test_callback_sends_basic_auth_header(self):
        """Verify that the token exchange uses Authorization: Basic (not httpx auth=)."""
        captured_requests = []

        def capturing_handler(request: httpx.Request) -> httpx.Response:
            captured_requests.append(request)
            return httpx.Response(
                200,
                content=json.dumps({
                    "access_token": "at", "id_token": "idt",
                    "token_type": "Bearer", "expires_in": 3600,
                }).encode(),
                headers={"content-type": "application/json"},
            )

        relay = _relay(transport=httpx.MockTransport(capturing_handler))
        okta_url = await _start_auth(relay)
        relay_state = parse_qs(urlparse(okta_url).query)["state"][0]

        await relay.handle_callback(relay_state, "code123")

        assert len(captured_requests) == 1
        auth_header = captured_requests[0].headers.get("authorization")
        assert auth_header is not None
        assert auth_header.startswith("Basic ")

    async def test_callback_token_exchange_failure(self):
        relay = _relay(transport=_token_response_transport(status_code=401))
        okta_url = await _start_auth(relay)
        relay_state = parse_qs(urlparse(okta_url).query)["state"][0]

        with pytest.raises(RelayError, match="Token exchange failed"):
            await relay.handle_callback(relay_state, "bad_code")


class TestConfidentialRelayCodeExchange:
    async def _setup_complete_flow(self, relay=None):
        """Run through start → callback and return (relay, gateway_code)."""
        if relay is None:
            relay = _relay()
        okta_url = await _start_auth(relay)
        relay_state = parse_qs(urlparse(okta_url).query)["state"][0]
        _, gateway_code, _ = await relay.handle_callback(relay_state, "okta_code")
        return relay, gateway_code

    async def test_full_happy_path(self):
        """start_authorization → handle_callback → exchange_code → tokens."""
        relay, gateway_code = await self._setup_complete_flow()

        tokens = await relay.exchange_code(gateway_code, CLIENT_ID_URL)

        assert tokens["access_token"] == "at_test123"
        assert tokens["id_token"] == "idt_test123"
        assert tokens["refresh_token"] == "rt_test123"
        assert tokens["token_type"] == "Bearer"
        assert tokens["expires_in"] == 3600

    async def test_code_replay_rejected(self):
        """Using the same code twice fails."""
        relay, gateway_code = await self._setup_complete_flow()

        # First exchange succeeds
        await relay.exchange_code(gateway_code, CLIENT_ID_URL)

        # Second exchange fails
        with pytest.raises(RelayError, match="No session found"):
            await relay.exchange_code(gateway_code, CLIENT_ID_URL)

    async def test_client_id_mismatch(self):
        relay, gateway_code = await self._setup_complete_flow()

        with pytest.raises(RelayClientMismatch, match="client_id mismatch"):
            await relay.exchange_code(gateway_code, "https://wrong.com/oauth.json")

    async def test_expired_session_on_exchange(self):
        relay, gateway_code = await self._setup_complete_flow()

        # Expire the session
        session = relay._sessions_by_code[gateway_code]
        session.created_at = datetime.now(timezone.utc) - timedelta(seconds=600)

        with pytest.raises(RelaySessionExpired, match="expired"):
            await relay.exchange_code(gateway_code, CLIENT_ID_URL)

    async def test_unknown_code(self):
        relay = _relay()
        with pytest.raises(RelayError, match="No session found"):
            await relay.exchange_code("nonexistent_code", CLIENT_ID_URL)

    async def test_relay_pkce_verifier_sent_to_okta(self):
        """Relay's own code_verifier is sent to Okta token exchange."""
        captured_requests = []

        def capturing_handler(request: httpx.Request) -> httpx.Response:
            captured_requests.append(request)
            return httpx.Response(
                200,
                content=json.dumps({
                    "access_token": "at", "id_token": "idt",
                    "token_type": "Bearer", "expires_in": 3600,
                }).encode(),
                headers={"content-type": "application/json"},
            )

        relay = _relay(transport=httpx.MockTransport(capturing_handler))
        okta_url = await _start_auth(relay)
        relay_state = parse_qs(urlparse(okta_url).query)["state"][0]
        await relay.handle_callback(relay_state, "okta_code")

        assert len(captured_requests) == 1
        body = captured_requests[0].content.decode()
        # Relay generates its own verifier — it should be present
        assert "code_verifier=" in body
        # And it should NOT be the client's verifier
        assert "code_verifier=verifier123" not in body


class TestTargetResource:
    """Tests for RFC 8707 target_resource plumbing through RelaySession."""

    async def test_session_stores_target_resource(self):
        relay = _relay()
        params = {**AUTH_PARAMS, "resource": "https://gateway.example.com/hr"}
        okta_url = await _start_auth(relay, auth_params=params)

        relay_state = parse_qs(urlparse(okta_url).query)["state"][0]
        session = relay._sessions_by_state[relay_state]
        assert session.target_resource == "https://gateway.example.com/hr"

    async def test_session_target_resource_none_when_omitted(self):
        relay = _relay()
        okta_url = await _start_auth(relay)

        relay_state = parse_qs(urlparse(okta_url).query)["state"][0]
        session = relay._sessions_by_state[relay_state]
        assert session.target_resource is None

    async def test_session_target_resource_none_for_empty_string(self):
        relay = _relay()
        params = {**AUTH_PARAMS, "resource": ""}
        okta_url = await _start_auth(relay, auth_params=params)

        relay_state = parse_qs(urlparse(okta_url).query)["state"][0]
        session = relay._sessions_by_state[relay_state]
        assert session.target_resource is None

    async def test_callback_tokens_only_returns_target_resource(self):
        relay = _relay()
        params = {**AUTH_PARAMS, "resource": "https://gateway.example.com/hr"}
        okta_url = await _start_auth(relay, auth_params=params)

        relay_state = parse_qs(urlparse(okta_url).query)["state"][0]
        result = await relay.handle_callback_tokens_only(relay_state, "okta_code")

        assert result["target_resource"] == "https://gateway.example.com/hr"

    async def test_callback_tokens_only_target_resource_none_when_omitted(self):
        relay = _relay()
        okta_url = await _start_auth(relay)

        relay_state = parse_qs(urlparse(okta_url).query)["state"][0]
        result = await relay.handle_callback_tokens_only(relay_state, "okta_code")

        assert result["target_resource"] is None


class TestCustomScopes:
    """Custom scopes stashed at /oauth/authorize must round-trip through the
    relay session and be recoverable at proxy time via lookup_token, so the
    ID-JAG Leg 1 exchange can replay them to the target authorization server.
    """

    async def test_session_stores_custom_scopes(self):
        relay = _relay()
        okta_url = await _start_auth(
            relay, custom_scopes=["bedrock:InvokeAgent", "repo:read"]
        )

        relay_state = parse_qs(urlparse(okta_url).query)["state"][0]
        session = relay._sessions_by_state[relay_state]
        assert session.custom_scopes == ["bedrock:InvokeAgent", "repo:read"]

    async def test_session_custom_scopes_default_empty(self):
        relay = _relay()
        okta_url = await _start_auth(relay)

        relay_state = parse_qs(urlparse(okta_url).query)["state"][0]
        session = relay._sessions_by_state[relay_state]
        assert session.custom_scopes == []

    async def test_custom_scopes_not_forwarded_to_okta(self):
        """The Okta authorization URL must carry ONLY OIDC scopes. Custom
        scopes live on the RelaySession, never on the wire to the org AS."""
        relay = _relay()
        okta_url = await _start_auth(
            relay, custom_scopes=["bedrock:InvokeAgent"]
        )

        qs = parse_qs(urlparse(okta_url).query)
        forwarded_scope = qs.get("scope", [""])[0]
        assert "bedrock:InvokeAgent" not in forwarded_scope
        # OIDC scopes from AUTH_PARAMS are preserved
        assert "openid" in forwarded_scope

    async def test_callback_tokens_only_surfaces_custom_scopes(self):
        relay = _relay()
        okta_url = await _start_auth(
            relay, custom_scopes=["bedrock:InvokeAgent"]
        )

        relay_state = parse_qs(urlparse(okta_url).query)["state"][0]
        result = await relay.handle_callback_tokens_only(relay_state, "okta_code")

        assert result["custom_scopes"] == ["bedrock:InvokeAgent"]

    async def test_callback_custom_scopes_empty_when_not_stashed(self):
        relay = _relay()
        okta_url = await _start_auth(relay)

        relay_state = parse_qs(urlparse(okta_url).query)["state"][0]
        result = await relay.handle_callback_tokens_only(relay_state, "okta_code")

        assert result["custom_scopes"] == []

    async def test_lookup_token_returns_custom_scopes(self):
        """Full flow: stash at start_authorization → issue gateway code in
        extra={} → atrack_token → lookup_token surfaces custom_scopes."""
        relay = _relay()
        okta_url = await _start_auth(
            relay, custom_scopes=["bedrock:InvokeAgent"]
        )
        relay_state = parse_qs(urlparse(okta_url).query)["state"][0]

        # Simulate oauth_callback binding scopes to the access token via
        # GatewayCodeManager.extra (mirrors app.py::oauth_callback fast path).
        callback = await relay.handle_callback_tokens_only(relay_state, "okta_code")
        await relay._code_manager.atrack_token(
            callback["access_token"],
            callback["original_client_id"],
            id_token=callback["id_token"],
            refresh_token=callback.get("refresh_token"),
            expires_in=callback.get("expires_in"),
            relay_client_id=callback.get("relay_client_id", ""),
            relay_client_secret=callback.get("relay_client_secret", ""),
            custom_scopes=callback.get("custom_scopes") or [],
        )

        info = await relay.alookup_token(callback["access_token"])
        assert info is not None
        assert info["custom_scopes"] == ["bedrock:InvokeAgent"]

    async def test_lookup_token_no_custom_scopes_returns_empty_list(self):
        relay = _relay()
        okta_url = await _start_auth(relay)
        relay_state = parse_qs(urlparse(okta_url).query)["state"][0]
        callback = await relay.handle_callback_tokens_only(relay_state, "okta_code")
        await relay._code_manager.atrack_token(
            callback["access_token"],
            callback["original_client_id"],
            id_token=callback["id_token"],
        )

        info = await relay.alookup_token(callback["access_token"])
        assert info is not None
        assert info["custom_scopes"] == []


# ---------------------------------------------------------------------------
# CacheService (L2) cross-instance tests
# ---------------------------------------------------------------------------

def _shared_cache_service():
    provider = MemoryCacheProvider(max_size=1000, default_ttl=3600)
    return CacheService(l2_provider=provider), provider


class TestConfidentialRelayCacheService:
    @pytest.mark.asyncio
    async def test_relay_state_visible_cross_instance(self):
        """Relay session stored on instance A is loadable on instance B."""
        svc, _ = _shared_cache_service()
        relay_a = _relay(cache_service=svc)
        relay_b = _relay(cache_service=svc)

        okta_url = await _start_auth(relay_a)
        relay_state = parse_qs(urlparse(okta_url).query)["state"][0]

        # Clear B's L1 to prove L2 read
        relay_b._sessions_by_state.clear()

        session = await relay_b._load_relay_state(relay_state)
        assert session is not None
        assert session.original_client_id == CLIENT_ID_URL
        assert session.relay_client_id == TEST_RELAY_CLIENT_ID

    @pytest.mark.asyncio
    async def test_preconsent_state_visible_cross_instance(self):
        """Pre-consent session on A is visible on B."""
        svc, _ = _shared_cache_service()
        relay_a = _relay(cache_service=svc)
        relay_b = _relay(cache_service=svc)

        okta_url = await relay_a.start_preconsent_authorization(
            agent_id="agent-1",
            relay_client_id="rc_001",
            relay_client_secret="rs_001",
            scopes="openid profile",
        )
        relay_state = parse_qs(urlparse(okta_url).query)["state"][0]

        # Clear B's L1
        relay_b._preconsent_sessions_by_state.clear()

        session = await relay_b._load_preconsent_state(relay_state)
        assert session is not None
        assert session.agent_id == "agent-1"

    @pytest.mark.asyncio
    async def test_ais_preconsent_state_checks_l2(self):
        """ais_preconsent_state checks L2 when L1 miss."""
        svc, _ = _shared_cache_service()
        relay_a = _relay(cache_service=svc)
        relay_b = _relay(cache_service=svc)

        okta_url = await relay_a.start_preconsent_authorization(
            agent_id="agent-2",
            relay_client_id="rc_002",
            relay_client_secret="rs_002",
            scopes="openid",
        )
        relay_state = parse_qs(urlparse(okta_url).query)["state"][0]

        # B's L1 is empty
        relay_b._preconsent_sessions_by_state.clear()
        assert await relay_b.ais_preconsent_state(relay_state) is True
        assert await relay_b.ais_preconsent_state("nonexistent") is False

    @pytest.mark.asyncio
    async def test_relay_client_secret_encrypted_at_rest(self):
        """With encryption, relay_client_secret is not in raw L2 bytes."""
        from okta_agent_proxy.crypto.encryption import EncryptionService
        enc = EncryptionService(os.urandom(32))
        provider = MemoryCacheProvider(max_size=100, default_ttl=3600)
        svc = CacheService(l2_provider=provider)
        relay = _relay(cache_service=svc, encryption_service=enc)

        okta_url = await _start_auth(relay)
        relay_state = parse_qs(urlparse(okta_url).query)["state"][0]

        # Check raw L2
        raw = await provider.get(f"{_RELAY_STATE_PREFIX}{relay_state}")
        assert raw is not None
        assert TEST_RELAY_CLIENT_SECRET not in raw

        # But load still works
        session = await relay._load_relay_state(relay_state)
        assert session.relay_client_secret == TEST_RELAY_CLIENT_SECRET

    @pytest.mark.asyncio
    async def test_callback_consumable_on_other_instance(self):
        """OAuth state on A is consumable on B after simulated callback."""
        svc, _ = _shared_cache_service()
        relay_a = _relay(cache_service=svc)
        relay_b = _relay(cache_service=svc)

        okta_url = await _start_auth(relay_a)
        relay_state = parse_qs(urlparse(okta_url).query)["state"][0]

        # Clear B's L1 to force L2 read
        relay_b._sessions_by_state.clear()

        # B handles the callback
        redirect_url, gateway_code, client_id = await relay_b.handle_callback(
            relay_state, "okta_code"
        )
        assert client_id == CLIENT_ID_URL
        assert len(gateway_code) == 64

        # State should be cleaned up in L2.
        # Clear A's L1 to simulate separate pod — L2 was deleted by B's callback.
        relay_a._sessions_by_state.clear()
        assert await relay_a._load_relay_state(relay_state) is None
