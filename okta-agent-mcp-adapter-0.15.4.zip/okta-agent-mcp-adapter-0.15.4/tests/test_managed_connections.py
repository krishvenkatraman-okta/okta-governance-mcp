"""
Tests for the deprecated ManagedConnectionsSync stub.

Validates that the stub module exists for backward compatibility
and that all methods return no-op/empty results.

The real managed connections functionality is now provided by
okta_agent_proxy.resource_map.syncer.OktaConnectionSyncer
(tested in test_okta_syncer.py).
"""

import warnings
import pytest

from okta_agent_proxy.auth.managed_connections import (
    ManagedConnectionsSync,
    ManagedConnectionsSyncResult,
)


class TestDeprecationWarning:
    """ManagedConnectionsSync emits a deprecation warning."""

    def test_constructor_warns(self):
        with warnings.catch_warnings(record=True) as w:
            warnings.simplefilter("always")
            ManagedConnectionsSync()
            assert len(w) >= 1
            assert issubclass(w[0].category, DeprecationWarning)
            assert "deprecated" in str(w[0].message).lower()


class TestSyncReturnsEmpty:
    """sync() returns an empty ManagedConnectionsSyncResult."""

    @pytest.mark.asyncio
    async def test_sync_returns_empty_result(self):
        with warnings.catch_warnings():
            warnings.simplefilter("ignore", DeprecationWarning)
            syncer = ManagedConnectionsSync()
        result = await syncer.sync()
        assert isinstance(result, ManagedConnectionsSyncResult)
        assert result.authorization_servers == []
        assert result.secrets == []
        assert result.service_accounts == []
        assert result.synced_at is not None


class TestGetManagedScopes:
    """get_managed_scopes always returns None."""

    def test_returns_none(self):
        with warnings.catch_warnings():
            warnings.simplefilter("ignore", DeprecationWarning)
            syncer = ManagedConnectionsSync()
        assert syncer.get_managed_scopes("any-resource") is None

    def test_returns_none_for_unknown(self):
        with warnings.catch_warnings():
            warnings.simplefilter("ignore", DeprecationWarning)
            syncer = ManagedConnectionsSync()
        assert syncer.get_managed_scopes("unknown") is None


class TestManagedConnectionsSyncResult:
    """Result container still works."""

    def test_default_values(self):
        result = ManagedConnectionsSyncResult()
        assert result.authorization_servers == []
        assert result.secrets == []
        assert result.service_accounts == []
        assert result.synced_at is not None
