"""
Tests for the Client Registry.

Tests:
- Pre-registered agent: returns ClientInfo with source="manual"
- CIMD URL: fetches, validates, returns ClientInfo with source="cimd"
- CIMD URL blocked by policy: returns None
- Unknown client_id (not URL, not in DB): returns None
- Resolution order: pre-registered takes priority over CIMD URL match
"""

import pytest
from datetime import datetime, timezone
from unittest.mock import MagicMock, AsyncMock, patch

from okta_agent_proxy.auth.client_registry import ClientRegistry, ClientInfo
from okta_agent_proxy.auth.cimd_fetcher import CIMDFetcher, CIMDMetadata, CIMDFetchError
from okta_agent_proxy.auth.cimd_policy import CIMDTrustPolicy, CIMDTrustResult, TrustLevel


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

CIMD_URL = "https://myapp.example.com/oauth.json"

SAMPLE_AGENT = {
    "agent_id": "agent-1",
    "agent_name": "claude-code",
    "client_id": "0oa_preregistered",
    "enabled": True,
    "resource_access": ["hr-system"],
}


def _metadata(client_id=CIMD_URL):
    from urllib.parse import urlparse
    parsed = urlparse(client_id)
    return CIMDMetadata(
        client_id=client_id,
        client_name="CIMD App",
        redirect_uris=["http://localhost:8080/callback"],
        grant_types=["authorization_code"],
        response_types=["code"],
        token_endpoint_auth_method="none",
        jwks_uri=None,
        logo_uri=None,
        client_uri=None,
        scope="openid",
        domain=parsed.hostname or "",
        fetched_at=datetime.now(timezone.utc),
        raw_json={},
    )


def _mock_store(agents=None):
    store = MagicMock()
    store.get_all_agents.return_value = agents or []
    # Default: no CIMD URL match
    store.get_agent_by_cimd_client_id.return_value = None
    # Simulate no DCR support (AttributeError)
    del store.get_dcr_registration
    return store


def _mock_fetcher(metadata=None, error=None):
    fetcher = MagicMock(spec=CIMDFetcher)
    if error:
        fetcher.fetch_and_validate = AsyncMock(side_effect=error)
    else:
        fetcher.fetch_and_validate = AsyncMock(return_value=metadata or _metadata())
    return fetcher


def _mock_policy(allowed=True, trust_level=TrustLevel.TRUSTED, resource_access=None,
                  auto_provision=False):
    policy = MagicMock(spec=CIMDTrustPolicy)
    result = CIMDTrustResult(
        allowed=allowed,
        trust_level=trust_level,
        domain="myapp.example.com",
        reason="test",
        redirect_uris_valid=True,
        resource_access=resource_access or [],
    )
    policy.evaluate = AsyncMock(return_value=result)
    policy.auto_provision_agent = auto_provision
    return policy


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------


class TestClientRegistry:
    async def test_preregistered_agent(self):
        """Pre-registered agent returns ClientInfo with source='manual'."""
        store = _mock_store(agents=[SAMPLE_AGENT])
        fetcher = _mock_fetcher()
        policy = _mock_policy()
        registry = ClientRegistry(store, fetcher, policy)

        result = await registry.resolve("0oa_preregistered")

        assert result is not None
        assert result.client_id == "0oa_preregistered"
        assert result.registration_source == "manual"
        assert result.agent_config == SAMPLE_AGENT
        assert result.client_name == "claude-code"
        # Fetcher should NOT have been called
        fetcher.fetch_and_validate.assert_not_called()

    async def test_cimd_url_resolves(self):
        """CIMD URL fetches, validates, and returns ClientInfo with source='cimd'."""
        store = _mock_store()
        fetcher = _mock_fetcher()
        policy = _mock_policy(allowed=True, trust_level=TrustLevel.TRUSTED)
        registry = ClientRegistry(store, fetcher, policy)

        result = await registry.resolve(CIMD_URL)

        assert result is not None
        assert result.client_id == CIMD_URL
        assert result.registration_source == "cimd"
        assert result.client_name == "CIMD App"
        assert result.trust_level == "trusted"
        assert result.cimd_metadata is not None
        fetcher.fetch_and_validate.assert_called_once_with(CIMD_URL)

    async def test_cimd_url_unknown_trust(self):
        """CIMD URL with unknown trust level still resolves."""
        store = _mock_store()
        fetcher = _mock_fetcher()
        policy = _mock_policy(allowed=True, trust_level=TrustLevel.UNKNOWN)
        registry = ClientRegistry(store, fetcher, policy)

        result = await registry.resolve(CIMD_URL)

        assert result is not None
        assert result.trust_level == "unknown"

    async def test_cimd_url_blocked_by_policy(self):
        """CIMD URL blocked by trust policy returns None."""
        store = _mock_store()
        fetcher = _mock_fetcher()
        policy = _mock_policy(allowed=False, trust_level=TrustLevel.BLOCKED)
        registry = ClientRegistry(store, fetcher, policy)

        result = await registry.resolve(CIMD_URL)

        assert result is None

    async def test_cimd_fetch_failure(self):
        """CIMD fetch failure returns None."""
        store = _mock_store()
        fetcher = _mock_fetcher(error=CIMDFetchError("timeout"))
        policy = _mock_policy()
        registry = ClientRegistry(store, fetcher, policy)

        result = await registry.resolve(CIMD_URL)

        assert result is None

    async def test_unknown_client_id(self):
        """Unknown client_id (not URL, not in DB) returns None."""
        store = _mock_store()
        fetcher = _mock_fetcher()
        policy = _mock_policy()
        registry = ClientRegistry(store, fetcher, policy)

        result = await registry.resolve("unknown_client_id_xyz")

        assert result is None
        # Not a URL → fetcher should not be called
        fetcher.fetch_and_validate.assert_not_called()

    async def test_preregistered_takes_priority_over_cimd(self):
        """Pre-registered agent matched by cimd_client_id_url takes priority over auto-provision."""
        # Agent pre-registered with cimd_client_id_url matching the CIMD URL
        url_agent = {**SAMPLE_AGENT, "cimd_client_id_url": CIMD_URL}
        store = _mock_store()
        store.get_agent_by_cimd_client_id.return_value = url_agent
        fetcher = _mock_fetcher()
        policy = _mock_policy()
        registry = ClientRegistry(store, fetcher, policy)

        result = await registry.resolve(CIMD_URL)

        assert result is not None
        assert result.registration_source == "cimd-matched"
        assert result.agent_config == url_agent
        # Fetcher should NOT be called — CIMD URL match resolution won
        fetcher.fetch_and_validate.assert_not_called()

    async def test_disabled_agent_skipped(self):
        """Disabled agents are not returned by the store (enabled_only=True)."""
        # Store returns empty (disabled agents filtered out)
        store = _mock_store(agents=[])
        fetcher = _mock_fetcher()
        policy = _mock_policy()
        registry = ClientRegistry(store, fetcher, policy)

        result = await registry.resolve("0oa_preregistered")

        assert result is None

    async def test_dcr_gracefully_skipped(self):
        """DCR lookup is skipped when store doesn't have get_dcr_registration."""
        store = _mock_store()
        fetcher = _mock_fetcher(error=CIMDFetchError("not found"))
        policy = _mock_policy()
        registry = ClientRegistry(store, fetcher, policy)

        # Non-URL client_id, no agent match, no DCR → None
        result = await registry.resolve("some_opaque_id")
        assert result is None

    async def test_localhost_http_is_cimd_url(self):
        """http://localhost URLs are treated as CIMD URLs."""
        url = "http://localhost:3000/oauth.json"
        store = _mock_store()
        metadata = _metadata(client_id=url)
        fetcher = _mock_fetcher(metadata=metadata)
        policy = _mock_policy()
        registry = ClientRegistry(store, fetcher, policy)

        result = await registry.resolve(url)

        assert result is not None
        assert result.registration_source == "cimd"
        fetcher.fetch_and_validate.assert_called_once_with(url)

    async def test_cimd_metadata_fields_mapped(self):
        """CIMD metadata fields are correctly mapped to ClientInfo."""
        store = _mock_store()
        metadata = _metadata()
        fetcher = _mock_fetcher(metadata=metadata)
        policy = _mock_policy()
        registry = ClientRegistry(store, fetcher, policy)

        result = await registry.resolve(CIMD_URL)

        assert result.redirect_uris == ["http://localhost:8080/callback"]
        assert result.grant_types == ["authorization_code"]
        assert result.response_types == ["code"]
        assert result.token_endpoint_auth_method == "none"
        assert result.scope == "openid"
        assert result.jwks_uri is None


class TestCIMDAutoProvision:
    """Tests for CIMD agent auto-provisioning."""

    async def test_cimd_auto_provision_creates_agent(self):
        """Auto-provision creates a persistent agent record."""
        store = _mock_store()
        store.create_cimd_agent = MagicMock(return_value=True)
        agent_record = {
            "agent_id": "cimd-app-abc12345",
            "agent_name": "cimd-app-abc12345",
            "client_id": CIMD_URL,
            "resource_access": ["hr-system", "finance-system"],
            "enabled": True,
        }
        store.get_agent_by_client_id = MagicMock(return_value=agent_record)

        fetcher = _mock_fetcher()
        policy = _mock_policy(
            allowed=True,
            trust_level=TrustLevel.TRUSTED,
            resource_access=["hr-system", "finance-system"],
            auto_provision=True,
        )
        registry = ClientRegistry(store, fetcher, policy)

        result = await registry.resolve(CIMD_URL)

        assert result is not None
        store.create_cimd_agent.assert_called_once_with(
            cimd_client_id=CIMD_URL,
            client_name="CIMD App",
            domain="myapp.example.com",
            trust_level="TRUSTED",
        )
        assert result.agent_config is not None
        assert result.agent_config["client_id"] == CIMD_URL
        assert result.resource_access == ["hr-system", "finance-system"]

    async def test_cimd_auto_provision_disabled(self):
        """When auto-provision is disabled, no agent record is created."""
        store = _mock_store()
        store.create_cimd_agent = MagicMock()
        store.get_agent_by_client_id = MagicMock()

        fetcher = _mock_fetcher()
        policy = _mock_policy(
            allowed=True,
            trust_level=TrustLevel.TRUSTED,
            resource_access=["hr-system"],
            auto_provision=False,
        )
        registry = ClientRegistry(store, fetcher, policy)

        result = await registry.resolve(CIMD_URL)

        assert result is not None
        store.create_cimd_agent.assert_not_called()
        store.get_agent_by_client_id.assert_not_called()
        assert result.agent_config is None
        assert result.resource_access == ["hr-system"]

    async def test_cimd_auto_provisioned_second_resolution(self):
        """Second resolution finds the existing agent via get_agent_by_cimd_client_id."""
        agent_record = {
            "agent_id": "cimd-app-abc12345",
            "agent_name": "cimd-app-abc12345",
            "client_id": CIMD_URL,
            "cimd_client_id_url": CIMD_URL,
            "resource_access": ["hr-system"],
            "enabled": True,
        }
        # Auto-provisioned agent is found via cimd_client_id_url lookup (step 2)
        store = _mock_store()
        store.get_agent_by_cimd_client_id.return_value = agent_record

        fetcher = _mock_fetcher()
        policy = _mock_policy(auto_provision=True, resource_access=["hr-system"])
        registry = ClientRegistry(store, fetcher, policy)

        result = await registry.resolve(CIMD_URL)

        # Should be resolved via cimd-matched (step 2) since it's already in DB
        assert result is not None
        assert result.registration_source == "cimd-matched"
        assert result.agent_config is not None
        assert result.agent_config["client_id"] == CIMD_URL

    async def test_admin_overrides_resource_access(self):
        """Admin can update resource_access on an auto-provisioned agent."""
        # First resolution: auto-provision creates agent with ["hr-system"]
        store = _mock_store()
        store.create_cimd_agent = MagicMock(return_value=True)
        # After admin update, get_agent_by_client_id returns updated list
        updated_record = {
            "agent_id": "cimd-app-abc12345",
            "agent_name": "cimd-app-abc12345",
            "client_id": CIMD_URL,
            "resource_access": ["hr-system", "finance-system"],
            "enabled": True,
        }
        store.get_agent_by_client_id = MagicMock(return_value=updated_record)

        fetcher = _mock_fetcher()
        policy = _mock_policy(
            allowed=True,
            trust_level=TrustLevel.TRUSTED,
            resource_access=["hr-system"],
            auto_provision=True,
        )
        registry = ClientRegistry(store, fetcher, policy)

        result = await registry.resolve(CIMD_URL)

        assert result is not None
        # resource_access should come from DB (admin-configured), not trust policy
        assert result.resource_access == ["hr-system", "finance-system"]

    async def test_cimd_unknown_domain_empty_resource_access(self):
        """Unknown domain with no CIMD_UNKNOWN_RESOURCE_ACCESS gets empty resource_access."""
        store = _mock_store()
        fetcher = _mock_fetcher()
        policy = _mock_policy(
            allowed=True,
            trust_level=TrustLevel.UNKNOWN,
            resource_access=[],
            auto_provision=False,
        )
        registry = ClientRegistry(store, fetcher, policy)

        result = await registry.resolve(CIMD_URL)

        assert result is not None
        assert result.resource_access == []
