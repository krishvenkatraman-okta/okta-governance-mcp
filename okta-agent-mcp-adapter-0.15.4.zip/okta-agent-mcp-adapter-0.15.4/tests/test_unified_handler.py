"""
Tests for the Unified MCP Handler.

Tests tool consolidation, namespace routing, authentication, and error handling.
"""

import pytest
import json
from unittest.mock import AsyncMock, MagicMock, patch
from okta_agent_proxy.mcp.unified_handler import UnifiedMCPHandler, NAMESPACE_SEPARATOR
from okta_agent_proxy.auth.resource_token_resolver import ResourceAuthResult


@pytest.fixture
def mock_store():
    store = MagicMock()
    store.get_agent_by_name.return_value = {
        "agent_id": "claude-code",
        "client_id": "0oatest123",
        "backend_access": ["hr-system", "finance-system"],
        "enabled": True,
    }
    store.get_all_agents.return_value = [
        {"agent_id": "claude-code", "client_id": "0oatest123"},
    ]
    return store


@pytest.fixture
def mock_validator():
    validator = MagicMock()
    validator.validate_token = AsyncMock(return_value={
        "sub": "user123",
        "aud": "0oatest123",
    })
    return validator


@pytest.fixture
def mock_resource_config():
    config = MagicMock()
    config.url = "http://hr-mcp-server:8001/mcp"
    config.auth_method = "pre-shared-key"
    config.auth_config = MagicMock()
    config.auth_config.model_dump.return_value = {
        "key": "test-api-key",
        "header_name": "X-API-Key",
    }
    config.enabled = True
    return config


@pytest.fixture
def mock_router(mock_resource_config):
    router = MagicMock()
    router.get_resource_config.return_value = mock_resource_config
    router.list_resources.return_value = {
        "hr-system": {"url": "http://hr-mcp-server:8001/mcp", "enabled": True},
        "finance-system": {"url": "http://finance-mcp-server:8002/mcp", "enabled": True},
    }
    resolver = MagicMock()
    resolver.resolve_auth_headers = AsyncMock(return_value=ResourceAuthResult(
        headers={"X-API-Key": "test-api-key"}
    ))
    router.resolver = resolver
    return router


@pytest.fixture
def handler(mock_router, mock_validator, mock_store):
    return UnifiedMCPHandler(mock_router, mock_validator, mock_store)


@pytest.fixture
def auth_headers():
    return {
        "authorization": "Bearer test-jwt-token",
        "x-mcp-agent": "claude-code",
        "content-type": "application/json",
    }


class TestInitialize:
    @pytest.mark.asyncio
    async def test_initialize_returns_capabilities(self, handler):
        body = {
            "jsonrpc": "2.0",
            "id": "1",
            "method": "initialize",
            "params": {
                "protocolVersion": "2024-11-05",
                "capabilities": {},
                "clientInfo": {"name": "test", "version": "1.0"},
            },
        }
        response, status, headers = await handler.handle(body, {})

        assert status == 200
        assert response["jsonrpc"] == "2.0"
        assert response["id"] == "1"
        result = response["result"]
        assert result["protocolVersion"] == "2024-11-05"
        assert "tools" in result["capabilities"]
        assert result["serverInfo"]["name"] == "Okta MCP Gateway"

    @pytest.mark.asyncio
    async def test_initialize_returns_session_id(self, handler):
        body = {"jsonrpc": "2.0", "id": "1", "method": "initialize", "params": {}}
        _, _, headers = await handler.handle(body, {})
        assert "Mcp-Session-Id" in headers
        assert len(headers["Mcp-Session-Id"]) > 0

    @pytest.mark.asyncio
    async def test_initialize_no_auth_needed(self, handler):
        body = {"jsonrpc": "2.0", "id": "1", "method": "initialize", "params": {}}
        response, status, _ = await handler.handle(body, {})
        assert status == 200
        assert "result" in response


class TestNotificationsInitialized:
    @pytest.mark.asyncio
    async def test_returns_empty_200(self, handler):
        body = {"jsonrpc": "2.0", "method": "notifications/initialized"}
        response, status, _ = await handler.handle(body, {})
        assert status == 200


class TestPing:
    @pytest.mark.asyncio
    async def test_ping_returns_result(self, handler):
        body = {"jsonrpc": "2.0", "id": "1", "method": "ping"}
        response, status, _ = await handler.handle(body, {})
        assert status == 200
        assert "result" in response


class TestAuthentication:
    @pytest.mark.asyncio
    async def test_tools_list_requires_auth(self, handler):
        body = {"jsonrpc": "2.0", "id": "1", "method": "tools/list", "params": {}}
        response, status, _ = await handler.handle(body, {})
        assert status == 401
        assert "error" in response
        assert response["error"]["code"] == -32001

    @pytest.mark.asyncio
    async def test_tools_call_requires_auth(self, handler):
        body = {
            "jsonrpc": "2.0", "id": "1", "method": "tools/call",
            "params": {"name": "hr-system__health_check", "arguments": {}},
        }
        response, status, _ = await handler.handle(body, {})
        assert status == 401

    @pytest.mark.asyncio
    async def test_invalid_token_returns_401(self, handler, mock_validator):
        mock_validator.validate_token = AsyncMock(return_value=None)
        body = {"jsonrpc": "2.0", "id": "1", "method": "tools/list", "params": {}}
        response, status, hdrs = await handler.handle(
            body, {"authorization": "Bearer invalid"}
        )
        assert status == 401
        # RFC 6750: token presented but rejected → invalid_token so the
        # client drops its cached token and starts a fresh auth flow
        # instead of trying to re-register the same credentials.
        www = hdrs.get("WWW-Authenticate", "")
        assert 'error="invalid_token"' in www
        assert "error_description=" in www
        assert "resource_metadata=" in www

    @pytest.mark.asyncio
    async def test_missing_auth_header_returns_401_without_invalid_token(self, handler):
        """No Authorization header → challenge only, not invalid_token."""
        body = {"jsonrpc": "2.0", "id": "1", "method": "tools/list", "params": {}}
        _resp, status, hdrs = await handler.handle(body, {})
        assert status == 401
        www = hdrs.get("WWW-Authenticate", "")
        assert "resource_metadata=" in www
        assert 'error="invalid_token"' not in www

    @pytest.mark.asyncio
    async def test_revoked_sub_returns_401_despite_valid_jwt(
        self, handler, auth_headers
    ):
        """After global logout, an unexpired JWT for the revoked sub must be rejected."""
        from okta_agent_proxy.auth.revocation_registry import (
            get_revocation_registry,
            reset_revocation_registry,
        )
        reset_revocation_registry()
        try:
            await get_revocation_registry().revoke("user123")
            body = {"jsonrpc": "2.0", "id": "1", "method": "tools/list", "params": {}}
            response, status, _ = await handler.handle(body, auth_headers)
            assert status == 401
            assert response["error"]["code"] == -32001
        finally:
            reset_revocation_registry()


class TestToolsList:
    @pytest.mark.asyncio
    async def test_tools_list_namespaces_tools(self, handler, auth_headers):
        resource_tools = [
            {"name": "health_check", "description": "Check health", "inputSchema": {}},
            {"name": "get_employee", "description": "Get employee", "inputSchema": {}},
        ]

        with patch.object(handler, "_discover_tools", new_callable=AsyncMock, return_value=resource_tools):
            body = {"jsonrpc": "2.0", "id": "1", "method": "tools/list", "params": {}}
            response, status, _ = await handler.handle(body, auth_headers)

        assert status == 200
        tools = response["result"]["tools"]
        # hr-system has 2 tools, finance-system also calls _discover_tools for its resource
        tool_names = [t["name"] for t in tools]
        assert "hr-system__health_check" in tool_names
        assert "hr-system__get_employee" in tool_names

    @pytest.mark.asyncio
    async def test_tools_list_caches_results(self, handler, auth_headers):
        resource_tools = [{"name": "health_check", "description": "Check", "inputSchema": {}}]

        with patch.object(handler, "_discover_tools", new_callable=AsyncMock, return_value=resource_tools) as mock_discover:
            body = {"jsonrpc": "2.0", "id": "1", "method": "tools/list", "params": {}}
            await handler.handle(body, auth_headers)
            # Second call should use cache
            await handler.handle(body, auth_headers)
            # _discover_tools called once per resource on first call, not on second
            first_call_count = mock_discover.call_count
            await handler.handle(body, auth_headers)
            assert mock_discover.call_count == first_call_count

    @pytest.mark.asyncio
    async def test_tools_list_skips_unavailable_resource(self, handler, auth_headers, mock_router):
        """If a resource is unreachable, skip it and return tools from other resources."""
        call_count = 0

        async def flaky_discover(url, headers):
            nonlocal call_count
            call_count += 1
            if call_count == 1:
                raise Exception("Connection refused")
            return [{"name": "tool1", "description": "test", "inputSchema": {}}]

        with patch.object(handler, "_discover_tools", side_effect=flaky_discover):
            body = {"jsonrpc": "2.0", "id": "1", "method": "tools/list", "params": {}}
            response, status, _ = await handler.handle(body, auth_headers)

        assert status == 200
        # Should still return tools from the second resource
        assert "result" in response

    @pytest.mark.asyncio
    async def test_tools_list_returns_empty_when_no_resources(self, handler, auth_headers, mock_store):
        mock_store.get_agent_by_name.return_value = {
            "agent_id": "claude-code",
            "client_id": "0oatest123",
            "backend_access": [],
            "enabled": True,
        }
        body = {"jsonrpc": "2.0", "id": "1", "method": "tools/list", "params": {}}
        response, status, _ = await handler.handle(body, auth_headers)

        assert status == 200
        assert response["result"]["tools"] == []


class TestToolsCall:
    @pytest.mark.asyncio
    @patch("okta_agent_proxy.auth.agent_authz.check_agent_can_access_resource", new_callable=AsyncMock, return_value=True)
    async def test_tools_call_routes_to_resource(self, mock_authz, handler, auth_headers):
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.headers = {"content-type": "application/json"}
        mock_response.json.return_value = {
            "jsonrpc": "2.0",
            "id": "1",
            "result": {"content": [{"type": "text", "text": "OK"}]},
        }

        with patch("httpx.AsyncClient") as mock_client_cls:
            mock_client = AsyncMock()
            mock_client.__aenter__ = AsyncMock(return_value=mock_client)
            mock_client.__aexit__ = AsyncMock(return_value=False)
            mock_client.post = AsyncMock(return_value=mock_response)
            mock_client_cls.return_value = mock_client

            body = {
                "jsonrpc": "2.0", "id": "1", "method": "tools/call",
                "params": {"name": "hr-system__health_check", "arguments": {}},
            }
            response, status, _ = await handler.handle(body, auth_headers)

        assert status == 200
        assert "result" in response
        # Verify the downstream resource was called with the original tool name
        call_args = mock_client.post.call_args
        sent_body = call_args.kwargs.get("json") or call_args[1].get("json")
        assert sent_body["params"]["name"] == "health_check"

    @pytest.mark.asyncio
    async def test_tools_call_unknown_tool(self, handler, auth_headers):
        body = {
            "jsonrpc": "2.0", "id": "1", "method": "tools/call",
            "params": {"name": "unknown_tool", "arguments": {}},
        }
        response, status, _ = await handler.handle(body, auth_headers)
        assert "error" in response
        assert "Unknown tool" in response["error"]["message"]

    @pytest.mark.asyncio
    async def test_tools_call_unauthorized_resource(self, handler, auth_headers, mock_store):
        mock_store.get_agent_by_name.return_value = {
            "agent_id": "claude-code",
            "client_id": "0oatest123",
            "backend_access": ["hr-system"],  # No access to "other-system"
            "enabled": True,
        }
        body = {
            "jsonrpc": "2.0", "id": "1", "method": "tools/call",
            "params": {"name": "other-system__some_tool", "arguments": {}},
        }
        response, status, _ = await handler.handle(body, auth_headers)
        assert status == 403
        assert "error" in response

    @pytest.mark.asyncio
    @patch("okta_agent_proxy.auth.agent_authz.check_agent_can_access_resource", new_callable=AsyncMock, return_value=True)
    async def test_tools_call_handles_sse_response(self, mock_authz, handler, auth_headers):
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.headers = {"content-type": "text/event-stream"}
        mock_response.text = 'event: message\ndata: {"jsonrpc":"2.0","id":"1","result":{"content":[{"type":"text","text":"SSE OK"}]}}\n\n'

        with patch("httpx.AsyncClient") as mock_client_cls:
            mock_client = AsyncMock()
            mock_client.__aenter__ = AsyncMock(return_value=mock_client)
            mock_client.__aexit__ = AsyncMock(return_value=False)
            mock_client.post = AsyncMock(return_value=mock_response)
            mock_client_cls.return_value = mock_client

            body = {
                "jsonrpc": "2.0", "id": "1", "method": "tools/call",
                "params": {"name": "hr-system__health_check", "arguments": {}},
            }
            response, status, _ = await handler.handle(body, auth_headers)

        assert status == 200
        assert response["result"]["content"][0]["text"] == "SSE OK"


class TestOtherMethods:
    @pytest.mark.asyncio
    async def test_resources_list_returns_empty(self, handler, auth_headers):
        body = {"jsonrpc": "2.0", "id": "1", "method": "resources/list", "params": {}}
        response, status, _ = await handler.handle(body, auth_headers)
        assert status == 200
        assert response["result"]["resources"] == []

    @pytest.mark.asyncio
    async def test_prompts_list_returns_empty(self, handler, auth_headers):
        body = {"jsonrpc": "2.0", "id": "1", "method": "prompts/list", "params": {}}
        response, status, _ = await handler.handle(body, auth_headers)
        assert status == 200
        assert response["result"]["prompts"] == []

    @pytest.mark.asyncio
    async def test_unknown_method_returns_error(self, handler, auth_headers):
        body = {"jsonrpc": "2.0", "id": "1", "method": "unknown/method", "params": {}}
        response, status, _ = await handler.handle(body, auth_headers)
        assert "error" in response
        assert response["error"]["code"] == -32601


class TestNamespaceSeparator:
    def test_separator_is_double_underscore(self):
        assert NAMESPACE_SEPARATOR == "__"

    def test_namespace_parsing(self):
        tool_name = "hr-system__get_employee"
        sep_idx = tool_name.index(NAMESPACE_SEPARATOR)
        resource = tool_name[:sep_idx]
        original = tool_name[sep_idx + len(NAMESPACE_SEPARATOR):]
        assert resource == "hr-system"
        assert original == "get_employee"

    def test_namespace_with_underscores_in_tool_name(self):
        tool_name = "hr-system__get_employee_details"
        sep_idx = tool_name.index(NAMESPACE_SEPARATOR)
        resource = tool_name[:sep_idx]
        original = tool_name[sep_idx + len(NAMESPACE_SEPARATOR):]
        assert resource == "hr-system"
        assert original == "get_employee_details"


class TestCacheInvalidation:
    @pytest.mark.asyncio
    async def test_invalidate_specific_agent(self, handler, auth_headers):
        with patch.object(handler, "_discover_tools", new_callable=AsyncMock, return_value=[]):
            body = {"jsonrpc": "2.0", "id": "1", "method": "tools/list", "params": {}}
            await handler.handle(body, auth_headers)
            assert "claude-code" in handler._tool_cache

        handler.invalidate_tool_cache("claude-code")
        assert "claude-code" not in handler._tool_cache

    @pytest.mark.asyncio
    async def test_invalidate_all_agents(self, handler, auth_headers):
        with patch.object(handler, "_discover_tools", new_callable=AsyncMock, return_value=[]):
            body = {"jsonrpc": "2.0", "id": "1", "method": "tools/list", "params": {}}
            await handler.handle(body, auth_headers)

        handler.invalidate_tool_cache()
        assert len(handler._tool_cache) == 0


class TestCacheServiceIntegration:
    """Test tool cache works through CacheService abstraction."""

    @pytest.fixture
    def handler_with_cache(self, mock_router, mock_validator, mock_store, cache_service):
        return UnifiedMCPHandler(mock_router, mock_validator, mock_store, cache_service=cache_service)

    @pytest.mark.asyncio
    async def test_tools_cached_in_service(self, handler_with_cache, auth_headers):
        resource_tools = [{"name": "tool1", "description": "Test", "inputSchema": {}}]

        with patch.object(handler_with_cache, "_discover_tools", new_callable=AsyncMock, return_value=resource_tools) as mock_discover:
            body = {"jsonrpc": "2.0", "id": "1", "method": "tools/list", "params": {}}
            resp1, _, _ = await handler_with_cache.handle(body, auth_headers)
            first_call_count = mock_discover.call_count

            # Second call should use cache (CacheService-backed)
            resp2, _, _ = await handler_with_cache.handle(body, auth_headers)
            assert mock_discover.call_count == first_call_count

        assert len(resp1["result"]["tools"]) > 0
        assert resp1["result"]["tools"] == resp2["result"]["tools"]

    @pytest.mark.asyncio
    async def test_invalidate_clears_service_cache(self, handler_with_cache, auth_headers):
        resource_tools = [{"name": "tool1", "description": "Test", "inputSchema": {}}]

        with patch.object(handler_with_cache, "_discover_tools", new_callable=AsyncMock, return_value=resource_tools) as mock_discover:
            body = {"jsonrpc": "2.0", "id": "1", "method": "tools/list", "params": {}}
            await handler_with_cache.handle(body, auth_headers)
            first_count = mock_discover.call_count

            # Invalidate: clear local cache + await CacheService delete
            handler_with_cache._tool_cache.clear()
            await handler_with_cache._cache_service.delete("tool_catalog:claude-code")

            # Should re-discover since cache was invalidated in both layers
            await handler_with_cache.handle(body, auth_headers)
            assert mock_discover.call_count > first_count


class TestPerUserSessions:
    @pytest.mark.asyncio
    async def test_sessions_are_scoped_per_user(self, handler):
        """Two users hitting the same resource get distinct cache entries."""
        await handler._set_session("http://backend/mcp", "sess-A", user_id="user-a")
        await handler._set_session("http://backend/mcp", "sess-B", user_id="user-b")

        assert await handler._get_session("http://backend/mcp", user_id="user-a") == "sess-A"
        assert await handler._get_session("http://backend/mcp", user_id="user-b") == "sess-B"

    @pytest.mark.asyncio
    async def test_terminate_all_for_user_removes_only_that_users_sessions(self, handler):
        await handler._set_session("http://backend-1/mcp", "s1a", user_id="user-a")
        await handler._set_session("http://backend-2/mcp", "s2a", user_id="user-a")
        await handler._set_session("http://backend-1/mcp", "s1b", user_id="user-b")

        count = await handler.terminate_all_for_user("user-a")

        assert count == 2
        assert await handler._get_session("http://backend-1/mcp", user_id="user-a") is None
        assert await handler._get_session("http://backend-2/mcp", user_id="user-a") is None
        # User B is untouched
        assert await handler._get_session("http://backend-1/mcp", user_id="user-b") == "s1b"

    @pytest.mark.asyncio
    async def test_terminate_all_for_user_empty_user_id_is_noop(self, handler):
        await handler._set_session("http://backend/mcp", "s", user_id="user-a")
        assert await handler.terminate_all_for_user("") == 0
        assert await handler._get_session("http://backend/mcp", user_id="user-a") == "s"

    @pytest.mark.asyncio
    async def test_terminate_all_for_user_returns_zero_when_no_sessions(self, handler):
        assert await handler.terminate_all_for_user("no-such-user") == 0
