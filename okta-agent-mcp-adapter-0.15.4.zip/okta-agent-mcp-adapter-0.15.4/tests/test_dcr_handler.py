"""
Tests for the DCR Handler.

Validates the full Dynamic Client Registration flow including:
- Relay-backed registration
- Policy rejection with audit event
- Agent record creation
- DCR registration record creation
- Cache invalidation events
- Registration revocation with audit event
- Agent linking and unlinking
- Selectable agents filtering
"""

import json
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from okta_agent_proxy.auth.dcr_handler import DCRHandler
from okta_agent_proxy.auth.dcr_policy import DCRPolicy
from okta_agent_proxy.audit.events import AuditEventType


def _valid_body(**overrides):
    """Build a valid DCR request body."""
    body = {
        "client_name": "Test MCP Client",
        "redirect_uris": ["http://localhost:9999/callback"],
        "grant_types": ["authorization_code"],
        "response_types": ["code"],
        "token_endpoint_auth_method": "client_secret_basic",
    }
    body.update(overrides)
    return body


def _mock_store():
    """Create a mock store with the required DCR methods."""
    store = MagicMock()
    store.create_agent.return_value = True
    store.create_dcr_registration.return_value = {
        "id": "test-uuid",
        "client_id": "test-client",
        "status": "active",
    }
    store.get_dcr_registration.return_value = None
    store.revoke_dcr_registration.return_value = True
    store.disable_agent.return_value = True
    store.update_agent.return_value = True
    store.update_dcr_registration_linked_agent.return_value = True
    store.get_all_agents.return_value = []
    return store


def _mock_event_bus():
    """Create a mock event bus."""
    bus = MagicMock()
    bus.publish = AsyncMock()
    return bus


def _dcr_handler(
    *,
    enabled=True,
    auto_enable_agent=True,
    default_resource_access=None,
    store=None,
    event_bus=None,
):
    """Create a DCRHandler with configurable policy."""
    policy = DCRPolicy(
        enabled=enabled,
        auto_enable_agent=auto_enable_agent,
        default_resource_access=default_resource_access or ["hr-system"],
    )
    return DCRHandler(
        dcr_policy=policy,
        store=store or _mock_store(),
        event_bus=event_bus,
    )


class TestDCRHandlerRegistration:
    """Tests for relay-backed client registration."""

    @patch("okta_agent_proxy.auth.dcr_handler.emit_audit_event", new_callable=AsyncMock)
    async def test_registration_returns_201(self, mock_emit):
        """Successful registration returns 201."""
        handler = _dcr_handler()
        status, body = await handler.handle_registration(
            _valid_body(), source_ip="10.0.0.1"
        )
        assert status == 201
        assert "client_id" in body
        assert body["client_id"].startswith("dcr_")
        assert "client_secret" in body
        assert body["client_secret_expires_at"] == 0
        assert body["client_name"] == "Test MCP Client"

    @patch("okta_agent_proxy.auth.dcr_handler.emit_audit_event", new_callable=AsyncMock)
    async def test_registration_has_rfc7591_fields(self, mock_emit):
        """Response includes all RFC 7591 required fields."""
        handler = _dcr_handler()
        status, body = await handler.handle_registration(
            _valid_body(), source_ip="10.0.0.1"
        )
        assert "client_id_issued_at" in body
        assert "redirect_uris" in body
        assert "grant_types" in body
        assert "response_types" in body
        assert "token_endpoint_auth_method" in body
        assert "registration_access_token" in body
        assert "registration_client_uri" in body

    @patch("okta_agent_proxy.auth.dcr_handler.emit_audit_event", new_callable=AsyncMock)
    async def test_registration_does_not_create_agent(self, mock_emit):
        """No agent record is created — DCR registrations are lightweight."""
        store = _mock_store()
        handler = _dcr_handler(store=store)
        status, body = await handler.handle_registration(
            _valid_body(), source_ip="10.0.0.1"
        )
        assert status == 201
        store.create_agent.assert_not_called()

    @patch("okta_agent_proxy.auth.dcr_handler.emit_audit_event", new_callable=AsyncMock)
    async def test_registration_creates_dcr_record(self, mock_emit):
        """DCR registration record is created in the store."""
        store = _mock_store()
        handler = _dcr_handler(store=store)
        status, body = await handler.handle_registration(
            _valid_body(), source_ip="10.0.0.1"
        )
        assert status == 201
        store.create_dcr_registration.assert_called_once()
        kwargs = store.create_dcr_registration.call_args[1]
        assert kwargs["provision_mode"] == "relay"
        assert kwargs["client_id"] == body["client_id"]
        assert kwargs["client_name"] == "Test MCP Client"
        assert kwargs["source_ip"] == "10.0.0.1"

    @patch("okta_agent_proxy.auth.dcr_handler.emit_audit_event", new_callable=AsyncMock)
    async def test_registration_no_cache_invalidation(self, mock_emit):
        """No cache invalidation — no agent record created."""
        bus = _mock_event_bus()
        handler = _dcr_handler(event_bus=bus)
        status, body = await handler.handle_registration(
            _valid_body(), source_ip="10.0.0.1"
        )
        assert status == 201
        bus.publish.assert_not_called()

    @patch("okta_agent_proxy.auth.dcr_handler.emit_audit_event", new_callable=AsyncMock)
    async def test_registration_creates_dcr_record_with_no_agent(self, mock_emit):
        """DCR registration has agent_name=None (no agent record created)."""
        store = _mock_store()
        handler = _dcr_handler(store=store)
        status, body = await handler.handle_registration(
            _valid_body(), source_ip="10.0.0.1"
        )
        assert status == 201
        kwargs = store.create_dcr_registration.call_args[1]
        assert kwargs["agent_name"] is None

    @patch("okta_agent_proxy.auth.dcr_handler.emit_audit_event", new_callable=AsyncMock)
    async def test_dcr_provision_emits_unlinked_audit(self, mock_emit):
        """DCR registration audit event has linked=False."""
        store = _mock_store()
        handler = _dcr_handler(store=store)
        status, body = await handler.handle_registration(
            _valid_body(), source_ip="10.0.0.1"
        )
        assert status == 201
        store.create_agent.assert_not_called()
        mock_emit.assert_called()
        reg_call = [
            c for c in mock_emit.call_args_list
            if c[0][0] == AuditEventType.DCR_REGISTRATION
        ]
        assert len(reg_call) == 1
        assert reg_call[0][1]["details"]["linked"] is False


class TestDCRHandlerPolicyRejection:
    """Tests for policy rejection."""

    @patch("okta_agent_proxy.auth.dcr_handler.emit_audit_event", new_callable=AsyncMock)
    async def test_policy_rejection_returns_400(self, mock_emit):
        """Policy rejection returns 400 with error details."""
        handler = _dcr_handler(enabled=False)
        status, body = await handler.handle_registration(
            _valid_body(), source_ip="10.0.0.1"
        )
        assert status == 400
        assert body["error"] == "invalid_client_metadata"
        assert "disabled" in body["error_description"].lower()

    @patch("okta_agent_proxy.auth.dcr_handler.emit_audit_event", new_callable=AsyncMock)
    async def test_policy_rejection_no_agent_created(self, mock_emit):
        """No agent record is created on policy rejection."""
        store = _mock_store()
        handler = _dcr_handler(enabled=False, store=store)
        await handler.handle_registration(_valid_body(), source_ip="10.0.0.1")
        store.create_agent.assert_not_called()
        store.create_dcr_registration.assert_not_called()

    @patch("okta_agent_proxy.auth.dcr_handler.emit_audit_event", new_callable=AsyncMock)
    async def test_dcr_registration_rejected_audit_event(self, mock_emit):
        """DCR_REGISTRATION_REJECTED audit event is emitted on rejection."""
        handler = _dcr_handler(enabled=False)
        await handler.handle_registration(
            _valid_body(), source_ip="10.0.0.1"
        )
        mock_emit.assert_called_once()
        call = mock_emit.call_args
        assert call[0][0] == AuditEventType.DCR_REGISTRATION_REJECTED
        assert call[1]["severity"] == AuditSeverity.WARNING
        assert call[1]["details"]["source_ip"] == "10.0.0.1"
        assert call[1]["outcome"] == "failure"


from okta_agent_proxy.audit.events import AuditSeverity


class TestDCRHandlerRevocation:
    """Tests for registration revocation."""

    @patch("okta_agent_proxy.auth.dcr_handler.emit_audit_event", new_callable=AsyncMock)
    async def test_revoke_active_registration(self, mock_emit):
        """Revoking an active registration revokes the DCR record."""
        store = _mock_store()
        store.get_dcr_registration.return_value = {
            "client_id": "test-client",
            "status": "active",
            "provision_mode": "relay",
            "linked_agent_name": None,
        }
        handler = _dcr_handler(store=store)
        success, message = await handler.revoke_registration("test-client")
        assert success is True
        store.revoke_dcr_registration.assert_called_once_with(
            "test-client", user="admin"
        )
        store.disable_agent.assert_not_called()

    @patch("okta_agent_proxy.auth.dcr_handler.emit_audit_event", new_callable=AsyncMock)
    async def test_revoke_not_found(self, mock_emit):
        """Revoking a non-existent registration fails."""
        store = _mock_store()
        store.get_dcr_registration.return_value = None
        handler = _dcr_handler(store=store)
        success, message = await handler.revoke_registration("nonexistent")
        assert success is False
        assert "not found" in message.lower()

    @patch("okta_agent_proxy.auth.dcr_handler.emit_audit_event", new_callable=AsyncMock)
    async def test_revoke_already_revoked(self, mock_emit):
        """Revoking an already-revoked registration fails."""
        store = _mock_store()
        store.get_dcr_registration.return_value = {
            "client_id": "test-client",
            "status": "revoked",
        }
        handler = _dcr_handler(store=store)
        success, message = await handler.revoke_registration("test-client")
        assert success is False
        assert "already revoked" in message.lower()

    @patch("okta_agent_proxy.auth.dcr_handler.emit_audit_event", new_callable=AsyncMock)
    async def test_revoke_no_agent_disable(self, mock_emit):
        """Revocation does not disable any agent (no DCR agent record exists)."""
        store = _mock_store()
        store.get_dcr_registration.return_value = {
            "client_id": "test-client",
            "status": "active",
            "provision_mode": "relay",
            "linked_agent_name": None,
        }
        handler = _dcr_handler(store=store)
        await handler.revoke_registration("test-client")
        store.disable_agent.assert_not_called()

    @patch("okta_agent_proxy.auth.dcr_handler.emit_audit_event", new_callable=AsyncMock)
    async def test_dcr_revocation_audit_event(self, mock_emit):
        """DCR_REVOCATION audit event is emitted with details."""
        store = _mock_store()
        store.get_dcr_registration.return_value = {
            "client_id": "test-client",
            "status": "active",
            "provision_mode": "relay",
            "linked_agent_name": "imported-agent",
        }
        handler = _dcr_handler(store=store)
        await handler.revoke_registration("test-client")
        mock_emit.assert_called_once()
        call = mock_emit.call_args
        assert call[0][0] == AuditEventType.DCR_REVOCATION
        details = call[1]["details"]
        assert details["client_id"] == "test-client"
        assert details["linked_agent_name"] == "imported-agent"


class TestDCRHandlerLinking:
    """Tests for link_to_agent and unlink_agent."""

    @patch("okta_agent_proxy.auth.dcr_handler.emit_audit_event", new_callable=AsyncMock)
    async def test_dcr_link_to_agent_success(self, mock_emit):
        """Linking sets linked_agent_name, emits audit event (no credential copy)."""
        store = _mock_store()
        store.get_dcr_registration.return_value = {
            "client_id": "dcr_abc123",
            "status": "active",
            "agent_name": "dcr-dcr_abc123",
            "client_name": "Test Client",
            "linked_agent_name": None,
        }
        store.get_agent.return_value = {
            "agent_name": "imported-agent",
            "client_id": "0oa_real_client",
            "client_secret": "real_secret",
            "private_key": '{"kty":"RSA","kid":"real"}',
            "dcr_selectable": True,
        }
        handler = _dcr_handler(store=store)
        success, msg = await handler.link_to_agent("dcr_abc123", "imported-agent")
        assert success is True

        # No credential copy — only linked_agent_name is set
        store.update_agent.assert_not_called()

        # Verify linked_agent_name was set
        store.update_dcr_registration_linked_agent.assert_called_once_with(
            "dcr_abc123", "imported-agent"
        )

        # Verify audit event
        link_calls = [
            c for c in mock_emit.call_args_list
            if c[0][0] == AuditEventType.DCR_AGENT_LINKED
        ]
        assert len(link_calls) == 1
        details = link_calls[0][1]["details"]
        assert details["target_agent_name"] == "imported-agent"
        assert details["credential_source"] == "linked_okta_app"
        assert details["target_client_id_prefix"] == "0oa_real..."

    @patch("okta_agent_proxy.auth.dcr_handler.emit_audit_event", new_callable=AsyncMock)
    async def test_dcr_link_to_non_selectable_rejected(self, mock_emit):
        """Linking fails if target agent has dcr_selectable=False."""
        store = _mock_store()
        store.get_dcr_registration.return_value = {
            "client_id": "dcr_abc123",
            "status": "active",
            "agent_name": "dcr-dcr_abc123",
        }
        store.get_agent.return_value = {
            "agent_name": "imported-agent",
            "client_id": "0oa_real_client",
            "client_secret": "real_secret",
            "dcr_selectable": False,
        }
        handler = _dcr_handler(store=store)
        success, msg = await handler.link_to_agent("dcr_abc123", "imported-agent")
        assert success is False
        assert "not selectable" in msg.lower()
        store.update_agent.assert_not_called()

    @patch("okta_agent_proxy.auth.dcr_handler.emit_audit_event", new_callable=AsyncMock)
    async def test_dcr_link_to_agent_without_creds_rejected(self, mock_emit):
        """Linking fails if target agent has no Okta credentials."""
        store = _mock_store()
        store.get_dcr_registration.return_value = {
            "client_id": "dcr_abc123",
            "status": "active",
            "agent_name": "dcr-dcr_abc123",
        }
        store.get_agent.return_value = {
            "agent_name": "imported-agent",
            "client_id": None,
            "client_secret": None,
            "dcr_selectable": True,
        }
        handler = _dcr_handler(store=store)
        success, msg = await handler.link_to_agent("dcr_abc123", "imported-agent")
        assert success is False
        assert "credentials" in msg.lower()

    @patch("okta_agent_proxy.auth.dcr_handler.emit_audit_event", new_callable=AsyncMock)
    async def test_dcr_unlink_clears_creds(self, mock_emit):
        """Unlinking restores placeholder creds and clears linked_agent_name."""
        store = _mock_store()
        store.get_dcr_registration.return_value = {
            "client_id": "dcr_abc123",
            "status": "active",
            "agent_name": "dcr-dcr_abc123",
            "linked_agent_name": "imported-agent",
        }
        handler = _dcr_handler(store=store)
        success, msg = await handler.unlink_agent("dcr_abc123")
        assert success is True

        # No credential restore needed — credentials live on the linked agent
        store.update_agent.assert_not_called()

        # Verify linked_agent_name was cleared
        store.update_dcr_registration_linked_agent.assert_called_once_with(
            "dcr_abc123", None
        )

        # Verify audit event
        unlink_calls = [
            c for c in mock_emit.call_args_list
            if c[0][0] == AuditEventType.DCR_AGENT_UNLINKED
        ]
        assert len(unlink_calls) == 1
        assert unlink_calls[0][1]["details"]["previous_linked_agent"] == "imported-agent"

    @patch("okta_agent_proxy.auth.dcr_handler.emit_audit_event", new_callable=AsyncMock)
    async def test_dcr_unlink_not_found(self, mock_emit):
        """Unlinking a non-existent registration returns failure."""
        store = _mock_store()
        store.get_dcr_registration.return_value = None
        handler = _dcr_handler(store=store)
        success, msg = await handler.unlink_agent("nonexistent")
        assert success is False
        assert "not found" in msg.lower()


class TestDCRHandlerSelectableAgents:
    """Tests for get_selectable_agents."""

    def test_dcr_get_selectable_agents(self):
        """Filters to agents with dcr_selectable=True, valid credentials, non-DCR client_id."""
        store = _mock_store()
        store.get_all_agents.return_value = [
            {"agent_name": "a1", "agent_id": "a1", "dcr_selectable": True, "client_id": "0oa1", "client_secret": "s1"},
            {"agent_name": "a2", "agent_id": "a2", "dcr_selectable": False, "client_id": "0oa2", "client_secret": "s2"},
            {"agent_name": "a3", "agent_id": "a3", "dcr_selectable": True, "client_id": None, "client_secret": None},
            {"agent_name": "a4", "agent_id": "a4", "dcr_selectable": True, "client_id": "0oa4", "client_secret": "s4"},
            {"agent_name": "a5", "agent_id": "a5", "dcr_selectable": True, "client_id": "dcr_xyz", "client_secret": "s5"},
        ]
        handler = _dcr_handler(store=store)
        result = handler.get_selectable_agents()
        names = [a["agent_name"] for a in result]
        assert names == ["a1", "a4"]

    def test_dcr_selectable_excludes_dcr_agents(self):
        """Agents with dcr_-prefixed client_id are excluded from selectable list."""
        store = _mock_store()
        store.get_all_agents.return_value = [
            {"agent_name": "real", "agent_id": "real", "dcr_selectable": True,
             "client_id": "0oa_real", "client_secret": "s"},
            {"agent_name": "dcr-agent", "agent_id": "dcr-agent", "dcr_selectable": True,
             "client_id": "dcr_abcdef", "client_secret": "s"},
        ]
        handler = _dcr_handler(store=store)
        result = handler.get_selectable_agents()
        assert len(result) == 1
        assert result[0]["agent_name"] == "real"


class TestDCRCredentialSeparation:
    """Tests for credential separation guards."""

    @patch("okta_agent_proxy.auth.dcr_handler.emit_audit_event", new_callable=AsyncMock)
    async def test_dcr_link_rejects_dcr_target(self, mock_emit):
        """link_to_agent rejects target agents with dcr_-prefixed client_id."""
        store = _mock_store()
        store.get_dcr_registration.return_value = {
            "client_id": "dcr_abc123",
            "status": "active",
            "agent_name": "dcr-dcr_abc123",
        }
        store.get_agent.return_value = {
            "agent_name": "dcr-other",
            "client_id": "dcr_other_id",
            "client_secret": "some_secret",
            "dcr_selectable": True,
        }
        handler = _dcr_handler(store=store)
        success, msg = await handler.link_to_agent("dcr_abc123", "dcr-other")
        assert success is False
        assert "DCR-issued client_id" in msg
        store.update_agent.assert_not_called()

    @patch("okta_agent_proxy.auth.dcr_handler.emit_audit_event", new_callable=AsyncMock)
    async def test_dcr_provision_does_not_return_okta_secret(self, mock_emit):
        """RFC 7591 response contains adapter-generated secret, not any Okta secret."""
        store = _mock_store()
        # Pre-existing agent with Okta creds that must NOT leak
        store.get_all_agents.return_value = [
            {"agent_name": "imported", "client_id": "0oa_real", "client_secret": "OKTA_SECRET_XYZ"},
        ]
        handler = _dcr_handler(store=store)

        sanitized = {
            "client_name": "Test",
            "redirect_uris": ["http://localhost:9999/callback"],
            "grant_types": ["authorization_code"],
        }
        status, body = await handler._provision(sanitized, "10.0.0.1")
        assert status == 201
        # The returned client_secret must be the adapter-generated one
        assert body["client_secret"] != "OKTA_SECRET_XYZ"
        assert len(body["client_secret"]) > 20  # Random token
        # client_id must be DCR-issued, not an Okta app id
        assert body["client_id"].startswith("dcr_")
