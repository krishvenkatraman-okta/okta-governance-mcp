"""
Tests for extended OktaAIAgentClient methods:
- Connection CRUD (create, get, update, delete, activate, deactivate)
- Potential connections discovery
- Public key management
- Agent lifecycle (register, activate, deactivate, delete)
- Operation polling
"""

import asyncio
import pytest
from unittest.mock import AsyncMock, MagicMock, patch

import httpx


@pytest.fixture(autouse=True)
def set_okta_domain(monkeypatch):
    monkeypatch.setenv("OKTA_DOMAIN", "dev-test.okta.com")
    monkeypatch.delenv("OKTA_AI_AGENT_ID", raising=False)


@pytest.fixture
def mock_service_auth():
    auth = MagicMock()
    auth.get_access_token = AsyncMock(return_value="service-token-xxx")
    return auth


@pytest.fixture
def client(mock_service_auth):
    from okta_agent_proxy.auth.okta_ai_agent_client import OktaAIAgentClient
    return OktaAIAgentClient(service_auth=mock_service_auth)


def _mock_response(status_code=200, json_data=None, text=""):
    resp = MagicMock(spec=httpx.Response)
    resp.status_code = status_code
    resp.text = text
    resp.json.return_value = json_data if json_data is not None else {}
    resp.headers = {}
    return resp


# ============================================================================
# Connection CRUD
# ============================================================================

class TestCreateConnection:

    @pytest.mark.asyncio
    async def test_create_connection_success(self, client):
        payload = {
            "connectionType": "IDENTITY_ASSERTION_CUSTOM_AS",
            "authorizationServer": {"orn": "orn:okta:idp:00o:authorization_servers:aus123"},
        }
        mock_resp = _mock_response(201, {"id": "conn123", "connectionType": "IDENTITY_ASSERTION_CUSTOM_AS"})

        with patch("httpx.AsyncClient") as mock_client_cls:
            mock_http = AsyncMock()
            mock_http.post.return_value = mock_resp
            mock_http.__aenter__ = AsyncMock(return_value=mock_http)
            mock_http.__aexit__ = AsyncMock(return_value=False)
            mock_client_cls.return_value = mock_http

            result = await client.create_connection("agt123", payload, okta_token="admin-token")

        assert result is not None
        assert result["id"] == "conn123"
        mock_http.post.assert_called_once()
        call_kwargs = mock_http.post.call_args
        assert "agt123/connections" in call_kwargs.args[0]
        assert call_kwargs.kwargs["json"] == payload

    @pytest.mark.asyncio
    async def test_create_connection_failure(self, client):
        mock_resp = _mock_response(400, text="Bad Request")

        with patch("httpx.AsyncClient") as mock_client_cls:
            mock_http = AsyncMock()
            mock_http.post.return_value = mock_resp
            mock_http.__aenter__ = AsyncMock(return_value=mock_http)
            mock_http.__aexit__ = AsyncMock(return_value=False)
            mock_client_cls.return_value = mock_http

            result = await client.create_connection("agt123", {})

        assert result is None

    @pytest.mark.asyncio
    async def test_create_connection_no_domain(self, monkeypatch):
        monkeypatch.setenv("OKTA_DOMAIN", "")
        from okta_agent_proxy.auth.okta_ai_agent_client import OktaAIAgentClient
        c = OktaAIAgentClient(service_auth=MagicMock())
        result = await c.create_connection("agt123", {})
        assert result is None


class TestGetConnection:

    @pytest.mark.asyncio
    async def test_get_connection_success(self, client):
        mock_resp = _mock_response(200, {"id": "conn456", "status": "ACTIVE"})

        with patch("httpx.AsyncClient") as mock_client_cls:
            mock_http = AsyncMock()
            mock_http.get.return_value = mock_resp
            mock_http.__aenter__ = AsyncMock(return_value=mock_http)
            mock_http.__aexit__ = AsyncMock(return_value=False)
            mock_client_cls.return_value = mock_http

            result = await client.get_connection("agt123", "conn456")

        assert result is not None
        assert result["id"] == "conn456"

    @pytest.mark.asyncio
    async def test_get_connection_not_found(self, client):
        mock_resp = _mock_response(404)

        with patch("httpx.AsyncClient") as mock_client_cls:
            mock_http = AsyncMock()
            mock_http.get.return_value = mock_resp
            mock_http.__aenter__ = AsyncMock(return_value=mock_http)
            mock_http.__aexit__ = AsyncMock(return_value=False)
            mock_client_cls.return_value = mock_http

            result = await client.get_connection("agt123", "conn999")

        assert result is None


class TestUpdateConnection:

    @pytest.mark.asyncio
    async def test_update_connection_success(self, client):
        mock_resp = _mock_response(200, {"id": "conn123", "scopeCondition": "INCLUDE_ONLY"})

        with patch("httpx.AsyncClient") as mock_client_cls:
            mock_http = AsyncMock()
            mock_http.patch.return_value = mock_resp
            mock_http.__aenter__ = AsyncMock(return_value=mock_http)
            mock_http.__aexit__ = AsyncMock(return_value=False)
            mock_client_cls.return_value = mock_http

            result = await client.update_connection("agt123", "conn123", {"scopeCondition": "INCLUDE_ONLY"})

        assert result is not None
        assert result["scopeCondition"] == "INCLUDE_ONLY"

    @pytest.mark.asyncio
    async def test_update_connection_204(self, client):
        mock_resp = _mock_response(204)

        with patch("httpx.AsyncClient") as mock_client_cls:
            mock_http = AsyncMock()
            mock_http.patch.return_value = mock_resp
            mock_http.__aenter__ = AsyncMock(return_value=mock_http)
            mock_http.__aexit__ = AsyncMock(return_value=False)
            mock_client_cls.return_value = mock_http

            result = await client.update_connection("agt123", "conn123", {})

        assert result == {}

    @pytest.mark.asyncio
    async def test_update_connection_failure(self, client):
        mock_resp = _mock_response(422, text="Unprocessable")

        with patch("httpx.AsyncClient") as mock_client_cls:
            mock_http = AsyncMock()
            mock_http.patch.return_value = mock_resp
            mock_http.__aenter__ = AsyncMock(return_value=mock_http)
            mock_http.__aexit__ = AsyncMock(return_value=False)
            mock_client_cls.return_value = mock_http

            result = await client.update_connection("agt123", "conn123", {})

        assert result is None


class TestDeleteConnection:

    @pytest.mark.asyncio
    async def test_delete_connection_success(self, client):
        mock_resp = _mock_response(204)

        with patch("httpx.AsyncClient") as mock_client_cls:
            mock_http = AsyncMock()
            mock_http.delete.return_value = mock_resp
            mock_http.__aenter__ = AsyncMock(return_value=mock_http)
            mock_http.__aexit__ = AsyncMock(return_value=False)
            mock_client_cls.return_value = mock_http

            result = await client.delete_connection("agt123", "conn123")

        assert result is True

    @pytest.mark.asyncio
    async def test_delete_connection_not_found(self, client):
        mock_resp = _mock_response(404, text="Not Found")

        with patch("httpx.AsyncClient") as mock_client_cls:
            mock_http = AsyncMock()
            mock_http.delete.return_value = mock_resp
            mock_http.__aenter__ = AsyncMock(return_value=mock_http)
            mock_http.__aexit__ = AsyncMock(return_value=False)
            mock_client_cls.return_value = mock_http

            result = await client.delete_connection("agt123", "conn999")

        assert result is False


class TestConnectionLifecycle:

    @pytest.mark.asyncio
    async def test_activate_connection(self, client):
        mock_resp = _mock_response(200, {"id": "conn123", "status": "ACTIVE"})

        with patch("httpx.AsyncClient") as mock_client_cls:
            mock_http = AsyncMock()
            mock_http.post.return_value = mock_resp
            mock_http.__aenter__ = AsyncMock(return_value=mock_http)
            mock_http.__aexit__ = AsyncMock(return_value=False)
            mock_client_cls.return_value = mock_http

            result = await client.activate_connection("agt123", "conn123")

        assert result is not None
        assert result["status"] == "ACTIVE"
        assert "lifecycle/activate" in mock_http.post.call_args.args[0]

    @pytest.mark.asyncio
    async def test_deactivate_connection(self, client):
        mock_resp = _mock_response(200, {"id": "conn123", "status": "INACTIVE"})

        with patch("httpx.AsyncClient") as mock_client_cls:
            mock_http = AsyncMock()
            mock_http.post.return_value = mock_resp
            mock_http.__aenter__ = AsyncMock(return_value=mock_http)
            mock_http.__aexit__ = AsyncMock(return_value=False)
            mock_client_cls.return_value = mock_http

            result = await client.deactivate_connection("agt123", "conn123")

        assert result is not None
        assert result["status"] == "INACTIVE"
        assert "lifecycle/deactivate" in mock_http.post.call_args.args[0]

    @pytest.mark.asyncio
    async def test_activate_connection_204(self, client):
        mock_resp = _mock_response(204)

        with patch("httpx.AsyncClient") as mock_client_cls:
            mock_http = AsyncMock()
            mock_http.post.return_value = mock_resp
            mock_http.__aenter__ = AsyncMock(return_value=mock_http)
            mock_http.__aexit__ = AsyncMock(return_value=False)
            mock_client_cls.return_value = mock_http

            result = await client.activate_connection("agt123", "conn123")

        assert result == {}

    @pytest.mark.asyncio
    async def test_activate_connection_failure(self, client):
        mock_resp = _mock_response(409, text="Conflict")

        with patch("httpx.AsyncClient") as mock_client_cls:
            mock_http = AsyncMock()
            mock_http.post.return_value = mock_resp
            mock_http.__aenter__ = AsyncMock(return_value=mock_http)
            mock_http.__aexit__ = AsyncMock(return_value=False)
            mock_client_cls.return_value = mock_http

            result = await client.activate_connection("agt123", "conn123")

        assert result is None


# ============================================================================
# Potential Connections
# ============================================================================

class TestPotentialConnections:

    @pytest.mark.asyncio
    async def test_list_potential_connections(self, client):
        mock_resp = _mock_response(200, [
            {"id": "pc1", "name": "Auth Server 1"},
            {"id": "pc2", "name": "Auth Server 2"},
        ])

        with patch("httpx.AsyncClient") as mock_client_cls:
            mock_http = AsyncMock()
            mock_http.get.return_value = mock_resp
            mock_http.__aenter__ = AsyncMock(return_value=mock_http)
            mock_http.__aexit__ = AsyncMock(return_value=False)
            mock_client_cls.return_value = mock_http

            result = await client.list_potential_connections("IDENTITY_ASSERTION_CUSTOM_AS")

        assert len(result) == 2
        call_kwargs = mock_http.get.call_args
        assert "potential-connections" in call_kwargs.args[0]
        params = call_kwargs.kwargs.get("params", {})
        assert 'connectionType eq "IDENTITY_ASSERTION_CUSTOM_AS"' in params.get("filter", "")

    @pytest.mark.asyncio
    async def test_list_potential_connections_with_match(self, client):
        mock_resp = _mock_response(200, {"data": [{"id": "pc1"}]})

        with patch("httpx.AsyncClient") as mock_client_cls:
            mock_http = AsyncMock()
            mock_http.get.return_value = mock_resp
            mock_http.__aenter__ = AsyncMock(return_value=mock_http)
            mock_http.__aexit__ = AsyncMock(return_value=False)
            mock_client_cls.return_value = mock_http

            result = await client.list_potential_connections(
                "STS_VAULT_SECRET", match="slack"
            )

        assert len(result) == 1
        params = mock_http.get.call_args.kwargs.get("params", {})
        assert params.get("match") == "slack"

    @pytest.mark.asyncio
    async def test_list_potential_connections_failure(self, client):
        mock_resp = _mock_response(403, text="Forbidden")

        with patch("httpx.AsyncClient") as mock_client_cls:
            mock_http = AsyncMock()
            mock_http.get.return_value = mock_resp
            mock_http.__aenter__ = AsyncMock(return_value=mock_http)
            mock_http.__aexit__ = AsyncMock(return_value=False)
            mock_client_cls.return_value = mock_http

            result = await client.list_potential_connections("IDENTITY_ASSERTION_CUSTOM_AS")

        assert result == []

    @pytest.mark.asyncio
    async def test_list_potential_connections_no_domain(self, monkeypatch):
        monkeypatch.setenv("OKTA_DOMAIN", "")
        from okta_agent_proxy.auth.okta_ai_agent_client import OktaAIAgentClient
        c = OktaAIAgentClient(service_auth=MagicMock())
        result = await c.list_potential_connections("IDENTITY_ASSERTION_CUSTOM_AS")
        assert result == []


# ============================================================================
# Public Key Management
# ============================================================================

class TestPublicKeyManagement:

    @pytest.mark.asyncio
    async def test_add_public_key(self, client):
        jwk = {"kty": "RSA", "n": "abc", "e": "AQAB", "kid": "key-1"}
        mock_resp = _mock_response(201, {"kid": "key-1", "kty": "RSA"})

        with patch("httpx.AsyncClient") as mock_client_cls:
            mock_http = AsyncMock()
            mock_http.post.return_value = mock_resp
            mock_http.__aenter__ = AsyncMock(return_value=mock_http)
            mock_http.__aexit__ = AsyncMock(return_value=False)
            mock_client_cls.return_value = mock_http

            result = await client.add_public_key("agt123", jwk)

        assert result is not None
        assert result["kid"] == "key-1"
        assert "credentials/jwks" in mock_http.post.call_args.args[0]

    @pytest.mark.asyncio
    async def test_add_public_key_failure(self, client):
        mock_resp = _mock_response(400, text="Bad key")

        with patch("httpx.AsyncClient") as mock_client_cls:
            mock_http = AsyncMock()
            mock_http.post.return_value = mock_resp
            mock_http.__aenter__ = AsyncMock(return_value=mock_http)
            mock_http.__aexit__ = AsyncMock(return_value=False)
            mock_client_cls.return_value = mock_http

            result = await client.add_public_key("agt123", {})

        assert result is None

    @pytest.mark.asyncio
    async def test_delete_public_key(self, client):
        mock_resp = _mock_response(204)

        with patch("httpx.AsyncClient") as mock_client_cls:
            mock_http = AsyncMock()
            mock_http.delete.return_value = mock_resp
            mock_http.__aenter__ = AsyncMock(return_value=mock_http)
            mock_http.__aexit__ = AsyncMock(return_value=False)
            mock_client_cls.return_value = mock_http

            result = await client.delete_public_key("agt123", "key-1")

        assert result is True
        assert "credentials/jwks/key-1" in mock_http.delete.call_args.args[0]

    @pytest.mark.asyncio
    async def test_delete_public_key_not_found(self, client):
        mock_resp = _mock_response(404, text="Not found")

        with patch("httpx.AsyncClient") as mock_client_cls:
            mock_http = AsyncMock()
            mock_http.delete.return_value = mock_resp
            mock_http.__aenter__ = AsyncMock(return_value=mock_http)
            mock_http.__aexit__ = AsyncMock(return_value=False)
            mock_client_cls.return_value = mock_http

            result = await client.delete_public_key("agt123", "key-999")

        assert result is False


# ============================================================================
# Agent Lifecycle
# ============================================================================

class TestAgentLifecycle:

    @pytest.mark.asyncio
    async def test_register_agent_sync_response(self, client):
        """Some orgs return 200/201 immediately (no async operation)."""
        mock_resp = _mock_response(201, {"id": "agt-new", "name": "My Agent"})

        with patch("httpx.AsyncClient") as mock_client_cls:
            mock_http = AsyncMock()
            mock_http.post.return_value = mock_resp
            mock_http.__aenter__ = AsyncMock(return_value=mock_http)
            mock_http.__aexit__ = AsyncMock(return_value=False)
            mock_client_cls.return_value = mock_http

            result = await client.register_agent("0oa123", "My Agent", description="Test")

        assert result is not None
        assert result["id"] == "agt-new"

    @pytest.mark.asyncio
    async def test_register_agent_async_operation(self, client):
        """202 Accepted triggers operation polling."""
        mock_202 = _mock_response(202, {"operationId": "op-123"})
        mock_poll = _mock_response(200, {"status": "COMPLETED", "result": {"id": "agt-new"}})

        with patch("httpx.AsyncClient") as mock_client_cls:
            mock_http = AsyncMock()
            mock_http.post.return_value = mock_202
            mock_http.get.return_value = mock_poll
            mock_http.__aenter__ = AsyncMock(return_value=mock_http)
            mock_http.__aexit__ = AsyncMock(return_value=False)
            mock_client_cls.return_value = mock_http

            result = await client.register_agent("0oa123", "My Agent")

        assert result is not None
        assert result["id"] == "agt-new"

    @pytest.mark.asyncio
    async def test_register_agent_failure(self, client):
        mock_resp = _mock_response(500, text="Server Error")

        with patch("httpx.AsyncClient") as mock_client_cls:
            mock_http = AsyncMock()
            mock_http.post.return_value = mock_resp
            mock_http.__aenter__ = AsyncMock(return_value=mock_http)
            mock_http.__aexit__ = AsyncMock(return_value=False)
            mock_client_cls.return_value = mock_http

            result = await client.register_agent("0oa123", "My Agent")

        assert result is None

    @pytest.mark.asyncio
    async def test_activate_agent(self, client):
        mock_resp = _mock_response(200, {"id": "agt123", "status": "ACTIVE"})

        with patch("httpx.AsyncClient") as mock_client_cls:
            mock_http = AsyncMock()
            mock_http.post.return_value = mock_resp
            mock_http.__aenter__ = AsyncMock(return_value=mock_http)
            mock_http.__aexit__ = AsyncMock(return_value=False)
            mock_client_cls.return_value = mock_http

            result = await client.activate_agent("agt123")

        assert result is not None
        assert "lifecycle/activate" in mock_http.post.call_args.args[0]

    @pytest.mark.asyncio
    async def test_deactivate_agent(self, client):
        mock_resp = _mock_response(200, {"id": "agt123", "status": "INACTIVE"})

        with patch("httpx.AsyncClient") as mock_client_cls:
            mock_http = AsyncMock()
            mock_http.post.return_value = mock_resp
            mock_http.__aenter__ = AsyncMock(return_value=mock_http)
            mock_http.__aexit__ = AsyncMock(return_value=False)
            mock_client_cls.return_value = mock_http

            result = await client.deactivate_agent("agt123")

        assert result is not None
        assert "lifecycle/deactivate" in mock_http.post.call_args.args[0]

    @pytest.mark.asyncio
    async def test_delete_agent_resource(self, client):
        mock_resp = _mock_response(204)

        with patch("httpx.AsyncClient") as mock_client_cls:
            mock_http = AsyncMock()
            mock_http.delete.return_value = mock_resp
            mock_http.__aenter__ = AsyncMock(return_value=mock_http)
            mock_http.__aexit__ = AsyncMock(return_value=False)
            mock_client_cls.return_value = mock_http

            result = await client.delete_agent_resource("agt123")

        assert result is True

    @pytest.mark.asyncio
    async def test_delete_agent_resource_failure(self, client):
        mock_resp = _mock_response(404, text="Not Found")

        with patch("httpx.AsyncClient") as mock_client_cls:
            mock_http = AsyncMock()
            mock_http.delete.return_value = mock_resp
            mock_http.__aenter__ = AsyncMock(return_value=mock_http)
            mock_http.__aexit__ = AsyncMock(return_value=False)
            mock_client_cls.return_value = mock_http

            result = await client.delete_agent_resource("agt123")

        assert result is False


# ============================================================================
# Operation Polling
# ============================================================================

class TestPollOperation:

    @pytest.mark.asyncio
    async def test_poll_completed_immediately(self, client):
        mock_resp = _mock_response(200, {"status": "COMPLETED", "result": {"id": "agt-new"}})

        with patch("httpx.AsyncClient") as mock_client_cls:
            mock_http = AsyncMock()
            mock_http.get.return_value = mock_resp
            mock_http.__aenter__ = AsyncMock(return_value=mock_http)
            mock_http.__aexit__ = AsyncMock(return_value=False)
            mock_client_cls.return_value = mock_http

            result = await client.poll_operation("op-123")

        assert result is not None
        assert result["id"] == "agt-new"

    @pytest.mark.asyncio
    async def test_poll_operation_failed(self, client):
        mock_resp = _mock_response(200, {"status": "FAILED", "error": "App not found"})

        with patch("httpx.AsyncClient") as mock_client_cls:
            mock_http = AsyncMock()
            mock_http.get.return_value = mock_resp
            mock_http.__aenter__ = AsyncMock(return_value=mock_http)
            mock_http.__aexit__ = AsyncMock(return_value=False)
            mock_client_cls.return_value = mock_http

            with pytest.raises(RuntimeError, match="App not found"):
                await client.poll_operation("op-123")

    @pytest.mark.asyncio
    async def test_poll_operation_timeout(self, client):
        mock_resp = _mock_response(200, {"status": "IN_PROGRESS"})

        with patch("httpx.AsyncClient") as mock_client_cls, \
             patch("asyncio.sleep", new_callable=AsyncMock):
            mock_http = AsyncMock()
            mock_http.get.return_value = mock_resp
            mock_http.__aenter__ = AsyncMock(return_value=mock_http)
            mock_http.__aexit__ = AsyncMock(return_value=False)
            mock_client_cls.return_value = mock_http

            with pytest.raises(TimeoutError, match="did not complete"):
                await client.poll_operation("op-123", max_wait=4, poll_interval=2)

    @pytest.mark.asyncio
    async def test_poll_operation_no_domain(self, monkeypatch):
        monkeypatch.setenv("OKTA_DOMAIN", "")
        from okta_agent_proxy.auth.okta_ai_agent_client import OktaAIAgentClient
        c = OktaAIAgentClient(service_auth=MagicMock())
        with pytest.raises(RuntimeError, match="OKTA_DOMAIN"):
            await c.poll_operation("op-123")

    @pytest.mark.asyncio
    async def test_poll_retries_on_pending(self, client):
        """Polls multiple times until COMPLETED."""
        pending = _mock_response(200, {"status": "IN_PROGRESS"})
        completed = _mock_response(200, {"status": "COMPLETED", "result": {"id": "done"}})

        call_count = 0

        async def mock_get(*args, **kwargs):
            nonlocal call_count
            call_count += 1
            return completed if call_count >= 2 else pending

        with patch("httpx.AsyncClient") as mock_client_cls, \
             patch("asyncio.sleep", new_callable=AsyncMock):
            mock_http = AsyncMock()
            mock_http.get = mock_get
            mock_http.__aenter__ = AsyncMock(return_value=mock_http)
            mock_http.__aexit__ = AsyncMock(return_value=False)
            mock_client_cls.return_value = mock_http

            result = await client.poll_operation("op-123", max_wait=10, poll_interval=1)

        assert result["id"] == "done"
        assert call_count == 2


# ============================================================================
# Auth header verification
# ============================================================================

class TestAuthHeaders:

    @pytest.mark.asyncio
    async def test_admin_token_passed_as_bearer(self, client):
        """okta_token is passed as Authorization: Bearer header, never via httpx auth=."""
        mock_resp = _mock_response(200, {"id": "conn1"})

        with patch("httpx.AsyncClient") as mock_client_cls:
            mock_http = AsyncMock()
            mock_http.get.return_value = mock_resp
            mock_http.__aenter__ = AsyncMock(return_value=mock_http)
            mock_http.__aexit__ = AsyncMock(return_value=False)
            mock_client_cls.return_value = mock_http

            await client.get_connection("agt123", "conn1", okta_token="my-admin-token")

        call_kwargs = mock_http.get.call_args
        headers = call_kwargs.kwargs.get("headers", {})
        assert headers["Authorization"] == "Bearer my-admin-token"

    @pytest.mark.asyncio
    async def test_service_token_used_when_no_okta_token(self, client, mock_service_auth):
        mock_resp = _mock_response(204)

        with patch("httpx.AsyncClient") as mock_client_cls:
            mock_http = AsyncMock()
            mock_http.delete.return_value = mock_resp
            mock_http.__aenter__ = AsyncMock(return_value=mock_http)
            mock_http.__aexit__ = AsyncMock(return_value=False)
            mock_client_cls.return_value = mock_http

            await client.delete_connection("agt123", "conn1")

        mock_service_auth.get_access_token.assert_called_once()
        call_kwargs = mock_http.delete.call_args
        headers = call_kwargs.kwargs.get("headers", {})
        assert headers["Authorization"] == "Bearer service-token-xxx"


# ============================================================================
# Error handling
# ============================================================================

class TestErrorHandling:

    @pytest.mark.asyncio
    async def test_network_error_returns_none(self, client):
        with patch("httpx.AsyncClient") as mock_client_cls:
            mock_http = AsyncMock()
            mock_http.post.side_effect = httpx.ConnectError("Connection refused")
            mock_http.__aenter__ = AsyncMock(return_value=mock_http)
            mock_http.__aexit__ = AsyncMock(return_value=False)
            mock_client_cls.return_value = mock_http

            result = await client.create_connection("agt123", {})

        assert result is None

    @pytest.mark.asyncio
    async def test_network_error_delete_returns_false(self, client):
        with patch("httpx.AsyncClient") as mock_client_cls:
            mock_http = AsyncMock()
            mock_http.delete.side_effect = httpx.ConnectError("Connection refused")
            mock_http.__aenter__ = AsyncMock(return_value=mock_http)
            mock_http.__aexit__ = AsyncMock(return_value=False)
            mock_client_cls.return_value = mock_http

            result = await client.delete_public_key("agt123", "key-1")

        assert result is False
