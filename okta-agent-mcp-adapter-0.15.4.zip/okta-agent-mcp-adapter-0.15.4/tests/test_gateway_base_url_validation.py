"""
Tests for GATEWAY_BASE_URL validation.

Covers the @field_validator on GatewaySettings.gateway_base_url that enforces
RFC 8414 §3.3 compatible issuer shape: absolute https URL (or loopback http),
no trailing slash, no path/query/fragment.
"""

import pytest

from okta_agent_proxy.config import GatewaySettings


@pytest.fixture(autouse=True)
def _set_required_env(monkeypatch):
    """OKTA_DOMAIN is required before GatewaySettings can be instantiated."""
    monkeypatch.setenv("OKTA_DOMAIN", "dev-test.okta.com")


class TestGatewayBaseUrlAccepted:
    """URLs that must be accepted by the validator."""

    def test_https_host_accepted(self, monkeypatch):
        monkeypatch.setenv("GATEWAY_BASE_URL", "https://example.com")
        settings = GatewaySettings()
        assert settings.gateway_base_url == "https://example.com"

    def test_https_host_with_port_accepted(self, monkeypatch):
        monkeypatch.setenv("GATEWAY_BASE_URL", "https://example.com:8443")
        settings = GatewaySettings()
        assert settings.gateway_base_url == "https://example.com:8443"

    def test_http_localhost_accepted(self, monkeypatch):
        monkeypatch.setenv("GATEWAY_BASE_URL", "http://localhost:8000")
        settings = GatewaySettings()
        assert settings.gateway_base_url == "http://localhost:8000"

    def test_http_127_0_0_1_accepted(self, monkeypatch):
        monkeypatch.setenv("GATEWAY_BASE_URL", "http://127.0.0.1:8000")
        settings = GatewaySettings()
        assert settings.gateway_base_url == "http://127.0.0.1:8000"

    def test_http_ipv6_loopback_accepted(self, monkeypatch):
        monkeypatch.setenv("GATEWAY_BASE_URL", "http://[::1]:8000")
        settings = GatewaySettings()
        assert settings.gateway_base_url == "http://[::1]:8000"

    def test_http_localhost_subdomain_accepted(self, monkeypatch):
        """RFC 6761 §6.3 — *.localhost is reserved for loopback."""
        monkeypatch.setenv("GATEWAY_BASE_URL", "http://app.localhost:8000")
        settings = GatewaySettings()
        assert settings.gateway_base_url == "http://app.localhost:8000"

    def test_default_value_passes_validation(self, monkeypatch):
        """The default http://localhost:8000 must remain valid."""
        monkeypatch.delenv("GATEWAY_BASE_URL", raising=False)
        settings = GatewaySettings()
        assert settings.gateway_base_url == "http://localhost:8000"


class TestGatewayBaseUrlRejected:
    """URLs that must be rejected by the validator."""

    def test_http_localhost_phishing_rejected(self, monkeypatch):
        """'localhost.evil.com' is NOT a loopback host — the label is
        'com', not 'localhost'. Must be rejected."""
        monkeypatch.setenv("GATEWAY_BASE_URL", "http://localhost.evil.com")
        with pytest.raises(Exception, match="https:// or a loopback host"):
            GatewaySettings()

    def test_http_public_host_rejected(self, monkeypatch):
        monkeypatch.setenv("GATEWAY_BASE_URL", "http://example.com")
        with pytest.raises(Exception, match="https:// or a loopback host"):
            GatewaySettings()

    def test_http_lan_ip_rejected(self, monkeypatch):
        """RFC 6761 does not classify RFC 1918 LAN IPs as loopback."""
        monkeypatch.setenv("GATEWAY_BASE_URL", "http://192.168.1.50:8000")
        with pytest.raises(Exception, match="https:// or a loopback host"):
            GatewaySettings()

    def test_trailing_slash_rejected(self, monkeypatch):
        monkeypatch.setenv("GATEWAY_BASE_URL", "https://example.com/")
        with pytest.raises(Exception, match="trailing slash"):
            GatewaySettings()

    def test_path_component_rejected(self, monkeypatch):
        monkeypatch.setenv("GATEWAY_BASE_URL", "https://example.com/foo")
        with pytest.raises(Exception, match="path component"):
            GatewaySettings()

    def test_query_string_rejected(self, monkeypatch):
        monkeypatch.setenv("GATEWAY_BASE_URL", "https://example.com?x=1")
        with pytest.raises(Exception, match="query string"):
            GatewaySettings()

    def test_fragment_rejected(self, monkeypatch):
        monkeypatch.setenv("GATEWAY_BASE_URL", "https://example.com#frag")
        with pytest.raises(Exception, match="fragment"):
            GatewaySettings()

    def test_ftp_scheme_rejected(self, monkeypatch):
        monkeypatch.setenv("GATEWAY_BASE_URL", "ftp://example.com")
        with pytest.raises(Exception, match="http:// or https://"):
            GatewaySettings()

    def test_missing_scheme_rejected(self, monkeypatch):
        monkeypatch.setenv("GATEWAY_BASE_URL", "example.com")
        with pytest.raises(Exception):
            GatewaySettings()

    def test_empty_string_rejected(self, monkeypatch):
        monkeypatch.setenv("GATEWAY_BASE_URL", "")
        with pytest.raises(Exception):
            GatewaySettings()
