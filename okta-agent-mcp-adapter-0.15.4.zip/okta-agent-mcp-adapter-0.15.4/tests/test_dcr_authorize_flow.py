"""Tests for DCR agent selection flow in oauth_authorize + new endpoints.

Validates:
- DCR authorize with linked agent relays through to Okta
- Unlinked DCR with single selectable agent auto-links
- Unlinked DCR with multiple selectable agents redirects to selection page
- Unlinked DCR with no selectable agents returns 503
- /oauth/dcr-select renders HTML with agent options
- /oauth/dcr-link binds agent and resumes authorize flow
- Selection sessions are cross-instance (CacheService) and consumed once
- Audit events emitted for all significant actions
- Pre-registered and CIMD authorize flows are unchanged (regression)
"""

import json
import sys
from datetime import datetime, timezone
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from okta_agent_proxy.audit.events import AuditEventType, AuditSeverity
from okta_agent_proxy.auth.cimd_fetcher import CIMDMetadata
from okta_agent_proxy.auth.client_registry import ClientInfo
from okta_agent_proxy.auth.confidential_relay import RelayError


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _dcr_client_info(
    client_id="dcr_abc123",
    agent_config=None,
    redirect_uris=None,
):
    return ClientInfo(
        client_id=client_id,
        client_name="Test DCR Client",
        registration_source="dcr",
        redirect_uris=redirect_uris or ["http://localhost:9999/callback"],
        grant_types=["authorization_code"],
        response_types=["code"],
        token_endpoint_auth_method="none",
        jwks_uri=None,
        scope=None,
        trust_level=None,
        agent_config=agent_config,
        cimd_metadata=None,
        resource_access=[],
    )


def _cimd_client_info(client_id="https://example.com/oauth.json"):
    return ClientInfo(
        client_id=client_id,
        client_name="CIMD Client",
        registration_source="cimd",
        redirect_uris=["http://localhost:9999/callback"],
        grant_types=["authorization_code"],
        response_types=["code"],
        token_endpoint_auth_method="none",
        jwks_uri=None,
        scope=None,
        trust_level="trusted",
        agent_config={"client_id": "0oa_cimd", "client_secret": "cimd_secret"},
        cimd_metadata=CIMDMetadata(
            client_id=client_id,
            client_name="CIMD Client",
            redirect_uris=["http://localhost:9999/callback"],
            grant_types=["authorization_code"],
            response_types=["code"],
            token_endpoint_auth_method="none",
            jwks_uri=None,
            logo_uri=None,
            client_uri=None,
            scope=None,
            domain="example.com",
            fetched_at=datetime.now(timezone.utc),
            raw_json={},
        ),
        resource_access=[],
    )


_AUTH_QS = {
    "client_id": "dcr_abc123",
    "redirect_uri": "http://localhost:9999/callback",
    "state": "test-state",
    "scope": "openid offline_access",
    "response_type": "code",
}


def _mock_request(query_params=None, form_data=None):
    req = MagicMock()
    req.query_params = query_params or {}

    async def _form():
        return form_data or {}

    req.form = _form
    return req


# ---------------------------------------------------------------------------
# Fixture: force-import app.py with mocked database, then patch handlers
# ---------------------------------------------------------------------------

def _ensure_app_imported():
    """Ensure okta_agent_proxy.app is fully importable by mocking the DB if needed."""
    mod = sys.modules.get("okta_agent_proxy.app")
    if mod is not None and hasattr(mod, "client_registry"):
        return  # Fully loaded

    # Remove partial module so re-import works
    sys.modules.pop("okta_agent_proxy.app", None)

    # The module-level code in app.py calls get_config_store() which needs PostgreSQL.
    # We mock it to return a MagicMock store, allowing the module to load.
    import okta_agent_proxy.database as _db_mod
    _orig_get = _db_mod.get_config_store
    _orig_store = _db_mod._config_store
    _mock_store = MagicMock()
    _mock_store.get_all_resources.return_value = []
    _mock_store.get_all_agents.return_value = []
    _db_mod.get_config_store = lambda **kw: _mock_store
    _db_mod._config_store = _mock_store
    try:
        import importlib
        import okta_agent_proxy.app
        importlib.reload(okta_agent_proxy.app)
    except Exception:
        sys.modules.pop("okta_agent_proxy.app", None)
        raise
    finally:
        _db_mod.get_config_store = _orig_get
        _db_mod._config_store = _orig_store


@pytest.fixture
def patched():
    """Patch all app-level deps. Mocks DB to allow import without PostgreSQL."""
    _ensure_app_imported()

    # Now the module is loaded, we can patch its attributes
    patches_to_start = [
        patch("okta_agent_proxy.app.client_registry"),
        patch("okta_agent_proxy.app.confidential_relay"),
        patch("okta_agent_proxy.app.dcr_handler"),
        patch("okta_agent_proxy.app.emit_audit_event", new_callable=AsyncMock),
        patch("okta_agent_proxy.app.cache_service"),
        patch("okta_agent_proxy.app.config"),
        patch("okta_agent_proxy.app.cimd_fetcher"),
    ]

    started = [p.start() for p in patches_to_start]
    mocks = {
        "registry": started[0],
        "relay": started[1],
        "dcr": started[2],
        "audit": started[3],
        "cache": started[4],
        "config": started[5],
        "cimd_fetcher": started[6],
    }

    # Defaults
    mocks["registry"].resolve = AsyncMock(return_value=None)
    mocks["registry"]._resolve_dcr = MagicMock(return_value=None)
    mocks["registry"]._is_cimd_url = staticmethod(
        lambda cid: cid.startswith("https://") or cid.startswith("http://localhost")
    )
    mocks["relay"].start_authorization = AsyncMock(
        return_value="https://okta.example.com/authorize?x=1"
    )
    mocks["dcr"].get_selectable_agents = MagicMock(return_value=[])
    mocks["dcr"].link_to_agent = AsyncMock(return_value=(True, "Linked"))

    # Cache: in-memory dict
    _store = {}

    async def _set(k, v, ttl_seconds=None):
        _store[k] = v

    async def _get(k):
        return _store.get(k)

    async def _delete(k):
        _store.pop(k, None)

    mocks["cache"].set = _set
    mocks["cache"].get = _get
    mocks["cache"].delete = _delete
    mocks["_store"] = _store

    mocks["config"].gateway.okta_domain = "dev-test.okta.com"

    yield mocks

    for p in patches_to_start:
        p.stop()


def _handlers():
    from okta_agent_proxy.app import oauth_authorize, oauth_dcr_select, oauth_dcr_link
    return oauth_authorize, oauth_dcr_select, oauth_dcr_link


# ---------------------------------------------------------------------------
# DCR Authorize: Linked agent relays
# ---------------------------------------------------------------------------

class TestDCRAuthorizeLinked:

    async def test_dcr_authorize_linked_routes_through_relay(self, patched):
        patched["registry"]._resolve_dcr.return_value = _dcr_client_info(
            agent_config={
                "agent_name": "dcr-dcr_abc123",
                "client_id": "0oa_real_client",
                "client_secret": "real_secret",
            },
        )
        authorize, _, _ = _handlers()
        resp = await authorize(_mock_request(query_params=_AUTH_QS))
        assert resp.status_code == 302
        patched["relay"].start_authorization.assert_called_once()
        assert patched["relay"].start_authorization.call_args[1]["relay_client_id"] == "0oa_real_client"

    async def test_dcr_audit_authorize_relayed(self, patched):
        patched["registry"]._resolve_dcr.return_value = _dcr_client_info(
            agent_config={
                "agent_name": "dcr-dcr_abc123",
                "client_id": "0oa_real_client",
                "client_secret": "real_secret",
            },
        )
        authorize, _, _ = _handlers()
        await authorize(_mock_request(query_params=_AUTH_QS))
        audit_calls = [
            c for c in patched["audit"].call_args_list
            if c[0][0] == AuditEventType.DCR_AUTHORIZE_RELAYED
        ]
        assert len(audit_calls) == 1
        assert audit_calls[0][1]["details"]["dcr_client_id"] == "dcr_abc123"

    async def test_dcr_audit_authorize_relay_failed(self, patched):
        patched["registry"]._resolve_dcr.return_value = _dcr_client_info(
            agent_config={
                "agent_name": "dcr-dcr_abc123",
                "client_id": "0oa_real_client",
                "client_secret": "real_secret",
            },
        )
        patched["relay"].start_authorization = AsyncMock(
            side_effect=RelayError("redirect_uri not allowed")
        )
        authorize, _, _ = _handlers()
        resp = await authorize(_mock_request(query_params=_AUTH_QS))
        assert resp.status_code == 400
        audit_calls = [
            c for c in patched["audit"].call_args_list
            if c[0][0] == AuditEventType.DCR_AUTHORIZE_RELAY_FAILED
        ]
        assert len(audit_calls) == 1
        assert audit_calls[0][1]["severity"] == AuditSeverity.WARNING


# ---------------------------------------------------------------------------
# DCR Authorize: Unlinked agent selection
# ---------------------------------------------------------------------------

class TestDCRAuthorizeUnlinked:

    async def test_dcr_authorize_unlinked_single_selectable_auto_links(self, patched):
        patched["registry"]._resolve_dcr.return_value = _dcr_client_info(
            agent_config={
                "agent_name": "dcr-dcr_abc123",
                "client_id": "dcr_abc123",
                "client_secret": "placeholder_secret",
            },
        )
        patched["dcr"].get_selectable_agents.return_value = [
            {"agent_name": "imported-agent", "client_id": "0oa_real", "client_secret": "s"}
        ]
        authorize, _, _ = _handlers()
        resp = await authorize(_mock_request(query_params=_AUTH_QS))
        assert resp.status_code == 302
        patched["dcr"].link_to_agent.assert_called_once_with(
            "dcr_abc123", "imported-agent", user="auto-link"
        )
        assert "/oauth/authorize" in resp.headers["location"]

    async def test_dcr_authorize_unlinked_multiple_selectable_redirects_to_select(self, patched):
        patched["registry"]._resolve_dcr.return_value = _dcr_client_info(
            agent_config={
                "agent_name": "dcr-dcr_abc123",
                "client_id": "dcr_abc123",
                "client_secret": "placeholder",
            },
        )
        patched["dcr"].get_selectable_agents.return_value = [
            {"agent_name": "agent-a", "client_id": "0oa_a", "client_secret": "sa"},
            {"agent_name": "agent-b", "client_id": "0oa_b", "client_secret": "sb"},
        ]
        authorize, _, _ = _handlers()
        resp = await authorize(_mock_request(query_params=_AUTH_QS))
        assert resp.status_code == 302
        loc = resp.headers["location"]
        assert "/oauth/dcr-select" in loc
        assert "session=" in loc

    async def test_dcr_authorize_unlinked_no_selectable_returns_503(self, patched):
        patched["registry"]._resolve_dcr.return_value = _dcr_client_info(
            agent_config={
                "agent_name": "dcr-dcr_abc123",
                "client_id": "dcr_abc123",
                "client_secret": "placeholder",
            },
        )
        patched["dcr"].get_selectable_agents.return_value = []
        authorize, _, _ = _handlers()
        resp = await authorize(_mock_request(query_params=_AUTH_QS))
        assert resp.status_code == 503

    async def test_dcr_audit_selection_shown(self, patched):
        patched["registry"]._resolve_dcr.return_value = _dcr_client_info(
            agent_config={
                "agent_name": "dcr-dcr_abc123",
                "client_id": "dcr_abc123",
                "client_secret": "placeholder",
            },
        )
        patched["dcr"].get_selectable_agents.return_value = [
            {"agent_name": "agent-a", "client_id": "0oa_a", "client_secret": "sa"},
            {"agent_name": "agent-b", "client_id": "0oa_b", "client_secret": "sb"},
        ]
        authorize, _, _ = _handlers()
        await authorize(_mock_request(query_params=_AUTH_QS))
        audit_calls = [
            c for c in patched["audit"].call_args_list
            if c[0][0] == AuditEventType.DCR_AGENT_SELECTION_SHOWN
        ]
        assert len(audit_calls) == 1
        assert set(audit_calls[0][1]["details"]["selectable_agents"]) == {"agent-a", "agent-b"}

    async def test_dcr_audit_selection_failed_no_agents(self, patched):
        patched["registry"]._resolve_dcr.return_value = _dcr_client_info(
            agent_config={
                "agent_name": "dcr-dcr_abc123",
                "client_id": "dcr_abc123",
                "client_secret": "placeholder",
            },
        )
        patched["dcr"].get_selectable_agents.return_value = []
        authorize, _, _ = _handlers()
        await authorize(_mock_request(query_params=_AUTH_QS))
        audit_calls = [
            c for c in patched["audit"].call_args_list
            if c[0][0] == AuditEventType.DCR_AGENT_SELECTION_FAILED
        ]
        assert len(audit_calls) == 1
        assert audit_calls[0][1]["details"]["reason"] == "no_selectable_agents"


# ---------------------------------------------------------------------------
# /oauth/dcr-select page
# ---------------------------------------------------------------------------

class TestDCRSelectPage:

    async def test_dcr_select_page_renders(self, patched):
        session_id = "test-session-123"
        patched["_store"][f"dcr_select:{session_id}"] = json.dumps({
            "dcr_client_id": "dcr_abc123",
            "client_name": "Test Client",
            "original_params": _AUTH_QS,
        })
        patched["dcr"].get_selectable_agents.return_value = [
            {"agent_name": "agent-a"},
            {"agent_name": "agent-b"},
        ]
        _, select, _ = _handlers()
        resp = await select(_mock_request(query_params={"session": session_id}))
        assert resp.status_code == 200
        body = resp.body.decode()
        assert "agent-a" in body
        assert "agent-b" in body
        assert "Test Client" in body

    async def test_dcr_select_page_expired_session(self, patched):
        _, select, _ = _handlers()
        resp = await select(_mock_request(query_params={"session": "expired"}))
        assert resp.status_code == 400
        assert "expired" in resp.body.decode().lower()


# ---------------------------------------------------------------------------
# /oauth/dcr-link handler
# ---------------------------------------------------------------------------

class TestDCRLink:

    async def test_dcr_link_binds_and_resumes(self, patched):
        session_id = "link-session-456"
        patched["_store"][f"dcr_select:{session_id}"] = json.dumps({
            "dcr_client_id": "dcr_abc123",
            "client_name": "Test Client",
            "original_params": _AUTH_QS,
        })
        patched["dcr"].link_to_agent = AsyncMock(return_value=(True, "Linked"))
        _, _, link = _handlers()
        resp = await link(_mock_request(form_data={"session": session_id, "agent_name": "imported-agent"}))
        assert resp.status_code == 302
        assert "/oauth/authorize" in resp.headers["location"]
        patched["dcr"].link_to_agent.assert_called_once_with(
            "dcr_abc123", "imported-agent", user="dcr-select"
        )

    async def test_dcr_link_invalid_agent_rejected(self, patched):
        session_id = "link-session-789"
        patched["_store"][f"dcr_select:{session_id}"] = json.dumps({
            "dcr_client_id": "dcr_abc123",
            "client_name": "Test Client",
            "original_params": _AUTH_QS,
        })
        patched["dcr"].link_to_agent = AsyncMock(
            return_value=(False, "Target agent is not selectable for DCR linking")
        )
        _, _, link = _handlers()
        resp = await link(_mock_request(form_data={"session": session_id, "agent_name": "bad-agent"}))
        assert resp.status_code == 400
        body = json.loads(resp.body)
        assert "not selectable" in body["error_description"]

    async def test_dcr_link_audit_on_failure(self, patched):
        session_id = "link-session-audit"
        patched["_store"][f"dcr_select:{session_id}"] = json.dumps({
            "dcr_client_id": "dcr_abc123",
            "client_name": "Test Client",
            "original_params": _AUTH_QS,
        })
        patched["dcr"].link_to_agent = AsyncMock(return_value=(False, "No creds"))
        _, _, link = _handlers()
        await link(_mock_request(form_data={"session": session_id, "agent_name": "bad-agent"}))
        audit_calls = [
            c for c in patched["audit"].call_args_list
            if c[0][0] == AuditEventType.DCR_AGENT_SELECTION_FAILED
        ]
        assert len(audit_calls) == 1


# ---------------------------------------------------------------------------
# Selection session cross-instance and one-time use
# ---------------------------------------------------------------------------

class TestDCRSelectionSession:

    async def test_dcr_selection_session_cross_instance(self, patched):
        from okta_agent_proxy.app import (
            _store_dcr_selection_session,
            _get_dcr_selection_session,
        )
        await _store_dcr_selection_session("state123", {"foo": "bar"})
        result = await _get_dcr_selection_session("state123")
        assert result == {"foo": "bar"}

    async def test_dcr_selection_session_consumed_once(self, patched):
        from okta_agent_proxy.app import (
            _store_dcr_selection_session,
            _consume_dcr_selection_session,
        )
        await _store_dcr_selection_session("state456", {"x": 1})
        result = await _consume_dcr_selection_session("state456")
        assert result == {"x": 1}

        result2 = await _consume_dcr_selection_session("state456")
        assert result2 is None


# ---------------------------------------------------------------------------
# Regression: Pre-registered and CIMD flows unchanged
# ---------------------------------------------------------------------------

class TestOAuthAuthorizeRegression:

    async def test_oauth_authorize_pre_registered_unchanged(self, patched):
        patched["registry"]._resolve_dcr.return_value = None
        authorize, _, _ = _handlers()
        resp = await authorize(_mock_request(query_params={
            "client_id": "0oa_pre_registered",
            "redirect_uri": "http://localhost:9999/callback",
            "state": "s",
            "scope": "openid",
            "response_type": "code",
        }))
        assert resp.status_code == 302
        location = resp.headers["location"]
        assert "/oauth/dcr-select" not in location
        assert "0oa_pre_registered" in location

    async def test_oauth_authorize_cimd_unchanged(self, patched):
        cimd_info = _cimd_client_info()
        patched["registry"].resolve = AsyncMock(return_value=cimd_info)
        authorize, _, _ = _handlers()
        resp = await authorize(_mock_request(query_params={
            "client_id": "https://example.com/oauth.json",
            "redirect_uri": "http://localhost:9999/callback",
            "state": "s",
            "scope": "openid",
            "response_type": "code",
        }))
        assert resp.status_code == 302
        patched["relay"].start_authorization.assert_called_once()
        patched["registry"]._resolve_dcr.assert_not_called()
