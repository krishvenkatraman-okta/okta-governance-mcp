"""
Tests for the Adapter CIMD Server.

Validates:
- CIMD metadata document structure and correctness
- JWKS endpoint with public key only (no private components)
- Client assertion JWT signing and verification
- Auto-generated key pair when ADAPTER_SIGNING_KEY not set
- Custom key loading from JWK JSON string
"""

import json
import time
from unittest.mock import patch

import pytest
from jose import jwt

from okta_agent_proxy.auth.adapter_cimd import AdapterCIMDServer, _generate_rsa_keypair


class TestAdapterCIMDMetadata:
    """Tests for the CIMD metadata document."""

    def test_metadata_has_correct_client_id(self):
        """client_id matches the metadata document URL."""
        server = AdapterCIMDServer(base_url="https://gateway.example.com")
        metadata = server.get_client_metadata()
        assert metadata["client_id"] == "https://gateway.example.com/oauth/client-metadata.json"

    def test_metadata_has_required_fields(self):
        """Metadata includes all RFC 7591 / CIMD fields."""
        server = AdapterCIMDServer(base_url="https://gateway.example.com")
        metadata = server.get_client_metadata()
        assert metadata["client_name"] == "Okta MCP Adapter"
        assert metadata["client_uri"] == "https://gateway.example.com"
        assert metadata["redirect_uris"] == ["https://gateway.example.com/oauth/backend-callback"]
        assert "authorization_code" in metadata["grant_types"]
        assert "refresh_token" in metadata["grant_types"]
        assert metadata["response_types"] == ["code"]
        assert metadata["token_endpoint_auth_method"] == "private_key_jwt"
        assert metadata["jwks_uri"] == "https://gateway.example.com/oauth/jwks.json"
        assert "scope" in metadata

    def test_metadata_scope_includes_mcp(self):
        """Scope includes MCP-specific scopes."""
        server = AdapterCIMDServer(base_url="https://gateway.example.com")
        metadata = server.get_client_metadata()
        scope = metadata["scope"]
        assert "mcp:read" in scope
        assert "mcp:write" in scope
        assert "openid" in scope

    def test_metadata_trailing_slash_stripped(self):
        """Trailing slashes on base_url are stripped."""
        server = AdapterCIMDServer(base_url="https://gateway.example.com/")
        metadata = server.get_client_metadata()
        assert "example.com//" not in metadata["client_id"]
        assert metadata["client_uri"] == "https://gateway.example.com"

    def test_client_id_property(self):
        """client_id property returns the CIMD URL."""
        server = AdapterCIMDServer(base_url="https://gw.test")
        assert server.client_id == "https://gw.test/oauth/client-metadata.json"


class TestAdapterJWKS:
    """Tests for the JWKS endpoint."""

    def test_jwks_has_one_key(self):
        """JWKS contains at least one key."""
        server = AdapterCIMDServer(base_url="https://gw.test")
        jwks = server.get_jwks()
        assert "keys" in jwks
        assert len(jwks["keys"]) >= 1

    def test_jwks_key_is_rsa(self):
        """JWKS key is RSA with required public fields."""
        server = AdapterCIMDServer(base_url="https://gw.test")
        key = server.get_jwks()["keys"][0]
        assert key["kty"] == "RSA"
        assert key["use"] == "sig"
        assert "kid" in key
        assert "n" in key
        assert "e" in key

    def test_jwks_has_no_private_components(self):
        """JWKS does not expose private key material."""
        server = AdapterCIMDServer(base_url="https://gw.test")
        key = server.get_jwks()["keys"][0]
        private_fields = {"d", "p", "q", "dp", "dq", "qi"}
        assert not private_fields.intersection(key.keys()), (
            f"JWKS exposes private fields: {private_fields.intersection(key.keys())}"
        )


class TestClientAssertion:
    """Tests for client assertion JWT signing."""

    def test_sign_client_assertion_produces_jwt(self):
        """sign_client_assertion returns a valid JWT string."""
        server = AdapterCIMDServer(base_url="https://gw.test")
        assertion = server.sign_client_assertion("https://backend.example.com/oauth2/v1/token")
        assert isinstance(assertion, str)
        parts = assertion.split(".")
        assert len(parts) == 3  # header.payload.signature

    def test_assertion_claims(self):
        """Assertion contains correct iss, sub, aud, jti, iat, exp claims."""
        server = AdapterCIMDServer(base_url="https://gw.test")
        audience = "https://backend.example.com/oauth2/v1/token"
        assertion = server.sign_client_assertion(audience)

        # Verify using the public key from JWKS
        jwks = server.get_jwks()
        claims = jwt.decode(
            assertion,
            jwks["keys"][0],
            algorithms=["RS256"],
            audience=audience,
        )
        assert claims["iss"] == "https://gw.test/oauth/client-metadata.json"
        assert claims["sub"] == "https://gw.test/oauth/client-metadata.json"
        assert claims["aud"] == audience
        assert "jti" in claims
        assert "iat" in claims
        assert "exp" in claims

    def test_assertion_expiry_is_5_minutes(self):
        """Assertion expires ~300 seconds from now."""
        server = AdapterCIMDServer(base_url="https://gw.test")
        assertion = server.sign_client_assertion("https://backend.test/token")
        jwks = server.get_jwks()
        claims = jwt.decode(
            assertion,
            jwks["keys"][0],
            algorithms=["RS256"],
            audience="https://backend.test/token",
        )
        assert 295 <= (claims["exp"] - claims["iat"]) <= 305

    def test_assertion_kid_in_header(self):
        """JWT header includes kid matching the JWKS key."""
        server = AdapterCIMDServer(base_url="https://gw.test")
        assertion = server.sign_client_assertion("https://backend.test/token")
        header = jwt.get_unverified_header(assertion)
        jwks_kid = server.get_jwks()["keys"][0]["kid"]
        assert header["kid"] == jwks_kid

    def test_assertion_verifiable_with_jwks_public_key(self):
        """JWT can be verified using only the public key from the JWKS endpoint."""
        server = AdapterCIMDServer(base_url="https://gw.test")
        audience = "https://backend.test/token"
        assertion = server.sign_client_assertion(audience)
        jwks = server.get_jwks()

        # This should not raise
        claims = jwt.decode(
            assertion,
            jwks["keys"][0],
            algorithms=["RS256"],
            audience=audience,
        )
        assert claims["iss"] == server.client_id


class TestKeyGeneration:
    """Tests for key generation and loading."""

    def test_auto_generated_key_when_no_env(self):
        """When ADAPTER_SIGNING_KEY is not set, a key pair is auto-generated."""
        with patch.dict("os.environ", {}, clear=False):
            # Remove the env var if present
            env = {k: v for k, v in __import__("os").environ.items() if k != "ADAPTER_SIGNING_KEY"}
            with patch.dict("os.environ", env, clear=True):
                server = AdapterCIMDServer(base_url="https://gw.test")
                jwks = server.get_jwks()
                assert len(jwks["keys"]) == 1
                assert jwks["keys"][0]["kty"] == "RSA"

    def test_load_key_from_jwk_json(self):
        """Loading a key from a JWK JSON string works."""
        # Generate a test key
        test_jwk = _generate_rsa_keypair()
        jwk_json = json.dumps(test_jwk)

        server = AdapterCIMDServer(base_url="https://gw.test", signing_key_raw=jwk_json)
        jwks = server.get_jwks()
        assert jwks["keys"][0]["n"] == test_jwk["n"]

    def test_generated_key_has_kid(self):
        """Auto-generated key includes a kid."""
        jwk = _generate_rsa_keypair()
        assert "kid" in jwk
        assert jwk["kid"].startswith("adapter-")

    def test_different_instances_get_different_keys(self):
        """Each instance gets a unique auto-generated key."""
        server1 = AdapterCIMDServer(base_url="https://gw.test")
        server2 = AdapterCIMDServer(base_url="https://gw.test")
        kid1 = server1.get_jwks()["keys"][0]["kid"]
        kid2 = server2.get_jwks()["keys"][0]["kid"]
        # Very unlikely to collide with UUID-based kid
        assert kid1 != kid2

    def test_fallback_to_gateway_base_url(self):
        """Falls back to GATEWAY_BASE_URL when ADAPTER_CIMD_BASE_URL not set."""
        with patch.dict("os.environ", {"GATEWAY_BASE_URL": "https://fallback.example.com"}):
            server = AdapterCIMDServer()
            assert "fallback.example.com" in server.client_id
