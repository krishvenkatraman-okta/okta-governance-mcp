"""
Tests for admin-API acceptance of Okta service-app tokens.

Covers the client_credentials + private_key_jwt path used by CI/CD:
- service-app claim shape projects into the expected admin payload
- non-allowlisted cid is rejected
- missing cid claim is rejected
- client_id_var is populated so audit events carry actor.client_id
- human token path is unchanged
"""

import pytest
from unittest.mock import patch, AsyncMock

from okta_agent_proxy.admin.auth import verify_okta_token
from okta_agent_proxy.admin.middleware import admin_required
from okta_agent_proxy.audit.context import client_id_var, user_id_var


SERVICE_CID = "0oaServiceAppTest123"


@pytest.fixture(autouse=True)
def _okta_domain(monkeypatch):
    monkeypatch.setenv("OKTA_DOMAIN", "dev-test.okta.com")


@pytest.fixture
def _allowlist(monkeypatch):
    monkeypatch.setenv("ADMIN_API_SERVICE_CLIENT_IDS", SERVICE_CID)


def _service_app_claims(cid: str = SERVICE_CID, scopes=("okta_mcp_adapter.admin",)):
    """Shape of claims returned by Okta for a client_credentials token."""
    return {
        "iss": "https://dev-test.okta.com",
        "sub": cid,
        "cid": cid,
        "scp": list(scopes),
        "exp": 9999999999,
        "iat": 1700000000,
    }


def _user_claims():
    return {
        "iss": "https://dev-test.okta.com",
        "sub": "00uUserId",
        "email": "alice@example.com",
        "preferred_username": "alice@example.com",
        "name": "Alice Admin",
        "exp": 9999999999,
        "iat": 1700000000,
    }


# ---------------------------------------------------------------------------
# verify_okta_token — service-app happy path
# ---------------------------------------------------------------------------

@pytest.mark.asyncio
async def test_service_app_token_allowlisted(_allowlist):
    with patch(
        "okta_agent_proxy.auth.okta_validator.OktaTokenValidator.validate_token",
        new_callable=AsyncMock,
    ) as mock_validate:
        mock_validate.return_value = _service_app_claims()
        payload = await verify_okta_token("any-token")

    assert payload is not None
    assert payload["principal_type"] == "service_app"
    assert payload["cid"] == SERVICE_CID
    assert payload["sub"] == SERVICE_CID
    assert payload["username"] == f"service_app:{SERVICE_CID}"
    assert payload["email"] is None
    assert payload["role"] == "admin"
    # Keeps _check_okta_auth() in okta_import_routes.py passing.
    assert payload["token_type"] == "okta_oauth"
    assert payload["scopes"] == ["okta_mcp_adapter.admin"]


@pytest.mark.asyncio
async def test_service_app_token_scopes_from_space_string(_allowlist):
    claims = _service_app_claims()
    claims["scp"] = "okta_mcp_adapter.admin okta_mcp_adapter.read"
    with patch(
        "okta_agent_proxy.auth.okta_validator.OktaTokenValidator.validate_token",
        new_callable=AsyncMock,
    ) as mock_validate:
        mock_validate.return_value = claims
        payload = await verify_okta_token("any-token")

    assert payload is not None
    assert payload["scopes"] == ["okta_mcp_adapter.admin", "okta_mcp_adapter.read"]


# ---------------------------------------------------------------------------
# verify_okta_token — service-app rejection paths
# ---------------------------------------------------------------------------

@pytest.mark.asyncio
async def test_service_app_token_rejected_when_allowlist_unset(monkeypatch):
    monkeypatch.delenv("ADMIN_API_SERVICE_CLIENT_IDS", raising=False)
    with patch(
        "okta_agent_proxy.auth.okta_validator.OktaTokenValidator.validate_token",
        new_callable=AsyncMock,
    ) as mock_validate:
        mock_validate.return_value = _service_app_claims()
        payload = await verify_okta_token("any-token")

    assert payload is None


@pytest.mark.asyncio
async def test_service_app_token_rejected_when_cid_not_in_allowlist(monkeypatch):
    monkeypatch.setenv("ADMIN_API_SERVICE_CLIENT_IDS", "0oaOtherAppOnly")
    with patch(
        "okta_agent_proxy.auth.okta_validator.OktaTokenValidator.validate_token",
        new_callable=AsyncMock,
    ) as mock_validate:
        mock_validate.return_value = _service_app_claims()
        payload = await verify_okta_token("any-token")

    assert payload is None


@pytest.mark.asyncio
async def test_service_app_token_allowlist_tolerates_whitespace(monkeypatch):
    monkeypatch.setenv(
        "ADMIN_API_SERVICE_CLIENT_IDS",
        f"  0oaOther ,  {SERVICE_CID}  ,",
    )
    with patch(
        "okta_agent_proxy.auth.okta_validator.OktaTokenValidator.validate_token",
        new_callable=AsyncMock,
    ) as mock_validate:
        mock_validate.return_value = _service_app_claims()
        payload = await verify_okta_token("any-token")

    assert payload is not None
    assert payload["cid"] == SERVICE_CID


# ---------------------------------------------------------------------------
# verify_okta_token — human token path unchanged
# ---------------------------------------------------------------------------

@pytest.mark.asyncio
async def test_user_token_unchanged(_allowlist):
    with patch(
        "okta_agent_proxy.auth.okta_validator.OktaTokenValidator.validate_token",
        new_callable=AsyncMock,
    ) as mock_validate:
        mock_validate.return_value = _user_claims()
        payload = await verify_okta_token("any-token")

    assert payload is not None
    assert payload["principal_type"] == "user"
    assert payload["email"] == "alice@example.com"
    assert payload["username"] == "alice@example.com"
    assert payload.get("cid") is None
    assert payload["token_type"] == "okta_oauth"
    assert payload["role"] == "admin"


@pytest.mark.asyncio
async def test_validator_returns_none_yields_none(_allowlist):
    with patch(
        "okta_agent_proxy.auth.okta_validator.OktaTokenValidator.validate_token",
        new_callable=AsyncMock,
    ) as mock_validate:
        mock_validate.return_value = None
        payload = await verify_okta_token("any-token")

    assert payload is None


# ---------------------------------------------------------------------------
# admin_required — audit context gets client_id for service-app tokens
# ---------------------------------------------------------------------------

@pytest.mark.asyncio
async def test_admin_required_sets_client_id_var_for_service_app(_allowlist):
    """Service-app requests populate client_id_var so audit events record cid."""
    captured = {}

    @admin_required
    async def handler(request):
        captured["user_id"] = user_id_var.get()
        captured["client_id"] = client_id_var.get()
        from starlette.responses import JSONResponse
        return JSONResponse({"ok": True})

    class _Req:
        method = "GET"
        headers = {"authorization": "Bearer stub"}

        class _Url:
            path = "/api/admin/test"

        url = _Url()

        class _State:
            pass

        state = _State()

    req = _Req()

    # Reset contextvars before the call so we measure only what the middleware sets.
    user_id_var.set(None)
    client_id_var.set(None)

    with patch(
        "okta_agent_proxy.admin.middleware.verify_okta_token",
        new_callable=AsyncMock,
    ) as mock_verify:
        mock_verify.return_value = {
            "sub": SERVICE_CID,
            "username": f"service_app:{SERVICE_CID}",
            "cid": SERVICE_CID,
            "principal_type": "service_app",
            "role": "admin",
            "token_type": "okta_oauth",
        }
        resp = await handler(req)

    assert resp.status_code == 200
    assert captured["user_id"] == f"service_app:{SERVICE_CID}"
    assert captured["client_id"] == SERVICE_CID


@pytest.mark.asyncio
async def test_admin_required_does_not_set_client_id_for_user():
    """Human requests leave client_id_var alone (user_id_var carries the principal)."""
    captured = {}

    @admin_required
    async def handler(request):
        captured["user_id"] = user_id_var.get()
        captured["client_id"] = client_id_var.get()
        from starlette.responses import JSONResponse
        return JSONResponse({"ok": True})

    class _Req:
        method = "GET"
        headers = {"authorization": "Bearer stub"}

        class _Url:
            path = "/api/admin/test"

        url = _Url()

        class _State:
            pass

        state = _State()

    req = _Req()

    user_id_var.set(None)
    client_id_var.set(None)

    with patch(
        "okta_agent_proxy.admin.middleware.verify_okta_token",
        new_callable=AsyncMock,
    ) as mock_verify:
        mock_verify.return_value = {
            "sub": "00uUserId",
            "username": "alice@example.com",
            "email": "alice@example.com",
            "principal_type": "user",
            "role": "admin",
            "token_type": "okta_oauth",
        }
        resp = await handler(req)

    assert resp.status_code == 200
    assert captured["user_id"] == "alice@example.com"
    assert captured["client_id"] is None
