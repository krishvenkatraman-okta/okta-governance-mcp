"""Tests for ClientSecretFetcher — Okta app secret retrieval and generation."""

import logging
from unittest.mock import AsyncMock, MagicMock

import httpx
import pytest

from okta_agent_proxy.okta_admin.client import OktaAPIClient
from okta_agent_proxy.okta_admin.exceptions import (
    OktaAdminAPIError,
    OktaAdminNotFoundError,
)
from okta_agent_proxy.okta_admin.secret_fetcher import ClientSecretFetcher

FAKE_TOKEN = "admin-token-xyz789"
OKTA_DOMAIN = "https://dev-12345.oktapreview.com"


def _make_response(json_body, status_code=200):
    """Build a real httpx.Response with JSON body."""
    return httpx.Response(
        status_code=status_code,
        json=json_body,
        request=httpx.Request("GET", OKTA_DOMAIN),
    )


@pytest.fixture
def api_client():
    client = MagicMock(spec=OktaAPIClient)
    client.get = AsyncMock()
    client.post = AsyncMock()
    return client


@pytest.fixture
def fetcher(api_client):
    return ClientSecretFetcher(api_client)


# ── Realistic Okta response fixtures ────────────────────────────────────

SECRET_ACTIVE_1 = {
    "id": "ocs1abc",
    "status": "ACTIVE",
    "client_secret": "secret-value-111",
    "created": "2026-01-15T10:00:00.000Z",
    "lastUpdated": "2026-01-15T10:00:00.000Z",
}

SECRET_ACTIVE_2 = {
    "id": "ocs2def",
    "status": "ACTIVE",
    "client_secret": "secret-value-222",
    "created": "2026-03-10T12:00:00.000Z",
    "lastUpdated": "2026-03-10T12:00:00.000Z",
}

SECRET_INACTIVE = {
    "id": "ocs3ghi",
    "status": "INACTIVE",
    "client_secret": "secret-value-inactive",
    "created": "2025-06-01T08:00:00.000Z",
}

NEW_SECRET = {
    "id": "ocs4jkl",
    "status": "ACTIVE",
    "client_secret": "brand-new-secret-999",
    "created": "2026-03-17T14:00:00.000Z",
}

APP_RESPONSE = {
    "id": "0oa1app123",
    "name": "oidc_client",
    "label": "My OIDC App",
    "status": "ACTIVE",
}

AGENT_RESPONSE_OAUTH = {
    "id": "agt1abc",
    "name": "My AI Agent",
    "credentials": {
        "oauthClient": {
            "client_id": "0oa1app123",
            "token_endpoint_auth_method": "client_secret_post",
        }
    },
}

AGENT_RESPONSE_APPID = {
    "id": "agt2def",
    "name": "Legacy Agent",
    "appId": "0oa2legacy456",
}

AGENT_RESPONSE_NO_APP = {
    "id": "agt3ghi",
    "name": "Orphan Agent",
    "credentials": {},
}


# ── list_app_secrets ─────────────────────────────────────────────────────

@pytest.mark.asyncio
async def test_list_secrets_returns_active_only(fetcher, api_client):
    api_client.get.return_value = _make_response(
        [SECRET_ACTIVE_1, SECRET_INACTIVE, SECRET_ACTIVE_2]
    )
    result = await fetcher.list_app_secrets("0oa1app123", FAKE_TOKEN)
    assert len(result) == 2
    assert all(s["status"] == "ACTIVE" for s in result)


@pytest.mark.asyncio
async def test_list_secrets_empty_when_all_inactive(fetcher, api_client):
    api_client.get.return_value = _make_response([SECRET_INACTIVE])
    result = await fetcher.list_app_secrets("0oa1app123", FAKE_TOKEN)
    assert result == []


@pytest.mark.asyncio
async def test_list_secrets_empty_response(fetcher, api_client):
    api_client.get.return_value = _make_response([])
    result = await fetcher.list_app_secrets("0oa1app123", FAKE_TOKEN)
    assert result == []


@pytest.mark.asyncio
async def test_list_secrets_passes_correct_path(fetcher, api_client):
    api_client.get.return_value = _make_response([])
    await fetcher.list_app_secrets("0oaXYZ", FAKE_TOKEN)
    api_client.get.assert_called_once_with(
        "/api/v1/apps/0oaXYZ/credentials/secrets", FAKE_TOKEN
    )


@pytest.mark.asyncio
async def test_list_secrets_propagates_404(fetcher, api_client):
    api_client.get.side_effect = OktaAdminNotFoundError("Resource not found: /api/v1/apps/bad/credentials/secrets")
    with pytest.raises(OktaAdminNotFoundError):
        await fetcher.list_app_secrets("bad", FAKE_TOKEN)


@pytest.mark.asyncio
async def test_list_secrets_propagates_api_error(fetcher, api_client):
    api_client.get.side_effect = OktaAdminAPIError("fail", status_code=500, error_description="boom")
    with pytest.raises(OktaAdminAPIError) as exc_info:
        await fetcher.list_app_secrets("0oa1", FAKE_TOKEN)
    assert exc_info.value.status_code == 500


# ── generate_app_secret ──────────────────────────────────────────────────

@pytest.mark.asyncio
async def test_generate_secret_success(fetcher, api_client):
    api_client.post.return_value = _make_response(NEW_SECRET)
    result = await fetcher.generate_app_secret("0oa1app123", FAKE_TOKEN)
    assert result["client_secret"] == "brand-new-secret-999"
    api_client.post.assert_called_once_with(
        "/api/v1/apps/0oa1app123/credentials/secrets", FAKE_TOKEN, json={}
    )


@pytest.mark.asyncio
async def test_generate_secret_max_limit_error(fetcher, api_client):
    api_client.post.side_effect = OktaAdminAPIError(
        "Bad Request", status_code=400, error_description="maximum number of secrets"
    )
    with pytest.raises(OktaAdminAPIError, match="maximum of 2 secrets"):
        await fetcher.generate_app_secret("0oa1app123", FAKE_TOKEN)


@pytest.mark.asyncio
async def test_generate_secret_propagates_404(fetcher, api_client):
    api_client.post.side_effect = OktaAdminNotFoundError("not found")
    with pytest.raises(OktaAdminNotFoundError):
        await fetcher.generate_app_secret("bad_app", FAKE_TOKEN)


@pytest.mark.asyncio
async def test_generate_secret_propagates_non_400_error(fetcher, api_client):
    api_client.post.side_effect = OktaAdminAPIError("fail", status_code=500, error_description="internal")
    with pytest.raises(OktaAdminAPIError) as exc_info:
        await fetcher.generate_app_secret("0oa1app123", FAKE_TOKEN)
    assert exc_info.value.status_code == 500


# ── fetch_or_generate_secret ────────────────────────────────────────────

@pytest.mark.asyncio
async def test_fetch_or_generate_uses_existing(fetcher, api_client):
    api_client.get.return_value = _make_response([SECRET_ACTIVE_1, SECRET_ACTIVE_2])
    secret, source = await fetcher.fetch_or_generate_secret("0oa1app123", FAKE_TOKEN)
    assert source == "fetched_existing"
    # Should pick the most recently created (SECRET_ACTIVE_2)
    assert secret == "secret-value-222"
    api_client.post.assert_not_called()


@pytest.mark.asyncio
async def test_fetch_or_generate_picks_most_recent(fetcher, api_client):
    api_client.get.return_value = _make_response([SECRET_ACTIVE_2, SECRET_ACTIVE_1])
    secret, _ = await fetcher.fetch_or_generate_secret("0oa1app123", FAKE_TOKEN)
    assert secret == "secret-value-222"


@pytest.mark.asyncio
async def test_fetch_or_generate_generates_when_none(fetcher, api_client):
    api_client.get.return_value = _make_response([])
    api_client.post.return_value = _make_response(NEW_SECRET)
    secret, source = await fetcher.fetch_or_generate_secret("0oa1app123", FAKE_TOKEN)
    assert source == "generated_new"
    assert secret == "brand-new-secret-999"


@pytest.mark.asyncio
async def test_fetch_or_generate_generates_when_all_inactive(fetcher, api_client):
    api_client.get.return_value = _make_response([SECRET_INACTIVE])
    api_client.post.return_value = _make_response(NEW_SECRET)
    secret, source = await fetcher.fetch_or_generate_secret("0oa1app123", FAKE_TOKEN)
    assert source == "generated_new"
    assert secret == "brand-new-secret-999"


# ── get_app_by_name ──────────────────────────────────────────────────────

@pytest.mark.asyncio
async def test_get_app_by_name_found(fetcher, api_client):
    api_client.get.return_value = _make_response([APP_RESPONSE])
    result = await fetcher.get_app_by_name("My OIDC App", FAKE_TOKEN)
    assert result["id"] == "0oa1app123"
    api_client.get.assert_called_once_with("/api/v1/apps?q=My OIDC App", FAKE_TOKEN)


@pytest.mark.asyncio
async def test_get_app_by_name_not_found(fetcher, api_client):
    api_client.get.return_value = _make_response([])
    result = await fetcher.get_app_by_name("Nonexistent", FAKE_TOKEN)
    assert result is None


@pytest.mark.asyncio
async def test_get_app_by_name_returns_first_match(fetcher, api_client):
    second_app = {"id": "0oa2other", "label": "Other App"}
    api_client.get.return_value = _make_response([APP_RESPONSE, second_app])
    result = await fetcher.get_app_by_name("App", FAKE_TOKEN)
    assert result["id"] == "0oa1app123"


# ── get_agent_linked_app_id ─────────────────────────────────────────────

@pytest.mark.asyncio
async def test_agent_linked_app_via_oauth_client(fetcher, api_client):
    api_client.get.return_value = _make_response(AGENT_RESPONSE_OAUTH)
    result = await fetcher.get_agent_linked_app_id("agt1abc", FAKE_TOKEN)
    assert result == "0oa1app123"


@pytest.mark.asyncio
async def test_agent_linked_app_via_app_id_fallback(fetcher, api_client):
    api_client.get.return_value = _make_response(AGENT_RESPONSE_APPID)
    result = await fetcher.get_agent_linked_app_id("agt2def", FAKE_TOKEN)
    assert result == "0oa2legacy456"


@pytest.mark.asyncio
async def test_agent_linked_app_no_app_raises(fetcher, api_client):
    api_client.get.return_value = _make_response(AGENT_RESPONSE_NO_APP)
    with pytest.raises(OktaAdminAPIError, match="no linked OAuth app"):
        await fetcher.get_agent_linked_app_id("agt3ghi", FAKE_TOKEN)


@pytest.mark.asyncio
async def test_agent_linked_app_not_found(fetcher, api_client):
    api_client.get.side_effect = OktaAdminNotFoundError("not found")
    with pytest.raises(OktaAdminNotFoundError):
        await fetcher.get_agent_linked_app_id("missing", FAKE_TOKEN)


@pytest.mark.asyncio
async def test_agent_linked_app_correct_path(fetcher, api_client):
    api_client.get.return_value = _make_response(AGENT_RESPONSE_OAUTH)
    await fetcher.get_agent_linked_app_id("agt1abc", FAKE_TOKEN)
    api_client.get.assert_called_once_with(
        "/workload-principals/api/v1/ai-agents/agt1abc", FAKE_TOKEN
    )


# ── Secret values never logged ──────────────────────────────────────────

@pytest.mark.asyncio
async def test_secret_not_logged_on_fetch(fetcher, api_client, caplog):
    api_client.get.return_value = _make_response([SECRET_ACTIVE_1])
    with caplog.at_level(logging.DEBUG, logger="okta_agent_proxy.okta_admin.secret_fetcher"):
        secret, _ = await fetcher.fetch_or_generate_secret("0oa1app123", FAKE_TOKEN)
    for record in caplog.records:
        assert "secret-value-111" not in record.getMessage(), "Secret value must never appear in logs"


@pytest.mark.asyncio
async def test_secret_not_logged_on_generate(fetcher, api_client, caplog):
    api_client.get.return_value = _make_response([])
    api_client.post.return_value = _make_response(NEW_SECRET)
    with caplog.at_level(logging.DEBUG, logger="okta_agent_proxy.okta_admin.secret_fetcher"):
        secret, _ = await fetcher.fetch_or_generate_secret("0oa1app123", FAKE_TOKEN)
    for record in caplog.records:
        assert "brand-new-secret-999" not in record.getMessage(), "Secret value must never appear in logs"


@pytest.mark.asyncio
async def test_token_not_logged(fetcher, api_client, caplog):
    api_client.get.return_value = _make_response([SECRET_ACTIVE_1])
    with caplog.at_level(logging.DEBUG, logger="okta_agent_proxy.okta_admin.secret_fetcher"):
        await fetcher.fetch_or_generate_secret("0oa1app123", FAKE_TOKEN)
    for record in caplog.records:
        assert FAKE_TOKEN not in record.getMessage(), "Token must never appear in logs"
