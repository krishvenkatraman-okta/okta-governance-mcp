"""
Tests for port configuration validation.

Covers:
- GatewaySettings port validation (range, privileged port warnings)
- HR backend port resolution (HR_BACKEND_PORT, SERVER_PORT fallback, default)
- Deploy server port resolution (DEPLOY_SERVER_PORT, SERVER_PORT fallback, default)
- Audit event emission for privileged port configuration
"""

import os
import warnings
from unittest.mock import AsyncMock, patch

import pytest

from okta_agent_proxy.config import GatewaySettings


# ============================================================================
# GatewaySettings port validation
# ============================================================================


class TestGatewayPortValidation:
    """Tests for the gateway_port field_validator on GatewaySettings."""

    @pytest.fixture(autouse=True)
    def _set_required_env(self, monkeypatch):
        """Set required env vars so GatewaySettings can be instantiated."""
        monkeypatch.setenv("OKTA_DOMAIN", "dev-test.okta.com")

    @pytest.mark.parametrize("port", [8000, 8080, 65535])
    def test_valid_port_accepted(self, port, monkeypatch):
        monkeypatch.setenv("GATEWAY_PORT", str(port))
        settings = GatewaySettings()
        assert settings.gateway_port == port

    def test_port_zero_rejected(self, monkeypatch):
        monkeypatch.setenv("GATEWAY_PORT", "0")
        with pytest.raises(Exception):
            GatewaySettings()

    def test_port_negative_rejected(self, monkeypatch):
        monkeypatch.setenv("GATEWAY_PORT", "-1")
        with pytest.raises(Exception):
            GatewaySettings()

    def test_port_too_high_rejected(self, monkeypatch):
        monkeypatch.setenv("GATEWAY_PORT", "65536")
        with pytest.raises(Exception):
            GatewaySettings()

    @pytest.mark.parametrize("port", [80, 443])
    def test_privileged_port_warns(self, port, monkeypatch):
        monkeypatch.setenv("GATEWAY_PORT", str(port))
        with pytest.warns(UserWarning, match="privileged port"):
            GatewaySettings()


# ============================================================================
# HR backend port resolution
# ============================================================================


class TestHRBackendPortResolution:
    """Tests for _resolve_port() in the HR backend server."""

    def _get_resolve_port(self):
        """Import the HR backend's _resolve_port function dynamically.

        We import the function source directly to avoid importing the full
        server module which has heavy dependencies (FastMCP, etc.).
        """
        import importlib.util
        import types

        # Build a minimal module with just os + the function
        hr_server_path = os.path.join(
            os.path.dirname(__file__),
            "..", "examples", "01-hr-system", "server.py",
        )
        hr_server_path = os.path.normpath(hr_server_path)

        # Read the source and extract _resolve_port
        with open(hr_server_path) as f:
            source = f.read()

        # Find and extract the function
        func_start = source.index("def _resolve_port()")
        # Find next function or class definition at module level
        rest = source[func_start:]
        lines = rest.split("\n")
        func_lines = [lines[0]]
        for line in lines[1:]:
            if line and not line[0].isspace() and not line.startswith("#"):
                break
            func_lines.append(line)
        func_source = "\n".join(func_lines)

        mod = types.ModuleType("_hr_port_helper")
        mod.__dict__["os"] = os
        exec(func_source, mod.__dict__)
        return mod._resolve_port

    def test_hr_backend_new_env_var_wins(self, monkeypatch):
        monkeypatch.setenv("HR_BACKEND_PORT", "9001")
        monkeypatch.setenv("SERVER_PORT", "7777")
        resolve = self._get_resolve_port()
        assert resolve() == 9001

    def test_hr_backend_legacy_env_var_deprecation_warning(self, monkeypatch):
        monkeypatch.delenv("HR_BACKEND_PORT", raising=False)
        monkeypatch.setenv("SERVER_PORT", "8888")
        resolve = self._get_resolve_port()
        with pytest.warns(DeprecationWarning, match="SERVER_PORT is deprecated"):
            port = resolve()
        assert port == 8888

    def test_hr_backend_default_port_when_no_env(self, monkeypatch):
        monkeypatch.delenv("HR_BACKEND_PORT", raising=False)
        monkeypatch.delenv("SERVER_PORT", raising=False)
        resolve = self._get_resolve_port()
        assert resolve() == 8001


# ============================================================================
# Deploy server port resolution
# ============================================================================


class TestDeployServerPortResolution:
    """Tests for _resolve_port() in the deploy server."""

    def _get_resolve_port(self):
        """Import the deploy server's _resolve_port function dynamically."""
        import types

        deploy_server_path = os.path.join(
            os.path.dirname(__file__),
            "..", "examples", "05-deploy-server", "server.py",
        )
        deploy_server_path = os.path.normpath(deploy_server_path)

        with open(deploy_server_path) as f:
            source = f.read()

        func_start = source.index("def _resolve_port()")
        rest = source[func_start:]
        lines = rest.split("\n")
        func_lines = [lines[0]]
        for line in lines[1:]:
            if line and not line[0].isspace() and not line.startswith("#"):
                break
            func_lines.append(line)
        func_source = "\n".join(func_lines)

        mod = types.ModuleType("_deploy_port_helper")
        mod.__dict__["os"] = os
        exec(func_source, mod.__dict__)
        return mod._resolve_port

    def test_deploy_server_new_env_var_wins(self, monkeypatch):
        monkeypatch.setenv("DEPLOY_SERVER_PORT", "9005")
        monkeypatch.setenv("SERVER_PORT", "7777")
        resolve = self._get_resolve_port()
        assert resolve() == 9005

    def test_deploy_server_legacy_env_var_deprecation_warning(self, monkeypatch):
        monkeypatch.delenv("DEPLOY_SERVER_PORT", raising=False)
        monkeypatch.setenv("SERVER_PORT", "8888")
        resolve = self._get_resolve_port()
        with pytest.warns(DeprecationWarning, match="SERVER_PORT is deprecated"):
            port = resolve()
        assert port == 8888

    def test_deploy_server_default_port_when_no_env(self, monkeypatch):
        monkeypatch.delenv("DEPLOY_SERVER_PORT", raising=False)
        monkeypatch.delenv("SERVER_PORT", raising=False)
        resolve = self._get_resolve_port()
        assert resolve() == 8005


# ============================================================================
# Audit event for privileged port
# ============================================================================


class TestConfigAuditEvent:
    """Test that a privileged port triggers an audit event at startup.

    These tests replicate the logic from app.py's _on_audit_startup() to
    verify the privileged port audit check without importing the full ASGI
    app module (which requires PostgreSQL and Redis connectivity).
    """

    @pytest.mark.asyncio
    async def test_config_audit_event_emitted_for_privileged_port(self, monkeypatch):
        monkeypatch.setenv("GATEWAY_PORT", "443")

        from okta_agent_proxy.audit.events import AuditEventType, AuditSeverity

        mock_emit = AsyncMock()

        # Replicate the startup check from app.py _on_audit_startup
        port = int(os.environ.get("GATEWAY_PORT", "8000"))
        if port < 1024:
            await mock_emit(
                event_type=AuditEventType.CONFIG_PORT_VALIDATION_WARNING,
                severity=AuditSeverity.WARNING,
                details={
                    "port": port,
                    "component": "gateway",
                    "severity": "warning",
                },
                outcome="warning",
            )

        mock_emit.assert_called_once()
        call_kwargs = mock_emit.call_args
        assert call_kwargs.kwargs["event_type"] == AuditEventType.CONFIG_PORT_VALIDATION_WARNING
        details = call_kwargs.kwargs["details"]
        assert details["port"] == 443
        assert details["component"] == "gateway"

    @pytest.mark.asyncio
    async def test_config_audit_event_not_emitted_for_normal_port(self, monkeypatch):
        monkeypatch.setenv("GATEWAY_PORT", "8000")

        mock_emit = AsyncMock()

        # Replicate the startup check from app.py _on_audit_startup
        port = int(os.environ.get("GATEWAY_PORT", "8000"))
        if port < 1024:
            await mock_emit(
                event_type="config.port.validation_warning",
                severity="warning",
                details={"port": port, "component": "gateway", "severity": "warning"},
                outcome="warning",
            )

        mock_emit.assert_not_called()
