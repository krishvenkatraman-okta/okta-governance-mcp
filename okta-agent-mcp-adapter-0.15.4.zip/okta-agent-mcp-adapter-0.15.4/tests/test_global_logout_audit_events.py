"""Smoke tests confirming Global Logout audit event types are registered."""

from okta_agent_proxy.audit.events import AuditEventType


def test_global_logout_requested_exists():
    assert AuditEventType.GLOBAL_LOGOUT_REQUESTED.value == "global_logout.requested"


def test_global_logout_auth_failed_exists():
    assert AuditEventType.GLOBAL_LOGOUT_AUTH_FAILED.value == "global_logout.auth.failed"


def test_global_logout_subject_invalid_exists():
    assert AuditEventType.GLOBAL_LOGOUT_SUBJECT_INVALID.value == "global_logout.subject.invalid"


def test_global_logout_subject_not_found_exists():
    assert (
        AuditEventType.GLOBAL_LOGOUT_SUBJECT_NOT_FOUND.value
        == "global_logout.subject.not_found"
    )


def test_global_logout_completed_exists():
    assert AuditEventType.GLOBAL_LOGOUT_COMPLETED.value == "global_logout.completed"


def test_global_logout_backend_session_terminated_exists():
    assert (
        AuditEventType.GLOBAL_LOGOUT_BACKEND_SESSION_TERMINATED.value
        == "global_logout.backend_session.terminated"
    )


def test_global_logout_backend_session_failed_exists():
    assert (
        AuditEventType.GLOBAL_LOGOUT_BACKEND_SESSION_FAILED.value
        == "global_logout.backend_session.failed"
    )
