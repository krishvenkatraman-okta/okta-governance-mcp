"""Tests confirming UserTokenStore.aremove_by_user contract for Global Logout."""

import pytest
from unittest.mock import AsyncMock

from okta_agent_proxy.auth.user_token_store import (
    UserTokenStore,
    _USER_TOKEN_PREFIX,
)


@pytest.mark.asyncio
async def test_aremove_by_user_removes_matching_entries():
    store = UserTokenStore(
        encryption_service=None, default_ttl=86400, max_size=1000
    )
    store.store("at-1", "id1", "rt1", "userA", "agent1")
    store.store("at-2", "id2", "rt2", "userA", "agent2")
    store.store("at-3", "id3", "rt3", "userB", "agent1")
    count = await store.aremove_by_user("userA")
    assert count == 2
    assert store.lookup("at-1") is None
    assert store.lookup("at-2") is None
    assert store.lookup("at-3") is not None


@pytest.mark.asyncio
async def test_aremove_by_user_with_encryption(encryption_service):
    store = UserTokenStore(
        encryption_service=encryption_service,
        default_ttl=86400,
        max_size=1000,
    )
    store.store("at-1", "id1", "rt1", "userA", "agent1")
    store.store("at-2", "id2", "rt2", "userB", "agent1")
    count = await store.aremove_by_user("userA")
    assert count == 1
    assert store.lookup("at-1") is None
    assert store.lookup("at-2") is not None


@pytest.mark.asyncio
async def test_aremove_by_user_zero_when_no_match():
    store = UserTokenStore(
        encryption_service=None, default_ttl=86400, max_size=1000
    )
    store.store("at-1", "id1", "rt1", "userA", "agent1")
    assert await store.aremove_by_user("userZ") == 0
    assert store.lookup("at-1") is not None


@pytest.mark.asyncio
async def test_aremove_by_user_calls_l2_clear_prefix():
    mock_cs = AsyncMock()
    store = UserTokenStore(
        encryption_service=None,
        default_ttl=86400,
        max_size=1000,
        cache_service=mock_cs,
    )
    store.store("at-1", "id1", "rt1", "userA", "agent1")
    await store.aremove_by_user("userA")
    mock_cs.clear_prefix.assert_awaited_once_with(_USER_TOKEN_PREFIX)


@pytest.mark.asyncio
async def test_aremove_by_user_publishes_pubsub_when_event_bus_wired():
    mock_bus = AsyncMock()
    store = UserTokenStore(
        encryption_service=None,
        default_ttl=86400,
        max_size=1000,
        event_bus=mock_bus,
    )
    store.store("at-1", "id1", "rt1", "userA", "agent1")
    store.store("at-2", "id2", "rt2", "userA", "agent2")
    count = await store.aremove_by_user("userA")
    assert count == 2
    assert mock_bus.publish.await_count == 2


@pytest.mark.asyncio
async def test_aremove_by_user_no_publish_when_count_is_zero():
    mock_bus = AsyncMock()
    store = UserTokenStore(
        encryption_service=None,
        default_ttl=86400,
        max_size=1000,
        event_bus=mock_bus,
    )
    await store.aremove_by_user("userA")
    mock_bus.publish.assert_not_awaited()
