"""Tests for Okta AI Agent import/sync admin routes."""

import json
import os
from dataclasses import asdict
from unittest.mock import AsyncMock, MagicMock, patch

import pytest
from starlette.testclient import TestClient

from okta_agent_proxy.admin.okta_import_routes import (
    _check_okta_auth,
)
from okta_agent_proxy.auth.okta_agent_import import ImportableAgent, ImportResult


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

@pytest.fixture(autouse=True)
def _reset_singletons():
    """Reset module-level singletons between tests."""
    import okta_agent_proxy.admin.okta_import_routes as mod
    mod._service_auth = None
    mod._client = None
    mod._importer = None
    yield
    mod._service_auth = None
    mod._client = None
    mod._importer = None


@pytest.fixture
def mock_store():
    store = MagicMock()
    store.get_all_agents.return_value = []
    store.get_all_resources.return_value = []
    store.get_agent.return_value = None
    store.create_agent.return_value = True
    store.update_agent.return_value = True
    store.update_resource.return_value = True
    return store


@pytest.fixture
def mock_client():
    client = AsyncMock()
    client.list_agents.return_value = []
    client.get_agent.return_value = None
    client.get_agent_connections.return_value = []
    client.get_linked_app.return_value = None
    client.check_token_scopes.return_value = {"has_ai_agent_scopes": True}
    return client


@pytest.fixture
def mock_importer():
    importer = AsyncMock()
    return importer


def _okta_headers():
    """Headers that simulate an Okta OAuth token (bypasses legacy JWT check)."""
    return {"Authorization": "Bearer okta-test-token-xyz"}


def _make_app(mock_store, mock_client, mock_importer, env_overrides=None):
    """Build test Starlette app with mocked dependencies."""
    env = {
        "OKTA_DOMAIN": "dev-test.okta.com",
        "OKTA_AI_AGENT_ID": "agt_adapter",
    }
    if env_overrides:
        env.update(env_overrides)

    patches = [
        patch("okta_agent_proxy.admin.okta_import_routes._get_client", return_value=mock_client),
        patch("okta_agent_proxy.admin.okta_import_routes._get_importer", return_value=mock_importer),
        patch("okta_agent_proxy.admin.okta_import_routes.get_store", return_value=mock_store),
        patch.dict(os.environ, env, clear=False),
        # Make admin_required pass with okta_oauth token_type
        patch(
            "okta_agent_proxy.admin.middleware.verify_okta_token",
            new_callable=AsyncMock,
            return_value={
                "username": "admin@example.com",
                "role": "admin",
                "token_type": "okta_oauth",
            },
        ),
    ]

    from starlette.applications import Starlette
    from starlette.routing import Route
    from okta_agent_proxy.admin import okta_import_routes as routes

    app = Starlette(routes=[
        Route("/api/admin/okta/agents/bulk-import", routes.bulk_import_agents, methods=["POST"]),
        Route("/api/admin/okta/sync/agents", routes.sync_all_agents, methods=["POST"]),
        Route("/api/admin/okta/sync/resources", routes.sync_all_resources, methods=["POST"]),
        Route("/api/admin/okta/sync/all", routes.sync_all, methods=["POST"]),
        Route("/api/admin/okta/agents/{okta_agent_id}/import", routes.import_agent, methods=["POST"]),
        Route("/api/admin/okta/agents/{okta_agent_id}/sync", routes.sync_agent, methods=["POST"]),
        Route("/api/admin/okta/agents/{okta_agent_id}", routes.get_agent_detail, methods=["GET"]),
        Route("/api/admin/okta/agents", routes.list_importable_agents, methods=["GET"]),
    ])

    # Start all patches
    started = [p.start() for p in patches]

    client = TestClient(app)
    return client, patches


def _stop_patches(patches):
    for p in patches:
        p.stop()


# ---------------------------------------------------------------------------
# Legacy JWT path removed in v0.15.x — the okta_auth_required guard in
# okta_import_routes._check_okta_auth is now effectively unreachable because
# middleware admits only Okta OAuth tokens. The old test_403_for_legacy_jwt
# test was deleted with the legacy auth path.


# ---------------------------------------------------------------------------
# Scope check (403 insufficient_scopes)
# ---------------------------------------------------------------------------

class TestScopeCheck:

    def test_403_when_scopes_missing(self, mock_store, mock_client, mock_importer):
        mock_client.check_token_scopes.return_value = {
            "has_ai_agent_scopes": False,
            "error": "Token lacks okta.aiAgents.read scope",
        }
        test_client, patches = _make_app(mock_store, mock_client, mock_importer)
        try:
            resp = test_client.get("/api/admin/okta/agents", headers=_okta_headers())
            assert resp.status_code == 403
            assert resp.json()["error"] == "insufficient_scopes"
        finally:
            _stop_patches(patches)


# ---------------------------------------------------------------------------
# List importable agents
# ---------------------------------------------------------------------------

class TestListImportableAgents:

    def test_returns_agents(self, mock_store, mock_client, mock_importer):
        mock_importer.list_importable_agents.return_value = [
            ImportableAgent(
                okta_agent_id="agt_1",
                name="Agent One",
                description="First agent",
                status="ACTIVE",
                app_id="0oa_1",
                linked_app_client_id="client_1",
                connections_count=2,
                already_imported=False,
            ),
        ]
        test_client, patches = _make_app(mock_store, mock_client, mock_importer)
        try:
            resp = test_client.get("/api/admin/okta/agents", headers=_okta_headers())
            assert resp.status_code == 200
            data = resp.json()
            assert len(data["agents"]) == 1
            assert data["agents"][0]["okta_agent_id"] == "agt_1"
            assert data["agents"][0]["already_imported"] is False
        finally:
            _stop_patches(patches)

    def test_502_on_okta_error(self, mock_store, mock_client, mock_importer):
        mock_importer.list_importable_agents.side_effect = Exception("Connection refused")
        test_client, patches = _make_app(mock_store, mock_client, mock_importer)
        try:
            resp = test_client.get("/api/admin/okta/agents", headers=_okta_headers())
            assert resp.status_code == 502
            assert resp.json()["error"] == "okta_unreachable"
        finally:
            _stop_patches(patches)


# ---------------------------------------------------------------------------
# Import agent
# ---------------------------------------------------------------------------

class TestImportAgent:

    def test_import_success(self, mock_store, mock_client, mock_importer):
        mock_importer.import_agent.return_value = ImportResult(
            success=True,
            agent_name="demo-agent",
            okta_agent_id="agt_1",
            message="Agent imported successfully",
            resources_linked=["hr-system"],
            warnings=[],
        )
        test_client, patches = _make_app(mock_store, mock_client, mock_importer)
        try:
            resp = test_client.post(
                "/api/admin/okta/agents/agt_1/import",
                headers=_okta_headers(),
                json={},
            )
            assert resp.status_code == 200
            data = resp.json()
            assert data["success"] is True
            assert data["agent_name"] == "demo-agent"
            assert "hr-system" in data["resources_linked"]
        finally:
            _stop_patches(patches)

    def test_import_forwards_token(self, mock_store, mock_client, mock_importer):
        mock_importer.import_agent.return_value = ImportResult(
            success=True, agent_name="a", okta_agent_id="agt_1", message="ok"
        )
        test_client, patches = _make_app(mock_store, mock_client, mock_importer)
        try:
            resp = test_client.post(
                "/api/admin/okta/agents/agt_1/import",
                headers=_okta_headers(),
                json={},
            )
            assert resp.status_code == 200
            # Verify token was forwarded
            call_args = mock_importer.import_agent.call_args
            assert call_args[0][1] == "okta-test-token-xyz"  # okta_token arg
        finally:
            _stop_patches(patches)

    def test_import_failure_returns_400(self, mock_store, mock_client, mock_importer):
        mock_importer.import_agent.return_value = ImportResult(
            success=False,
            agent_name="",
            okta_agent_id="agt_bad",
            message="Agent not found in Okta",
        )
        test_client, patches = _make_app(mock_store, mock_client, mock_importer)
        try:
            resp = test_client.post(
                "/api/admin/okta/agents/agt_bad/import",
                headers=_okta_headers(),
                json={},
            )
            assert resp.status_code == 400
            assert resp.json()["success"] is False
        finally:
            _stop_patches(patches)


# ---------------------------------------------------------------------------
# Bulk import
# ---------------------------------------------------------------------------

class TestBulkImport:

    def test_bulk_import(self, mock_store, mock_client, mock_importer):
        mock_importer.bulk_import.return_value = [
            ImportResult(success=True, agent_name="a1", okta_agent_id="agt_1", message="ok"),
            ImportResult(success=False, agent_name="", okta_agent_id="agt_2", message="fail"),
        ]
        test_client, patches = _make_app(mock_store, mock_client, mock_importer)
        try:
            resp = test_client.post(
                "/api/admin/okta/agents/bulk-import",
                headers=_okta_headers(),
                json={"agent_ids": ["agt_1", "agt_2"]},
            )
            assert resp.status_code == 200
            data = resp.json()
            assert data["imported"] == 1
            assert data["failed"] == 1
            assert len(data["results"]) == 2
        finally:
            _stop_patches(patches)

    def test_bulk_import_bad_body(self, mock_store, mock_client, mock_importer):
        test_client, patches = _make_app(mock_store, mock_client, mock_importer)
        try:
            resp = test_client.post(
                "/api/admin/okta/agents/bulk-import",
                headers=_okta_headers(),
                json={"agent_ids": []},
            )
            assert resp.status_code == 400
        finally:
            _stop_patches(patches)


# ---------------------------------------------------------------------------
# Sync single agent
# ---------------------------------------------------------------------------

class TestSyncAgent:

    def test_sync_updates_status_and_resources(self, mock_store, mock_client, mock_importer):
        mock_importer.sync_agent.return_value = ImportResult(
            success=True,
            agent_name="demo-agent",
            okta_agent_id="agt_1",
            message="Agent synced",
            resources_linked=["hr-system", "finance-system"],
            warnings=[],
        )
        test_client, patches = _make_app(mock_store, mock_client, mock_importer)
        try:
            resp = test_client.post(
                "/api/admin/okta/agents/agt_1/sync",
                headers=_okta_headers(),
            )
            assert resp.status_code == 200
            data = resp.json()
            assert data["success"] is True
            assert "hr-system" in data["resources_linked"]
        finally:
            _stop_patches(patches)

    def test_sync_failure_returns_400(self, mock_store, mock_client, mock_importer):
        mock_importer.sync_agent.return_value = ImportResult(
            success=False,
            agent_name="",
            okta_agent_id="agt_1",
            message="Agent not found in store",
        )
        test_client, patches = _make_app(mock_store, mock_client, mock_importer)
        try:
            resp = test_client.post(
                "/api/admin/okta/agents/agt_1/sync",
                headers=_okta_headers(),
            )
            assert resp.status_code == 400
        finally:
            _stop_patches(patches)


# ---------------------------------------------------------------------------
# Sync all agents
# ---------------------------------------------------------------------------

class TestSyncAllAgents:

    def test_syncs_okta_import_agents_only(self, mock_store, mock_client, mock_importer):
        mock_store.get_all_agents.return_value = [
            {"agent_name": "imported-1", "agent_id": "imported-1",
             "registration_source": "okta-import", "okta_ai_agent_id": "agt_1"},
            {"agent_name": "manual-1", "agent_id": "manual-1",
             "registration_source": "manual", "okta_ai_agent_id": None},
        ]
        mock_importer.sync_agent.return_value = ImportResult(
            success=True, agent_name="imported-1", okta_agent_id="agt_1",
            message="synced", resources_linked=["hr-system"],
        )
        test_client, patches = _make_app(mock_store, mock_client, mock_importer)
        try:
            resp = test_client.post(
                "/api/admin/okta/sync/agents",
                headers=_okta_headers(),
            )
            assert resp.status_code == 200
            data = resp.json()
            assert data["synced"] == 1
            assert data["failed"] == 0
            # Only imported-1 should be synced (manual-1 has no okta_ai_agent_id)
            assert len(data["results"]) == 1
            mock_importer.sync_agent.assert_called_once_with("agt_1", "okta-test-token-xyz")
        finally:
            _stop_patches(patches)

    def test_empty_when_no_okta_imports(self, mock_store, mock_client, mock_importer):
        mock_store.get_all_agents.return_value = [
            {"agent_name": "manual-1", "agent_id": "manual-1",
             "registration_source": "manual"},
        ]
        test_client, patches = _make_app(mock_store, mock_client, mock_importer)
        try:
            resp = test_client.post(
                "/api/admin/okta/sync/agents",
                headers=_okta_headers(),
            )
            assert resp.status_code == 200
            assert resp.json()["synced"] == 0
        finally:
            _stop_patches(patches)


# ---------------------------------------------------------------------------
# Sync all resources
# ---------------------------------------------------------------------------

class TestSyncAllResources:

    def test_updates_managed_connection_scopes(self, mock_store, mock_client, mock_importer):
        mock_client.get_agent_connections.return_value = [
            {
                "name": "hr-connection",
                "type": "IDENTITY_ASSERTION_CUSTOM_AS",
                "properties": {
                    "authorizationServerId": "aus123hr",
                    "scopes": ["mcp:read", "mcp:write"],
                },
            },
        ]
        mock_store.get_all_resources.return_value = [
            {
                "name": "hr-system",
                "auth_method": "okta-cross-app",
                "auth_config": {
                    "target_authorization_server": "https://dev-test.okta.com/oauth2/aus123hr",
                },
            },
            {
                "name": "static-resource",
                "auth_method": "static-key",
                "auth_config": {},
            },
        ]
        test_client, patches = _make_app(mock_store, mock_client, mock_importer)
        try:
            resp = test_client.post(
                "/api/admin/okta/sync/resources",
                headers=_okta_headers(),
            )
            assert resp.status_code == 200
            data = resp.json()
            assert "hr-system" in data["resources_updated"]
            # static-resource is not okta-cross-app so won't be in unchanged
            # (unchanged only lists okta-cross-app resources not updated)
        finally:
            _stop_patches(patches)

    def test_400_when_no_agent_id(self, mock_store, mock_client, mock_importer):
        test_client, patches = _make_app(
            mock_store, mock_client, mock_importer,
            env_overrides={"OKTA_AI_AGENT_ID": ""},
        )
        try:
            resp = test_client.post(
                "/api/admin/okta/sync/resources",
                headers=_okta_headers(),
            )
            assert resp.status_code == 400
            assert resp.json()["error"] == "not_configured"
        finally:
            _stop_patches(patches)

    def test_502_on_okta_error(self, mock_store, mock_client, mock_importer):
        mock_client.get_agent_connections.side_effect = Exception("timeout")
        test_client, patches = _make_app(mock_store, mock_client, mock_importer)
        try:
            resp = test_client.post(
                "/api/admin/okta/sync/resources",
                headers=_okta_headers(),
            )
            assert resp.status_code == 502
        finally:
            _stop_patches(patches)


# ---------------------------------------------------------------------------
# Sync all (agents + resources)
# ---------------------------------------------------------------------------

class TestSyncAll:

    def test_syncs_agents_and_resources(self, mock_store, mock_client, mock_importer):
        mock_store.get_all_agents.return_value = [
            {"agent_name": "imp-1", "agent_id": "imp-1",
             "registration_source": "okta-import", "okta_ai_agent_id": "agt_1"},
        ]
        mock_importer.sync_agent.return_value = ImportResult(
            success=True, agent_name="imp-1", okta_agent_id="agt_1",
            message="synced", resources_linked=["hr-system"],
        )
        mock_client.get_agent_connections.return_value = [
            {
                "name": "hr-conn",
                "type": "IDENTITY_ASSERTION_CUSTOM_AS",
                "properties": {
                    "authorizationServerId": "aus123",
                    "scopes": ["read"],
                },
            },
        ]
        mock_store.get_all_resources.return_value = [
            {
                "name": "hr-system",
                "auth_method": "okta-cross-app",
                "auth_config": {
                    "target_authorization_server": "https://dev.okta.com/oauth2/aus123",
                },
            },
        ]
        test_client, patches = _make_app(mock_store, mock_client, mock_importer)
        try:
            resp = test_client.post(
                "/api/admin/okta/sync/all",
                headers=_okta_headers(),
            )
            assert resp.status_code == 200
            data = resp.json()
            assert data["agents"]["synced"] == 1
            assert "hr-system" in data["resources"]["resources_updated"]
        finally:
            _stop_patches(patches)


# ---------------------------------------------------------------------------
# Agent detail
# ---------------------------------------------------------------------------

class TestAgentDetail:

    def test_returns_agent_with_connections(self, mock_store, mock_client, mock_importer):
        mock_client.get_agent.return_value = {
            "id": "agt_1",
            "name": "Demo Agent",
            "status": "ACTIVE",
            "appId": "0oa_app",
        }
        mock_client.get_agent_connections.return_value = [
            {
                "name": "hr-conn",
                "type": "IDENTITY_ASSERTION_CUSTOM_AS",
                "properties": {"authorizationServerId": "aus123hr"},
            },
        ]
        mock_client.get_linked_app.return_value = {
            "id": "0oa_app",
            "label": "Demo App",
            "credentials": {"oauthClient": {"client_id": "client_abc"}},
        }
        mock_store.get_all_resources.return_value = [
            {
                "name": "hr-system",
                "auth_method": "okta-cross-app",
                "auth_config": {
                    "target_authorization_server": "https://dev.okta.com/oauth2/aus123hr",
                },
            },
        ]
        test_client, patches = _make_app(mock_store, mock_client, mock_importer)
        try:
            resp = test_client.get(
                "/api/admin/okta/agents/agt_1",
                headers=_okta_headers(),
            )
            assert resp.status_code == 200
            data = resp.json()
            assert data["agent"]["id"] == "agt_1"
            assert data["linked_app"]["client_id"] == "client_abc"
            assert data["connections"][0]["matched_resource"] == "hr-system"
        finally:
            _stop_patches(patches)

    def test_404_when_not_found(self, mock_store, mock_client, mock_importer):
        mock_client.get_agent.return_value = None
        test_client, patches = _make_app(mock_store, mock_client, mock_importer)
        try:
            resp = test_client.get(
                "/api/admin/okta/agents/agt_missing",
                headers=_okta_headers(),
            )
            assert resp.status_code == 404
        finally:
            _stop_patches(patches)
