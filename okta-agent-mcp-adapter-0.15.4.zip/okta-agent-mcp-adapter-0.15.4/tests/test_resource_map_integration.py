"""
Integration tests for Resource Map pipeline migration (P3).

Verifies that ResourceRouter, ProxyHandler, and UnifiedMCPHandler work
correctly when backed by OktaConnectionSyncer + ResolvedResource objects
instead of ResourceConfigStore + ResourceModel.
"""

import pytest
from unittest.mock import AsyncMock, MagicMock, patch

from okta_agent_proxy.routing.router import (
    ResourceRouter,
    ResolvedResourceConfigAdapter,
)
from okta_agent_proxy.resources.models import (
    OktaConnectionType,
    OktaScopeCondition,
    ResolvedResource,
)
from okta_agent_proxy.auth.cross_app_access import OktaCrossAppAccessManager


# ============================================================================
# Fixtures
# ============================================================================


def _make_resolved_resource(
    name="hr-system",
    resource_id="ausvpuw0yn",
    mcp_url="https://hr.example.com/mcp",
    protocol="mcp",
    connection_type=OktaConnectionType.IDENTITY_ASSERTION_CUSTOM_AS,
    auth_method="okta-cross-app",
    scopes=None,
    scope_condition=OktaScopeCondition.ALLOW_ALL,
):
    return ResolvedResource(
        resource_id=resource_id,
        name=name,
        mcp_url=mcp_url,
        protocol=protocol,
        description=f"{name} resource",
        connection_id=f"conn-{name}",
        connection_type=connection_type,
        auth_method=auth_method,
        scopes=scopes or [],
        scope_condition=scope_condition,
    )


@pytest.fixture
def mock_syncer():
    """Mock OktaConnectionSyncer with two ResolvedResources."""
    syncer = MagicMock()

    hr = _make_resolved_resource("hr-system", "ausvpuw0yn")
    finance = _make_resolved_resource(
        "finance-api",
        resource_id="secret123",
        mcp_url="https://finance.example.com/mcp",
        connection_type=OktaConnectionType.SECRET,
        auth_method="pre-shared-key",
    )

    resources_by_name = {"hr-system": hr, "finance-api": finance}

    syncer.get_resource.side_effect = lambda name: resources_by_name.get(name)
    syncer.get_all_resources.return_value = list(resources_by_name.values())
    return syncer


@pytest.fixture
def syncer_router(mock_syncer):
    """ResourceRouter with syncer (no static resources)."""
    return ResourceRouter(resources_config={}, syncer=mock_syncer)


# ============================================================================
# ResolvedResourceConfigAdapter
# ============================================================================


class TestResolvedResourceConfigAdapter:

    def test_attribute_access(self):
        rb = _make_resolved_resource()
        adapter = ResolvedResourceConfigAdapter(rb)

        assert adapter.name == "hr-system"
        assert adapter.url == "https://hr.example.com/mcp"
        assert adapter.auth_method == "okta-cross-app"
        assert adapter.enabled is True
        assert adapter.paths == []
        assert adapter.resource_id == "ausvpuw0yn"
        assert adapter.connection_id == "conn-hr-system"
        assert adapter.protocol == "mcp"

    def test_auth_config_model_dump(self):
        rb = _make_resolved_resource(
            scopes=["mcp:read"],
            scope_condition=OktaScopeCondition.INCLUDE_ONLY,
        )
        adapter = ResolvedResourceConfigAdapter(rb)
        dump = adapter.auth_config.model_dump()
        assert dump["scopes"] == ["mcp:read"]
        assert dump["scope_condition"] == "INCLUDE_ONLY"
        assert dump["resource_id"] == "ausvpuw0yn"

    def test_to_dict(self):
        rb = _make_resolved_resource()
        adapter = ResolvedResourceConfigAdapter(rb)
        d = adapter.to_dict()
        assert d["name"] == "hr-system"
        assert d["url"] == "https://hr.example.com/mcp"
        assert d["auth_method"] == "okta-cross-app"
        assert d["enabled"] is True
        assert d["resource_id"] == "ausvpuw0yn"
        assert d["connection_type"] == "IDENTITY_ASSERTION_CUSTOM_AS"

    def test_scope_condition_values_in_dict(self):
        rb = _make_resolved_resource(scope_condition=OktaScopeCondition.DISALLOW)
        adapter = ResolvedResourceConfigAdapter(rb)
        d = adapter.to_dict()
        assert d["scope_condition"] == "DISALLOW"

    def test_pre_shared_key_adapter(self):
        rb = _make_resolved_resource(
            connection_type=OktaConnectionType.SECRET,
            auth_method="pre-shared-key",
        )
        adapter = ResolvedResourceConfigAdapter(rb)
        assert adapter.auth_method == "pre-shared-key"
        assert adapter.connection_type == OktaConnectionType.SECRET


# ============================================================================
# ResourceRouter with syncer
# ============================================================================


class TestResourceRouterWithSyncer:

    def test_get_resource_config_from_syncer(self, syncer_router):
        config = syncer_router.get_resource_config("hr-system")
        assert config is not None
        assert isinstance(config, ResolvedResourceConfigAdapter)
        assert config.url == "https://hr.example.com/mcp"
        assert config.auth_method == "okta-cross-app"

    def test_get_resource_config_returns_none_for_unknown(self, syncer_router):
        config = syncer_router.get_resource_config("nonexistent")
        assert config is None

    def test_get_resource_url(self, syncer_router):
        url = syncer_router.get_resource_url("hr-system")
        assert url == "https://hr.example.com/mcp"

    def test_get_resource_url_none_for_unknown(self, syncer_router):
        assert syncer_router.get_resource_url("nonexistent") is None

    def test_list_resources_includes_syncer(self, syncer_router):
        resources = syncer_router.list_resources()
        assert "hr-system" in resources
        assert "finance-api" in resources
        assert resources["hr-system"]["url"] == "https://hr.example.com/mcp"

    def test_get_resource_for_path_canonical(self, syncer_router):
        """Syncer resources are reachable via canonical /{name} routing."""
        assert syncer_router.get_resource_for_path("/hr-system") == "hr-system"

    def test_get_resource_for_path_unknown(self, syncer_router):
        assert syncer_router.get_resource_for_path("/nonexistent") is None

    def test_syncer_takes_priority_over_static(self, mock_syncer):
        """When both syncer and static resources exist, syncer wins."""
        from okta_agent_proxy.config import ResourceConfig, ResourceAuthConfig

        static_resource = ResourceConfig(
            name="hr-system",
            url="http://old-hr:8000/mcp",
            paths=["/hr"],
            auth_method="pre-shared-key",
            auth_config=ResourceAuthConfig(key="old-key"),
        )
        router = ResourceRouter(
            resources_config={"hr-system": static_resource},
            syncer=mock_syncer,
        )

        config = router.get_resource_config("hr-system")
        # Syncer's URL should win
        assert config.url == "https://hr.example.com/mcp"
        assert isinstance(config, ResolvedResourceConfigAdapter)

    def test_static_resource_still_works_when_not_in_syncer(self, mock_syncer):
        """Static resources are returned when syncer doesn't have them."""
        from okta_agent_proxy.config import ResourceConfig, ResourceAuthConfig

        static_resource = ResourceConfig(
            name="legacy-system",
            url="http://legacy:8000/mcp",
            paths=["/legacy"],
            auth_method="pre-shared-key",
            auth_config=ResourceAuthConfig(key="key"),
        )
        router = ResourceRouter(
            resources_config={"legacy-system": static_resource},
            syncer=mock_syncer,
        )

        config = router.get_resource_config("legacy-system")
        assert config is not None
        assert config.url == "http://legacy:8000/mcp"
        # Not a ResolvedResourceConfigAdapter -- it's the original ResourceConfig
        assert not isinstance(config, ResolvedResourceConfigAdapter)


# ============================================================================
# Scope condition logic in cross_app_access.py
# ============================================================================


class TestScopeConditionLogic:

    def test_allow_all_unions_requested_and_configured(self):
        result = OktaCrossAppAccessManager.apply_scope_condition(
            ["mcp:read", "mcp:write"], ["read"], "ALLOW_ALL"
        )
        assert result == ["mcp:read", "mcp:write", "read"]

    def test_allow_all_default_when_none_is_empty(self):
        result = OktaCrossAppAccessManager.apply_scope_condition(None, None, None)
        assert result == []

    def test_include_only(self):
        result = OktaCrossAppAccessManager.apply_scope_condition(
            ["mcp:read", "mcp:write", "admin"],
            ["mcp:read", "mcp:write"],
            "INCLUDE_ONLY",
        )
        assert result == ["mcp:read", "mcp:write"]

    def test_disallow(self):
        result = OktaCrossAppAccessManager.apply_scope_condition(
            ["mcp:read", "mcp:write", "admin"],
            ["admin"],
            "DISALLOW",
        )
        assert result == ["mcp:read", "mcp:write"]

    def test_disallow_all_returns_empty(self):
        result = OktaCrossAppAccessManager.apply_scope_condition(
            ["admin"],
            ["admin"],
            "DISALLOW",
        )
        assert result == []

    def test_include_only_empty_resource_scopes(self):
        # INCLUDE_ONLY with an empty configured list = restrict to nothing.
        # The old behavior (fall through to requested) was a bug.
        result = OktaCrossAppAccessManager.apply_scope_condition(
            ["mcp:read"], [], "INCLUDE_ONLY"
        )
        assert result == []


# ============================================================================
# UnifiedMCPHandler refresh_catalog
# ============================================================================


class TestUnifiedHandlerRefreshCatalog:

    @pytest.mark.asyncio
    async def test_refresh_catalog_clears_tool_cache(self):
        from okta_agent_proxy.mcp.unified_handler import UnifiedMCPHandler

        handler = UnifiedMCPHandler(
            MagicMock(), MagicMock(), MagicMock()
        )
        # Seed something in tool cache
        handler._tool_cache["agent-1"] = {"tools": [], "tool_map": {}}
        assert "agent-1" in handler._tool_cache

        await handler.refresh_catalog()
        assert "agent-1" not in handler._tool_cache

    @pytest.mark.asyncio
    async def test_refresh_catalog_with_cache_service(self):
        from okta_agent_proxy.mcp.unified_handler import UnifiedMCPHandler

        cache_service = MagicMock()
        cache_service.clear_prefix = AsyncMock()

        handler = UnifiedMCPHandler(
            MagicMock(), MagicMock(), MagicMock(),
            cache_service=cache_service,
        )
        handler._tool_cache["agent-1"] = {"tools": [], "tool_map": {}}

        await handler.refresh_catalog()
        assert "agent-1" not in handler._tool_cache


# ============================================================================
# ProxyHandler with syncer-backed router
# ============================================================================


class TestProxyHandlerWithSyncer:

    @pytest.mark.asyncio
    @patch("okta_agent_proxy.proxy.handler.check_agent_can_access_resource", new_callable=AsyncMock, return_value=True)
    async def test_proxy_routes_to_syncer_resource(self, mock_authz):
        """ProxyHandler resolves resource from syncer via router."""
        from okta_agent_proxy.proxy.handler import ProxyHandler

        # Use pre-shared-key resource to avoid token exchange complexity
        psk_resource = _make_resolved_resource(
            name="api-keys",
            resource_id="secret123",
            mcp_url="https://keys.example.com/mcp",
            connection_type=OktaConnectionType.SECRET,
            auth_method="pre-shared-key",
        )
        syncer = MagicMock()
        syncer.get_resource.side_effect = lambda n: psk_resource if n == "api-keys" else None
        syncer.get_all_resources.return_value = [psk_resource]

        router = ResourceRouter(resources_config={}, syncer=syncer)

        validator = MagicMock()
        validator.validate_token = AsyncMock(return_value={
            "sub": "user@test.com", "aud": "test-client",
        })

        store = MagicMock()
        agent_config = {
            "agent_id": "claude-code",
            "client_id": "test-client",
            "resource_access": ["api-keys"],
        }
        store.get_agent_by_name.return_value = agent_config
        store.get_all_agents.return_value = [agent_config]
        store.get_agent.return_value = MagicMock(client_id="test-client")

        handler = ProxyHandler(router, validator, store)
        handler.session_manager = MagicMock()
        handler.session_manager.get_or_create_session = AsyncMock(return_value="sess-1")

        # Mock the HTTP response from resource
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.headers = {"content-type": "application/json"}
        mock_response.json.return_value = {
            "jsonrpc": "2.0", "id": "1",
            "result": {"tools": [{"name": "lookup", "description": "Lookup key"}]},
        }

        # Mock auth handler creation to avoid needing real PSK config
        mock_auth_handler = MagicMock()
        mock_auth_handler.get_auth_headers = AsyncMock(return_value={"X-API-Key": "test"})

        with patch("okta_agent_proxy.auth.resource_token_resolver.create_auth_handler", return_value=mock_auth_handler):
            with patch("okta_agent_proxy.proxy.handler.httpx.AsyncClient") as mock_client_cls:
                mock_client = AsyncMock()
                mock_client.__aenter__ = AsyncMock(return_value=mock_client)
                mock_client.__aexit__ = AsyncMock(return_value=False)
                mock_client.post.return_value = mock_response
                mock_client_cls.return_value = mock_client

                result = await handler.proxy_request(
                    request_path="/api-keys",
                    method="tools/list",
                    params={},
                    auth_header="Bearer test-jwt",
                    headers={"x-mcp-agent": "claude-code"},
                )

        assert "tools" in result
        assert result["tools"][0]["name"] == "lookup"


# ============================================================================
# Backward compatibility (no syncer)
# ============================================================================


class TestBackwardCompatibility:

    def test_router_without_syncer_works(self):
        from okta_agent_proxy.config import ResourceConfig, ResourceAuthConfig

        resource = ResourceConfig(
            name="legacy",
            url="http://legacy:8000",
            paths=["/legacy"],
            auth_method="pre-shared-key",
            auth_config=ResourceAuthConfig(key="key"),
        )
        router = ResourceRouter(resources_config={"legacy": resource})
        assert router.syncer is None
        config = router.get_resource_config("legacy")
        assert config.url == "http://legacy:8000"

    def test_router_with_empty_syncer(self):
        syncer = MagicMock()
        syncer.get_resource.return_value = None
        syncer.get_all_resources.return_value = []

        from okta_agent_proxy.config import ResourceConfig, ResourceAuthConfig

        resource = ResourceConfig(
            name="static",
            url="http://static:8000",
            paths=["/static"],
            auth_method="pre-shared-key",
            auth_config=ResourceAuthConfig(key="key"),
        )
        router = ResourceRouter(
            resources_config={"static": resource}, syncer=syncer
        )
        # Syncer returns None, so falls through to static
        config = router.get_resource_config("static")
        assert config.url == "http://static:8000"
