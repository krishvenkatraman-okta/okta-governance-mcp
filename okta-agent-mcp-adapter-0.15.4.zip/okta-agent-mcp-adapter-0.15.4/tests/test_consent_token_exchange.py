"""
Tests for consent-issued gateway code exchange via the token endpoint.

Verifies that codes issued by the consent interstitial flow are correctly
exchanged through both CIMD and DCR token endpoint paths, and that
_capture_token_mapping is called for UserTokenStore integration.
"""

import json
import pytest
from unittest.mock import AsyncMock, MagicMock, patch, call
from urllib.parse import urlparse, parse_qs

from starlette.applications import Starlette
from starlette.routing import Route
from starlette.requests import Request
from starlette.responses import JSONResponse
from starlette.testclient import TestClient

from okta_agent_proxy.auth.confidential_relay import ConfidentialRelay, RelayError
from okta_agent_proxy.auth.client_registry import ClientRegistry
from okta_agent_proxy.auth.gateway_code_manager import GatewayCodeManager


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

CIMD_CLIENT_ID = "https://myapp.example.com/oauth.json"
DCR_CLIENT_ID = "dcr_auto_12345"


def _build_token_app(relay, registry, capture_fn=None):
    """Build a minimal Starlette app with the CIMD/DCR token exchange paths."""
    _capture = capture_fn or MagicMock()

    async def token_endpoint(request: Request):
        try:
            content_type = request.headers.get("content-type", "")
            if content_type.startswith("application/x-www-form-urlencoded"):
                body = dict(await request.form())
            else:
                body = await request.json()
        except Exception:
            body = dict(request.query_params)

        grant_type = body.get("grant_type")
        client_id = body.get("client_id", "")

        # CIMD path
        if client_id and ClientRegistry._is_cimd_url(client_id):
            if grant_type == "authorization_code":
                code = body.get("code")
                if code:
                    try:
                        client_info = await registry.resolve(client_id)
                        if client_info and client_info.registration_source in ("cimd", "cimd-matched"):
                            tokens = await relay.exchange_code(code, client_id)
                            if tokens.get("access_token") and tokens.get("id_token"):
                                _capture(
                                    tokens["access_token"],
                                    tokens["id_token"],
                                    tokens.get("refresh_token"),
                                    client_id,
                                    tokens.get("expires_in", 3600),
                                )
                            return JSONResponse(tokens)
                    except RelayError as e:
                        return JSONResponse(
                            {"error": "invalid_grant", "error_description": str(e)},
                            status_code=400,
                        )

        # DCR path
        if client_id and not ClientRegistry._is_cimd_url(client_id):
            dcr_info = registry._resolve_dcr(client_id)
            if dcr_info is not None:
                if grant_type == "authorization_code":
                    code = body.get("code")
                    if code:
                        try:
                            tokens = await relay.exchange_code(code, client_id)
                            if tokens.get("access_token") and tokens.get("id_token"):
                                _capture(
                                    tokens["access_token"],
                                    tokens["id_token"],
                                    tokens.get("refresh_token"),
                                    client_id,
                                    tokens.get("expires_in", 3600),
                                )
                            return JSONResponse(tokens)
                        except RelayError as e:
                            return JSONResponse(
                                {"error": "invalid_grant", "error_description": str(e)},
                                status_code=400,
                            )

        return JSONResponse(
            {"error": "invalid_client", "error_description": "Unknown client"},
            status_code=401,
        )

    return Starlette(routes=[
        Route("/oauth2/v1/token", token_endpoint, methods=["POST"]),
    ])


def _make_cimd_client_info():
    info = MagicMock()
    info.registration_source = "cimd"
    info.agent_config = {"agent_id": "agent-1", "client_id": "0oa_xyz"}
    return info


def _make_dcr_info():
    info = MagicMock()
    info.registration_source = "dcr"
    return info


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------


class TestConsentCodeCIMDPath:
    def test_consent_code_exchanged_via_cimd_path(self):
        """CIMD client_id + consent-issued gateway code → tokens returned."""
        relay = ConfidentialRelay(
            gateway_base_url="http://localhost:8000",
            okta_domain="dev-test.okta.com",
        )
        # Issue a code via the shared code manager (simulating consent-complete)
        gateway_code = relay._code_manager.issue_code(
            client_id=CIMD_CLIENT_ID,
            tokens={
                "access_token": "at_consent_123",
                "id_token": "idt_consent_123",
                "refresh_token": "rt_consent_123",
                "expires_in": 3600,
            },
            extra={"relay_client_id": "rc", "relay_client_secret": "rs"},
        )

        registry = AsyncMock()
        registry.resolve.return_value = _make_cimd_client_info()

        capture = MagicMock()
        app = _build_token_app(relay, registry, capture_fn=capture)
        client = TestClient(app)

        resp = client.post("/oauth2/v1/token", data={
            "grant_type": "authorization_code",
            "code": gateway_code,
            "client_id": CIMD_CLIENT_ID,
        })

        assert resp.status_code == 200
        tokens = resp.json()
        assert tokens["access_token"] == "at_consent_123"
        assert tokens["id_token"] == "idt_consent_123"
        assert tokens["token_type"] == "Bearer"

    def test_consent_code_token_mapping_captured(self):
        """Verify _capture_token_mapping is called after exchange."""
        relay = ConfidentialRelay(
            gateway_base_url="http://localhost:8000",
            okta_domain="dev-test.okta.com",
        )
        gateway_code = relay._code_manager.issue_code(
            client_id=CIMD_CLIENT_ID,
            tokens={
                "access_token": "at_map",
                "id_token": "idt_map",
                "refresh_token": "rt_map",
                "expires_in": 7200,
            },
        )

        registry = AsyncMock()
        registry.resolve.return_value = _make_cimd_client_info()

        capture = MagicMock()
        app = _build_token_app(relay, registry, capture_fn=capture)
        client = TestClient(app)

        resp = client.post("/oauth2/v1/token", data={
            "grant_type": "authorization_code",
            "code": gateway_code,
            "client_id": CIMD_CLIENT_ID,
        })

        assert resp.status_code == 200
        capture.assert_called_once_with(
            "at_map", "idt_map", "rt_map", CIMD_CLIENT_ID, 7200,
        )


class TestConsentCodeDCRPath:
    def test_consent_code_exchanged_via_dcr_path(self):
        """DCR client_id + consent-issued gateway code → tokens returned."""
        relay = ConfidentialRelay(
            gateway_base_url="http://localhost:8000",
            okta_domain="dev-test.okta.com",
        )
        gateway_code = relay._code_manager.issue_code(
            client_id=DCR_CLIENT_ID,
            tokens={
                "access_token": "at_dcr_consent",
                "id_token": "idt_dcr_consent",
                "expires_in": 3600,
            },
        )

        registry = AsyncMock()
        registry.resolve.return_value = None
        registry._resolve_dcr.return_value = _make_dcr_info()

        app = _build_token_app(relay, registry)
        client = TestClient(app)

        resp = client.post("/oauth2/v1/token", data={
            "grant_type": "authorization_code",
            "code": gateway_code,
            "client_id": DCR_CLIENT_ID,
        })

        assert resp.status_code == 200
        tokens = resp.json()
        assert tokens["access_token"] == "at_dcr_consent"
        assert tokens["id_token"] == "idt_dcr_consent"


class TestConsentCodeErrors:
    def test_consent_code_replay_rejected(self):
        """Second exchange of same code → 400 invalid_grant."""
        relay = ConfidentialRelay(
            gateway_base_url="http://localhost:8000",
            okta_domain="dev-test.okta.com",
        )
        gateway_code = relay._code_manager.issue_code(
            client_id=CIMD_CLIENT_ID,
            tokens={"access_token": "at", "id_token": "idt"},
        )

        registry = AsyncMock()
        registry.resolve.return_value = _make_cimd_client_info()

        app = _build_token_app(relay, registry)
        client = TestClient(app)

        # First exchange succeeds
        r1 = client.post("/oauth2/v1/token", data={
            "grant_type": "authorization_code",
            "code": gateway_code,
            "client_id": CIMD_CLIENT_ID,
        })
        assert r1.status_code == 200

        # Replay fails
        r2 = client.post("/oauth2/v1/token", data={
            "grant_type": "authorization_code",
            "code": gateway_code,
            "client_id": CIMD_CLIENT_ID,
        })
        assert r2.status_code == 400
        assert r2.json()["error"] == "invalid_grant"

    def test_consent_code_client_mismatch(self):
        """Wrong client_id → 400."""
        relay = ConfidentialRelay(
            gateway_base_url="http://localhost:8000",
            okta_domain="dev-test.okta.com",
        )
        gateway_code = relay._code_manager.issue_code(
            client_id=CIMD_CLIENT_ID,
            tokens={"access_token": "at", "id_token": "idt"},
        )

        wrong_client = "https://wrong.example.com/oauth.json"
        registry = AsyncMock()
        info = MagicMock()
        info.registration_source = "cimd"
        registry.resolve.return_value = info

        app = _build_token_app(relay, registry)
        client = TestClient(app)

        resp = client.post("/oauth2/v1/token", data={
            "grant_type": "authorization_code",
            "code": gateway_code,
            "client_id": wrong_client,
        })
        assert resp.status_code == 400
        assert "mismatch" in resp.json()["error_description"]
