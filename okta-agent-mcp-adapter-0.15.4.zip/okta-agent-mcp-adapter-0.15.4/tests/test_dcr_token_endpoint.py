"""Tests for DCR token endpoint handling in oauth_token_endpoint.

Validates:
- DCR code exchange routes through confidential relay
- DCR refresh token routes through confidential relay
- Unlinked DCR agent falls through (no relay session)
- Audit events emitted on success and failure
- CIMD token exchange unchanged (regression)
"""

import json
import sys
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from okta_agent_proxy.audit.events import AuditEventType, AuditSeverity
from okta_agent_proxy.auth.client_registry import ClientInfo
from okta_agent_proxy.auth.confidential_relay import RelayError


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _dcr_client_info(client_id="dcr_abc123", agent_config=None):
    return ClientInfo(
        client_id=client_id,
        client_name="Test DCR Client",
        registration_source="dcr",
        redirect_uris=["http://localhost:9999/callback"],
        grant_types=["authorization_code"],
        response_types=["code"],
        token_endpoint_auth_method="none",
        jwks_uri=None,
        scope=None,
        trust_level=None,
        agent_config=agent_config,
        cimd_metadata=None,
        resource_access=[],
    )


def _mock_request(form_data=None, headers=None):
    req = MagicMock()
    req.headers = headers or {"content-type": "application/x-www-form-urlencoded"}

    async def _form():
        return form_data or {}

    req.form = _form
    req.query_params = {}
    return req


# ---------------------------------------------------------------------------
# App import helper (same as test_dcr_authorize_flow.py)
# ---------------------------------------------------------------------------

def _ensure_app_imported():
    mod = sys.modules.get("okta_agent_proxy.app")
    if mod is not None and hasattr(mod, "client_registry"):
        return

    sys.modules.pop("okta_agent_proxy.app", None)

    import okta_agent_proxy.database as _db_mod
    _orig_get = _db_mod.get_config_store
    _orig_store = _db_mod._config_store
    _mock_store = MagicMock()
    _mock_store.get_all_resources.return_value = []
    _mock_store.get_all_agents.return_value = []
    _db_mod.get_config_store = lambda **kw: _mock_store
    _db_mod._config_store = _mock_store
    try:
        import importlib
        import okta_agent_proxy.app
        importlib.reload(okta_agent_proxy.app)
    except Exception:
        sys.modules.pop("okta_agent_proxy.app", None)
        raise
    finally:
        _db_mod.get_config_store = _orig_get
        _db_mod._config_store = _orig_store


@pytest.fixture
def patched():
    _ensure_app_imported()

    patches_to_start = [
        patch("okta_agent_proxy.app.client_registry"),
        patch("okta_agent_proxy.app.confidential_relay"),
        patch("okta_agent_proxy.app.emit_audit_event", new_callable=AsyncMock),
        patch("okta_agent_proxy.app.config"),
    ]

    started = [p.start() for p in patches_to_start]
    mocks = {
        "registry": started[0],
        "relay": started[1],
        "audit": started[2],
        "config": started[3],
    }

    mocks["registry"]._resolve_dcr = MagicMock(return_value=None)
    mocks["registry"]._is_cimd_url = staticmethod(
        lambda cid: cid.startswith("https://") or cid.startswith("http://localhost")
    )
    mocks["registry"].resolve = AsyncMock(return_value=None)
    mocks["relay"].exchange_code = AsyncMock(return_value={
        "access_token": "at_xxx",
        "id_token": "idt_xxx",
        "token_type": "Bearer",
        "expires_in": 3600,
        "refresh_token": "rt_xxx",
    })
    mocks["relay"].refresh_token = AsyncMock(return_value={
        "access_token": "at_refreshed",
        "id_token": "idt_refreshed",
        "token_type": "Bearer",
        "expires_in": 3600,
        "refresh_token": "rt_refreshed",
    })

    mocks["config"].gateway.okta_domain = "dev-test.okta.com"

    yield mocks

    for p in patches_to_start:
        p.stop()


def _handler():
    from okta_agent_proxy.app import oauth_token_endpoint
    return oauth_token_endpoint


# ---------------------------------------------------------------------------
# DCR code exchange
# ---------------------------------------------------------------------------

class TestDCRTokenExchange:

    async def test_dcr_token_exchange_linked(self, patched):
        """Code exchange for linked DCR client routes through relay."""
        patched["registry"]._resolve_dcr.return_value = _dcr_client_info(
            agent_config={"client_id": "0oa_real", "client_secret": "secret"},
        )
        handler = _handler()
        resp = await handler(_mock_request(form_data={
            "grant_type": "authorization_code",
            "client_id": "dcr_abc123",
            "code": "gateway_code_xyz",
        }))
        assert resp.status_code == 200
        body = json.loads(resp.body)
        assert body["access_token"] == "at_xxx"
        patched["relay"].exchange_code.assert_called_once_with(
            "gateway_code_xyz", "dcr_abc123"
        )

    async def test_dcr_token_refresh_linked(self, patched):
        """Refresh token for linked DCR client routes through relay."""
        patched["registry"]._resolve_dcr.return_value = _dcr_client_info(
            agent_config={"client_id": "0oa_real", "client_secret": "secret"},
        )
        handler = _handler()
        resp = await handler(_mock_request(form_data={
            "grant_type": "refresh_token",
            "client_id": "dcr_abc123",
            "refresh_token": "rt_original",
        }))
        assert resp.status_code == 200
        body = json.loads(resp.body)
        assert body["access_token"] == "at_refreshed"
        patched["relay"].refresh_token.assert_called_once_with(
            "rt_original", "dcr_abc123", scope=""
        )

    async def test_dcr_token_exchange_unlinked_falls_through(self, patched):
        """Unlinked DCR agent with no relay session falls through to standard flow."""
        patched["registry"]._resolve_dcr.return_value = _dcr_client_info(
            agent_config={"client_id": "dcr_abc123", "client_secret": "placeholder"},
        )
        # Relay raises because there's no session for this code
        patched["relay"].exchange_code = AsyncMock(
            side_effect=RelayError("Unknown gateway code")
        )
        handler = _handler()
        resp = await handler(_mock_request(form_data={
            "grant_type": "authorization_code",
            "client_id": "dcr_abc123",
            "code": "bad_code",
        }))
        # Should return 400 from relay error
        assert resp.status_code == 400
        body = json.loads(resp.body)
        assert body["error"] == "invalid_grant"


# ---------------------------------------------------------------------------
# Audit events
# ---------------------------------------------------------------------------

class TestDCRTokenAudit:

    async def test_dcr_token_exchange_audit_success(self, patched):
        """DCR_TOKEN_EXCHANGE_SUCCESS emitted on successful code exchange."""
        patched["registry"]._resolve_dcr.return_value = _dcr_client_info()
        handler = _handler()
        await handler(_mock_request(form_data={
            "grant_type": "authorization_code",
            "client_id": "dcr_abc123",
            "code": "gateway_code",
        }))
        audit_calls = [
            c for c in patched["audit"].call_args_list
            if c[0][0] == AuditEventType.DCR_TOKEN_EXCHANGE_SUCCESS
        ]
        assert len(audit_calls) == 1
        details = audit_calls[0][1]["details"]
        assert details["dcr_client_id"] == "dcr_abc123"
        assert details["grant_type"] == "authorization_code"

    async def test_dcr_token_exchange_audit_failure(self, patched):
        """DCR_TOKEN_EXCHANGE_FAILURE emitted on relay error."""
        patched["registry"]._resolve_dcr.return_value = _dcr_client_info()
        patched["relay"].exchange_code = AsyncMock(
            side_effect=RelayError("Code expired")
        )
        handler = _handler()
        await handler(_mock_request(form_data={
            "grant_type": "authorization_code",
            "client_id": "dcr_abc123",
            "code": "expired_code",
        }))
        audit_calls = [
            c for c in patched["audit"].call_args_list
            if c[0][0] == AuditEventType.DCR_TOKEN_EXCHANGE_FAILURE
        ]
        assert len(audit_calls) == 1
        assert audit_calls[0][1]["severity"] == AuditSeverity.WARNING
        assert audit_calls[0][1]["outcome"] == "failure"

    async def test_dcr_token_refresh_audit_success(self, patched):
        """DCR_TOKEN_EXCHANGE_SUCCESS emitted on successful refresh."""
        patched["registry"]._resolve_dcr.return_value = _dcr_client_info()
        handler = _handler()
        await handler(_mock_request(form_data={
            "grant_type": "refresh_token",
            "client_id": "dcr_abc123",
            "refresh_token": "rt_xyz",
        }))
        audit_calls = [
            c for c in patched["audit"].call_args_list
            if c[0][0] == AuditEventType.DCR_TOKEN_EXCHANGE_SUCCESS
        ]
        assert len(audit_calls) == 1
        assert audit_calls[0][1]["details"]["grant_type"] == "refresh_token"


# ---------------------------------------------------------------------------
# Regression: CIMD unchanged
# ---------------------------------------------------------------------------

class TestCIMDTokenRegression:

    async def test_cimd_token_exchange_unchanged(self, patched):
        """CIMD token exchange still works via relay — DCR path not triggered."""
        cimd_info = MagicMock()
        cimd_info.registration_source = "cimd"
        patched["registry"].resolve = AsyncMock(return_value=cimd_info)

        handler = _handler()
        resp = await handler(_mock_request(form_data={
            "grant_type": "authorization_code",
            "client_id": "https://example.com/oauth.json",
            "code": "cimd_gateway_code",
        }))
        assert resp.status_code == 200
        patched["relay"].exchange_code.assert_called_once_with(
            "cimd_gateway_code", "https://example.com/oauth.json"
        )
        # DCR path should NOT be called
        patched["registry"]._resolve_dcr.assert_not_called()
