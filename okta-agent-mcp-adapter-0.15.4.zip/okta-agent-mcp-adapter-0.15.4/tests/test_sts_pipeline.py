"""
Tests for STS token exchange wired into the proxy pipeline.

Covers:
- ProxyHandler dispatches to okta-sts auth method
- consent_required produces structured error (not proxied)
- Successful exchange produces proxied request with Bearer token
- Token cache hit skips the exchange
- UnifiedMCPHandler formats consent_required as MCP JSON-RPC error
- create_auth_handler("okta-sts") returns Bearer handler
- TokenCache STS methods (get/set/invalidate)
"""

import json
import pytest
from unittest.mock import AsyncMock, MagicMock, patch, PropertyMock

from okta_agent_proxy.auth.resource_auth import create_auth_handler
from okta_agent_proxy.auth.resource_token_resolver import ResourceAuthResult
from okta_agent_proxy.cache.token_cache import TokenCache


# ============================================================================
# create_auth_handler — okta-sts
# ============================================================================


class TestCreateAuthHandlerOktaSts:

    def test_okta_sts_returns_bearer_handler(self):
        handler = create_auth_handler("okta-sts", {}, access_token="gho_abc123")
        assert handler is not None

    @pytest.mark.asyncio
    async def test_okta_sts_injects_bearer_token(self):
        handler = create_auth_handler("okta-sts", {}, access_token="gho_abc123")
        headers = await handler.get_auth_headers()
        assert headers == {"Authorization": "Bearer gho_abc123"}

    def test_okta_sts_no_token_returns_none(self):
        handler = create_auth_handler("okta-sts", {})
        assert handler is None

    def test_okta_sts_requires_caching(self):
        handler = create_auth_handler("okta-sts", {}, access_token="tok")
        assert handler.requires_caching() is True


# ============================================================================
# TokenCache STS methods
# ============================================================================


class TestTokenCacheSts:

    def test_get_miss(self):
        cache = TokenCache(max_size=100, ttl_seconds=60)
        result = cache.get_sts_token("user1", "orn:okta:rsc123")
        assert result is None

    def test_set_and_get(self):
        cache = TokenCache(max_size=100, ttl_seconds=60)
        cache.set_sts_token("user1", "orn:okta:rsc123", "gho_tok", expires_in=3600)
        result = cache.get_sts_token("user1", "orn:okta:rsc123")
        assert result == "gho_tok"

    def test_invalidate(self):
        cache = TokenCache(max_size=100, ttl_seconds=60)
        cache.set_sts_token("user1", "orn:okta:rsc123", "gho_tok", expires_in=3600)
        cache.invalidate_sts_token("user1", "orn:okta:rsc123")
        result = cache.get_sts_token("user1", "orn:okta:rsc123")
        assert result is None

    def test_different_users_different_keys(self):
        cache = TokenCache(max_size=100, ttl_seconds=60)
        cache.set_sts_token("user1", "orn:okta:rsc123", "tok1", expires_in=3600)
        cache.set_sts_token("user2", "orn:okta:rsc123", "tok2", expires_in=3600)
        assert cache.get_sts_token("user1", "orn:okta:rsc123") == "tok1"
        assert cache.get_sts_token("user2", "orn:okta:rsc123") == "tok2"

    def test_ttl_clamped_to_max(self):
        """TTL is min(expires_in - 60, 28800)."""
        cache = TokenCache(max_size=100, ttl_seconds=60)
        # With a very large expires_in, TTL should be clamped to 28800
        cache.set_sts_token("user1", "orn:okta:rsc1", "tok", expires_in=999999)
        # Token should be present (we can't easily check the TTL, but
        # the set should succeed without error)
        assert cache.get_sts_token("user1", "orn:okta:rsc1") == "tok"

    def test_sts_key_format(self):
        key = TokenCache._make_sts_key("user@example.com", "orn:okta:idp:00o:client-auth-settings:rsc123")
        assert key.startswith("sts:")
        parts = key.split(":")
        assert len(parts) == 3
        # Hash parts should be 12 chars each
        assert len(parts[1]) == 12
        assert len(parts[2]) == 12


# ============================================================================
# ProxyHandler — okta-sts dispatch
# ============================================================================


def _make_proxy_handler():
    """Create a ProxyHandler with mocked dependencies."""
    from okta_agent_proxy.proxy.handler import ProxyHandler

    router = MagicMock()
    router.get_resource_for_path.return_value = "github-org"

    # Add resolver to the mock router
    from okta_agent_proxy.auth.resource_token_resolver import ResourceTokenResolver
    resolver = MagicMock(spec=ResourceTokenResolver)
    resolver.resolve_auth_headers = AsyncMock()
    router.resolver = resolver

    # Mock resource config with okta-sts auth method
    resource_config = MagicMock()
    resource_config.url = "https://github.example.com/mcp"
    resource_config.auth_method = "okta-sts"
    resource_config.enabled = True
    resource_config.metadata = {
        "resource_indicator": "orn:okta:idp:00o:client-auth-settings:rsc123",
        "app_instance_name": "GitHub Enterprise",
    }
    router.get_resource_config.return_value = resource_config

    validator = MagicMock()
    validator.validate_token = AsyncMock(return_value={
        "sub": "user@example.com",
        "aud": "0oa_test",
        "cid": "0oa_test",
    })

    store = MagicMock()
    store.get_all_agents.return_value = []
    store.get_agent_by_name.return_value = {
        "agent_id": "test-agent",
        "client_id": "0oa_test",
        "private_key": "PLACEHOLDER",
        "principal_id": "agt123",
        "resource_access": ["github-org"],
        "enabled": True,
    }

    handler = ProxyHandler(router, validator, store)
    return handler, router, resource_config


class TestProxyHandlerStsDispatch:

    @pytest.mark.asyncio
    @patch("okta_agent_proxy.proxy.handler.check_agent_can_access_resource", new_callable=AsyncMock, return_value=True)
    async def test_consent_required_returns_structured_error(self, mock_authz):
        handler, router, _ = _make_proxy_handler()

        consent_result = {
            "status": "consent_required",
            "interaction_uri": "https://okta.example.com/consent/abc",
            "provider": "GitHub Enterprise",
            "error_description": "User must authorize",
            "resource_indicator": "orn:okta:rsc123",
        }

        router.resolver.resolve_auth_headers = AsyncMock(
            return_value=ResourceAuthResult(
                consent_required=consent_result,
                error="consent_required",
                error_message="User consent required",
            )
        )

        result = await handler.proxy_request(
            request_path="/github-org",
            method="tools/call",
            params={"name": "list_repos"},
            auth_header="Bearer eyJ.test.token",
            headers={"X-MCP-Agent": "test-agent"},
        )

        assert result["error"] == "consent_required"
        assert result["consent_url"] == "https://okta.example.com/consent/abc"
        assert result["provider"] == "GitHub Enterprise"
        assert "re-run" in result["instructions"].lower() or "re-run" in result["retry_hint"].lower()
        assert result["expires_in"] == 600

    @pytest.mark.asyncio
    @patch("okta_agent_proxy.proxy.handler.check_agent_can_access_resource", new_callable=AsyncMock, return_value=True)
    async def test_successful_exchange_proxies_request(self, mock_authz):
        handler, router, _ = _make_proxy_handler()

        router.resolver.resolve_auth_headers = AsyncMock(
            return_value=ResourceAuthResult(headers={"Authorization": "Bearer gho_abc123"})
        )

        with patch("okta_agent_proxy.proxy.handler.httpx.AsyncClient") as mock_httpx:
            mock_response = MagicMock()
            mock_response.status_code = 200
            mock_response.headers = {"content-type": "application/json"}
            mock_response.json.return_value = {
                "jsonrpc": "2.0",
                "id": "1",
                "result": {"content": [{"type": "text", "text": "OK"}]},
            }

            mock_client = AsyncMock()
            mock_client.post.return_value = mock_response
            mock_client.__aenter__ = AsyncMock(return_value=mock_client)
            mock_client.__aexit__ = AsyncMock(return_value=False)
            mock_httpx.return_value = mock_client

            # Mock session manager
            handler.session_manager.get_or_create_session = AsyncMock(return_value="session-1")

            result = await handler.proxy_request(
                request_path="/github-org",
                method="tools/call",
                params={"name": "list_repos"},
                auth_header="Bearer eyJ.test.token",
                headers={"X-MCP-Agent": "test-agent"},
            )

        # Should have proxied successfully
        assert "error" not in result or result.get("error") is None
        assert result.get("content") is not None or "content" in str(result)

    @pytest.mark.asyncio
    @patch("okta_agent_proxy.proxy.handler.check_agent_can_access_resource", new_callable=AsyncMock, return_value=True)
    async def test_exchange_failure_returns_error(self, mock_authz):
        handler, router, _ = _make_proxy_handler()

        router.resolver.resolve_auth_headers = AsyncMock(
            return_value=ResourceAuthResult(error="sts_exchange_failed", error_message="STS exchange failed")
        )

        result = await handler.proxy_request(
            request_path="/github-org",
            method="tools/call",
            params={"name": "list_repos"},
            auth_header="Bearer eyJ.test.token",
            headers={"X-MCP-Agent": "test-agent"},
        )

        assert result["error"] == "sts_exchange_failed"


# ============================================================================
# ResourceTokenResolver — STS token cache integration
# ============================================================================


class TestResolverStsCache:

    @pytest.mark.asyncio
    async def test_cache_hit_skips_exchange(self):
        from okta_agent_proxy.auth.resource_token_resolver import ResourceTokenResolver
        from okta_agent_proxy.cache.token_cache import TokenCache

        token_cache = TokenCache(max_size=100, ttl_seconds=3600)
        resolver = ResourceTokenResolver(token_cache)

        # Pre-populate cache
        token_cache.set_sts_token("user@example.com", "orn:okta:idp:00o:client-auth-settings:rsc123", "cached_gho_token", 28800)

        resource_config = MagicMock()
        resource_config.auth_method = "okta-sts"
        resource_config.metadata = {"resource_indicator": "orn:okta:idp:00o:client-auth-settings:rsc123"}
        resource_config.connection_id = None
        resource_config.auth_config = MagicMock()
        resource_config.auth_config.model_dump.return_value = {}

        agent_config = {"agent_id": "test-agent", "client_id": "0oa_test", "private_key": "PLACEHOLDER", "principal_id": "agt123"}

        result = await resolver.resolve_auth_headers(
            resource_name="github-org",
            resource_config=resource_config,
            agent_config=agent_config,
            user_id="user@example.com",
            user_id_token="eyJ.test.token",
        )

        assert result.ok
        assert result.headers["Authorization"] == "Bearer cached_gho_token"

    @pytest.mark.asyncio
    async def test_cache_miss_calls_exchanger(self):
        from okta_agent_proxy.auth.resource_token_resolver import ResourceTokenResolver
        from okta_agent_proxy.cache.token_cache import TokenCache

        token_cache = TokenCache(max_size=100, ttl_seconds=3600)
        resolver = ResourceTokenResolver(token_cache)

        resource_config = MagicMock()
        resource_config.auth_method = "okta-sts"
        resource_config.metadata = {"resource_indicator": "orn:okta:idp:00o:client-auth-settings:rsc123"}
        resource_config.connection_id = None
        resource_config.auth_config = MagicMock()
        resource_config.auth_config.model_dump.return_value = {}

        agent_config = {"agent_id": "test-agent", "client_id": "0oa_test", "private_key": "PLACEHOLDER", "principal_id": "agt123"}

        mock_exchanger = MagicMock()
        mock_exchanger.exchange = AsyncMock(return_value={
            "status": "success",
            "access_token": "gho_fresh",
            "token_type": "Bearer",
            "expires_in": 28800,
            "provider": "github-org",
        })

        with patch("okta_agent_proxy.auth.okta_sts_exchanger.OktaSTSTokenExchanger", return_value=mock_exchanger):
            result = await resolver.resolve_auth_headers(
                resource_name="github-org",
                resource_config=resource_config,
                agent_config=agent_config,
                user_id="user@example.com",
                user_id_token="eyJ.test.token",
            )

        assert result.ok
        assert result.headers["Authorization"] == "Bearer gho_fresh"
        # Verify it was cached
        cached = token_cache.get_sts_token("user@example.com", "orn:okta:idp:00o:client-auth-settings:rsc123")
        assert cached == "gho_fresh"


# ============================================================================
# UnifiedMCPHandler — consent_required MCP error
# ============================================================================


class TestUnifiedHandlerConsentError:

    def _make_unified_handler(self):
        from okta_agent_proxy.mcp.unified_handler import UnifiedMCPHandler

        router = MagicMock()
        validator = MagicMock()
        store = MagicMock()

        resource_config = MagicMock()
        resource_config.url = "https://github.example.com/mcp"
        resource_config.auth_method = "okta-sts"
        resource_config.enabled = True
        resource_config.metadata = {
            "resource_indicator": "orn:okta:rsc123",
            "app_instance_name": "GitHub Enterprise",
        }
        router.get_resource_config.return_value = resource_config

        handler = UnifiedMCPHandler(router, validator, store)
        return handler, router, resource_config

    @pytest.mark.asyncio
    @patch("okta_agent_proxy.auth.agent_authz.check_agent_can_access_resource", new_callable=AsyncMock, return_value=True)
    async def test_consent_required_produces_jsonrpc_error(self, mock_authz):
        handler, router, _ = self._make_unified_handler()

        consent_result = {
            "status": "consent_required",
            "interaction_uri": "https://okta.example.com/consent/abc",
            "provider": "GitHub Enterprise",
            "error_description": "User must authorize",
            "resource_indicator": "orn:okta:rsc123",
        }

        # Mock authentication
        handler._authenticate = AsyncMock(return_value=(
            "test-agent",
            {"agent_id": "test-agent", "resource_access": ["github-org"], "client_id": "0oa1"},
            "user@example.com",
            "eyJ.test.token",
        ))

        # Mock _handle_sts_exchange to return consent
        handler._handle_sts_exchange = AsyncMock(return_value=consent_result)

        # Set _last_sts_consent to be set during _get_resource_auth_headers
        original_get_auth = handler._get_resource_auth_headers

        async def mock_get_auth(resource_name, resource_config, agent_config, user_id, token):
            handler._last_sts_consent = consent_result
            return None

        handler._get_resource_auth_headers = mock_get_auth

        body = {
            "jsonrpc": "2.0",
            "id": "req-1",
            "method": "tools/call",
            "params": {"name": "github-org__list_repos", "arguments": {}},
        }

        response, status, headers = await handler.handle(body, {"Authorization": "Bearer eyJ.test"})

        assert status == 200
        assert response["jsonrpc"] == "2.0"
        assert response["id"] == "req-1"
        assert response["error"]["code"] == -32001
        assert "Authorization required" in response["error"]["message"]
        assert response["error"]["data"]["type"] == "consent_required"
        assert response["error"]["data"]["consent_url"] == "https://okta.example.com/consent/abc"
        assert response["error"]["data"]["provider"] == "GitHub Enterprise"
        assert "re-run" in response["error"]["data"]["retry_hint"].lower()
        assert response["error"]["data"]["expires_in"] == 600

    @pytest.mark.asyncio
    async def test_jsonrpc_error_with_data(self):
        from okta_agent_proxy.mcp.unified_handler import UnifiedMCPHandler

        result = UnifiedMCPHandler._jsonrpc_error_with_data(
            "req-1", -32001, "Test error", {"key": "value"}
        )
        assert result["jsonrpc"] == "2.0"
        assert result["id"] == "req-1"
        assert result["error"]["code"] == -32001
        assert result["error"]["message"] == "Test error"
        assert result["error"]["data"] == {"key": "value"}
