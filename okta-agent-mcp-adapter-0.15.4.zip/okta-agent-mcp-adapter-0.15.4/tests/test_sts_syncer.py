"""
Tests for OktaConnectionSyncer handling of STS_ACCESS_TOKEN connections.

Covers:
- Resolving STS_ACCESS_TOKEN into ResolvedResource when resource exists in store
- ResolvedResource has auth_method="okta-sts"
- Metadata includes resource_indicator, app_instance_id, app_instance_name
- Unresolved when resource not in store (same as other types)
- Existing types (IDENTITY_ASSERTION_CUSTOM_AS, etc.) still work
"""

import pytest
from unittest.mock import MagicMock
from datetime import datetime

from okta_agent_proxy.resources.syncer import OktaConnectionSyncer
from okta_agent_proxy.resources.models import (
    OktaConnectionType,
    OktaScopeCondition,
    ResolvedResource,
    Resource,
)


# Real STS_ACCESS_TOKEN connection from the Okta API
STS_ACCESS_TOKEN_CONN = {
    "id": "mcnwecqhmwbcHp7ig1d7",
    "orn": "orn:oktapreview:idp:00oudv75opUSqDo3B1d7:connections:mcnwecqhmwbcHp7ig1d7",
    "resource": {
        "appInstanceId": "0oaweclvlpWSkuYXX1d7",
        "appInstanceName": "Github Enterprise Cloud - Organization",
        "orn": "orn:oktapreview:idp:00oudv75opUSqDo3B1d7:client-auth-settings:rscwecmwxmK9skZBD1d7",
        "resourceType": "APP_INSTANCE",
    },
    "resourceIndicator": "orn:oktapreview:idp:00oudv75opUSqDo3B1d7:client-auth-settings:rscwecmwxmK9skZBD1d7",
    "status": "ACTIVE",
    "connectionType": "STS_ACCESS_TOKEN",
}

# Standard IDENTITY_ASSERTION connection for regression check
IDENTITY_ASSERTION_CONN = {
    "id": "conn-ia-1",
    "connectionType": "IDENTITY_ASSERTION_CUSTOM_AS",
    "status": "ACTIVE",
    "authorizationServer": {
        "orn": "orn:okta:idp:00o:authorization_servers:aus123",
        "issuerUrl": "https://dev-test.okta.com/oauth2/aus123",
    },
    "resourceIndicator": "orn:okta:idp:00o:authorization_servers:aus123",
    "scopes": ["mcp:read"],
    "scopeCondition": "INCLUDE_ONLY",
}


def _mock_resource_store(entries_by_id=None, entries_by_name=None):
    """Create a mock ResourceStore."""
    store = MagicMock()
    entries_by_id = entries_by_id or {}
    entries_by_name = entries_by_name or {}

    store.get_by_id.side_effect = lambda rid: entries_by_id.get(rid, [])
    store.get_by_connection_id = store.get_by_id
    store.get_by_name.side_effect = lambda name: entries_by_name.get(name)
    store.get_all.return_value = list(entries_by_name.values())
    store.create.side_effect = lambda entry: entry
    store.load_cache.return_value = 0
    store.save_sync_state.return_value = None

    return store


def _make_syncer(store=None):
    """Create an OktaConnectionSyncer with test defaults."""
    store = store or _mock_resource_store()
    event_bus = MagicMock()
    event_bus.subscribe = MagicMock()
    event_bus.publish = MagicMock()

    syncer = OktaConnectionSyncer(
        okta_domain="https://dev-test.okta.com",
        api_token="test-token",
        resource_store=store,
        event_bus=event_bus,
    )
    return syncer


# ============================================================================
# STS_ACCESS_TOKEN resolves when resource exists in store
# ============================================================================


class TestMergeConnectionsStsAccessToken:

    def test_resolves_when_resource_in_store(self):
        """STS_ACCESS_TOKEN resolves to ResolvedResource when resource exists."""
        existing = Resource(
            resource_id="rscwecmwxmK9skZBD1d7",
            name="github-proxy",
            mcp_url="https://api.githubcopilot.com/mcp/",
            protocol="mcp",
        )
        store = _mock_resource_store(
            entries_by_id={"rscwecmwxmK9skZBD1d7": [existing]}
        )
        syncer = _make_syncer(store)

        resources, unresolved = syncer._merge_connections([STS_ACCESS_TOKEN_CONN])

        assert len(resources) == 1
        assert len(unresolved) == 0
        assert "github-proxy" in resources

        resolved = resources["github-proxy"]
        assert isinstance(resolved, ResolvedResource)
        assert resolved.mcp_url == "https://api.githubcopilot.com/mcp/"
        assert resolved.protocol == "mcp"

    def test_auth_method_is_okta_sts(self):
        """auth_method is auto-derived as 'okta-sts' from connection type."""
        existing = Resource(
            resource_id="rscwecmwxmK9skZBD1d7",
            name="github-proxy",
            mcp_url="https://api.githubcopilot.com/mcp/",
            protocol="mcp",
        )
        store = _mock_resource_store(
            entries_by_id={"rscwecmwxmK9skZBD1d7": [existing]}
        )
        syncer = _make_syncer(store)

        resources, _ = syncer._merge_connections([STS_ACCESS_TOKEN_CONN])
        resolved = resources["github-proxy"]

        assert resolved.auth_method == "okta-sts"
        assert resolved.connection_type == OktaConnectionType.STS_ACCESS_TOKEN

    def test_metadata_includes_resource_indicator(self):
        """resource_indicator must be in metadata for STS token exchange."""
        existing = Resource(
            resource_id="rscwecmwxmK9skZBD1d7",
            name="github-proxy",
            mcp_url="https://api.githubcopilot.com/mcp/",
            protocol="mcp",
        )
        store = _mock_resource_store(
            entries_by_id={"rscwecmwxmK9skZBD1d7": [existing]}
        )
        syncer = _make_syncer(store)

        resources, _ = syncer._merge_connections([STS_ACCESS_TOKEN_CONN])
        resolved = resources["github-proxy"]

        assert "resource_indicator" in resolved.metadata
        assert resolved.metadata["resource_indicator"] == STS_ACCESS_TOKEN_CONN["resourceIndicator"]

    def test_metadata_includes_app_instance_fields(self):
        """Metadata should include appInstanceId, appInstanceName, etc."""
        existing = Resource(
            resource_id="rscwecmwxmK9skZBD1d7",
            name="github-proxy",
            mcp_url="https://api.githubcopilot.com/mcp/",
            protocol="mcp",
        )
        store = _mock_resource_store(
            entries_by_id={"rscwecmwxmK9skZBD1d7": [existing]}
        )
        syncer = _make_syncer(store)

        resources, _ = syncer._merge_connections([STS_ACCESS_TOKEN_CONN])
        resolved = resources["github-proxy"]

        assert resolved.metadata["app_instance_id"] == "0oaweclvlpWSkuYXX1d7"
        assert resolved.metadata["app_instance_name"] == "Github Enterprise Cloud - Organization"
        assert resolved.metadata["resource_type"] == "APP_INSTANCE"

    def test_scopes_empty_for_sts(self):
        """STS scopes are managed in Okta OIN app, not per-connection."""
        existing = Resource(
            resource_id="rscwecmwxmK9skZBD1d7",
            name="github-proxy",
            mcp_url="https://api.githubcopilot.com/mcp/",
            protocol="mcp",
        )
        store = _mock_resource_store(
            entries_by_id={"rscwecmwxmK9skZBD1d7": [existing]}
        )
        syncer = _make_syncer(store)

        resources, _ = syncer._merge_connections([STS_ACCESS_TOKEN_CONN])
        resolved = resources["github-proxy"]

        assert resolved.scopes == []
        assert resolved.scope_condition == OktaScopeCondition.ALLOW_ALL

    def test_unresolved_when_not_in_store(self):
        """STS_ACCESS_TOKEN goes to unresolved when resource not in store."""
        store = _mock_resource_store()  # empty store
        syncer = _make_syncer(store)

        resources, unresolved = syncer._merge_connections([STS_ACCESS_TOKEN_CONN])

        assert len(resources) == 0
        assert "rscwecmwxmK9skZBD1d7" in unresolved


# ============================================================================
# Regression: existing connection types still work
# ============================================================================


class TestMergeConnectionsRegression:

    def test_identity_assertion_still_works(self):
        """IDENTITY_ASSERTION_CUSTOM_AS connections resolve normally."""
        existing = Resource(
            resource_id="aus123",
            name="deploy-server",
            mcp_url="https://deploy.example.com",
            protocol="mcp",
        )
        store = _mock_resource_store(entries_by_id={"aus123": [existing]})
        syncer = _make_syncer(store)

        resources, unresolved = syncer._merge_connections([IDENTITY_ASSERTION_CONN])

        assert len(resources) == 1
        assert "deploy-server" in resources
        resolved = resources["deploy-server"]
        assert resolved.connection_type == OktaConnectionType.IDENTITY_ASSERTION_CUSTOM_AS
        assert resolved.auth_method == "okta-cross-app"
        assert resolved.scopes == ["mcp:read"]
        assert len(unresolved) == 0

    def test_unresolved_identity_assertion_not_auto_created(self):
        """Non-STS types should NOT be auto-created — they go to unresolved."""
        store = _mock_resource_store()  # empty store
        syncer = _make_syncer(store)

        resources, unresolved = syncer._merge_connections([IDENTITY_ASSERTION_CONN])

        assert len(resources) == 0
        assert "aus123" in unresolved


# ============================================================================
# Mixed connection types
# ============================================================================


class TestMixedConnectionTypes:

    def test_mixed_sts_and_identity_assertion(self):
        """Both types resolve when their resources exist in store."""
        existing_ia = Resource(
            resource_id="aus123",
            name="deploy-server",
            mcp_url="https://deploy.example.com",
            protocol="mcp",
        )
        existing_sts = Resource(
            resource_id="rscwecmwxmK9skZBD1d7",
            name="github-proxy",
            mcp_url="https://api.githubcopilot.com/mcp/",
            protocol="mcp",
        )
        store = _mock_resource_store(entries_by_id={
            "aus123": [existing_ia],
            "rscwecmwxmK9skZBD1d7": [existing_sts],
        })
        syncer = _make_syncer(store)

        resources, unresolved = syncer._merge_connections([
            IDENTITY_ASSERTION_CONN,
            STS_ACCESS_TOKEN_CONN,
        ])

        assert len(resources) == 2
        assert "deploy-server" in resources
        assert "github-proxy" in resources
        assert len(unresolved) == 0

        assert resources["deploy-server"].auth_method == "okta-cross-app"
        assert resources["github-proxy"].auth_method == "okta-sts"

    def test_inactive_sts_connection_skipped(self):
        """INACTIVE STS_ACCESS_TOKEN connections should be skipped."""
        inactive_conn = {**STS_ACCESS_TOKEN_CONN, "status": "INACTIVE"}
        store = _mock_resource_store()
        syncer = _make_syncer(store)

        resources, unresolved = syncer._merge_connections([inactive_conn])

        assert len(resources) == 0
        assert len(unresolved) == 0
