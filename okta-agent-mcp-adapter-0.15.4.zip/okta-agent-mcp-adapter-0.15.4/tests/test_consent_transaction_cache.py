"""
Tests for ConsentTransactionStore CacheService (L2) integration.

Tests:
- Standalone mode (no CacheService) — sync behavior unchanged
- Two instances sharing one MemoryCacheProvider (cross-pod simulation)
- Session index pointer works cross-instance
- apersist propagates mutations cross-instance
- Encryption: tokens in L2 don't contain plaintext
- aremove cleans up both prefixes
- Expired tx is removed on read
- is_expired uses time.time() after migration
"""

import os
import time

import pytest

from okta_agent_proxy.auth.consent_transaction import (
    ConsentConnectionStatus,
    ConsentTransaction,
    ConsentTransactionStore,
    _CONSENT_TX_PREFIX,
    _CONSENT_SESSION_INDEX_PREFIX,
)
from okta_agent_proxy.cache.cache_service import CacheService
from okta_agent_proxy.cache.memory_provider import MemoryCacheProvider


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _make_store(cache_service=None, encryption_service=None):
    return ConsentTransactionStore(
        cache_service=cache_service,
        encryption_service=encryption_service,
    )


def _shared_cache_service():
    """Create a CacheService backed by a single MemoryCacheProvider (shared L2)."""
    provider = MemoryCacheProvider(max_size=1000, default_ttl=3600)
    return CacheService(l2_provider=provider)


def _sample_kwargs(**overrides):
    base = dict(
        original_redirect_uri="https://example.com/callback",
        original_state="state123",
        original_client_id="client_abc",
        id_token="eyJ.id_token_value.sig",
        access_token="access_token_secret",
        refresh_token="refresh_token_secret",
        agent_id="agent-1",
        agent_config={"client_id": "0oa_xxx"},
        ip_address="10.0.0.1",
        user_agent_hash="ua_hash_123",
        okta_expires_in=3600,
        relay_client_id="relay_cid",
        relay_client_secret="relay_secret_value",
        target_resource=None,
        mode="oauth_return",
    )
    base.update(overrides)
    return base


# ---------------------------------------------------------------------------
# 1. Standalone mode (no CacheService) — existing sync behavior
# ---------------------------------------------------------------------------

class TestStandaloneMode:
    def test_create_and_get_by_id(self):
        s = _make_store()
        tx = s.create(**_sample_kwargs())
        result = s.get_by_id(tx.transaction_id)
        assert result is not None
        assert result.transaction_id == tx.transaction_id
        assert result.agent_id == "agent-1"

    def test_get_by_session(self):
        s = _make_store()
        tx = s.create(**_sample_kwargs())
        result = s.get_by_session(tx.session_id)
        assert result is not None
        assert result.transaction_id == tx.transaction_id

    def test_validate_session(self):
        s = _make_store()
        tx = s.create(**_sample_kwargs())
        result = s.validate_session(tx.session_id, "10.0.0.1", "ua_hash_123")
        assert result is not None
        assert result.transaction_id == tx.transaction_id

    def test_validate_session_ip_mismatch(self):
        s = _make_store()
        tx = s.create(**_sample_kwargs())
        result = s.validate_session(tx.session_id, "10.0.0.99", "ua_hash_123")
        assert result is None

    def test_validate_session_ua_mismatch(self):
        s = _make_store()
        tx = s.create(**_sample_kwargs())
        result = s.validate_session(tx.session_id, "10.0.0.1", "different_ua")
        assert result is None

    def test_remove(self):
        s = _make_store()
        tx = s.create(**_sample_kwargs())
        s.remove(tx.transaction_id)
        assert s.get_by_id(tx.transaction_id) is None
        assert s.get_by_session(tx.session_id) is None

    def test_get_miss_returns_none(self):
        s = _make_store()
        assert s.get_by_id("nonexistent") is None
        assert s.get_by_session("nonexistent") is None


# ---------------------------------------------------------------------------
# 2. to_dict / from_dict round-trip
# ---------------------------------------------------------------------------

class TestSerialization:
    def test_connection_status_round_trip(self):
        conn = ConsentConnectionStatus(
            connection_id="conn_1",
            resource_name="github",
            provider="GitHub",
            resource_indicator="orn:okta:resource:github",
            status="verified",
            interaction_uri="https://okta.com/consent",
            error_message=None,
            checked_at=time.time(),
        )
        d = conn.to_dict()
        restored = ConsentConnectionStatus.from_dict(d)
        assert restored.connection_id == conn.connection_id
        assert restored.status == "verified"
        assert restored.checked_at == conn.checked_at
        assert restored.interaction_uri == conn.interaction_uri

    def test_transaction_round_trip(self):
        tx = ConsentTransaction(
            transaction_id="tx_123",
            session_id="sess_456",
            mode="standalone",
            id_token="id_tok",
            access_token="acc_tok",
            refresh_token="ref_tok",
            agent_id="agent-2",
            agent_config={"key": "val"},
            status="consents_required",
            connections=[
                ConsentConnectionStatus(
                    connection_id="c1",
                    resource_name="jira",
                    provider="Jira",
                    resource_indicator="orn:okta:resource:jira",
                    status="consent_required",
                    interaction_uri="https://okta.com/jira-consent",
                ),
            ],
            skip_requested=False,
            relay_client_id="rcid",
            relay_client_secret="rsecret",
            ip_address="192.168.1.1",
            user_agent_hash="ua123",
            ttl_seconds=300,
            target_resource="jira",
        )
        d = tx.to_dict()
        restored = ConsentTransaction.from_dict(d)
        assert restored.transaction_id == "tx_123"
        assert restored.mode == "standalone"
        assert restored.agent_config == {"key": "val"}
        assert len(restored.connections) == 1
        assert restored.connections[0].resource_name == "jira"
        assert restored.connections[0].status == "consent_required"
        assert restored.relay_client_secret == "rsecret"
        assert restored.ttl_seconds == 300
        assert restored.target_resource == "jira"

    def test_is_expired_uses_time_time(self):
        """Verify is_expired uses wall-clock time, not monotonic."""
        tx = ConsentTransaction(
            transaction_id="tx_exp",
            session_id="sess_exp",
            created_at=time.time() - 700,  # 700s ago
            ttl_seconds=600,
        )
        assert tx.is_expired is True

        tx2 = ConsentTransaction(
            transaction_id="tx_fresh",
            session_id="sess_fresh",
            created_at=time.time() - 10,  # 10s ago
            ttl_seconds=600,
        )
        assert tx2.is_expired is False


# ---------------------------------------------------------------------------
# 3. Cross-instance via shared CacheService
# ---------------------------------------------------------------------------

class TestCrossInstance:
    @pytest.mark.asyncio
    async def test_acreate_on_a_aget_by_id_on_b(self):
        """acreate on instance A, aget_by_id on instance B returns identical tx."""
        svc = _shared_cache_service()
        store_a = _make_store(cache_service=svc)
        store_b = _make_store(cache_service=svc)

        tx = await store_a.acreate(**_sample_kwargs())

        # B has no L1 state
        assert tx.transaction_id not in store_b._by_id

        result = await store_b.aget_by_id(tx.transaction_id)
        assert result is not None
        assert result.transaction_id == tx.transaction_id
        assert result.agent_id == "agent-1"
        assert result.id_token == "eyJ.id_token_value.sig"
        assert result.original_redirect_uri == "https://example.com/callback"
        assert result.relay_client_secret == "relay_secret_value"

    @pytest.mark.asyncio
    async def test_aget_by_session_cross_instance(self):
        """Session index pointer resolves cross-instance."""
        svc = _shared_cache_service()
        store_a = _make_store(cache_service=svc)
        store_b = _make_store(cache_service=svc)

        tx = await store_a.acreate(**_sample_kwargs())

        result = await store_b.aget_by_session(tx.session_id)
        assert result is not None
        assert result.transaction_id == tx.transaction_id

    @pytest.mark.asyncio
    async def test_avalidate_session_cross_instance(self):
        """avalidate_session works cross-instance with IP/UA checks."""
        svc = _shared_cache_service()
        store_a = _make_store(cache_service=svc)
        store_b = _make_store(cache_service=svc)

        tx = await store_a.acreate(**_sample_kwargs())

        result = await store_b.avalidate_session(tx.session_id, "10.0.0.1", "ua_hash_123")
        assert result is not None
        assert result.transaction_id == tx.transaction_id

        # IP mismatch fails
        result2 = await store_b.avalidate_session(tx.session_id, "10.0.0.99", "ua_hash_123")
        assert result2 is None

    @pytest.mark.asyncio
    async def test_apersist_propagates_mutations(self):
        """apersist after connection status change is visible on other instance."""
        svc = _shared_cache_service()
        store_a = _make_store(cache_service=svc)
        store_b = _make_store(cache_service=svc)

        tx = await store_a.acreate(**_sample_kwargs())

        # Simulate consent verification adding connections
        tx.connections.append(ConsentConnectionStatus(
            connection_id="conn_1",
            resource_name="github",
            provider="GitHub",
            resource_indicator="orn:okta:resource:github",
            status="consent_required",
            interaction_uri="https://okta.com/consent",
        ))
        tx.status = "consents_required"
        await store_a.apersist(tx)

        # B should see the mutation
        result = await store_b.aget_by_id(tx.transaction_id)
        assert result is not None
        assert len(result.connections) == 1
        assert result.connections[0].status == "consent_required"
        assert result.connections[0].resource_name == "github"
        assert result.status == "consents_required"

        # Now simulate verification success
        tx.connections[0].status = "verified"
        tx.connections[0].checked_at = time.time()
        tx.status = "complete"
        await store_a.apersist(tx)

        # Clear B's L1 to force L2 read
        store_b._by_id.clear()
        store_b._by_session.clear()

        result2 = await store_b.aget_by_id(tx.transaction_id)
        assert result2 is not None
        assert result2.connections[0].status == "verified"
        assert result2.status == "complete"
        assert result2.connections[0].checked_at is not None

    @pytest.mark.asyncio
    async def test_aremove_cleans_both_prefixes(self):
        """aremove deletes tx and session index from both L1 and L2."""
        provider = MemoryCacheProvider(max_size=1000, default_ttl=3600)
        svc = CacheService(l2_provider=provider)
        store_a = _make_store(cache_service=svc)
        store_b = _make_store(cache_service=svc)

        tx = await store_a.acreate(**_sample_kwargs())
        tx_id = tx.transaction_id
        sess_id = tx.session_id

        await store_a.aremove(tx_id)

        # L1 on A is gone
        assert tx_id not in store_a._by_id
        assert sess_id not in store_a._by_session

        # L2 is gone
        assert await provider.get(f"{_CONSENT_TX_PREFIX}{tx_id}") is None
        assert await provider.get(f"{_CONSENT_SESSION_INDEX_PREFIX}{sess_id}") is None

        # B cannot find it
        assert await store_b.aget_by_id(tx_id) is None
        assert await store_b.aget_by_session(sess_id) is None

    @pytest.mark.asyncio
    async def test_expired_tx_removed_on_read(self):
        """Expired tx is cleaned up on aget_by_id."""
        svc = _shared_cache_service()
        store_a = _make_store(cache_service=svc)
        store_b = _make_store(cache_service=svc)

        tx = await store_a.acreate(**_sample_kwargs())

        # Manually expire the transaction
        tx.created_at = time.time() - 700  # 700s ago, TTL is 600
        await store_a.apersist(tx)

        # Reading on B should see it as expired and remove it
        result = await store_b.aget_by_id(tx.transaction_id)
        assert result is None

    @pytest.mark.asyncio
    async def test_connections_list_preserved(self):
        """Nested connections list round-trips correctly through L2."""
        svc = _shared_cache_service()
        store_a = _make_store(cache_service=svc)
        store_b = _make_store(cache_service=svc)

        tx = await store_a.acreate(**_sample_kwargs())
        tx.connections = [
            ConsentConnectionStatus(
                connection_id="c1",
                resource_name="github",
                provider="GitHub",
                resource_indicator="orn:okta:resource:github",
                status="verified",
                checked_at=time.time(),
            ),
            ConsentConnectionStatus(
                connection_id="c2",
                resource_name="jira",
                provider="Jira",
                resource_indicator="orn:okta:resource:jira",
                status="consent_required",
                interaction_uri="https://okta.com/jira",
            ),
        ]
        await store_a.apersist(tx)

        result = await store_b.aget_by_id(tx.transaction_id)
        assert result is not None
        assert len(result.connections) == 2
        assert result.connections[0].resource_name == "github"
        assert result.connections[0].status == "verified"
        assert result.connections[1].resource_name == "jira"
        assert result.connections[1].status == "consent_required"
        assert result.connections[1].interaction_uri == "https://okta.com/jira"


# ---------------------------------------------------------------------------
# 4. Encryption
# ---------------------------------------------------------------------------

class TestEncryption:
    @pytest.mark.asyncio
    async def test_encrypted_l2_does_not_contain_plaintext(self):
        """L2 bytes must not contain raw id_token, access_token, or relay_client_secret."""
        from okta_agent_proxy.crypto.encryption import EncryptionService

        key = os.urandom(32)
        enc = EncryptionService(key)

        provider = MemoryCacheProvider(max_size=100, default_ttl=3600)
        svc = CacheService(l2_provider=provider)
        store = _make_store(cache_service=svc, encryption_service=enc)

        tx = await store.acreate(**_sample_kwargs())

        # Read raw bytes from L2 provider
        raw_l2 = await provider.get(f"{_CONSENT_TX_PREFIX}{tx.transaction_id}")
        assert raw_l2 is not None
        assert "id_token_value" not in raw_l2
        assert "access_token_secret" not in raw_l2
        assert "relay_secret_value" not in raw_l2

        # But aget_by_id decrypts correctly
        # Clear L1 to force L2 read
        store._by_id.clear()
        store._by_session.clear()

        result = await store.aget_by_id(tx.transaction_id)
        assert result is not None
        assert result.id_token == "eyJ.id_token_value.sig"
        assert result.access_token == "access_token_secret"
        assert result.relay_client_secret == "relay_secret_value"

    @pytest.mark.asyncio
    async def test_encryption_warning_logged(self, caplog):
        """One-time warning when CacheService is wired but no encryption."""
        import logging
        svc = _shared_cache_service()
        store = _make_store(cache_service=svc, encryption_service=None)

        with caplog.at_level(logging.WARNING):
            await store.acreate(**_sample_kwargs())

        assert any("UNENCRYPTED" in record.message for record in caplog.records)

        # Second call does not warn again
        caplog.clear()
        with caplog.at_level(logging.WARNING):
            await store.acreate(**_sample_kwargs())

        assert not any("UNENCRYPTED" in record.message for record in caplog.records)


# ---------------------------------------------------------------------------
# 5. L1-only fast path (sync methods still work with cache_service wired)
# ---------------------------------------------------------------------------

class TestSyncWithCacheServiceWired:
    def test_sync_create_does_not_write_l2(self):
        """Sync create() only populates L1, not L2."""
        provider = MemoryCacheProvider(max_size=100, default_ttl=3600)
        svc = CacheService(l2_provider=provider)
        store = _make_store(cache_service=svc)

        tx = store.create(**_sample_kwargs())

        # L1 populated
        assert tx.transaction_id in store._by_id
        assert tx.session_id in store._by_session

    def test_sync_get_by_id_works(self):
        provider = MemoryCacheProvider(max_size=100, default_ttl=3600)
        svc = CacheService(l2_provider=provider)
        store = _make_store(cache_service=svc)

        tx = store.create(**_sample_kwargs())
        result = store.get_by_id(tx.transaction_id)
        assert result is not None
        assert result.agent_id == "agent-1"
