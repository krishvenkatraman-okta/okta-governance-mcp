"""
Integration tests for Admin API.

Tests the full HTTP request/response cycle with authentication,
authorization, and repository integration.
"""

import pytest
import os
import json
from unittest.mock import patch, MagicMock
from starlette.testclient import TestClient


# ============================================================================
# Fixtures
# ============================================================================

@pytest.fixture
def mock_okta_env(monkeypatch):
    """Mock Okta environment variables for app initialization"""
    monkeypatch.setenv("OKTA_DOMAIN", "dev-test.okta.com")
    monkeypatch.setenv("OKTA_CLIENT_SECRET", "test_secret")
    monkeypatch.setenv("OKTA_ISSUER", "https://dev-test.okta.com")
    monkeypatch.setenv("GATEWAY_BASE_URL", "http://localhost:8000")
    monkeypatch.setenv("GATEWAY_PORT", "8000")
    monkeypatch.setenv("LOG_LEVEL", "ERROR")  # Reduce noise in tests


@pytest.fixture
def test_app_postgres(mock_okta_env, postgres_store, monkeypatch):
    """Create test app with PostgreSQL store and a stubbed Okta token validator.

    Admin API auth is Okta-OAuth-only (username/password login was removed in
    v0.15.x). Patch verify_okta_token so any bearer passed by the test client
    resolves to a synthetic admin user without hitting a live Okta org.
    """
    # Import modules first so patch can find them
    import okta_agent_proxy.app
    import okta_agent_proxy.database

    async def _fake_verify_okta_token(token):
        if not token:
            return None
        if token == "invalid_token":
            return None
        return {
            "sub": "test-admin",
            "email": "test-admin@example.com",
            "username": "test-admin",
            "role": "admin",
            "token_type": "okta_oauth",
        }

    with patch("okta_agent_proxy.app.get_config_store", return_value=postgres_store):
        with patch("okta_agent_proxy.database.get_config_store", return_value=postgres_store):
            with patch(
                "okta_agent_proxy.admin.middleware.verify_okta_token",
                side_effect=_fake_verify_okta_token,
            ):
                from okta_agent_proxy.app import app
                client = TestClient(app)
                yield client


@pytest.fixture
def auth_headers():
    """Bearer headers for tests. The actual token value is unused because
    verify_okta_token is patched in test_app_postgres."""
    return {"Authorization": "Bearer test-okta-access-token"}


# ============================================================================
# Authentication Tests
# ============================================================================

def test_login_endpoint_removed(test_app_postgres):
    """The legacy username/password login endpoint must not exist."""
    response = test_app_postgres.post(
        "/api/admin/login",
        json={"username": "admin", "password": "admin123"},
    )
    assert response.status_code in (404, 405)


def test_protected_endpoint_without_token(test_app_postgres):
    """Test accessing protected endpoint without token"""
    response = test_app_postgres.get("/api/admin/agents")

    assert response.status_code == 401
    data = response.json()
    assert "error" in data


def test_protected_endpoint_with_invalid_token(test_app_postgres):
    """Test accessing protected endpoint with invalid token"""
    response = test_app_postgres.get(
        "/api/admin/agents",
        headers={"Authorization": "Bearer invalid_token"}
    )

    assert response.status_code == 401
    data = response.json()
    assert "error" in data


# ============================================================================
# Agent Endpoints Tests (PostgreSQL)
# ============================================================================

def test_list_agents_empty(test_app_postgres, auth_headers):
    """Test listing agents when none exist"""
    response = test_app_postgres.get(
        "/api/admin/agents",
        headers=auth_headers
    )

    assert response.status_code == 200
    data = response.json()
    assert "agents" in data
    assert isinstance(data["agents"], list)


def test_create_agent_success(test_app_postgres, auth_headers, sample_agent_data):
    """Test creating a new agent"""
    response = test_app_postgres.post(
        "/api/admin/agents",
        headers=auth_headers,
        json=sample_agent_data
    )

    assert response.status_code == 201
    data = response.json()
    assert data["agent_id"] == sample_agent_data["agent_id"]
    assert data["client_id"] == sample_agent_data["client_id"]
    assert data["enabled"] is True


def test_create_agent_duplicate(test_app_postgres, auth_headers, sample_agent_data):
    """Test creating duplicate agent returns 409"""
    # Create first agent
    test_app_postgres.post(
        "/api/admin/agents",
        headers=auth_headers,
        json=sample_agent_data
    )

    # Try to create duplicate
    response = test_app_postgres.post(
        "/api/admin/agents",
        headers=auth_headers,
        json=sample_agent_data
    )

    assert response.status_code == 409
    data = response.json()
    assert data["error"] == "agent_exists"


def test_create_agent_missing_fields(test_app_postgres, auth_headers):
    """Test creating agent with missing required fields"""
    invalid_data = {
        "agent_id": "test-agent"
        # Missing client_id, private_key
    }

    response = test_app_postgres.post(
        "/api/admin/agents",
        headers=auth_headers,
        json=invalid_data
    )

    assert response.status_code == 400
    data = response.json()
    assert "error" in data


def test_get_agent_success(test_app_postgres, auth_headers, sample_agent_data):
    """Test getting a specific agent"""
    # Create agent
    test_app_postgres.post(
        "/api/admin/agents",
        headers=auth_headers,
        json=sample_agent_data
    )

    # Get agent
    response = test_app_postgres.get(
        f"/api/admin/agents/{sample_agent_data['agent_id']}",
        headers=auth_headers
    )

    assert response.status_code == 200
    data = response.json()
    assert data["agent_id"] == sample_agent_data["agent_id"]
    assert data["client_id"] == sample_agent_data["client_id"]


def test_get_agent_not_found(test_app_postgres, auth_headers):
    """Test getting non-existent agent returns 404"""
    response = test_app_postgres.get(
        "/api/admin/agents/nonexistent-agent",
        headers=auth_headers
    )

    assert response.status_code == 404
    data = response.json()
    assert data["error"] == "agent_not_found"


def test_list_agents_after_create(test_app_postgres, auth_headers, sample_agent_data):
    """Test listing agents after creating one"""
    # Create agent
    test_app_postgres.post(
        "/api/admin/agents",
        headers=auth_headers,
        json=sample_agent_data
    )

    # List agents
    response = test_app_postgres.get(
        "/api/admin/agents",
        headers=auth_headers
    )

    assert response.status_code == 200
    data = response.json()
    assert len(data["agents"]) == 1
    assert data["agents"][0]["agent_id"] == sample_agent_data["agent_id"]


def test_update_agent_success(test_app_postgres, auth_headers, sample_agent_data):
    """Test updating an existing agent"""
    # Create agent
    test_app_postgres.post(
        "/api/admin/agents",
        headers=auth_headers,
        json=sample_agent_data
    )

    # Update agent
    updated_data = sample_agent_data.copy()
    updated_data["scopes"] = ["mcp:read", "mcp:write", "mcp:admin"]

    response = test_app_postgres.put(
        f"/api/admin/agents/{sample_agent_data['agent_id']}",
        headers=auth_headers,
        json=updated_data
    )

    assert response.status_code == 200
    data = response.json()
    assert data["scopes"] == ["mcp:read", "mcp:write", "mcp:admin"]


def test_update_agent_not_found(test_app_postgres, auth_headers, sample_agent_data):
    """Test updating non-existent agent returns 404"""
    response = test_app_postgres.put(
        "/api/admin/agents/nonexistent-agent",
        headers=auth_headers,
        json=sample_agent_data
    )

    assert response.status_code == 404
    data = response.json()
    assert data["error"] == "agent_not_found"


def test_delete_agent_success(test_app_postgres, auth_headers, sample_agent_data):
    """Test deleting an existing agent"""
    # Create agent
    test_app_postgres.post(
        "/api/admin/agents",
        headers=auth_headers,
        json=sample_agent_data
    )

    # Delete agent
    response = test_app_postgres.delete(
        f"/api/admin/agents/{sample_agent_data['agent_id']}",
        headers=auth_headers
    )

    assert response.status_code == 200
    data = response.json()
    assert data["message"] == "Agent deleted successfully"

    # Verify deletion
    response = test_app_postgres.get(
        f"/api/admin/agents/{sample_agent_data['agent_id']}",
        headers=auth_headers
    )
    assert response.status_code == 404


def test_delete_agent_not_found(test_app_postgres, auth_headers):
    """Test deleting non-existent agent returns 404"""
    response = test_app_postgres.delete(
        "/api/admin/agents/nonexistent-agent",
        headers=auth_headers
    )

    assert response.status_code == 404
    data = response.json()
    assert data["error"] == "agent_not_found"


# ============================================================================
# Full Workflow Tests
# ============================================================================

def test_full_agent_lifecycle(test_app_postgres, auth_headers, sample_agent_data):
    """Test complete agent lifecycle: create, get, update, delete"""
    # Create
    create_response = test_app_postgres.post(
        "/api/admin/agents",
        headers=auth_headers,
        json=sample_agent_data
    )
    assert create_response.status_code == 201

    # Get
    get_response = test_app_postgres.get(
        f"/api/admin/agents/{sample_agent_data['agent_id']}",
        headers=auth_headers
    )
    assert get_response.status_code == 200
    assert get_response.json()["agent_id"] == sample_agent_data["agent_id"]

    # Update
    updated_data = sample_agent_data.copy()
    updated_data["scopes"] = ["mcp:admin"]
    update_response = test_app_postgres.put(
        f"/api/admin/agents/{sample_agent_data['agent_id']}",
        headers=auth_headers,
        json=updated_data
    )
    assert update_response.status_code == 200
    assert update_response.json()["scopes"] == ["mcp:admin"]

    # Delete
    delete_response = test_app_postgres.delete(
        f"/api/admin/agents/{sample_agent_data['agent_id']}",
        headers=auth_headers
    )
    assert delete_response.status_code == 200

    # Verify deletion
    get_after_delete = test_app_postgres.get(
        f"/api/admin/agents/{sample_agent_data['agent_id']}",
        headers=auth_headers
    )
    assert get_after_delete.status_code == 404


# ============================================================================
# CIMD Client ID Tests
# ============================================================================

def test_create_agent_with_cimd_client_id(test_app_postgres, auth_headers, sample_agent_data):
    """Test creating an agent with cimd_client_id via Admin API"""
    agent_data = sample_agent_data.copy()
    agent_data["cimd_client_id"] = "https://claude.ai/oauth/client-metadata.json"

    response = test_app_postgres.post(
        "/api/admin/agents",
        headers=auth_headers,
        json=agent_data
    )

    assert response.status_code == 201
    data = response.json()
    assert data["cimd_client_id_url"] == "https://claude.ai/oauth/client-metadata.json"


def test_update_agent_add_cimd_client_id(test_app_postgres, auth_headers, sample_agent_data):
    """Test updating an agent to add cimd_client_id via Admin API"""
    # Create agent without cimd_client_id
    test_app_postgres.post(
        "/api/admin/agents",
        headers=auth_headers,
        json=sample_agent_data
    )

    # Update to add cimd_client_id
    response = test_app_postgres.put(
        f"/api/admin/agents/{sample_agent_data['agent_id']}",
        headers=auth_headers,
        json={"cimd_client_id": "https://claude.ai/oauth/client-metadata.json"}
    )

    assert response.status_code == 200
    data = response.json()
    assert data["cimd_client_id_url"] == "https://claude.ai/oauth/client-metadata.json"


def test_create_agent_invalid_cimd_client_id(test_app_postgres, auth_headers, sample_agent_data):
    """Test creating an agent with invalid cimd_client_id returns 400"""
    agent_data = sample_agent_data.copy()
    agent_data["cimd_client_id"] = "ftp://invalid.example.com/metadata"

    response = test_app_postgres.post(
        "/api/admin/agents",
        headers=auth_headers,
        json=agent_data
    )

    assert response.status_code == 400
    assert response.json()["error"] == "invalid_input"


def test_update_agent_invalid_cimd_client_id(test_app_postgres, auth_headers, sample_agent_data):
    """Test updating an agent with invalid cimd_client_id returns 400"""
    # Create agent
    test_app_postgres.post(
        "/api/admin/agents",
        headers=auth_headers,
        json=sample_agent_data
    )

    # Try invalid cimd_client_id
    response = test_app_postgres.put(
        f"/api/admin/agents/{sample_agent_data['agent_id']}",
        headers=auth_headers,
        json={"cimd_client_id": "not-a-url"}
    )

    assert response.status_code == 400
    assert response.json()["error"] == "invalid_input"


def test_create_agent_cimd_client_id_localhost(test_app_postgres, auth_headers, sample_agent_data):
    """Test creating an agent with http://localhost cimd_client_id is valid"""
    agent_data = sample_agent_data.copy()
    agent_data["cimd_client_id"] = "http://localhost:3000/oauth/metadata.json"

    response = test_app_postgres.post(
        "/api/admin/agents",
        headers=auth_headers,
        json=agent_data
    )

    assert response.status_code == 201
    data = response.json()
    assert data["cimd_client_id_url"] == "http://localhost:3000/oauth/metadata.json"


# ============================================================================
# Principal ID Tests (Admin API)
# ============================================================================

def test_create_agent_with_principal_id_via_api(test_app_postgres, auth_headers, sample_agent_data):
    """Test creating an agent with principal_id via Admin API"""
    agent_data = sample_agent_data.copy()
    agent_data["principal_id"] = "agt1234567890"

    response = test_app_postgres.post(
        "/api/admin/agents",
        headers=auth_headers,
        json=agent_data
    )

    assert response.status_code == 201
    data = response.json()
    assert data["principal_id"] == "agt1234567890"


def test_update_agent_principal_id_via_api(test_app_postgres, auth_headers, sample_agent_data):
    """Test updating an agent to add principal_id via Admin API"""
    # Create agent without principal_id
    test_app_postgres.post(
        "/api/admin/agents",
        headers=auth_headers,
        json=sample_agent_data
    )

    # Update to add principal_id
    response = test_app_postgres.put(
        f"/api/admin/agents/{sample_agent_data['agent_id']}",
        headers=auth_headers,
        json={"principal_id": "agt9876543210"}
    )

    assert response.status_code == 200
    data = response.json()
    assert data["principal_id"] == "agt9876543210"


def test_get_agent_includes_principal_id(test_app_postgres, auth_headers, sample_agent_data):
    """Test GET agent includes principal_id in the response"""
    agent_data = sample_agent_data.copy()
    agent_data["principal_id"] = "agtABCDEF"

    test_app_postgres.post(
        "/api/admin/agents",
        headers=auth_headers,
        json=agent_data
    )

    response = test_app_postgres.get(
        f"/api/admin/agents/{sample_agent_data['agent_id']}",
        headers=auth_headers
    )

    assert response.status_code == 200
    data = response.json()
    assert data["principal_id"] == "agtABCDEF"
