"""Tests for CorrelationIdMiddleware."""

import uuid

import pytest
from starlette.applications import Starlette
from starlette.middleware import Middleware
from starlette.requests import Request
from starlette.responses import JSONResponse
from starlette.routing import Route
from starlette.testclient import TestClient

from okta_agent_proxy.audit.context import (
    clear_request_context,
    get_request_context,
)
from okta_agent_proxy.middleware.correlation import CorrelationIdMiddleware

# Captured context during request processing (populated by the test endpoint)
_captured_context: dict = {}


async def context_endpoint(request: Request):
    """Test endpoint that captures audit context and request state."""
    ctx = get_request_context()
    state_corr = getattr(request.state, "correlation_id", None)
    return JSONResponse({
        "correlation_id": ctx["correlation_id"],
        "agent_id": ctx["agent_id"],
        "user_id": ctx["user_id"],
        "ip_address": ctx["ip_address"],
        "user_agent": ctx["user_agent"],
        "state_correlation_id": state_corr,
    })


test_app = Starlette(
    routes=[Route("/test", context_endpoint, methods=["GET", "POST"])],
    middleware=[Middleware(CorrelationIdMiddleware)],
)

client = TestClient(test_app)


@pytest.fixture(autouse=True)
def _clean():
    clear_request_context()
    yield
    clear_request_context()


class TestCorrelationIdGeneration:
    def test_generates_uuid_when_no_header(self):
        resp = client.get("/test")
        assert resp.status_code == 200
        corr_id = resp.headers["x-correlation-id"]
        # Should be a valid UUID4
        uuid.UUID(corr_id, version=4)

    def test_preserves_provided_correlation_id(self):
        provided = "my-custom-correlation-123"
        resp = client.get("/test", headers={"X-Correlation-ID": provided})
        assert resp.status_code == 200
        assert resp.headers["x-correlation-id"] == provided

    def test_each_request_gets_unique_id(self):
        ids = set()
        for _ in range(5):
            resp = client.get("/test")
            ids.add(resp.headers["x-correlation-id"])
        assert len(ids) == 5


class TestResponseHeader:
    def test_response_includes_correlation_header(self):
        resp = client.get("/test")
        assert "x-correlation-id" in resp.headers

    def test_response_header_matches_generated_id(self):
        resp = client.get("/test")
        body = resp.json()
        assert resp.headers["x-correlation-id"] == body["correlation_id"]

    def test_response_header_matches_provided_id(self):
        provided = "req-abc-def"
        resp = client.get("/test", headers={"X-Correlation-ID": provided})
        assert resp.headers["x-correlation-id"] == provided
        assert resp.json()["correlation_id"] == provided


class TestContextVarsPopulated:
    def test_correlation_id_in_context(self):
        provided = "ctx-test-1"
        resp = client.get("/test", headers={"X-Correlation-ID": provided})
        body = resp.json()
        assert body["correlation_id"] == provided

    def test_ip_address_populated(self):
        resp = client.get("/test")
        body = resp.json()
        # TestClient connects from localhost
        assert body["ip_address"] is not None

    def test_user_agent_populated(self):
        resp = client.get("/test", headers={"User-Agent": "TestBot/1.0"})
        body = resp.json()
        assert body["user_agent"] == "TestBot/1.0"

    def test_agent_id_not_set_by_middleware(self):
        resp = client.get("/test")
        body = resp.json()
        assert body["agent_id"] is None

    def test_user_id_not_set_by_middleware(self):
        resp = client.get("/test")
        body = resp.json()
        assert body["user_id"] is None

    def test_state_correlation_id_accessible(self):
        provided = "state-test-1"
        resp = client.get("/test", headers={"X-Correlation-ID": provided})
        body = resp.json()
        assert body["state_correlation_id"] == provided


class TestContextCleanup:
    def test_context_cleared_after_response(self):
        client.get("/test", headers={"X-Correlation-ID": "should-be-cleared"})
        ctx = get_request_context()
        assert ctx["correlation_id"] == ""
        assert ctx["agent_id"] is None
        assert ctx["ip_address"] is None

    def test_context_cleared_even_on_error(self):
        """Context must be cleared even if the downstream app raises."""
        async def failing_endpoint(request):
            raise RuntimeError("boom")

        error_app = Starlette(
            routes=[Route("/fail", failing_endpoint, methods=["GET"])],
            middleware=[Middleware(CorrelationIdMiddleware)],
        )
        error_client = TestClient(error_app, raise_server_exceptions=False)
        error_client.get("/fail")
        ctx = get_request_context()
        assert ctx["correlation_id"] == ""


class TestNonHttpScope:
    def test_non_http_scope_passes_through(self):
        """Websocket and other scope types should pass through untouched."""
        # This is implicitly tested by the fact that the middleware checks scope["type"].
        # We verify the middleware doesn't crash on a normal HTTP request as a baseline.
        resp = client.get("/test")
        assert resp.status_code == 200
