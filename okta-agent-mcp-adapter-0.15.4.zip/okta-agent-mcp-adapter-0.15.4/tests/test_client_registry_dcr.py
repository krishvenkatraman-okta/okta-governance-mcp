"""Tests for ClientRegistry._resolve_dcr() enrichment."""

from unittest.mock import MagicMock

import pytest

from okta_agent_proxy.auth.client_registry import ClientRegistry, ClientInfo
from okta_agent_proxy.auth.cimd_fetcher import CIMDFetcher
from okta_agent_proxy.auth.cimd_policy import CIMDTrustPolicy


def _registry(store):
    """Create a ClientRegistry with a mock store."""
    fetcher = MagicMock(spec=CIMDFetcher)
    policy = MagicMock(spec=CIMDTrustPolicy)
    return ClientRegistry(store=store, cimd_fetcher=fetcher, cimd_policy=policy)


class TestResolveDcrWithAgentConfig:

    def test_resolve_dcr_with_linked_agent(self):
        """Active DCR registration with linked_agent_name returns linked agent's config."""
        store = MagicMock()
        store.get_dcr_registration.return_value = {
            "client_id": "dcr_abc123",
            "client_name": "Test Client",
            "status": "active",
            "linked_agent_name": "claude-code",
            "redirect_uris": ["http://localhost/callback"],
            "grant_types": ["authorization_code"],
        }
        store.get_agent.return_value = {
            "agent_name": "claude-code",
            "agent_id": "claude-code",
            "client_id": "0oa_real_client",
            "client_secret": "real_secret",
            "resource_access": ["hr-system"],
        }

        registry = _registry(store)
        info = registry._resolve_dcr("dcr_abc123")

        assert info is not None
        assert info.client_id == "dcr_abc123"
        assert info.registration_source == "dcr"
        assert info.agent_config is not None
        assert info.agent_config["client_id"] == "0oa_real_client"
        assert info.resource_access == ["hr-system"]

    def test_resolve_dcr_unlinked(self):
        """Active DCR registration with no linked_agent_name returns agent_config=None."""
        store = MagicMock()
        store.get_dcr_registration.return_value = {
            "client_id": "dcr_orphan",
            "client_name": "Unlinked Client",
            "status": "active",
            "linked_agent_name": None,
            "redirect_uris": [],
            "grant_types": ["authorization_code"],
        }

        registry = _registry(store)
        info = registry._resolve_dcr("dcr_orphan")

        assert info is not None
        assert info.agent_config is None
        assert info.resource_access == []

    def test_resolve_dcr_inactive(self):
        """Revoked DCR registration returns None."""
        store = MagicMock()
        store.get_dcr_registration.return_value = {
            "client_id": "dcr_revoked",
            "status": "revoked",
        }

        registry = _registry(store)
        info = registry._resolve_dcr("dcr_revoked")

        assert info is None

    def test_resolve_dcr_not_found(self):
        """Unknown client_id returns None."""
        store = MagicMock()
        store.get_dcr_registration.return_value = None

        registry = _registry(store)
        info = registry._resolve_dcr("unknown_client")

        assert info is None
