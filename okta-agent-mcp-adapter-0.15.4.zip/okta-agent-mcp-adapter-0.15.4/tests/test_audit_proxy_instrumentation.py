"""Tests for audit event instrumentation in proxy handler, unified handler, and session manager."""

import asyncio
import json
from typing import List
from unittest.mock import AsyncMock, MagicMock, patch, PropertyMock

import httpx
import pytest

from okta_agent_proxy.audit.events import AuditEvent, AuditEventType, AuditSeverity
from okta_agent_proxy.audit.context import set_request_context, clear_request_context
from okta_agent_proxy.audit.emitter import AuditEventEmitter
from okta_agent_proxy.audit.sinks.base import AuditSink
from okta_agent_proxy.auth.resource_token_resolver import ResourceAuthResult


# --- Helper: capture sink ---


class CaptureSink(AuditSink):
    """Collects emitted audit events for assertion."""

    def __init__(self):
        self.events: List[AuditEvent] = []

    async def write(self, event: AuditEvent) -> None:
        self.events.append(event)

    @property
    def name(self) -> str:
        return "capture"


@pytest.fixture(autouse=True)
def _clean():
    clear_request_context()
    yield
    clear_request_context()


@pytest.fixture
async def capture_emitter():
    """Create a capture-sink emitter and patch it as the global emitter."""
    sink = CaptureSink()
    emitter = AuditEventEmitter(sinks=[sink], flush_interval=0.05)
    await emitter.start()

    import okta_agent_proxy.audit as audit_mod
    old = audit_mod._emitter
    audit_mod._emitter = emitter
    yield sink
    audit_mod._emitter = old
    await emitter.stop()


# --- Helpers for building mock objects ---


def _make_mock_store(agent_config=None):
    """Create a mock ResourceConfigStore."""
    store = MagicMock()
    if agent_config:
        store.get_agent_by_name.return_value = agent_config
        store.get_agent.return_value = MagicMock(client_id=agent_config.get("client_id", "test-client"))
        store.get_all_agents.return_value = [agent_config]
    else:
        store.get_agent_by_name.return_value = None
        store.get_agent.return_value = None
        store.get_all_agents.return_value = []
    return store


def _make_mock_router(resource_name="hr-system", resource_url="http://backend:8080/mcp"):
    """Create a mock ResourceRouter."""
    router = MagicMock()
    router.get_resource_for_path.return_value = resource_name

    resource_config = MagicMock()
    resource_config.url = resource_url
    resource_config.auth_method = "pre-shared-key"
    resource_config.enabled = True
    auth_config = MagicMock()
    auth_config.model_dump.return_value = {"header_name": "X-API-Key", "api_key": "test-key"}
    resource_config.auth_config = auth_config

    router.get_resource_config.return_value = resource_config
    router.get_resource_config.return_value = resource_config

    # Set up resolver mock so await router.resolver.resolve_auth_headers(...) works
    resolver = MagicMock()
    resolver.resolve_auth_headers = AsyncMock(return_value=ResourceAuthResult(
        headers={"X-API-Key": "test-key"}
    ))
    router.resolver = resolver

    return router


def _make_mock_validator(claims=None):
    """Create a mock OktaTokenValidator."""
    validator = MagicMock()
    if claims is None:
        claims = {"sub": "user@test.com", "aud": "test-client", "exp": 9999999999}
    validator.validate_token = AsyncMock(return_value=claims)
    return validator


# --- ProxyHandler tests ---


class TestProxyHandlerAudit:
    @pytest.mark.asyncio
    @patch("okta_agent_proxy.proxy.handler.check_agent_can_access_resource", new_callable=AsyncMock, return_value=True)
    async def test_successful_proxy_emits_tool_list_event(self, mock_authz, capture_emitter):
        """Successful tools/list through proxy emits MCP_TOOL_LIST."""
        from okta_agent_proxy.proxy.handler import ProxyHandler

        agent_config = {"agent_id": "claude-code", "client_id": "test-client",
                        "backend_access": ["hr-system"]}
        router = _make_mock_router()
        validator = _make_mock_validator()
        store = _make_mock_store(agent_config)

        handler = ProxyHandler(router, validator, store)

        # Mock session manager
        handler.session_manager = MagicMock()
        handler.session_manager.get_or_create_session = AsyncMock(return_value="session-123")

        # Mock the HTTP response
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.headers = {"content-type": "application/json"}
        mock_response.json.return_value = {
            "jsonrpc": "2.0", "id": "1",
            "result": {"tools": [{"name": "get_employee"}]}
        }

        set_request_context(correlation_id="proxy-list-1")

        with patch("okta_agent_proxy.proxy.handler.create_auth_handler") as mock_auth:
            mock_auth_handler = MagicMock()
            mock_auth_handler.get_auth_headers = AsyncMock(return_value={"X-API-Key": "test"})
            mock_auth.return_value = mock_auth_handler

            with patch("httpx.AsyncClient") as mock_client_cls:
                mock_client = AsyncMock()
                mock_client.post = AsyncMock(return_value=mock_response)
                mock_client.__aenter__ = AsyncMock(return_value=mock_client)
                mock_client.__aexit__ = AsyncMock(return_value=False)
                mock_client_cls.return_value = mock_client

                result = await handler.proxy_request(
                    request_path="/hr",
                    method="tools/list",
                    params={},
                    auth_header="Bearer fake.jwt.token",
                    request_id="1",
                    headers={"x-mcp-agent": "claude-code"},
                )

        assert "tools" in result
        await asyncio.sleep(0.15)

        events = [e for e in capture_emitter.events
                  if e.event_type == AuditEventType.MCP_TOOL_LIST]
        assert len(events) >= 1
        assert events[0].outcome == "success"
        assert "latency_ms" in events[0].details
        assert events[0].details["tool_count"] == 1

    @pytest.mark.asyncio
    @patch("okta_agent_proxy.proxy.handler.check_agent_can_access_resource", new_callable=AsyncMock, return_value=True)
    async def test_token_exchange_failure_emits_events(self, mock_authz, capture_emitter):
        """Failed token exchange emits TOKEN_EXCHANGE_FAILURE and MCP event."""
        from okta_agent_proxy.proxy.handler import ProxyHandler

        agent_config = {"agent_id": "claude-code", "client_id": "test-client",
                        "backend_access": ["hr-system"]}
        router = _make_mock_router()
        # Set auth_method to okta-cross-app to trigger token exchange
        router.get_resource_config.return_value.auth_method = "okta-cross-app"
        router.resolver.resolve_auth_headers = AsyncMock(return_value=ResourceAuthResult(
            error="token_exchange_failed", error_message="Could not exchange token"
        ))

        validator = _make_mock_validator()
        store = _make_mock_store(agent_config)

        handler = ProxyHandler(router, validator, store)

        set_request_context(correlation_id="proxy-exchange-fail-1")

        result = await handler.proxy_request(
            request_path="/hr",
            method="tools/call",
            params={"name": "get_employee"},
            auth_header="Bearer fake.jwt.token",
            request_id="1",
            headers={"x-mcp-agent": "claude-code"},
        )

        assert result["error"] == "token_exchange_failed"
        await asyncio.sleep(0.15)

        exchange_events = [e for e in capture_emitter.events
                          if e.event_type == AuditEventType.TOKEN_EXCHANGE_FAILURE]
        assert len(exchange_events) == 1
        assert exchange_events[0].outcome == "failure"
        assert exchange_events[0].resource_name == "hr-system"

        tool_events = [e for e in capture_emitter.events
                       if e.event_type == AuditEventType.MCP_TOOL_CALL]
        assert len(tool_events) == 1
        assert tool_events[0].outcome == "failure"

    @pytest.mark.asyncio
    @patch("okta_agent_proxy.proxy.handler.check_agent_can_access_resource", new_callable=AsyncMock, return_value=True)
    async def test_token_exchange_success_emits_event(self, mock_authz, capture_emitter):
        """Successful token exchange emits TOKEN_EXCHANGE_SUCCESS."""
        from okta_agent_proxy.proxy.handler import ProxyHandler

        agent_config = {"agent_id": "claude-code", "client_id": "test-client",
                        "backend_access": ["hr-system"]}
        router = _make_mock_router()
        router.get_resource_config.return_value.auth_method = "okta-cross-app"
        router.resolver.resolve_auth_headers = AsyncMock(return_value=ResourceAuthResult(
            headers={"Authorization": "Bearer backend-token-xyz"}
        ))

        validator = _make_mock_validator()
        store = _make_mock_store(agent_config)

        handler = ProxyHandler(router, validator, store)
        handler.session_manager = MagicMock()
        handler.session_manager.get_or_create_session = AsyncMock(return_value="session-123")

        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.headers = {"content-type": "application/json"}
        mock_response.json.return_value = {
            "jsonrpc": "2.0", "id": "1",
            "result": {"content": [{"type": "text", "text": "ok"}]}
        }

        set_request_context(correlation_id="proxy-exchange-ok-1")

        with patch("httpx.AsyncClient") as mock_client_cls:
            mock_client = AsyncMock()
            mock_client.post = AsyncMock(return_value=mock_response)
            mock_client.__aenter__ = AsyncMock(return_value=mock_client)
            mock_client.__aexit__ = AsyncMock(return_value=False)
            mock_client_cls.return_value = mock_client

            result = await handler.proxy_request(
                request_path="/hr",
                method="tools/call",
                params={"name": "get_employee"},
                auth_header="Bearer fake.jwt.token",
                request_id="1",
                headers={"x-mcp-agent": "claude-code"},
            )

        await asyncio.sleep(0.15)

        exchange_events = [e for e in capture_emitter.events
                          if e.event_type == AuditEventType.TOKEN_EXCHANGE_SUCCESS]
        assert len(exchange_events) == 1
        assert exchange_events[0].resource_name == "hr-system"

    @pytest.mark.asyncio
    @patch("okta_agent_proxy.proxy.handler.check_agent_can_access_resource", new_callable=AsyncMock, return_value=True)
    async def test_resource_timeout_emits_failure_event(self, mock_authz, capture_emitter):
        """Resource timeout emits MCP event with failure outcome."""
        from okta_agent_proxy.proxy.handler import ProxyHandler

        agent_config = {"agent_id": "claude-code", "client_id": "test-client",
                        "backend_access": ["hr-system"]}
        router = _make_mock_router()
        validator = _make_mock_validator()
        store = _make_mock_store(agent_config)

        handler = ProxyHandler(router, validator, store)
        handler.session_manager = MagicMock()
        handler.session_manager.get_or_create_session = AsyncMock(return_value="session-123")

        set_request_context(correlation_id="proxy-timeout-1")

        with patch("okta_agent_proxy.proxy.handler.create_auth_handler") as mock_auth:
            mock_auth_handler = MagicMock()
            mock_auth_handler.get_auth_headers = AsyncMock(return_value={"X-API-Key": "test"})
            mock_auth.return_value = mock_auth_handler

            with patch("httpx.AsyncClient") as mock_client_cls:
                mock_client = AsyncMock()
                mock_client.post = AsyncMock(side_effect=httpx.TimeoutException("timeout"))
                mock_client.__aenter__ = AsyncMock(return_value=mock_client)
                mock_client.__aexit__ = AsyncMock(return_value=False)
                mock_client_cls.return_value = mock_client

                result = await handler.proxy_request(
                    request_path="/hr",
                    method="tools/call",
                    params={"name": "get_employee"},
                    auth_header="Bearer fake.jwt.token",
                    request_id="1",
                    headers={"x-mcp-agent": "claude-code"},
                )

        assert result["error"] == "backend_timeout"
        await asyncio.sleep(0.15)

        events = [e for e in capture_emitter.events
                  if e.event_type == AuditEventType.MCP_TOOL_CALL]
        assert len(events) == 1
        assert events[0].outcome == "failure"
        assert events[0].details["error"] == "backend_timeout"
        assert "latency_ms" in events[0].details

    @pytest.mark.asyncio
    @patch("okta_agent_proxy.proxy.handler.check_agent_can_access_resource", new_callable=AsyncMock, return_value=True)
    async def test_context_enrichment_sets_vars(self, mock_authz, capture_emitter):
        """Proxy handler enriches audit context with agent_id, user_id, client_id."""
        from okta_agent_proxy.proxy.handler import ProxyHandler
        from okta_agent_proxy.audit.context import agent_id_var, user_id_var, client_id_var

        agent_config = {"agent_id": "cursor", "client_id": "cursor-client-id",
                        "backend_access": ["hr-system"]}
        router = _make_mock_router()
        validator = _make_mock_validator(claims={"sub": "jane@corp.com", "aud": "cursor-client-id", "exp": 9999999999})
        store = _make_mock_store(agent_config)

        handler = ProxyHandler(router, validator, store)
        handler.session_manager = MagicMock()
        handler.session_manager.get_or_create_session = AsyncMock(return_value="session-123")

        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.headers = {"content-type": "application/json"}
        mock_response.json.return_value = {
            "jsonrpc": "2.0", "id": "1",
            "result": {"tools": []}
        }

        set_request_context(correlation_id="ctx-enrich-1")

        with patch("okta_agent_proxy.proxy.handler.create_auth_handler") as mock_auth:
            mock_auth_handler = MagicMock()
            mock_auth_handler.get_auth_headers = AsyncMock(return_value={"X-API-Key": "test"})
            mock_auth.return_value = mock_auth_handler

            with patch("httpx.AsyncClient") as mock_client_cls:
                mock_client = AsyncMock()
                mock_client.post = AsyncMock(return_value=mock_response)
                mock_client.__aenter__ = AsyncMock(return_value=mock_client)
                mock_client.__aexit__ = AsyncMock(return_value=False)
                mock_client_cls.return_value = mock_client

                await handler.proxy_request(
                    request_path="/hr",
                    method="tools/list",
                    params={},
                    auth_header="Bearer fake.jwt.token",
                    request_id="1",
                    headers={"x-mcp-agent": "cursor"},
                )

        # Verify context vars were set during processing
        assert agent_id_var.get() == "cursor"
        assert user_id_var.get() == "jane@corp.com"
        assert client_id_var.get() == "cursor-client-id"


# --- UnifiedMCPHandler tests ---


class TestUnifiedHandlerAudit:
    @pytest.mark.asyncio
    async def test_tools_list_cache_hit_emits_event(self, capture_emitter):
        """Cached tools/list emits MCP_TOOL_LIST with cache=hit."""
        from okta_agent_proxy.mcp.unified_handler import UnifiedMCPHandler

        router = _make_mock_router()
        validator = _make_mock_validator()
        store = _make_mock_store({"agent_id": "claude-code", "client_id": "test-client",
                                  "backend_access": ["hr-system"]})

        handler = UnifiedMCPHandler(router, validator, store)

        # Pre-populate tool cache
        handler._tool_cache["claude-code"] = {
            "tools": [{"name": "hr-system__get_employee", "description": "Get employee"}],
            "tool_map": {"hr-system__get_employee": ("hr-system", "get_employee")},
        }

        set_request_context(correlation_id="unified-list-hit-1", agent_id="claude-code")

        with patch.object(handler, "_authenticate", new_callable=AsyncMock,
                          return_value=("claude-code", {"agent_id": "claude-code", "client_id": "test-client",
                                                         "backend_access": ["hr-system"]},
                                        "user@test.com", "fake-token")):
            result, status, _ = await handler.handle(
                {"jsonrpc": "2.0", "id": "1", "method": "tools/list", "params": {}},
                {"authorization": "Bearer fake", "x-mcp-agent": "claude-code"},
            )

        assert status == 200
        await asyncio.sleep(0.15)

        events = [e for e in capture_emitter.events
                  if e.event_type == AuditEventType.MCP_TOOL_LIST]
        assert len(events) == 1
        assert events[0].details["cache"] == "hit"
        assert events[0].details["tool_count"] == 1

    @pytest.mark.asyncio
    @patch("okta_agent_proxy.auth.agent_authz.check_agent_can_access_resource", new_callable=AsyncMock, return_value=True)
    async def test_tools_call_success_emits_event(self, mock_authz, capture_emitter):
        """Successful tools/call emits MCP_TOOL_CALL with latency."""
        from okta_agent_proxy.mcp.unified_handler import UnifiedMCPHandler

        agent_config = {"agent_id": "claude-code", "client_id": "test-client",
                        "backend_access": ["hr-system"]}
        router = _make_mock_router()
        validator = _make_mock_validator()
        store = _make_mock_store(agent_config)

        handler = UnifiedMCPHandler(router, validator, store)

        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.headers = {"content-type": "application/json"}
        mock_response.json.return_value = {
            "jsonrpc": "2.0", "id": "1",
            "result": {"content": [{"type": "text", "text": "Employee data"}]}
        }

        set_request_context(correlation_id="unified-call-ok-1", agent_id="claude-code")

        with patch.object(handler, "_authenticate", new_callable=AsyncMock,
                          return_value=("claude-code", agent_config, "user@test.com", "fake-token")):
            with patch.object(handler, "_get_resource_auth_headers", new_callable=AsyncMock,
                              return_value={"X-API-Key": "test"}):
                with patch.object(handler, "_get_resource_session", new_callable=AsyncMock,
                                  return_value="session-123"):
                    with patch("httpx.AsyncClient") as mock_client_cls:
                        mock_client = AsyncMock()
                        mock_client.post = AsyncMock(return_value=mock_response)
                        mock_client.__aenter__ = AsyncMock(return_value=mock_client)
                        mock_client.__aexit__ = AsyncMock(return_value=False)
                        mock_client_cls.return_value = mock_client

                        result, status, _ = await handler.handle(
                            {"jsonrpc": "2.0", "id": "1", "method": "tools/call",
                             "params": {"name": "hr-system__get_employee", "arguments": {"id": "123"}}},
                            {"authorization": "Bearer fake", "x-mcp-agent": "claude-code"},
                        )

        assert status == 200
        await asyncio.sleep(0.15)

        events = [e for e in capture_emitter.events
                  if e.event_type == AuditEventType.MCP_TOOL_CALL]
        assert len(events) == 1
        assert events[0].outcome == "success"
        assert events[0].resource_name == "hr-system"
        assert events[0].details["tool_name"] == "hr-system__get_employee"
        assert "latency_ms" in events[0].details

    @pytest.mark.asyncio
    @patch("okta_agent_proxy.auth.agent_authz.check_agent_can_access_resource", new_callable=AsyncMock, return_value=True)
    async def test_tools_call_timeout_emits_failure(self, mock_authz, capture_emitter):
        """Resource timeout in unified handler emits MCP_TOOL_CALL with failure."""
        from okta_agent_proxy.mcp.unified_handler import UnifiedMCPHandler

        agent_config = {"agent_id": "claude-code", "client_id": "test-client",
                        "backend_access": ["hr-system"]}
        router = _make_mock_router()
        validator = _make_mock_validator()
        store = _make_mock_store(agent_config)

        handler = UnifiedMCPHandler(router, validator, store)

        set_request_context(correlation_id="unified-call-timeout-1", agent_id="claude-code")

        with patch.object(handler, "_authenticate", new_callable=AsyncMock,
                          return_value=("claude-code", agent_config, "user@test.com", "fake-token")):
            with patch.object(handler, "_get_resource_auth_headers", new_callable=AsyncMock,
                              return_value={"X-API-Key": "test"}):
                with patch.object(handler, "_get_resource_session", new_callable=AsyncMock,
                                  return_value="session-123"):
                    with patch("httpx.AsyncClient") as mock_client_cls:
                        mock_client = AsyncMock()
                        mock_client.post = AsyncMock(side_effect=httpx.TimeoutException("timeout"))
                        mock_client.__aenter__ = AsyncMock(return_value=mock_client)
                        mock_client.__aexit__ = AsyncMock(return_value=False)
                        mock_client_cls.return_value = mock_client

                        result, status, _ = await handler.handle(
                            {"jsonrpc": "2.0", "id": "1", "method": "tools/call",
                             "params": {"name": "hr-system__get_employee", "arguments": {}}},
                            {"authorization": "Bearer fake", "x-mcp-agent": "claude-code"},
                        )

        await asyncio.sleep(0.15)

        events = [e for e in capture_emitter.events
                  if e.event_type == AuditEventType.MCP_TOOL_CALL]
        assert len(events) == 1
        assert events[0].outcome == "failure"
        assert events[0].details["error"] == "resource_timeout"

    @pytest.mark.asyncio
    async def test_unified_context_enrichment(self, capture_emitter):
        """Unified handler enriches audit context via _authenticate."""
        from okta_agent_proxy.mcp.unified_handler import UnifiedMCPHandler
        from okta_agent_proxy.audit.context import agent_id_var, user_id_var, client_id_var

        agent_config = {"agent_id": "cursor", "client_id": "cursor-client",
                        "backend_access": ["hr-system"]}
        router = _make_mock_router()
        validator = _make_mock_validator(claims={"sub": "bob@corp.com", "aud": "cursor-client", "exp": 9999999999})
        store = _make_mock_store(agent_config)

        handler = UnifiedMCPHandler(router, validator, store)

        # Pre-populate tool cache
        handler._tool_cache["cursor"] = {
            "tools": [{"name": "hr-system__search", "description": "Search"}],
            "tool_map": {"hr-system__search": ("hr-system", "search")},
        }

        set_request_context(correlation_id="unified-ctx-1")

        result, status, _ = await handler.handle(
            {"jsonrpc": "2.0", "id": "1", "method": "tools/list", "params": {}},
            {"authorization": "Bearer fake", "x-mcp-agent": "cursor"},
        )

        assert status == 200
        assert agent_id_var.get() == "cursor"
        assert user_id_var.get() == "bob@corp.com"
        assert client_id_var.get() == "cursor-client"


# --- Session Manager tests ---


class TestSessionManagerAudit:
    @pytest.mark.asyncio
    async def test_session_created_emits_event(self, capture_emitter):
        """New session creation emits MCP_SESSION_CREATED."""
        from okta_agent_proxy.proxy.session_manager import MCPSessionManager

        manager = MCPSessionManager(session_ttl=3600)

        set_request_context(correlation_id="session-create-1")

        with patch.object(manager, "_create_session", new_callable=AsyncMock,
                          return_value="new-session-id-12345678"):
            session_id = await manager.get_or_create_session(
                user_id="user@test.com",
                resource_name="hr-system",
                resource_url="http://backend:8080/mcp",
                access_token="token-xyz",
            )

        assert session_id == "new-session-id-12345678"
        await asyncio.sleep(0.15)

        events = [e for e in capture_emitter.events
                  if e.event_type == AuditEventType.MCP_SESSION_CREATED]
        assert len(events) == 1
        assert events[0].resource_name == "hr-system"
        assert events[0].details["user_id"] == "user@test.com"
        assert events[0].details["resource_name"] == "hr-system"

    @pytest.mark.asyncio
    async def test_cached_session_does_not_emit_event(self, capture_emitter):
        """Returning a cached session does NOT emit MCP_SESSION_CREATED."""
        from okta_agent_proxy.proxy.session_manager import MCPSessionManager

        manager = MCPSessionManager(session_ttl=3600)
        # Pre-populate cache
        manager.sessions["user@test.com:hr-system"] = {
            "session_id": "existing-session-123",
            "created_at": "2026-01-01T00:00:00",
            "expires_at": "2026-01-01T01:00:00",
            "resource_url": "http://backend:8080/mcp",
        }

        set_request_context(correlation_id="session-cached-1")

        session_id = await manager.get_or_create_session(
            user_id="user@test.com",
            resource_name="hr-system",
            resource_url="http://backend:8080/mcp",
            access_token="token-xyz",
        )

        assert session_id == "existing-session-123"
        await asyncio.sleep(0.15)

        events = [e for e in capture_emitter.events
                  if e.event_type == AuditEventType.MCP_SESSION_CREATED]
        assert len(events) == 0

    @pytest.mark.asyncio
    async def test_session_terminated_emits_event(self, capture_emitter):
        """Successful session termination emits MCP_SESSION_TERMINATED."""
        from okta_agent_proxy.proxy.session_manager import MCPSessionManager

        manager = MCPSessionManager(session_ttl=3600)
        # Pre-populate cache so termination can find it
        manager.sessions["user@test.com:hr-system"] = {
            "session_id": "term-session-123",
            "created_at": "2026-01-01T00:00:00",
            "expires_at": "2026-01-01T01:00:00",
            "resource_url": "http://backend:8080/mcp",
        }

        set_request_context(correlation_id="session-term-1")

        mock_response = MagicMock()
        mock_response.status_code = 204

        with patch("httpx.AsyncClient") as mock_client_cls:
            mock_client = AsyncMock()
            mock_client.delete = AsyncMock(return_value=mock_response)
            mock_client.__aenter__ = AsyncMock(return_value=mock_client)
            mock_client.__aexit__ = AsyncMock(return_value=False)
            mock_client_cls.return_value = mock_client

            result = await manager.terminate_session(
                user_id="user@test.com",
                resource_name="hr-system",
                resource_url="http://backend:8080/mcp",
                session_id="term-session-123",
            )

        assert result is True
        await asyncio.sleep(0.15)

        events = [e for e in capture_emitter.events
                  if e.event_type == AuditEventType.MCP_SESSION_TERMINATED]
        assert len(events) == 1
        assert events[0].resource_name == "hr-system"
        assert events[0].details["user_id"] == "user@test.com"
