"""Integration tests for /oauth/global-token-revocation route (P7)."""

import asyncio
import base64
import json
import time
import uuid
from typing import List
from unittest.mock import AsyncMock, MagicMock, patch

import cachetools
import pytest
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric import rsa
from jose import jwt as jose_jwt
from starlette.applications import Starlette
from starlette.middleware import Middleware
from starlette.routing import Route
from starlette.testclient import TestClient

from okta_agent_proxy.audit.emitter import AuditEventEmitter
from okta_agent_proxy.audit.events import AuditEvent, AuditEventType
from okta_agent_proxy.audit.sinks.base import AuditSink
from okta_agent_proxy.auth.global_logout import (
    GlobalLogoutHandler,
    reset_global_logout_handler,
)
from okta_agent_proxy.auth.global_logout_route import (
    EXPECTED_TYP,
    GLOBAL_LOGOUT_PATH,
    _reset_allowlist_cache,
    _reset_rate_limiter,
    global_token_revocation,
    invalidate_agent_client_id_allowlist,
)
from okta_agent_proxy.middleware.correlation import CorrelationIdMiddleware


# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

TEST_OKTA_DOMAIN = "test.okta.com"
TEST_ISSUER = f"https://{TEST_OKTA_DOMAIN}"
TEST_GATEWAY_URL = "http://localhost:8000"
TEST_AUDIENCE = TEST_GATEWAY_URL + GLOBAL_LOGOUT_PATH
TEST_CALLER_CLIENT_ID = "0oarelaytest"


# ---------------------------------------------------------------------------
# Keypair / JWT helpers
# ---------------------------------------------------------------------------


def _int_to_b64url(n: int) -> str:
    byte_length = (n.bit_length() + 7) // 8
    raw = n.to_bytes(byte_length, byteorder="big")
    return base64.urlsafe_b64encode(raw).rstrip(b"=").decode("ascii")


def _generate_rsa_keypair(kid: str = "test-key-id"):
    key = rsa.generate_private_key(public_exponent=65537, key_size=2048)
    private_pem = key.private_bytes(
        encoding=serialization.Encoding.PEM,
        format=serialization.PrivateFormat.PKCS8,
        encryption_algorithm=serialization.NoEncryption(),
    )
    pub_numbers = key.public_key().public_numbers()
    public_jwk = {
        "kty": "RSA",
        "kid": kid,
        "use": "sig",
        "alg": "RS256",
        "n": _int_to_b64url(pub_numbers.n),
        "e": _int_to_b64url(pub_numbers.e),
    }
    return private_pem, {"keys": [public_jwk]}


def _sign_jwt(
    claims: dict,
    private_pem: bytes,
    kid: str = "test-key-id",
    typ: str = EXPECTED_TYP,
) -> str:
    return jose_jwt.encode(
        claims,
        private_pem,
        algorithm="RS256",
        headers={"kid": kid, "typ": typ},
    )


# ---------------------------------------------------------------------------
# Capture sink
# ---------------------------------------------------------------------------


class CaptureSink(AuditSink):
    def __init__(self):
        self.events: List[AuditEvent] = []

    async def write(self, event: AuditEvent) -> None:
        self.events.append(event)

    @property
    def name(self) -> str:
        return "capture"


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


@pytest.fixture(autouse=True)
def _env(monkeypatch):
    monkeypatch.setenv("OKTA_DOMAIN", TEST_OKTA_DOMAIN)
    monkeypatch.setenv("OKTA_ISSUER", TEST_ISSUER)
    monkeypatch.setenv("GATEWAY_BASE_URL", TEST_GATEWAY_URL)
    monkeypatch.delenv("GLOBAL_LOGOUT_AUDIENCE", raising=False)
    _reset_allowlist_cache()
    _reset_rate_limiter()
    reset_global_logout_handler()
    yield
    _reset_allowlist_cache()
    _reset_rate_limiter()
    reset_global_logout_handler()


@pytest.fixture(autouse=True)
def _default_allowlist(monkeypatch):
    """Patch _load_agent_client_id_allowlist so existing v4
    tests using TEST_CALLER_CLIENT_ID authorize by default.
    Tests that need a different allowlist can override by
    re-patching the loader and calling
    invalidate_agent_client_id_allowlist() to force a reread."""
    async def _default_loader():
        return frozenset({
            TEST_CALLER_CLIENT_ID,
            "0oaagent1abc",
            "0oaagent2def",
        })
    monkeypatch.setattr(
        "okta_agent_proxy.auth.global_logout_route."
        "_load_agent_client_id_allowlist",
        _default_loader,
    )
    _reset_allowlist_cache()
    yield
    _reset_allowlist_cache()


@pytest.fixture
def keypair():
    return _generate_rsa_keypair()


@pytest.fixture
def patched_jwks(keypair):
    _, public_jwks = keypair
    with patch(
        "okta_agent_proxy.auth.global_logout_route.get_validator"
    ) as mock_get_validator:
        mock_validator = MagicMock()
        mock_validator.fetch_jwks = AsyncMock(return_value=public_jwks)
        mock_get_validator.return_value = mock_validator
        yield


@pytest.fixture
def mock_handler_deps():
    from okta_agent_proxy.auth import global_logout as gl_module

    mock_store = AsyncMock()
    mock_store.aremove_by_user = AsyncMock(return_value=0)

    mock_cache = AsyncMock()
    mock_cache.ainvalidate_all_for_user = AsyncMock(return_value=None)

    mock_sm = AsyncMock()
    mock_sm.terminate_all_for_user = AsyncMock(return_value={})

    handler = GlobalLogoutHandler(
        token_store=mock_store,
        token_cache=mock_cache,
        session_manager=mock_sm,
    )
    gl_module._handler = handler
    yield {"store": mock_store, "cache": mock_cache, "sm": mock_sm}
    gl_module._handler = None


@pytest.fixture
def patched_allowlist(monkeypatch):
    """Return a list-of-dicts shaped like store.get_all_agents,
    and let tests mutate it to simulate agent CRUD."""
    agents_data = [
        {"agent_id": "a1", "client_id": "0oaagent1abc"},
        {"agent_id": "a2", "client_id": "0oaagent2def"},
    ]

    async def _loader():
        return frozenset(
            a["client_id"] for a in agents_data
            if isinstance(a.get("client_id"), str) and a.get("client_id")
        )

    monkeypatch.setattr(
        "okta_agent_proxy.auth.global_logout_route."
        "_load_agent_client_id_allowlist",
        _loader,
    )
    _reset_allowlist_cache()
    yield agents_data


@pytest.fixture
def client():
    app = Starlette(
        routes=[
            Route(GLOBAL_LOGOUT_PATH, global_token_revocation, methods=["POST"]),
        ],
        middleware=[Middleware(CorrelationIdMiddleware)],
    )
    return TestClient(app, raise_server_exceptions=False)


@pytest.fixture
async def capture_emitter():
    sink = CaptureSink()
    emitter = AuditEventEmitter(sinks=[sink], flush_interval=0.05)
    await emitter.start()

    import okta_agent_proxy.audit as audit_mod

    old = audit_mod._emitter
    audit_mod._emitter = emitter
    yield sink
    audit_mod._emitter = old
    await emitter.stop()


# ---------------------------------------------------------------------------
# Builders
# ---------------------------------------------------------------------------


def _valid_claims(
    aud: str = TEST_AUDIENCE,
    iss: str = TEST_ISSUER,
    sub: str = TEST_CALLER_CLIENT_ID,
) -> dict:
    now = int(time.time())
    return {
        "jti": str(uuid.uuid4()),
        "iss": iss,
        "sub": sub,
        "aud": aud,
        "iat": now,
        "nbf": now - 60,
        "exp": now + 300,
    }


def _valid_body(sub: str = "00ujane", subject_iss: str = TEST_ISSUER) -> dict:
    return {
        "subject": {
            "format": "iss_sub",
            "iss": subject_iss,
            "sub": sub,
        }
    }


def _bearer(jwt_token: str) -> dict:
    return {"Authorization": f"Bearer {jwt_token}"}


def _poll(predicate, timeout: float = 1.0, step: float = 0.025) -> bool:
    end = time.monotonic() + timeout
    while time.monotonic() < end:
        if predicate():
            return True
        time.sleep(step)
    return False


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------


def test_happy_path_returns_204(client, keypair, patched_jwks, mock_handler_deps):
    private_pem, _ = keypair
    token = _sign_jwt(_valid_claims(), private_pem)
    resp = client.post(
        GLOBAL_LOGOUT_PATH,
        headers=_bearer(token),
        json=_valid_body(sub="00ujane"),
    )
    assert resp.status_code == 204
    assert _poll(lambda: mock_handler_deps["store"].aremove_by_user.await_count > 0)
    mock_handler_deps["store"].aremove_by_user.assert_awaited_with("00ujane")


def test_missing_authorization_header_returns_401(client, patched_jwks):
    resp = client.post(GLOBAL_LOGOUT_PATH, json=_valid_body())
    assert resp.status_code == 401
    assert resp.json()["error"] == "invalid_client"


def test_non_bearer_authorization_returns_401(client, patched_jwks):
    resp = client.post(
        GLOBAL_LOGOUT_PATH,
        headers={"Authorization": "Basic foo"},
        json=_valid_body(),
    )
    assert resp.status_code == 401


def test_invalid_jwt_signature_returns_401(client, keypair, patched_jwks):
    other_private_pem, _ = _generate_rsa_keypair(kid="other-kid")
    # Use the SAME kid as the served JWKS so kid lookup finds a key,
    # but sign with a non-matching private key -> signature verification fails.
    token = _sign_jwt(_valid_claims(), other_private_pem, kid="test-key-id")
    resp = client.post(GLOBAL_LOGOUT_PATH, headers=_bearer(token), json=_valid_body())
    assert resp.status_code == 401


def test_expired_jwt_returns_401(client, keypair, patched_jwks):
    private_pem, _ = keypair
    claims = _valid_claims()
    claims["exp"] = int(time.time()) - 60
    token = _sign_jwt(claims, private_pem)
    resp = client.post(GLOBAL_LOGOUT_PATH, headers=_bearer(token), json=_valid_body())
    assert resp.status_code == 401


def test_nbf_in_future_returns_401(client, keypair, patched_jwks):
    private_pem, _ = keypair
    claims = _valid_claims()
    claims["nbf"] = int(time.time()) + 300
    token = _sign_jwt(claims, private_pem)
    resp = client.post(GLOBAL_LOGOUT_PATH, headers=_bearer(token), json=_valid_body())
    assert resp.status_code == 401


def test_wrong_typ_header_returns_401(client, keypair, patched_jwks):
    private_pem, _ = keypair
    token = _sign_jwt(_valid_claims(), private_pem, typ="JWT")
    resp = client.post(GLOBAL_LOGOUT_PATH, headers=_bearer(token), json=_valid_body())
    assert resp.status_code == 401


def test_wrong_audience_returns_401(client, keypair, patched_jwks):
    private_pem, _ = keypair
    claims = _valid_claims(aud="https://wrong.example.com/oauth/global-token-revocation")
    token = _sign_jwt(claims, private_pem)
    resp = client.post(GLOBAL_LOGOUT_PATH, headers=_bearer(token), json=_valid_body())
    assert resp.status_code == 401


def test_wrong_jwt_issuer_returns_401(client, keypair, patched_jwks):
    private_pem, _ = keypair
    claims = _valid_claims(iss="https://other.okta.com")
    token = _sign_jwt(claims, private_pem)
    resp = client.post(GLOBAL_LOGOUT_PATH, headers=_bearer(token), json=_valid_body())
    assert resp.status_code == 401


def test_email_subject_format_returns_400_with_helpful_hint(
    client, keypair, patched_jwks, mock_handler_deps
):
    private_pem, _ = keypair
    token = _sign_jwt(_valid_claims(), private_pem)
    body = {"subject": {"format": "email", "email": "j@x.com"}}
    resp = client.post(GLOBAL_LOGOUT_PATH, headers=_bearer(token), json=body)
    assert resp.status_code == 400
    data = resp.json()
    assert data["error"] == "unsupported_subject_format"
    assert "Issuer and Subject Identifier" in data["error_description"]


def test_missing_subject_field_returns_400(
    client, keypair, patched_jwks, mock_handler_deps
):
    private_pem, _ = keypair
    token = _sign_jwt(_valid_claims(), private_pem)
    resp = client.post(GLOBAL_LOGOUT_PATH, headers=_bearer(token), json={})
    assert resp.status_code == 400
    assert resp.json()["error"] == "missing_subject"


def test_malformed_body_returns_400(client, keypair, patched_jwks, mock_handler_deps):
    private_pem, _ = keypair
    token = _sign_jwt(_valid_claims(), private_pem)
    resp = client.post(
        GLOBAL_LOGOUT_PATH,
        headers={**_bearer(token), "Content-Type": "application/json"},
        content=b"not-json",
    )
    assert resp.status_code == 400
    assert resp.json()["error"] == "malformed_body"


def test_subject_iss_mismatch_returns_400(
    client, keypair, patched_jwks, mock_handler_deps
):
    private_pem, _ = keypair
    token = _sign_jwt(_valid_claims(), private_pem)
    body = _valid_body(subject_iss="https://evil.example.com")
    resp = client.post(GLOBAL_LOGOUT_PATH, headers=_bearer(token), json=body)
    assert resp.status_code == 400
    assert resp.json()["error"] == "invalid_subject"


def test_subject_not_found_still_returns_204(
    client, keypair, patched_jwks, mock_handler_deps
):
    private_pem, _ = keypair
    mock_handler_deps["store"].aremove_by_user = AsyncMock(return_value=0)
    mock_handler_deps["sm"].terminate_all_for_user = AsyncMock(return_value={})
    token = _sign_jwt(_valid_claims(), private_pem)
    resp = client.post(
        GLOBAL_LOGOUT_PATH, headers=_bearer(token), json=_valid_body(sub="unknown")
    )
    assert resp.status_code == 204
    assert _poll(lambda: mock_handler_deps["store"].aremove_by_user.await_count > 0)


def test_terminates_mcp_sessions(client, keypair, patched_jwks, mock_handler_deps):
    private_pem, _ = keypair
    mock_handler_deps["sm"].terminate_all_for_user = AsyncMock(
        return_value={"hr": True, "finance": True}
    )
    token = _sign_jwt(_valid_claims(), private_pem)
    resp = client.post(GLOBAL_LOGOUT_PATH, headers=_bearer(token), json=_valid_body())
    assert resp.status_code == 204
    assert _poll(lambda: mock_handler_deps["sm"].terminate_all_for_user.await_count > 0)


def test_rate_limit_exceeded_returns_429(
    client, keypair, patched_jwks, mock_handler_deps
):
    private_pem, _ = keypair
    token = _sign_jwt(_valid_claims(), private_pem)
    for _ in range(100):
        resp = client.post(
            GLOBAL_LOGOUT_PATH, headers=_bearer(token), json=_valid_body()
        )
        assert resp.status_code == 204
    resp = client.post(GLOBAL_LOGOUT_PATH, headers=_bearer(token), json=_valid_body())
    assert resp.status_code == 429
    assert resp.json()["error"] == "rate_limit_exceeded"


@pytest.mark.asyncio
async def test_correlation_id_and_context_propagated_to_background_task(
    client, keypair, patched_jwks, mock_handler_deps, capture_emitter
):
    private_pem, _ = keypair
    token = _sign_jwt(_valid_claims(), private_pem)

    resp = client.post(
        GLOBAL_LOGOUT_PATH,
        headers={
            **_bearer(token),
            "X-Correlation-Id": "test-corr-42",
            "User-Agent": "p7-agent/1.0",
        },
        json=_valid_body(sub="00ujane"),
    )
    assert resp.status_code == 204

    def _seen():
        return any(
            e.event_type == AuditEventType.GLOBAL_LOGOUT_COMPLETED
            for e in capture_emitter.events
        )

    # poll for bg task completion
    end = time.monotonic() + 2.0
    while time.monotonic() < end and not _seen():
        await asyncio.sleep(0.05)

    completed = [
        e
        for e in capture_emitter.events
        if e.event_type == AuditEventType.GLOBAL_LOGOUT_COMPLETED
    ]
    assert len(completed) >= 1
    evt = completed[0]
    assert evt.correlation_id == "test-corr-42"
    assert evt.user_agent == "p7-agent/1.0"


def test_backend_session_termination_failure_still_returns_204(
    client, keypair, patched_jwks, mock_handler_deps
):
    private_pem, _ = keypair
    mock_handler_deps["sm"].terminate_all_for_user = AsyncMock(
        return_value={"hr": False}
    )
    token = _sign_jwt(_valid_claims(), private_pem)
    resp = client.post(GLOBAL_LOGOUT_PATH, headers=_bearer(token), json=_valid_body())
    assert resp.status_code == 204


def test_rate_limiter_idle_ips_eventually_evicted(
    client, keypair, patched_jwks, mock_handler_deps
):
    """With a short TTL on the rate-limit cache, idle IPs age out."""
    import okta_agent_proxy.auth.global_logout_route as route_mod

    original = route_mod._rate_limit_state
    try:
        route_mod._rate_limit_state = cachetools.TTLCache(maxsize=4096, ttl=0.1)
        private_pem, _ = keypair
        token = _sign_jwt(_valid_claims(), private_pem)
        resp = client.post(
            GLOBAL_LOGOUT_PATH,
            headers=_bearer(token),
            json=_valid_body(),
        )
        assert resp.status_code == 204
        # TestClient uses "testclient" as the default client host.
        hot_ip = next(iter(route_mod._rate_limit_state.keys()), None)
        assert hot_ip is not None
        time.sleep(0.2)
        # TTLCache expires entries on access
        assert hot_ip not in route_mod._rate_limit_state
    finally:
        route_mod._rate_limit_state = original


# ---------------------------------------------------------------------------
# Allowlist tests (v5 — DB-backed client_id allowlist)
# ---------------------------------------------------------------------------


def test_jwt_sub_in_allowlist_returns_204(
    client, keypair, patched_jwks, patched_allowlist, mock_handler_deps
):
    private_pem, _ = keypair
    claims = _valid_claims(sub="0oaagent1abc")
    jwt_token = _sign_jwt(claims, private_pem)
    resp = client.post(
        GLOBAL_LOGOUT_PATH,
        json=_valid_body(),
        headers=_bearer(jwt_token),
    )
    assert resp.status_code == 204


def test_jwt_sub_not_in_allowlist_returns_401(
    client, keypair, patched_jwks, patched_allowlist
):
    private_pem, _ = keypair
    claims = _valid_claims(sub="0oaUNKNOWNapp")
    jwt_token = _sign_jwt(claims, private_pem)
    resp = client.post(
        GLOBAL_LOGOUT_PATH,
        json=_valid_body(),
        headers=_bearer(jwt_token),
    )
    assert resp.status_code == 401
    assert resp.json()["error"] == "invalid_client"


def test_jwt_sub_missing_returns_401(
    client, keypair, patched_jwks, patched_allowlist
):
    """JWT with no sub claim still rejected by allowlist check."""
    private_pem, _ = keypair
    claims = _valid_claims()
    claims.pop("sub")
    jwt_token = _sign_jwt(claims, private_pem)
    resp = client.post(
        GLOBAL_LOGOUT_PATH,
        json=_valid_body(),
        headers=_bearer(jwt_token),
    )
    assert resp.status_code == 401


def test_disabled_agent_client_id_still_in_allowlist(
    client, keypair, patched_jwks, patched_allowlist, mock_handler_deps
):
    """The loader uses enabled_only=False; assert disabled agents
    (which would still appear in the loader output) are accepted."""
    patched_allowlist.append(
        {"agent_id": "disabled1", "client_id": "0oaDISABLEDx",
         "enabled": False}
    )
    invalidate_agent_client_id_allowlist()

    private_pem, _ = keypair
    claims = _valid_claims(sub="0oaDISABLEDx")
    jwt_token = _sign_jwt(claims, private_pem)
    resp = client.post(
        GLOBAL_LOGOUT_PATH,
        json=_valid_body(),
        headers=_bearer(jwt_token),
    )
    assert resp.status_code == 204


def test_allowlist_cache_invalidation_picks_up_new_agent(
    client, keypair, patched_jwks, patched_allowlist, mock_handler_deps
):
    """Simulate adding a new agent post-startup: cache invalidation
    triggers a re-query and the new client_id is accepted."""
    private_pem, _ = keypair

    claims = _valid_claims(sub="0oaNEWagent")
    jwt_token = _sign_jwt(claims, private_pem)
    resp = client.post(
        GLOBAL_LOGOUT_PATH,
        json=_valid_body(),
        headers=_bearer(jwt_token),
    )
    assert resp.status_code == 401

    patched_allowlist.append(
        {"agent_id": "new1", "client_id": "0oaNEWagent"}
    )
    invalidate_agent_client_id_allowlist()

    claims = _valid_claims(sub="0oaNEWagent")
    jwt_token = _sign_jwt(claims, private_pem)
    resp = client.post(
        GLOBAL_LOGOUT_PATH,
        json=_valid_body(),
        headers=_bearer(jwt_token),
    )
    assert resp.status_code == 204


def test_allowlist_load_failure_keeps_previous_value(
    client, keypair, patched_jwks, patched_allowlist, mock_handler_deps,
    monkeypatch,
):
    """If the DB load fails on a refresh, the existing allowlist
    value is preserved (do not regress to empty set)."""
    private_pem, _ = keypair
    claims = _valid_claims(sub="0oaagent1abc")
    jwt_token = _sign_jwt(claims, private_pem)
    resp = client.post(
        GLOBAL_LOGOUT_PATH,
        json=_valid_body(),
        headers=_bearer(jwt_token),
    )
    assert resp.status_code == 204

    async def _raising_loader():
        raise RuntimeError("DB unavailable")
    monkeypatch.setattr(
        "okta_agent_proxy.auth.global_logout_route."
        "_load_agent_client_id_allowlist",
        _raising_loader,
    )
    invalidate_agent_client_id_allowlist()

    claims = _valid_claims(sub="0oaagent1abc")
    jwt_token = _sign_jwt(claims, private_pem)
    resp = client.post(
        GLOBAL_LOGOUT_PATH,
        json=_valid_body(),
        headers=_bearer(jwt_token),
    )
    assert resp.status_code == 204


def test_allowlist_first_load_failure_returns_empty_set_rejecting_all(
    client, keypair, patched_jwks, monkeypatch,
):
    """If the FIRST allowlist load (no prior value) fails, the
    allowlist is empty and all logout calls are rejected — fail
    closed. This test overrides the autouse _default_allowlist by
    re-patching the loader to raise, then resetting the cache."""
    async def _raising_loader():
        raise RuntimeError("DB unavailable on startup")
    monkeypatch.setattr(
        "okta_agent_proxy.auth.global_logout_route."
        "_load_agent_client_id_allowlist",
        _raising_loader,
    )
    _reset_allowlist_cache()

    private_pem, _ = keypair
    claims = _valid_claims(sub="0oaanything")
    jwt_token = _sign_jwt(claims, private_pem)
    resp = client.post(
        GLOBAL_LOGOUT_PATH,
        json=_valid_body(),
        headers=_bearer(jwt_token),
    )
    assert resp.status_code == 401


def test_allowlist_ttl_expiration_triggers_refresh(
    client, keypair, patched_jwks, patched_allowlist, mock_handler_deps,
    monkeypatch,
):
    """After TTL expires, the next request triggers a re-query."""
    monkeypatch.setattr(
        "okta_agent_proxy.auth.global_logout_route._ALLOWLIST_TTL_SECONDS",
        0.05,
    )

    private_pem, _ = keypair
    claims = _valid_claims(sub="0oaagent1abc")
    jwt_token = _sign_jwt(claims, private_pem)
    resp = client.post(
        GLOBAL_LOGOUT_PATH,
        json=_valid_body(),
        headers=_bearer(jwt_token),
    )
    assert resp.status_code == 204

    time.sleep(0.1)
    patched_allowlist.append(
        {"agent_id": "ttltest", "client_id": "0oaTTLagent"}
    )

    claims = _valid_claims(sub="0oaTTLagent")
    jwt_token = _sign_jwt(claims, private_pem)
    resp = client.post(
        GLOBAL_LOGOUT_PATH,
        json=_valid_body(),
        headers=_bearer(jwt_token),
    )
    assert resp.status_code == 204
