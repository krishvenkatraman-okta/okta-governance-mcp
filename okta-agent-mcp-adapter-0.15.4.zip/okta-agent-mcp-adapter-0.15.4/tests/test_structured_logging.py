"""Tests for structured logging setup."""

import json
import logging
from io import StringIO

import pytest

from okta_agent_proxy.audit.context import (
    clear_request_context,
    set_request_context,
)
from okta_agent_proxy.middleware.logging import ContextFilter, setup_logging


@pytest.fixture(autouse=True)
def _clean():
    clear_request_context()
    yield
    clear_request_context()
    # Reset root logger so tests don't leak handlers
    root = logging.getLogger()
    root.handlers.clear()
    root.setLevel(logging.WARNING)


def _capture_logger(log_format: str, log_level: str = "INFO") -> tuple:
    """Set up logging with a StringIO handler and return (logger, stream)."""
    setup_logging(log_level=log_level, log_format=log_format)
    root = logging.getLogger()
    stream = StringIO()
    # Replace the StreamHandler's stream with our StringIO
    for h in root.handlers:
        if isinstance(h, logging.StreamHandler):
            h.stream = stream
            break
    logger = logging.getLogger("test.structured")
    return logger, stream


class TestJsonFormat:
    def test_produces_valid_json(self):
        logger, stream = _capture_logger("json")
        logger.info("hello world")
        line = stream.getvalue().strip()
        parsed = json.loads(line)
        assert parsed["message"] == "hello world"

    def test_includes_standard_fields(self):
        logger, stream = _capture_logger("json")
        logger.info("check fields")
        parsed = json.loads(stream.getvalue().strip())
        assert "timestamp" in parsed
        assert parsed["level"] == "INFO"
        assert parsed["logger"] == "test.structured"

    def test_correlation_id_from_context(self):
        logger, stream = _capture_logger("json")
        set_request_context(correlation_id="corr-abc-123", agent_id="claude")
        logger.info("with context")
        parsed = json.loads(stream.getvalue().strip())
        assert parsed["correlation_id"] == "corr-abc-123"
        assert parsed["agent_id"] == "claude"

    def test_empty_context_fields(self):
        logger, stream = _capture_logger("json")
        logger.info("no context")
        parsed = json.loads(stream.getvalue().strip())
        assert parsed["correlation_id"] == ""
        assert parsed["agent_id"] == ""

    def test_exception_included(self):
        logger, stream = _capture_logger("json")
        try:
            raise ValueError("boom")
        except ValueError:
            logger.exception("something failed")
        parsed = json.loads(stream.getvalue().strip())
        assert "boom" in parsed.get("exc_info", "")

    def test_all_context_fields_present(self):
        logger, stream = _capture_logger("json")
        set_request_context(
            correlation_id="c1",
            agent_id="a1",
            user_id="u1",
            client_id="cl1",
            ip_address="10.0.0.1",
        )
        logger.info("full context")
        parsed = json.loads(stream.getvalue().strip())
        assert parsed["correlation_id"] == "c1"
        assert parsed["agent_id"] == "a1"
        assert parsed["user_id"] == "u1"
        assert parsed["client_id"] == "cl1"
        assert parsed["ip_address"] == "10.0.0.1"


class TestTextFormat:
    def test_text_format_works(self):
        logger, stream = _capture_logger("text")
        logger.info("text mode")
        output = stream.getvalue()
        assert "text mode" in output
        assert "INFO" in output

    def test_text_format_not_json(self):
        logger, stream = _capture_logger("text")
        logger.info("plain text")
        output = stream.getvalue().strip()
        with pytest.raises(json.JSONDecodeError):
            json.loads(output)

    def test_text_format_includes_logger_name(self):
        logger, stream = _capture_logger("text")
        logger.info("name check")
        assert "test.structured" in stream.getvalue()


class TestContextFilter:
    def test_filter_populates_record(self):
        set_request_context(
            correlation_id="filter-1",
            agent_id="ag-1",
            user_id="usr-1",
            client_id="cli-1",
            ip_address="1.2.3.4",
        )
        record = logging.LogRecord(
            name="test", level=logging.INFO, pathname="", lineno=0,
            msg="test", args=(), exc_info=None,
        )
        f = ContextFilter()
        result = f.filter(record)
        assert result is True
        assert record.correlation_id == "filter-1"
        assert record.agent_id == "ag-1"
        assert record.user_id == "usr-1"
        assert record.client_id == "cli-1"
        assert record.ip_address == "1.2.3.4"

    def test_filter_defaults_empty_strings(self):
        record = logging.LogRecord(
            name="test", level=logging.INFO, pathname="", lineno=0,
            msg="test", args=(), exc_info=None,
        )
        f = ContextFilter()
        f.filter(record)
        assert record.correlation_id == ""
        assert record.agent_id == ""

    def test_filter_always_returns_true(self):
        record = logging.LogRecord(
            name="test", level=logging.DEBUG, pathname="", lineno=0,
            msg="", args=(), exc_info=None,
        )
        assert ContextFilter().filter(record) is True


class TestLogLevel:
    def test_info_level(self):
        logger, stream = _capture_logger("json", log_level="INFO")
        logger.debug("should not appear")
        logger.info("should appear")
        lines = [l for l in stream.getvalue().strip().split("\n") if l]
        # Only the info message (plus the setup_logging info message)
        messages = [json.loads(l)["message"] for l in lines]
        assert "should appear" in messages
        assert "should not appear" not in messages

    def test_debug_level(self):
        logger, stream = _capture_logger("json", log_level="DEBUG")
        logger.debug("debug visible")
        lines = [l for l in stream.getvalue().strip().split("\n") if l]
        messages = [json.loads(l)["message"] for l in lines]
        assert "debug visible" in messages

    def test_warning_level(self):
        logger, stream = _capture_logger("json", log_level="WARNING")
        logger.info("hidden")
        logger.warning("shown")
        lines = [l for l in stream.getvalue().strip().split("\n") if l]
        messages = [json.loads(l)["message"] for l in lines]
        assert "shown" in messages
        assert "hidden" not in messages


class TestNoisyLoggerSuppression:
    def test_httpx_suppressed(self):
        setup_logging(log_level="DEBUG", log_format="json")
        assert logging.getLogger("httpx").level == logging.WARNING

    def test_asyncio_suppressed(self):
        setup_logging(log_level="DEBUG", log_format="json")
        assert logging.getLogger("asyncio").level == logging.WARNING
