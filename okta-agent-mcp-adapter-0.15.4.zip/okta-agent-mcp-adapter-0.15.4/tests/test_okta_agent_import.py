"""Tests for OktaAgentImport (Okta AI Agent import/sync into adapter store)."""

import asyncio
import json
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from okta_agent_proxy.auth.okta_agent_import import (
    ImportableAgent,
    ImportResult,
    OktaAgentImport,
)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _mock_store():
    """Create a mock config store with sensible defaults."""
    store = MagicMock()
    store.get_all_agents.return_value = []
    store.get_agent.return_value = None
    store.create_agent.return_value = True
    store.update_agent.return_value = True
    store.get_all_resources.return_value = [
        {
            "name": "hr-system",
            "url": "http://localhost:9000",
            "auth_method": "okta-cross-app",
            "auth_config": {
                "target_authorization_server": "https://dev-test.okta.com/oauth2/aus123hr",
            },
            "enabled": True,
        },
        {
            "name": "finance-system",
            "url": "http://localhost:9001",
            "auth_method": "okta-cross-app",
            "auth_config": {
                "target_authorization_server": "https://dev-test.okta.com/oauth2/aus456fin",
            },
            "enabled": True,
        },
    ]
    return store


def _mock_client():
    """Create a mock OktaAIAgentClient."""
    client = AsyncMock()
    client.list_agents.return_value = []
    client.get_agent.return_value = None
    client.get_agent_connections.return_value = []
    client.get_linked_app.return_value = None
    return client


def _sample_okta_agent(
    agent_id="agt_abc123",
    name="Demo AI Agent",
    status="ACTIVE",
    app_id="0oa_linked_app",
):
    return {
        "id": agent_id,
        "name": name,
        "description": "A demo agent",
        "status": status,
        "appId": app_id,
    }


def _sample_linked_app(client_id="0oaClientId123"):
    return {
        "id": "0oa_linked_app",
        "label": "Demo Agent App",
        "credentials": {
            "oauthClient": {
                "client_id": client_id,
            }
        },
    }


def _sample_connections():
    """Return connections with one IDENTITY_ASSERTION_CUSTOM_AS matching hr-system."""
    return [
        {
            "name": "hr-connection",
            "connectionType": "IDENTITY_ASSERTION_CUSTOM_AS",
            "status": "ACTIVE",
            "authorizationServer": {
                "orn": "orn:okta:idp:00o:authorization_servers:aus123hr",
            },
            "resourceIndicator": "orn:okta:idp:00o:authorization_servers:aus123hr",
            "scopes": ["mcp:read"],
        },
        {
            "name": "secret-conn",
            "connectionType": "STS_VAULT_SECRET",
            "status": "ACTIVE",
            "secret": {"orn": "orn:okta:pam:00o:secrets:secret-uuid-1"},
        },
    ]


# ---------------------------------------------------------------------------
# list_importable_agents
# ---------------------------------------------------------------------------

class TestListImportableAgents:

    @pytest.mark.asyncio
    async def test_empty_list(self):
        client = _mock_client()
        store = _mock_store()
        importer = OktaAgentImport(client, store)

        result = await importer.list_importable_agents("tok_admin")
        assert result == []

    @pytest.mark.asyncio
    async def test_returns_enriched_agents(self):
        client = _mock_client()
        store = _mock_store()

        client.list_agents.return_value = [_sample_okta_agent()]
        client.get_agent_connections.return_value = _sample_connections()
        client.get_linked_app.return_value = _sample_linked_app()

        importer = OktaAgentImport(client, store)
        result = await importer.list_importable_agents("tok_admin")

        assert len(result) == 1
        agent = result[0]
        assert isinstance(agent, ImportableAgent)
        assert agent.okta_agent_id == "agt_abc123"
        assert agent.name == "Demo AI Agent"
        assert agent.linked_app_client_id == "0oaClientId123"
        assert agent.connections_count == 2
        assert agent.already_imported is False

    @pytest.mark.asyncio
    async def test_already_imported_flag(self):
        client = _mock_client()
        store = _mock_store()

        # Simulate existing imported agent
        store.get_all_agents.return_value = [
            {"agent_name": "demo-ai-agent", "okta_ai_agent_id": "agt_abc123"}
        ]

        client.list_agents.return_value = [_sample_okta_agent()]
        client.get_agent_connections.return_value = []
        client.get_linked_app.return_value = _sample_linked_app()

        importer = OktaAgentImport(client, store)
        result = await importer.list_importable_agents("tok_admin")

        assert len(result) == 1
        assert result[0].already_imported is True

    @pytest.mark.asyncio
    async def test_no_linked_app(self):
        client = _mock_client()
        store = _mock_store()

        agent_data = _sample_okta_agent(app_id=None)
        client.list_agents.return_value = [agent_data]
        client.get_agent_connections.return_value = []

        importer = OktaAgentImport(client, store)
        result = await importer.list_importable_agents("tok_admin")

        assert len(result) == 1
        assert result[0].linked_app_client_id is None
        assert result[0].app_id is None


# ---------------------------------------------------------------------------
# import_agent
# ---------------------------------------------------------------------------

class TestImportAgent:

    @pytest.mark.asyncio
    async def test_agent_not_found_in_okta(self):
        client = _mock_client()
        store = _mock_store()
        client.get_agent.return_value = None

        importer = OktaAgentImport(client, store)
        result = await importer.import_agent("agt_missing", "tok_admin")

        assert result.success is False
        assert "not found" in result.message

    @pytest.mark.asyncio
    async def test_creates_minimal_record(self):
        client = _mock_client()
        store = _mock_store()

        client.get_agent.return_value = _sample_okta_agent()
        client.get_linked_app.return_value = _sample_linked_app()
        client.get_agent_connections.return_value = []

        importer = OktaAgentImport(client, store)
        result = await importer.import_agent("agt_abc123", "tok_admin")

        assert result.success is True
        assert result.agent_name == "demo-ai-agent"
        assert result.okta_agent_id == "agt_abc123"

        # Verify store.create_agent was called with correct config
        store.create_agent.assert_called_once()
        call_args = store.create_agent.call_args
        agent_id = call_args[0][0]
        config = call_args[0][1]

        assert agent_id == "demo-ai-agent"
        assert config["client_id"] == "0oaClientId123"
        assert config["registration_source"] == "okta-import"
        assert config["principal_id"] == "agt_abc123"
        assert config["enabled"] is True
        # Private key is NOT auto-generated — admin pastes it via Configure dialog
        assert "private_key" not in config

    @pytest.mark.asyncio
    async def test_matches_connections_to_resources(self):
        client = _mock_client()
        store = _mock_store()

        client.get_agent.return_value = _sample_okta_agent()
        client.get_linked_app.return_value = _sample_linked_app()
        client.get_agent_connections.return_value = _sample_connections()

        importer = OktaAgentImport(client, store)
        result = await importer.import_agent("agt_abc123", "tok_admin")

        assert result.success is True
        assert "hr-system" in result.resources_linked

    @pytest.mark.asyncio
    async def test_missing_linked_app_warning(self):
        client = _mock_client()
        store = _mock_store()

        agent_data = _sample_okta_agent(app_id=None)
        client.get_agent.return_value = agent_data
        client.get_agent_connections.return_value = []

        importer = OktaAgentImport(client, store)
        result = await importer.import_agent("agt_abc123", "tok_admin")

        assert result.success is True
        assert any("No linked OIDC app" in w for w in result.warnings)

    @pytest.mark.asyncio
    async def test_staged_agent_imports_disabled(self):
        client = _mock_client()
        store = _mock_store()

        agent_data = _sample_okta_agent(status="STAGED")
        client.get_agent.return_value = agent_data
        client.get_linked_app.return_value = _sample_linked_app()
        client.get_agent_connections.return_value = []

        importer = OktaAgentImport(client, store)
        result = await importer.import_agent("agt_abc123", "tok_admin")

        assert result.success is True
        config = store.create_agent.call_args[0][1]
        assert config["enabled"] is False
        assert any("disabled" in w for w in result.warnings)

    @pytest.mark.asyncio
    async def test_duplicate_import_updates(self):
        client = _mock_client()
        store = _mock_store()

        # Simulate existing imported agent
        store.get_all_agents.return_value = [
            {
                "agent_name": "demo-ai-agent",
                "agent_id": "demo-ai-agent",
                "okta_ai_agent_id": "agt_abc123",
            }
        ]

        client.get_agent.return_value = _sample_okta_agent()
        client.get_linked_app.return_value = _sample_linked_app()
        client.get_agent_connections.return_value = _sample_connections()

        importer = OktaAgentImport(client, store)
        result = await importer.import_agent("agt_abc123", "tok_admin")

        assert result.success is True
        assert "updated" in result.message.lower()
        # Should call update_agent, not create_agent
        store.create_agent.assert_not_called()
        store.update_agent.assert_called()

    @pytest.mark.asyncio
    async def test_agent_name_override(self):
        client = _mock_client()
        store = _mock_store()

        client.get_agent.return_value = _sample_okta_agent()
        client.get_linked_app.return_value = _sample_linked_app()
        client.get_agent_connections.return_value = []

        importer = OktaAgentImport(client, store)
        result = await importer.import_agent(
            "agt_abc123", "tok_admin", agent_name_override="custom-name"
        )

        assert result.success is True
        assert result.agent_name == "custom-name"

    @pytest.mark.asyncio
    async def test_resource_mapping_override(self):
        client = _mock_client()
        store = _mock_store()

        client.get_agent.return_value = _sample_okta_agent()
        client.get_linked_app.return_value = _sample_linked_app()
        client.get_agent_connections.return_value = _sample_connections()

        importer = OktaAgentImport(client, store)
        result = await importer.import_agent(
            "agt_abc123",
            "tok_admin",
            resource_mapping={"hr-connection": "finance-system"},
        )

        assert result.success is True
        assert "finance-system" in result.resources_linked


# ---------------------------------------------------------------------------
# sync_agent
# ---------------------------------------------------------------------------

class TestSyncAgent:

    @pytest.mark.asyncio
    async def test_sync_updates_status_and_resources(self):
        client = _mock_client()
        store = _mock_store()

        store.get_all_agents.return_value = [
            {
                "agent_name": "demo-ai-agent",
                "agent_id": "demo-ai-agent",
                "okta_ai_agent_id": "agt_abc123",
            }
        ]

        client.get_agent.return_value = _sample_okta_agent()
        client.get_agent_connections.return_value = _sample_connections()

        importer = OktaAgentImport(client, store)
        result = await importer.sync_agent("agt_abc123", "tok_admin")

        assert result.success is True
        assert "synced" in result.message.lower()
        assert "hr-system" in result.resources_linked

        # Verify update was called with correct fields
        update_call = store.update_agent.call_args
        assert update_call[0][0] == "demo-ai-agent"
        config = update_call[0][1]
        assert config["enabled"] is True

    @pytest.mark.asyncio
    async def test_sync_not_found_in_store(self):
        client = _mock_client()
        store = _mock_store()

        importer = OktaAgentImport(client, store)
        result = await importer.sync_agent("agt_unknown", "tok_admin")

        assert result.success is False
        assert "not found in store" in result.message

    @pytest.mark.asyncio
    async def test_sync_not_found_in_okta(self):
        client = _mock_client()
        store = _mock_store()

        store.get_all_agents.return_value = [
            {
                "agent_name": "demo-ai-agent",
                "agent_id": "demo-ai-agent",
                "okta_ai_agent_id": "agt_abc123",
            }
        ]
        client.get_agent.return_value = None

        importer = OktaAgentImport(client, store)
        result = await importer.sync_agent("agt_abc123", "tok_admin")

        assert result.success is False
        assert "not found in Okta" in result.message

    @pytest.mark.asyncio
    async def test_sync_disabled_status(self):
        client = _mock_client()
        store = _mock_store()

        store.get_all_agents.return_value = [
            {
                "agent_name": "demo-ai-agent",
                "agent_id": "demo-ai-agent",
                "okta_ai_agent_id": "agt_abc123",
            }
        ]
        client.get_agent.return_value = _sample_okta_agent(status="DEACTIVATED")
        client.get_agent_connections.return_value = []

        importer = OktaAgentImport(client, store)
        result = await importer.sync_agent("agt_abc123", "tok_admin")

        assert result.success is True
        config = store.update_agent.call_args[0][1]
        assert config["enabled"] is False
        assert any("disabled" in w for w in result.warnings)


# ---------------------------------------------------------------------------
# sync_agent_from_event
# ---------------------------------------------------------------------------

class TestSyncAgentFromEvent:

    @pytest.mark.asyncio
    async def test_uses_service_auth(self):
        client = _mock_client()
        store = _mock_store()

        store.get_all_agents.return_value = [
            {
                "agent_name": "demo-ai-agent",
                "agent_id": "demo-ai-agent",
                "okta_ai_agent_id": "agt_abc123",
            }
        ]
        client.get_agent.return_value = _sample_okta_agent()
        client.get_agent_connections.return_value = []

        importer = OktaAgentImport(client, store)
        result = await importer.sync_agent_from_event("agt_abc123")

        assert result.success is True
        # Verify get_agent was called with no okta_token
        client.get_agent.assert_called_with("agt_abc123", None)


# ---------------------------------------------------------------------------
# bulk_import
# ---------------------------------------------------------------------------

class TestBulkImport:

    @pytest.mark.asyncio
    async def test_imports_multiple_agents(self):
        client = _mock_client()
        store = _mock_store()

        agent1 = _sample_okta_agent(agent_id="agt_1", name="Agent One")
        agent2 = _sample_okta_agent(agent_id="agt_2", name="Agent Two")

        client.get_agent.side_effect = [agent1, agent2]
        client.get_linked_app.return_value = _sample_linked_app()
        client.get_agent_connections.return_value = []

        importer = OktaAgentImport(client, store)
        results = await importer.bulk_import(["agt_1", "agt_2"], "tok_admin")

        assert len(results) == 2
        assert all(r.success for r in results)

    @pytest.mark.asyncio
    async def test_concurrency_limit(self):
        """Verify that bulk_import uses a semaphore (max 5 concurrent)."""
        client = _mock_client()
        store = _mock_store()

        concurrent_count = 0
        max_concurrent = 0

        original_get_agent = client.get_agent

        async def _tracked_get_agent(agent_id, okta_token=None):
            nonlocal concurrent_count, max_concurrent
            concurrent_count += 1
            max_concurrent = max(max_concurrent, concurrent_count)
            await asyncio.sleep(0.01)
            concurrent_count -= 1
            return _sample_okta_agent(agent_id=agent_id, name=f"Agent {agent_id}")

        client.get_agent.side_effect = _tracked_get_agent
        client.get_linked_app.return_value = _sample_linked_app()
        client.get_agent_connections.return_value = []

        importer = OktaAgentImport(client, store)
        agent_ids = [f"agt_{i}" for i in range(10)]
        results = await importer.bulk_import(agent_ids, "tok_admin")

        assert len(results) == 10
        assert max_concurrent <= 5


# ---------------------------------------------------------------------------
# slugify
# ---------------------------------------------------------------------------

class TestSlugify:

    def test_basic_slugify(self):
        store = _mock_store()
        importer = OktaAgentImport(_mock_client(), store)
        assert importer._slugify("Demo AI Agent") == "demo-ai-agent"

    def test_special_characters(self):
        store = _mock_store()
        importer = OktaAgentImport(_mock_client(), store)
        assert importer._slugify("My Agent (v2.0)!") == "my-agent-v2-0"

    def test_collision_appends_counter(self):
        store = _mock_store()
        # First call returns existing agent, second returns None
        store.get_agent.side_effect = [
            {"agent_name": "demo-ai-agent"},  # exists
            None,  # demo-ai-agent-2 doesn't exist
        ]
        importer = OktaAgentImport(_mock_client(), store)
        assert importer._slugify("Demo AI Agent") == "demo-ai-agent-2"

    def test_multiple_collisions(self):
        store = _mock_store()
        store.get_agent.side_effect = [
            {"agent_name": "agent"},  # exists
            {"agent_name": "agent-2"},  # exists
            {"agent_name": "agent-3"},  # exists
            None,  # agent-4 doesn't exist
        ]
        importer = OktaAgentImport(_mock_client(), store)
        assert importer._slugify("Agent") == "agent-4"

    def test_empty_name(self):
        store = _mock_store()
        importer = OktaAgentImport(_mock_client(), store)
        assert importer._slugify("") == "agent"
