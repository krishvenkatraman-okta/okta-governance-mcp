"""
End-to-end tests for Okta AI Agent import, sync, event hook, and service auth.

These tests exercise the full flow across multiple modules:
  - OktaAgentImport (import/sync logic)
  - okta_import_routes (Admin API endpoints)
  - okta_event_hook (Event Hook endpoint)
  - OktaServiceAuth (private_key_jwt auth)
  - OktaAIAgentClient (Okta API client)

All external calls (Okta APIs, httpx) are mocked. The tests verify that
the modules compose correctly end-to-end.
"""

import asyncio
import json
import os
import time
from dataclasses import asdict
from unittest.mock import AsyncMock, MagicMock, patch, call

import pytest
from starlette.applications import Starlette
from starlette.routing import Route
from starlette.testclient import TestClient

from okta_agent_proxy.auth.okta_agent_import import (
    ImportableAgent,
    ImportResult,
    OktaAgentImport,
)
from okta_agent_proxy.auth.okta_service_auth import OktaServiceAuth
from okta_agent_proxy.admin.okta_import_routes import (
    list_importable_agents,
    import_agent,
    sync_agent as sync_agent_route,
    sync_all_agents,
    sync_all_resources,
    sync_all,
    bulk_import_agents,
    get_agent_detail,
)
from okta_agent_proxy.admin.okta_event_hook import (
    okta_event_hook_verify,
    okta_event_hook_receive,
)


# ===========================================================================
# Shared helpers
# ===========================================================================

def _reset_all_singletons():
    """Reset singletons in both route modules."""
    import okta_agent_proxy.admin.okta_import_routes as ir
    import okta_agent_proxy.admin.okta_event_hook as eh
    ir._service_auth = ir._client = ir._importer = None
    eh._service_auth = eh._client = eh._importer = None


def _okta_headers(token="okta-test-token-xyz"):
    return {"Authorization": f"Bearer {token}"}


def _event_hook_headers(secret="e2e-hook-secret"):
    return {"Authorization": secret}


# Sample Okta API responses
def _okta_agent(agent_id="agt_1", name="Demo Agent", status="ACTIVE", app_id="0oa_app1"):
    return {"id": agent_id, "name": name, "description": f"Desc for {name}",
            "status": status, "appId": app_id}


def _okta_linked_app(client_id="client_abc"):
    return {"id": "0oa_app1", "label": "Agent App",
            "credentials": {"oauthClient": {"client_id": client_id}}}


def _okta_connections(auth_server_ids=None):
    """Generate IDENTITY_ASSERTION_CUSTOM_AS connections (production API shape)."""
    if auth_server_ids is None:
        auth_server_ids = ["aus123hr"]
    conns = []
    for i, asid in enumerate(auth_server_ids):
        conns.append({
            "name": f"conn-{i}",
            "connectionType": "IDENTITY_ASSERTION_CUSTOM_AS",
            "status": "ACTIVE",
            "authorizationServer": {
                "orn": f"orn:okta:idp:00o:authorization_servers:{asid}",
            },
            "resourceIndicator": f"orn:okta:idp:00o:authorization_servers:{asid}",
            "scopes": ["mcp:read"],
        })
    return conns


def _make_store(agents=None, resources=None):
    """Create a mock store with optional pre-loaded data."""
    store = MagicMock()

    _agents = list(agents or [])
    _resources = list(resources or [])

    def get_all_agents(enabled_only=True):
        if enabled_only:
            return [a for a in _agents if a.get("enabled", True)]
        return list(_agents)

    def get_agent(agent_id, enabled_only=True):
        for a in _agents:
            if a.get("agent_id") == agent_id or a.get("agent_name") == agent_id:
                if enabled_only and not a.get("enabled", True):
                    return None
                return a
        return None

    def create_agent(agent_id, config, user=None):
        record = {"agent_id": agent_id, "agent_name": agent_id, **config}
        _agents.append(record)
        return True

    def update_agent(agent_id, config, user=None):
        for a in _agents:
            if a.get("agent_id") == agent_id or a.get("agent_name") == agent_id:
                a.update(config)
                return True
        return False

    def get_all_resources():
        return list(_resources)

    def update_resource(name, config, user=None):
        for b in _resources:
            if b.get("name") == name:
                b.update(config)
                return True
        return False

    store.get_all_agents = MagicMock(side_effect=get_all_agents)
    store.get_agent = MagicMock(side_effect=get_agent)
    store.create_agent = MagicMock(side_effect=create_agent)
    store.update_agent = MagicMock(side_effect=update_agent)
    store.get_all_resources = MagicMock(side_effect=get_all_resources)
    store.update_resource = MagicMock(side_effect=update_resource)

    # Expose internal lists for assertions
    store._agents = _agents
    store._resources = _resources

    return store


def _make_client():
    """Create a mock OktaAIAgentClient with sensible defaults."""
    client = AsyncMock()
    client.list_agents.return_value = []
    client.get_agent.return_value = None
    client.get_agent_connections.return_value = []
    client.get_linked_app.return_value = None
    client.check_token_scopes.return_value = {"has_ai_agent_scopes": True}
    return client


def _build_full_app(store, client, importer, env_overrides=None,
                    hook_secret="e2e-hook-secret"):
    """Build a Starlette app with both import routes and event hook routes."""
    env = {
        "OKTA_DOMAIN": "dev-e2e.okta.com",
        "OKTA_AI_AGENT_ID": "agt_adapter",
        "OKTA_EVENT_HOOK_SECRET": hook_secret,
    }
    if env_overrides:
        env.update(env_overrides)

    routes = [
        # Import routes (admin auth)
        Route("/api/admin/okta/agents/bulk-import", bulk_import_agents, methods=["POST"]),
        Route("/api/admin/okta/sync/agents", sync_all_agents, methods=["POST"]),
        Route("/api/admin/okta/sync/resources", sync_all_resources, methods=["POST"]),
        Route("/api/admin/okta/sync/all", sync_all, methods=["POST"]),
        Route("/api/admin/okta/agents/{okta_agent_id}/import", import_agent, methods=["POST"]),
        Route("/api/admin/okta/agents/{okta_agent_id}/sync", sync_agent_route, methods=["POST"]),
        Route("/api/admin/okta/agents/{okta_agent_id}", get_agent_detail, methods=["GET"]),
        Route("/api/admin/okta/agents", list_importable_agents, methods=["GET"]),
        # Event hook routes (shared key auth)
        Route("/api/hooks/okta/events", okta_event_hook_verify, methods=["GET"]),
        Route("/api/hooks/okta/events", okta_event_hook_receive, methods=["POST"]),
    ]

    app = Starlette(routes=routes)

    patches = [
        patch("okta_agent_proxy.admin.okta_import_routes._get_client", return_value=client),
        patch("okta_agent_proxy.admin.okta_import_routes._get_importer", return_value=importer),
        patch("okta_agent_proxy.admin.okta_import_routes.get_store", return_value=store),
        patch("okta_agent_proxy.admin.okta_event_hook._get_import_service", return_value=importer),
        patch.dict(os.environ, env, clear=False),
        # Admin auth bypass: accept Bearer tokens as okta_oauth
        patch(
            "okta_agent_proxy.admin.middleware.verify_okta_token",
            new_callable=AsyncMock,
            return_value={
                "username": "admin@example.com",
                "role": "admin",
                "token_type": "okta_oauth",
            },
        ),
    ]

    for p in patches:
        p.start()

    return TestClient(app), patches


def _stop(patches):
    for p in patches:
        p.stop()


# ===========================================================================
# Fixtures
# ===========================================================================

@pytest.fixture(autouse=True)
def _reset():
    _reset_all_singletons()
    yield
    _reset_all_singletons()


# ===========================================================================
# Test 1: Full Import Lifecycle
# ===========================================================================

class TestFullImportLifecycle:
    """3 mock agents: ACTIVE+connections, STAGED, ACTIVE+no-app.
    List → import → verify records."""

    def _setup(self):
        resources = [
            {"name": "hr-system", "auth_method": "okta-cross-app",
             "auth_config": {"target_authorization_server": "https://dev-e2e.okta.com/oauth2/aus123hr"},
             "enabled": True},
        ]
        store = _make_store(resources=resources)
        client = _make_client()

        # 3 agents in Okta
        agents = [
            _okta_agent("agt_active", "Active Agent", "ACTIVE", "0oa_app1"),
            _okta_agent("agt_staged", "Staged Agent", "STAGED", "0oa_app2"),
            _okta_agent("agt_noapp", "No App Agent", "ACTIVE", None),
        ]
        client.list_agents.return_value = agents

        # get_agent returns by ID
        async def _get_agent(agent_id, okta_token=None):
            for a in agents:
                if a["id"] == agent_id:
                    return a
            return None
        client.get_agent = AsyncMock(side_effect=_get_agent)

        # connections: active has hr-system match
        async def _get_connections(agent_id, okta_token=None):
            if agent_id == "agt_active":
                return _okta_connections(["aus123hr"])
            return []
        client.get_agent_connections = AsyncMock(side_effect=_get_connections)

        # linked app: only for agt_active and agt_staged
        async def _get_linked_app(app_id, okta_token=None):
            if app_id == "0oa_app1":
                return _okta_linked_app("client_active")
            if app_id == "0oa_app2":
                return _okta_linked_app("client_staged")
            return None
        client.get_linked_app = AsyncMock(side_effect=_get_linked_app)

        importer = OktaAgentImport(client, store)
        return store, client, importer

    @pytest.mark.asyncio
    async def test_list_then_import_all(self):
        store, client, importer = self._setup()

        # List
        importable = await importer.list_importable_agents("tok_admin")
        assert len(importable) == 3
        assert all(not a.already_imported for a in importable)

        # Find specific agents
        active = next(a for a in importable if a.okta_agent_id == "agt_active")
        staged = next(a for a in importable if a.okta_agent_id == "agt_staged")
        noapp = next(a for a in importable if a.okta_agent_id == "agt_noapp")

        assert active.connections_count == 1
        assert active.linked_app_client_id == "client_active"
        assert staged.status == "STAGED"
        assert noapp.linked_app_client_id is None

        # Import active agent
        r1 = await importer.import_agent("agt_active", "tok_admin")
        assert r1.success is True
        assert "hr-system" in r1.resources_linked
        assert any("Private key not set" in w for w in r1.warnings)

        # Import staged agent — should be disabled
        r2 = await importer.import_agent("agt_staged", "tok_admin")
        assert r2.success is True
        staged_record = next(
            a for a in store._agents if a.get("okta_ai_agent_id") == "agt_staged"
            or a.get("principal_id") == "agt_staged"
        )
        assert staged_record["enabled"] is False
        assert any("disabled" in w for w in r2.warnings)

        # Import no-app agent — should warn about missing OIDC app
        r3 = await importer.import_agent("agt_noapp", "tok_admin")
        assert r3.success is True
        assert any("No linked OIDC app" in w for w in r3.warnings)

        # Verify list now shows already_imported
        importable2 = await importer.list_importable_agents("tok_admin")
        imported_ids = {a.okta_agent_id for a in importable2 if a.already_imported}
        assert "agt_active" in imported_ids
        assert "agt_staged" in imported_ids
        assert "agt_noapp" in imported_ids


# ===========================================================================
# Test 2: Token Forwarding
# ===========================================================================

class TestTokenForwarding:
    """Verify okta_token is forwarded to Okta API calls."""

    @pytest.mark.asyncio
    async def test_import_forwards_okta_token(self):
        store = _make_store()
        client = _make_client()
        client.get_agent.return_value = _okta_agent()
        client.get_linked_app.return_value = _okta_linked_app()
        client.get_agent_connections.return_value = []

        importer = OktaAgentImport(client, store)
        await importer.import_agent("agt_1", "tok_user_abc")

        # get_agent called with forwarded token
        client.get_agent.assert_called_with("agt_1", "tok_user_abc")
        client.get_linked_app.assert_called_with("0oa_app1", "tok_user_abc")

    @pytest.mark.asyncio
    async def test_sync_from_event_uses_no_token(self):
        store = _make_store(agents=[
            {"agent_id": "demo", "agent_name": "demo",
             "okta_ai_agent_id": "agt_1", "enabled": True},
        ])
        client = _make_client()
        client.get_agent.return_value = _okta_agent()
        client.get_agent_connections.return_value = []

        importer = OktaAgentImport(client, store)
        result = await importer.sync_agent_from_event("agt_1")

        assert result.success is True
        # Called with None (service auth, not user token)
        client.get_agent.assert_called_with("agt_1", None)


# ===========================================================================
# Test 3: Manual Sync — Single Agent
# ===========================================================================

class TestManualSyncSingleAgent:
    """Import, then sync through status change and new connection."""

    @pytest.mark.asyncio
    async def test_sync_status_change_and_new_connection(self):
        resources = [
            {"name": "hr-system", "auth_method": "okta-cross-app",
             "auth_config": {"target_authorization_server": "https://dev.okta.com/oauth2/aus123hr"},
             "enabled": True},
            {"name": "finance-system", "auth_method": "okta-cross-app",
             "auth_config": {"target_authorization_server": "https://dev.okta.com/oauth2/aus456fin"},
             "enabled": True},
        ]
        store = _make_store(resources=resources)
        client = _make_client()

        # Initial state: ACTIVE, hr connection
        client.get_agent.return_value = _okta_agent(status="ACTIVE")
        client.get_linked_app.return_value = _okta_linked_app()
        client.get_agent_connections.return_value = _okta_connections(["aus123hr"])

        importer = OktaAgentImport(client, store)

        # Import
        r = await importer.import_agent("agt_1", "tok")
        assert r.success is True
        assert "hr-system" in r.resources_linked

        # Change to DEACTIVATED
        client.get_agent.return_value = _okta_agent(status="DEACTIVATED")
        client.get_agent_connections.return_value = _okta_connections(["aus123hr"])

        r2 = await importer.sync_agent("agt_1", "tok")
        assert r2.success is True
        agent = next(a for a in store._agents if a.get("okta_ai_agent_id") == "agt_1")
        assert agent["enabled"] is False
        assert any("disabled" in w for w in r2.warnings)

        # Add finance connection, reactivate
        client.get_agent.return_value = _okta_agent(status="ACTIVE")
        client.get_agent_connections.return_value = _okta_connections(["aus123hr", "aus456fin"])

        r3 = await importer.sync_agent("agt_1", "tok")
        assert r3.success is True
        agent = next(a for a in store._agents if a.get("okta_ai_agent_id") == "agt_1")
        assert agent["enabled"] is True
        assert "hr-system" in r3.resources_linked
        assert "finance-system" in r3.resources_linked


# ===========================================================================
# Test 4: Manual Sync — All Agents
# ===========================================================================

class TestManualSyncAllAgents:
    """Import 2 agents, change one, sync all via admin route."""

    def test_sync_all_agents_only_updates_changed(self):
        store = _make_store(resources=[
            {"name": "hr-system", "auth_method": "okta-cross-app",
             "auth_config": {"target_authorization_server": "https://dev.okta.com/oauth2/aus123hr"},
             "enabled": True},
        ])
        client = _make_client()
        client.check_token_scopes.return_value = {"has_ai_agent_scopes": True}

        # Pre-populate store with 2 imported agents
        store._agents.extend([
            {"agent_id": "agent-one", "agent_name": "agent-one",
             "registration_source": "okta-import", "okta_ai_agent_id": "agt_1",
             "enabled": True, "resource_access": ["hr-system"]},
            {"agent_id": "agent-two", "agent_name": "agent-two",
             "registration_source": "okta-import", "okta_ai_agent_id": "agt_2",
             "enabled": True, "resource_access": ["hr-system"]},
            {"agent_id": "manual-agent", "agent_name": "manual-agent",
             "registration_source": "manual", "okta_ai_agent_id": None,
             "enabled": True, "resource_access": ["hr-system"]},
        ])

        # agt_1: still active, agt_2: now deactivated
        async def _get_agent(agent_id, okta_token=None):
            if agent_id == "agt_1":
                return _okta_agent("agt_1", status="ACTIVE")
            if agent_id == "agt_2":
                return _okta_agent("agt_2", status="DEACTIVATED")
            return None
        client.get_agent = AsyncMock(side_effect=_get_agent)

        async def _get_connections(agent_id, okta_token=None):
            if agent_id == "agt_1":
                return _okta_connections(["aus123hr"])
            return []
        client.get_agent_connections = AsyncMock(side_effect=_get_connections)

        importer = OktaAgentImport(client, store)

        tc, patches = _build_full_app(store, client, importer)
        try:
            resp = tc.post("/api/admin/okta/sync/agents", headers=_okta_headers())
            assert resp.status_code == 200
            data = resp.json()

            # 2 okta-import agents synced (manual-agent skipped)
            assert data["synced"] + data["failed"] == 2
            assert data["synced"] == 2  # both "succeed" even if status changes

            # Verify agent-two is now disabled
            agent_two = next(a for a in store._agents if a["agent_id"] == "agent-two")
            assert agent_two["enabled"] is False

            # manual-agent unchanged
            manual = next(a for a in store._agents if a["agent_id"] == "manual-agent")
            assert manual["enabled"] is True
        finally:
            _stop(patches)


# ===========================================================================
# Test 5: Manual Sync — Resources
# ===========================================================================

class TestManualSyncResources:
    """Sync Managed Connection scopes to resources via admin route."""

    def test_sync_resources_updates_scopes(self):
        resources = [
            {"name": "hr-system", "auth_method": "okta-cross-app",
             "auth_config": {"target_authorization_server": "https://dev.okta.com/oauth2/aus123hr"},
             "enabled": True},
            {"name": "finance-system", "auth_method": "okta-cross-app",
             "auth_config": {"target_authorization_server": "https://dev.okta.com/oauth2/aus456fin"},
             "enabled": True},
        ]
        store = _make_store(resources=resources)
        client = _make_client()
        client.check_token_scopes.return_value = {"has_ai_agent_scopes": True}

        # Adapter's connections from Okta (production API shape)
        client.get_agent_connections.return_value = [
            {"name": "hr-conn", "connectionType": "IDENTITY_ASSERTION_CUSTOM_AS",
             "status": "ACTIVE",
             "authorizationServer": {"orn": "orn:okta:idp:00o:authorization_servers:aus123hr"},
             "resourceIndicator": "orn:okta:idp:00o:authorization_servers:aus123hr",
             "scopes": ["mcp:read", "mcp:write"]},
            {"name": "fin-conn", "connectionType": "IDENTITY_ASSERTION_CUSTOM_AS",
             "status": "ACTIVE",
             "authorizationServer": {"orn": "orn:okta:idp:00o:authorization_servers:aus456fin"},
             "resourceIndicator": "orn:okta:idp:00o:authorization_servers:aus456fin",
             "scopes": ["finance:read"]},
        ]

        importer = OktaAgentImport(client, store)
        tc, patches = _build_full_app(store, client, importer)
        try:
            resp = tc.post("/api/admin/okta/sync/resources", headers=_okta_headers())
            assert resp.status_code == 200
            data = resp.json()

            assert "hr-system" in data["resources_updated"]
            assert "finance-system" in data["resources_updated"]

            # Verify scopes were written
            hr = next(b for b in store._resources if b["name"] == "hr-system")
            scopes = json.loads(hr["managed_connection_scopes"])
            assert "mcp:read" in scopes
            assert "mcp:write" in scopes

            fin = next(b for b in store._resources if b["name"] == "finance-system")
            fin_scopes = json.loads(fin["managed_connection_scopes"])
            assert "finance:read" in fin_scopes
        finally:
            _stop(patches)


# ===========================================================================
# Test 6: Event Hook Sync
# ===========================================================================

class TestEventHookSync:
    """Event hook triggers agent sync without admin auth."""

    def test_deactivation_event_disables_agent(self):
        store = _make_store(agents=[
            {"agent_id": "demo-agent", "agent_name": "demo-agent",
             "okta_ai_agent_id": "agt_1", "enabled": True,
             "registration_source": "okta-import", "resource_access": ["hr-system"]},
        ], resources=[
            {"name": "hr-system", "auth_method": "okta-cross-app",
             "auth_config": {"target_authorization_server": "https://dev.okta.com/oauth2/aus123hr"},
             "enabled": True},
        ])
        client = _make_client()

        # Okta now returns DEACTIVATED
        client.get_agent.return_value = _okta_agent("agt_1", status="DEACTIVATED")
        client.get_agent_connections.return_value = []

        importer = OktaAgentImport(client, store)
        tc, patches = _build_full_app(store, client, importer)
        try:
            # Send deactivation event
            payload = {
                "data": {
                    "events": [{
                        "uuid": "evt-1",
                        "eventType": "ai_agent.lifecycle.deactivate",
                        "target": [{"id": "agt_1", "type": "AI_AGENT"}],
                    }]
                }
            }
            resp = tc.post("/api/hooks/okta/events",
                          json=payload, headers=_event_hook_headers())
            assert resp.status_code == 200
            assert resp.json()["processed"] == 1

            # Agent should now be disabled
            agent = next(a for a in store._agents if a["agent_id"] == "demo-agent")
            assert agent["enabled"] is False
        finally:
            _stop(patches)

    def test_connection_update_refreshes_resource_access(self):
        store = _make_store(agents=[
            {"agent_id": "demo-agent", "agent_name": "demo-agent",
             "okta_ai_agent_id": "agt_1", "enabled": True,
             "registration_source": "okta-import", "resource_access": ["hr-system"]},
        ], resources=[
            {"name": "hr-system", "auth_method": "okta-cross-app",
             "auth_config": {"target_authorization_server": "https://dev.okta.com/oauth2/aus123hr"},
             "enabled": True},
            {"name": "finance-system", "auth_method": "okta-cross-app",
             "auth_config": {"target_authorization_server": "https://dev.okta.com/oauth2/aus456fin"},
             "enabled": True},
        ])
        client = _make_client()

        # Okta returns active with new finance connection
        client.get_agent.return_value = _okta_agent("agt_1", status="ACTIVE")
        client.get_agent_connections.return_value = _okta_connections(["aus123hr", "aus456fin"])

        importer = OktaAgentImport(client, store)
        tc, patches = _build_full_app(store, client, importer)
        try:
            payload = {
                "data": {
                    "events": [{
                        "uuid": "evt-2",
                        "eventType": "ai_agent.connection.update",
                        "target": [{"id": "agt_1", "type": "AI_AGENT"}],
                    }]
                }
            }
            resp = tc.post("/api/hooks/okta/events",
                          json=payload, headers=_event_hook_headers())
            assert resp.status_code == 200

            # Sync completed (enabled status updated, resources resolved by syncer)
            assert resp.status_code == 200
        finally:
            _stop(patches)


# ===========================================================================
# Test 7: Event Hook Simulator Script
# ===========================================================================

class TestEventHookSimulator:
    """Test using the same payload structure as simulate_okta_event_hook.py."""

    def test_verification_handshake(self):
        store = _make_store()
        client = _make_client()
        importer = OktaAgentImport(client, store)
        tc, patches = _build_full_app(store, client, importer)
        try:
            resp = tc.get("/api/hooks/okta/events",
                         headers={"x-okta-verification-challenge": "sim-challenge-123"})
            assert resp.status_code == 200
            assert resp.json()["verification"] == "sim-challenge-123"
        finally:
            _stop(patches)

    def test_simulated_deactivation_event(self):
        store = _make_store(agents=[
            {"agent_id": "demo-agent", "agent_name": "demo-agent",
             "okta_ai_agent_id": "agt_sim", "enabled": True,
             "registration_source": "okta-import"},
        ])
        client = _make_client()
        client.get_agent.return_value = _okta_agent("agt_sim", status="DEACTIVATED")
        client.get_agent_connections.return_value = []

        importer = OktaAgentImport(client, store)
        tc, patches = _build_full_app(store, client, importer)
        try:
            # Payload matching simulate_okta_event_hook.py build_event_payload()
            payload = {
                "data": {
                    "events": [{
                        "uuid": "sim-20260313120000",
                        "published": "2026-03-13T12:00:00+00:00",
                        "eventType": "ai_agent.lifecycle.deactivate",
                        "displayMessage": "Simulated agent.deactivate event for agt_sim",
                        "actor": {"id": "00u_simulator", "type": "User",
                                 "displayName": "Event Hook Simulator"},
                        "target": [{
                            "id": "agt_sim", "type": "AI_AGENT",
                            "alternateId": "simulated-agt_sim",
                            "displayName": "Agent agt_sim",
                        }],
                    }]
                }
            }
            resp = tc.post("/api/hooks/okta/events",
                          json=payload, headers=_event_hook_headers())
            assert resp.status_code == 200
            assert resp.json()["processed"] == 1

            agent = next(a for a in store._agents if a["agent_id"] == "demo-agent")
            assert agent["enabled"] is False
        finally:
            _stop(patches)

    def test_wrong_secret_returns_401(self):
        store = _make_store()
        client = _make_client()
        importer = OktaAgentImport(client, store)
        tc, patches = _build_full_app(store, client, importer)
        try:
            payload = {
                "data": {"events": [{
                    "eventType": "ai_agent.lifecycle.activate",
                    "target": [{"id": "agt_x", "type": "AI_AGENT"}],
                }]}
            }
            resp = tc.post("/api/hooks/okta/events",
                          json=payload, headers={"Authorization": "wrong-secret"})
            assert resp.status_code == 401
        finally:
            _stop(patches)


# ===========================================================================
# Test 8: Connection-to-Resource Matching
# ===========================================================================

class TestConnectionToResourceMatching:
    """IDENTITY_ASSERTION_CUSTOM_AS connections matched by authorizationServerId."""

    @pytest.mark.asyncio
    async def test_matching_and_unmatched_connections(self):
        resources = [
            {"name": "hr-system", "auth_method": "okta-cross-app",
             "auth_config": {"target_authorization_server": "https://dev.okta.com/oauth2/aus_hr"},
             "enabled": True},
            {"name": "deploy-server", "auth_method": "okta-cross-app",
             "auth_config": {"target_authorization_server": "https://dev.okta.com/oauth2/aus_deploy"},
             "enabled": True},
        ]
        store = _make_store(resources=resources)
        client = _make_client()

        # 3 connections: 2 match, 1 doesn't
        client.get_agent.return_value = _okta_agent()
        client.get_linked_app.return_value = _okta_linked_app()
        client.get_agent_connections.return_value = [
            {"name": "hr-conn", "connectionType": "IDENTITY_ASSERTION_CUSTOM_AS",
             "status": "ACTIVE",
             "authorizationServer": {"orn": "orn:okta:idp:00o:authorization_servers:aus_hr"},
             "resourceIndicator": "orn:okta:idp:00o:authorization_servers:aus_hr"},
            {"name": "deploy-conn", "connectionType": "IDENTITY_ASSERTION_CUSTOM_AS",
             "status": "ACTIVE",
             "authorizationServer": {"orn": "orn:okta:idp:00o:authorization_servers:aus_deploy"},
             "resourceIndicator": "orn:okta:idp:00o:authorization_servers:aus_deploy"},
            {"name": "unknown-conn", "connectionType": "IDENTITY_ASSERTION_CUSTOM_AS",
             "status": "ACTIVE",
             "authorizationServer": {"orn": "orn:okta:idp:00o:authorization_servers:aus_unknown"},
             "resourceIndicator": "orn:okta:idp:00o:authorization_servers:aus_unknown"},
            {"name": "secret-conn", "connectionType": "STS_VAULT_SECRET",
             "status": "ACTIVE",
             "secret": {"orn": "orn:okta:pam:00o:secrets:secret-uuid"}},
        ]

        importer = OktaAgentImport(client, store)
        result = await importer.import_agent("agt_1", "tok")

        assert result.success is True
        assert "hr-system" in result.resources_linked
        assert "deploy-server" in result.resources_linked
        assert len(result.resources_linked) == 2  # unknown-conn and SECRET not matched

    @pytest.mark.asyncio
    async def test_resource_mapping_override(self):
        """Explicit mapping overrides auto-match."""
        resources = [
            {"name": "hr-system", "auth_method": "okta-cross-app",
             "auth_config": {"target_authorization_server": "https://dev.okta.com/oauth2/aus_hr"},
             "enabled": True},
            {"name": "custom-backend", "auth_method": "okta-cross-app",
             "auth_config": {"target_authorization_server": "https://dev.okta.com/oauth2/aus_custom"},
             "enabled": True},
        ]
        store = _make_store(resources=resources)
        client = _make_client()
        client.get_agent.return_value = _okta_agent()
        client.get_linked_app.return_value = _okta_linked_app()
        client.get_agent_connections.return_value = [
            {"name": "hr-conn", "connectionType": "IDENTITY_ASSERTION_CUSTOM_AS",
             "status": "ACTIVE",
             "authorizationServer": {"orn": "orn:okta:idp:00o:authorization_servers:aus_hr"},
             "resourceIndicator": "orn:okta:idp:00o:authorization_servers:aus_hr"},
        ]

        importer = OktaAgentImport(client, store)
        result = await importer.import_agent(
            "agt_1", "tok",
            resource_mapping={"hr-conn": "custom-backend"},
        )

        assert result.success is True
        assert "custom-backend" in result.resources_linked
        assert "hr-system" not in result.resources_linked


# ===========================================================================
# Test 9: Admin API Auth
# ===========================================================================

class TestAdminAPIAuth:
    """Test auth requirements for import routes."""

    def test_okta_oauth_token_accepted(self):
        store = _make_store()
        client = _make_client()
        client.check_token_scopes.return_value = {"has_ai_agent_scopes": True}
        importer = AsyncMock()
        importer.list_importable_agents.return_value = []

        tc, patches = _build_full_app(store, client, importer)
        try:
            resp = tc.get("/api/admin/okta/agents", headers=_okta_headers())
            assert resp.status_code == 200
        finally:
            _stop(patches)

    # test_legacy_jwt_rejected was removed in v0.15.x — the legacy username/password
    # JWT auth path no longer exists, so this scenario is unreachable.

    def test_no_token_rejected(self):
        """No auth token gets 401."""
        store = _make_store()
        client = _make_client()
        importer = AsyncMock()

        env = {
            "OKTA_AI_AGENT_ENABLED": "true",
            "OKTA_DOMAIN": "dev-e2e.okta.com",
        }
        app = Starlette(routes=[
            Route("/api/admin/okta/agents", list_importable_agents, methods=["GET"]),
        ])

        with patch("okta_agent_proxy.admin.middleware.verify_okta_token",
                    new_callable=AsyncMock, return_value=None), \
             patch("okta_agent_proxy.admin.okta_import_routes._get_client",
                    return_value=client), \
             patch("okta_agent_proxy.admin.okta_import_routes._get_importer",
                    return_value=importer), \
             patch("okta_agent_proxy.admin.okta_import_routes.get_store",
                    return_value=store), \
             patch.dict(os.environ, env, clear=False):

            tc = TestClient(app)
            resp = tc.get("/api/admin/okta/agents")
            assert resp.status_code == 401


# ===========================================================================
# Test 10: Service App Auth
# ===========================================================================

class TestServiceAppAuth:
    """OktaServiceAuth JWT assertion, caching, and refresh."""

    @pytest.mark.asyncio
    async def test_jwt_assertion_generation(self):
        """Service auth generates a valid JWT assertion."""
        from jose import jwt as jose_jwt

        # Generate a test RSA key
        from okta_agent_proxy.auth.adapter_cimd import _generate_rsa_keypair
        test_key = _generate_rsa_keypair()

        with patch.dict(os.environ, {
            "OKTA_SERVICE_CLIENT_ID": "0oa_service_test",
            "OKTA_DOMAIN": "dev-test.okta.com",
            "ADAPTER_SIGNING_KEY": json.dumps(test_key),
        }):
            auth = OktaServiceAuth()
            assertion = auth._generate_jwt_assertion(["okta.aiAgents.read"])

            assert assertion is not None
            # Decode without verification to check claims
            claims = jose_jwt.get_unverified_claims(assertion)
            assert claims["iss"] == "0oa_service_test"
            assert claims["sub"] == "0oa_service_test"
            assert claims["aud"] == "https://dev-test.okta.com/oauth2/v1/token"
            assert "jti" in claims
            assert claims["exp"] > claims["iat"]

    @pytest.mark.asyncio
    async def test_token_caching(self):
        """Second call returns cached token without HTTP request."""
        from okta_agent_proxy.auth.adapter_cimd import _generate_rsa_keypair
        test_key = _generate_rsa_keypair()

        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            "access_token": "cached_tok_123",
            "token_type": "Bearer",
            "expires_in": 3600,
        }

        with patch.dict(os.environ, {
            "OKTA_SERVICE_CLIENT_ID": "0oa_test",
            "OKTA_DOMAIN": "dev-test.okta.com",
            "ADAPTER_SIGNING_KEY": json.dumps(test_key),
        }):
            auth = OktaServiceAuth()

            with patch("httpx.AsyncClient") as mock_client_cls:
                mock_client = AsyncMock()
                mock_client.post.return_value = mock_response
                mock_client.__aenter__ = AsyncMock(return_value=mock_client)
                mock_client.__aexit__ = AsyncMock(return_value=False)
                mock_client_cls.return_value = mock_client

                # First call — HTTP request
                token1 = await auth.get_access_token()
                assert token1 == "cached_tok_123"
                assert mock_client.post.call_count == 1

                # Second call — cached (no new HTTP request)
                token2 = await auth.get_access_token()
                assert token2 == "cached_tok_123"
                assert mock_client.post.call_count == 1  # still 1

    @pytest.mark.asyncio
    async def test_token_refresh_on_expiry(self):
        """Expired cached token triggers new request."""
        from okta_agent_proxy.auth.adapter_cimd import _generate_rsa_keypair
        test_key = _generate_rsa_keypair()

        with patch.dict(os.environ, {
            "OKTA_SERVICE_CLIENT_ID": "0oa_test",
            "OKTA_DOMAIN": "dev-test.okta.com",
            "ADAPTER_SIGNING_KEY": json.dumps(test_key),
        }):
            auth = OktaServiceAuth()
            # Simulate expired cache
            auth._cached_token = "old_token"
            auth._token_expiry = time.time() - 10  # already expired

            mock_response = MagicMock()
            mock_response.status_code = 200
            mock_response.json.return_value = {
                "access_token": "new_fresh_token",
                "token_type": "Bearer",
                "expires_in": 3600,
            }

            with patch("httpx.AsyncClient") as mock_client_cls:
                mock_client = AsyncMock()
                mock_client.post.return_value = mock_response
                mock_client.__aenter__ = AsyncMock(return_value=mock_client)
                mock_client.__aexit__ = AsyncMock(return_value=False)
                mock_client_cls.return_value = mock_client

                token = await auth.get_access_token()
                assert token == "new_fresh_token"
                mock_client.post.assert_called_once()
