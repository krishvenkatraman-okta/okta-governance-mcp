"""
Tests for path-scoped 401 WWW-Authenticate headers and RFC 8707 resource URLs.

Validates:
- mcp_proxy returns WWW-Authenticate header on 401 with path-scoped metadata URL
- oauth_protected_resource_by_name returns resource as a full URL
"""

import json
import pytest
from unittest.mock import AsyncMock, MagicMock

from starlette.applications import Starlette
from starlette.routing import Route
from starlette.responses import JSONResponse
from starlette.requests import Request
from starlette.testclient import TestClient


# ---------------------------------------------------------------------------
# Helpers — inline handlers that replicate the app.py logic under test
# ---------------------------------------------------------------------------

GATEWAY_BASE_URL = "https://gateway.example.com"


def _build_mcp_proxy_app(proxy_handler_mock):
    """Build a Starlette app with the mcp_proxy handler logic."""
    config_mock = MagicMock()
    config_mock.gateway.gateway_base_url = GATEWAY_BASE_URL

    async def mcp_proxy(request: Request):
        body = await request.json()
        method = body.get("method")
        params = body.get("params")
        request_id = body.get("id")
        auth_header = request.headers.get("authorization")
        request_path = request.url.path

        result = await proxy_handler_mock.proxy_request(
            request_path=request_path,
            method=method,
            params=params,
            auth_header=auth_header,
            request_id=request_id,
            headers=dict(request.headers),
        )

        response = {"jsonrpc": "2.0", "id": request_id}

        if isinstance(result, dict) and "error" in result:
            error_type = result.get("error")
            http_status = 500
            extra_headers = {}

            if error_type == "unauthorized":
                http_status = 401
                try:
                    path_segment = request_path.lstrip("/")
                    if path_segment:
                        gateway_base = config_mock.gateway.gateway_base_url.rstrip("/")
                        metadata_url = (
                            f"{gateway_base}/.well-known"
                            f"/oauth-protected-resource/{path_segment}"
                        )
                        extra_headers["WWW-Authenticate"] = (
                            f'Bearer resource_metadata="{metadata_url}", '
                            f'error="invalid_token", '
                            f'error_description="Authentication required'
                            f' for {request_path}"'
                        )
                except Exception:
                    pass
            elif error_type in ["forbidden", "authorization_denied"]:
                http_status = 403
            elif error_type == "not_found":
                http_status = 404

            response["error"] = {
                "code": -32000 - http_status,
                "message": result.get("message", "Unknown error"),
                "data": result.get("data", error_type),
            }
            return JSONResponse(response, status_code=http_status, headers=extra_headers)

        response["result"] = result
        return JSONResponse(response)

    return Starlette(routes=[
        Route("/{path:path}", mcp_proxy, methods=["POST"]),
    ])


def _build_metadata_app(router_mock, store_mock):
    """Build a Starlette app with the oauth_protected_resource_by_name logic."""
    config_mock = MagicMock()
    config_mock.gateway.gateway_base_url = GATEWAY_BASE_URL
    config_mock.gateway.okta_domain = "dev-test.okta.com"

    async def oauth_protected_resource_by_name(request: Request):
        import os
        path_segment = request.path_params.get("resource")
        request_path = f"/{path_segment}"

        okta_issuer = f"https://{config_mock.gateway.okta_domain}"
        metadata = {
            "authorization_servers": [okta_issuer],
            "scopes_supported": ["openid", "offline_access"],
            "bearer_methods_supported": ["header"],
        }

        try:
            resource_name = router_mock.get_resource_for_path(request_path)
            if not resource_name:
                return JSONResponse(
                    {"error": "invalid_resource"},
                    status_code=404,
                )

            resource_config = store_mock.get_resource(resource_name)
            if resource_config:
                gateway_base = config_mock.gateway.gateway_base_url.rstrip("/")
                metadata["resource"] = f"{gateway_base}{request_path}"
                metadata["resource_documentation"] = f"{gateway_base}{request_path}"
            else:
                return JSONResponse(
                    {"error": "invalid_resource"},
                    status_code=404,
                )
        except Exception:
            return JSONResponse(
                {"error": "server_error"},
                status_code=500,
            )

        return JSONResponse(metadata)

    return Starlette(routes=[
        Route(
            "/.well-known/oauth-protected-resource/{resource:path}",
            oauth_protected_resource_by_name,
            methods=["GET"],
        ),
    ])


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------


class TestMcpProxy401:
    def test_mcp_proxy_401_includes_www_authenticate(self):
        """401 from path-based proxy includes WWW-Authenticate with resource_metadata."""
        proxy_handler = AsyncMock()
        proxy_handler.proxy_request.return_value = {
            "error": "unauthorized",
            "message": "Missing or invalid authorization token",
        }

        app = _build_mcp_proxy_app(proxy_handler)
        client = TestClient(app, raise_server_exceptions=False)

        resp = client.post(
            "/hr",
            json={"jsonrpc": "2.0", "id": 1, "method": "tools/list", "params": {}},
        )

        assert resp.status_code == 401
        www_auth = resp.headers.get("www-authenticate", "")
        assert "resource_metadata=" in www_auth
        assert "/.well-known/oauth-protected-resource/hr" in www_auth

    def test_mcp_proxy_401_path_in_metadata_url(self):
        """WWW-Authenticate metadata URL contains the full request path."""
        proxy_handler = AsyncMock()
        proxy_handler.proxy_request.return_value = {
            "error": "unauthorized",
            "message": "Invalid token",
        }

        app = _build_mcp_proxy_app(proxy_handler)
        client = TestClient(app, raise_server_exceptions=False)

        resp = client.post(
            "/finance-system",
            json={"jsonrpc": "2.0", "id": 1, "method": "tools/list", "params": {}},
        )

        assert resp.status_code == 401
        www_auth = resp.headers.get("www-authenticate", "")
        expected_url = f"{GATEWAY_BASE_URL}/.well-known/oauth-protected-resource/finance-system"
        assert expected_url in www_auth

    def test_mcp_proxy_403_no_www_authenticate(self):
        """Non-401 errors should not include WWW-Authenticate header."""
        proxy_handler = AsyncMock()
        proxy_handler.proxy_request.return_value = {
            "error": "forbidden",
            "message": "Access denied",
        }

        app = _build_mcp_proxy_app(proxy_handler)
        client = TestClient(app, raise_server_exceptions=False)

        resp = client.post(
            "/hr",
            json={"jsonrpc": "2.0", "id": 1, "method": "tools/list", "params": {}},
        )

        assert resp.status_code == 403
        assert "www-authenticate" not in resp.headers


class TestProtectedResourceMetadata:
    def test_metadata_returns_url_resource(self):
        """resource field in metadata should be a full URL, not just the name."""
        router = MagicMock()
        router.get_resource_for_path.return_value = "hr"

        store = MagicMock()
        store.get_resource.return_value = MagicMock()  # truthy = resource exists

        app = _build_metadata_app(router, store)
        client = TestClient(app, raise_server_exceptions=False)

        resp = client.get("/.well-known/oauth-protected-resource/hr")

        assert resp.status_code == 200
        data = resp.json()
        assert data["resource"] == f"{GATEWAY_BASE_URL}/hr"
        assert data["resource"].startswith("https://")

    def test_metadata_404_for_unknown_path(self):
        """Unknown path returns 404."""
        router = MagicMock()
        router.get_resource_for_path.return_value = None

        app = _build_metadata_app(router, MagicMock())
        client = TestClient(app, raise_server_exceptions=False)

        resp = client.get("/.well-known/oauth-protected-resource/nonexistent")

        assert resp.status_code == 404
