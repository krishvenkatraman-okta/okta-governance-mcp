"""
Tests for the modified oauth_callback handler in app.py.

Verifies:
- Fast path (no STS connections): 302 redirect to agent with code+state
- STS path: 302 redirect to consent interstitial with session cookie
- Cookie attributes: httpOnly, SameSite=lax, Path=/oauth, Max-Age=600
- Missing code/state: 400
- Relay error: 400
"""

import json
import pytest
from unittest.mock import AsyncMock, MagicMock, patch
from urllib.parse import urlparse, parse_qs

from starlette.applications import Starlette
from starlette.routing import Route
from starlette.testclient import TestClient

# Import the handler and the module-level objects we need to patch
from okta_agent_proxy.auth.confidential_relay import RelayError


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

ORIGINAL_REDIRECT_URI = "http://localhost:9999/callback"
ORIGINAL_STATE = "client_state_abc"
CLIENT_ID = "https://app.example.com/oauth.json"

CALLBACK_RESULT = {
    "access_token": "at_123",
    "id_token": "idt_123",
    "refresh_token": "rt_123",
    "expires_in": 3600,
    "original_client_id": CLIENT_ID,
    "original_redirect_uri": ORIGINAL_REDIRECT_URI,
    "original_state": ORIGINAL_STATE,
    "relay_client_id": "relay_cid",
    "relay_client_secret": "relay_secret",
}


def _make_sts_resource(name="github"):
    rc = MagicMock()
    rc.name = name
    rc.auth_method = "okta-sts"
    rc.connection_id = f"conn-{name}"
    rc.metadata = {"app_instance_name": name, "resource_indicator": f"orn:okta:{name}"}
    return rc


def _build_test_app(
    relay_mock,
    registry_mock,
    consent_store_mock,
    consent_service_mock,
    code_manager_mock=None,
):
    """Build a minimal Starlette app wrapping the oauth_callback logic."""
    from starlette.responses import RedirectResponse
    from urllib.parse import urlencode
    import hashlib
    import asyncio

    async def oauth_callback(request):
        from starlette.responses import JSONResponse

        code = request.query_params.get("code")
        state = request.query_params.get("state")

        if not code or not state:
            return JSONResponse(
                {"error": "invalid_request", "error_description": "Missing code or state parameter"},
                status_code=400,
            )

        try:
            callback_result = await relay_mock.handle_callback_tokens_only(state, code)
            original_client_id = callback_result["original_client_id"]

            agent_config = None
            agent_id = None
            try:
                client_info = await registry_mock.resolve(original_client_id)
                if client_info and client_info.agent_config:
                    agent_config = client_info.agent_config
                    agent_id = agent_config.get("agent_id", "")
            except Exception:
                pass

            has_sts = False
            matching_sts_count = 0
            target_resource = callback_result.get("target_resource")

            if agent_config and agent_id:
                sts_resources = consent_service_mock.get_sts_resources(agent_id, agent_config)
                matching_resources = consent_service_mock.filter_resources_by_target(
                    sts_resources, target_resource
                )
                matching_sts_count = len(matching_resources)
                has_sts = matching_sts_count > 0

            if not has_sts:
                gw_code = code_manager_mock.issue_code(
                    client_id=original_client_id,
                    tokens={
                        "access_token": callback_result["access_token"],
                        "id_token": callback_result["id_token"],
                        "refresh_token": callback_result.get("refresh_token"),
                        "expires_in": callback_result.get("expires_in"),
                    },
                    extra={
                        "relay_client_id": callback_result.get("relay_client_id", ""),
                        "relay_client_secret": callback_result.get("relay_client_secret", ""),
                    },
                )
                redirect_params = {"code": gw_code, "state": callback_result["original_state"]}
                redirect_url = f"{callback_result['original_redirect_uri']}?{urlencode(redirect_params)}"
                return RedirectResponse(url=redirect_url, status_code=302)

            ua_hash = hashlib.sha256(
                request.headers.get("user-agent", "").encode()
            ).hexdigest()[:16]

            transaction = consent_store_mock.create(
                original_redirect_uri=callback_result["original_redirect_uri"],
                original_state=callback_result["original_state"],
                original_client_id=original_client_id,
                id_token=callback_result["id_token"],
                access_token=callback_result["access_token"],
                refresh_token=callback_result.get("refresh_token"),
                okta_expires_in=callback_result.get("expires_in"),
                agent_id=agent_id,
                agent_config=agent_config,
                ip_address=request.client.host if request.client else "",
                user_agent_hash=ua_hash,
                relay_client_id=callback_result.get("relay_client_id", ""),
                relay_client_secret=callback_result.get("relay_client_secret", ""),
                target_resource=callback_result.get("target_resource"),
            )

            asyncio.ensure_future(consent_service_mock.verify_all(transaction))

            response = RedirectResponse(
                url=f"/oauth/consent-verify?tx={transaction.transaction_id}",
                status_code=302,
            )
            response.set_cookie(
                "__okta_consent_session",
                value=transaction.session_id,
                httponly=True,
                secure=request.url.hostname not in ("localhost", "127.0.0.1"),
                samesite="lax",
                path="/oauth",
                max_age=600,
            )
            return response

        except RelayError as e:
            return JSONResponse(
                {"error": "relay_error", "error_description": str(e)},
                status_code=400,
            )

    return Starlette(routes=[
        Route("/oauth/callback", oauth_callback, methods=["GET"]),
    ])


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------


class TestCallbackNoSTS:
    def test_callback_no_sts_connections_fast_path(self):
        """No STS resources → 302 redirect to agent's redirect_uri with code+state."""
        relay = AsyncMock()
        relay.handle_callback_tokens_only.return_value = dict(CALLBACK_RESULT)

        client_info = MagicMock()
        client_info.agent_config = {"agent_id": "agent-1", "client_id": "0oa_xyz"}
        registry = AsyncMock()
        registry.resolve.return_value = client_info

        consent_svc = MagicMock()
        consent_svc.get_sts_resources.return_value = []  # No STS
        consent_svc.filter_resources_by_target.side_effect = lambda r, t: r

        code_mgr = MagicMock()
        code_mgr.issue_code.return_value = "a" * 64

        app = _build_test_app(relay, registry, MagicMock(), consent_svc, code_mgr)
        client = TestClient(app, raise_server_exceptions=False)

        resp = client.get(
            "/oauth/callback?code=okta_code&state=relay_state",
            follow_redirects=False,
        )

        assert resp.status_code == 302
        location = resp.headers["location"]
        assert location.startswith(ORIGINAL_REDIRECT_URI)
        params = parse_qs(urlparse(location).query)
        assert params["code"] == ["a" * 64]
        assert params["state"] == [ORIGINAL_STATE]


class TestCallbackWithSTS:
    def test_callback_with_sts_connections_redirects_to_interstitial(self):
        """STS resources present → redirect to consent interstitial with cookie."""
        relay = AsyncMock()
        relay.handle_callback_tokens_only.return_value = dict(CALLBACK_RESULT)

        client_info = MagicMock()
        client_info.agent_config = {"agent_id": "agent-1", "client_id": "0oa_xyz"}
        registry = AsyncMock()
        registry.resolve.return_value = client_info

        consent_svc = MagicMock()
        consent_svc.get_sts_resources.return_value = [_make_sts_resource("github")]
        consent_svc.filter_resources_by_target.side_effect = lambda r, t: r
        consent_svc.verify_all = AsyncMock()

        tx_mock = MagicMock()
        tx_mock.transaction_id = "tx-uuid-123"
        tx_mock.session_id = "sess-abc-456"
        consent_store = MagicMock()
        consent_store.create.return_value = tx_mock

        app = _build_test_app(relay, registry, consent_store, consent_svc)
        client = TestClient(app, raise_server_exceptions=False)

        resp = client.get(
            "/oauth/callback?code=okta_code&state=relay_state",
            follow_redirects=False,
        )

        assert resp.status_code == 302
        location = resp.headers["location"]
        assert "/oauth/consent-verify" in location
        assert "tx=tx-uuid-123" in location

        # Verify cookie is set
        cookie_header = resp.headers.get("set-cookie", "")
        assert "__okta_consent_session=sess-abc-456" in cookie_header

    def test_callback_cookie_attributes(self):
        """Verify httpOnly, SameSite=lax, Path=/oauth, Max-Age=600."""
        relay = AsyncMock()
        relay.handle_callback_tokens_only.return_value = dict(CALLBACK_RESULT)

        client_info = MagicMock()
        client_info.agent_config = {"agent_id": "agent-1", "client_id": "0oa_xyz"}
        registry = AsyncMock()
        registry.resolve.return_value = client_info

        consent_svc = MagicMock()
        consent_svc.get_sts_resources.return_value = [_make_sts_resource()]
        consent_svc.filter_resources_by_target.side_effect = lambda r, t: r
        consent_svc.verify_all = AsyncMock()

        tx_mock = MagicMock()
        tx_mock.transaction_id = "tx-001"
        tx_mock.session_id = "sess-001"
        consent_store = MagicMock()
        consent_store.create.return_value = tx_mock

        app = _build_test_app(relay, registry, consent_store, consent_svc)
        client = TestClient(app, raise_server_exceptions=False)

        resp = client.get(
            "/oauth/callback?code=c&state=s",
            follow_redirects=False,
        )

        cookie = resp.headers.get("set-cookie", "")
        assert "httponly" in cookie.lower()
        assert "samesite=lax" in cookie.lower()
        assert "path=/oauth" in cookie.lower()
        assert "max-age=600" in cookie.lower()


class TestCallbackErrors:
    def test_callback_missing_code_or_state(self):
        app = _build_test_app(AsyncMock(), AsyncMock(), MagicMock(), MagicMock())
        client = TestClient(app, raise_server_exceptions=False)

        resp = client.get("/oauth/callback?code=c", follow_redirects=False)
        assert resp.status_code == 400
        assert "Missing" in resp.json()["error_description"]

        resp = client.get("/oauth/callback?state=s", follow_redirects=False)
        assert resp.status_code == 400

        resp = client.get("/oauth/callback", follow_redirects=False)
        assert resp.status_code == 400

    def test_callback_relay_error(self):
        relay = AsyncMock()
        relay.handle_callback_tokens_only.side_effect = RelayError("session expired")

        app = _build_test_app(relay, AsyncMock(), MagicMock(), MagicMock())
        client = TestClient(app, raise_server_exceptions=False)

        resp = client.get(
            "/oauth/callback?code=c&state=s",
            follow_redirects=False,
        )
        assert resp.status_code == 400
        assert "relay_error" in resp.json()["error"]


class TestCallbackPathScoped:
    def test_callback_path_scoped_target_passes_to_transaction(self):
        """target_resource from callback result is passed to consent_store.create()."""
        callback_result_with_target = dict(CALLBACK_RESULT)
        callback_result_with_target["target_resource"] = "https://gateway.example.com/hr"

        relay = AsyncMock()
        relay.handle_callback_tokens_only.return_value = callback_result_with_target

        client_info = MagicMock()
        client_info.agent_config = {"agent_id": "agent-1", "client_id": "0oa_xyz"}
        registry = AsyncMock()
        registry.resolve.return_value = client_info

        hr_resource = _make_sts_resource("hr")
        github_resource = _make_sts_resource("github")

        consent_svc = MagicMock()
        consent_svc.get_sts_resources.return_value = [hr_resource, github_resource]
        # Path scoping: only hr matches
        consent_svc.filter_resources_by_target.side_effect = lambda r, t: (
            [rc for rc in r if rc.name == "hr"] if t else r
        )
        consent_svc.verify_all = AsyncMock()

        tx_mock = MagicMock()
        tx_mock.transaction_id = "tx-path-001"
        tx_mock.session_id = "sess-path-001"
        consent_store = MagicMock()
        consent_store.create.return_value = tx_mock

        app = _build_test_app(relay, registry, consent_store, consent_svc)
        client = TestClient(app, raise_server_exceptions=False)

        resp = client.get(
            "/oauth/callback?code=okta_code&state=relay_state",
            follow_redirects=False,
        )

        assert resp.status_code == 302
        assert "/oauth/consent-verify" in resp.headers["location"]

        # Verify target_resource was passed to consent_store.create()
        create_kwargs = consent_store.create.call_args[1]
        assert create_kwargs["target_resource"] == "https://gateway.example.com/hr"

    def test_callback_path_scoped_no_match_takes_fast_path(self):
        """Agent has STS resources but none match target_resource → fast path redirect."""
        callback_result_with_target = dict(CALLBACK_RESULT)
        callback_result_with_target["target_resource"] = "https://gateway.example.com/hr"

        relay = AsyncMock()
        relay.handle_callback_tokens_only.return_value = callback_result_with_target

        client_info = MagicMock()
        client_info.agent_config = {"agent_id": "agent-1", "client_id": "0oa_xyz"}
        registry = AsyncMock()
        registry.resolve.return_value = client_info

        consent_svc = MagicMock()
        consent_svc.get_sts_resources.return_value = [_make_sts_resource("github")]
        # No match: github doesn't match target "hr"
        consent_svc.filter_resources_by_target.return_value = []

        code_mgr = MagicMock()
        code_mgr.issue_code.return_value = "b" * 64

        app = _build_test_app(relay, registry, MagicMock(), consent_svc, code_mgr)
        client = TestClient(app, raise_server_exceptions=False)

        resp = client.get(
            "/oauth/callback?code=okta_code&state=relay_state",
            follow_redirects=False,
        )

        assert resp.status_code == 302
        location = resp.headers["location"]
        assert location.startswith(ORIGINAL_REDIRECT_URI)
        assert "/oauth/consent-verify" not in location
        params = parse_qs(urlparse(location).query)
        assert params["code"] == ["b" * 64]

    def test_callback_unified_flow_no_target_resource(self):
        """target_resource=None → all STS resources enter consent transaction."""
        relay = AsyncMock()
        relay.handle_callback_tokens_only.return_value = dict(CALLBACK_RESULT)  # no target_resource

        client_info = MagicMock()
        client_info.agent_config = {"agent_id": "agent-1", "client_id": "0oa_xyz"}
        registry = AsyncMock()
        registry.resolve.return_value = client_info

        hr_resource = _make_sts_resource("hr")
        github_resource = _make_sts_resource("github")

        consent_svc = MagicMock()
        consent_svc.get_sts_resources.return_value = [hr_resource, github_resource]
        # No target → return all
        consent_svc.filter_resources_by_target.side_effect = lambda r, t: r
        consent_svc.verify_all = AsyncMock()

        tx_mock = MagicMock()
        tx_mock.transaction_id = "tx-unified-001"
        tx_mock.session_id = "sess-unified-001"
        consent_store = MagicMock()
        consent_store.create.return_value = tx_mock

        app = _build_test_app(relay, registry, consent_store, consent_svc)
        client = TestClient(app, raise_server_exceptions=False)

        resp = client.get(
            "/oauth/callback?code=okta_code&state=relay_state",
            follow_redirects=False,
        )

        assert resp.status_code == 302
        assert "/oauth/consent-verify" in resp.headers["location"]

        # Verify target_resource=None was passed
        create_kwargs = consent_store.create.call_args[1]
        assert create_kwargs["target_resource"] is None
