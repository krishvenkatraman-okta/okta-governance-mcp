"""Tests for OktaAPIClient — stateless Okta Management API proxy."""

import logging

import httpx
import pytest
import pytest_asyncio

from okta_agent_proxy.okta_admin.client import OktaAPIClient
from okta_agent_proxy.okta_admin.exceptions import (
    OktaAdminAuthError,
    OktaAdminForbiddenError,
    OktaAdminNotFoundError,
    OktaAdminRateLimitError,
    OktaAdminAPIError,
    OktaAdminError,
)

OKTA_DOMAIN = "https://dev-12345.oktapreview.com"
FAKE_TOKEN = "fake-admin-token-abc123"


@pytest_asyncio.fixture
async def client():
    c = OktaAPIClient(okta_domain=OKTA_DOMAIN)
    yield c
    await c.close()


def _mock_response(status_code: int, json_body: dict | None = None, text: str = ""):
    """Build an httpx.Response stub."""
    resp = httpx.Response(
        status_code=status_code,
        json=json_body,
        request=httpx.Request("GET", OKTA_DOMAIN),
    )
    return resp


# ── Constructor ──────────────────────────────────────────────────────────

def test_constructor_requires_domain(monkeypatch):
    monkeypatch.delenv("OKTA_DOMAIN", raising=False)
    with pytest.raises(ValueError, match="okta_domain must be provided"):
        OktaAPIClient(okta_domain="")


def test_constructor_reads_env(monkeypatch):
    monkeypatch.setenv("OKTA_DOMAIN", OKTA_DOMAIN)
    c = OktaAPIClient()
    assert c.okta_domain == OKTA_DOMAIN


def test_constructor_strips_trailing_slash():
    c = OktaAPIClient(okta_domain=f"{OKTA_DOMAIN}/")
    assert c.okta_domain == OKTA_DOMAIN


# ── Successful requests ─────────────────────────────────────────────────

@pytest.mark.asyncio
async def test_get_success(client, monkeypatch):
    async def mock_request(**kwargs):
        return _mock_response(200, {"id": "app123"})

    monkeypatch.setattr(client._client, "request", mock_request)
    resp = await client.get("/api/v1/apps/app123", FAKE_TOKEN)
    assert resp.status_code == 200
    assert resp.json()["id"] == "app123"


@pytest.mark.asyncio
async def test_post_success(client, monkeypatch):
    payload = {"label": "My App"}

    async def mock_request(**kwargs):
        assert kwargs["json"] == payload
        return _mock_response(200, {"id": "app456", "label": "My App"})

    monkeypatch.setattr(client._client, "request", mock_request)
    resp = await client.post("/api/v1/apps", FAKE_TOKEN, json=payload)
    assert resp.status_code == 200


@pytest.mark.asyncio
async def test_post_without_body(client, monkeypatch):
    async def mock_request(**kwargs):
        assert kwargs["json"] is None
        return _mock_response(200, {"status": "ok"})

    monkeypatch.setattr(client._client, "request", mock_request)
    resp = await client.post("/api/v1/apps/app1/lifecycle/activate", FAKE_TOKEN)
    assert resp.status_code == 200


# ── Token handling ───────────────────────────────────────────────────────

@pytest.mark.asyncio
async def test_token_passed_in_auth_header(client, monkeypatch):
    async def mock_request(**kwargs):
        assert kwargs["headers"]["Authorization"] == f"Bearer {FAKE_TOKEN}"
        return _mock_response(200, {})

    monkeypatch.setattr(client._client, "request", mock_request)
    await client.get("/api/v1/apps", FAKE_TOKEN)


@pytest.mark.asyncio
async def test_content_type_and_accept_headers(client, monkeypatch):
    async def mock_request(**kwargs):
        assert kwargs["headers"]["Content-Type"] == "application/json"
        assert kwargs["headers"]["Accept"] == "application/json"
        return _mock_response(200, {})

    monkeypatch.setattr(client._client, "request", mock_request)
    await client.get("/api/v1/apps", FAKE_TOKEN)


@pytest.mark.asyncio
async def test_url_constructed_correctly(client, monkeypatch):
    async def mock_request(**kwargs):
        assert kwargs["url"] == f"{OKTA_DOMAIN}/api/v1/apps"
        return _mock_response(200, {})

    monkeypatch.setattr(client._client, "request", mock_request)
    await client.get("/api/v1/apps", FAKE_TOKEN)


# ── Error handling ───────────────────────────────────────────────────────

@pytest.mark.asyncio
async def test_401_raises_auth_error(client, monkeypatch):
    async def mock_request(**kwargs):
        return _mock_response(401, {"error": "invalid_token"})

    monkeypatch.setattr(client._client, "request", mock_request)
    with pytest.raises(OktaAdminAuthError, match="expired or invalid"):
        await client.get("/api/v1/apps", FAKE_TOKEN)


@pytest.mark.asyncio
async def test_403_raises_forbidden_error(client, monkeypatch):
    async def mock_request(**kwargs):
        return _mock_response(403, {"error": "insufficient_scope"})

    monkeypatch.setattr(client._client, "request", mock_request)
    with pytest.raises(OktaAdminForbiddenError, match="Insufficient Okta permissions"):
        await client.get("/api/v1/apps", FAKE_TOKEN)


@pytest.mark.asyncio
async def test_403_message_includes_scope_guidance(client, monkeypatch):
    async def mock_request(**kwargs):
        return _mock_response(403, {})

    monkeypatch.setattr(client._client, "request", mock_request)
    with pytest.raises(OktaAdminForbiddenError, match="okta.apps.manage"):
        await client.get("/api/v1/apps", FAKE_TOKEN)


@pytest.mark.asyncio
async def test_404_raises_not_found_error(client, monkeypatch):
    async def mock_request(**kwargs):
        return _mock_response(404, {})

    monkeypatch.setattr(client._client, "request", mock_request)
    with pytest.raises(OktaAdminNotFoundError, match="/api/v1/apps/missing"):
        await client.get("/api/v1/apps/missing", FAKE_TOKEN)


@pytest.mark.asyncio
async def test_429_raises_rate_limit_error(client, monkeypatch):
    async def mock_request(**kwargs):
        return _mock_response(429, {})

    monkeypatch.setattr(client._client, "request", mock_request)
    with pytest.raises(OktaAdminRateLimitError, match="rate limit"):
        await client.get("/api/v1/apps", FAKE_TOKEN)


@pytest.mark.asyncio
async def test_500_raises_api_error(client, monkeypatch):
    async def mock_request(**kwargs):
        return _mock_response(500, {"errorSummary": "Internal Server Error"})

    monkeypatch.setattr(client._client, "request", mock_request)
    with pytest.raises(OktaAdminAPIError) as exc_info:
        await client.get("/api/v1/apps", FAKE_TOKEN)
    assert exc_info.value.status_code == 500
    assert "Internal Server Error" in exc_info.value.error_description


@pytest.mark.asyncio
async def test_api_error_with_error_description_field(client, monkeypatch):
    async def mock_request(**kwargs):
        return _mock_response(502, {"error_description": "Bad Gateway upstream"})

    monkeypatch.setattr(client._client, "request", mock_request)
    with pytest.raises(OktaAdminAPIError) as exc_info:
        await client.get("/api/v1/apps", FAKE_TOKEN)
    assert exc_info.value.status_code == 502
    assert "Bad Gateway upstream" in exc_info.value.error_description


# ── Token never logged ───────────────────────────────────────────────────

@pytest.mark.asyncio
async def test_token_not_logged(client, monkeypatch, caplog):
    async def mock_request(**kwargs):
        return _mock_response(200, {})

    monkeypatch.setattr(client._client, "request", mock_request)
    with caplog.at_level(logging.DEBUG, logger="okta_agent_proxy.okta_admin.client"):
        await client.get("/api/v1/apps", FAKE_TOKEN)

    for record in caplog.records:
        assert FAKE_TOKEN not in record.getMessage(), "Token value must never appear in logs"


@pytest.mark.asyncio
async def test_token_not_logged_on_rate_limit(client, monkeypatch, caplog):
    async def mock_request(**kwargs):
        return _mock_response(429, {})

    monkeypatch.setattr(client._client, "request", mock_request)
    with caplog.at_level(logging.DEBUG, logger="okta_agent_proxy.okta_admin.client"):
        with pytest.raises(OktaAdminRateLimitError):
            await client.get("/api/v1/apps", FAKE_TOKEN)

    for record in caplog.records:
        assert FAKE_TOKEN not in record.getMessage(), "Token value must never appear in logs"


# ── get_user_by_login ────────────────────────────────────────────────────

@pytest.mark.asyncio
async def test_get_user_by_login_happy_path(client, monkeypatch):
    async def mock_request(**kwargs):
        assert kwargs["method"] == "GET"
        assert kwargs["url"] == f"{OKTA_DOMAIN}/api/v1/users/u@example.com"
        return _mock_response(
            200,
            {"id": "00u123", "profile": {"email": "u@example.com"}},
        )

    monkeypatch.setattr(client._client, "request", mock_request)
    user = await client.get_user_by_login("u@example.com", FAKE_TOKEN)
    assert user["id"] == "00u123"
    assert user["profile"]["email"] == "u@example.com"


@pytest.mark.asyncio
async def test_get_user_by_login_not_found(client, monkeypatch):
    async def mock_request(**kwargs):
        return _mock_response(404, {})

    monkeypatch.setattr(client._client, "request", mock_request)
    with pytest.raises(OktaAdminNotFoundError):
        await client.get_user_by_login("missing@example.com", FAKE_TOKEN)


@pytest.mark.asyncio
async def test_get_user_by_login_forbidden(client, monkeypatch):
    async def mock_request(**kwargs):
        return _mock_response(403, {"error": "insufficient_scope"})

    monkeypatch.setattr(client._client, "request", mock_request)
    with pytest.raises(OktaAdminForbiddenError, match="Insufficient Okta permissions"):
        await client.get_user_by_login("u@example.com", FAKE_TOKEN)


# ── Exception hierarchy ──────────────────────────────────────────────────

def test_all_exceptions_inherit_from_base():
    assert issubclass(OktaAdminAuthError, OktaAdminError)
    assert issubclass(OktaAdminForbiddenError, OktaAdminError)
    assert issubclass(OktaAdminNotFoundError, OktaAdminError)
    assert issubclass(OktaAdminRateLimitError, OktaAdminError)
    assert issubclass(OktaAdminAPIError, OktaAdminError)


def test_api_error_stores_fields():
    err = OktaAdminAPIError("msg", status_code=422, error_description="bad input")
    assert err.status_code == 422
    assert err.error_description == "bad input"
    assert err.message == "msg"
