"""
Tests for token store admin endpoints.

Tests:
- test_stats_endpoint: Correct structure returned
- test_delete_by_user: Store 3 entries (2 user A, 1 user B). Delete A. Verify 2 removed.
"""

import pytest
from unittest.mock import patch, MagicMock

from okta_agent_proxy.auth.user_token_store import UserTokenStore
from okta_agent_proxy.admin.routes import token_store_stats, token_store_delete_user


# ============================================================================
# Helpers
# ============================================================================


def _make_request(path_params=None):
    """Create a mock Starlette Request with admin auth bypassed."""
    req = MagicMock()
    req.path_params = path_params or {}
    req.state = MagicMock()
    req.state.admin_user = "admin"
    req.headers = {"authorization": "Bearer test-token"}
    req.method = "GET"
    req.url = MagicMock()
    req.url.path = "/api/admin/token-store/stats"
    return req


def _admin_auth_bypass():
    """Patch require_admin_token to always return a valid admin payload."""
    async def _valid_admin(request):
        return {"username": "admin"}
    return patch(
        "okta_agent_proxy.admin.middleware.require_admin_token",
        side_effect=_valid_admin,
    )


def _make_store_with_entries():
    """Create a UserTokenStore with 3 entries: 2 for user-a, 1 for user-b."""
    store = UserTokenStore(encryption_service=None, default_ttl=3600, max_size=100)
    store.store(
        access_token="at-1",
        id_token="idt-1",
        refresh_token="rt-1",
        user_sub="user-a@corp.com",
        agent_id="agent-1",
        expires_in=3600,
    )
    store.store(
        access_token="at-2",
        id_token="idt-2",
        refresh_token="rt-2",
        user_sub="user-a@corp.com",
        agent_id="agent-1",
        expires_in=3600,
    )
    store.store(
        access_token="at-3",
        id_token="idt-3",
        refresh_token="rt-3",
        user_sub="user-b@corp.com",
        agent_id="agent-2",
        expires_in=3600,
    )
    return store


# ============================================================================
# Tests
# ============================================================================


class TestTokenStoreStats:
    @pytest.mark.asyncio
    async def test_stats_endpoint(self):
        """Stats endpoint returns correct structure with no token values."""
        store = _make_store_with_entries()
        req = _make_request()

        with _admin_auth_bypass(), \
             patch("okta_agent_proxy.admin.routes.get_user_token_store", return_value=store):
            resp = await token_store_stats(req)

        import json
        result = json.loads(resp.body.decode())
        assert result == {
            "total_entries": 3,
            "encrypted": False,
            "ttl_seconds": 3600,
            "max_size": 100,
            "cache_service": False,
        }
        assert resp.status_code == 200

        # Verify no token values leak
        body_str = resp.body.decode()
        assert "idt-" not in body_str
        assert "rt-" not in body_str
        assert "at-" not in body_str


class TestTokenStoreDeleteUser:
    @pytest.mark.asyncio
    async def test_delete_by_user(self):
        """Delete user-a entries: 2 removed, user-b's entry remains."""
        store = _make_store_with_entries()
        req = _make_request(path_params={"user_sub": "user-a@corp.com"})

        with _admin_auth_bypass(), \
             patch("okta_agent_proxy.admin.routes.get_user_token_store", return_value=store):
            resp = await token_store_delete_user(req)

        import json
        result = json.loads(resp.body.decode())
        assert result == {"removed": 2}
        assert resp.status_code == 200

        # Verify store now has only 1 entry (user-b)
        assert store.get_stats()["total_entries"] == 1
