"""Tests for MCPSessionManager.terminate_all_for_user (global logout fan-out)."""

import asyncio
from datetime import datetime, timedelta
from typing import List
from unittest.mock import AsyncMock

import pytest

from okta_agent_proxy.audit.events import AuditEvent, AuditEventType
from okta_agent_proxy.audit.emitter import AuditEventEmitter
from okta_agent_proxy.audit.sinks.base import AuditSink
from okta_agent_proxy.audit.context import clear_request_context
from okta_agent_proxy.proxy.session_manager import MCPSessionManager


class CaptureSink(AuditSink):
    def __init__(self):
        self.events: List[AuditEvent] = []

    async def write(self, event: AuditEvent) -> None:
        self.events.append(event)

    @property
    def name(self) -> str:
        return "capture"


@pytest.fixture(autouse=True)
def _clean():
    clear_request_context()
    yield
    clear_request_context()


@pytest.fixture
async def capture_emitter():
    sink = CaptureSink()
    emitter = AuditEventEmitter(sinks=[sink], flush_interval=0.05)
    await emitter.start()

    import okta_agent_proxy.audit as audit_mod
    old = audit_mod._emitter
    audit_mod._emitter = emitter
    yield sink
    audit_mod._emitter = old
    await emitter.stop()


def _make_manager_with_sessions(entries):
    """entries: list of (cache_key, session_id, resource_url)."""
    sm = MCPSessionManager(session_ttl=3600)
    now = datetime.now()
    for cache_key, session_id, resource_url in entries:
        sm.sessions[cache_key] = {
            "session_id": session_id,
            "created_at": now.isoformat(),
            "expires_at": (now + timedelta(seconds=3600)).isoformat(),
            "resource_url": resource_url,
        }
    return sm


@pytest.mark.asyncio
async def test_terminate_all_for_user_empty_returns_empty_dict():
    sm = _make_manager_with_sessions([])
    sm.terminate_session = AsyncMock(return_value=True)
    result = await sm.terminate_all_for_user("userA")
    assert result == {}
    sm.terminate_session.assert_not_awaited()


@pytest.mark.asyncio
async def test_terminate_all_for_user_calls_each_backend():
    sm = _make_manager_with_sessions([
        ("userA:hr", "sid-hr-1", "http://hr/mcp"),
        ("userA:finance", "sid-fin-1", "http://finance/mcp"),
        ("userB:hr", "sid-hr-2", "http://hr/mcp"),
    ])
    sm.terminate_session = AsyncMock(return_value=True)
    result = await sm.terminate_all_for_user("userA")
    assert result == {"hr": True, "finance": True}
    assert sm.terminate_session.await_count == 2

    called_resources = {
        call.args[1] if len(call.args) > 1 else call.kwargs.get("resource_name")
        for call in sm.terminate_session.await_args_list
    }
    assert called_resources == {"hr", "finance"}


@pytest.mark.asyncio
async def test_terminate_all_for_user_handles_partial_failure():
    sm = _make_manager_with_sessions([
        ("userA:hr", "sid-hr", "http://hr/mcp"),
        ("userA:finance", "sid-fin", "http://finance/mcp"),
    ])

    async def fake_terminate(user_id, resource_name, resource_url, session_id):
        if resource_name == "hr":
            return True
        raise RuntimeError("backend exploded")

    sm.terminate_session = AsyncMock(side_effect=fake_terminate)
    result = await sm.terminate_all_for_user("userA")
    assert result["hr"] is True
    assert result["finance"] is False


@pytest.mark.asyncio
async def test_terminate_all_for_user_respects_timeout():
    sm = _make_manager_with_sessions([
        ("userA:slow", "sid-slow", "http://slow/mcp"),
    ])

    async def slow_terminate(user_id, resource_name, resource_url, session_id):
        await asyncio.sleep(5)
        return True

    sm.terminate_session = AsyncMock(side_effect=slow_terminate)
    result = await sm.terminate_all_for_user("userA", per_call_timeout=0.05)
    assert result == {"slow": False}


@pytest.mark.asyncio
async def test_terminate_all_for_user_emits_correct_audit_events(capture_emitter):
    sm = _make_manager_with_sessions([
        ("userA:hr", "sid-hr", "http://hr/mcp"),
        ("userA:finance", "sid-fin", "http://finance/mcp"),
    ])

    async def fake_terminate(user_id, resource_name, resource_url, session_id):
        return resource_name == "hr"

    sm.terminate_session = AsyncMock(side_effect=fake_terminate)
    await sm.terminate_all_for_user("userA")

    await asyncio.sleep(0.15)

    types = [e.event_type for e in capture_emitter.events]
    assert AuditEventType.GLOBAL_LOGOUT_BACKEND_SESSION_TERMINATED in types
    assert AuditEventType.GLOBAL_LOGOUT_BACKEND_SESSION_FAILED in types

    terminated = [e for e in capture_emitter.events
                  if e.event_type == AuditEventType.GLOBAL_LOGOUT_BACKEND_SESSION_TERMINATED]
    failed = [e for e in capture_emitter.events
              if e.event_type == AuditEventType.GLOBAL_LOGOUT_BACKEND_SESSION_FAILED]
    assert len(terminated) == 1
    assert terminated[0].resource_name == "hr"
    assert len(failed) == 1
    assert failed[0].resource_name == "finance"
    assert failed[0].outcome == "failure"
    assert "error" in failed[0].details


@pytest.mark.asyncio
async def test_terminate_all_for_user_only_matches_user_prefix():
    """Guard against substring trap: 'user1' must NOT match 'user12:<resource>'."""
    sm = _make_manager_with_sessions([
        ("user1:hr", "sid-1", "http://hr/mcp"),
        ("user12:hr", "sid-12", "http://hr/mcp"),
    ])
    sm.terminate_session = AsyncMock(return_value=True)

    result = await sm.terminate_all_for_user("user1")
    assert result == {"hr": True}
    assert sm.terminate_session.await_count == 1
    call = sm.terminate_session.await_args_list[0]
    user_arg = call.args[0] if call.args else call.kwargs.get("user_id")
    assert user_arg == "user1"
