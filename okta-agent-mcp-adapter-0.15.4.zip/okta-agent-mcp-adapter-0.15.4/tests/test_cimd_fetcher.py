"""
Tests for CIMD (Client ID Metadata Document) Fetcher.

Tests:
- Happy path: valid HTTPS URL → valid JSON → CIMDMetadata
- client_id mismatch → CIMDValidationError
- Missing required fields → CIMDValidationError
- SSRF: private IP → CIMDSSRFError
- SSRF: link-local → CIMDSSRFError
- SSRF: loopback blocked/allowed
- Timeout → CIMDFetchError
- Oversized response → CIMDFetchError
- Non-JSON response → CIMDValidationError
- HTTP scheme rejected → CIMDFetchError
- Cache hit: second call uses cache
- Negative cache: failed fetch cached for retry prevention
- private_key_jwt without jwks_uri → CIMDValidationError
- Redirect to private IP → CIMDSSRFError
"""

import json
import pytest
from datetime import datetime
from unittest.mock import AsyncMock, patch

import httpx

from okta_agent_proxy.auth.cimd_fetcher import (
    CIMDFetcher,
    CIMDMetadata,
    CIMDSSRFError,
    CIMDFetchError,
    CIMDValidationError,
    _is_blocked_ip,
    _resolve_and_check,
)
from okta_agent_proxy.cache.cache_service import CacheService
from okta_agent_proxy.cache.memory_provider import MemoryCacheProvider


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

VALID_URL = "https://example.com/oauth.json"

VALID_DOC = {
    "client_id": VALID_URL,
    "client_name": "Test App",
    "redirect_uris": ["https://example.com/callback"],
    "grant_types": ["authorization_code"],
    "response_types": ["code"],
    "token_endpoint_auth_method": "none",
}

# Patch target for DNS resolution
DNS_PATCH = "okta_agent_proxy.auth.cimd_fetcher.socket.getaddrinfo"

# Standard "public IP" DNS result
PUBLIC_DNS = [(2, 1, 6, "", ("93.184.216.34", 0))]


def _mock_transport(body=None, status_code=200, headers=None):
    """Create an httpx.MockTransport returning a fixed response."""
    if body is None:
        body = VALID_DOC
    if isinstance(body, dict):
        content = json.dumps(body).encode()
    elif isinstance(body, str):
        content = body.encode()
    else:
        content = body

    resp_headers = {"content-type": "application/json"}
    if headers:
        resp_headers.update(headers)

    def handler(request: httpx.Request) -> httpx.Response:
        return httpx.Response(status_code=status_code, content=content, headers=resp_headers)

    return httpx.MockTransport(handler)


def _make_cache_service():
    l2 = MemoryCacheProvider(max_size=1000, default_ttl=3600)
    return CacheService(l2_provider=l2)


def _fetcher(transport=None, **kwargs):
    """Convenience to create a CIMDFetcher with a mock transport."""
    if transport is None:
        transport = _mock_transport()
    # Default to blocking private networks in tests (env var may override)
    kwargs.setdefault("allow_private_networks", False)
    kwargs.setdefault("allow_localhost", False)
    return CIMDFetcher(transport=transport, **kwargs)


# ---------------------------------------------------------------------------
# IP blocking tests
# ---------------------------------------------------------------------------


class TestIPBlocking:
    def test_private_10_blocked(self):
        assert _is_blocked_ip("10.0.0.1") is True

    def test_private_172_blocked(self):
        assert _is_blocked_ip("172.16.0.1") is True

    def test_private_192_blocked(self):
        assert _is_blocked_ip("192.168.1.1") is True

    def test_loopback_blocked(self):
        assert _is_blocked_ip("127.0.0.1") is True

    def test_loopback_allowed_in_dev(self):
        assert _is_blocked_ip("127.0.0.1", allow_localhost=True) is False

    def test_link_local_blocked(self):
        assert _is_blocked_ip("169.254.169.254") is True

    def test_ipv6_loopback_blocked(self):
        assert _is_blocked_ip("::1") is True

    def test_ipv6_loopback_allowed_in_dev(self):
        assert _is_blocked_ip("::1", allow_localhost=True) is False

    def test_public_ip_allowed(self):
        assert _is_blocked_ip("93.184.216.34") is False

    def test_multicast_blocked(self):
        assert _is_blocked_ip("ff02::1") is True


# ---------------------------------------------------------------------------
# DNS resolution tests
# ---------------------------------------------------------------------------


class TestDNSResolution:
    def test_private_ip_raises_ssrf(self):
        with patch(DNS_PATCH) as mock_dns:
            mock_dns.return_value = [(2, 1, 6, "", ("192.168.1.1", 0))]
            with pytest.raises(CIMDSSRFError, match="restricted IP range"):
                _resolve_and_check("evil.example.com")

    def test_link_local_raises_ssrf(self):
        with patch(DNS_PATCH) as mock_dns:
            mock_dns.return_value = [(2, 1, 6, "", ("169.254.169.254", 0))]
            with pytest.raises(CIMDSSRFError, match="restricted IP range"):
                _resolve_and_check("metadata.example.com")

    def test_public_ip_passes(self):
        with patch(DNS_PATCH) as mock_dns:
            mock_dns.return_value = PUBLIC_DNS
            ips = _resolve_and_check("example.com")
            assert ips == ["93.184.216.34"]

    def test_dns_failure_raises_fetch_error(self):
        import socket as sock_mod

        with patch(DNS_PATCH) as mock_dns:
            mock_dns.side_effect = sock_mod.gaierror("Name resolution failed")
            with pytest.raises(CIMDFetchError, match="DNS resolution failed"):
                _resolve_and_check("nonexistent.example.com")


# ---------------------------------------------------------------------------
# Fetcher – happy path
# ---------------------------------------------------------------------------


class TestCIMDFetcherHappyPath:
    async def test_valid_document(self):
        """Valid HTTPS URL → valid JSON → returns CIMDMetadata with all fields."""
        fetcher = _fetcher(allow_localhost=False)

        with patch(DNS_PATCH, return_value=PUBLIC_DNS):
            result = await fetcher.fetch_and_validate(VALID_URL)

        assert isinstance(result, CIMDMetadata)
        assert result.client_id == VALID_URL
        assert result.client_name == "Test App"
        assert result.redirect_uris == ["https://example.com/callback"]
        assert result.grant_types == ["authorization_code"]
        assert result.response_types == ["code"]
        assert result.token_endpoint_auth_method == "none"
        assert result.domain == "example.com"
        assert isinstance(result.fetched_at, datetime)
        assert result.raw_json == VALID_DOC

    async def test_optional_fields_defaults(self):
        """Optional fields get defaults when not provided."""
        doc = {
            "client_id": VALID_URL,
            "client_name": "Minimal App",
            "redirect_uris": ["https://example.com/cb"],
        }
        fetcher = _fetcher(transport=_mock_transport(doc), allow_localhost=False)

        with patch(DNS_PATCH, return_value=PUBLIC_DNS):
            result = await fetcher.fetch_and_validate(VALID_URL)

        assert result.grant_types == ["authorization_code"]
        assert result.response_types == ["code"]
        assert result.token_endpoint_auth_method == "none"
        assert result.jwks_uri is None


# ---------------------------------------------------------------------------
# Fetcher – validation errors
# ---------------------------------------------------------------------------


class TestCIMDFetcherValidation:
    async def test_client_id_mismatch(self):
        """JSON client_id differs from fetch URL → CIMDValidationError."""
        doc = {**VALID_DOC, "client_id": "https://evil.com/other.json"}
        fetcher = _fetcher(transport=_mock_transport(doc), allow_localhost=False)

        with patch(DNS_PATCH, return_value=PUBLIC_DNS):
            with pytest.raises(CIMDValidationError, match="client_id mismatch"):
                await fetcher.fetch_and_validate(VALID_URL)

    async def test_missing_client_name(self):
        doc = {"client_id": VALID_URL, "redirect_uris": ["https://example.com/cb"]}
        fetcher = _fetcher(transport=_mock_transport(doc), allow_localhost=False)

        with patch(DNS_PATCH, return_value=PUBLIC_DNS):
            with pytest.raises(CIMDValidationError, match="client_name"):
                await fetcher.fetch_and_validate(VALID_URL)

    async def test_missing_redirect_uris(self):
        doc = {"client_id": VALID_URL, "client_name": "Test"}
        fetcher = _fetcher(transport=_mock_transport(doc), allow_localhost=False)

        with patch(DNS_PATCH, return_value=PUBLIC_DNS):
            with pytest.raises(CIMDValidationError, match="redirect_uris"):
                await fetcher.fetch_and_validate(VALID_URL)

    async def test_empty_redirect_uris(self):
        doc = {**VALID_DOC, "redirect_uris": []}
        fetcher = _fetcher(transport=_mock_transport(doc), allow_localhost=False)

        with patch(DNS_PATCH, return_value=PUBLIC_DNS):
            with pytest.raises(CIMDValidationError, match="redirect_uris"):
                await fetcher.fetch_and_validate(VALID_URL)

    async def test_javascript_redirect_uri_rejected(self):
        doc = {**VALID_DOC, "redirect_uris": ["javascript:alert(1)"]}
        fetcher = _fetcher(transport=_mock_transport(doc), allow_localhost=False)

        with patch(DNS_PATCH, return_value=PUBLIC_DNS):
            with pytest.raises(CIMDValidationError, match="Invalid redirect_uri scheme"):
                await fetcher.fetch_and_validate(VALID_URL)

    async def test_data_redirect_uri_rejected(self):
        doc = {**VALID_DOC, "redirect_uris": ["data:text/html,<h1>hi</h1>"]}
        fetcher = _fetcher(transport=_mock_transport(doc), allow_localhost=False)

        with patch(DNS_PATCH, return_value=PUBLIC_DNS):
            with pytest.raises(CIMDValidationError, match="Invalid redirect_uri scheme"):
                await fetcher.fetch_and_validate(VALID_URL)

    async def test_invalid_auth_method(self):
        doc = {**VALID_DOC, "token_endpoint_auth_method": "magic"}
        fetcher = _fetcher(transport=_mock_transport(doc), allow_localhost=False)

        with patch(DNS_PATCH, return_value=PUBLIC_DNS):
            with pytest.raises(CIMDValidationError, match="token_endpoint_auth_method"):
                await fetcher.fetch_and_validate(VALID_URL)

    async def test_private_key_jwt_without_jwks_uri(self):
        doc = {**VALID_DOC, "token_endpoint_auth_method": "private_key_jwt"}
        fetcher = _fetcher(transport=_mock_transport(doc), allow_localhost=False)

        with patch(DNS_PATCH, return_value=PUBLIC_DNS):
            with pytest.raises(CIMDValidationError, match="jwks_uri is required"):
                await fetcher.fetch_and_validate(VALID_URL)

    async def test_private_key_jwt_with_jwks_uri_ok(self):
        doc = {
            **VALID_DOC,
            "token_endpoint_auth_method": "private_key_jwt",
            "jwks_uri": "https://example.com/.well-known/jwks.json",
        }
        fetcher = _fetcher(transport=_mock_transport(doc), allow_localhost=False)

        with patch(DNS_PATCH, return_value=PUBLIC_DNS):
            result = await fetcher.fetch_and_validate(VALID_URL)

        assert result.token_endpoint_auth_method == "private_key_jwt"
        assert result.jwks_uri == "https://example.com/.well-known/jwks.json"

    async def test_non_json_response(self):
        fetcher = _fetcher(
            transport=_mock_transport("<html><body>Not JSON</body></html>"),
            allow_localhost=False,
        )

        with patch(DNS_PATCH, return_value=PUBLIC_DNS):
            with pytest.raises(CIMDValidationError, match="Invalid JSON"):
                await fetcher.fetch_and_validate(VALID_URL)


# ---------------------------------------------------------------------------
# Fetcher – SSRF
# ---------------------------------------------------------------------------


class TestCIMDFetcherSSRF:
    async def test_private_ip_blocked(self):
        """URL resolves to 192.168.1.1 → CIMDSSRFError."""
        fetcher = _fetcher(allow_localhost=False)

        with patch(DNS_PATCH, return_value=[(2, 1, 6, "", ("192.168.1.1", 0))]):
            with pytest.raises(CIMDSSRFError, match="restricted IP range"):
                await fetcher.fetch_and_validate(VALID_URL)

    async def test_link_local_blocked(self):
        fetcher = _fetcher(allow_localhost=False)

        with patch(DNS_PATCH, return_value=[(2, 1, 6, "", ("169.254.169.254", 0))]):
            with pytest.raises(CIMDSSRFError, match="restricted IP range"):
                await fetcher.fetch_and_validate(VALID_URL)

    async def test_loopback_blocked_in_prod(self):
        """http://127.0.0.1/meta.json with allow_localhost=False → CIMDFetchError."""
        fetcher = _fetcher(allow_localhost=False)
        with pytest.raises(CIMDFetchError, match="HTTP scheme not allowed"):
            await fetcher.fetch_and_validate("http://127.0.0.1/meta.json")

    async def test_loopback_allowed_in_dev(self):
        """http://127.0.0.1/oauth.json with allow_localhost=True → success."""
        url = "http://127.0.0.1/oauth.json"
        doc = {**VALID_DOC, "client_id": url}
        fetcher = _fetcher(transport=_mock_transport(doc), allow_localhost=True)

        with patch(DNS_PATCH, return_value=[(2, 1, 6, "", ("127.0.0.1", 0))]):
            result = await fetcher.fetch_and_validate(url)

        assert result.client_id == url

    async def test_https_loopback_blocked_in_prod(self):
        fetcher = _fetcher(allow_localhost=False)

        with patch(DNS_PATCH, return_value=[(2, 1, 6, "", ("127.0.0.1", 0))]):
            with pytest.raises(CIMDSSRFError, match="restricted IP range"):
                await fetcher.fetch_and_validate(VALID_URL)

    async def test_http_scheme_rejected_for_non_localhost(self):
        fetcher = _fetcher(allow_localhost=False)
        with pytest.raises(CIMDFetchError, match="HTTP scheme not allowed"):
            await fetcher.fetch_and_validate("http://example.com/meta.json")

    async def test_redirect_to_private_ip(self):
        """URL redirects to internal host that resolves to 10.0.0.1 → CIMDSSRFError."""
        call_count = 0

        def redirect_handler(request: httpx.Request) -> httpx.Response:
            nonlocal call_count
            call_count += 1
            if call_count == 1:
                return httpx.Response(
                    status_code=302,
                    headers={"location": "https://internal.example.com/secret"},
                )
            return httpx.Response(200, content=json.dumps(VALID_DOC).encode())

        fetcher = _fetcher(
            transport=httpx.MockTransport(redirect_handler), allow_localhost=False
        )

        def dns_side_effect(hostname, *args, **kwargs):
            if hostname == "internal.example.com":
                return [(2, 1, 6, "", ("10.0.0.1", 0))]
            return PUBLIC_DNS

        with patch(DNS_PATCH, side_effect=dns_side_effect):
            with pytest.raises(CIMDSSRFError, match="restricted IP range"):
                await fetcher.fetch_and_validate(VALID_URL)


# ---------------------------------------------------------------------------
# Fetcher – network errors
# ---------------------------------------------------------------------------


class TestCIMDFetcherNetworkErrors:
    async def test_timeout(self):
        """Server hangs → CIMDFetchError."""

        def timeout_handler(request: httpx.Request) -> httpx.Response:
            raise httpx.ReadTimeout("Read timed out")

        fetcher = _fetcher(
            transport=httpx.MockTransport(timeout_handler),
            allow_localhost=False,
            connect_timeout=0.1,
            read_timeout=0.1,
        )

        with patch(DNS_PATCH, return_value=PUBLIC_DNS):
            with pytest.raises(CIMDFetchError, match="Timeout"):
                await fetcher.fetch_and_validate(VALID_URL)

    async def test_oversized_response(self):
        """100KB response → CIMDFetchError."""
        huge_body = "x" * (100 * 1024)
        fetcher = _fetcher(
            transport=_mock_transport(huge_body),
            allow_localhost=False,
            max_doc_size=50 * 1024,
        )

        with patch(DNS_PATCH, return_value=PUBLIC_DNS):
            with pytest.raises(CIMDFetchError, match="too large"):
                await fetcher.fetch_and_validate(VALID_URL)


# ---------------------------------------------------------------------------
# Fetcher – caching
# ---------------------------------------------------------------------------


class TestCIMDFetcherCaching:
    async def test_cache_hit(self):
        """Second call returns cached result without HTTP request."""
        cache = _make_cache_service()
        fetcher = _fetcher(allow_localhost=False, cache_service=cache)

        with patch(DNS_PATCH, return_value=PUBLIC_DNS):
            result1 = await fetcher.fetch_and_validate(VALID_URL)
            assert result1.client_id == VALID_URL

        # Replace transport with one that would fail – proves cache is used
        fetcher._transport = _mock_transport("THIS WOULD FAIL")
        result2 = await fetcher.fetch_and_validate(VALID_URL)
        assert result2.client_id == VALID_URL
        assert result2.client_name == "Test App"

    async def test_negative_cache(self):
        """Failed fetch, immediate retry returns cached error."""
        cache = _make_cache_service()
        fetcher = _fetcher(allow_localhost=False, cache_service=cache)

        # First call – fails (private IP)
        with patch(DNS_PATCH, return_value=[(2, 1, 6, "", ("192.168.1.1", 0))]):
            with pytest.raises(CIMDSSRFError):
                await fetcher.fetch_and_validate(VALID_URL)

        # Second call – negative cache hit (no DNS mock needed)
        with pytest.raises(CIMDFetchError, match="cached negative result"):
            await fetcher.fetch_and_validate(VALID_URL)

    async def test_invalidate_cache(self):
        """invalidate() clears the cached entry."""
        cache = _make_cache_service()
        fetcher = _fetcher(allow_localhost=False, cache_service=cache)

        with patch(DNS_PATCH, return_value=PUBLIC_DNS):
            await fetcher.fetch_and_validate(VALID_URL)

        await fetcher.invalidate(VALID_URL)

        # Next call should fetch again – will fail with bad transport
        fetcher._transport = _mock_transport("NOT JSON")
        with patch(DNS_PATCH, return_value=PUBLIC_DNS):
            with pytest.raises(CIMDValidationError):
                await fetcher.fetch_and_validate(VALID_URL)
