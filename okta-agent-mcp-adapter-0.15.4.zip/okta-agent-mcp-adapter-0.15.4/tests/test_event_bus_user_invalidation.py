"""
Tests for cross-pod user-scoped pub/sub invalidation channels (P5).

Uses two component instances sharing a single CacheEventBus backed by a
FakeRedisProvider to simulate multi-pod invalidation without real Redis.
"""

import asyncio
import json
import pytest
from datetime import datetime, timezone
from unittest.mock import AsyncMock, MagicMock

from okta_agent_proxy.cache.cache_service import CacheService
from okta_agent_proxy.cache.pubsub import (
    CacheEventBus,
    CHANNEL_USER_TOKEN_INVALIDATE,
    CHANNEL_RELAY_SESSION_INVALIDATE,
    CHANNEL_CONSENT_TX_INVALIDATE,
    CHANNEL_USER_LOGOUT,
)
from okta_agent_proxy.auth.user_token_store import UserTokenStore, reset_user_token_store
from okta_agent_proxy.auth.confidential_relay import ConfidentialRelay, RelaySession
from okta_agent_proxy.auth.consent_transaction import ConsentTransactionStore


# ---------------------------------------------------------------------------
# FakeRedisProvider — reused from test_cache_encryption_wiring.py
# ---------------------------------------------------------------------------
from okta_agent_proxy.cache.redis_provider import RedisCacheProvider


class FakeRedisProvider(RedisCacheProvider):
    """In-memory dict backing that satisfies isinstance(x, RedisCacheProvider)."""

    def __init__(self):
        self._data: dict[str, str] = {}
        self._ttls: dict[str, int] = {}

    async def get(self, key: str):
        return self._data.get(key)

    async def set(self, key: str, value: str, ttl_seconds=None):
        self._data[key] = value
        if ttl_seconds:
            self._ttls[key] = ttl_seconds

    async def delete(self, key: str):
        self._data.pop(key, None)
        self._ttls.pop(key, None)

    async def exists(self, key: str) -> bool:
        return key in self._data

    async def clear_prefix(self, prefix: str) -> int:
        keys = [k for k in self._data if k.startswith(prefix)]
        for k in keys:
            del self._data[k]
        return len(keys)

    async def health_check(self) -> bool:
        return True

    def close(self):
        self._data.clear()


# ---------------------------------------------------------------------------
# FakeRedis pubsub — synchronous message dispatch for testing
# ---------------------------------------------------------------------------
class FakePubSub:
    """Simulates Redis pub/sub with synchronous in-process delivery."""

    def __init__(self):
        self._subscribers: dict[str, list] = {}

    async def publish(self, channel: str, message: str):
        for cb in self._subscribers.get(channel, []):
            result = cb(message)
            if asyncio.iscoroutine(result):
                await result

    async def subscribe(self, channel: str, callback):
        if channel not in self._subscribers:
            self._subscribers[channel] = []
        self._subscribers[channel].append(callback)


class SharedEventBus:
    """Wraps two CacheEventBus instances with shared in-process message delivery."""

    def __init__(self):
        self._pubsub = FakePubSub()

    def create_bus(self, cache_service) -> CacheEventBus:
        bus = CacheEventBus(cache_service)
        # Override publish to route through the shared pubsub
        original_subscribe = bus.subscribe

        async def patched_publish(channel, message):
            await self._pubsub.publish(channel, message)

        async def patched_subscribe(channel, callback):
            await original_subscribe(channel, callback)
            await self._pubsub.subscribe(channel, callback)

        bus.publish = patched_publish
        bus.subscribe = patched_subscribe
        return bus


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


@pytest.fixture
def fake_redis():
    return FakeRedisProvider()


@pytest.fixture
def cache_service(fake_redis):
    return CacheService(l2_provider=fake_redis)


@pytest.fixture
def shared_bus(cache_service):
    return SharedEventBus()


@pytest.fixture
def enc_service():
    import base64
    from okta_agent_proxy.crypto.encryption import EncryptionService
    key_b64 = EncryptionService.generate_key()
    key_bytes = base64.b64decode(key_b64)
    return EncryptionService(key=key_bytes, key_id="test")


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------


class TestUserTokenInvalidation:
    """user_token_invalidate: remove on A → L1 cleared on B."""

    @pytest.mark.asyncio
    async def test_invalidate_clears_remote_l1(self, cache_service, shared_bus):
        bus_a = shared_bus.create_bus(cache_service)
        bus_b = shared_bus.create_bus(cache_service)

        store_a = UserTokenStore(cache_service=cache_service, event_bus=bus_a)
        store_b = UserTokenStore(cache_service=cache_service, event_bus=bus_b)

        # Subscribe B to the channel
        async def _on_invalidate(message):
            payload = json.loads(message)
            token_hash = payload.get("key")
            if token_hash:
                store_b._cache.pop(token_hash, None)

        await bus_b.subscribe(CHANNEL_USER_TOKEN_INVALIDATE, _on_invalidate)

        # Store a token on A (writes to L1 + L2)
        await store_a.astore(
            access_token="test-token-123",
            id_token="id-tok",
            refresh_token="ref-tok",
            user_sub="alice",
            agent_id="claude",
        )

        # Simulate B loading from L2 into its L1
        result = await store_b.alookup("test-token-123")
        assert result is not None
        assert result["user_sub"] == "alice"
        # Verify B has it in L1
        token_hash = UserTokenStore._hash_token("test-token-123")
        assert token_hash in store_b._cache

        # Remove on A — publishes invalidation
        await store_a.aremove("test-token-123")

        # B's L1 should now be cleared (message delivered synchronously)
        assert token_hash not in store_b._cache


class TestRelaySessionInvalidation:
    """relay_session_invalidate: delete on A → L1 cleared on B."""

    @pytest.mark.asyncio
    async def test_invalidate_clears_remote_l1(self, cache_service, shared_bus):
        bus_a = shared_bus.create_bus(cache_service)
        bus_b = shared_bus.create_bus(cache_service)

        relay_a = ConfidentialRelay(cache_service=cache_service, event_bus=bus_a)
        relay_b = ConfidentialRelay(cache_service=cache_service, event_bus=bus_b)

        # Subscribe B
        async def _on_invalidate(message):
            payload = json.loads(message)
            state = payload.get("key")
            if state:
                relay_b._sessions_by_state.pop(state, None)
                relay_b._preconsent_sessions_by_state.pop(state, None)

        await bus_b.subscribe(CHANNEL_RELAY_SESSION_INVALIDATE, _on_invalidate)

        # Create a relay session on A's L1
        session = RelaySession(
            original_client_id="http://example.com/.well-known/oauth-client",
            original_redirect_uri="http://localhost:8080/callback",
            original_state="orig-state",
            relay_state="test-relay-state-abc",
            code_verifier="verifier",
            created_at=datetime.now(timezone.utc),
            relay_client_id="okta-client",
            relay_client_secret="okta-secret",
        )
        await relay_a._store_relay_state("test-relay-state-abc", session)

        # Simulate B loading from L2
        loaded = await relay_b._load_relay_state("test-relay-state-abc")
        assert loaded is not None
        assert "test-relay-state-abc" in relay_b._sessions_by_state

        # Delete on A — publishes invalidation
        await relay_a._delete_relay_state("test-relay-state-abc")

        # B's L1 should be cleared
        assert "test-relay-state-abc" not in relay_b._sessions_by_state


class TestConsentTxInvalidation:
    """consent_tx_invalidate: remove on A → L1 cleared on B."""

    @pytest.mark.asyncio
    async def test_invalidate_clears_remote_l1(self, cache_service, shared_bus):
        bus_a = shared_bus.create_bus(cache_service)
        bus_b = shared_bus.create_bus(cache_service)

        store_a = ConsentTransactionStore(cache_service=cache_service, event_bus=bus_a)
        store_b = ConsentTransactionStore(cache_service=cache_service, event_bus=bus_b)

        # Subscribe B
        async def _on_invalidate(message):
            payload = json.loads(message)
            tx_id = payload.get("key")
            if tx_id:
                tx = store_b._by_id.pop(tx_id, None)
                if tx is not None:
                    store_b._by_session.pop(tx.session_id, None)

        await bus_b.subscribe(CHANNEL_CONSENT_TX_INVALIDATE, _on_invalidate)

        # Create on A
        tx = await store_a.acreate(
            agent_id="claude",
            id_token="id-tok",
            access_token="access-tok",
        )
        tx_id = tx.transaction_id

        # Load on B from L2
        loaded = await store_b.aget_by_id(tx_id)
        assert loaded is not None
        assert tx_id in store_b._by_id

        # Remove on A — publishes invalidation
        await store_a.aremove(tx_id)

        # B's L1 should be cleared
        assert tx_id not in store_b._by_id


class TestUserLogout:
    """user_logout: cascade clears UserTokenStore and TokenCache on remote pod."""

    @pytest.mark.asyncio
    async def test_logout_clears_remote_token_store(self, cache_service, shared_bus):
        bus_a = shared_bus.create_bus(cache_service)
        bus_b = shared_bus.create_bus(cache_service)

        store_a = UserTokenStore(cache_service=cache_service, event_bus=bus_a)
        store_b = UserTokenStore(cache_service=cache_service, event_bus=bus_b)

        # Subscribe B to user_logout
        async def _on_logout(message):
            payload = json.loads(message)
            user_sub = payload.get("key")
            if user_sub:
                store_b.remove_by_user(user_sub)

        await bus_b.subscribe(CHANNEL_USER_LOGOUT, _on_logout)

        # Store tokens for "alice" on both A and B (simulating they both
        # served requests for this user)
        for s in (store_a, store_b):
            await s.astore(
                access_token="alice-token-1",
                id_token="id1",
                refresh_token="ref1",
                user_sub="alice",
                agent_id="claude",
            )
            await s.astore(
                access_token="alice-token-2",
                id_token="id2",
                refresh_token="ref2",
                user_sub="alice",
                agent_id="claude",
            )

        # Verify B has 2 entries in L1
        assert len(store_b._cache) == 2

        # Publish logout from A
        await bus_a.publish(
            CHANNEL_USER_LOGOUT,
            json.dumps({"v": 1, "key": "alice"}),
        )

        # B's L1 should be cleared
        assert len(store_b._cache) == 0


class TestChannelEnvelope:
    """Verify the standard message envelope format."""

    def test_user_token_envelope(self):
        msg = json.dumps({"v": 1, "key": "abc123hash", "user_sub": "alice"})
        parsed = json.loads(msg)
        assert parsed["v"] == 1
        assert parsed["key"] == "abc123hash"

    def test_relay_session_envelope(self):
        msg = json.dumps({"v": 1, "key": "relay-state-xyz"})
        parsed = json.loads(msg)
        assert parsed["v"] == 1
        assert "user_sub" not in parsed or parsed.get("user_sub") is None

    def test_consent_tx_envelope(self):
        msg = json.dumps({"v": 1, "key": "uuid-1234"})
        parsed = json.loads(msg)
        assert parsed["v"] == 1

    def test_user_logout_envelope(self):
        msg = json.dumps({"v": 1, "key": "alice"})
        parsed = json.loads(msg)
        assert parsed["v"] == 1
        assert parsed["key"] == "alice"
