"""Tests for OAUTH_AUTHORIZE_RELAYED / OAUTH_AUTHORIZE_RELAY_FAILED audit emissions
in the traditional-client branch of oauth_authorize (RFC 8414 §3.3 work, prompt R5).

The CIMD and DCR branches already emit their own CIMD_* / DCR_AUTHORIZE_* events
and must NOT emit OAUTH_AUTHORIZE_RELAYED.
"""

import sys
from datetime import datetime, timezone
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from okta_agent_proxy.audit.events import AuditEventType, AuditSeverity
from okta_agent_proxy.auth.cimd_fetcher import CIMDMetadata
from okta_agent_proxy.auth.client_registry import ClientInfo


def _dcr_client_info(
    client_id="dcr_abc123",
    agent_config=None,
    redirect_uris=None,
):
    return ClientInfo(
        client_id=client_id,
        client_name="Test DCR Client",
        registration_source="dcr",
        redirect_uris=redirect_uris or ["http://localhost:9999/callback"],
        grant_types=["authorization_code"],
        response_types=["code"],
        token_endpoint_auth_method="none",
        jwks_uri=None,
        scope=None,
        trust_level=None,
        agent_config=agent_config,
        cimd_metadata=None,
        resource_access=[],
    )


def _cimd_client_info(client_id="https://example.com/oauth.json"):
    return ClientInfo(
        client_id=client_id,
        client_name="CIMD Client",
        registration_source="cimd",
        redirect_uris=["http://localhost:9999/callback"],
        grant_types=["authorization_code"],
        response_types=["code"],
        token_endpoint_auth_method="none",
        jwks_uri=None,
        scope=None,
        trust_level="trusted",
        agent_config={"client_id": "0oa_cimd", "client_secret": "cimd_secret"},
        cimd_metadata=CIMDMetadata(
            client_id=client_id,
            client_name="CIMD Client",
            redirect_uris=["http://localhost:9999/callback"],
            grant_types=["authorization_code"],
            response_types=["code"],
            token_endpoint_auth_method="none",
            jwks_uri=None,
            logo_uri=None,
            client_uri=None,
            scope=None,
            domain="example.com",
            fetched_at=datetime.now(timezone.utc),
            raw_json={},
        ),
        resource_access=[],
    )


def _mock_request(query_params=None):
    req = MagicMock()
    req.query_params = query_params or {}
    return req


def _ensure_app_imported():
    mod = sys.modules.get("okta_agent_proxy.app")
    if mod is not None and hasattr(mod, "client_registry"):
        return
    sys.modules.pop("okta_agent_proxy.app", None)

    import okta_agent_proxy.database as _db_mod
    _orig_get = _db_mod.get_config_store
    _orig_store = _db_mod._config_store
    _mock_store = MagicMock()
    _mock_store.get_all_resources.return_value = []
    _mock_store.get_all_agents.return_value = []
    _db_mod.get_config_store = lambda **kw: _mock_store
    _db_mod._config_store = _mock_store
    try:
        import importlib
        import okta_agent_proxy.app
        importlib.reload(okta_agent_proxy.app)
    except Exception:
        sys.modules.pop("okta_agent_proxy.app", None)
        raise
    finally:
        _db_mod.get_config_store = _orig_get
        _db_mod._config_store = _orig_store


@pytest.fixture
def patched():
    _ensure_app_imported()

    patches_to_start = [
        patch("okta_agent_proxy.app.client_registry"),
        patch("okta_agent_proxy.app.confidential_relay"),
        patch("okta_agent_proxy.app.dcr_handler"),
        patch("okta_agent_proxy.app.emit_audit_event", new_callable=AsyncMock),
        patch("okta_agent_proxy.app.cache_service"),
        patch("okta_agent_proxy.app.config"),
        patch("okta_agent_proxy.app.cimd_fetcher"),
    ]
    started = [p.start() for p in patches_to_start]
    mocks = {
        "registry": started[0],
        "relay": started[1],
        "dcr": started[2],
        "audit": started[3],
        "cache": started[4],
        "config": started[5],
        "cimd_fetcher": started[6],
    }

    mocks["registry"].resolve = AsyncMock(return_value=None)
    mocks["registry"]._resolve_dcr = MagicMock(return_value=None)
    mocks["registry"]._is_cimd_url = staticmethod(
        lambda cid: cid.startswith("https://") or cid.startswith("http://localhost")
    )
    mocks["relay"].start_authorization = AsyncMock(
        return_value="https://okta.example.com/authorize?x=1"
    )
    mocks["dcr"].get_selectable_agents = MagicMock(return_value=[])
    mocks["dcr"].link_to_agent = AsyncMock(return_value=(True, "Linked"))

    mocks["config"].gateway.okta_domain = "dev-test.okta.com"

    yield mocks

    for p in patches_to_start:
        p.stop()


def _get_authorize():
    from okta_agent_proxy.app import oauth_authorize
    return oauth_authorize


def _find_audit_calls(audit_mock, event_type):
    return [c for c in audit_mock.call_args_list if c[0][0] == event_type]


class TestOAuthAuthorizeRelayFailed:

    async def test_missing_client_id_emits_relay_failed(self, patched, monkeypatch):
        monkeypatch.delenv("OKTA_ISSUER", raising=False)
        authorize = _get_authorize()
        resp = await authorize(_mock_request(query_params={}))
        assert resp.status_code == 400
        calls = _find_audit_calls(
            patched["audit"], AuditEventType.OAUTH_AUTHORIZE_RELAY_FAILED
        )
        assert len(calls) == 1
        kwargs = calls[0][1]
        assert kwargs["severity"] == AuditSeverity.WARNING
        assert kwargs["outcome"] == "failure"

    async def test_relay_failed_payload_contains_error_fields(self, patched):
        authorize = _get_authorize()
        await authorize(_mock_request(query_params={}))
        calls = _find_audit_calls(
            patched["audit"], AuditEventType.OAUTH_AUTHORIZE_RELAY_FAILED
        )
        details = calls[0][1]["details"]
        assert details["error"] == "invalid_request"
        assert "client_id is required" in details["error_description"]

    async def test_relay_failed_payload_excludes_client_id(self, patched):
        authorize = _get_authorize()
        await authorize(_mock_request(query_params={}))
        calls = _find_audit_calls(
            patched["audit"], AuditEventType.OAUTH_AUTHORIZE_RELAY_FAILED
        )
        details = calls[0][1]["details"]
        assert "client_id" not in details


class TestOAuthAuthorizeRelayed:

    _TRADITIONAL_QS = {
        "client_id": "0oa_traditional_client",
        "redirect_uri": "https://app.example.com/cb?x=1",
        "state": "opaque-state-value",
        "scope": "openid offline_access",
        "response_type": "code",
        "code_challenge": "super-secret-pkce-value",
        "code_challenge_method": "S256",
        "resource": "https://rs.example.com/",
    }

    async def test_traditional_success_emits_relayed(self, patched, monkeypatch):
        monkeypatch.setenv("OKTA_ISSUER", "https://dev-test.okta.com/oauth2/default")
        authorize = _get_authorize()
        resp = await authorize(_mock_request(query_params=self._TRADITIONAL_QS))
        assert resp.status_code == 302
        calls = _find_audit_calls(
            patched["audit"], AuditEventType.OAUTH_AUTHORIZE_RELAYED
        )
        assert len(calls) == 1

    async def test_relayed_payload_contains_expected_fields(self, patched, monkeypatch):
        monkeypatch.setenv("OKTA_ISSUER", "https://dev-test.okta.com/oauth2/default")
        authorize = _get_authorize()
        await authorize(_mock_request(query_params=self._TRADITIONAL_QS))
        details = _find_audit_calls(
            patched["audit"], AuditEventType.OAUTH_AUTHORIZE_RELAYED
        )[0][1]["details"]
        assert details["client_id"] == "0oa_traditional_client"
        assert details["redirect_uri_host"] == "app.example.com"
        assert details["scope"] == "openid offline_access"
        assert details["resource"] == "https://rs.example.com/"
        assert details["upstream_authorize_url"] == (
            "https://dev-test.okta.com/oauth2/default/v1/authorize"
        )

    async def test_relayed_payload_excludes_code_challenge(self, patched, monkeypatch):
        monkeypatch.setenv("OKTA_ISSUER", "https://dev-test.okta.com/oauth2/default")
        authorize = _get_authorize()
        await authorize(_mock_request(query_params=self._TRADITIONAL_QS))
        details = _find_audit_calls(
            patched["audit"], AuditEventType.OAUTH_AUTHORIZE_RELAYED
        )[0][1]["details"]
        for key, value in details.items():
            assert "super-secret-pkce-value" not in str(value), (
                f"code_challenge leaked into {key}"
            )
        assert "code_challenge" not in details
        assert "code_challenge_method" not in details

    async def test_relayed_payload_excludes_state(self, patched, monkeypatch):
        monkeypatch.setenv("OKTA_ISSUER", "https://dev-test.okta.com/oauth2/default")
        authorize = _get_authorize()
        await authorize(_mock_request(query_params=self._TRADITIONAL_QS))
        details = _find_audit_calls(
            patched["audit"], AuditEventType.OAUTH_AUTHORIZE_RELAYED
        )[0][1]["details"]
        for key, value in details.items():
            assert "opaque-state-value" not in str(value), (
                f"state leaked into {key}"
            )
        assert "state" not in details

    async def test_relayed_redirect_uri_host_excludes_path_and_query(
        self, patched, monkeypatch
    ):
        monkeypatch.setenv("OKTA_ISSUER", "https://dev-test.okta.com/oauth2/default")
        authorize = _get_authorize()
        await authorize(_mock_request(query_params=self._TRADITIONAL_QS))
        details = _find_audit_calls(
            patched["audit"], AuditEventType.OAUTH_AUTHORIZE_RELAYED
        )[0][1]["details"]
        host = details["redirect_uri_host"]
        assert "/cb" not in host
        assert "?" not in host
        assert "x=1" not in host

    async def test_relayed_upstream_url_excludes_query_string(self, patched, monkeypatch):
        monkeypatch.setenv("OKTA_ISSUER", "https://dev-test.okta.com/oauth2/default")
        authorize = _get_authorize()
        await authorize(_mock_request(query_params=self._TRADITIONAL_QS))
        details = _find_audit_calls(
            patched["audit"], AuditEventType.OAUTH_AUTHORIZE_RELAYED
        )[0][1]["details"]
        upstream = details["upstream_authorize_url"]
        assert "?" not in upstream
        assert "client_id" not in upstream


class TestOAuthAuthorizeBranchIsolation:
    """CIMD and DCR branches MUST NOT emit OAUTH_AUTHORIZE_RELAYED."""

    async def test_cimd_client_does_not_emit_oauth_relayed(self, patched):
        cimd_info = _cimd_client_info()
        patched["registry"].resolve = AsyncMock(return_value=cimd_info)
        authorize = _get_authorize()
        resp = await authorize(_mock_request(query_params={
            "client_id": "https://example.com/oauth.json",
            "redirect_uri": "http://localhost:9999/callback",
            "state": "s",
            "scope": "openid",
            "response_type": "code",
        }))
        assert resp.status_code == 302
        assert _find_audit_calls(
            patched["audit"], AuditEventType.OAUTH_AUTHORIZE_RELAYED
        ) == []
        assert _find_audit_calls(
            patched["audit"], AuditEventType.OAUTH_AUTHORIZE_RELAY_FAILED
        ) == []

    async def test_dcr_linked_client_does_not_emit_oauth_relayed(self, patched):
        patched["registry"]._resolve_dcr.return_value = _dcr_client_info(
            agent_config={
                "agent_name": "dcr-dcr_abc123",
                "client_id": "0oa_real_client",
                "client_secret": "real_secret",
            },
        )
        authorize = _get_authorize()
        resp = await authorize(_mock_request(query_params={
            "client_id": "dcr_abc123",
            "redirect_uri": "http://localhost:9999/callback",
            "state": "s",
            "scope": "openid",
            "response_type": "code",
        }))
        assert resp.status_code == 302
        assert _find_audit_calls(
            patched["audit"], AuditEventType.OAUTH_AUTHORIZE_RELAYED
        ) == []
        dcr_calls = _find_audit_calls(
            patched["audit"], AuditEventType.DCR_AUTHORIZE_RELAYED
        )
        assert len(dcr_calls) == 1
