"""
Regression tests for CIMD resource access vulnerability fix.

Proves that CIMD clients do NOT get access to all resources by default.
Resource access is resolved via ClientRegistry trust-tier policies.

Tests:
- CIMD client does not get all resources (CRITICAL)
- Unknown domain gets zero tools by default
- Unknown domain with configured access
- Auto-provisioned agent with admin resource update
- Pre-registered agent takes precedence over CIMD policy
- tools/call respects CIMD resource access
- No client registry falls back to empty access
- Audit log includes trust info
"""

import pytest
import logging
from unittest.mock import MagicMock, AsyncMock, patch
from datetime import datetime, timezone

from okta_agent_proxy.mcp.unified_handler import UnifiedMCPHandler, NAMESPACE_SEPARATOR
from okta_agent_proxy.auth.client_registry import ClientRegistry, ClientInfo
from okta_agent_proxy.auth.cimd_fetcher import CIMDFetcher, CIMDMetadata
from okta_agent_proxy.auth.cimd_policy import CIMDTrustPolicy, TrustLevel


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

CIMD_URL = "https://myapp.example.com/oauth.json"
CIMD_TOKEN = "cimd-test-token-12345"


def _cimd_metadata(client_id=CIMD_URL):
    from urllib.parse import urlparse
    parsed = urlparse(client_id)
    return CIMDMetadata(
        client_id=client_id,
        client_name="Test CIMD App",
        redirect_uris=["http://localhost:8080/callback"],
        grant_types=["authorization_code"],
        response_types=["code"],
        token_endpoint_auth_method="none",
        jwks_uri=None,
        logo_uri=None,
        client_uri=None,
        scope="openid",
        domain=parsed.hostname or "",
        fetched_at=datetime.now(timezone.utc),
        raw_json={},
    )


def _mock_relay(client_id=CIMD_URL, user_id="user-123"):
    """Create a relay mock that returns cimd_info for the test token."""
    relay = MagicMock()
    relay.lookup_token.return_value = {
        "client_id": client_id,
        "user_id": user_id,
    }
    relay._sessions_by_token = {CIMD_TOKEN: True}
    return relay


def _mock_store(resources=None, agents=None):
    """Create a mock store with configurable resources and agents."""
    store = MagicMock()
    store.get_all_resources.return_value = resources or [
        {"name": "hr-system", "url": "http://hr:8001/mcp"},
        {"name": "finance-system", "url": "http://finance:8002/mcp"},
    ]
    store.get_all_agents.return_value = agents or []
    store.get_agent_by_name.return_value = None
    # No DCR support by default
    del store.get_dcr_registration
    return store


def _mock_client_registry(resource_access=None, trust_level="trusted",
                          agent_config=None):
    """Create a mock ClientRegistry that returns predetermined ClientInfo."""
    registry = MagicMock(spec=ClientRegistry)
    client_info = ClientInfo(
        client_id=CIMD_URL,
        client_name="Test CIMD App",
        registration_source="cimd",
        redirect_uris=["http://localhost:8080/callback"],
        grant_types=["authorization_code"],
        response_types=["code"],
        token_endpoint_auth_method="none",
        jwks_uri=None,
        scope="openid",
        trust_level=trust_level,
        agent_config=agent_config,
        cimd_metadata=_cimd_metadata(),
        resource_access=resource_access or [],
    )
    registry.resolve = AsyncMock(return_value=client_info)
    return registry


def _mock_validator():
    validator = MagicMock()
    validator.validate_token = AsyncMock(return_value=None)
    return validator


def _mock_router():
    router = MagicMock()
    return router


def _auth_headers():
    return {
        "authorization": f"Bearer {CIMD_TOKEN}",
        "content-type": "application/json",
    }


async def _authenticate(handler, headers=None):
    """Call _authenticate and return the result tuple."""
    return await handler._authenticate(headers or _auth_headers())


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------


class TestCIMDResourceAccessVulnerabilityFix:
    """Regression tests proving CIMD clients don't get access to all resources."""

    @pytest.mark.asyncio
    async def test_cimd_client_does_not_get_all_resources(self):
        """CRITICAL: CIMD client with trusted domain only gets configured resources,
        NOT all resources from the store."""
        store = _mock_store(resources=[
            {"name": "hr-system", "url": "http://hr:8001/mcp"},
            {"name": "finance-system", "url": "http://finance:8002/mcp"},
            {"name": "payroll-system", "url": "http://payroll:8003/mcp"},
        ])
        relay = _mock_relay()
        registry = _mock_client_registry(resource_access=["hr-system"])

        handler = UnifiedMCPHandler(
            _mock_router(), _mock_validator(), store,
            relay=relay, client_registry=registry,
        )

        result = await _authenticate(handler)
        assert result is not None
        agent_id, agent_config, user_id, token = result

        assert agent_config["resource_access"] == ["hr-system"]
        assert "finance-system" not in agent_config["resource_access"]
        assert "payroll-system" not in agent_config["resource_access"]

        # Store.get_all_resources should NOT have been called for access decisions
        store.get_all_resources.assert_not_called()

    @pytest.mark.asyncio
    async def test_unknown_domain_gets_zero_tools(self):
        """Unknown domain with no CIMD_UNKNOWN_RESOURCE_ACCESS gets empty resource_access."""
        relay = _mock_relay()
        registry = _mock_client_registry(
            resource_access=[],
            trust_level="unknown",
        )

        handler = UnifiedMCPHandler(
            _mock_router(), _mock_validator(), _mock_store(),
            relay=relay, client_registry=registry,
        )

        result = await _authenticate(handler)
        assert result is not None
        _, agent_config, _, _ = result
        assert agent_config["resource_access"] == []

    @pytest.mark.asyncio
    async def test_unknown_domain_with_configured_access(self):
        """Unknown domain with CIMD_UNKNOWN_RESOURCE_ACCESS=hr-system gets hr-system."""
        relay = _mock_relay()
        registry = _mock_client_registry(
            resource_access=["hr-system"],
            trust_level="unknown",
        )

        handler = UnifiedMCPHandler(
            _mock_router(), _mock_validator(), _mock_store(),
            relay=relay, client_registry=registry,
        )

        result = await _authenticate(handler)
        assert result is not None
        _, agent_config, _, _ = result
        assert agent_config["resource_access"] == ["hr-system"]

    @pytest.mark.asyncio
    async def test_auto_provisioned_agent_admin_adds_resource(self):
        """Auto-provisioned agent's resource access can be updated by admin."""
        relay = _mock_relay()
        # Simulate: agent was auto-provisioned with hr-system,
        # admin later added finance-system via Admin API.
        agent_record = {
            "agent_id": "cimd-test-app-abc12345",
            "client_id": CIMD_URL,
            "resource_access": ["hr-system", "finance-system"],
            "enabled": True,
        }
        registry = _mock_client_registry(
            resource_access=["hr-system", "finance-system"],
            trust_level="trusted",
            agent_config=agent_record,
        )

        handler = UnifiedMCPHandler(
            _mock_router(), _mock_validator(), _mock_store(),
            relay=relay, client_registry=registry,
        )

        result = await _authenticate(handler)
        assert result is not None
        agent_id, agent_config, _, _ = result

        # Should use the agent record from DB (admin-configured)
        assert agent_config == agent_record
        assert agent_config["resource_access"] == ["hr-system", "finance-system"]
        assert agent_id == "cimd-test-app-abc12345"

    @pytest.mark.asyncio
    async def test_pre_registered_agent_takes_precedence(self):
        """Pre-registered agent with matching client_id uses DB resource access,
        not CIMD policy env var."""
        relay = _mock_relay()
        # ClientRegistry returns manual registration with DB-configured access
        agent_record = {
            "agent_id": "my-registered-agent",
            "client_id": CIMD_URL,
            "resource_access": ["finance-system"],
            "enabled": True,
        }
        registry = MagicMock(spec=ClientRegistry)
        client_info = ClientInfo(
            client_id=CIMD_URL,
            client_name="Registered App",
            registration_source="manual",
            redirect_uris=[],
            grant_types=["authorization_code"],
            response_types=["code"],
            token_endpoint_auth_method="client_secret_basic",
            jwks_uri=None,
            scope=None,
            trust_level=None,
            agent_config=agent_record,
            cimd_metadata=None,
            resource_access=["finance-system"],
        )
        registry.resolve = AsyncMock(return_value=client_info)

        handler = UnifiedMCPHandler(
            _mock_router(), _mock_validator(), _mock_store(),
            relay=relay, client_registry=registry,
        )

        result = await _authenticate(handler)
        assert result is not None
        agent_id, agent_config, _, _ = result

        assert agent_config["resource_access"] == ["finance-system"]
        assert "hr-system" not in agent_config["resource_access"]
        assert agent_id == "my-registered-agent"

    @pytest.mark.asyncio
    async def test_tools_call_respects_cimd_resource_access(self):
        """tools/call rejects access to resource not in CIMD client's resource access."""
        relay = _mock_relay()
        registry = _mock_client_registry(resource_access=["hr-system"])

        handler = UnifiedMCPHandler(
            _mock_router(), _mock_validator(), _mock_store(),
            relay=relay, client_registry=registry,
        )

        # Authenticate first
        auth_result = await _authenticate(handler)
        assert auth_result is not None
        agent_id, agent_config, user_id, token = auth_result

        # Try to call a tool on finance-system (not in resource access list)
        params = {
            "name": f"finance-system{NAMESPACE_SEPARATOR}get_report",
            "arguments": {},
        }

        response, status, resp_headers = await handler._handle_tools_call(
            "1", params, agent_id, agent_config, user_id, token
        )

        # Should get an error about access denied
        assert "error" in response
        assert "does not have access" in response["error"]["message"]

    @pytest.mark.asyncio
    async def test_no_client_registry_falls_back_to_empty(self):
        """When client_registry=None, CIMD clients get empty resource access (safe default)."""
        relay = _mock_relay()

        handler = UnifiedMCPHandler(
            _mock_router(), _mock_validator(), _mock_store(),
            relay=relay, client_registry=None,  # No registry
        )

        result = await _authenticate(handler)
        assert result is not None
        _, agent_config, _, _ = result
        assert agent_config["resource_access"] == []

    @pytest.mark.asyncio
    async def test_audit_log_includes_trust_info(self, caplog):
        """CIMD authentication logs include trust-related information."""
        relay = _mock_relay()
        registry = _mock_client_registry(
            resource_access=["hr-system"],
            trust_level="trusted",
        )

        handler = UnifiedMCPHandler(
            _mock_router(), _mock_validator(), _mock_store(),
            relay=relay, client_registry=registry,
        )

        with caplog.at_level(logging.INFO):
            result = await _authenticate(handler)

        assert result is not None
        # Should log the CIMD authentication
        log_text = caplog.text
        assert "CIMD token authenticated" in log_text
        assert CIMD_URL in log_text

    @pytest.mark.asyncio
    async def test_client_registry_error_falls_back_to_empty(self):
        """If ClientRegistry.resolve() throws, CIMD client gets empty access."""
        relay = _mock_relay()
        registry = MagicMock(spec=ClientRegistry)
        registry.resolve = AsyncMock(side_effect=Exception("registry down"))

        handler = UnifiedMCPHandler(
            _mock_router(), _mock_validator(), _mock_store(),
            relay=relay, client_registry=registry,
        )

        result = await _authenticate(handler)
        assert result is not None
        _, agent_config, _, _ = result
        assert agent_config["resource_access"] == []

    @pytest.mark.asyncio
    async def test_client_registry_returns_none_falls_back_to_empty(self):
        """If ClientRegistry.resolve() returns None (blocked), CIMD gets empty access."""
        relay = _mock_relay()
        registry = MagicMock(spec=ClientRegistry)
        registry.resolve = AsyncMock(return_value=None)

        handler = UnifiedMCPHandler(
            _mock_router(), _mock_validator(), _mock_store(),
            relay=relay, client_registry=registry,
        )

        result = await _authenticate(handler)
        assert result is not None
        _, agent_config, _, _ = result
        assert agent_config["resource_access"] == []
