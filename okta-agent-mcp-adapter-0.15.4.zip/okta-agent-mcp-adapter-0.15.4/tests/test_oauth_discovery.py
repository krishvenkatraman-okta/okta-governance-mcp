"""Tests for RFC 8414 §3.3 compliance in OAuth Authorization Server discovery.

Validates:
- oauth_authorization_server (root) returns issuer == GATEWAY_BASE_URL
- oauth_authorization_server_by_name ({resource}) returns issuer == GATEWAY_BASE_URL
- All advertised endpoints live under GATEWAY_BASE_URL (no Okta domain leakage)
- RFC 8414 §3.3 byte-identity: PRM.authorization_servers[0] == AS metadata.issuer
- OAUTH_DISCOVERY_SERVED audit emission on both handlers
"""

import json
import sys
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from okta_agent_proxy.audit.events import AuditEventType


GATEWAY_BASE_URL = "http://localhost:8000"
OKTA_DOMAIN = "dev-test.okta.com"


# ---------------------------------------------------------------------------
# App import + patching fixtures (mirrors test_dcr_authorize_flow.py pattern)
# ---------------------------------------------------------------------------

def _ensure_app_imported():
    """Ensure okta_agent_proxy.app is fully importable by mocking the DB if needed."""
    mod = sys.modules.get("okta_agent_proxy.app")
    if mod is not None and hasattr(mod, "oauth_authorization_server"):
        return

    sys.modules.pop("okta_agent_proxy.app", None)

    import okta_agent_proxy.database as _db_mod
    _orig_get = _db_mod.get_config_store
    _orig_store = _db_mod._config_store
    _mock_store = MagicMock()
    _mock_store.get_all_resources.return_value = []
    _mock_store.get_all_agents.return_value = []
    _db_mod.get_config_store = lambda **kw: _mock_store
    _db_mod._config_store = _mock_store
    try:
        import importlib
        import okta_agent_proxy.app
        importlib.reload(okta_agent_proxy.app)
    except Exception:
        sys.modules.pop("okta_agent_proxy.app", None)
        raise
    finally:
        _db_mod.get_config_store = _orig_get
        _db_mod._config_store = _orig_store


@pytest.fixture
def patched(monkeypatch):
    """Patch app-level deps so we can call the handlers directly."""
    _ensure_app_imported()

    # oauth_protected_resource reads GATEWAY_BASE_URL from env; align it so
    # the §3.3 byte-identity contract can be asserted without drift.
    monkeypatch.setenv("GATEWAY_BASE_URL", GATEWAY_BASE_URL)
    monkeypatch.setenv("OKTA_ISSUER", f"https://{OKTA_DOMAIN}")

    patches = [
        patch("okta_agent_proxy.app.emit_audit_event", new_callable=AsyncMock),
        patch("okta_agent_proxy.app.config"),
        patch("okta_agent_proxy.app.router"),
    ]

    started = [p.start() for p in patches]
    mocks = {
        "audit": started[0],
        "config": started[1],
        "router": started[2],
    }

    mocks["config"].gateway.gateway_base_url = GATEWAY_BASE_URL
    mocks["config"].gateway.okta_domain = OKTA_DOMAIN
    mocks["router"].get_resource_for_path = MagicMock(return_value=None)
    mocks["router"].resolve_resource = MagicMock(return_value=None)

    yield mocks

    for p in patches:
        p.stop()


def _mock_request(
    path_params=None,
    client_host="1.2.3.4",
    user_agent="pytest-ua/1.0",
    extra_headers=None,
):
    req = MagicMock()
    req.path_params = path_params or {}
    req.client = MagicMock()
    req.client.host = client_host
    headers_map = {"user-agent": user_agent}
    for k, v in (extra_headers or {}).items():
        headers_map[k.lower()] = v
    headers = MagicMock()
    headers.get = MagicMock(side_effect=lambda k, d="": headers_map.get(k.lower(), d))
    req.headers = headers
    return req


async def _call_handler(handler_name, request):
    from okta_agent_proxy import app as _app
    handler = getattr(_app, handler_name)
    response = await handler(request)
    body = json.loads(bytes(response.body).decode("utf-8"))
    return response, body


# ---------------------------------------------------------------------------
# oauth_authorization_server (root)
# ---------------------------------------------------------------------------

class TestRootDiscoveryHandler:

    async def test_issuer_equals_gateway_base_url(self, patched):
        """§3.3: issuer MUST be GATEWAY_BASE_URL, not Okta."""
        _, body = await _call_handler("oauth_authorization_server", _mock_request())
        assert body["issuer"] == GATEWAY_BASE_URL

    async def test_all_endpoints_under_gateway_base_url(self, patched):
        _, body = await _call_handler("oauth_authorization_server", _mock_request())
        for field in (
            "authorization_endpoint",
            "token_endpoint",
            "jwks_uri",
            "registration_endpoint",
        ):
            assert body[field].startswith(GATEWAY_BASE_URL), f"{field} not under gateway: {body[field]}"

    async def test_no_okta_domain_in_response(self, patched):
        _, body = await _call_handler("oauth_authorization_server", _mock_request())
        serialized = json.dumps(body)
        assert OKTA_DOMAIN not in serialized, f"Okta domain leaked: {serialized}"

    async def test_code_challenge_s256_advertised(self, patched):
        _, body = await _call_handler("oauth_authorization_server", _mock_request())
        assert "S256" in body["code_challenge_methods_supported"]

    async def test_client_id_metadata_document_supported_true(self, patched):
        _, body = await _call_handler("oauth_authorization_server", _mock_request())
        assert body["client_id_metadata_document_supported"] is True

    async def test_response_status_and_content_type(self, patched):
        response, _ = await _call_handler("oauth_authorization_server", _mock_request())
        assert response.status_code == 200
        assert response.headers["content-type"].startswith("application/json")

    async def test_discovery_served_audit_event_emitted(self, patched):
        await _call_handler("oauth_authorization_server", _mock_request())
        patched["audit"].assert_called_once()
        call_args = patched["audit"].call_args
        assert call_args.args[0] == AuditEventType.OAUTH_DISCOVERY_SERVED
        details = call_args.kwargs["details"]
        assert details["endpoint"] == "oauth-authorization-server"
        assert details["issuer"] == GATEWAY_BASE_URL
        assert details["client_ip"] == "1.2.3.4"
        assert details["user_agent"] == "pytest-ua/1.0"


# ---------------------------------------------------------------------------
# oauth_authorization_server_by_name ({resource})
# ---------------------------------------------------------------------------

class TestPerResourceDiscoveryHandler:

    async def test_issuer_equals_gateway_base_url(self, patched):
        patched["router"].get_resource_for_path.return_value = "hr"
        _, body = await _call_handler(
            "oauth_authorization_server_by_name",
            _mock_request(path_params={"resource": "hr"}),
        )
        assert body["issuer"] == GATEWAY_BASE_URL

    async def test_authorization_endpoint_points_at_gateway(self, patched):
        patched["router"].get_resource_for_path.return_value = "hr"
        _, body = await _call_handler(
            "oauth_authorization_server_by_name",
            _mock_request(path_params={"resource": "hr"}),
        )
        # authorization_endpoint includes a scope query param; split before "?"
        assert body["authorization_endpoint"].startswith(f"{GATEWAY_BASE_URL}/oauth/authorize")

    async def test_jwks_uri_points_at_gateway(self, patched):
        patched["router"].get_resource_for_path.return_value = "hr"
        _, body = await _call_handler(
            "oauth_authorization_server_by_name",
            _mock_request(path_params={"resource": "hr"}),
        )
        assert body["jwks_uri"] == f"{GATEWAY_BASE_URL}/oauth2/v1/keys"

    async def test_no_okta_domain_in_response(self, patched):
        patched["router"].get_resource_for_path.return_value = "hr"
        _, body = await _call_handler(
            "oauth_authorization_server_by_name",
            _mock_request(path_params={"resource": "hr"}),
        )
        serialized = json.dumps(body)
        assert OKTA_DOMAIN not in serialized, f"Okta domain leaked: {serialized}"

    async def test_code_challenge_s256_advertised(self, patched):
        patched["router"].get_resource_for_path.return_value = "hr"
        _, body = await _call_handler(
            "oauth_authorization_server_by_name",
            _mock_request(path_params={"resource": "hr"}),
        )
        assert "S256" in body["code_challenge_methods_supported"]

    async def test_response_status_and_content_type(self, patched):
        patched["router"].get_resource_for_path.return_value = "hr"
        response, _ = await _call_handler(
            "oauth_authorization_server_by_name",
            _mock_request(path_params={"resource": "hr"}),
        )
        assert response.status_code == 200
        assert response.headers["content-type"].startswith("application/json")

    async def test_discovery_served_audit_event_with_resource_path(self, patched):
        patched["router"].get_resource_for_path.return_value = "hr"
        await _call_handler(
            "oauth_authorization_server_by_name",
            _mock_request(path_params={"resource": "hr"}),
        )
        patched["audit"].assert_called_once()
        call_args = patched["audit"].call_args
        assert call_args.args[0] == AuditEventType.OAUTH_DISCOVERY_SERVED
        details = call_args.kwargs["details"]
        assert details["endpoint"] == "oauth-authorization-server-by-name"
        assert details["issuer"] == GATEWAY_BASE_URL
        assert details["resource_path"] == "/hr"


# ---------------------------------------------------------------------------
# §3.3 byte-identity contract: PRM ↔ AS metadata
# ---------------------------------------------------------------------------

class TestByteIdentityContract:

    async def test_prm_authorization_servers_byte_matches_as_issuer(self, patched):
        """RFC 8414 §3.3: PRM.authorization_servers[0] MUST byte-equal AS.issuer."""
        # Root AS metadata
        _, as_body = await _call_handler(
            "oauth_authorization_server", _mock_request()
        )
        # PRM
        _, prm_body = await _call_handler(
            "oauth_protected_resource", _mock_request()
        )
        assert prm_body["authorization_servers"][0] == as_body["issuer"]
        assert prm_body["authorization_servers"][0] == GATEWAY_BASE_URL


# ---------------------------------------------------------------------------
# scopes_supported advertisement (RFC 9728 discovery of per-resource scopes)
# ---------------------------------------------------------------------------

class TestScopesSupportedAdvertisement:
    """Per-resource and per-agent scopes flow into scopes_supported so MCP
    clients can discover what the target resource requires and request it.
    """

    def _resource_stub(self, scopes, url="https://agentcore.example.com"):
        stub = MagicMock()
        stub.scopes = scopes
        stub.url = url
        return stub

    def _syncer_with(self, resources_by_name):
        """Build a fake syncer that returns the given resources.

        resources_by_name maps resource_name -> resource stub. The stub's
        agent_id attribute drives per-agent filtering; set it via MagicMock.
        """
        syncer = MagicMock()
        syncer.get_all_resolved_resources_raw = MagicMock(return_value=resources_by_name)
        syncer.get_resolved_resources_for_agent = MagicMock(
            side_effect=lambda aid: {
                name: res for name, res in resources_by_name.items()
                if getattr(res, "agent_id", None) in (aid, None)
            }
        )
        return syncer

    async def test_per_resource_advertises_resource_scopes(self, patched, monkeypatch):
        resource = self._resource_stub(["bedrock:InvokeAgent"])
        patched["router"].get_resource_for_path.return_value = "agentcore"
        patched["router"].resolve_resource.return_value = resource

        _, body = await _call_handler(
            "oauth_protected_resource_by_name",
            _mock_request(path_params={"resource": "agentcore"}),
        )

        # Baseline OIDC scopes are always present + the configured resource scope.
        assert "bedrock:InvokeAgent" in body["scopes_supported"]
        assert "openid" in body["scopes_supported"]
        assert "offline_access" in body["scopes_supported"]

    async def test_per_resource_omits_scope_when_resource_has_none(self, patched):
        resource = self._resource_stub([])
        patched["router"].get_resource_for_path.return_value = "agentcore"
        patched["router"].resolve_resource.return_value = resource

        _, body = await _call_handler(
            "oauth_protected_resource_by_name",
            _mock_request(path_params={"resource": "agentcore"}),
        )

        # Only baseline OIDC scopes — no fabricated customer scopes.
        assert sorted(body["scopes_supported"]) == ["offline_access", "openid"]

    async def test_unified_endpoint_with_agent_header_emits_agent_union(
        self, patched, monkeypatch
    ):
        res_a = self._resource_stub(["repo:read"])
        res_a.agent_id = "claude-code"
        res_b = self._resource_stub(["bedrock:InvokeAgent"])
        res_b.agent_id = "cursor"

        syncer = self._syncer_with({"repo": res_a, "agentcore": res_b})
        monkeypatch.setattr(
            "okta_agent_proxy.app.get_resource_syncer", lambda: syncer
        )

        store_mock = MagicMock()
        store_mock.get_agent_by_name.return_value = {"agent_id": "claude-code"}
        monkeypatch.setattr("okta_agent_proxy.app.store", store_mock)

        _, body = await _call_handler(
            "oauth_protected_resource",
            _mock_request(extra_headers={"X-MCP-Agent": "claude-code"}),
        )

        assert "repo:read" in body["scopes_supported"]
        # Cursor's scope is NOT advertised to claude-code.
        assert "bedrock:InvokeAgent" not in body["scopes_supported"]

    async def test_unified_endpoint_without_agent_header_emits_global_union(
        self, patched, monkeypatch
    ):
        res_a = self._resource_stub(["repo:read"])
        res_a.agent_id = "claude-code"
        res_b = self._resource_stub(["bedrock:InvokeAgent"])
        res_b.agent_id = "cursor"

        syncer = self._syncer_with({"repo": res_a, "agentcore": res_b})
        monkeypatch.setattr(
            "okta_agent_proxy.app.get_resource_syncer", lambda: syncer
        )

        _, body = await _call_handler(
            "oauth_protected_resource", _mock_request()
        )

        # No agent scoping → advertise everything configured.
        assert "repo:read" in body["scopes_supported"]
        assert "bedrock:InvokeAgent" in body["scopes_supported"]
        assert "openid" in body["scopes_supported"]


# ---------------------------------------------------------------------------
# Global Logout endpoint advertisement (P8)
# ---------------------------------------------------------------------------


class TestGlobalTokenRevocationAdvertisement:

    async def test_metadata_advertises_global_token_revocation_endpoint(self, patched):
        _, body = await _call_handler(
            "oauth_authorization_server", _mock_request()
        )
        assert "global_token_revocation_endpoint" in body
        assert body["global_token_revocation_endpoint"].endswith(
            "/oauth/global-token-revocation"
        )
        # RFC 8414 §3.3: issuer byte-matches GATEWAY_BASE_URL, and the
        # revocation endpoint is built from the same gateway_base — so the
        # endpoint starts with the advertised issuer.
        assert body["global_token_revocation_endpoint"].startswith(body["issuer"])

    async def test_metadata_by_name_advertises_global_token_revocation_endpoint(
        self, patched
    ):
        patched["router"].get_resource_for_path.return_value = "hr"
        _, body = await _call_handler(
            "oauth_authorization_server_by_name",
            _mock_request(path_params={"resource": "hr"}),
        )
        assert "global_token_revocation_endpoint" in body
        assert body["global_token_revocation_endpoint"].endswith(
            "/oauth/global-token-revocation"
        )
