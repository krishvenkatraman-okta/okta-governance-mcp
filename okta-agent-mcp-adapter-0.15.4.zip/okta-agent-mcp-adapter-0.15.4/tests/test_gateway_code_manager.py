"""
Tests for GatewayCodeManager.

Unit tests for the gateway authorization code lifecycle:
issue, exchange, token tracking, error conditions.
Also: CacheService (L2) cross-instance tests.
"""

import os
import pytest
from datetime import datetime, timezone, timedelta

from okta_agent_proxy.auth.gateway_code_manager import (
    GatewayCodeManager,
    GatewayCodeNotFound,
    GatewayCodeExpired,
    GatewayCodeClientMismatch,
    _CODE_PREFIX,
    _TOKEN_PREFIX,
)
from okta_agent_proxy.cache.cache_service import CacheService
from okta_agent_proxy.cache.memory_provider import MemoryCacheProvider


CLIENT_ID = "https://myapp.example.com/oauth.json"


def _make_tokens(**overrides):
    defaults = {
        "access_token": "at_test123",
        "id_token": "idt_test123",
        "refresh_token": "rt_test123",
        "expires_in": 3600,
    }
    defaults.update(overrides)
    return defaults


class TestGatewayCodeManager:
    def test_issue_code_returns_64_char_hex(self):
        mgr = GatewayCodeManager()
        code = mgr.issue_code(CLIENT_ID, _make_tokens())
        assert len(code) == 64
        assert all(c in "0123456789abcdef" for c in code)

    def test_exchange_code_returns_tokens(self):
        mgr = GatewayCodeManager()
        code = mgr.issue_code(CLIENT_ID, _make_tokens())

        result = mgr.exchange_code(code, CLIENT_ID)

        assert result["access_token"] == "at_test123"
        assert result["id_token"] == "idt_test123"
        assert result["refresh_token"] == "rt_test123"
        assert result["token_type"] == "Bearer"
        assert result["expires_in"] == 3600

    def test_exchange_code_one_time_use(self):
        mgr = GatewayCodeManager()
        code = mgr.issue_code(CLIENT_ID, _make_tokens())

        mgr.exchange_code(code, CLIENT_ID)

        with pytest.raises(GatewayCodeNotFound):
            mgr.exchange_code(code, CLIENT_ID)

    def test_exchange_code_client_mismatch(self):
        mgr = GatewayCodeManager()
        code = mgr.issue_code(CLIENT_ID, _make_tokens())

        with pytest.raises(GatewayCodeClientMismatch, match="client_id mismatch"):
            mgr.exchange_code(code, "https://wrong.example.com/oauth.json")

    def test_exchange_code_expired(self):
        mgr = GatewayCodeManager()
        code = mgr.issue_code(CLIENT_ID, _make_tokens(), ttl_seconds=300)

        # Expire the session by backdating created_at
        session = mgr._sessions_by_code[code]
        session.created_at = datetime.now(timezone.utc) - timedelta(seconds=600)

        with pytest.raises(GatewayCodeExpired):
            mgr.exchange_code(code, CLIENT_ID)

    def test_exchange_code_unknown(self):
        mgr = GatewayCodeManager()

        with pytest.raises(GatewayCodeNotFound):
            mgr.exchange_code("nonexistent_code", CLIENT_ID)

    def test_exchange_tracks_token(self):
        mgr = GatewayCodeManager()
        code = mgr.issue_code(CLIENT_ID, _make_tokens())

        mgr.exchange_code(code, CLIENT_ID)

        info = mgr.lookup_token("at_test123")
        assert info is not None
        assert info["client_id"] == CLIENT_ID

    def test_lookup_token_unknown(self):
        mgr = GatewayCodeManager()
        assert mgr.lookup_token("nonexistent") is None

    def test_track_token(self):
        mgr = GatewayCodeManager()
        mgr.track_token("manual_token", CLIENT_ID, id_token="idt", relay_client_id="rc")

        info = mgr.lookup_token("manual_token")
        assert info is not None
        assert info["client_id"] == CLIENT_ID
        assert info["id_token"] == "idt"
        assert info["relay_client_id"] == "rc"

    def test_extra_metadata_preserved(self):
        mgr = GatewayCodeManager()
        extra = {"relay_client_id": "rc_123", "relay_client_secret": "rs_456"}
        code = mgr.issue_code(CLIENT_ID, _make_tokens(), extra=extra)

        mgr.exchange_code(code, CLIENT_ID)

        info = mgr.lookup_token("at_test123")
        assert info is not None
        assert info["relay_client_id"] == "rc_123"
        assert info["relay_client_secret"] == "rs_456"

    def test_issue_code_with_partial_tokens(self):
        mgr = GatewayCodeManager()
        tokens = {"access_token": "at_only"}
        code = mgr.issue_code(CLIENT_ID, tokens)

        result = mgr.exchange_code(code, CLIENT_ID)

        assert result["access_token"] == "at_only"
        assert result["token_type"] == "Bearer"
        # No refresh_token or expires_in in result when not provided
        assert "refresh_token" not in result
        assert "expires_in" not in result


# ---------------------------------------------------------------------------
# CacheService (L2) cross-instance tests
# ---------------------------------------------------------------------------

def _shared_cache_service():
    provider = MemoryCacheProvider(max_size=1000, default_ttl=3600)
    return CacheService(l2_provider=provider)


class TestGatewayCodeManagerCacheService:
    @pytest.mark.asyncio
    async def test_aissue_on_a_aexchange_on_b(self):
        """Code issued on instance A can be exchanged on instance B."""
        svc = _shared_cache_service()
        mgr_a = GatewayCodeManager(cache_service=svc)
        mgr_b = GatewayCodeManager(cache_service=svc)

        code = await mgr_a.aissue_code(CLIENT_ID, _make_tokens())

        # Clear B's L1 to prove it reads from L2
        mgr_b._sessions_by_code.clear()

        result = await mgr_b.aexchange_code(code, CLIENT_ID)
        assert result["access_token"] == "at_test123"
        assert result["token_type"] == "Bearer"

        # Second exchange should fail (single-use).
        # Clear A's L1 to simulate separate pod (code was deleted from L2 by B).
        mgr_a._sessions_by_code.clear()
        with pytest.raises(GatewayCodeNotFound):
            await mgr_a.aexchange_code(code, CLIENT_ID)

    @pytest.mark.asyncio
    async def test_atrack_token_on_a_alookup_on_b(self):
        """Token tracked on instance A is visible on instance B."""
        svc = _shared_cache_service()
        mgr_a = GatewayCodeManager(cache_service=svc)
        mgr_b = GatewayCodeManager(cache_service=svc)

        await mgr_a.atrack_token("at_cross", CLIENT_ID, id_token="idt_cross")

        # Clear B's L1
        mgr_b._sessions_by_token.clear()

        info = await mgr_b.alookup_token("at_cross")
        assert info is not None
        assert info["client_id"] == CLIENT_ID
        assert info["id_token"] == "idt_cross"

    @pytest.mark.asyncio
    async def test_encrypted_mode_hides_access_token(self):
        """With encryption, stored bytes don't contain access_token plaintext."""
        from okta_agent_proxy.crypto.encryption import EncryptionService
        enc = EncryptionService(os.urandom(32))
        provider = MemoryCacheProvider(max_size=100, default_ttl=3600)
        svc = CacheService(l2_provider=provider)
        mgr = GatewayCodeManager(cache_service=svc, encryption_service=enc)

        code = await mgr.aissue_code(CLIENT_ID, _make_tokens())

        # Check raw L2 content
        raw = await provider.get(f"{_CODE_PREFIX}{code}")
        assert raw is not None
        assert "at_test123" not in raw

        # But exchange still works
        result = await mgr.aexchange_code(code, CLIENT_ID)
        assert result["access_token"] == "at_test123"

    @pytest.mark.asyncio
    async def test_sync_api_raises_with_cache_service(self):
        """Sync API methods raise RuntimeError when cache_service is set."""
        svc = _shared_cache_service()
        mgr = GatewayCodeManager(cache_service=svc)

        with pytest.raises(RuntimeError, match="sync API requires"):
            mgr.issue_code(CLIENT_ID, _make_tokens())

        with pytest.raises(RuntimeError, match="sync API requires"):
            mgr.exchange_code("x", CLIENT_ID)

    @pytest.mark.asyncio
    async def test_aexchange_code_expired(self):
        svc = _shared_cache_service()
        mgr = GatewayCodeManager(cache_service=svc)
        code = await mgr.aissue_code(CLIENT_ID, _make_tokens(), ttl_seconds=300)

        # Expire by backdating created_at in L1
        session = mgr._sessions_by_code[code]
        session.created_at = datetime.now(timezone.utc) - timedelta(seconds=600)

        with pytest.raises(GatewayCodeExpired):
            await mgr.aexchange_code(code, CLIENT_ID)

    @pytest.mark.asyncio
    async def test_aexchange_code_client_mismatch(self):
        svc = _shared_cache_service()
        mgr = GatewayCodeManager(cache_service=svc)
        code = await mgr.aissue_code(CLIENT_ID, _make_tokens())

        with pytest.raises(GatewayCodeClientMismatch):
            await mgr.aexchange_code(code, "https://wrong.example.com/oauth.json")
