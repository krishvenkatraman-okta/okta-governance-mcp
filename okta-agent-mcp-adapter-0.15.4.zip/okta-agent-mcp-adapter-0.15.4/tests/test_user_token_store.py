"""
Tests for the UserTokenStore — server-side access_token → OIDC token mapping.

Tests:
- Store and lookup by access_token
- Lookup with wrong/missing token returns None
- Update id_token only (refresh_token preserved)
- Update refresh_token only (id_token preserved)
- Remove entry
- Remove by user_sub (bulk)
- Cache key is SHA-256 hash, not raw token
- Encrypted storage (encrypt on store, decrypt on lookup)
- get_stats returns correct counts
- TTL expiry
"""

import asyncio
import hashlib
import json
import time
import pytest
from unittest.mock import MagicMock, patch

from okta_agent_proxy.auth.user_token_store import (
    UserTokenStore,
    get_user_token_store,
    reset_user_token_store,
)


# ============================================================================
# Fixtures
# ============================================================================


@pytest.fixture
def store():
    """Plain (unencrypted) UserTokenStore."""
    return UserTokenStore(encryption_service=None, default_ttl=86400, max_size=1000)


@pytest.fixture
def mock_encryption_service():
    """Mock encryption service that round-trips correctly."""
    enc = MagicMock()
    enc.encrypt.side_effect = lambda plaintext: (
        plaintext.encode() if isinstance(plaintext, str) else plaintext,
        b"\x00" * 12,  # iv
        b"\x00" * 16,  # tag
    )
    enc.decrypt.side_effect = lambda ciphertext, iv, tag: (
        ciphertext.decode() if isinstance(ciphertext, bytes) else ciphertext
    )
    return enc


@pytest.fixture
def encrypted_store(mock_encryption_service):
    """UserTokenStore with encryption enabled."""
    return UserTokenStore(
        encryption_service=mock_encryption_service,
        default_ttl=86400,
        max_size=1000,
    )


# ============================================================================
# Store & Lookup
# ============================================================================


class TestStoreAndLookup:
    def test_store_and_lookup(self, store):
        """Store a mapping, look it up by the same access_token, verify all fields."""
        store.store(
            access_token="at-abc-123",
            id_token="eyJ.id.xyz",
            refresh_token="rt-xyz-789",
            user_sub="user@example.com",
            agent_id="claude-code",
            expires_in=3600,
        )
        result = store.lookup("at-abc-123")
        assert result is not None
        assert result["id_token"] == "eyJ.id.xyz"
        assert result["refresh_token"] == "rt-xyz-789"
        assert result["user_sub"] == "user@example.com"
        assert result["agent_id"] == "claude-code"
        assert result["expires_in"] == 3600
        assert "stored_at" in result

    def test_lookup_wrong_token(self, store):
        """Lookup with a different access_token returns None."""
        store.store(
            access_token="at-correct",
            id_token="id1",
            refresh_token="rt1",
            user_sub="u1",
            agent_id="a1",
        )
        assert store.lookup("at-wrong") is None

    def test_lookup_missing(self, store):
        """Lookup with an unknown token returns None."""
        assert store.lookup("nonexistent-token") is None

    def test_multiple_entries(self, store):
        """Different access_tokens map to different entries."""
        store.store("at-1", "id-1", "rt-1", "u1", "a1")
        store.store("at-2", "id-2", "rt-2", "u2", "a1")
        store.store("at-3", "id-3", "rt-3", "u1", "a2")

        r1 = store.lookup("at-1")
        r2 = store.lookup("at-2")
        r3 = store.lookup("at-3")
        assert r1["id_token"] == "id-1"
        assert r2["id_token"] == "id-2"
        assert r3["id_token"] == "id-3"

    def test_overwrite_same_access_token(self, store):
        """Storing with the same access_token overwrites the previous entry."""
        store.store("at-1", "old-id", "old-rt", "u1", "a1")
        store.store("at-1", "new-id", "new-rt", "u1", "a1")

        result = store.lookup("at-1")
        assert result["id_token"] == "new-id"
        assert result["refresh_token"] == "new-rt"


# ============================================================================
# Update
# ============================================================================


class TestUpdate:
    def test_update_id_token_only(self, store):
        """Update only id_token — refresh_token is preserved."""
        store.store("at-1", "old-id", "original-rt", "u1", "a1")
        store.update("at-1", id_token="new-id")

        result = store.lookup("at-1")
        assert result["id_token"] == "new-id"
        assert result["refresh_token"] == "original-rt"

    def test_update_refresh_token_only(self, store):
        """Update only refresh_token — id_token is preserved."""
        store.store("at-1", "original-id", "old-rt", "u1", "a1")
        store.update("at-1", refresh_token="new-rt")

        result = store.lookup("at-1")
        assert result["id_token"] == "original-id"
        assert result["refresh_token"] == "new-rt"

    def test_update_both(self, store):
        """Update both tokens."""
        store.store("at-1", "old-id", "old-rt", "u1", "a1")
        store.update("at-1", id_token="new-id", refresh_token="new-rt")

        result = store.lookup("at-1")
        assert result["id_token"] == "new-id"
        assert result["refresh_token"] == "new-rt"

    def test_update_missing_entry(self, store):
        """Update on a missing entry is a no-op (no crash)."""
        store.update("nonexistent", id_token="new-id")  # should not raise
        assert store.lookup("nonexistent") is None

    def test_update_refreshes_stored_at(self, store):
        """Update changes the stored_at timestamp."""
        store.store("at-1", "id", "rt", "u1", "a1")
        original_stored_at = store.lookup("at-1")["stored_at"]
        time.sleep(0.01)
        store.update("at-1", id_token="id2")
        assert store.lookup("at-1")["stored_at"] != original_stored_at


# ============================================================================
# Remove
# ============================================================================


class TestRemove:
    def test_remove(self, store):
        """Store, remove, lookup returns None."""
        store.store("at-1", "id", "rt", "u1", "a1")
        assert store.lookup("at-1") is not None
        store.remove("at-1")
        assert store.lookup("at-1") is None

    def test_remove_nonexistent(self, store):
        """Removing a missing entry is a no-op."""
        store.remove("nonexistent")  # should not raise

    def test_remove_by_user(self, store):
        """Remove all entries for a specific user_sub."""
        store.store("at-1", "id1", "rt1", "userA", "a1")
        store.store("at-2", "id2", "rt2", "userA", "a2")
        store.store("at-3", "id3", "rt3", "userB", "a1")

        removed = store.remove_by_user("userA")
        assert removed == 2
        assert store.lookup("at-1") is None
        assert store.lookup("at-2") is None
        assert store.lookup("at-3") is not None  # userB still present

    def test_remove_by_user_none_found(self, store):
        """remove_by_user returns 0 when no entries match."""
        store.store("at-1", "id", "rt", "userA", "a1")
        assert store.remove_by_user("userZ") == 0


# ============================================================================
# Key Hashing
# ============================================================================


class TestKeyHashing:
    def test_key_is_hashed(self, store):
        """Internal cache key is a SHA-256 hash, not the raw access_token."""
        raw_token = "my-secret-access-token"
        store.store(raw_token, "id", "rt", "u1", "a1")

        expected_hash = hashlib.sha256(raw_token.encode()).hexdigest()
        assert expected_hash in store._cache
        assert raw_token not in store._cache

    def test_hash_token_deterministic(self):
        """Same token always produces the same hash."""
        h1 = UserTokenStore._hash_token("token-abc")
        h2 = UserTokenStore._hash_token("token-abc")
        assert h1 == h2
        assert len(h1) == 64  # SHA-256 hex digest

    def test_different_tokens_different_hashes(self):
        """Different tokens produce different hashes."""
        h1 = UserTokenStore._hash_token("token-a")
        h2 = UserTokenStore._hash_token("token-b")
        assert h1 != h2


# ============================================================================
# Encrypted Storage
# ============================================================================


class TestEncryptedStorage:
    def test_encrypted_storage(self, encrypted_store, mock_encryption_service):
        """With encryption, encrypt is called on store and decrypt on lookup."""
        encrypted_store.store("at-1", "secret-id", "secret-rt", "u1", "a1")
        assert mock_encryption_service.encrypt.called

        result = encrypted_store.lookup("at-1")
        assert mock_encryption_service.decrypt.called
        assert result is not None
        assert result["id_token"] == "secret-id"
        assert result["refresh_token"] == "secret-rt"

    def test_unencrypted_raw_json(self, store):
        """Without encryption, values are plain JSON in the cache."""
        store.store("at-1", "id-val", "rt-val", "u1", "a1")
        key = UserTokenStore._hash_token("at-1")
        raw = store._cache[key]
        parsed = json.loads(raw)
        assert parsed["id_token"] == "id-val"
        assert parsed["refresh_token"] == "rt-val"


# ============================================================================
# Stats
# ============================================================================


class TestStats:
    def test_stats_empty(self, store):
        """Stats on an empty store."""
        stats = store.get_stats()
        assert stats["total_entries"] == 0
        assert stats["encrypted"] is False
        assert stats["ttl_seconds"] == 86400
        assert stats["max_size"] == 1000

    def test_stats_after_stores(self, store):
        """Stats reflect stored entry count."""
        store.store("at-1", "id1", "rt1", "u1", "a1")
        store.store("at-2", "id2", "rt2", "u2", "a1")
        stats = store.get_stats()
        assert stats["total_entries"] == 2

    def test_stats_encrypted_flag(self, encrypted_store):
        """Stats report encrypted=True when encryption is active."""
        assert encrypted_store.get_stats()["encrypted"] is True

    def test_stats_no_token_values(self, store):
        """Stats dict must not contain any token values."""
        store.store("at-1", "secret-id", "secret-rt", "u1", "a1")
        stats = store.get_stats()
        stats_str = json.dumps(stats)
        assert "secret-id" not in stats_str
        assert "secret-rt" not in stats_str
        assert "at-1" not in stats_str


# ============================================================================
# TTL Expiry
# ============================================================================


class TestTTLExpiry:
    def test_ttl_expiry(self):
        """Store with very short TTL, verify entry expires."""
        store = UserTokenStore(default_ttl=1, max_size=100)
        store.store("at-1", "id", "rt", "u1", "a1")
        assert store.lookup("at-1") is not None

        time.sleep(1.1)
        assert store.lookup("at-1") is None


# ============================================================================
# Singleton Accessor
# ============================================================================


class TestSingletonAccessor:
    def setup_method(self):
        reset_user_token_store()

    def teardown_method(self):
        reset_user_token_store()

    def test_get_user_token_store_returns_instance(self):
        """get_user_token_store returns a UserTokenStore instance."""
        with patch(
            "okta_agent_proxy.crypto.get_encryption_service",
            side_effect=Exception("no key"),
        ):
            s = get_user_token_store()
            assert isinstance(s, UserTokenStore)

    def test_singleton(self):
        """Repeated calls return the same instance."""
        with patch(
            "okta_agent_proxy.crypto.get_encryption_service",
            side_effect=Exception("no key"),
        ):
            s1 = get_user_token_store()
            s2 = get_user_token_store()
            assert s1 is s2

    def test_reset_clears_singleton(self):
        """reset_user_token_store clears the cached instance."""
        with patch(
            "okta_agent_proxy.crypto.get_encryption_service",
            side_effect=Exception("no key"),
        ):
            s1 = get_user_token_store()
            reset_user_token_store()
            s2 = get_user_token_store()
            assert s1 is not s2


# ============================================================================
# Env var configuration
# ============================================================================


class TestEnvVarConfig:
    def test_default_ttl_from_env(self):
        """USER_TOKEN_STORE_TTL env var controls default TTL."""
        with patch.dict("os.environ", {"USER_TOKEN_STORE_TTL": "7200"}):
            s = UserTokenStore()
            assert s._default_ttl == 7200

    def test_max_size_from_env(self):
        """USER_TOKEN_STORE_MAX_SIZE env var controls max_size."""
        with patch.dict("os.environ", {"USER_TOKEN_STORE_MAX_SIZE": "500"}):
            s = UserTokenStore()
            assert s._max_size == 500
