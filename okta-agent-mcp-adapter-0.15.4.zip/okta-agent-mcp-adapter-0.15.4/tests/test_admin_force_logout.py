"""Integration tests for POST /api/admin/users/force-logout.

Covers every branch of the admin force-logout endpoint:
  - by-sub happy path
  - by-email happy path (resolver success)
  - both/neither input rejection
  - Okta 404 pass-through (user not found)
  - Okta 403 pass-through (missing scope)
  - audit event emission shape
  - unauthenticated request rejection (@admin_required wiring)

Follows the fixture style of tests/test_admin_api_integration.py: Starlette
TestClient, Okta token validation patched, GlobalLogoutHandler.revoke_user
and OktaAPIClient.get_user_by_login mocked so no live dependencies are
hit.
"""

from typing import List
from unittest.mock import AsyncMock, patch

import pytest
from starlette.testclient import TestClient

from okta_agent_proxy.audit.emitter import AuditEventEmitter
from okta_agent_proxy.audit.events import AuditEvent, AuditEventType
from okta_agent_proxy.audit.sinks.base import AuditSink
from okta_agent_proxy.okta_admin.exceptions import (
    OktaAdminForbiddenError,
    OktaAdminNotFoundError,
)


# ============================================================================
# Fixtures
# ============================================================================


@pytest.fixture
def mock_okta_env(monkeypatch):
    """Mock Okta environment variables for app initialization."""
    monkeypatch.setenv("OKTA_DOMAIN", "dev-test.okta.com")
    monkeypatch.setenv("OKTA_CLIENT_SECRET", "test_secret")
    monkeypatch.setenv("OKTA_ISSUER", "https://dev-test.okta.com")
    monkeypatch.setenv("GATEWAY_BASE_URL", "http://localhost:8000")
    monkeypatch.setenv("GATEWAY_PORT", "8000")
    monkeypatch.setenv("LOG_LEVEL", "ERROR")


@pytest.fixture
def test_app_postgres(mock_okta_env, postgres_store, monkeypatch):
    """Admin-authenticated Starlette TestClient with a stubbed Okta validator."""
    import okta_agent_proxy.app
    import okta_agent_proxy.database

    async def _fake_verify_okta_token(token):
        if not token or token == "invalid_token":
            return None
        return {
            "sub": "test-admin",
            "email": "test-admin@example.com",
            "username": "test-admin",
            "role": "admin",
            "token_type": "okta_oauth",
        }

    with patch("okta_agent_proxy.app.get_config_store", return_value=postgres_store):
        with patch("okta_agent_proxy.database.get_config_store", return_value=postgres_store):
            with patch(
                "okta_agent_proxy.admin.middleware.verify_okta_token",
                side_effect=_fake_verify_okta_token,
            ):
                from okta_agent_proxy.app import app
                client = TestClient(app)
                yield client


@pytest.fixture
def auth_headers():
    return {"Authorization": "Bearer test-okta-access-token"}


class CaptureSink(AuditSink):
    def __init__(self):
        self.events: List[AuditEvent] = []

    async def write(self, event: AuditEvent) -> None:
        self.events.append(event)

    @property
    def name(self) -> str:
        return "capture"


@pytest.fixture
def capture_emitter():
    """Install a capturing audit emitter and tear it down after the test."""
    import asyncio

    import okta_agent_proxy.audit as audit_mod

    sink = CaptureSink()
    emitter = AuditEventEmitter(sinks=[sink], flush_interval=0.05)

    loop = asyncio.new_event_loop()
    try:
        loop.run_until_complete(emitter.start())

        old = audit_mod._emitter
        audit_mod._emitter = emitter
        try:
            yield sink, emitter, loop
        finally:
            audit_mod._emitter = old
            loop.run_until_complete(emitter.stop())
    finally:
        loop.close()


def _drain_emitter(emitter: AuditEventEmitter, loop) -> None:
    """Flush any pending audit events so the capture sink has them."""
    import asyncio

    async def _flush():
        # AuditEventEmitter exposes an internal queue; waiting briefly
        # lets the background task drain.
        await asyncio.sleep(0.2)

    loop.run_until_complete(_flush())


@pytest.fixture
def revoke_summary():
    return {
        "user_sub": "00u1",
        "correlation_id": "correlation-placeholder",
        "tokens_revoked": 2,
        "cache_swept": True,
        "sessions_terminated": 1,
        "sessions_failed": 0,
        "backends": {"hr-system": True},
    }


@pytest.fixture
def patch_revoke(revoke_summary):
    """Patch GlobalLogoutHandler.revoke_user to return the canned summary."""
    mock = AsyncMock(return_value=revoke_summary)
    with patch(
        "okta_agent_proxy.admin.routes.GlobalLogoutHandler"
    ) as mock_cls:
        mock_cls.return_value.revoke_user = mock
        yield mock


# ============================================================================
# Tests
# ============================================================================


def test_force_logout_by_sub_happy_path(
    test_app_postgres, auth_headers, patch_revoke, revoke_summary
):
    response = test_app_postgres.post(
        "/api/admin/users/force-logout",
        headers=auth_headers,
        json={"sub": "00u1"},
    )

    assert response.status_code == 200
    body = response.json()
    assert body["user_sub"] == revoke_summary["user_sub"]
    assert body["tokens_revoked"] == revoke_summary["tokens_revoked"]
    assert body["sessions_terminated"] == revoke_summary["sessions_terminated"]
    patch_revoke.assert_awaited_once()
    (called_sub, _corr) = patch_revoke.await_args.args
    assert called_sub == "00u1"


def test_force_logout_by_email_resolves_sub(
    test_app_postgres, auth_headers, patch_revoke
):
    fake_user = {
        "id": "00u1",
        "profile": {"email": "u@example.com"},
    }
    resolver = AsyncMock(return_value=fake_user)
    with patch(
        "okta_agent_proxy.admin.routes.OktaAPIClient"
    ) as mock_client_cls:
        mock_client_cls.return_value.get_user_by_login = resolver
        response = test_app_postgres.post(
            "/api/admin/users/force-logout",
            headers=auth_headers,
            json={"email": "u@example.com"},
        )

    assert response.status_code == 200
    resolver.assert_awaited_once()
    assert resolver.await_args.args[0] == "u@example.com"
    patch_revoke.assert_awaited_once()
    called_sub, _ = patch_revoke.await_args.args
    assert called_sub == "00u1"


def test_force_logout_rejects_both_email_and_sub(
    test_app_postgres, auth_headers, patch_revoke
):
    response = test_app_postgres.post(
        "/api/admin/users/force-logout",
        headers=auth_headers,
        json={"email": "u@example.com", "sub": "00u1"},
    )

    assert response.status_code == 400
    assert response.json()["error"] == "invalid_input"
    patch_revoke.assert_not_awaited()


def test_force_logout_rejects_neither_email_nor_sub(
    test_app_postgres, auth_headers, patch_revoke
):
    response = test_app_postgres.post(
        "/api/admin/users/force-logout",
        headers=auth_headers,
        json={},
    )

    assert response.status_code == 400
    assert response.json()["error"] == "invalid_input"
    patch_revoke.assert_not_awaited()


def test_force_logout_email_not_found_in_okta(
    test_app_postgres, auth_headers, patch_revoke
):
    resolver = AsyncMock(side_effect=OktaAdminNotFoundError("not found"))
    with patch(
        "okta_agent_proxy.admin.routes.OktaAPIClient"
    ) as mock_client_cls:
        mock_client_cls.return_value.get_user_by_login = resolver
        response = test_app_postgres.post(
            "/api/admin/users/force-logout",
            headers=auth_headers,
            json={"email": "ghost@example.com"},
        )

    assert response.status_code == 404
    assert response.json()["error"] == "user_not_found"
    patch_revoke.assert_not_awaited()


def test_force_logout_admin_lacks_okta_users_read(
    test_app_postgres, auth_headers, patch_revoke
):
    resolver = AsyncMock(
        side_effect=OktaAdminForbiddenError(
            "Insufficient Okta permissions. Ensure your admin role has the required "
            "scopes (okta.apps.manage, okta.aiAgents.manage)."
        )
    )
    with patch(
        "okta_agent_proxy.admin.routes.OktaAPIClient"
    ) as mock_client_cls:
        mock_client_cls.return_value.get_user_by_login = resolver
        response = test_app_postgres.post(
            "/api/admin/users/force-logout",
            headers=auth_headers,
            json={"email": "u@example.com"},
        )

    assert response.status_code == 403
    body = response.json()
    assert body["error"] == "forbidden"
    assert "Insufficient Okta permissions" in body["message"]
    patch_revoke.assert_not_awaited()


def test_force_logout_emits_admin_audit_event(
    test_app_postgres, auth_headers, patch_revoke, revoke_summary, capture_emitter
):
    sink, emitter, loop = capture_emitter

    response = test_app_postgres.post(
        "/api/admin/users/force-logout",
        headers=auth_headers,
        json={"sub": "00u1"},
    )
    assert response.status_code == 200

    _drain_emitter(emitter, loop)

    force_events = [
        e for e in sink.events
        if e.event_type == AuditEventType.ADMIN_FORCE_LOGOUT
    ]
    assert len(force_events) == 1
    event = force_events[0]
    details = event.details
    assert details["target_sub"] == "00u1"
    assert details["target_email"] is None
    assert details["tokens_revoked"] == revoke_summary["tokens_revoked"]
    assert details["cache_swept"] == revoke_summary["cache_swept"]
    assert details["sessions_terminated"] == revoke_summary["sessions_terminated"]
    assert details["sessions_failed"] == revoke_summary["sessions_failed"]
    assert details["correlation_id"]
    assert "actor" in details


def test_force_logout_unauthenticated_is_401(test_app_postgres, patch_revoke):
    response = test_app_postgres.post(
        "/api/admin/users/force-logout",
        json={"sub": "00u1"},
    )

    assert response.status_code == 401
    patch_revoke.assert_not_awaited()
