"""
Tests for encryption wiring across cache-bearing components.

Tests:
- Encrypted values are not stored as plaintext in L2 provider
- Round-trip: write encrypted, read back original values
- is_redis_backed property reflects the L2 provider type
- Startup warning when Redis is enabled without ENCRYPTION_KEY
- No warning when using MemoryCacheProvider
"""

import logging
import pytest
from unittest.mock import MagicMock

from okta_agent_proxy.cache.cache_service import CacheService, get_encryption_service_or_none
from okta_agent_proxy.cache.memory_provider import MemoryCacheProvider
from okta_agent_proxy.cache.redis_provider import RedisCacheProvider
from okta_agent_proxy.crypto.encryption import EncryptionService
from okta_agent_proxy.auth.user_token_store import UserTokenStore, reset_user_token_store
from okta_agent_proxy.auth.consent_transaction import ConsentTransactionStore


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


class FakeRedisProvider(RedisCacheProvider):
    """A RedisCacheProvider subclass backed by an in-memory dict.

    isinstance(fake, RedisCacheProvider) is True, which is what
    CacheService.is_redis_backed checks.
    """

    def __init__(self):
        # Skip real __init__ — no actual Redis connection
        self._data: dict[str, str] = {}
        self._ttls: dict[str, int] = {}

    async def get(self, key: str):
        return self._data.get(key)

    async def set(self, key: str, value: str, ttl_seconds=None):
        self._data[key] = value
        if ttl_seconds:
            self._ttls[key] = ttl_seconds

    async def delete(self, key: str):
        self._data.pop(key, None)
        self._ttls.pop(key, None)

    async def exists(self, key: str) -> bool:
        return key in self._data

    async def clear_prefix(self, prefix: str) -> int:
        keys = [k for k in self._data if k.startswith(prefix)]
        for k in keys:
            del self._data[k]
        return len(keys)

    async def health_check(self) -> bool:
        return True

    def close(self):
        self._data.clear()


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


@pytest.fixture
def fake_redis():
    return FakeRedisProvider()


@pytest.fixture
def redis_cache_service(fake_redis):
    return CacheService(l2_provider=fake_redis)


@pytest.fixture
def memory_cache_service():
    return CacheService(l2_provider=MemoryCacheProvider(max_size=1000, default_ttl=3600))


@pytest.fixture
def enc_service():
    import base64
    key_b64 = EncryptionService.generate_key()
    key_bytes = base64.b64decode(key_b64)
    return EncryptionService(key=key_bytes, key_id="test")


# ---------------------------------------------------------------------------
# Test 1: Encrypted values are opaque in L2
# ---------------------------------------------------------------------------


class TestEncryptedStorageInL2:
    """Write sensitive values through cache-bearing components and verify
    that the raw bytes in the L2 provider do NOT contain plaintext."""

    async def test_token_cache_encrypts_in_l2(self, redis_cache_service, enc_service, fake_redis):
        """UserTokenStore with encryption: L2 must not contain plaintext."""
        reset_user_token_store()
        store = UserTokenStore(
            encryption_service=enc_service,
            cache_service=redis_cache_service,
        )

        secret_id_token = "eyJ.SUPER_SECRET_ID_TOKEN.sig"
        secret_refresh = "REFRESH_TOKEN_SHOULD_NOT_APPEAR"

        await store.astore(
            access_token="test-access-token-abc",
            id_token=secret_id_token,
            refresh_token=secret_refresh,
            user_sub="user@example.com",
            agent_id="claude-code",
            expires_in=3600,
        )

        # Inspect raw L2 values
        for key, raw_value in fake_redis._data.items():
            assert secret_id_token not in raw_value, (
                f"Plaintext id_token found in L2 key={key}"
            )
            assert secret_refresh not in raw_value, (
                f"Plaintext refresh_token found in L2 key={key}"
            )

        # Round-trip: read back and verify original values
        result = await store.alookup("test-access-token-abc")
        assert result is not None
        assert result["id_token"] == secret_id_token
        assert result["refresh_token"] == secret_refresh
        assert result["user_sub"] == "user@example.com"

    async def test_consent_store_encrypts_in_l2(self, redis_cache_service, enc_service, fake_redis):
        """ConsentTransactionStore with encryption: L2 must not contain plaintext."""
        store = ConsentTransactionStore(
            cache_service=redis_cache_service,
            encryption_service=enc_service,
        )

        secret_token = "CONSENT_ACCESS_TOKEN_SECRET"

        tx = await store.acreate(
            agent_id="claude-code",
            id_token="id-tok",
            access_token=secret_token,
            refresh_token="ref-tok",
            original_state="state-123",
        )

        # Inspect raw L2 values
        for key, raw_value in fake_redis._data.items():
            # Skip the session index key (it just stores the transaction_id, not tokens)
            if "consent_session:" in key:
                continue
            assert secret_token not in raw_value, (
                f"Plaintext access_token found in L2 key={key}"
            )

        # Round-trip: clear L1 to force L2 read
        store._by_id.clear()
        store._by_session.clear()
        loaded = await store.aget_by_id(tx.transaction_id)
        assert loaded is not None
        assert loaded.access_token == secret_token

    async def test_user_token_store_without_encryption_stores_plaintext(
        self, redis_cache_service, fake_redis
    ):
        """Without encryption, plaintext IS in L2 (baseline sanity check)."""
        reset_user_token_store()
        store = UserTokenStore(
            encryption_service=None,
            cache_service=redis_cache_service,
        )

        secret_id_token = "PLAINTEXT_VISIBLE"

        await store.astore(
            access_token="test-access-no-enc",
            id_token=secret_id_token,
            refresh_token="ref",
            user_sub="user@example.com",
            agent_id="agent",
        )

        found_plaintext = any(
            secret_id_token in v for v in fake_redis._data.values()
        )
        assert found_plaintext, "Without encryption, plaintext should be visible in L2"


# ---------------------------------------------------------------------------
# Test 2: is_redis_backed with MemoryCacheProvider
# ---------------------------------------------------------------------------


class TestIsRedisBacked:
    def test_memory_provider_is_not_redis_backed(self, memory_cache_service):
        assert memory_cache_service.is_redis_backed is False

    def test_fake_redis_provider_is_redis_backed(self, redis_cache_service):
        assert redis_cache_service.is_redis_backed is True


# ---------------------------------------------------------------------------
# Test 3: Startup warning via caplog
# ---------------------------------------------------------------------------


class TestStartupWarning:
    def test_warning_emitted_when_redis_without_encryption(self, redis_cache_service, caplog):
        """Simulate the app.py startup check: Redis + no encryption = warning."""
        _encryption_svc = None
        with caplog.at_level(logging.WARNING):
            if redis_cache_service.is_redis_backed and _encryption_svc is None:
                logging.getLogger("okta_agent_proxy.app").warning(
                    "=" * 78
                    + "\nREDIS ENABLED WITHOUT ENCRYPTION_KEY"
                    + "\nSensitive tokens (id_token, refresh_token, "
                    + "relay_client_secret, consent transactions) will be "
                    + "stored UNENCRYPTED in Redis."
                    + "\nSet ENCRYPTION_KEY to fix.\n"
                    + "=" * 78
                )
        assert "REDIS ENABLED WITHOUT ENCRYPTION_KEY" in caplog.text

    def test_no_warning_when_memory_backed(self, memory_cache_service, caplog):
        """No warning when L2 is memory — no shared state risk."""
        _encryption_svc = None
        with caplog.at_level(logging.WARNING):
            if memory_cache_service.is_redis_backed and _encryption_svc is None:
                logging.getLogger("okta_agent_proxy.app").warning(
                    "REDIS ENABLED WITHOUT ENCRYPTION_KEY"
                )
        assert "REDIS ENABLED WITHOUT ENCRYPTION_KEY" not in caplog.text

    def test_no_warning_when_redis_with_encryption(self, redis_cache_service, enc_service, caplog):
        """No warning when Redis is backed AND encryption is available."""
        _encryption_svc = enc_service  # non-None
        with caplog.at_level(logging.WARNING):
            if redis_cache_service.is_redis_backed and _encryption_svc is None:
                logging.getLogger("okta_agent_proxy.app").warning(
                    "REDIS ENABLED WITHOUT ENCRYPTION_KEY"
                )
        assert "REDIS ENABLED WITHOUT ENCRYPTION_KEY" not in caplog.text


# ---------------------------------------------------------------------------
# Test: get_encryption_service_or_none helper
# ---------------------------------------------------------------------------


class TestGetEncryptionServiceOrNone:
    def test_returns_none_when_no_key(self, monkeypatch):
        monkeypatch.delenv("ENCRYPTION_KEY", raising=False)
        monkeypatch.delenv("ENCRYPTION_PASSWORD", raising=False)
        result = get_encryption_service_or_none()
        assert result is None

    def test_returns_service_when_key_set(self, monkeypatch):
        key = EncryptionService.generate_key()
        monkeypatch.setenv("ENCRYPTION_KEY", key)
        # Reset the cached singleton so it picks up our key
        import okta_agent_proxy.crypto.encryption as enc_mod
        enc_mod._encryption_service = None
        result = get_encryption_service_or_none()
        assert result is not None
        # Cleanup
        enc_mod._encryption_service = None
