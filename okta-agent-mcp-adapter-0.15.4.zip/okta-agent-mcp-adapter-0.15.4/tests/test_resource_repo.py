"""Tests for the collapsed ``ResourceRepository`` public surface."""

from __future__ import annotations

import pytest


@pytest.fixture
def agent_row(postgres_store):
    """Create an ``agents`` row that resources can FK to."""
    postgres_store.create_agent(
        "agent-alpha",
        {
            "agent_name": "agent-alpha",
            "agent_id": "agent-alpha",
            "client_id": "0oa_alpha",
            "private_key": '{"kty":"RSA","n":"x","e":"AQAB"}',
            "scopes": [],
            "enabled": True,
        },
        user="test",
    )
    yield "agent-alpha"


def _repo(postgres_store):
    return postgres_store._resources


# ---------------------------------------------------------------------------
# upsert_synced + update_sync_fields
# ---------------------------------------------------------------------------


def test_upsert_synced_inserts_disabled_row(postgres_store, agent_row):
    repo = _repo(postgres_store)
    row = repo.upsert_synced(
        agent_id=agent_row,
        connection_id="conn-1",
        name="hr-system",
        connection_type="IDENTITY_ASSERTION_CUSTOM_AS",
        scopes=["read"],
        scope_condition="INCLUDE_ONLY",
        auth_method="okta-cross-app",
        metadata={"issuer_url": "https://example.okta.com"},
        connection_resource_id="aus123",
    )
    assert row["name"] == "hr-system"
    assert row["agent_id"] == agent_row
    assert row["connection_id"] == "conn-1"
    assert row["enabled"] is False
    assert row["url"] == ""
    assert row["scopes"] == ["read"]
    assert row["scope_condition"] == "INCLUDE_ONLY"
    assert row["connection_type"] == "IDENTITY_ASSERTION_CUSTOM_AS"


def test_upsert_synced_updates_existing_row(postgres_store, agent_row):
    repo = _repo(postgres_store)
    repo.upsert_synced(
        agent_id=agent_row,
        connection_id="conn-1",
        name="hr-system",
        connection_type="IDENTITY_ASSERTION_CUSTOM_AS",
        scopes=["read"],
        scope_condition="INCLUDE_ONLY",
        auth_method="okta-cross-app",
        metadata={},
    )
    # Admin sets URL + enables
    postgres_store.update_resource(
        "hr-system", {"url": "https://hr.example.com", "enabled": True}, user="admin"
    )
    # Re-sync with different scopes
    repo.upsert_synced(
        agent_id=agent_row,
        connection_id="conn-1",
        name="hr-system",
        connection_type="IDENTITY_ASSERTION_CUSTOM_AS",
        scopes=["read", "write"],
        scope_condition="ALLOW_ALL",
        auth_method="okta-cross-app",
        metadata={},
    )
    fresh = postgres_store.get_resource("hr-system")
    assert fresh["scopes"] == ["read", "write"]
    assert fresh["scope_condition"] == "ALLOW_ALL"
    # Admin-editable fields preserved across re-sync
    assert fresh["url"] == "https://hr.example.com"
    assert fresh["enabled"] is True


def test_update_sync_fields_only_updates_sync_owned(postgres_store, agent_row):
    repo = _repo(postgres_store)
    repo.upsert_synced(
        agent_id=agent_row,
        connection_id="conn-1",
        name="svc",
        connection_type="STS_VAULT_SECRET",
        scopes=[],
        scope_condition="ALLOW_ALL",
        auth_method="vault-secret",
        metadata={},
    )
    ok = repo.update_sync_fields(
        agent_id=agent_row,
        connection_id="conn-1",
        scopes=["a", "b"],
        scope_condition="INCLUDE_ONLY",
    )
    assert ok is True
    row = postgres_store.get_resource("svc")
    assert row["scopes"] == ["a", "b"]
    assert row["scope_condition"] == "INCLUDE_ONLY"


# ---------------------------------------------------------------------------
# update_editable
# ---------------------------------------------------------------------------


def test_update_editable_rejects_sync_owned_fields(postgres_store, agent_row):
    repo = _repo(postgres_store)
    repo.upsert_synced(
        agent_id=agent_row,
        connection_id="conn-1",
        name="svc",
        connection_type="IDENTITY_ASSERTION_CUSTOM_AS",
        scopes=[],
        scope_condition="ALLOW_ALL",
        auth_method="okta-cross-app",
        metadata={},
    )
    with pytest.raises(ValueError, match="sync-owned"):
        repo.update_editable("svc", {"scopes": ["new"]}, user="admin")


def test_update_editable_applies_allowed_fields(postgres_store, agent_row):
    repo = _repo(postgres_store)
    repo.upsert_synced(
        agent_id=agent_row,
        connection_id="conn-1",
        name="svc",
        connection_type="IDENTITY_ASSERTION_CUSTOM_AS",
        scopes=[],
        scope_condition="ALLOW_ALL",
        auth_method="okta-cross-app",
        metadata={},
    )
    updated = repo.update_editable(
        "svc",
        {"url": "https://svc.example.com", "enabled": True, "description": "hi"},
        user="admin",
    )
    assert updated is not None
    assert updated["url"] == "https://svc.example.com"
    assert updated["enabled"] is True
    assert updated["description"] == "hi"


# ---------------------------------------------------------------------------
# Lookups + cache
# ---------------------------------------------------------------------------


def test_get_by_agent_connection(postgres_store, agent_row):
    repo = _repo(postgres_store)
    repo.upsert_synced(
        agent_id=agent_row,
        connection_id="conn-42",
        name="svc",
        connection_type="IDENTITY_ASSERTION_CUSTOM_AS",
        scopes=[],
        scope_condition="ALLOW_ALL",
        auth_method="okta-cross-app",
        metadata={},
    )
    row = repo.get_by_agent_connection(agent_row, "conn-42")
    assert row is not None
    assert row["name"] == "svc"
    assert repo.get_by_agent_connection(agent_row, "nope") is None


def test_load_cache_and_get_by_name(postgres_store, agent_row):
    repo = _repo(postgres_store)
    repo.upsert_synced(
        agent_id=agent_row,
        connection_id="c1",
        name="r1",
        connection_type="IDENTITY_ASSERTION_CUSTOM_AS",
        scopes=[],
        scope_condition="ALLOW_ALL",
        auth_method="okta-cross-app",
        metadata={},
    )
    count = repo.load_cache()
    assert count == 1
    entry = repo.get_by_name("r1")
    assert entry is not None
    assert entry.name == "r1"
    assert entry.agent_id == agent_row
    assert entry.connection_id == "c1"


# ---------------------------------------------------------------------------
# Deletion + FK cascade
# ---------------------------------------------------------------------------


def test_delete_by_name(postgres_store, agent_row):
    repo = _repo(postgres_store)
    repo.upsert_synced(
        agent_id=agent_row,
        connection_id="c1",
        name="doomed",
        connection_type="IDENTITY_ASSERTION_CUSTOM_AS",
        scopes=[],
        scope_condition="ALLOW_ALL",
        auth_method="okta-cross-app",
        metadata={},
    )
    assert repo.delete_by_name("doomed") is True
    assert postgres_store.get_resource("doomed") is None
    assert repo.delete_by_name("doomed") is False


def test_fk_cascade_from_agent_delete(postgres_store, agent_row):
    repo = _repo(postgres_store)
    repo.upsert_synced(
        agent_id=agent_row,
        connection_id="c1",
        name="r1",
        connection_type="IDENTITY_ASSERTION_CUSTOM_AS",
        scopes=[],
        scope_condition="ALLOW_ALL",
        auth_method="okta-cross-app",
        metadata={},
    )
    repo.upsert_synced(
        agent_id=agent_row,
        connection_id="c2",
        name="r2",
        connection_type="IDENTITY_ASSERTION_CUSTOM_AS",
        scopes=[],
        scope_condition="ALLOW_ALL",
        auth_method="okta-cross-app",
        metadata={},
    )
    postgres_store.delete_agent(agent_row, user="test")
    assert postgres_store.get_resource("r1") is None
    assert postgres_store.get_resource("r2") is None
