"""P15 — coverage for deploy/shell-lib/db_bootstrap.sh.

Shells out to `bash`, drives the shared lib with stub PATH entries for
`aws`, `az`, `psql`, and `python`, and asserts on the captured argv
logs. Keeps the repo's pytest convention instead of pulling in
bats-core or shellspec.
"""
from __future__ import annotations

import os
import stat
import subprocess
import textwrap
from pathlib import Path

import pytest

REPO_ROOT = Path(__file__).resolve().parent.parent
LIB_PATH = REPO_ROOT / "deploy" / "shell-lib" / "db_bootstrap.sh"


def _write_exec(path: Path, body: str) -> None:
    path.write_text(body)
    path.chmod(path.stat().st_mode | stat.S_IXUSR | stat.S_IXGRP | stat.S_IXOTH)


def _make_stub(dir: Path, name: str, log_path: Path, *, exit_code: int = 0, stdout: str = "") -> None:
    """Write a shell stub that logs its argv to `log_path` and exits `exit_code`."""
    body = textwrap.dedent(
        f"""\
        #!/usr/bin/env bash
        {{ printf '%s' '{name}'; for a in "$@"; do printf '\\0%s' "$a"; done; printf '\\n'; }} >> '{log_path}'
        {'printf "%s" ' + repr(stdout) if stdout else 'true'}
        exit {exit_code}
        """
    )
    _write_exec(dir / name, body)


def _run(
    tmp_path: Path,
    *,
    env_extra: dict[str, str] | None = None,
    call: str = "db_bootstrap_run",
    force_path_only: bool = True,
) -> tuple[subprocess.CompletedProcess, Path]:
    """Source the lib and call `call`. Returns the completed process + argv-log path."""
    log_path = tmp_path / "argv.log"
    log_path.touch()

    # Minimal harness that provides the info/ok/warn/die helpers the lib expects.
    harness = tmp_path / "harness.sh"
    harness.write_text(
        textwrap.dedent(
            f"""\
            #!/usr/bin/env bash
            set -u
            info()  {{ printf '[INFO] %s\\n' "$*"; }}
            ok()    {{ printf '[ OK ] %s\\n' "$*"; }}
            warn()  {{ printf '[WARN] %s\\n' "$*" >&2; }}
            die()   {{ printf '[FAIL] %s\\n' "$*" >&2; exit 1; }}
            # shellcheck disable=SC1091
            source '{LIB_PATH}'
            {call}
            """
        )
    )
    harness.chmod(0o755)

    env = {
        "PATH": f"{tmp_path}:{os.environ.get('PATH', '/usr/bin:/bin')}",
        "HOME": str(tmp_path),
    }
    if force_path_only:
        # Drop inherited AWS/AZ creds so the real CLIs (if installed) don't
        # accidentally contact cloud endpoints during a probe test.
        pass
    if env_extra:
        env.update(env_extra)

    proc = subprocess.run(
        ["bash", str(harness)],
        env=env,
        capture_output=True,
        text=True,
        timeout=60,
    )
    return proc, log_path


# ---------------------------------------------------------------------------
# Off-mode handoff
# ---------------------------------------------------------------------------


def test_run_db_bootstrap_false_prints_handoff_with_correct_secret_arns(tmp_path: Path) -> None:
    env = {
        "RUN_DB_BOOTSTRAP": "false",
        "PLATFORM": "aws",
        "AWS_REGION": "us-east-1",
        "ECS_CLUSTER": "my-cluster",
        "MIGRATE_TASK_DEF_ARN": "arn:aws:ecs:us-east-1:123:task-definition/migrate:7",
        "ECS_SUBNETS": "subnet-a,subnet-b",
        "ECS_SECURITY_GROUPS": "sg-123",
        "DB_MASTER_SECRET_ARN": "arn:aws:secretsmanager:us-east-1:123:secret:db-xyz",
        "DB_HOST": "rds.example.internal",
        "DB_PORT": "5432",
        "DB_NAME": "gateway_db",
        "DB_OWNER_ROLE": "okta_adapter_owner",
        "DB_APP_ROLE": "okta_adapter_app",
    }
    proc, _ = _run(tmp_path, env_extra=env)
    assert proc.returncode == 0, proc.stderr
    assert "DEPLOYMENT COMPLETE — DATABASE BOOTSTRAP NOT YET RUN" in proc.stdout
    # The handoff must cite the real ARN verbatim so the DBA can copy-paste.
    assert env["DB_MASTER_SECRET_ARN"] in proc.stdout
    assert env["MIGRATE_TASK_DEF_ARN"] in proc.stdout
    assert env["ECS_CLUSTER"] in proc.stdout
    # No placeholders left behind.
    assert "<placeholder>" not in proc.stdout
    assert "<master-secret-arn>" not in proc.stdout


def test_azure_handoff_references_entra_owner(tmp_path: Path) -> None:
    env = {
        "RUN_DB_BOOTSTRAP": "false",
        "PLATFORM": "azure",
        "AZURE_RG": "rg-demo",
        "MIGRATE_JOB_NAME": "okta-migrate",
        "DB_HOST": "pg-demo.postgres.database.azure.com",
        "DB_PORT": "5432",
        "DB_NAME": "gateway_db",
        "DB_OWNER_ROLE": "okta_adapter_owner",
        "DB_APP_ROLE": "okta_adapter_app",
        "ENTRA_OWNER_PRINCIPAL": "okta-ps-adapter-owner",
    }
    proc, _ = _run(tmp_path, env_extra=env)
    assert proc.returncode == 0, proc.stderr
    assert env["MIGRATE_JOB_NAME"] in proc.stdout
    assert env["ENTRA_OWNER_PRINCIPAL"] in proc.stdout
    assert "az containerapp job start" in proc.stdout


# ---------------------------------------------------------------------------
# Cloud-CLI probe
# ---------------------------------------------------------------------------


def test_cloud_cli_probe_returns_false_when_aws_missing(tmp_path: Path) -> None:
    # PATH contains no `aws` binary, so probe must return false and fall back.
    env = {
        "PLATFORM": "aws",
        "AWS_REGION": "us-east-1",
        "DB_BOOTSTRAP_FORCE_LOCAL": "false",
        # Make local-exec the only viable path, then make it fail fast so the
        # test doesn't actually need psql/python — we just need to prove the
        # probe returned false and the case statement chose `local`.
        "RUN_DB_BOOTSTRAP": "true",
        # No psql stub → _check_local_prereqs die()s with a deterministic error.
    }
    proc, _ = _run(tmp_path, env_extra=env)
    assert proc.returncode != 0
    assert "Cloud CLI unavailable" in proc.stderr
    assert "Bootstrap path: local execution" in proc.stdout


def test_cloud_cli_probe_returns_false_when_az_unauthenticated(tmp_path: Path) -> None:
    log = tmp_path / "argv.log"
    log.touch()
    # `az` exists but `az account show` exits 1 — simulate not logged in.
    stub = tmp_path / "az"
    stub.write_text(
        textwrap.dedent(
            f"""\
            #!/usr/bin/env bash
            {{ printf 'az'; for a in "$@"; do printf '\\0%s' "$a"; done; printf '\\n'; }} >> '{log}'
            if [ "$1" = "account" ] && [ "$2" = "show" ]; then
              exit 1
            fi
            exit 0
            """
        )
    )
    _write_exec(stub, stub.read_text())

    env = {
        "PLATFORM": "azure",
        "DB_BOOTSTRAP_FORCE_LOCAL": "false",
        "RUN_DB_BOOTSTRAP": "true",
    }
    proc, _ = _run(tmp_path, env_extra=env)
    assert proc.returncode != 0
    assert "Cloud CLI unavailable" in proc.stderr
    argv = log.read_text()
    assert "account\x00show" in argv


def test_force_local_skips_cloud_job_attempt(tmp_path: Path) -> None:
    log = tmp_path / "argv.log"
    log.touch()
    # Provide a working `aws` stub so the probe would otherwise choose cloud_job.
    _make_stub(tmp_path, "aws", log, exit_code=0, stdout="ok\n")

    env = {
        "PLATFORM": "aws",
        "AWS_REGION": "us-east-1",
        "DB_BOOTSTRAP_FORCE_LOCAL": "true",
        "RUN_DB_BOOTSTRAP": "true",
    }
    proc, _ = _run(tmp_path, env_extra=env)
    # Local path will fail (no psql stub) — that's fine; we just need to
    # confirm the script never reached the aws-probe branch.
    assert proc.returncode != 0
    assert "DB_BOOTSTRAP_FORCE_LOCAL=true" in proc.stdout
    # aws stub must not have been invoked for get-caller-identity
    assert "get-caller-identity" not in log.read_text()


# ---------------------------------------------------------------------------
# AWS local-exec + IAM mode
# ---------------------------------------------------------------------------


def test_aws_local_exec_refuses_when_use_rds_iam_true(tmp_path: Path) -> None:
    log = tmp_path / "argv.log"
    log.touch()
    _make_stub(tmp_path, "psql", log, exit_code=0)
    # python that imports migrate without failure
    python_stub = tmp_path / "python"
    python_stub.write_text(
        textwrap.dedent(
            f"""\
            #!/usr/bin/env bash
            {{ printf 'python'; for a in "$@"; do printf '\\0%s' "$a"; done; printf '\\n'; }} >> '{log}'
            exit 0
            """
        )
    )
    _write_exec(python_stub, python_stub.read_text())

    env = {
        "PLATFORM": "aws",
        "AWS_REGION": "us-east-1",
        "DB_BOOTSTRAP_FORCE_LOCAL": "true",
        "RUN_DB_BOOTSTRAP": "true",
        "USE_RDS_IAM": "true",
        "DB_MASTER_SECRET_ARN": "arn:aws:secretsmanager:us-east-1:123:secret:db",
        "DB_HOST": "rds.example.internal",
        "DB_PORT": "5432",
        "DB_NAME": "gateway_db",
        "DB_OWNER_ROLE": "okta_adapter_owner",
        "DB_APP_ROLE": "okta_adapter_app",
        "MIGRATIONS_DIR": str(REPO_ROOT / "deploy" / "migrations" / "sql"),
    }
    proc, _ = _run(tmp_path, env_extra=env)
    assert proc.returncode != 0
    assert "Local-exec path is not supported when USE_RDS_IAM=true" in proc.stderr


# ---------------------------------------------------------------------------
# Local-exec order of operations
# ---------------------------------------------------------------------------


def test_local_exec_calls_psql_then_migrate_in_order(tmp_path: Path) -> None:
    log = tmp_path / "argv.log"
    log.touch()
    _make_stub(tmp_path, "psql", log, exit_code=0)

    # `aws` stub that returns a fake master secret JSON. The lib pipes the
    # secret into `python -c '...'` — we stub python too, so we have to
    # keep the json-extract behavior.
    aws_body = textwrap.dedent(
        f"""\
        #!/usr/bin/env bash
        {{ printf 'aws'; for a in "$@"; do printf '\\0%s' "$a"; done; printf '\\n'; }} >> '{log}'
        # secretsmanager get-secret-value → print the JSON payload
        if [[ "$*" == *get-secret-value* ]]; then
          printf '%s' '{{"DATABASE_URL":"postgresql://master:pw@db:5432/gateway_db"}}'
          exit 0
        fi
        # sts get-caller-identity — doesn't matter, force-local skips it
        exit 0
        """
    )
    _write_exec(tmp_path / "aws", aws_body)

    # Multi-mode python stub:
    #   - `python -c 'import okta_agent_proxy.storage.migrate'` → exit 0 (prereq check)
    #   - `python -c 'import sys,json; print(json.load(sys.stdin)["DATABASE_URL"])'` → parse
    #   - `python -m okta_agent_proxy.storage.migrate upgrade ...` → log + exit 0
    #   - `python -m okta_agent_proxy.storage.migrate version ...` → print "001"
    #   - `python -c 'from okta_agent_proxy.storage.constants import MIN_SCHEMA_VERSION; ...'` → print "001"
    python_body = textwrap.dedent(
        f"""\
        #!/usr/bin/env bash
        {{ printf 'python'; for a in "$@"; do printf '\\0%s' "$a"; done; printf '\\n'; }} >> '{log}'
        case "$*" in
          *"import sys, urllib.parse"*|*"import sys,urllib.parse"*)
            # _url_encode caller
            shift  # drop -c
            /usr/bin/env python3 -c "$@"
            exit $?
            ;;
          *"import okta_agent_proxy.storage.migrate"*)
            # prereq check
            exit 0
            ;;
          *"import sys,json; print(json.load(sys.stdin)"*)
            /usr/bin/env python3 -c "import sys,json; print(json.load(sys.stdin)[\\"DATABASE_URL\\"])"
            exit $?
            ;;
          *"okta_agent_proxy.storage.migrate"*"upgrade"*)
            exit 0
            ;;
          *"okta_agent_proxy.storage.migrate"*"version"*)
            printf '%s' '001'
            exit 0
            ;;
          *"MIN_SCHEMA_VERSION"*)
            printf '%s' '001'
            exit 0
            ;;
          *)
            exit 0
            ;;
        esac
        """
    )
    _write_exec(tmp_path / "python", python_body)

    env = {
        "PLATFORM": "aws",
        "AWS_REGION": "us-east-1",
        "DB_BOOTSTRAP_FORCE_LOCAL": "true",
        "RUN_DB_BOOTSTRAP": "true",
        "USE_RDS_IAM": "false",
        "DB_MASTER_SECRET_ARN": "arn:aws:secretsmanager:us-east-1:123:secret:db",
        "DB_HOST": "rds.example.internal",
        "DB_PORT": "5432",
        "DB_NAME": "gateway_db",
        "DB_OWNER_ROLE": "okta_adapter_owner",
        "DB_APP_ROLE": "okta_adapter_app",
        "MIGRATIONS_DIR": str(REPO_ROOT / "deploy" / "migrations" / "sql"),
    }
    proc, _ = _run(tmp_path, env_extra=env)
    assert proc.returncode == 0, f"stderr={proc.stderr}\nstdout={proc.stdout}"

    # psql must appear before the `migrate upgrade` python invocation.
    content = log.read_text().splitlines()
    psql_idx = next(i for i, line in enumerate(content) if line.startswith("psql\x00"))
    upgrade_idx = next(
        i
        for i, line in enumerate(content)
        if "okta_agent_proxy.storage.migrate" in line and "upgrade" in line
    )
    assert psql_idx < upgrade_idx, f"order wrong: psql@{psql_idx} upgrade@{upgrade_idx}"
    assert "Schema version verified: 001" in proc.stdout


# ---------------------------------------------------------------------------
# Post-condition verification
# ---------------------------------------------------------------------------


def test_post_condition_fails_when_schema_empty(tmp_path: Path) -> None:
    log = tmp_path / "argv.log"
    log.touch()
    _make_stub(tmp_path, "psql", log, exit_code=0)

    aws_body = textwrap.dedent(
        f"""\
        #!/usr/bin/env bash
        if [[ "$*" == *get-secret-value* ]]; then
          printf '%s' '{{"DATABASE_URL":"postgresql://master:pw@db:5432/gateway_db"}}'
        fi
        exit 0
        """
    )
    _write_exec(tmp_path / "aws", aws_body)

    # python stub where `migrate version` returns "(none)" — empty schema.
    python_body = textwrap.dedent(
        """\
        #!/usr/bin/env bash
        case "$*" in
          *"import okta_agent_proxy.storage.migrate"*) exit 0 ;;
          *"import sys,json"*)
            /usr/bin/env python3 -c "import sys,json; print(json.load(sys.stdin)[\\"DATABASE_URL\\"])"
            exit $?
            ;;
          *"import sys, urllib.parse"*|*"import sys,urllib.parse"*)
            shift
            /usr/bin/env python3 -c "$@"
            exit $?
            ;;
          *"okta_agent_proxy.storage.migrate"*"upgrade"*) exit 0 ;;
          *"okta_agent_proxy.storage.migrate"*"version"*)
            printf '(none)'; exit 0 ;;
          *"MIN_SCHEMA_VERSION"*)
            printf '001'; exit 0 ;;
          *) exit 0 ;;
        esac
        """
    )
    _write_exec(tmp_path / "python", python_body)

    env = {
        "PLATFORM": "aws",
        "AWS_REGION": "us-east-1",
        "DB_BOOTSTRAP_FORCE_LOCAL": "true",
        "RUN_DB_BOOTSTRAP": "true",
        "USE_RDS_IAM": "false",
        "DB_MASTER_SECRET_ARN": "arn:aws:secretsmanager:us-east-1:123:secret:db",
        "DB_HOST": "db",
        "DB_PORT": "5432",
        "DB_NAME": "gateway_db",
        "DB_OWNER_ROLE": "okta_adapter_owner",
        "DB_APP_ROLE": "okta_adapter_app",
        "MIGRATIONS_DIR": str(REPO_ROOT / "deploy" / "migrations" / "sql"),
    }
    proc, _ = _run(tmp_path, env_extra=env)
    assert proc.returncode != 0
    assert "Post-condition failed: schema_migrations is empty" in proc.stderr


# ---------------------------------------------------------------------------
# Static bash syntax / shellcheck
# ---------------------------------------------------------------------------


def test_shared_lib_passes_bash_syntax_check() -> None:
    """Fast smoke-test: the lib at least parses."""
    proc = subprocess.run(
        ["bash", "-n", str(LIB_PATH)],
        capture_output=True,
        text=True,
    )
    assert proc.returncode == 0, proc.stderr


@pytest.mark.skipif(
    subprocess.run(["which", "shellcheck"], capture_output=True).returncode != 0,
    reason="shellcheck not installed",
)
def test_shared_lib_passes_shellcheck() -> None:
    proc = subprocess.run(
        ["shellcheck", "-x", str(LIB_PATH)],
        capture_output=True,
        text=True,
    )
    assert proc.returncode == 0, f"shellcheck findings:\n{proc.stdout}{proc.stderr}"
