"""Tests for TokenCache user-scoped sweep methods (global logout support)."""

import hashlib
from unittest.mock import AsyncMock, MagicMock

import pytest

from okta_agent_proxy.cache.token_cache import TokenCache, _TOKEN_PREFIX


def _sts_prefix(user_id: str) -> str:
    user_hash = hashlib.sha256(user_id.encode()).hexdigest()[:12]
    return f"sts:{user_hash}:"


def test_invalidate_all_for_user_clears_idjag_keys():
    cache = TokenCache(max_size=100, ttl_seconds=3600)
    cache.set("userA", "hr-system", "tok-A-hr")
    cache.set("userA", "finance", "tok-A-fin", agent_id="agentX", connection_id="connY")
    cache.set("userB", "hr-system", "tok-B-hr")

    cache.invalidate_all_for_user("userA")

    assert cache.get("userA", "hr-system") is None
    assert cache.get("userA", "finance", agent_id="agentX", connection_id="connY") is None
    assert cache.get("userB", "hr-system") == "tok-B-hr"


def test_invalidate_all_for_user_clears_sts_keys_for_user():
    cache = TokenCache(max_size=100, ttl_seconds=3600)
    cache.set_sts_token("userA", "orn::resource:1", "sts-tok-1", expires_in=3600)
    cache.set_sts_token("userA", "orn::resource:2", "sts-tok-2", expires_in=3600)
    cache.set_sts_token("userB", "orn::resource:1", "sts-tok-3", expires_in=3600)

    cache.invalidate_all_for_user("userA")

    assert cache.get_sts_token("userA", "orn::resource:1") is None
    assert cache.get_sts_token("userA", "orn::resource:2") is None
    assert cache.get_sts_token("userB", "orn::resource:1") == "sts-tok-3"


def test_invalidate_all_for_user_clears_both_families():
    cache = TokenCache(max_size=100, ttl_seconds=3600)
    cache.set("userA", "hr-system", "idjag-tok")
    cache.set_sts_token("userA", "orn::res", "sts-tok", expires_in=3600)

    cache.invalidate_all_for_user("userA")

    assert cache.get("userA", "hr-system") is None
    assert cache.get_sts_token("userA", "orn::res") is None


def test_invalidate_all_for_user_no_match_is_noop():
    cache = TokenCache(max_size=100, ttl_seconds=3600)
    cache.set("userA", "hr-system", "tok-A")
    cache.set_sts_token("userA", "orn::res", "sts-A", expires_in=3600)

    # No entries for userZ — must not touch userA's entries.
    cache.invalidate_all_for_user("userZ")

    assert cache.get("userA", "hr-system") == "tok-A"
    assert cache.get_sts_token("userA", "orn::res") == "sts-A"


@pytest.mark.asyncio
async def test_ainvalidate_all_for_user_uses_cache_service_awaitably():
    """ainvalidate_all_for_user must await CacheService directly, not
    dispatch via the thread-pool fallback in _run_async."""
    mock_service = MagicMock()
    mock_service.clear_prefix = AsyncMock(return_value=0)

    cache = TokenCache(max_size=100, ttl_seconds=3600, cache_service=mock_service)
    await cache.ainvalidate_all_for_user("userA")

    prefixes = [call.args[0] for call in mock_service.clear_prefix.await_args_list]
    assert f"{_TOKEN_PREFIX}userA" in prefixes
    assert f"{_TOKEN_PREFIX}{_sts_prefix('userA')}" in prefixes
    assert mock_service.clear_prefix.await_count == 2


@pytest.mark.asyncio
async def test_ainvalidate_all_for_user_clears_both_families_without_service():
    cache = TokenCache(max_size=100, ttl_seconds=3600)
    cache.set("userA", "hr-system", "idjag-tok")
    cache.set_sts_token("userA", "orn::res", "sts-tok", expires_in=3600)
    cache.set("userB", "hr-system", "other-tok")

    await cache.ainvalidate_all_for_user("userA")

    assert cache.get("userA", "hr-system") is None
    assert cache.get_sts_token("userA", "orn::res") is None
    assert cache.get("userB", "hr-system") == "other-tok"
