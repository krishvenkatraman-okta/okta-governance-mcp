"""Integration tests for GET /api/admin/agents/{agent_id}/tools."""

from unittest.mock import patch
import pytest
from starlette.testclient import TestClient


@pytest.fixture
def mock_okta_env(monkeypatch):
    monkeypatch.setenv("OKTA_DOMAIN", "dev-test.okta.com")
    monkeypatch.setenv("OKTA_CLIENT_SECRET", "test_secret")
    monkeypatch.setenv("OKTA_ISSUER", "https://dev-test.okta.com")
    monkeypatch.setenv("GATEWAY_BASE_URL", "http://localhost:8000")
    monkeypatch.setenv("GATEWAY_PORT", "8000")
    monkeypatch.setenv("LOG_LEVEL", "ERROR")


@pytest.fixture
def test_app(mock_okta_env, postgres_store, monkeypatch):
    import okta_agent_proxy.app
    import okta_agent_proxy.database

    async def _fake_verify_okta_token(token):
        if not token or token == "invalid_token":
            return None
        return {
            "sub": "test-admin",
            "email": "test-admin@example.com",
            "username": "test-admin",
            "role": "admin",
            "token_type": "okta_oauth",
        }

    with patch("okta_agent_proxy.app.get_config_store", return_value=postgres_store), \
         patch("okta_agent_proxy.database.get_config_store", return_value=postgres_store), \
         patch(
             "okta_agent_proxy.admin.middleware.verify_okta_token",
             side_effect=_fake_verify_okta_token,
         ):
        from okta_agent_proxy.app import app, unified_handler
        unified_handler._tool_cache.clear()
        client = TestClient(app)
        yield client, unified_handler


@pytest.fixture
def auth_headers():
    return {"Authorization": "Bearer test-okta-access-token"}


def _seed_agent(store, agent_id):
    store.create_agent(
        agent_id,
        {
            "agent_name": agent_id,
            "agent_id": agent_id,
            "client_id": "0oa_test",
            "client_secret": "s",
            "private_key": '{"kty":"RSA","kid":"k","n":"n","e":"AQAB","d":"d"}',
            "scopes": [],
            "enabled": True,
        },
        user="test",
    )


def test_tools_endpoint_requires_auth(test_app):
    client, _ = test_app
    r = client.get("/api/admin/agents/does-not-matter/tools")
    assert r.status_code == 401


def test_tools_endpoint_missing_agent(test_app, auth_headers):
    client, _ = test_app
    r = client.get("/api/admin/agents/nope/tools", headers=auth_headers)
    assert r.status_code == 404


def test_tools_endpoint_empty_cache(test_app, auth_headers, postgres_store):
    client, _ = test_app
    _seed_agent(postgres_store, "empty-agent")
    r = client.get("/api/admin/agents/empty-agent/tools", headers=auth_headers)
    assert r.status_code == 200
    body = r.json()
    assert body == {
        "agent_id": "empty-agent",
        "cached": False,
        "total_tools": 0,
        "resources": [],
    }


def test_tools_endpoint_populated_cache(test_app, auth_headers, postgres_store):
    client, unified_handler = test_app
    _seed_agent(postgres_store, "vscode")

    # Seed the local tool cache the way _set_tool_catalog would.
    unified_handler._tool_cache["vscode"] = {
        "tools": [
            {"name": "github-jw__list_issues", "description": "List issues", "inputSchema": {}},
            {"name": "github-jw__create_issue", "description": "Create an issue", "inputSchema": {}},
            {"name": "deploy-server__deploy", "description": "Deploy", "inputSchema": {}},
        ],
        "tool_map": {
            "github-jw__list_issues": ("github-jw", "list_issues"),
            "github-jw__create_issue": ("github-jw", "create_issue"),
            "deploy-server__deploy": ("deploy-server", "deploy"),
        },
    }

    r = client.get("/api/admin/agents/vscode/tools", headers=auth_headers)
    assert r.status_code == 200
    body = r.json()
    assert body["agent_id"] == "vscode"
    assert body["cached"] is True
    assert body["total_tools"] == 3

    groups = {g["resource_name"]: g for g in body["resources"]}
    assert set(groups) == {"github-jw", "deploy-server"}
    assert groups["github-jw"]["tool_count"] == 2
    names = {t["name"] for t in groups["github-jw"]["tools"]}
    assert names == {"list_issues", "create_issue"}
    assert groups["deploy-server"]["tools"][0]["name"] == "deploy"


def test_tools_endpoint_non_namespaced_tool_grouped_as_unknown(
    test_app, auth_headers, postgres_store
):
    client, unified_handler = test_app
    _seed_agent(postgres_store, "weird-agent")
    unified_handler._tool_cache["weird-agent"] = {
        "tools": [{"name": "orphan", "description": "", "inputSchema": {}}],
        "tool_map": {},
    }
    r = client.get("/api/admin/agents/weird-agent/tools", headers=auth_headers)
    assert r.status_code == 200
    body = r.json()
    assert body["total_tools"] == 1
    assert body["resources"][0]["resource_name"] == "unknown"
    assert body["resources"][0]["tools"][0]["name"] == "orphan"
