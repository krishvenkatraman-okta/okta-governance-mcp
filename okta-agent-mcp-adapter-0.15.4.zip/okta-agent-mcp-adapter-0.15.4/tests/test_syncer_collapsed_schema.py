"""Integration tests for the collapsed-schema syncer path.

Verifies that `_merge_connections` materializes one row per (agent,
connection), that re-syncing preserves admin-editable fields, and that
the FK cascade from `agents` removes all per-agent rows.
"""

from __future__ import annotations

from unittest.mock import MagicMock

import pytest

from okta_agent_proxy.resources.syncer import OktaConnectionSyncer


@pytest.fixture
def agent_with_two_conns(postgres_store):
    postgres_store.create_agent(
        "adapter-agent",
        {
            "agent_name": "adapter-agent",
            "agent_id": "adapter-agent",
            "client_id": "0oa_adapter",
            "private_key": '{"kty":"RSA","n":"x","e":"AQAB"}',
            "scopes": [],
            "enabled": True,
        },
        user="test",
    )
    return "adapter-agent"


@pytest.fixture
def syncer(postgres_store):
    bus = MagicMock()
    bus.subscribe = MagicMock()
    s = OktaConnectionSyncer(
        okta_domain="https://test.okta.com",
        api_token="tok",
        resource_store=postgres_store._resources,
        event_bus=bus,
    )
    return s


CONN_A = {
    "id": "conn-a",
    "connectionType": "IDENTITY_ASSERTION_CUSTOM_AS",
    "status": "ACTIVE",
    "name": "hr-connection",
    "authorizationServer": {
        "orn": "orn:okta:idp:00oabc:authorization_servers:ausA",
        "issuerUrl": "https://test.okta.com/oauth2/ausA",
    },
    "scopes": ["read"],
    "scopeCondition": "INCLUDE_ONLY",
}

CONN_B = {
    "id": "conn-b",
    "connectionType": "IDENTITY_ASSERTION_CUSTOM_AS",
    "status": "ACTIVE",
    "name": "finance-connection",
    "authorizationServer": {
        "orn": "orn:okta:idp:00oabc:authorization_servers:ausB",
        "issuerUrl": "https://test.okta.com/oauth2/ausB",
    },
    "scopes": ["write"],
    "scopeCondition": "INCLUDE_ONLY",
}


def test_merge_creates_one_row_per_connection(
    postgres_store, syncer, agent_with_two_conns
):
    agent_info = {"agent_id": agent_with_two_conns, "agent_name": "adapter"}
    annotated = [(CONN_A, agent_info), (CONN_B, agent_info)]

    # _merge_connections only produces ResolvedResource for enabled rows;
    # here new rows start disabled so `resolved` is empty but the DB rows
    # exist with the correct sync state.
    resolved, _ = syncer._merge_connections(
        [CONN_A, CONN_B], annotated_connections=annotated
    )
    assert resolved == {}

    rows = postgres_store.get_all_resources()
    assert len(rows) == 2
    by_conn = {r["connection_id"]: r for r in rows}
    assert set(by_conn) == {"conn-a", "conn-b"}
    assert by_conn["conn-a"]["scopes"] == ["read"]
    assert by_conn["conn-b"]["scopes"] == ["write"]
    assert all(r["enabled"] is False for r in rows)


def test_resync_preserves_admin_edits(
    postgres_store, syncer, agent_with_two_conns
):
    agent_info = {"agent_id": agent_with_two_conns, "agent_name": "adapter"}
    syncer._merge_connections([CONN_A], annotated_connections=[(CONN_A, agent_info)])

    # Admin sets URL + enables
    rows = postgres_store.get_all_resources()
    name = rows[0]["name"]
    postgres_store.update_resource(
        name, {"url": "https://hr.example.com", "enabled": True}, user="admin"
    )

    # Okta updates scopes; re-sync
    conn_a_updated = dict(CONN_A, scopes=["read", "list"])
    resolved, _ = syncer._merge_connections(
        [conn_a_updated], annotated_connections=[(conn_a_updated, agent_info)]
    )

    refreshed = postgres_store.get_resource(name)
    assert refreshed["scopes"] == ["read", "list"]
    assert refreshed["url"] == "https://hr.example.com"
    assert refreshed["enabled"] is True
    # Now enabled, so the merged output contains it
    assert len(resolved) == 1


def test_fk_cascade_on_agent_delete(postgres_store, syncer, agent_with_two_conns):
    agent_info = {"agent_id": agent_with_two_conns, "agent_name": "adapter"}
    syncer._merge_connections(
        [CONN_A, CONN_B],
        annotated_connections=[(CONN_A, agent_info), (CONN_B, agent_info)],
    )
    assert len(postgres_store.get_all_resources()) == 2

    postgres_store.delete_agent(agent_with_two_conns, user="test")
    assert postgres_store.get_all_resources() == []
