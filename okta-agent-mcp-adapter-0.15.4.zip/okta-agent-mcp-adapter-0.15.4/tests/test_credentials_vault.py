"""Tests for the HashiCorp Vault dynamic DB credential provider (P12).

``hvac.Client`` is mocked — these tests never touch a real Vault
instance. End-to-end validation belongs in a deployment-specific smoke
test.
"""

from __future__ import annotations

import sys
from unittest.mock import MagicMock

import pytest

from okta_agent_proxy.storage.credentials import (
    DatabaseCredentialProvider,
    get_credential_provider,
)
from okta_agent_proxy.storage.credentials_vault import (
    _DEFAULT_LEASE_SECONDS,
    _LEASE_REFRESH_FRACTION,
    _MIN_LEASE_SECONDS,
    VaultDbCredentialProvider,
)


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


@pytest.fixture()
def vault_env(monkeypatch):
    """Populate the env vars the Vault provider requires (minus auth)."""
    monkeypatch.setenv("DB_HOST", "db.example.com")
    monkeypatch.setenv("DB_PORT", "5432")
    monkeypatch.setenv("DB_NAME", "gateway_db")
    monkeypatch.setenv("VAULT_ADDR", "https://vault.example.com:8200")
    monkeypatch.setenv("VAULT_DB_ROLE", "okta-adapter-app")
    monkeypatch.delenv("VAULT_DB_MOUNT", raising=False)
    monkeypatch.delenv("VAULT_TOKEN", raising=False)
    monkeypatch.delenv("VAULT_K8S_ROLE", raising=False)
    monkeypatch.delenv("VAULT_K8S_AUTH_PATH", raising=False)
    monkeypatch.delenv("K8S_SA_TOKEN_PATH", raising=False)
    monkeypatch.delenv("VAULT_APPROLE_ROLE_ID", raising=False)
    monkeypatch.delenv("VAULT_APPROLE_SECRET_ID", raising=False)
    monkeypatch.delenv("DB_SSLMODE", raising=False)
    monkeypatch.delenv("DB_SSLROOTCERT", raising=False)


def _fake_generate_credentials_response(
    username: str = "v-root-xyz",
    password: str = "s3cret",
    lease_duration: int = 3600,
):
    return {
        "data": {"username": username, "password": password},
        "lease_duration": lease_duration,
    }


def _fake_hvac_client(
    *,
    is_authenticated: bool = True,
    generate_responses=None,
):
    client = MagicMock()
    client.is_authenticated.return_value = is_authenticated
    if generate_responses is None:
        generate_responses = [_fake_generate_credentials_response()]
    client.secrets.database.generate_credentials.side_effect = generate_responses
    return client


@pytest.fixture()
def fake_hvac_module(monkeypatch):
    """Replace the `hvac` module so `_build_client` uses our mock."""
    fake_hvac = MagicMock()
    fake_client = _fake_hvac_client()
    fake_hvac.Client.return_value = fake_client
    monkeypatch.setitem(sys.modules, "hvac", fake_hvac)
    return fake_hvac


# ---------------------------------------------------------------------------
# Auth-method selection
# ---------------------------------------------------------------------------


def test_vault_provider_uses_token_auth_when_set(vault_env, fake_hvac_module, monkeypatch):
    monkeypatch.setenv("VAULT_TOKEN", "dev-root-token")

    provider = VaultDbCredentialProvider()

    # Token auth path assigns client.token directly; Kubernetes / AppRole
    # login methods must not have been called.
    assert provider._client.token == "dev-root-token"
    provider._client.auth.kubernetes.login.assert_not_called()
    provider._client.auth.approle.login.assert_not_called()


def test_vault_provider_uses_k8s_auth_when_role_set(
    vault_env, fake_hvac_module, monkeypatch, tmp_path
):
    sa_token = tmp_path / "sa-token"
    sa_token.write_text("eyJhbGc...sa-jwt\n")

    monkeypatch.setenv("VAULT_K8S_ROLE", "okta-adapter")
    monkeypatch.setenv("K8S_SA_TOKEN_PATH", str(sa_token))

    provider = VaultDbCredentialProvider()

    provider._client.auth.kubernetes.login.assert_called_once_with(
        role="okta-adapter",
        jwt="eyJhbGc...sa-jwt",  # stripped
        mount_point="kubernetes",
    )
    provider._client.auth.approle.login.assert_not_called()


def test_vault_provider_k8s_auth_respects_custom_mount(
    vault_env, fake_hvac_module, monkeypatch, tmp_path
):
    sa_token = tmp_path / "sa-token"
    sa_token.write_text("sa-jwt")
    monkeypatch.setenv("VAULT_K8S_ROLE", "okta-adapter")
    monkeypatch.setenv("VAULT_K8S_AUTH_PATH", "k8s-prod")
    monkeypatch.setenv("K8S_SA_TOKEN_PATH", str(sa_token))

    provider = VaultDbCredentialProvider()
    _, kwargs = provider._client.auth.kubernetes.login.call_args
    assert kwargs["mount_point"] == "k8s-prod"


def test_vault_provider_uses_approle_auth_when_role_id_set(
    vault_env, fake_hvac_module, monkeypatch
):
    monkeypatch.setenv("VAULT_APPROLE_ROLE_ID", "role-123")
    monkeypatch.setenv("VAULT_APPROLE_SECRET_ID", "secret-abc")

    provider = VaultDbCredentialProvider()

    provider._client.auth.approle.login.assert_called_once_with(
        role_id="role-123", secret_id="secret-abc"
    )


def test_vault_provider_approle_missing_secret_id_raises(
    vault_env, fake_hvac_module, monkeypatch
):
    monkeypatch.setenv("VAULT_APPROLE_ROLE_ID", "role-123")
    # No VAULT_APPROLE_SECRET_ID.

    with pytest.raises(RuntimeError) as exc:
        VaultDbCredentialProvider()
    assert "VAULT_APPROLE_SECRET_ID" in str(exc.value)


def test_vault_provider_no_auth_raises_clear_error(vault_env, fake_hvac_module):
    # None of VAULT_TOKEN / VAULT_K8S_ROLE / VAULT_APPROLE_ROLE_ID is set.
    with pytest.raises(RuntimeError) as exc:
        VaultDbCredentialProvider()
    msg = str(exc.value)
    assert "VAULT_TOKEN" in msg
    assert "VAULT_K8S_ROLE" in msg
    assert "VAULT_APPROLE_ROLE_ID" in msg
    # Error must point the operator at the runbook.
    assert "HashiCorp Vault" in msg


def test_vault_provider_auth_failure_raises(vault_env, monkeypatch):
    # is_authenticated() returning False after a successful transport
    # call must still be treated as a hard failure.
    fake_hvac = MagicMock()
    fake_client = _fake_hvac_client(is_authenticated=False)
    fake_hvac.Client.return_value = fake_client
    monkeypatch.setitem(sys.modules, "hvac", fake_hvac)
    monkeypatch.setenv("VAULT_TOKEN", "bad-token")

    with pytest.raises(RuntimeError) as exc:
        VaultDbCredentialProvider()
    assert "is_authenticated()" in str(exc.value)


# ---------------------------------------------------------------------------
# Credential generation & caching
# ---------------------------------------------------------------------------


def test_generate_credentials_called_with_role_and_mount(vault_env, monkeypatch):
    client = _fake_hvac_client()
    monkeypatch.setenv("VAULT_DB_MOUNT", "database-prod")

    provider = VaultDbCredentialProvider(hvac_client=client)
    provider.get_credential()

    client.secrets.database.generate_credentials.assert_called_once_with(
        name="okta-adapter-app", mount_point="database-prod"
    )


def test_get_credential_returns_vault_username_password_as_fields(vault_env):
    client = _fake_hvac_client(
        generate_responses=[
            _fake_generate_credentials_response(
                username="v-approle-okta-abc", password="pwd-1", lease_duration=600
            ),
        ]
    )
    provider = VaultDbCredentialProvider(hvac_client=client)

    cred = provider.get_credential()

    assert cred.username == "v-approle-okta-abc"
    assert cred.password == "pwd-1"
    assert cred.host == "db.example.com"
    assert cred.port == 5432
    assert cred.dbname == "gateway_db"
    assert cred.ttl_seconds == 600


def test_credential_cached_until_80_percent_lease(vault_env):
    # Two distinct responses so we can detect an unexpected re-issue.
    client = _fake_hvac_client(
        generate_responses=[
            _fake_generate_credentials_response(
                username="v-1", password="p1", lease_duration=1000
            ),
            _fake_generate_credentials_response(
                username="v-2", password="p2", lease_duration=1000
            ),
        ]
    )
    provider = VaultDbCredentialProvider(hvac_client=client)

    cred1 = provider.get_credential()
    cred2 = provider.get_credential()

    # Within the 80% lease window, the cached credential is returned.
    assert cred1 is cred2
    assert client.secrets.database.generate_credentials.call_count == 1


def test_credential_refreshed_after_lease_window(vault_env, monkeypatch):
    client = _fake_hvac_client(
        generate_responses=[
            _fake_generate_credentials_response(
                username="v-1", password="p1", lease_duration=1000
            ),
            _fake_generate_credentials_response(
                username="v-2", password="p2", lease_duration=1000
            ),
        ]
    )
    provider = VaultDbCredentialProvider(hvac_client=client)

    cred1 = provider.get_credential()

    # Fast-forward the monotonic clock past the 80% refresh point.
    import okta_agent_proxy.storage.credentials_vault as mod

    fake_now = [0.0]

    def fake_monotonic():
        return fake_now[0]

    monkeypatch.setattr(mod.time, "monotonic", fake_monotonic)
    # First issuance already happened at 0.0 — advance clock past refresh.
    # Re-prime cache timestamp so the monkeypatched monotonic takes effect
    # from here on out.
    provider._cached_until = 0.0 + (cred1.ttl_seconds * _LEASE_REFRESH_FRACTION)
    fake_now[0] = provider._cached_until + 1.0

    cred2 = provider.get_credential()

    assert cred1.username == "v-1"
    assert cred2.username == "v-2"
    assert cred1 is not cred2
    assert client.secrets.database.generate_credentials.call_count == 2


def test_missing_lease_duration_uses_default(vault_env):
    # A malformed response without lease_duration should fall back to
    # the default rather than crashing.
    bad_resp = {"data": {"username": "v-x", "password": "p"}}
    client = _fake_hvac_client(generate_responses=[bad_resp])

    provider = VaultDbCredentialProvider(hvac_client=client)
    cred = provider.get_credential()

    assert cred.ttl_seconds == _DEFAULT_LEASE_SECONDS


def test_tiny_lease_floored_to_min(vault_env):
    # A pathologically small lease gets floored so the cache window and
    # pool max_lifetime stay sensible.
    client = _fake_hvac_client(
        generate_responses=[
            _fake_generate_credentials_response(lease_duration=5),
        ]
    )

    provider = VaultDbCredentialProvider(hvac_client=client)
    cred = provider.get_credential()

    assert cred.ttl_seconds == _MIN_LEASE_SECONDS
    assert cred.ttl_seconds >= 60


def test_sslmode_defaults_to_require(vault_env):
    client = _fake_hvac_client()
    provider = VaultDbCredentialProvider(hvac_client=client)
    cred = provider.get_credential()

    assert cred.sslmode == "require"
    assert cred.sslrootcert is None


def test_sslmode_and_sslrootcert_overridable(vault_env, monkeypatch):
    monkeypatch.setenv("DB_SSLMODE", "verify-full")
    monkeypatch.setenv("DB_SSLROOTCERT", "/etc/ssl/ca.pem")
    client = _fake_hvac_client()

    provider = VaultDbCredentialProvider(hvac_client=client)
    cred = provider.get_credential()

    assert cred.sslmode == "verify-full"
    assert cred.sslrootcert == "/etc/ssl/ca.pem"


# ---------------------------------------------------------------------------
# Provider contract / factory
# ---------------------------------------------------------------------------


def test_supports_rotation_true(vault_env):
    client = _fake_hvac_client()
    provider = VaultDbCredentialProvider(hvac_client=client)

    assert provider.supports_rotation() is True
    assert provider.name == "vault"
    assert isinstance(provider, DatabaseCredentialProvider)


def test_missing_env_vars_raises_clear_error(monkeypatch):
    for var in (
        "DB_HOST",
        "DB_PORT",
        "DB_NAME",
        "VAULT_ADDR",
        "VAULT_DB_ROLE",
        "VAULT_DB_MOUNT",
        "VAULT_TOKEN",
        "VAULT_K8S_ROLE",
        "VAULT_APPROLE_ROLE_ID",
        "DB_SSLMODE",
        "DB_SSLROOTCERT",
    ):
        monkeypatch.delenv(var, raising=False)

    with pytest.raises(RuntimeError) as exc:
        VaultDbCredentialProvider(hvac_client=MagicMock())

    msg = str(exc.value)
    assert "DB_HOST" in msg
    assert "DB_NAME" in msg
    assert "VAULT_DB_ROLE" in msg
    assert "HashiCorp Vault" in msg


def test_get_credential_provider_vault_returns_vault_provider(
    vault_env, monkeypatch
):
    # P12 makes 'vault' a real provider, not a NotImplementedError stub.
    monkeypatch.setenv("DB_CREDENTIAL_PROVIDER", "vault")
    monkeypatch.setenv("VAULT_TOKEN", "dev-token")

    fake_hvac = MagicMock()
    fake_hvac.Client.return_value = _fake_hvac_client()
    monkeypatch.setitem(sys.modules, "hvac", fake_hvac)

    provider = get_credential_provider()

    assert isinstance(provider, VaultDbCredentialProvider)
    assert provider.supports_rotation() is True
    assert provider.name == "vault"
