"""Tests for AgentKeyManager — RSA key generation and Okta registration."""

import base64
import json
import logging
import re
from unittest.mock import AsyncMock, MagicMock

import httpx
import pytest
from jose import jwt as jose_jwt
from jose import jwk as jose_jwk

from okta_agent_proxy.okta_admin.client import OktaAPIClient
from okta_agent_proxy.okta_admin.exceptions import (
    OktaAdminAPIError,
    OktaAdminForbiddenError,
    OktaAdminNotFoundError,
)
from okta_agent_proxy.okta_admin.key_manager import AgentKeyManager

FAKE_TOKEN = "admin-token-keymgr"
OKTA_DOMAIN = "https://dev-12345.oktapreview.com"

UUID4_RE = re.compile(
    r"^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$"
)


def _make_response(json_body, status_code=200):
    return httpx.Response(
        status_code=status_code,
        json=json_body,
        request=httpx.Request("POST", OKTA_DOMAIN),
    )


@pytest.fixture
def api_client():
    client = MagicMock(spec=OktaAPIClient)
    client.get = AsyncMock()
    client.post = AsyncMock()
    return client


@pytest.fixture
def mgr(api_client):
    return AgentKeyManager(api_client)


# ── generate_key_pair — JWK structure ────────────────────────────────────

def test_public_jwk_structure(mgr):
    pub, _ = mgr.generate_key_pair()
    assert pub["kty"] == "RSA"
    assert pub["use"] == "sig"
    assert pub["alg"] == "RS256"
    assert "n" in pub
    assert "e" in pub
    assert "kid" in pub
    # Public JWK must NOT have private components
    for field in ("d", "p", "q", "dp", "dq", "qi"):
        assert field not in pub


def test_private_jwk_structure(mgr):
    _, priv = mgr.generate_key_pair()
    assert priv["kty"] == "RSA"
    assert priv["use"] == "sig"
    assert priv["alg"] == "RS256"
    for field in ("n", "e", "d", "p", "q", "dp", "dq", "qi", "kid"):
        assert field in priv, f"Missing field: {field}"


def test_kid_is_uuid4(mgr):
    pub, priv = mgr.generate_key_pair()
    assert UUID4_RE.match(pub["kid"])
    assert pub["kid"] == priv["kid"]


def test_base64url_no_padding(mgr):
    pub, priv = mgr.generate_key_pair()
    for key_dict in (pub, priv):
        for field in ("n", "e"):
            assert "=" not in key_dict[field], f"Padding found in {field}"
            assert "+" not in key_dict[field], f"Non-urlsafe char in {field}"
            assert "/" not in key_dict[field], f"Non-urlsafe char in {field}"


def test_public_components_match(mgr):
    pub, priv = mgr.generate_key_pair()
    assert pub["n"] == priv["n"]
    assert pub["e"] == priv["e"]


def test_different_calls_generate_different_keys(mgr):
    pub1, _ = mgr.generate_key_pair()
    pub2, _ = mgr.generate_key_pair()
    assert pub1["kid"] != pub2["kid"]
    assert pub1["n"] != pub2["n"]


def test_custom_key_size(mgr):
    pub, priv = mgr.generate_key_pair(key_size=4096)
    # 4096-bit key → n should be longer than 2048-bit
    assert len(pub["n"]) > 300  # 4096-bit n is ~683 base64url chars


def test_e_is_65537(mgr):
    pub, _ = mgr.generate_key_pair()
    # 65537 = 0x10001 → base64url of b'\x01\x00\x01' = "AQAB"
    assert pub["e"] == "AQAB"


# ── generate_key_pair — cryptographic validity ───────────────────────────

def test_sign_verify_with_cryptography_lib(mgr):
    """Verify the generated key pair works for sign/verify."""
    pub, priv = mgr.generate_key_pair()
    assert mgr.validate_key_pair(pub, priv)


def test_sign_verify_with_jose(mgr):
    """Verify generated keys produce valid JWTs via python-jose."""
    pub, priv = mgr.generate_key_pair()

    # Sign a JWT with private key
    token = jose_jwt.encode(
        {"sub": "test-agent", "iss": "test"},
        priv,
        algorithm="RS256",
        headers={"kid": priv["kid"]},
    )

    # Verify with public key
    claims = jose_jwt.decode(
        token,
        pub,
        algorithms=["RS256"],
        options={"verify_aud": False},
    )
    assert claims["sub"] == "test-agent"


# ── validate_key_pair ────────────────────────────────────────────────────

def test_validate_valid_pair(mgr):
    pub, priv = mgr.generate_key_pair()
    assert mgr.validate_key_pair(pub, priv) is True


def test_validate_mismatched_kid(mgr):
    pub, priv = mgr.generate_key_pair()
    pub2 = {**pub, "kid": "wrong-kid"}
    assert mgr.validate_key_pair(pub2, priv) is False


def test_validate_mismatched_n(mgr):
    pub1, _ = mgr.generate_key_pair()
    _, priv2 = mgr.generate_key_pair()
    # Force same kid to isolate n mismatch
    pub1["kid"] = priv2["kid"]
    assert mgr.validate_key_pair(pub1, priv2) is False


def test_validate_mismatched_e(mgr):
    pub, priv = mgr.generate_key_pair()
    pub_bad = {**pub, "e": "AAAA"}
    assert mgr.validate_key_pair(pub_bad, priv) is False


# ── register_public_key ──────────────────────────────────────────────────

@pytest.mark.asyncio
async def test_register_public_key_success(mgr, api_client):
    pub, _ = mgr.generate_key_pair()
    api_client.post.return_value = _make_response({"kid": pub["kid"], "status": "ACTIVE"})
    result = await mgr.register_public_key("agt1abc", pub, FAKE_TOKEN)
    assert result["kid"] == pub["kid"]
    api_client.post.assert_called_once_with(
        f"/workload-principals/api/v1/ai-agents/agt1abc/credentials/jwks",
        FAKE_TOKEN,
        json=pub,
    )


@pytest.mark.asyncio
async def test_register_public_key_404(mgr, api_client):
    pub, _ = mgr.generate_key_pair()
    api_client.post.side_effect = OktaAdminNotFoundError("not found")
    with pytest.raises(OktaAdminNotFoundError):
        await mgr.register_public_key("missing", pub, FAKE_TOKEN)


@pytest.mark.asyncio
async def test_register_public_key_403(mgr, api_client):
    pub, _ = mgr.generate_key_pair()
    api_client.post.side_effect = OktaAdminForbiddenError("forbidden")
    with pytest.raises(OktaAdminForbiddenError):
        await mgr.register_public_key("agt1abc", pub, FAKE_TOKEN)


@pytest.mark.asyncio
async def test_register_public_key_api_error(mgr, api_client):
    pub, _ = mgr.generate_key_pair()
    api_client.post.side_effect = OktaAdminAPIError("err", status_code=500, error_description="boom")
    with pytest.raises(OktaAdminAPIError):
        await mgr.register_public_key("agt1abc", pub, FAKE_TOKEN)


# ── list_agent_keys ──────────────────────────────────────────────────────

@pytest.mark.asyncio
async def test_list_agent_keys_success(mgr, api_client):
    keys = [{"kid": "k1", "kty": "RSA"}, {"kid": "k2", "kty": "RSA"}]
    api_client.get.return_value = _make_response(keys)
    result = await mgr.list_agent_keys("agt1abc", FAKE_TOKEN)
    assert len(result) == 2
    api_client.get.assert_called_once_with(
        "/workload-principals/api/v1/ai-agents/agt1abc/credentials/jwks",
        FAKE_TOKEN,
    )


@pytest.mark.asyncio
async def test_list_agent_keys_empty(mgr, api_client):
    api_client.get.return_value = _make_response([])
    result = await mgr.list_agent_keys("agt1abc", FAKE_TOKEN)
    assert result == []


@pytest.mark.asyncio
async def test_list_agent_keys_404(mgr, api_client):
    api_client.get.side_effect = OktaAdminNotFoundError("not found")
    with pytest.raises(OktaAdminNotFoundError):
        await mgr.list_agent_keys("missing", FAKE_TOKEN)


# ── generate_and_register ────────────────────────────────────────────────

@pytest.mark.asyncio
async def test_generate_and_register_e2e(mgr, api_client):
    api_client.post.return_value = _make_response({"status": "ACTIVE"})
    pub, priv = await mgr.generate_and_register("agt1abc", FAKE_TOKEN)

    # Both returned
    assert "n" in pub and "e" in pub
    assert "d" in priv and "p" in priv

    # Only public key sent to Okta
    call_args = api_client.post.call_args
    sent_json = call_args.kwargs.get("json") or call_args[0][2] if len(call_args[0]) > 2 else call_args.kwargs["json"]
    assert "d" not in sent_json, "Private key component must NEVER be sent to Okta"
    assert "p" not in sent_json
    assert "q" not in sent_json


@pytest.mark.asyncio
async def test_generate_and_register_private_has_all_crt(mgr, api_client):
    api_client.post.return_value = _make_response({"status": "ACTIVE"})
    _, priv = await mgr.generate_and_register("agt1abc", FAKE_TOKEN)
    for field in ("d", "p", "q", "dp", "dq", "qi"):
        assert field in priv, f"Missing CRT field: {field}"


@pytest.mark.asyncio
async def test_generate_and_register_custom_key_size(mgr, api_client):
    api_client.post.return_value = _make_response({"status": "ACTIVE"})
    pub, _ = await mgr.generate_and_register("agt1abc", FAKE_TOKEN, key_size=4096)
    assert len(pub["n"]) > 300


# ── Private key never logged ─────────────────────────────────────────────

@pytest.mark.asyncio
async def test_private_key_not_logged(mgr, api_client, caplog):
    api_client.post.return_value = _make_response({"status": "ACTIVE"})
    with caplog.at_level(logging.DEBUG, logger="okta_agent_proxy.okta_admin.key_manager"):
        pub, priv = await mgr.generate_and_register("agt1abc", FAKE_TOKEN)

    # Check that no private key component values appear in logs
    for record in caplog.records:
        msg = record.getMessage()
        assert priv["d"][:20] not in msg, "Private key 'd' must never appear in logs"
        assert priv["p"][:20] not in msg, "Private key 'p' must never appear in logs"


@pytest.mark.asyncio
async def test_token_not_logged(mgr, api_client, caplog):
    api_client.post.return_value = _make_response({"status": "ACTIVE"})
    with caplog.at_level(logging.DEBUG, logger="okta_agent_proxy.okta_admin.key_manager"):
        await mgr.generate_and_register("agt1abc", FAKE_TOKEN)

    for record in caplog.records:
        assert FAKE_TOKEN not in record.getMessage(), "Token must never appear in logs"


# ── Only public JWK sent to Okta (explicit verification) ────────────────

@pytest.mark.asyncio
async def test_register_sends_only_public_jwk(mgr, api_client):
    """Explicitly verify that the POST body has zero private key fields."""
    pub, priv = mgr.generate_key_pair()
    api_client.post.return_value = _make_response({"kid": pub["kid"]})
    await mgr.register_public_key("agt1abc", pub, FAKE_TOKEN)

    sent = api_client.post.call_args.kwargs.get("json")
    if sent is None:
        sent = api_client.post.call_args[0][2]
    private_fields = {"d", "p", "q", "dp", "dq", "qi"}
    assert private_fields.isdisjoint(sent.keys()), (
        f"Private key fields found in Okta POST: {private_fields & sent.keys()}"
    )
