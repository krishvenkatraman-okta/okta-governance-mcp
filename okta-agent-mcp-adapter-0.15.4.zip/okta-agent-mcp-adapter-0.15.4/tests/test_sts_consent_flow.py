"""
Integration tests for the STS OAuth Consent flow.

Tests the full lifecycle:
1. First call → interaction_required → MCP error with consent_url
2. Second call (post-consent) → success → proxied request with Bearer token
3. Third call → cache hit → proxied request (no exchange)

Also covers:
- Consent URL deduplication (multiple rapid calls)
- Token expiry and re-exchange
- Error propagation (non-interaction_required errors)
- MCP JSON-RPC error structure for consent_required
"""

import pytest
from unittest.mock import AsyncMock, MagicMock, patch

from okta_agent_proxy.proxy.handler import ProxyHandler
from okta_agent_proxy.mcp.unified_handler import UnifiedMCPHandler
from okta_agent_proxy.auth.resource_token_resolver import ResourceAuthResult


# ---------------------------------------------------------------------------
# Shared mock data
# ---------------------------------------------------------------------------

MOCK_INTERACTION_REQUIRED = {
    "error": "interaction_required",
    "error_description": "User interaction required",
    "interaction_uri": "https://test.okta.com/oauth2/v1/sts/redirect?dataHandle=test123",
}

MOCK_STS_SUCCESS = {
    "access_token": "gho_test_token_xxx",
    "token_type": "Bearer",
    "expires_in": 28800,
    "issued_token_type": "urn:okta:params:oauth:token-type:oauth-sts",
}

RESOURCE_INDICATOR = "orn:oktapreview:idp:00o:client-auth-settings:rsc123"


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _mock_httpx_response(status_code, json_body):
    resp = MagicMock()
    resp.status_code = status_code
    resp.json.return_value = json_body
    resp.headers = {"content-type": "application/json"}
    resp.text = ""
    return resp


def _make_proxy_handler():
    """Create a ProxyHandler wired for okta-sts with mocked dependencies."""
    router = MagicMock()
    router.get_resource_for_path.return_value = "github-org"

    resource_config = MagicMock()
    resource_config.url = "https://github.example.com/mcp"
    resource_config.auth_method = "okta-sts"
    resource_config.enabled = True
    resource_config.metadata = {
        "resource_indicator": RESOURCE_INDICATOR,
        "app_instance_name": "GitHub Enterprise",
    }
    router.get_resource_config.return_value = resource_config

    # Token cache
    from okta_agent_proxy.cache.token_cache import TokenCache
    token_cache = TokenCache(max_size=100, ttl_seconds=3600)
    router.get_token_cache.return_value = token_cache

    validator = MagicMock()
    validator.validate_token = AsyncMock(return_value={
        "sub": "user@example.com",
        "aud": "0oa_test",
        "cid": "0oa_test",
    })

    store = MagicMock()
    store.get_all_agents.return_value = []
    store.get_agent_by_name.return_value = {
        "agent_id": "test-agent",
        "client_id": "0oa_test",
        "private_key": "PLACEHOLDER",
        "principal_id": "agt123",
        "resource_access": ["github-org"],
        "enabled": True,
    }

    resolver = MagicMock()
    resolver.resolve_auth_headers = AsyncMock()
    router.resolver = resolver

    handler = ProxyHandler(router, validator, store)
    return handler, router, token_cache


def _make_unified_handler():
    """Create a UnifiedMCPHandler wired for okta-sts."""
    router = MagicMock()

    resource_config = MagicMock()
    resource_config.url = "https://github.example.com/mcp"
    resource_config.auth_method = "okta-sts"
    resource_config.enabled = True
    resource_config.metadata = {
        "resource_indicator": RESOURCE_INDICATOR,
        "app_instance_name": "GitHub Enterprise",
    }
    router.get_resource_config.return_value = resource_config

    from okta_agent_proxy.cache.token_cache import TokenCache
    token_cache = TokenCache(max_size=100, ttl_seconds=3600)
    router.get_token_cache.return_value = token_cache

    validator = MagicMock()
    store = MagicMock()

    resolver = MagicMock()
    resolver.resolve_auth_headers = AsyncMock()
    router.resolver = resolver

    handler = UnifiedMCPHandler(router, validator, store)
    return handler, token_cache


# ============================================================================
# Full consent flow — proxy handler
# ============================================================================


class TestFullConsentFlowProxy:
    """End-to-end: interaction_required → consent → success → cache hit."""

    @pytest.mark.asyncio
    @patch("okta_agent_proxy.proxy.handler.check_agent_can_access_resource", new_callable=AsyncMock, return_value=True)
    async def test_first_call_returns_consent_error(self, mock_authz):
        """First call triggers STS exchange → interaction_required → consent error."""
        handler, router, _ = _make_proxy_handler()

        consent_data = {
            "status": "consent_required",
            "interaction_uri": MOCK_INTERACTION_REQUIRED["interaction_uri"],
            "provider": "GitHub Enterprise",
            "error_description": MOCK_INTERACTION_REQUIRED["error_description"],
            "resource_indicator": RESOURCE_INDICATOR,
        }

        router.resolver.resolve_auth_headers = AsyncMock(return_value=ResourceAuthResult(
            consent_required=consent_data,
            error="consent_required",
            error_message="User consent required",
        ))

        result = await handler.proxy_request(
            request_path="/github-org",
            method="tools/call",
            params={"name": "list_repos"},
            auth_header="Bearer eyJ.test.token",
            headers={"X-MCP-Agent": "test-agent"},
        )

        assert result["error"] == "consent_required"
        assert result["consent_url"] == MOCK_INTERACTION_REQUIRED["interaction_uri"]
        assert result["provider"] == "GitHub Enterprise"
        assert result["expires_in"] == 600
        assert "re-run" in result["retry_hint"].lower()

    @pytest.mark.asyncio
    @patch("okta_agent_proxy.proxy.handler.check_agent_can_access_resource", new_callable=AsyncMock, return_value=True)
    async def test_second_call_after_consent_succeeds(self, mock_authz):
        """After user consents, STS exchange returns access token."""
        handler, router, _ = _make_proxy_handler()

        router.resolver.resolve_auth_headers = AsyncMock(return_value=ResourceAuthResult(
            headers={"Authorization": f"Bearer {MOCK_STS_SUCCESS['access_token']}"},
        ))

        with patch("okta_agent_proxy.proxy.handler.httpx.AsyncClient") as mock_httpx:
            mock_response = _mock_httpx_response(200, {
                "jsonrpc": "2.0", "id": "1",
                "result": {"content": [{"type": "text", "text": "repos: [my-repo]"}]},
            })
            mock_client = AsyncMock()
            mock_client.post.return_value = mock_response
            mock_client.__aenter__ = AsyncMock(return_value=mock_client)
            mock_client.__aexit__ = AsyncMock(return_value=False)
            mock_httpx.return_value = mock_client

            handler.session_manager.get_or_create_session = AsyncMock(return_value="session-1")

            result = await handler.proxy_request(
                request_path="/github-org",
                method="tools/call",
                params={"name": "list_repos"},
                auth_header="Bearer eyJ.test.token",
                headers={"X-MCP-Agent": "test-agent"},
            )

        assert "error" not in result or result.get("error") is None
        # Verify the Bearer token was injected into the proxied request
        post_call = mock_client.post.call_args
        auth_header = post_call.kwargs["headers"].get("Authorization", "")
        assert auth_header == f"Bearer {MOCK_STS_SUCCESS['access_token']}"

    @pytest.mark.asyncio
    @patch("okta_agent_proxy.proxy.handler.check_agent_can_access_resource", new_callable=AsyncMock, return_value=True)
    async def test_third_call_uses_cache(self, mock_authz):
        """Third call hits token cache — no STS exchange."""
        from okta_agent_proxy.auth.resource_token_resolver import ResourceTokenResolver

        handler, router, token_cache = _make_proxy_handler()

        # Pre-populate cache
        token_cache.set_sts_token(
            "user@example.com", RESOURCE_INDICATOR,
            MOCK_STS_SUCCESS["access_token"], MOCK_STS_SUCCESS["expires_in"],
        )

        # Use real resolver so it checks the cache
        resolver = ResourceTokenResolver(token_cache)
        router.resolver = resolver

        with patch("okta_agent_proxy.proxy.handler.httpx.AsyncClient") as mock_httpx:
            mock_response = _mock_httpx_response(200, {
                "jsonrpc": "2.0", "id": "1",
                "result": {"content": [{"type": "text", "text": "cached result"}]},
            })
            mock_client = AsyncMock()
            mock_client.post.return_value = mock_response
            mock_client.__aenter__ = AsyncMock(return_value=mock_client)
            mock_client.__aexit__ = AsyncMock(return_value=False)
            mock_httpx.return_value = mock_client

            handler.session_manager.get_or_create_session = AsyncMock(return_value="session-1")

            # Patch the exchanger constructor to verify it's NOT called
            with patch("okta_agent_proxy.auth.okta_sts_exchanger.OktaSTSTokenExchanger") as mock_cls:
                result = await handler.proxy_request(
                    request_path="/github-org",
                    method="tools/call",
                    params={"name": "list_repos"},
                    auth_header="Bearer eyJ.test.token",
                    headers={"X-MCP-Agent": "test-agent"},
                )

                # Exchanger should NOT have been instantiated (cache hit)
                mock_cls.assert_not_called()

        assert "error" not in result or result.get("error") is None


# ============================================================================
# Consent URL deduplication
# ============================================================================


class TestConsentDeduplication:

    @pytest.mark.asyncio
    @patch("okta_agent_proxy.proxy.handler.check_agent_can_access_resource", new_callable=AsyncMock, return_value=True)
    async def test_two_rapid_calls_same_consent_url(self, mock_authz):
        """Two rapid calls to same unconsented ISV both get same consent_url."""
        handler, router, _ = _make_proxy_handler()

        consent_data = {
            "status": "consent_required",
            "interaction_uri": MOCK_INTERACTION_REQUIRED["interaction_uri"],
            "provider": "GitHub Enterprise",
            "error_description": "User interaction required",
            "resource_indicator": RESOURCE_INDICATOR,
        }

        router.resolver.resolve_auth_headers = AsyncMock(return_value=ResourceAuthResult(
            consent_required=consent_data,
            error="consent_required",
            error_message="User consent required",
        ))

        result1 = await handler.proxy_request(
            request_path="/github-org", method="tools/call",
            params={"name": "list_repos"},
            auth_header="Bearer eyJ.test.token",
            headers={"X-MCP-Agent": "test-agent"},
        )
        result2 = await handler.proxy_request(
            request_path="/github-org", method="tools/call",
            params={"name": "create_issue"},
            auth_header="Bearer eyJ.test.token",
            headers={"X-MCP-Agent": "test-agent"},
        )

        assert result1["consent_url"] == result2["consent_url"]
        assert result1["provider"] == result2["provider"]


# ============================================================================
# Token expiry and re-exchange
# ============================================================================


class TestTokenExpiry:

    @pytest.mark.asyncio
    @patch("okta_agent_proxy.proxy.handler.check_agent_can_access_resource", new_callable=AsyncMock, return_value=True)
    async def test_expired_token_triggers_new_exchange(self, mock_authz):
        """When cached token is gone (expired), a new exchange succeeds."""
        handler, router, token_cache = _make_proxy_handler()

        # Cache is empty (simulates expired token)
        assert token_cache.get_sts_token("user@example.com", RESOURCE_INDICATOR) is None

        router.resolver.resolve_auth_headers = AsyncMock(return_value=ResourceAuthResult(
            headers={"Authorization": "Bearer gho_refreshed_token"},
        ))

        with patch("okta_agent_proxy.proxy.handler.httpx.AsyncClient") as mock_httpx:
            mock_response = _mock_httpx_response(200, {
                "jsonrpc": "2.0", "id": "1",
                "result": {"content": [{"type": "text", "text": "OK"}]},
            })
            mock_client = AsyncMock()
            mock_client.post.return_value = mock_response
            mock_client.__aenter__ = AsyncMock(return_value=mock_client)
            mock_client.__aexit__ = AsyncMock(return_value=False)
            mock_httpx.return_value = mock_client

            handler.session_manager.get_or_create_session = AsyncMock(return_value="s1")

            result = await handler.proxy_request(
                request_path="/github-org", method="tools/call",
                params={"name": "list_repos"},
                auth_header="Bearer eyJ.test.token",
                headers={"X-MCP-Agent": "test-agent"},
            )

        router.resolver.resolve_auth_headers.assert_called_once()
        assert "error" not in result or result.get("error") is None


# ============================================================================
# Error propagation
# ============================================================================


class TestErrorPropagation:

    @pytest.mark.asyncio
    @patch("okta_agent_proxy.proxy.handler.check_agent_can_access_resource", new_callable=AsyncMock, return_value=True)
    async def test_unexpected_okta_error_returns_generic_error(self, mock_authz):
        """Non-interaction_required errors produce generic error, not consent."""
        handler, router, _ = _make_proxy_handler()

        router.resolver.resolve_auth_headers = AsyncMock(return_value=ResourceAuthResult(
            error="sts_exchange_failed",
            error_message="STS exchange failed for github-org",
        ))

        result = await handler.proxy_request(
            request_path="/github-org", method="tools/call",
            params={"name": "list_repos"},
            auth_header="Bearer eyJ.test.token",
            headers={"X-MCP-Agent": "test-agent"},
        )

        assert result["error"] == "sts_exchange_failed"
        assert "consent" not in result.get("error", "")

    @pytest.mark.asyncio
    @patch("okta_agent_proxy.proxy.handler.check_agent_can_access_resource", new_callable=AsyncMock, return_value=True)
    async def test_no_resource_indicator_returns_error(self, mock_authz):
        """Missing resource_indicator in metadata returns exchange failure."""
        handler, router, _ = _make_proxy_handler()

        # Override resource_config to have no resource_indicator anywhere
        resource_config = MagicMock()
        resource_config.url = "https://github.example.com/mcp"
        resource_config.auth_method = "okta-sts"
        resource_config.enabled = True
        resource_config.metadata = {}  # No resource_indicator
        resource_config.config = {}
        resource_config.auth_config = MagicMock()
        resource_config.auth_config.model_dump.return_value = {}  # No resource_indicator
        router.get_resource_config.return_value = resource_config

        # Resolver returns missing_resource_indicator error
        router.resolver.resolve_auth_headers = AsyncMock(return_value=ResourceAuthResult(
            error="sts_exchange_failed",
            error_message="No resource_indicator for github-org",
        ))

        result = await handler.proxy_request(
            request_path="/github-org", method="tools/call",
            params={"name": "list_repos"},
            auth_header="Bearer eyJ.test.token",
            headers={"X-MCP-Agent": "test-agent"},
        )

        assert result["error"] == "sts_exchange_failed"


# ============================================================================
# MCP JSON-RPC error format (unified handler)
# ============================================================================


class TestMcpConsentErrorFormat:

    @pytest.mark.asyncio
    @patch("okta_agent_proxy.auth.agent_authz.check_agent_can_access_resource", new_callable=AsyncMock, return_value=True)
    async def test_consent_error_jsonrpc_structure(self, mock_authz):
        """consent_required error has correct JSON-RPC structure."""
        handler, _ = _make_unified_handler()

        consent_result = {
            "status": "consent_required",
            "interaction_uri": MOCK_INTERACTION_REQUIRED["interaction_uri"],
            "provider": "GitHub Enterprise",
            "error_description": "User interaction required",
            "resource_indicator": RESOURCE_INDICATOR,
        }

        handler._authenticate = AsyncMock(return_value=(
            "test-agent",
            {"agent_id": "test-agent", "resource_access": ["github-org"], "client_id": "0oa1"},
            "user@example.com",
            "eyJ.test.token",
        ))

        async def mock_get_auth(resource_name, resource_config, agent_config, user_id, token):
            handler._last_sts_consent = consent_result
            return None

        handler._get_resource_auth_headers = mock_get_auth

        body = {
            "jsonrpc": "2.0",
            "id": "req-42",
            "method": "tools/call",
            "params": {"name": "github-org__list_repos", "arguments": {}},
        }

        response, status, headers = await handler.handle(body, {"Authorization": "Bearer eyJ.test"})

        # Verify full JSON-RPC error structure
        assert response["jsonrpc"] == "2.0"
        assert response["id"] == "req-42"
        assert "error" in response

        error = response["error"]
        assert error["code"] == -32001
        assert "Authorization required" in error["message"]
        assert "GitHub Enterprise" in error["message"]

        data = error["data"]
        assert data["type"] == "consent_required"
        assert data["provider"] == "GitHub Enterprise"
        assert data["consent_url"] == MOCK_INTERACTION_REQUIRED["interaction_uri"]
        assert data["resource_indicator"] == RESOURCE_INDICATOR
        assert "browser" in data["instructions"].lower()
        assert "re-run" in data["retry_hint"].lower()
        assert data["expires_in"] == 600

    @pytest.mark.asyncio
    @patch("okta_agent_proxy.auth.agent_authz.check_agent_can_access_resource", new_callable=AsyncMock, return_value=True)
    async def test_consent_error_has_all_required_fields(self, mock_authz):
        """Verify every required field is present in the error data block."""
        handler, _ = _make_unified_handler()

        consent_result = {
            "status": "consent_required",
            "interaction_uri": "https://okta.example.com/consent/abc",
            "provider": "Jira Cloud",
            "error_description": "Consent needed",
            "resource_indicator": "orn:okta:rsc456",
        }

        handler._authenticate = AsyncMock(return_value=(
            "agent-1",
            {"agent_id": "agent-1", "resource_access": ["jira-cloud"], "client_id": "0oa2"},
            "user2@example.com",
            "eyJ.test",
        ))

        async def mock_get_auth(resource_name, resource_config, agent_config, user_id, token):
            handler._last_sts_consent = consent_result
            return None

        handler._get_resource_auth_headers = mock_get_auth

        # Override resource config for jira namespace
        jira_config = MagicMock()
        jira_config.url = "https://jira.example.com"
        jira_config.auth_method = "okta-sts"
        jira_config.enabled = True
        jira_config.metadata = {"resource_indicator": "orn:okta:rsc456"}
        handler.router.get_resource_config.return_value = jira_config

        body = {
            "jsonrpc": "2.0",
            "id": "req-99",
            "method": "tools/call",
            "params": {"name": "jira-cloud__create_ticket", "arguments": {}},
        }

        response, status, _ = await handler.handle(body, {"Authorization": "Bearer eyJ.test"})

        data = response["error"]["data"]
        required_fields = ["type", "provider", "consent_url", "resource_indicator",
                           "instructions", "retry_hint", "expires_in"]
        for field in required_fields:
            assert field in data, f"Missing required field: {field}"

    @pytest.mark.asyncio
    @patch("okta_agent_proxy.auth.agent_authz.check_agent_can_access_resource", new_callable=AsyncMock, return_value=True)
    async def test_successful_sts_proxies_normally(self, mock_authz):
        """When STS exchange succeeds, tools/call proxies the request normally."""
        handler, _ = _make_unified_handler()

        handler._authenticate = AsyncMock(return_value=(
            "test-agent",
            {"agent_id": "test-agent", "resource_access": ["github-org"], "client_id": "0oa1"},
            "user@example.com",
            "eyJ.test.token",
        ))

        # Mock successful auth headers (STS exchange worked)
        async def mock_get_auth(resource_name, resource_config, agent_config, user_id, token):
            return {"Authorization": "Bearer gho_test_token_xxx"}

        handler._get_resource_auth_headers = mock_get_auth

        # Mock resource session and HTTP call
        handler._get_resource_session = AsyncMock(return_value="session-1")

        with patch("okta_agent_proxy.mcp.unified_handler.httpx.AsyncClient") as mock_httpx:
            mock_response = _mock_httpx_response(200, {
                "jsonrpc": "2.0", "id": "req-1",
                "result": {"content": [{"type": "text", "text": "data"}]},
            })
            mock_client = AsyncMock()
            mock_client.post.return_value = mock_response
            mock_client.__aenter__ = AsyncMock(return_value=mock_client)
            mock_client.__aexit__ = AsyncMock(return_value=False)
            mock_httpx.return_value = mock_client

            body = {
                "jsonrpc": "2.0",
                "id": "req-1",
                "method": "tools/call",
                "params": {"name": "github-org__list_repos", "arguments": {}},
            }

            response, status, _ = await handler.handle(body, {"Authorization": "Bearer eyJ.test"})

        assert status == 200
        assert "result" in response
        assert "error" not in response
