"""
Tests for OktaSTSTokenExchanger — RFC 8693 token exchange for ISV access tokens.

Covers:
- Successful token exchange (HTTP 200)
- interaction_required consent flow (HTTP 400)
- Unexpected error handling (HTTP 500)
- Client assertion JWT structure
- Gateway key fallback for placeholder keys
- httpx auth= parameter is never used
"""

import json
import os
import time
import pytest
from unittest.mock import AsyncMock, MagicMock, patch, ANY

from okta_agent_proxy.auth.okta_sts_exchanger import (
    OktaSTSTokenExchanger,
    GRANT_TYPE_TOKEN_EXCHANGE,
    REQUESTED_TOKEN_TYPE_STS,
    SUBJECT_TOKEN_TYPE_ID_TOKEN,
    CLIENT_ASSERTION_TYPE_JWT_BEARER,
)


# ---------------------------------------------------------------------------
# Test RSA key (2048-bit, for testing only)
# ---------------------------------------------------------------------------
TEST_JWK = json.dumps({
    "kty": "RSA",
    "kid": "test-kid-001",
    "alg": "RS256",
    "use": "sig",
    "n": "vdGMa1NIq7z4D8Os_NNrsFBCa1MWPBgumMntXgLML8-Wx5T4lHf5x_ReAWHOb7O_tQboNDMbmzuakZ6jxth92Y_YdpkiOzl69cPtb29sbiRt-51JUHWvIv-KV6uLKfzZ8Z_cDMf_Bd8e92bgap803YwNBRoxkWMiQBc1gVY1cag4MH0c0CTlQLRqiKgtHGopjZvRi13xNF7Wefoe9xjvpFbSZ3kj85Sd_KUGy3PvL49QdWYnixfvTNV6WNT3EVOL-IdE6Hu7uEiJ_Fs0yHXH6-1e_7qrhCm05Iq8WQ2pARpKQqhpI7q8WIWGJuVedqqaBYzER66NivJv2aE37YVRFQ",
    "e": "AQAB",
    "d": "D5wjdZIISGNGbRl06OfEE-BNzgCrs-5zKop0lEYbn5TtO-WC2cbSCkEM2AVAkkwQaGU0hFJto0LwD6ihpFEabGFZdktals8_zuU5afAaVSZ2yvng1RaQfArSyCnpzF6oV6gDUyPBU6zJIaRasTn9gXiqe3BvghrKbsXZ1xSNWZbM4C0SiNpl3nGWVYxIS0sfvD2ritEYrunuBXPOuhxm4vyVrUms5-myLXqGLgrVSF607pn_pYpfpsmeIBYZDreHRw62Myy-ZBPIbrI6NtAHUe1YaJG-tgid4h8Q5Fy9eEnZ9wSb3xOLer3lOeWdTBg59cuPggdIMym6qJJ8r2i78Q",
    "p": "-GZS0CnNvLHeUFIztnVFb1O9Cgmvd_tcet7J1NpIlrBFrbzGL7lrn_9dEEAh6SIlTHJEptF9dsKAE_pX4aMnfT1kwqSAN8FSQGaGGeg1KWBi8VtG5LF3XD_8oLI3Zvp6HXBZAghnyGFsEtSmvH_xvq_xFPkyQ6zbz7T0DdrqFVk",
    "q": "w6BeLtLNrv1k5bH_DTMnJgh_q9zBeTLOHHX7DrfMqpZHsF6imtoog0oH-S1jlUc-3x0wEs8GW4KmS86Z6MQABoiAJHV62_dtxcxUsZEtcmVqEKRTgtBahewp1dqtOeDZHYJRKl6Wco_vlLk1PgOqJyqw7THOPRGnGsX6jZDdVh0",
    "dp": "aP4vIMeaq5hvBHpKW2PkLnMxoy2G2msHovPKUcrWBcOKIC57gq6YHC--8WB6NOV26IIgHHbN1kXOByO4w6nHxjsN_Ou1OlvfXVM4eXjaB5wzFhtjssSEVBzDtlS98CwNM6ZKKP7OhzcOjEMQGvrlfpk1iIzwPwSwgHHW-og-izk",
    "dq": "tLp5iISUJTBQgKw613UEm-yKFrqxu0imhkCxGl3PpWGFBXnIe4tEllZUm23FbGoPuYx7l0TPuMcw3yQVqKc65s5ApG4sfP9P2Mb3D7zx4Zezr4BA7r-Sgds2oy2Nj8UckFiOp7gPAfPcAOhCOfKkxd546glzYZPnb6Kr4RGOijk",
    "qi": "lnKIAVNxIgrTTWUCDDNFM36vbG8jPB55ksex8xEkCAi2oTGqin_Y1IGNTgFIbwmmZuzJ2-8AviUZylHkQhPIKu4fLP-CfLP_RzUimv2TnIg3_2qY8wRChmDLzefvZNc8qBM0UvnMG3AaK5H6Go1p28v8-emVKNtT1Fw231l67HY",
})


def _make_exchanger(**overrides):
    """Create an OktaSTSTokenExchanger with test defaults."""
    defaults = {
        "agent_id": "test-agent",
        "client_id": "0oa_test_client",
        "agent_private_key": TEST_JWK,
        "okta_domain": "https://dev-test.okta.com",
        "principal_id": "agt_test_principal",
    }
    defaults.update(overrides)
    return OktaSTSTokenExchanger(**defaults)


def _mock_httpx_response(status_code, json_body):
    """Build a mock httpx response."""
    resp = MagicMock()
    resp.status_code = status_code
    resp.json.return_value = json_body
    return resp


# ============================================================================
# Constructor tests
# ============================================================================


class TestConstructor:

    def test_basic_init(self):
        exchanger = _make_exchanger()
        assert exchanger.agent_id == "test-agent"
        assert exchanger.client_id == "0oa_test_client"
        assert exchanger.principal_id == "agt_test_principal"
        assert exchanger.okta_domain == "https://dev-test.okta.com"
        assert exchanger.token_endpoint == "https://dev-test.okta.com/oauth2/v1/token"
        assert exchanger._private_key is not None

    def test_domain_normalization_bare(self):
        exchanger = _make_exchanger(okta_domain="dev-test.okta.com")
        assert exchanger.okta_domain == "https://dev-test.okta.com"

    def test_domain_normalization_http(self):
        exchanger = _make_exchanger(okta_domain="http://dev-test.okta.com")
        assert exchanger.okta_domain == "https://dev-test.okta.com"

    def test_missing_principal_id_raises(self):
        with pytest.raises(ValueError, match="principal_id is required"):
            _make_exchanger(principal_id=None)

    @patch.dict("os.environ", {"OKTA_DOMAIN": ""}, clear=False)
    def test_missing_domain_raises(self):
        with pytest.raises(ValueError, match="OKTA_DOMAIN"):
            OktaSTSTokenExchanger(
                agent_id="a", client_id="c", agent_private_key=TEST_JWK,
                okta_domain="", principal_id="p",
            )

    @patch("okta_agent_proxy.auth.okta_sts_exchanger.AdapterCIMDServer", side_effect=Exception("no adapter"))
    @patch.dict("os.environ", {
        "OKTA_AI_AGENT_PRIVATE_KEY": "",
        "OKTA_AI_AGENT_CLIENT_ID": "",
        "OKTA_AI_AGENT_ID": "",
    }, clear=False)
    def test_placeholder_key_disables_without_gateway(self, _mock_cimd):
        exchanger = _make_exchanger(agent_private_key="PLACEHOLDER")
        assert exchanger._private_key is None


# ============================================================================
# build_client_assertion
# ============================================================================


class TestBuildClientAssertion:

    def test_assertion_is_signed_jwt(self):
        exchanger = _make_exchanger()
        assertion = exchanger.build_client_assertion()
        # JWT has 3 dot-separated parts
        parts = assertion.split(".")
        assert len(parts) == 3

    def test_assertion_claims(self):
        from jose import jwt as jose_jwt

        exchanger = _make_exchanger()
        assertion = exchanger.build_client_assertion()

        # Decode without verification to inspect claims
        claims = jose_jwt.get_unverified_claims(assertion)
        claims = json.loads(claims) if isinstance(claims, str) else claims

        assert claims["iss"] == "agt_test_principal"
        assert claims["sub"] == "agt_test_principal"
        assert claims["aud"] == "https://dev-test.okta.com/oauth2/v1/token"
        assert "exp" in claims
        assert "iat" in claims
        assert "jti" in claims
        # exp should be ~5 minutes from now
        assert claims["exp"] - claims["iat"] == 300

    def test_assertion_header_has_kid(self):
        from jose import jwt as jose_jwt

        exchanger = _make_exchanger()
        assertion = exchanger.build_client_assertion()

        header = jose_jwt.get_unverified_header(assertion)
        assert header["alg"] == "RS256"
        assert header["kid"] == "test-kid-001"

    def test_no_key_raises(self):
        exchanger = _make_exchanger()
        exchanger._private_key = None
        with pytest.raises(ValueError, match="No private key"):
            exchanger.build_client_assertion()


# ============================================================================
# exchange — success
# ============================================================================


class TestExchangeSuccess:

    @pytest.mark.asyncio
    async def test_successful_exchange(self):
        exchanger = _make_exchanger()

        success_body = {
            "access_token": "gho_abc123",
            "token_type": "Bearer",
            "expires_in": 28800,
            "issued_token_type": "urn:okta:params:oauth:token-type:oauth-sts",
        }

        mock_response = _mock_httpx_response(200, success_body)

        with patch("okta_agent_proxy.auth.okta_sts_exchanger.httpx") as mock_httpx:
            mock_client = AsyncMock()
            mock_client.post.return_value = mock_response
            mock_client.__aenter__ = AsyncMock(return_value=mock_client)
            mock_client.__aexit__ = AsyncMock(return_value=False)
            mock_httpx.AsyncClient.return_value = mock_client

            result = await exchanger.exchange(
                user_id_token="eyJ.test.token",
                resource_indicator="orn:okta:idp:00o:client-auth-settings:rsc123",
                resource_name="github-org",
            )

        assert result is not None
        assert result["status"] == "success"
        assert result["access_token"] == "gho_abc123"
        assert result["token_type"] == "Bearer"
        assert result["expires_in"] == 28800
        assert result["provider"] == "github-org"

    @pytest.mark.asyncio
    async def test_provider_defaults_to_resource_indicator(self):
        exchanger = _make_exchanger()

        mock_response = _mock_httpx_response(200, {
            "access_token": "tok", "token_type": "Bearer", "expires_in": 100,
        })

        with patch("okta_agent_proxy.auth.okta_sts_exchanger.httpx") as mock_httpx:
            mock_client = AsyncMock()
            mock_client.post.return_value = mock_response
            mock_client.__aenter__ = AsyncMock(return_value=mock_client)
            mock_client.__aexit__ = AsyncMock(return_value=False)
            mock_httpx.AsyncClient.return_value = mock_client

            result = await exchanger.exchange(
                user_id_token="eyJ.test.token",
                resource_indicator="orn:okta:rsc123",
            )

        assert result["provider"] == "orn:okta:rsc123"


# ============================================================================
# exchange — interaction_required
# ============================================================================


class TestExchangeConsentRequired:

    @pytest.mark.asyncio
    async def test_interaction_required(self):
        exchanger = _make_exchanger()

        consent_body = {
            "error": "interaction_required",
            "error_description": "User must consent to GitHub access",
            "interaction_uri": "https://dev-test.okta.com/consent/abc",
        }

        mock_response = _mock_httpx_response(400, consent_body)

        with patch("okta_agent_proxy.auth.okta_sts_exchanger.httpx") as mock_httpx:
            mock_client = AsyncMock()
            mock_client.post.return_value = mock_response
            mock_client.__aenter__ = AsyncMock(return_value=mock_client)
            mock_client.__aexit__ = AsyncMock(return_value=False)
            mock_httpx.AsyncClient.return_value = mock_client

            result = await exchanger.exchange(
                user_id_token="eyJ.test.token",
                resource_indicator="orn:okta:rsc123",
                resource_name="github-org",
            )

        assert result is not None
        assert result["status"] == "consent_required"
        assert result["interaction_uri"] == "https://dev-test.okta.com/consent/abc"
        assert result["provider"] == "github-org"
        assert result["error_description"] == "User must consent to GitHub access"


# ============================================================================
# exchange — error cases
# ============================================================================


class TestExchangeErrors:

    @pytest.mark.asyncio
    async def test_unexpected_error_returns_none(self):
        exchanger = _make_exchanger()

        error_body = {"error": "server_error", "error_description": "Internal"}
        mock_response = _mock_httpx_response(500, error_body)

        with patch("okta_agent_proxy.auth.okta_sts_exchanger.httpx") as mock_httpx:
            mock_client = AsyncMock()
            mock_client.post.return_value = mock_response
            mock_client.__aenter__ = AsyncMock(return_value=mock_client)
            mock_client.__aexit__ = AsyncMock(return_value=False)
            mock_httpx.AsyncClient.return_value = mock_client

            result = await exchanger.exchange(
                user_id_token="eyJ.test.token",
                resource_indicator="orn:okta:rsc123",
            )

        assert result is None

    @pytest.mark.asyncio
    async def test_http_400_non_interaction_returns_none(self):
        exchanger = _make_exchanger()

        error_body = {"error": "invalid_grant", "error_description": "Bad token"}
        mock_response = _mock_httpx_response(400, error_body)

        with patch("okta_agent_proxy.auth.okta_sts_exchanger.httpx") as mock_httpx:
            mock_client = AsyncMock()
            mock_client.post.return_value = mock_response
            mock_client.__aenter__ = AsyncMock(return_value=mock_client)
            mock_client.__aexit__ = AsyncMock(return_value=False)
            mock_httpx.AsyncClient.return_value = mock_client

            result = await exchanger.exchange(
                user_id_token="eyJ.test.token",
                resource_indicator="orn:okta:rsc123",
            )

        assert result is None

    @pytest.mark.asyncio
    async def test_no_private_key_returns_none(self):
        exchanger = _make_exchanger()
        exchanger._private_key = None

        result = await exchanger.exchange(
            user_id_token="eyJ.test.token",
            resource_indicator="orn:okta:rsc123",
        )

        assert result is None

    @pytest.mark.asyncio
    async def test_network_exception_returns_none(self):
        exchanger = _make_exchanger()

        with patch("okta_agent_proxy.auth.okta_sts_exchanger.httpx") as mock_httpx:
            mock_client = AsyncMock()
            mock_client.post.side_effect = Exception("Connection refused")
            mock_client.__aenter__ = AsyncMock(return_value=mock_client)
            mock_client.__aexit__ = AsyncMock(return_value=False)
            mock_httpx.AsyncClient.return_value = mock_client

            result = await exchanger.exchange(
                user_id_token="eyJ.test.token",
                resource_indicator="orn:okta:rsc123",
            )

        assert result is None


# ============================================================================
# httpx auth= parameter is never used
# ============================================================================


class TestHttpxNoAuth:

    @pytest.mark.asyncio
    async def test_no_auth_param_on_httpx_post(self):
        """Verify httpx.post() is never called with auth= kwarg."""
        exchanger = _make_exchanger()

        mock_response = _mock_httpx_response(200, {
            "access_token": "tok", "token_type": "Bearer", "expires_in": 100,
        })

        with patch("okta_agent_proxy.auth.okta_sts_exchanger.httpx") as mock_httpx:
            mock_client = AsyncMock()
            mock_client.post.return_value = mock_response
            mock_client.__aenter__ = AsyncMock(return_value=mock_client)
            mock_client.__aexit__ = AsyncMock(return_value=False)
            mock_httpx.AsyncClient.return_value = mock_client

            await exchanger.exchange(
                user_id_token="eyJ.test.token",
                resource_indicator="orn:okta:rsc123",
            )

            # Verify post() was called without auth= parameter
            call_kwargs = mock_client.post.call_args
            assert "auth" not in call_kwargs.kwargs

    @pytest.mark.asyncio
    async def test_httpx_client_created_without_auth(self):
        """Verify AsyncClient() is never created with auth= kwarg."""
        exchanger = _make_exchanger()

        mock_response = _mock_httpx_response(200, {
            "access_token": "tok", "token_type": "Bearer", "expires_in": 100,
        })

        with patch("okta_agent_proxy.auth.okta_sts_exchanger.httpx") as mock_httpx:
            mock_client = AsyncMock()
            mock_client.post.return_value = mock_response
            mock_client.__aenter__ = AsyncMock(return_value=mock_client)
            mock_client.__aexit__ = AsyncMock(return_value=False)
            mock_httpx.AsyncClient.return_value = mock_client

            await exchanger.exchange(
                user_id_token="eyJ.test.token",
                resource_indicator="orn:okta:rsc123",
            )

            # Verify AsyncClient() was called without auth= parameter
            client_kwargs = mock_httpx.AsyncClient.call_args
            assert "auth" not in (client_kwargs.kwargs if client_kwargs.kwargs else {})


# ============================================================================
# exchange — form data correctness
# ============================================================================


class TestExchangeFormData:

    @pytest.mark.asyncio
    async def test_correct_form_data(self):
        exchanger = _make_exchanger()

        mock_response = _mock_httpx_response(200, {
            "access_token": "tok", "token_type": "Bearer", "expires_in": 100,
        })

        with patch("okta_agent_proxy.auth.okta_sts_exchanger.httpx") as mock_httpx:
            mock_client = AsyncMock()
            mock_client.post.return_value = mock_response
            mock_client.__aenter__ = AsyncMock(return_value=mock_client)
            mock_client.__aexit__ = AsyncMock(return_value=False)
            mock_httpx.AsyncClient.return_value = mock_client

            await exchanger.exchange(
                user_id_token="eyJ.id.token",
                resource_indicator="orn:okta:rsc123",
            )

            call_args = mock_client.post.call_args
            # Verify URL
            assert call_args.args[0] == "https://dev-test.okta.com/oauth2/v1/token"
            # Verify form data
            form = call_args.kwargs["data"]
            assert form["grant_type"] == GRANT_TYPE_TOKEN_EXCHANGE
            assert form["requested_token_type"] == REQUESTED_TOKEN_TYPE_STS
            assert form["subject_token"] == "eyJ.id.token"
            assert form["subject_token_type"] == SUBJECT_TOKEN_TYPE_ID_TOKEN
            assert form["client_assertion_type"] == CLIENT_ASSERTION_TYPE_JWT_BEARER
            assert form["resource"] == "orn:okta:rsc123"
            # client_assertion should be a JWT
            assert form["client_assertion"].count(".") == 2


# ============================================================================
# Gateway key fallback
# ============================================================================


class TestGatewayKeyFallback:

    @patch.dict("os.environ", {
        "OKTA_AI_AGENT_PRIVATE_KEY": TEST_JWK,
        "OKTA_AI_AGENT_CLIENT_ID": "gw-client-id",
        "OKTA_AI_AGENT_ID": "gw-agent-id",
    })
    def test_placeholder_uses_gateway_credentials(self):
        exchanger = _make_exchanger(agent_private_key="PLACEHOLDER")
        assert exchanger._using_gateway_key is True
        assert exchanger.client_id == "gw-client-id"
        assert exchanger.agent_id == "gw-agent-id"
        assert exchanger.principal_id == "gw-agent-id"
        assert exchanger._private_key is not None

    @patch.dict("os.environ", {
        "OKTA_AI_AGENT_PRIVATE_KEY": TEST_JWK,
        "OKTA_AI_AGENT_CLIENT_ID": "gw-client-id",
        "OKTA_AI_AGENT_ID": "gw-agent-id",
    })
    def test_none_key_uses_gateway_credentials(self):
        exchanger = _make_exchanger(agent_private_key=None)
        assert exchanger._using_gateway_key is True
        assert exchanger._private_key is not None


# ============================================================================
# Placeholder key detection
# ============================================================================


class TestIsPlaceholderKey:

    def test_none_is_placeholder(self):
        assert OktaSTSTokenExchanger._is_placeholder_key(None) is True

    def test_empty_string_is_placeholder(self):
        assert OktaSTSTokenExchanger._is_placeholder_key("") is True

    def test_placeholder_string(self):
        assert OktaSTSTokenExchanger._is_placeholder_key("PLACEHOLDER") is True

    def test_placeholder_in_jwk(self):
        assert OktaSTSTokenExchanger._is_placeholder_key({"n": "PLACEHOLDER"}) is True

    def test_real_key_not_placeholder(self):
        assert OktaSTSTokenExchanger._is_placeholder_key(TEST_JWK) is False

    def test_dict_key_not_placeholder(self):
        assert OktaSTSTokenExchanger._is_placeholder_key({"n": "abc", "kty": "RSA"}) is False
