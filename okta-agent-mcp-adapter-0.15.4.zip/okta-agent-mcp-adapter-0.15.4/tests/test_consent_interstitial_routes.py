"""
Tests for consent completion, recheck, and skip routes.

Tests:
- consent-complete: redirects to agent with gateway code, clears cookie
- consent-complete: invalid session → 400
- consent-complete: gateway code one-time use
- consent-recheck: triggers reverification
- consent-recheck: invalid session → 403
- consent-skip: marks consent_required as skipped, status=complete
"""

import hashlib
import pytest
from unittest.mock import AsyncMock, MagicMock, patch
from urllib.parse import urlparse, parse_qs

from starlette.applications import Starlette
from starlette.routing import Route
from starlette.requests import Request
from starlette.responses import JSONResponse
from starlette.testclient import TestClient

from okta_agent_proxy.auth.consent_transaction import (
    ConsentConnectionStatus,
    ConsentTransaction,
    ConsentTransactionStore,
)
from okta_agent_proxy.auth.gateway_code_manager import GatewayCodeManager


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _ua_hash(ua: str = "testclient") -> str:
    return hashlib.sha256(ua.encode()).hexdigest()[:16]


def _build_app(store, code_manager, consent_service_mock=None, audit_mock=None):
    """Build a minimal Starlette app with the consent routes."""
    from starlette.responses import RedirectResponse, HTMLResponse
    from urllib.parse import urlencode

    _consent_service = consent_service_mock or AsyncMock()
    _audit = audit_mock or AsyncMock()

    async def consent_complete(request: Request):
        form = await request.form()
        tx_id = form.get("tx", "")
        session_id = request.cookies.get("__okta_consent_session", "")

        if not tx_id or not session_id:
            return JSONResponse({"error": "invalid_request"}, status_code=400)

        ua_hash = hashlib.sha256(
            request.headers.get("user-agent", "").encode()
        ).hexdigest()[:16]

        tx = store.validate_session(
            session_id=session_id,
            ip_address=request.client.host if request.client else "",
            user_agent_hash=ua_hash,
        )

        if not tx or tx.transaction_id != tx_id:
            return HTMLResponse(
                "<h1>Session Expired</h1>",
                status_code=400,
            )

        gateway_code = code_manager.issue_code(
            client_id=tx.original_client_id,
            tokens={
                "access_token": tx.access_token,
                "id_token": tx.id_token,
                "refresh_token": tx.refresh_token,
                "expires_in": tx.okta_expires_in,
            },
        )

        redirect_params = {"code": gateway_code, "state": tx.original_state}
        redirect_url = f"{tx.original_redirect_uri}?{urlencode(redirect_params)}"

        await _audit(details={"transaction_id": tx.transaction_id})

        store.remove(tx.transaction_id)

        response = RedirectResponse(url=redirect_url, status_code=302)
        response.delete_cookie("__okta_consent_session", path="/oauth")
        return response

    async def consent_recheck(request: Request):
        form = await request.form()
        tx_id = form.get("tx", "")
        session_id = request.cookies.get("__okta_consent_session", "")

        if not tx_id or not session_id:
            return JSONResponse({"error": "invalid_request"}, status_code=400)

        ua_hash = hashlib.sha256(
            request.headers.get("user-agent", "").encode()
        ).hexdigest()[:16]

        tx = store.validate_session(
            session_id=session_id,
            ip_address=request.client.host if request.client else "",
            user_agent_hash=ua_hash,
        )

        if not tx or tx.transaction_id != tx_id:
            return JSONResponse({"error": "session_invalid"}, status_code=403)

        await _consent_service.recheck_pending(tx)
        return JSONResponse({"status": tx.status})

    async def consent_skip(request: Request):
        form = await request.form()
        tx_id = form.get("tx", "")
        session_id = request.cookies.get("__okta_consent_session", "")

        if not tx_id or not session_id:
            return JSONResponse({"error": "invalid_request"}, status_code=400)

        ua_hash = hashlib.sha256(
            request.headers.get("user-agent", "").encode()
        ).hexdigest()[:16]

        tx = store.validate_session(
            session_id=session_id,
            ip_address=request.client.host if request.client else "",
            user_agent_hash=ua_hash,
        )

        if not tx or tx.transaction_id != tx_id:
            return JSONResponse({"error": "session_invalid"}, status_code=403)

        for conn in tx.connections:
            if conn.status == "consent_required":
                conn.status = "skipped"
        tx.skip_requested = True
        tx.status = "complete"

        await _audit(details={"transaction_id": tx.transaction_id})
        return JSONResponse({"status": "complete"})

    return Starlette(routes=[
        Route("/oauth/consent-complete", consent_complete, methods=["POST"]),
        Route("/oauth/consent-recheck", consent_recheck, methods=["POST"]),
        Route("/oauth/consent-skip", consent_skip, methods=["POST"]),
    ])


ORIGINAL_REDIRECT = "http://localhost:9999/callback"
ORIGINAL_STATE = "client_state_abc"
CLIENT_ID = "https://app.example.com/oauth.json"


def _create_tx(store, connections=None):
    tx = store.create(
        original_redirect_uri=ORIGINAL_REDIRECT,
        original_state=ORIGINAL_STATE,
        original_client_id=CLIENT_ID,
        id_token="idt_123",
        access_token="at_123",
        refresh_token="rt_123",
        okta_expires_in=3600,
        agent_id="agent-1",
        agent_config={"client_id": "0oa_xyz"},
        ip_address="testclient",
        user_agent_hash=_ua_hash("testclient"),
    )
    if connections:
        tx.connections = connections
    return tx


# ---------------------------------------------------------------------------
# Tests — consent-complete
# ---------------------------------------------------------------------------


class TestConsentComplete:
    def test_consent_complete_redirects_to_agent(self):
        store = ConsentTransactionStore()
        code_mgr = GatewayCodeManager()
        tx = _create_tx(store)

        app = _build_app(store, code_mgr)
        client = TestClient(app, raise_server_exceptions=False)
        client.cookies.set("__okta_consent_session", tx.session_id)

        resp = client.post(
            "/oauth/consent-complete",
            data={"tx": tx.transaction_id},
            follow_redirects=False,
        )

        assert resp.status_code == 302
        location = resp.headers["location"]
        assert location.startswith(ORIGINAL_REDIRECT)
        params = parse_qs(urlparse(location).query)
        assert params["state"] == [ORIGINAL_STATE]
        assert len(params["code"][0]) == 64  # hex(32)

    def test_consent_complete_clears_cookie(self):
        store = ConsentTransactionStore()
        code_mgr = GatewayCodeManager()
        tx = _create_tx(store)

        app = _build_app(store, code_mgr)
        client = TestClient(app, raise_server_exceptions=False)
        client.cookies.set("__okta_consent_session", tx.session_id)

        resp = client.post(
            "/oauth/consent-complete",
            data={"tx": tx.transaction_id},
            follow_redirects=False,
        )

        cookie_header = resp.headers.get("set-cookie", "")
        assert "__okta_consent_session" in cookie_header
        # Cookie should be deleted (max-age=0 or expires in past)
        assert 'max-age=0' in cookie_header.lower() or '01 jan 1970' in cookie_header.lower()

    def test_consent_complete_invalid_session(self):
        store = ConsentTransactionStore()
        code_mgr = GatewayCodeManager()
        tx = _create_tx(store)

        app = _build_app(store, code_mgr)
        client = TestClient(app, raise_server_exceptions=False)
        client.cookies.set("__okta_consent_session", "wrong_session")

        resp = client.post(
            "/oauth/consent-complete",
            data={"tx": tx.transaction_id},
            follow_redirects=False,
        )
        assert resp.status_code == 400
        assert "Session Expired" in resp.text

    def test_consent_complete_gateway_code_is_one_time(self):
        store = ConsentTransactionStore()
        code_mgr = GatewayCodeManager()
        tx = _create_tx(store)

        app = _build_app(store, code_mgr)
        client = TestClient(app, raise_server_exceptions=False)
        client.cookies.set("__okta_consent_session", tx.session_id)

        resp = client.post(
            "/oauth/consent-complete",
            data={"tx": tx.transaction_id},
            follow_redirects=False,
        )
        gateway_code = parse_qs(urlparse(resp.headers["location"]).query)["code"][0]

        # Exchange succeeds first time
        result = code_mgr.exchange_code(gateway_code, CLIENT_ID)
        assert result["access_token"] == "at_123"

        # Second exchange fails
        from okta_agent_proxy.auth.gateway_code_manager import GatewayCodeNotFound
        with pytest.raises(GatewayCodeNotFound):
            code_mgr.exchange_code(gateway_code, CLIENT_ID)


# ---------------------------------------------------------------------------
# Tests — consent-recheck
# ---------------------------------------------------------------------------


class TestConsentRecheck:
    def test_consent_recheck_triggers_reverification(self):
        store = ConsentTransactionStore()
        consent_svc = AsyncMock()
        tx = _create_tx(store)

        app = _build_app(store, GatewayCodeManager(), consent_service_mock=consent_svc)
        client = TestClient(app, raise_server_exceptions=False)
        client.cookies.set("__okta_consent_session", tx.session_id)

        resp = client.post(
            "/oauth/consent-recheck",
            data={"tx": tx.transaction_id},
        )

        assert resp.status_code == 200
        consent_svc.recheck_pending.assert_called_once_with(tx)

    def test_consent_recheck_invalid_session(self):
        store = ConsentTransactionStore()
        tx = _create_tx(store)

        app = _build_app(store, GatewayCodeManager())
        client = TestClient(app, raise_server_exceptions=False)
        client.cookies.set("__okta_consent_session", "bad_session")

        resp = client.post(
            "/oauth/consent-recheck",
            data={"tx": tx.transaction_id},
        )
        assert resp.status_code == 403


# ---------------------------------------------------------------------------
# Tests — consent-skip
# ---------------------------------------------------------------------------


class TestConsentSkip:
    def test_consent_skip_marks_connections_skipped(self):
        store = ConsentTransactionStore()
        connections = [
            ConsentConnectionStatus(
                connection_id="c1", resource_name="github",
                provider="GitHub", resource_indicator="orn:1",
                status="verified",
            ),
            ConsentConnectionStatus(
                connection_id="c2", resource_name="jira",
                provider="Jira", resource_indicator="orn:2",
                status="consent_required",
                interaction_uri="https://okta/consent",
            ),
        ]
        tx = _create_tx(store, connections=connections)

        app = _build_app(store, GatewayCodeManager())
        client = TestClient(app, raise_server_exceptions=False)
        client.cookies.set("__okta_consent_session", tx.session_id)

        resp = client.post(
            "/oauth/consent-skip",
            data={"tx": tx.transaction_id},
        )

        assert resp.status_code == 200
        # Verified stays verified, consent_required becomes skipped
        assert tx.connections[0].status == "verified"
        assert tx.connections[1].status == "skipped"

    def test_consent_skip_sets_status_complete(self):
        store = ConsentTransactionStore()
        connections = [
            ConsentConnectionStatus(
                connection_id="c1", resource_name="github",
                provider="GitHub", resource_indicator="orn:1",
                status="consent_required",
            ),
        ]
        tx = _create_tx(store, connections=connections)
        tx.status = "consents_required"

        app = _build_app(store, GatewayCodeManager())
        client = TestClient(app, raise_server_exceptions=False)
        client.cookies.set("__okta_consent_session", tx.session_id)

        resp = client.post(
            "/oauth/consent-skip",
            data={"tx": tx.transaction_id},
        )

        assert resp.status_code == 200
        data = resp.json()
        assert data["status"] == "complete"
        assert tx.status == "complete"
        assert tx.skip_requested is True
