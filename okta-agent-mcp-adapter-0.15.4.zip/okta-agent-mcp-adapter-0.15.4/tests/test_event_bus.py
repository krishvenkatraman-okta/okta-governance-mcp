"""
Tests for CacheEventBus (resource_map cross-pod invalidation).

Covers:
- Redis available: publish/subscribe across channels
- Redis unavailable: graceful fallback to polling
- Multiple subscribers on same channel
- Publish with no subscribers (no error)
- Start/stop lifecycle
- Redis connection failure mid-operation (graceful)
- Poll fallback invokes subscribers at interval
- Local-only mode (no redis_url): direct callback invocation
- Channel constants
"""

import asyncio
import pytest
from unittest.mock import AsyncMock, MagicMock, patch

from okta_agent_proxy.resources.event_bus import (
    CacheEventBus,
    CHANNEL_RESOURCE_CHANGED,
    CHANNEL_OKTA_SYNC,
    ALL_CHANNELS,
)


# ============================================================================
# Fixtures
# ============================================================================


@pytest.fixture
def mock_redis():
    """Mock redis.asyncio.Redis with pub/sub support."""
    r = AsyncMock()
    r.ping = AsyncMock(return_value=True)
    r.publish = AsyncMock(return_value=1)
    r.close = AsyncMock()

    pubsub = AsyncMock()
    pubsub.subscribe = AsyncMock()
    pubsub.unsubscribe = AsyncMock()
    pubsub.close = AsyncMock()

    # listen() returns an async iterator that yields nothing by default
    async def empty_listen():
        # Block forever until cancelled (mimics real Redis listener)
        try:
            while True:
                await asyncio.sleep(3600)
        except asyncio.CancelledError:
            return
        yield  # make it an async generator  # pragma: no cover

    pubsub.listen = empty_listen
    r.pubsub = MagicMock(return_value=pubsub)

    return r, pubsub


@pytest.fixture
def bus_no_redis():
    """CacheEventBus with no Redis URL (local-only mode)."""
    return CacheEventBus(redis_url=None)


@pytest.fixture
def bus_with_redis_url():
    """CacheEventBus configured with a Redis URL (not yet started)."""
    return CacheEventBus(redis_url="redis://localhost:6379/0")


# ============================================================================
# Channel constants
# ============================================================================


class TestChannelConstants:
    def test_all_channels(self):
        assert CHANNEL_RESOURCE_CHANGED in ALL_CHANNELS
        assert CHANNEL_OKTA_SYNC in ALL_CHANNELS
        assert len(ALL_CHANNELS) == 2

    def test_channel_values(self):
        assert CHANNEL_RESOURCE_CHANGED == "resource:changed"
        assert CHANNEL_OKTA_SYNC == "okta:sync"


# ============================================================================
# Local-only mode (no redis_url)
# ============================================================================


class TestLocalOnlyMode:
    """When redis_url is None, everything works locally without Redis."""

    @pytest.mark.asyncio
    async def test_start_sets_started(self, bus_no_redis):
        await bus_no_redis.start()
        assert bus_no_redis.started is True
        assert bus_no_redis.use_redis is False
        await bus_no_redis.stop()

    @pytest.mark.asyncio
    async def test_publish_invokes_local_subscribers(self, bus_no_redis):
        cb = AsyncMock()
        bus_no_redis.subscribe(CHANNEL_RESOURCE_CHANGED, cb)
        await bus_no_redis.start()

        await bus_no_redis.publish(CHANNEL_RESOURCE_CHANGED, "test-msg")
        cb.assert_called_once_with("test-msg")
        await bus_no_redis.stop()

    @pytest.mark.asyncio
    async def test_publish_no_subscribers_no_error(self, bus_no_redis):
        await bus_no_redis.start()
        # Should not raise
        await bus_no_redis.publish(CHANNEL_RESOURCE_CHANGED, "no-one-listening")
        await bus_no_redis.stop()

    @pytest.mark.asyncio
    async def test_publish_generates_timestamp_if_empty(self, bus_no_redis):
        cb = AsyncMock()
        bus_no_redis.subscribe(CHANNEL_RESOURCE_CHANGED, cb)
        await bus_no_redis.start()

        await bus_no_redis.publish(CHANNEL_RESOURCE_CHANGED)
        assert cb.call_count == 1
        # Message should be an ISO timestamp
        msg = cb.call_args[0][0]
        assert "T" in msg  # ISO format contains 'T'
        await bus_no_redis.stop()

    @pytest.mark.asyncio
    async def test_multiple_subscribers_same_channel(self, bus_no_redis):
        cb1 = AsyncMock()
        cb2 = AsyncMock()
        bus_no_redis.subscribe(CHANNEL_RESOURCE_CHANGED, cb1)
        bus_no_redis.subscribe(CHANNEL_RESOURCE_CHANGED, cb2)
        await bus_no_redis.start()

        await bus_no_redis.publish(CHANNEL_RESOURCE_CHANGED, "hello")
        cb1.assert_called_once_with("hello")
        cb2.assert_called_once_with("hello")
        await bus_no_redis.stop()

    @pytest.mark.asyncio
    async def test_subscribe_different_channels(self, bus_no_redis):
        cb_resource = AsyncMock()
        cb_okta = AsyncMock()
        bus_no_redis.subscribe(CHANNEL_RESOURCE_CHANGED, cb_resource)
        bus_no_redis.subscribe(CHANNEL_OKTA_SYNC, cb_okta)
        await bus_no_redis.start()

        await bus_no_redis.publish(CHANNEL_RESOURCE_CHANGED, "res")
        cb_resource.assert_called_once_with("res")
        cb_okta.assert_not_called()

        await bus_no_redis.publish(CHANNEL_OKTA_SYNC, "sync")
        cb_okta.assert_called_once_with("sync")
        await bus_no_redis.stop()

    @pytest.mark.asyncio
    async def test_callback_error_doesnt_break_others(self, bus_no_redis):
        bad_cb = AsyncMock(side_effect=ValueError("boom"))
        good_cb = AsyncMock()
        bus_no_redis.subscribe(CHANNEL_RESOURCE_CHANGED, bad_cb)
        bus_no_redis.subscribe(CHANNEL_RESOURCE_CHANGED, good_cb)
        await bus_no_redis.start()

        await bus_no_redis.publish(CHANNEL_RESOURCE_CHANGED, "test")
        bad_cb.assert_called_once()
        good_cb.assert_called_once_with("test")
        await bus_no_redis.stop()

    @pytest.mark.asyncio
    async def test_sync_callback_supported(self, bus_no_redis):
        """Non-async callbacks should also work."""
        results = []

        def sync_cb(msg):
            results.append(msg)

        bus_no_redis.subscribe(CHANNEL_RESOURCE_CHANGED, sync_cb)
        await bus_no_redis.start()
        await bus_no_redis.publish(CHANNEL_RESOURCE_CHANGED, "sync-msg")
        assert results == ["sync-msg"]
        await bus_no_redis.stop()


# ============================================================================
# Start / stop lifecycle
# ============================================================================


class TestLifecycle:
    @pytest.mark.asyncio
    async def test_stop_before_start(self, bus_no_redis):
        """Stop without start should not raise."""
        await bus_no_redis.stop()
        assert bus_no_redis.started is False

    @pytest.mark.asyncio
    async def test_double_stop(self, bus_no_redis):
        await bus_no_redis.start()
        await bus_no_redis.stop()
        await bus_no_redis.stop()  # Should not raise
        assert bus_no_redis.started is False

    @pytest.mark.asyncio
    async def test_stop_cancels_poll_tasks(self, bus_no_redis):
        await bus_no_redis.start()
        assert len(bus_no_redis._poll_tasks) == 2  # resource + okta
        await bus_no_redis.stop()
        assert len(bus_no_redis._poll_tasks) == 0

    @pytest.mark.asyncio
    async def test_initial_state(self):
        bus = CacheEventBus()
        assert bus.started is False
        assert bus.use_redis is False
        assert bus._listener_task is None
        assert bus._poll_tasks == []


# ============================================================================
# Redis available (mocked)
# ============================================================================


class TestRedisMode:
    @pytest.mark.asyncio
    async def test_start_connects_to_redis(self, bus_with_redis_url, mock_redis):
        mock_r, mock_ps = mock_redis
        with patch("redis.asyncio.from_url", return_value=mock_r):
            await bus_with_redis_url.start()

        assert bus_with_redis_url.use_redis is True
        assert bus_with_redis_url.started is True
        mock_r.ping.assert_called_once()
        mock_ps.subscribe.assert_called_once_with(
            CHANNEL_RESOURCE_CHANGED, CHANNEL_OKTA_SYNC
        )
        await bus_with_redis_url.stop()

    @pytest.mark.asyncio
    async def test_publish_via_redis(self, bus_with_redis_url, mock_redis):
        mock_r, mock_ps = mock_redis
        with patch("redis.asyncio.from_url", return_value=mock_r):
            await bus_with_redis_url.start()

        await bus_with_redis_url.publish(CHANNEL_RESOURCE_CHANGED, "update")
        mock_r.publish.assert_called_once_with(CHANNEL_RESOURCE_CHANGED, "update")
        await bus_with_redis_url.stop()

    @pytest.mark.asyncio
    async def test_stop_cleans_up_redis(self, bus_with_redis_url, mock_redis):
        mock_r, mock_ps = mock_redis
        with patch("redis.asyncio.from_url", return_value=mock_r):
            await bus_with_redis_url.start()

        await bus_with_redis_url.stop()
        mock_ps.unsubscribe.assert_called_once()
        mock_ps.close.assert_called_once()
        mock_r.close.assert_called_once()
        assert bus_with_redis_url.use_redis is False

    @pytest.mark.asyncio
    async def test_no_poll_tasks_with_redis(self, bus_with_redis_url, mock_redis):
        mock_r, mock_ps = mock_redis
        with patch("redis.asyncio.from_url", return_value=mock_r):
            await bus_with_redis_url.start()

        assert len(bus_with_redis_url._poll_tasks) == 0
        await bus_with_redis_url.stop()

    @pytest.mark.asyncio
    async def test_listener_task_created(self, bus_with_redis_url, mock_redis):
        mock_r, mock_ps = mock_redis
        with patch("redis.asyncio.from_url", return_value=mock_r):
            await bus_with_redis_url.start()

        assert bus_with_redis_url._listener_task is not None
        await bus_with_redis_url.stop()


# ============================================================================
# Redis connection failure
# ============================================================================


class TestRedisFailure:
    @pytest.mark.asyncio
    async def test_redis_ping_fails_falls_back_to_polling(self, bus_with_redis_url):
        mock_r = AsyncMock()
        mock_r.ping = AsyncMock(side_effect=ConnectionError("refused"))

        with patch("redis.asyncio.from_url", return_value=mock_r):
            await bus_with_redis_url.start()

        assert bus_with_redis_url.use_redis is False
        assert bus_with_redis_url.started is True
        assert len(bus_with_redis_url._poll_tasks) == 2
        await bus_with_redis_url.stop()

    @pytest.mark.asyncio
    async def test_redis_publish_fails_invokes_local(self, bus_with_redis_url, mock_redis):
        mock_r, mock_ps = mock_redis
        mock_r.publish = AsyncMock(side_effect=ConnectionError("broken pipe"))

        with patch("redis.asyncio.from_url", return_value=mock_r):
            await bus_with_redis_url.start()

        cb = AsyncMock()
        bus_with_redis_url.subscribe(CHANNEL_RESOURCE_CHANGED, cb)

        await bus_with_redis_url.publish(CHANNEL_RESOURCE_CHANGED, "fallback-msg")
        cb.assert_called_once_with("fallback-msg")
        await bus_with_redis_url.stop()

    @pytest.mark.asyncio
    async def test_redis_from_url_raises_falls_back(self):
        """If redis.asyncio.from_url raises, fall back to polling."""
        bus = CacheEventBus(redis_url="redis://localhost:6379/0")

        with patch(
            "redis.asyncio.from_url",
            side_effect=Exception("connection factory broken"),
        ):
            await bus.start()

        assert bus.use_redis is False
        assert bus.started is True
        assert len(bus._poll_tasks) == 2
        await bus.stop()


# ============================================================================
# Poll fallback
# ============================================================================


class TestPollFallback:
    @pytest.mark.asyncio
    async def test_poll_creates_tasks_for_both_channels(self, bus_no_redis):
        await bus_no_redis.start()
        assert len(bus_no_redis._poll_tasks) == 2
        await bus_no_redis.stop()

    @pytest.mark.asyncio
    async def test_poll_invokes_subscribers(self, bus_no_redis):
        cb = AsyncMock()
        bus_no_redis.subscribe(CHANNEL_RESOURCE_CHANGED, cb)

        # Use very short poll interval
        bus_no_redis._poll_interval_resource = 0.01
        bus_no_redis._poll_interval_okta = 9999  # don't fire

        await bus_no_redis.start()
        # Wait for at least one poll cycle
        await asyncio.sleep(0.05)
        await bus_no_redis.stop()

        assert cb.call_count >= 1
        cb.assert_called_with("poll")

    @pytest.mark.asyncio
    async def test_poll_custom_intervals(self):
        bus = CacheEventBus(
            poll_interval_resource=15,
            poll_interval_okta=600,
        )
        assert bus._poll_interval_resource == 15
        assert bus._poll_interval_okta == 600


# ============================================================================
# Redis listener dispatching (simulate message)
# ============================================================================


class TestRedisListenerDispatch:
    @pytest.mark.asyncio
    async def test_listener_dispatches_to_subscribers(self, bus_with_redis_url):
        """Simulate Redis listener receiving a message and dispatching."""
        cb = AsyncMock()
        bus_with_redis_url.subscribe(CHANNEL_RESOURCE_CHANGED, cb)

        # Directly test _invoke_local (the core dispatch)
        await bus_with_redis_url._invoke_local(CHANNEL_RESOURCE_CHANGED, "event-data")
        cb.assert_called_once_with("event-data")

    @pytest.mark.asyncio
    async def test_listener_ignores_unknown_channels(self, bus_with_redis_url):
        cb = AsyncMock()
        bus_with_redis_url.subscribe(CHANNEL_RESOURCE_CHANGED, cb)

        await bus_with_redis_url._invoke_local("unknown:channel", "data")
        cb.assert_not_called()

    @pytest.mark.asyncio
    async def test_redis_listener_processes_messages(self, bus_with_redis_url):
        """Full integration: mock Redis listener yielding a message."""
        cb = AsyncMock()
        bus_with_redis_url.subscribe(CHANNEL_RESOURCE_CHANGED, cb)

        mock_r = AsyncMock()
        mock_r.ping = AsyncMock(return_value=True)
        mock_r.close = AsyncMock()

        messages = [
            {"type": "subscribe", "channel": CHANNEL_RESOURCE_CHANGED, "data": 1},
            {"type": "message", "channel": CHANNEL_RESOURCE_CHANGED, "data": "reload"},
        ]

        mock_ps = AsyncMock()
        mock_ps.subscribe = AsyncMock()
        mock_ps.unsubscribe = AsyncMock()
        mock_ps.close = AsyncMock()

        async def mock_listen():
            for msg in messages:
                yield msg

        mock_ps.listen = mock_listen
        mock_r.pubsub = MagicMock(return_value=mock_ps)
        mock_r.publish = AsyncMock()

        with patch("redis.asyncio.from_url", return_value=mock_r):
            await bus_with_redis_url.start()

        # Give the listener task time to process
        await asyncio.sleep(0.05)

        cb.assert_called_once_with("reload")
        await bus_with_redis_url.stop()
