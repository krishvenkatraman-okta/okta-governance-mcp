"""
Tests for the consent verification interstitial page and polling endpoint.

Tests:
- consent-verify serves HTML with tx_id, no tokens leaked
- consent-verify rejects invalid/missing sessions
- consent-status returns connection JSON
- consent-status rejects invalid sessions
- consent-status returns 410 on expired tx
"""

import hashlib
import time
import pytest
from unittest.mock import MagicMock

from starlette.applications import Starlette
from starlette.routing import Route
from starlette.requests import Request
from starlette.responses import JSONResponse
from starlette.testclient import TestClient

from okta_agent_proxy.auth.consent_transaction import (
    ConsentConnectionStatus,
    ConsentTransaction,
    ConsentTransactionStore,
)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _ua_hash(ua: str = "TestAgent/1.0") -> str:
    return hashlib.sha256(ua.encode()).hexdigest()[:16]


def _build_app(store: ConsentTransactionStore):
    """Build a minimal Starlette app with consent-verify and consent-status."""
    from starlette.responses import HTMLResponse

    # Import the builder from app.py would require full init; inline a minimal version
    def _build_html(tx_id):
        return f"<html><body>TX={tx_id}</body></html>"

    async def consent_verify(request: Request):
        tx_id = request.query_params.get("tx", "")
        session_id = request.cookies.get("__okta_consent_session", "")

        if not tx_id or not session_id:
            return HTMLResponse(
                "<h1>Invalid Request</h1><p>Missing transaction or session.</p>",
                status_code=400,
            )

        ua_hash = hashlib.sha256(
            request.headers.get("user-agent", "").encode()
        ).hexdigest()[:16]

        tx = store.validate_session(
            session_id=session_id,
            ip_address=request.client.host if request.client else "",
            user_agent_hash=ua_hash,
        )

        if not tx or tx.transaction_id != tx_id:
            return HTMLResponse(
                "<h1>Session Invalid</h1><p>Your consent session has expired or is invalid.</p>",
                status_code=403,
            )

        return HTMLResponse(_build_html(tx_id))

    async def consent_status(request: Request):
        tx_id = request.query_params.get("tx", "")
        session_id = request.cookies.get("__okta_consent_session", "")

        if not tx_id or not session_id:
            return JSONResponse({"error": "invalid_request"}, status_code=400)

        ua_hash = hashlib.sha256(
            request.headers.get("user-agent", "").encode()
        ).hexdigest()[:16]

        tx = store.validate_session(
            session_id=session_id,
            ip_address=request.client.host if request.client else "",
            user_agent_hash=ua_hash,
        )

        if not tx or tx.transaction_id != tx_id:
            return JSONResponse({"error": "session_invalid"}, status_code=403)

        if tx.is_expired:
            return JSONResponse({"error": "session_expired", "status": "expired"}, status_code=410)

        return JSONResponse({
            "status": tx.status,
            "connections": [
                {
                    "resource_name": c.resource_name,
                    "provider": c.provider,
                    "status": c.status,
                    "interaction_uri": c.interaction_uri if c.status == "consent_required" else None,
                }
                for c in tx.connections
            ],
        })

    return Starlette(routes=[
        Route("/oauth/consent-verify", consent_verify, methods=["GET"]),
        Route("/oauth/consent-status", consent_status, methods=["GET"]),
    ])


def _create_tx_and_client(store, connections=None):
    """Create a transaction and return (tx, TestClient) with cookie set."""
    tx = store.create(
        original_redirect_uri="http://localhost:9999/callback",
        original_state="state_abc",
        original_client_id="https://app.example.com/oauth.json",
        id_token="idt_secret_123",
        access_token="at_secret_456",
        refresh_token="rt_secret_789",
        agent_id="agent-1",
        agent_config={"client_id": "0oa_xyz"},
        ip_address="testclient",
        user_agent_hash=_ua_hash("testclient"),
    )
    if connections:
        tx.connections = connections

    app = _build_app(store)
    client = TestClient(app)
    # Set the session cookie
    client.cookies.set("__okta_consent_session", tx.session_id)
    return tx, client


# ---------------------------------------------------------------------------
# Tests — consent-verify page
# ---------------------------------------------------------------------------


class TestConsentVerifyPage:
    def test_consent_verify_serves_html(self):
        store = ConsentTransactionStore()
        tx, client = _create_tx_and_client(store)

        resp = client.get(f"/oauth/consent-verify?tx={tx.transaction_id}")
        assert resp.status_code == 200
        assert "text/html" in resp.headers["content-type"]
        assert tx.transaction_id in resp.text

    def test_consent_verify_no_tokens_in_html(self):
        store = ConsentTransactionStore()
        tx, client = _create_tx_and_client(store)

        resp = client.get(f"/oauth/consent-verify?tx={tx.transaction_id}")
        html = resp.text
        # Sensitive values must NOT appear in HTML
        assert "at_secret_456" not in html
        assert "idt_secret_123" not in html
        assert "rt_secret_789" not in html
        assert "http://localhost:9999/callback" not in html

    def test_consent_verify_invalid_session(self):
        store = ConsentTransactionStore()
        tx, client = _create_tx_and_client(store)

        # Use a bad cookie
        client.cookies.set("__okta_consent_session", "bad_session_id")
        resp = client.get(f"/oauth/consent-verify?tx={tx.transaction_id}")
        assert resp.status_code == 403
        assert "Session Invalid" in resp.text

    def test_consent_verify_missing_tx(self):
        store = ConsentTransactionStore()
        tx, client = _create_tx_and_client(store)

        resp = client.get("/oauth/consent-verify")
        assert resp.status_code == 400
        assert "Missing" in resp.text


# ---------------------------------------------------------------------------
# Tests — consent-status polling
# ---------------------------------------------------------------------------


class TestConsentStatus:
    def test_consent_status_returns_connections(self):
        store = ConsentTransactionStore()
        connections = [
            ConsentConnectionStatus(
                connection_id="c1", resource_name="github",
                provider="GitHub Enterprise", resource_indicator="orn:1",
                status="verified",
            ),
            ConsentConnectionStatus(
                connection_id="c2", resource_name="jira",
                provider="Jira Cloud", resource_indicator="orn:2",
                status="consent_required",
                interaction_uri="https://okta.example.com/consent",
            ),
        ]
        tx, client = _create_tx_and_client(store, connections=connections)

        resp = client.get(f"/oauth/consent-status?tx={tx.transaction_id}")
        assert resp.status_code == 200
        data = resp.json()
        assert data["status"] == "verifying"
        assert len(data["connections"]) == 2
        assert data["connections"][0]["status"] == "verified"
        assert data["connections"][0]["interaction_uri"] is None
        assert data["connections"][1]["status"] == "consent_required"
        assert data["connections"][1]["interaction_uri"] == "https://okta.example.com/consent"

    def test_consent_status_invalid_session(self):
        store = ConsentTransactionStore()
        tx, client = _create_tx_and_client(store)

        client.cookies.set("__okta_consent_session", "wrong_session")
        resp = client.get(f"/oauth/consent-status?tx={tx.transaction_id}")
        assert resp.status_code == 403
        assert resp.json()["error"] == "session_invalid"

    def test_consent_status_expired(self):
        store = ConsentTransactionStore()
        tx, client = _create_tx_and_client(store)

        # Expire the transaction
        tx.created_at = time.monotonic() - 700

        resp = client.get(f"/oauth/consent-status?tx={tx.transaction_id}")
        # get_by_session → get_by_id removes expired, returns None → 403
        assert resp.status_code == 403
