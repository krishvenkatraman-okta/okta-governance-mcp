"""
Multi-pod integration tests for Redis-backed caching (P6).

Runs two adapter component instances against a shared FakeRedisProvider
to verify cross-pod state visibility for all caches migrated in P2-P5.

Runnable in CI without a real Redis server.

Usage:
    pytest tests/integration/test_redis_multipod.py -v
    pytest tests/integration/test_redis_multipod.py -v -m integration
"""

import asyncio
import json
import time

import pytest
from datetime import datetime, timezone, timedelta
from unittest.mock import AsyncMock, patch, MagicMock

from okta_agent_proxy.cache.cache_service import CacheService
from okta_agent_proxy.cache.pubsub import (
    CacheEventBus,
    CHANNEL_USER_TOKEN_INVALIDATE,
    CHANNEL_RELAY_SESSION_INVALIDATE,
    CHANNEL_CONSENT_TX_INVALIDATE,
    CHANNEL_USER_LOGOUT,
    CHANNEL_TOOL_CATALOG_INVALIDATE,
)
from okta_agent_proxy.cache.redis_provider import RedisCacheProvider
from okta_agent_proxy.cache.token_cache import TokenCache
from okta_agent_proxy.cache.serializers import serialize_json, deserialize_json
from okta_agent_proxy.auth.user_token_store import UserTokenStore
from okta_agent_proxy.auth.gateway_code_manager import (
    GatewayCodeManager,
    GatewayCodeNotFound,
)
from okta_agent_proxy.auth.confidential_relay import ConfidentialRelay, RelaySession
from okta_agent_proxy.auth.consent_transaction import (
    ConsentTransactionStore,
    ConsentConnectionStatus,
)
from okta_agent_proxy.proxy.session_manager import MCPSessionManager

pytestmark = [pytest.mark.integration, pytest.mark.asyncio]


# ---------------------------------------------------------------------------
# FakeRedisProvider — in-memory dict that satisfies isinstance checks
# ---------------------------------------------------------------------------
class FakeRedisProvider(RedisCacheProvider):
    """In-memory dict backing that satisfies isinstance(x, RedisCacheProvider)."""

    def __init__(self):
        self._data: dict[str, str] = {}
        self._ttls: dict[str, int] = {}

    async def get(self, key: str):
        return self._data.get(key)

    async def set(self, key: str, value: str, ttl_seconds=None):
        self._data[key] = value
        if ttl_seconds:
            self._ttls[key] = ttl_seconds

    async def delete(self, key: str):
        self._data.pop(key, None)
        self._ttls.pop(key, None)

    async def exists(self, key: str) -> bool:
        return key in self._data

    async def clear_prefix(self, prefix: str) -> int:
        keys = [k for k in self._data if k.startswith(prefix)]
        for k in keys:
            del self._data[k]
        return len(keys)

    async def health_check(self) -> bool:
        return True

    def close(self):
        self._data.clear()


# ---------------------------------------------------------------------------
# Shared in-process pub/sub for simulating cross-pod message delivery
# ---------------------------------------------------------------------------
class InProcessPubSub:
    """Delivers published messages to all registered subscribers immediately."""

    def __init__(self):
        self._subscribers: dict[str, list] = {}

    async def publish(self, channel: str, message: str):
        for cb in self._subscribers.get(channel, []):
            result = cb(message)
            if asyncio.iscoroutine(result):
                await result

    async def subscribe(self, channel: str, callback):
        if channel not in self._subscribers:
            self._subscribers[channel] = []
        self._subscribers[channel].append(callback)


def _make_event_bus(cache_service, shared_pubsub: InProcessPubSub) -> CacheEventBus:
    """Create a CacheEventBus that routes through shared in-process delivery."""
    bus = CacheEventBus(cache_service)
    original_subscribe = bus.subscribe

    async def patched_publish(channel, message):
        await shared_pubsub.publish(channel, message)

    async def patched_subscribe(channel, callback):
        await original_subscribe(channel, callback)
        await shared_pubsub.subscribe(channel, callback)

    bus.publish = patched_publish
    bus.subscribe = patched_subscribe
    return bus


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


@pytest.fixture
def fake_redis():
    return FakeRedisProvider()


@pytest.fixture
def cache_service(fake_redis):
    return CacheService(l2_provider=fake_redis)


@pytest.fixture
def shared_pubsub():
    return InProcessPubSub()


# ---------------------------------------------------------------------------
# Test class
# ---------------------------------------------------------------------------
class TestMultiPodRedisCaching:
    """Integration tests proving cross-pod state visibility via shared Redis."""

    # -- (a) UserTokenStore -------------------------------------------------

    async def test_user_token_visible_across_pods(self, cache_service):
        """astore on pod A → alookup on pod B returns the same payload."""
        store_a = UserTokenStore(cache_service=cache_service)
        store_b = UserTokenStore(cache_service=cache_service)

        await store_a.astore(
            access_token="cross-pod-token",
            id_token="id-tok-xyz",
            refresh_token="ref-tok-xyz",
            user_sub="alice",
            agent_id="claude",
            expires_in=3600,
        )

        result = await store_b.alookup("cross-pod-token")
        assert result is not None
        assert result["user_sub"] == "alice"
        assert result["id_token"] == "id-tok-xyz"
        assert result["refresh_token"] == "ref-tok-xyz"
        assert result["agent_id"] == "claude"

    # -- (b) TokenCache (resource tokens) -----------------------------------

    async def test_resource_token_visible_across_pods(self, cache_service):
        """Set a resource token on pod A → read it from pod B."""
        cache_a = TokenCache(cache_service=cache_service)
        cache_b = TokenCache(cache_service=cache_service)

        cache_a.set(
            user_id="alice",
            resource_name="hr-system",
            token="eyJhbGciOiJSUzI1NiJ9.resource-jwt",
            ttl_seconds=3600,
        )

        token = cache_b.get(user_id="alice", resource_name="hr-system")
        assert token == "eyJhbGciOiJSUzI1NiJ9.resource-jwt"

    # -- (c) MCPSessionManager ----------------------------------------------

    async def test_mcp_session_visible_across_pods(self, cache_service):
        """Pre-populate session via CacheService on pod A → read from pod B."""
        mgr_a = MCPSessionManager(cache_service=cache_service)
        mgr_b = MCPSessionManager(cache_service=cache_service)

        # Directly write session data to CacheService (avoid HTTP calls)
        cache_key = "alice:hr-system"
        session_data = {
            "session_id": "sess-abc-123",
            "created_at": datetime.now().isoformat(),
            "expires_at": (datetime.now() + timedelta(hours=1)).isoformat(),
            "resource_url": "https://hr.example.com/mcp",
        }
        await mgr_a._set_to_service(cache_key, session_data)

        # Read from pod B
        result = await mgr_b._get_from_service(cache_key)
        assert result is not None
        assert result["session_id"] == "sess-abc-123"

    # -- (d) GatewayCodeManager single-use ----------------------------------

    async def test_gateway_code_single_use_across_pods(self, cache_service):
        """Issue on A → exchange on B succeeds → second exchange raises."""
        mgr_a = GatewayCodeManager(cache_service=cache_service)
        mgr_b = GatewayCodeManager(cache_service=cache_service)

        code = await mgr_a.aissue_code(
            client_id="http://example.com/.well-known/oauth-client",
            tokens={
                "access_token": "at-123",
                "id_token": "idt-456",
                "refresh_token": "rt-789",
                "expires_in": 3600,
            },
        )

        # Exchange on B succeeds
        result = await mgr_b.aexchange_code(
            code, "http://example.com/.well-known/oauth-client"
        )
        assert result["access_token"] == "at-123"
        assert result["id_token"] == "idt-456"

        # Second exchange on A raises (code consumed)
        with pytest.raises(GatewayCodeNotFound):
            await mgr_a.aexchange_code(
                code, "http://example.com/.well-known/oauth-client"
            )

        # Third exchange on B also raises
        with pytest.raises(GatewayCodeNotFound):
            await mgr_b.aexchange_code(
                code, "http://example.com/.well-known/oauth-client"
            )

    # -- (e) ConfidentialRelay state ----------------------------------------

    async def test_relay_state_visible_across_pods(self, cache_service):
        """Store relay state on A → load on B returns the same session."""
        relay_a = ConfidentialRelay(cache_service=cache_service)
        relay_b = ConfidentialRelay(cache_service=cache_service)

        session = RelaySession(
            original_client_id="http://example.com/.well-known/oauth-client",
            original_redirect_uri="http://localhost:8080/callback",
            original_state="orig-state-xyz",
            relay_state="relay-state-shared",
            code_verifier="verifier-123",
            created_at=datetime.now(timezone.utc),
            relay_client_id="okta-client-id",
            relay_client_secret="okta-secret",
        )
        await relay_a._store_relay_state("relay-state-shared", session)

        loaded = await relay_b._load_relay_state("relay-state-shared")
        assert loaded is not None
        assert loaded.original_client_id == "http://example.com/.well-known/oauth-client"
        assert loaded.relay_client_id == "okta-client-id"
        assert loaded.original_state == "orig-state-xyz"

    # -- (f) ConsentTransactionStore ----------------------------------------

    async def test_consent_tx_visible_across_pods(self, cache_service):
        """acreate on A → aget_by_id and aget_by_session on B work."""
        store_a = ConsentTransactionStore(cache_service=cache_service)
        store_b = ConsentTransactionStore(cache_service=cache_service)

        tx = await store_a.acreate(
            agent_id="claude",
            id_token="id-tok",
            access_token="access-tok",
        )

        # aget_by_id on B
        loaded = await store_b.aget_by_id(tx.transaction_id)
        assert loaded is not None
        assert loaded.agent_id == "claude"
        assert loaded.id_token == "id-tok"

        # aget_by_session on B
        loaded_by_session = await store_b.aget_by_session(tx.session_id)
        assert loaded_by_session is not None
        assert loaded_by_session.transaction_id == tx.transaction_id

    # -- (g) ConsentTransaction apersist ------------------------------------

    async def test_consent_tx_apersist_visible_across_pods(self, cache_service):
        """Mutate + apersist on A → aget_by_id on B sees the mutation."""
        store_a = ConsentTransactionStore(cache_service=cache_service)
        store_b = ConsentTransactionStore(cache_service=cache_service)

        tx = await store_a.acreate(
            agent_id="claude",
            id_token="id-tok",
            access_token="access-tok",
        )
        # Add a connection and mutate its status
        tx.connections.append(
            ConsentConnectionStatus(
                connection_id="conn-1",
                resource_name="github",
                provider="STS",
                resource_indicator="orn:okta:...",
                status="pending",
            )
        )
        tx.connections[0].status = "verified"
        await store_a.apersist(tx)

        # Read on B
        loaded = await store_b.aget_by_id(tx.transaction_id)
        assert loaded is not None
        assert len(loaded.connections) == 1
        assert loaded.connections[0].status == "verified"
        assert loaded.connections[0].connection_id == "conn-1"

    # -- (h) user_logout clears all pods ------------------------------------

    async def test_user_logout_clears_all_pods(
        self, cache_service, shared_pubsub
    ):
        """Logout cascade clears UserTokenStore + TokenCache on remote pod."""
        bus_a = _make_event_bus(cache_service, shared_pubsub)
        bus_b = _make_event_bus(cache_service, shared_pubsub)

        token_store_b = UserTokenStore(cache_service=cache_service)
        token_cache_b = TokenCache(cache_service=cache_service)

        # Subscribe B to user_logout
        async def _on_logout(message):
            payload = json.loads(message)
            user_sub = payload.get("key")
            if user_sub:
                token_store_b.remove_by_user(user_sub)
                token_cache_b.invalidate(user_id=user_sub)

        await bus_b.subscribe(CHANNEL_USER_LOGOUT, _on_logout)

        # Populate B's stores for "alice"
        await token_store_b.astore(
            access_token="alice-token",
            id_token="id1",
            refresh_token="ref1",
            user_sub="alice",
            agent_id="claude",
        )
        token_cache_b.set(
            user_id="alice",
            resource_name="hr-system",
            token="resource-jwt",
        )

        # Verify B has data
        assert len(token_store_b._cache) == 1
        assert token_cache_b.get(user_id="alice", resource_name="hr-system") is not None

        # Publish logout from A
        await bus_a.publish(
            CHANNEL_USER_LOGOUT,
            json.dumps({"v": 1, "key": "alice"}),
        )

        # B's caches should be cleared
        assert len(token_store_b._cache) == 0
        assert token_cache_b.get(user_id="alice", resource_name="hr-system") is None

    # -- (i) JWKS cache visible across pods ---------------------------------

    async def test_jwks_cache_visible_across_pods(self, cache_service):
        """JWKS fetched by pod A is reused by pod B — no second HTTP call."""
        from okta_agent_proxy.auth.okta_validator import OktaTokenValidator

        fake_jwks = {"keys": [{"kty": "RSA", "kid": "test-kid", "n": "abc", "e": "AQAB"}]}

        # Track how many times the HTTP fetch is called
        fetch_count = 0
        original_fetch = None

        async def mock_fetch(self_val):
            nonlocal fetch_count
            # Check local cache first
            if "jwks" in self_val.jwks_cache:
                return self_val.jwks_cache["jwks"]
            # Check CacheService
            cached = await self_val._get_from_service()
            if cached is not None:
                self_val.jwks_cache["jwks"] = cached
                return cached
            # "Fetch" from Okta
            fetch_count += 1
            self_val.jwks_cache["jwks"] = fake_jwks
            await self_val._set_to_service(fake_jwks)
            return fake_jwks

        validator_a = OktaTokenValidator(
            okta_domain="dev-test.okta.com",
            cache_service=cache_service,
        )
        validator_b = OktaTokenValidator(
            okta_domain="dev-test.okta.com",
            cache_service=cache_service,
        )

        with patch.object(OktaTokenValidator, "fetch_jwks", mock_fetch):
            jwks_a = await validator_a.fetch_jwks()
            jwks_b = await validator_b.fetch_jwks()

        assert jwks_a == fake_jwks
        assert jwks_b == fake_jwks
        assert fetch_count == 1  # Only one HTTP fetch, not two

    # -- (j) tool_catalog_invalidate clears both pods -----------------------

    async def test_tool_catalog_invalidate_clears_both_pods(
        self, cache_service, shared_pubsub
    ):
        """Publish tool_catalog_invalidate → both pods' caches cleared."""
        bus_a = _make_event_bus(cache_service, shared_pubsub)
        bus_b = _make_event_bus(cache_service, shared_pubsub)

        # Simulate tool catalog L1 caches on both pods
        catalog_a = {"agent-1": {"tools": ["tool_a"]}}
        catalog_b = {"agent-1": {"tools": ["tool_a"]}}

        # Subscribe both to tool_catalog_invalidate
        async def _on_invalidate_a(message):
            catalog_a.clear()

        async def _on_invalidate_b(message):
            catalog_b.clear()

        await bus_a.subscribe(CHANNEL_TOOL_CATALOG_INVALIDATE, _on_invalidate_a)
        await bus_b.subscribe(CHANNEL_TOOL_CATALOG_INVALIDATE, _on_invalidate_b)

        # Verify both have data
        assert len(catalog_a) == 1
        assert len(catalog_b) == 1

        # Publish from A
        await bus_a.publish(
            CHANNEL_TOOL_CATALOG_INVALIDATE,
            json.dumps({"agent_id": "agent-1"}),
        )

        # Both should be cleared
        assert len(catalog_a) == 0
        assert len(catalog_b) == 0
