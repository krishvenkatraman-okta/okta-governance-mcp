"""Tests for GatewayCodeManager.arevoke_by_user / revoke_by_user.

Covers the L1 purge path that global logout uses to kill CIMD/DCR tokens
held in _sessions_by_token.
"""

from unittest.mock import AsyncMock

import pytest
from jose import jwt as jose_jwt

from okta_agent_proxy.auth.gateway_code_manager import GatewayCodeManager


def _id_token_with_sub(sub: str) -> str:
    """Unsigned JWT is fine — the manager uses get_unverified_claims()."""
    return jose_jwt.encode({"sub": sub, "iss": "https://x"}, key="k", algorithm="HS256")


def test_revoke_by_user_sync_drops_only_matching_entries():
    mgr = GatewayCodeManager(token_ttl=60, max_tokens=100)
    mgr.track_token("tokA1", "client-a", id_token=_id_token_with_sub("user-a"))
    mgr.track_token("tokA2", "client-a", id_token=_id_token_with_sub("user-a"))
    mgr.track_token("tokB1", "client-b", id_token=_id_token_with_sub("user-b"))

    removed = mgr.revoke_by_user("user-a")

    assert removed == 2
    assert mgr.lookup_token("tokA1") is None
    assert mgr.lookup_token("tokA2") is None
    # B is untouched
    assert mgr.lookup_token("tokB1") is not None


def test_revoke_by_user_prefers_explicit_user_sub_over_id_token():
    """Entries that carry a stored user_sub skip JWT decode."""
    mgr = GatewayCodeManager(token_ttl=60, max_tokens=100)
    mgr.track_token("tokA", "client-a", user_sub="user-a")  # no id_token
    mgr.track_token("tokB", "client-b", user_sub="user-b")

    removed = mgr.revoke_by_user("user-a")

    assert removed == 1
    assert mgr.lookup_token("tokA") is None
    assert mgr.lookup_token("tokB") is not None


def test_revoke_by_user_noop_for_unknown_sub():
    mgr = GatewayCodeManager(token_ttl=60, max_tokens=100)
    mgr.track_token("tokA", "client-a", id_token=_id_token_with_sub("user-a"))

    removed = mgr.revoke_by_user("nobody")

    assert removed == 0
    assert mgr.lookup_token("tokA") is not None


def test_revoke_by_user_handles_malformed_id_token_entry():
    mgr = GatewayCodeManager(token_ttl=60, max_tokens=100)
    mgr.track_token("tokA", "client-a", id_token="not-a-jwt")
    mgr.track_token("tokB", "client-b", id_token=_id_token_with_sub("user-b"))

    removed = mgr.revoke_by_user("user-b")

    assert removed == 1
    assert mgr.lookup_token("tokB") is None
    # Malformed entry is left alone (no sub extractable)
    assert mgr.lookup_token("tokA") is not None


def test_revoke_by_user_sync_refuses_when_cache_service_wired():
    mgr = GatewayCodeManager(token_ttl=60, cache_service=AsyncMock())
    with pytest.raises(RuntimeError, match="arevoke_by_user"):
        mgr.revoke_by_user("user-a")


@pytest.mark.asyncio
async def test_arevoke_by_user_deletes_l2_entries():
    """L2 keys for revoked tokens must be deleted."""
    cache = AsyncMock()
    cache.delete = AsyncMock(return_value=None)
    mgr = GatewayCodeManager(token_ttl=60, cache_service=cache)

    await mgr.atrack_token("tokA", "client-a", id_token=_id_token_with_sub("user-a"))
    await mgr.atrack_token("tokB", "client-b", id_token=_id_token_with_sub("user-b"))

    removed = await mgr.arevoke_by_user("user-a")

    assert removed == 1
    assert mgr.lookup_token("tokA") is None
    assert mgr.lookup_token("tokB") is not None
    cache.delete.assert_any_await("gateway_token:tokA")


@pytest.mark.asyncio
async def test_arevoke_by_user_swallows_l2_errors():
    cache = AsyncMock()
    cache.delete = AsyncMock(side_effect=RuntimeError("L2 boom"))
    mgr = GatewayCodeManager(token_ttl=60, cache_service=cache)

    await mgr.atrack_token("tokA", "client-a", id_token=_id_token_with_sub("user-a"))

    # Must not raise — L1 purge already happened
    removed = await mgr.arevoke_by_user("user-a")
    assert removed == 1
    assert mgr.lookup_token("tokA") is None
