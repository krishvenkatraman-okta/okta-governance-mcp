"""
End-to-end tests for connection-scoped resource isolation.

Proves cross-agent resource leakage is impossible across the full stack:
- Token cache layer (P02)
- Resource routing layer (P03)
- Token exchange layer (P04)
- Tool catalog layer (P05)
- Backward compatibility for local resources
"""

import pytest
from datetime import datetime, timedelta
from unittest.mock import MagicMock

from okta_agent_proxy.cache.token_cache import TokenCache
from okta_agent_proxy.resources.models import (
    OktaConnectionType,
    OktaScopeCondition,
    ResolvedResource,
)


# ============================================================================
# Helpers
# ============================================================================


def _make_resolved(
    name,
    agent_id=None,
    agent_name=None,
    connection_id="conn-1",
    scopes=None,
    mcp_url=None,
):
    return ResolvedResource(
        resource_id=f"aus-{name}",
        name=name,
        mcp_url=mcp_url or f"https://{name}.example.com/mcp",
        connection_id=connection_id,
        connection_type=OktaConnectionType.IDENTITY_ASSERTION_CUSTOM_AS,
        agent_id=agent_id,
        agent_name=agent_name,
        scopes=scopes or [],
    )


# ============================================================================
# Attack Scenario: Cache Isolation
# ============================================================================


class TestCacheIsolationE2E:
    """Prove that cached tokens cannot leak between agents."""

    def test_agent_a_cached_token_invisible_to_agent_b(self):
        """
        ATTACK: Agent A (Claude, scoped read:employees) caches a token for hr-system.
        Agent B (Cursor, scoped read:payroll) requests hr-system for the SAME user.
        Agent B must NOT get Agent A's cached token.
        """
        cache = TokenCache(max_size=1000, ttl_seconds=3600)
        user_id = "user@example.com"

        # Agent A caches token
        token_a = {"access_token": "at_employees", "scope": "read:employees", "expires_in": 3600}
        cache.set(
            user_id, "hr-system", token_a,
            agent_id="agent-claude", connection_id="conn-claude-hr",
        )

        # Agent B tries to read — MUST get None
        result_b = cache.get(
            user_id, "hr-system",
            agent_id="agent-cursor", connection_id="conn-cursor-hr",
        )
        assert result_b is None, "ISOLATION BREACH: Agent B got Agent A's cached token!"

        # Agent A can still read its own token
        result_a = cache.get(
            user_id, "hr-system",
            agent_id="agent-claude", connection_id="conn-claude-hr",
        )
        assert result_a is not None
        assert result_a["scope"] == "read:employees"

    def test_cache_invalidation_does_not_cross_agents(self):
        """
        ATTACK: Invalidating Agent A's hr-system token must NOT invalidate Agent B's.
        """
        cache = TokenCache(max_size=1000, ttl_seconds=3600)
        user_id = "user@example.com"

        # Both agents cache tokens
        cache.set(
            user_id, "hr-system",
            {"access_token": "at_A", "scope": "read:employees"},
            agent_id="agent-claude", connection_id="conn-claude-hr",
        )
        cache.set(
            user_id, "hr-system",
            {"access_token": "at_B", "scope": "read:payroll"},
            agent_id="agent-cursor", connection_id="conn-cursor-hr",
        )

        # Invalidate only Agent A
        cache.invalidate(
            user_id, "hr-system",
            agent_id="agent-claude", connection_id="conn-claude-hr",
        )

        # Agent A's token gone
        assert cache.get(
            user_id, "hr-system",
            agent_id="agent-claude", connection_id="conn-claude-hr",
        ) is None

        # Agent B's token intact
        result_b = cache.get(
            user_id, "hr-system",
            agent_id="agent-cursor", connection_id="conn-cursor-hr",
        )
        assert result_b is not None
        assert result_b["scope"] == "read:payroll"

    def test_same_user_three_agents_fully_isolated(self):
        """Three agents, same user, same resource — all cached tokens isolated."""
        cache = TokenCache(max_size=1000, ttl_seconds=3600)
        user = "shared-user@corp.com"
        agents = [
            ("agent-claude", "conn-claude", "scope-claude"),
            ("agent-cursor", "conn-cursor", "scope-cursor"),
            ("agent-copilot", "conn-copilot", "scope-copilot"),
        ]

        # Cache tokens for all three
        for agent_id, conn_id, scope in agents:
            cache.set(
                user, "hr-system", {"token": f"tok-{agent_id}", "scope": scope},
                agent_id=agent_id, connection_id=conn_id,
            )

        # Each agent gets only its own token
        for agent_id, conn_id, scope in agents:
            result = cache.get(user, "hr-system", agent_id=agent_id, connection_id=conn_id)
            assert result is not None, f"{agent_id} should have a cached token"
            assert result["scope"] == scope, f"{agent_id} got wrong scope"

            # Verify cross-agent isolation
            for other_id, other_conn, _ in agents:
                if other_id != agent_id:
                    cross_result = cache.get(user, "hr-system", agent_id=other_id, connection_id=other_conn)
                    assert cross_result is None or cross_result["scope"] != scope, \
                        f"{agent_id}'s token was served to {other_id}!"


# ============================================================================
# Isolation Key Tests
# ============================================================================


class TestIsolationKeys:
    """Verify isolation keys are unique across agent/connection combinations."""

    def test_same_resource_different_agents_different_keys(self):
        r_a = _make_resolved("hr-system", agent_id="agent-a", connection_id="conn-a")
        r_b = _make_resolved("hr-system", agent_id="agent-b", connection_id="conn-b")
        assert r_a.isolation_key != r_b.isolation_key

    def test_same_agent_different_connections_different_keys(self):
        r1 = _make_resolved("hr-system", agent_id="agent-a", connection_id="conn-1")
        r2 = _make_resolved("hr-system", agent_id="agent-a", connection_id="conn-2")
        assert r1.isolation_key != r2.isolation_key

    def test_local_resource_key_is_just_name(self):
        r = _make_resolved("api-keys", connection_id="")
        assert r.isolation_key == "api-keys"

    def test_isolation_key_deterministic(self):
        """Same inputs always produce the same key."""
        for _ in range(10):
            r = _make_resolved("hr-system", agent_id="agent-a", connection_id="conn-1")
            assert r.isolation_key == "agent-a:conn-1:hr-system"


# ============================================================================
# Router Isolation E2E
# ============================================================================


class TestRouterIsolationE2E:
    """Verify the router returns agent-specific scopes."""

    def test_agent_specific_scopes_from_router(self):
        """Agent A and B get different scopes for the same resource through the syncer."""
        from okta_agent_proxy.resources.syncer import OktaConnectionSyncer

        r_a = _make_resolved("hr-system", agent_id="agent-a", connection_id="conn-a", scopes=["read:employees"])
        r_b = _make_resolved("hr-system", agent_id="agent-b", connection_id="conn-b", scopes=["read:payroll"])

        syncer = OktaConnectionSyncer.__new__(OktaConnectionSyncer)
        syncer._resources = {
            r_a.isolation_key: r_a,
            r_b.isolation_key: r_b,
        }
        syncer._unresolved = []
        syncer._last_sync_at = None
        syncer._last_sync_status = "never"
        syncer._last_connections = {}
        syncer._last_agent_info = {}
        syncer._raw_connections = []
        syncer._http_client = None
        syncer._okta_domain = "https://test.okta.com"
        syncer._api_token = ""
        syncer._store = MagicMock()
        syncer._event_bus = MagicMock()
        syncer._stale_threshold = 1800

        # Agent A sees read:employees
        res_a = syncer.get_resolved_resources_for_agent("agent-a")
        assert "hr-system" in res_a
        assert res_a["hr-system"].scopes == ["read:employees"]

        # Agent B sees read:payroll
        res_b = syncer.get_resolved_resources_for_agent("agent-b")
        assert "hr-system" in res_b
        assert res_b["hr-system"].scopes == ["read:payroll"]

        # Agent C sees nothing
        res_c = syncer.get_resolved_resources_for_agent("agent-c")
        assert "hr-system" not in res_c


# ============================================================================
# Tool Catalog Isolation E2E
# ============================================================================


class TestToolCatalogIsolationE2E:
    """Verify tool catalogs are not shared between agents."""

    def test_agent_a_catalog_not_shared_with_agent_b(self):
        """Tool catalogs are keyed by agent_id — no cross-contamination."""
        import cachetools

        tool_cache = cachetools.TTLCache(maxsize=100, ttl=300)

        catalog_a = {"tools": [{"name": "hr__get_employee"}], "tool_map": {"hr__get_employee": ("hr", "get_employee")}}
        catalog_b = {"tools": [{"name": "hr__get_payroll"}], "tool_map": {"hr__get_payroll": ("hr", "get_payroll")}}

        tool_cache["agent-a"] = catalog_a
        tool_cache["agent-b"] = catalog_b

        # Agent A gets only its tools
        assert tool_cache["agent-a"]["tools"][0]["name"] == "hr__get_employee"
        # Agent B gets only its tools
        assert tool_cache["agent-b"]["tools"][0]["name"] == "hr__get_payroll"
        # Agent C gets nothing
        assert tool_cache.get("agent-c") is None

    def test_invalidating_agent_a_catalog_keeps_agent_b(self):
        import cachetools

        tool_cache = cachetools.TTLCache(maxsize=100, ttl=300)
        tool_cache["agent-a"] = {"tools": [{"name": "tool-a"}], "tool_map": {}}
        tool_cache["agent-b"] = {"tools": [{"name": "tool-b"}], "tool_map": {}}

        # Invalidate agent-a
        del tool_cache["agent-a"]

        assert "agent-a" not in tool_cache
        assert "agent-b" in tool_cache


# ============================================================================
# Full Pipeline: Concurrent Agents Same User
# ============================================================================


class TestFullPipelineIsolation:
    """Verify concurrent agents for the same user cannot leak data."""

    def test_concurrent_agents_same_user_no_cache_leakage(self):
        """Simulate two agents for the same user making requests simultaneously."""
        cache = TokenCache(max_size=1000, ttl_seconds=3600)
        user = "alice@corp.com"

        # Agent A stores a cross-app token
        cache.set(
            user, "hr-system", {"token": "xaa-token-a", "expires_at": datetime.now() + timedelta(hours=1)},
            agent_id="claude-code", connection_id="conn-claude",
        )

        # Agent B stores a vault secret
        cache.set(
            f"vault:{user}", "hr-system", {"token": "vault-secret-b", "expires_at": datetime.now() + timedelta(hours=1)},
            agent_id="cursor", connection_id="conn-cursor",
        )

        # Cross-check: Agent B cannot access Agent A's cross-app token
        assert cache.get(
            user, "hr-system", agent_id="cursor", connection_id="conn-cursor"
        ) is None

        # Each agent gets its own
        assert cache.get(
            user, "hr-system", agent_id="claude-code", connection_id="conn-claude"
        )["token"] == "xaa-token-a"
        assert cache.get(
            f"vault:{user}", "hr-system", agent_id="cursor", connection_id="conn-cursor"
        )["token"] == "vault-secret-b"


# ============================================================================
# Backward Compatibility
# ============================================================================


class TestBackwardCompatibility:
    """Ensure local resources without agent scoping still work."""

    def test_local_psk_resource_no_agent_id(self):
        """Pre-shared-key resource with no agent scoping works as before."""
        cache = TokenCache(max_size=1000, ttl_seconds=3600)
        cache.set("user-1", "legacy-api", "static-key-123")
        result = cache.get("user-1", "legacy-api")
        assert result == "static-key-123"

    def test_local_resource_accessible_to_any_agent(self):
        """Local resource (agent_id=None in syncer) visible to all agents."""
        from okta_agent_proxy.resources.syncer import OktaConnectionSyncer

        r_local = _make_resolved("api-keys", connection_id="")
        r_scoped = _make_resolved("hr-system", agent_id="agent-a", connection_id="conn-a")

        syncer = OktaConnectionSyncer.__new__(OktaConnectionSyncer)
        syncer._resources = {
            r_local.isolation_key: r_local,
            r_scoped.isolation_key: r_scoped,
        }
        syncer._unresolved = []
        syncer._last_sync_at = None
        syncer._last_sync_status = "never"
        syncer._last_connections = {}
        syncer._last_agent_info = {}
        syncer._raw_connections = []
        syncer._http_client = None
        syncer._okta_domain = "https://test.okta.com"
        syncer._api_token = ""
        syncer._store = MagicMock()
        syncer._event_bus = MagicMock()
        syncer._stale_threshold = 1800

        # Any agent can see api-keys (agent_id=None)
        for agent in ["agent-a", "agent-b", "agent-x"]:
            res = syncer.get_resolved_resources_for_agent(agent)
            assert "api-keys" in res, f"Agent {agent} should see local resource api-keys"

    def test_mixed_local_and_connection_resources(self):
        """Agent sees both local and agent-scoped resources."""
        from okta_agent_proxy.resources.syncer import OktaConnectionSyncer

        r_local = _make_resolved("api-keys", connection_id="")
        r_scoped = _make_resolved("hr-system", agent_id="agent-a", connection_id="conn-a", scopes=["read:employees"])

        syncer = OktaConnectionSyncer.__new__(OktaConnectionSyncer)
        syncer._resources = {
            r_local.isolation_key: r_local,
            r_scoped.isolation_key: r_scoped,
        }
        syncer._unresolved = []
        syncer._last_sync_at = None
        syncer._last_sync_status = "never"
        syncer._last_connections = {}
        syncer._last_agent_info = {}
        syncer._raw_connections = []
        syncer._http_client = None
        syncer._okta_domain = "https://test.okta.com"
        syncer._api_token = ""
        syncer._store = MagicMock()
        syncer._event_bus = MagicMock()
        syncer._stale_threshold = 1800

        # Agent A sees both
        res_a = syncer.get_resolved_resources_for_agent("agent-a")
        assert "api-keys" in res_a
        assert "hr-system" in res_a
        assert res_a["hr-system"].scopes == ["read:employees"]

        # Agent B sees only local
        res_b = syncer.get_resolved_resources_for_agent("agent-b")
        assert "api-keys" in res_b
        assert "hr-system" not in res_b

    def test_unscoped_cache_and_scoped_cache_do_not_collide(self):
        """Legacy (unscoped) and new (scoped) cache entries for same resource coexist."""
        cache = TokenCache(max_size=1000, ttl_seconds=3600)

        # Legacy: no agent_id
        cache.set("user-1", "hr-system", "legacy-token")

        # Scoped: with agent_id
        cache.set("user-1", "hr-system", "scoped-token", agent_id="agent-a", connection_id="conn-a")

        # Both retrievable independently
        assert cache.get("user-1", "hr-system") == "legacy-token"
        assert cache.get("user-1", "hr-system", agent_id="agent-a", connection_id="conn-a") == "scoped-token"


# ============================================================================
# Pub/Sub Scoped Invalidation
# ============================================================================


class TestPubSubScopedInvalidation:
    """Verify scoped pub/sub invalidation payloads."""

    def test_json_payload_with_agent_id(self):
        """JSON payload with agent_id is parseable."""
        import json
        payload = json.dumps({"agent_id": "agent-abc"})
        parsed = json.loads(payload)
        assert parsed["agent_id"] == "agent-abc"

    def test_plain_string_payload_backward_compat(self):
        """Plain string payload (no JSON) doesn't crash the parser."""
        import json
        message = "all"
        scoped_agent_id = None
        try:
            parsed = json.loads(message)
            if isinstance(parsed, dict):
                scoped_agent_id = parsed.get("agent_id")
        except (ValueError, TypeError):
            pass
        assert scoped_agent_id is None
