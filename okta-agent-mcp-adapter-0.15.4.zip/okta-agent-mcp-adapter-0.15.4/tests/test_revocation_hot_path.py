"""Post-logout hot-path rejection.

Exercises the revocation-registry check that ProxyHandler and
UnifiedMCPHandler do after validate_token returns a valid claimset.
Without this check, an Okta-signed JWT held by VS Code / Cursor would
keep passing validation until its exp even after global logout.
"""

from unittest.mock import AsyncMock, MagicMock

import pytest

from okta_agent_proxy.auth.revocation_registry import (
    get_revocation_registry,
    reset_revocation_registry,
)
from okta_agent_proxy.proxy.handler import ProxyHandler


@pytest.fixture(autouse=True)
def _reset_registry():
    reset_revocation_registry()
    yield
    reset_revocation_registry()


def _mk_router():
    router = MagicMock()
    router.get_resource_for_path.return_value = "hr-system"
    resource = MagicMock()
    resource.enabled = True
    router.get_resource_config.return_value = resource
    return router


def _mk_store():
    store = MagicMock()
    store.get_agent_by_name.return_value = {
        "agent_id": "claude-code",
        "client_id": "test-client",
        "backend_access": ["hr-system"],
    }
    store.get_agent.return_value = MagicMock(client_id="test-client")
    store.get_all_agents.return_value = [{"agent_id": "claude-code", "client_id": "test-client"}]
    return store


def _mk_validator(sub="user-1"):
    validator = MagicMock()
    validator.validate_token = AsyncMock(return_value={
        "sub": sub, "aud": "test-client", "exp": 9999999999,
    })
    return validator


@pytest.mark.asyncio
async def test_proxy_request_returns_unauthorized_when_sub_revoked():
    handler = ProxyHandler(_mk_router(), _mk_validator("user-1"), _mk_store())

    # Simulate global logout: mark user-1 as revoked.
    await get_revocation_registry().revoke("user-1")

    result = await handler.proxy_request(
        request_path="/hr",
        method="tools/list",
        params={},
        auth_header="Bearer valid.jwt.token",
        request_id="1",
        headers={"x-mcp-agent": "claude-code"},
    )

    assert result.get("error") == "unauthorized"
    assert "invalid or expired" in result.get("message", "").lower()


@pytest.mark.asyncio
async def test_proxy_request_still_works_for_non_revoked_sub():
    """Guard rail: the registry check must not reject healthy users."""
    # Simulate a prior logout of a different user
    await get_revocation_registry().revoke("other-user")

    handler = ProxyHandler(_mk_router(), _mk_validator("user-1"), _mk_store())

    result = await handler.proxy_request(
        request_path="/hr",
        method="tools/list",
        params={},
        auth_header="Bearer valid.jwt.token",
        request_id="1",
        headers={"x-mcp-agent": "claude-code"},
    )

    # We don't care about the downstream failure mode; just that we did
    # NOT short-circuit with unauthorized for a non-revoked sub.
    assert result.get("error") != "unauthorized"
