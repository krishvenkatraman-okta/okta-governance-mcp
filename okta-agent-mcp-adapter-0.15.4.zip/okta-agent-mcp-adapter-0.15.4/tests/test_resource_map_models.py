"""
Tests for the Resource Map subsystem.

As of DB migration P07 these tests depend on the removed SQLAlchemy
models (``storage/models.py``) and the legacy ``ResourceMapStore`` that
took a ``sessionmaker``. The psycopg3 port of ``ResourceStore`` lives in
``storage/repositories/linkage_repo.py``; coverage of the Pydantic
validators is preserved in the ``ResourceMapEntry`` class tests.
"""

import pytest

pytest.skip(
    "Superseded by P07 — SQLAlchemy ResourceMapModel removed.",
    allow_module_level=True,
)

from datetime import datetime  # noqa: E402
from sqlalchemy import create_engine  # noqa: E402
from sqlalchemy.orm import sessionmaker  # noqa: E402
from sqlalchemy.exc import IntegrityError  # noqa: E402

from okta_agent_proxy.storage.models import Base, ResourceMapModel, OktaSyncStateModel  # noqa: E402
from okta_agent_proxy.storage.postgres import ResourceMapStore  # noqa: E402
from okta_agent_proxy.resources.models import (
    ResourceMapEntry,
    OktaConnectionType,
    OktaScopeCondition,
    ResolvedResource,
    SyncResult,
)


# ============================================================================
# Fixtures
# ============================================================================

@pytest.fixture
def resource_map_engine():
    """Dedicated SQLite engine for resource_map tests."""
    engine = create_engine(
        "sqlite:///:memory:",
        connect_args={"check_same_thread": False},
        echo=False,
    )
    Base.metadata.create_all(engine)
    yield engine
    Base.metadata.drop_all(engine)
    engine.dispose()


@pytest.fixture
def rm_session_factory(resource_map_engine):
    """Session factory bound to the resource_map test engine."""
    return sessionmaker(bind=resource_map_engine)


@pytest.fixture
def rm_store(rm_session_factory):
    """ResourceMapStore backed by in-memory SQLite."""
    return ResourceMapStore(rm_session_factory)


@pytest.fixture
def sample_entry():
    """A valid ResourceMapEntry for testing."""
    return ResourceMapEntry(
        resource_id="aus1234567890",
        name="hr-system",
        mcp_url="https://hr.example.com/mcp",
        protocol="mcp",
        description="HR resource",
    )


@pytest.fixture
def sample_entry_b():
    """A second valid ResourceMapEntry."""
    return ResourceMapEntry(
        resource_id="aus0000000002",
        name="finance-api",
        mcp_url="https://finance.example.com/mcp",
        protocol="a2a",
        description="Finance resource",
    )


# ============================================================================
# ResourceMapEntry — valid creation
# ============================================================================

class TestResourceMapEntryValid:

    def test_create_basic(self, sample_entry):
        assert sample_entry.resource_id == "aus1234567890"
        assert sample_entry.name == "hr-system"
        assert sample_entry.protocol == "mcp"

    def test_defaults(self):
        entry = ResourceMapEntry(
            resource_id="x", name="a", mcp_url="http://localhost"
        )
        assert entry.protocol == "mcp"
        assert entry.description == ""

    def test_single_char_name(self):
        entry = ResourceMapEntry(
            resource_id="x", name="a", mcp_url="http://localhost"
        )
        assert entry.name == "a"

    def test_protocol_a2a(self):
        entry = ResourceMapEntry(
            resource_id="x", name="svc", mcp_url="http://localhost", protocol="a2a"
        )
        assert entry.protocol == "a2a"

    def test_http_url(self):
        entry = ResourceMapEntry(
            resource_id="x", name="dev", mcp_url="http://dev.local:8080/mcp"
        )
        assert entry.mcp_url.startswith("http://")

    def test_https_url(self):
        entry = ResourceMapEntry(
            resource_id="x", name="prod", mcp_url="https://prod.example.com/mcp"
        )
        assert entry.mcp_url.startswith("https://")

    def test_long_slug(self):
        name = "a" + "b" * 98 + "c"  # 100 chars
        entry = ResourceMapEntry(
            resource_id="x", name=name, mcp_url="http://localhost"
        )
        assert len(entry.name) == 100

    def test_slug_with_numbers(self):
        entry = ResourceMapEntry(
            resource_id="x", name="svc2", mcp_url="http://localhost"
        )
        assert entry.name == "svc2"

    def test_slug_with_hyphens(self):
        entry = ResourceMapEntry(
            resource_id="x", name="my-cool-service", mcp_url="http://localhost"
        )
        assert entry.name == "my-cool-service"


# ============================================================================
# ResourceMapEntry — invalid inputs
# ============================================================================

class TestResourceMapEntryInvalid:

    def test_empty_name(self):
        with pytest.raises(ValueError, match="name must be"):
            ResourceMapEntry(resource_id="x", name="", mcp_url="http://localhost")

    def test_name_starts_with_number(self):
        with pytest.raises(ValueError, match="slug"):
            ResourceMapEntry(resource_id="x", name="1bad", mcp_url="http://localhost")

    def test_name_starts_with_hyphen(self):
        with pytest.raises(ValueError, match="slug"):
            ResourceMapEntry(resource_id="x", name="-bad", mcp_url="http://localhost")

    def test_name_ends_with_hyphen(self):
        with pytest.raises(ValueError, match="slug"):
            ResourceMapEntry(resource_id="x", name="bad-", mcp_url="http://localhost")

    def test_name_uppercase(self):
        with pytest.raises(ValueError, match="slug"):
            ResourceMapEntry(resource_id="x", name="Bad", mcp_url="http://localhost")

    def test_name_with_spaces(self):
        with pytest.raises(ValueError, match="slug"):
            ResourceMapEntry(resource_id="x", name="bad name", mcp_url="http://localhost")

    def test_name_too_long(self):
        with pytest.raises(ValueError, match="name must be"):
            ResourceMapEntry(
                resource_id="x", name="a" * 101, mcp_url="http://localhost"
            )

    def test_url_no_scheme(self):
        with pytest.raises(ValueError, match="mcp_url must start with"):
            ResourceMapEntry(resource_id="x", name="svc", mcp_url="ftp://bad.example.com")

    def test_url_bare_hostname(self):
        with pytest.raises(ValueError, match="mcp_url must start with"):
            ResourceMapEntry(resource_id="x", name="svc", mcp_url="example.com")

    def test_invalid_protocol(self):
        with pytest.raises(ValueError, match="protocol must be"):
            ResourceMapEntry(
                resource_id="x", name="svc", mcp_url="http://localhost", protocol="grpc"
            )


# ============================================================================
# ResolvedResource — auth_method auto-derivation
# ============================================================================

class TestResolvedResource:

    def test_identity_assertion_derives_okta_cross_app(self):
        rb = ResolvedResource(
            resource_id="r1", name="svc", mcp_url="http://localhost",
            connection_id="conn1",
            connection_type=OktaConnectionType.IDENTITY_ASSERTION_CUSTOM_AS,
        )
        assert rb.auth_method == "okta-cross-app"

    def test_sts_vault_secret_derives_vault_secret(self):
        rb = ResolvedResource(
            resource_id="r1", name="svc", mcp_url="http://localhost",
            connection_id="conn1",
            connection_type=OktaConnectionType.STS_VAULT_SECRET,
        )
        assert rb.auth_method == "vault-secret"

    def test_sts_service_account_derives_sts_service_account(self):
        rb = ResolvedResource(
            resource_id="r1", name="svc", mcp_url="http://localhost",
            connection_id="conn1",
            connection_type=OktaConnectionType.STS_SERVICE_ACCOUNT,
        )
        assert rb.auth_method == "sts-service-account"

    def test_legacy_secret_derives_vault_secret(self):
        rb = ResolvedResource(
            resource_id="r1", name="svc", mcp_url="http://localhost",
            connection_id="conn1",
            connection_type=OktaConnectionType.SECRET,
        )
        assert rb.auth_method == "vault-secret"

    def test_legacy_service_account_derives_sts_service_account(self):
        rb = ResolvedResource(
            resource_id="r1", name="svc", mcp_url="http://localhost",
            connection_id="conn1",
            connection_type=OktaConnectionType.SERVICE_ACCOUNT,
        )
        assert rb.auth_method == "sts-service-account"

    def test_explicit_auth_method_preserved(self):
        rb = ResolvedResource(
            resource_id="r1", name="svc", mcp_url="http://localhost",
            connection_id="conn1",
            connection_type=OktaConnectionType.SECRET,
            auth_method="custom-method",
        )
        assert rb.auth_method == "custom-method"

    def test_scopes_default_empty(self):
        rb = ResolvedResource(
            resource_id="r1", name="svc", mcp_url="http://localhost",
            connection_id="conn1",
            connection_type=OktaConnectionType.SECRET,
        )
        assert rb.scopes == []

    def test_scope_condition_default(self):
        rb = ResolvedResource(
            resource_id="r1", name="svc", mcp_url="http://localhost",
            connection_id="conn1",
            connection_type=OktaConnectionType.SECRET,
        )
        assert rb.scope_condition == OktaScopeCondition.ALLOW_ALL

    def test_string_connection_type_in_dict(self):
        rb = ResolvedResource(
            resource_id="r1", name="svc", mcp_url="http://localhost",
            connection_id="conn1",
            connection_type="SECRET",
        )
        assert rb.auth_method == "vault-secret"
        assert rb.connection_type == OktaConnectionType.SECRET

    def test_string_sts_vault_secret_in_dict(self):
        rb = ResolvedResource(
            resource_id="r1", name="svc", mcp_url="http://localhost",
            connection_id="conn1",
            connection_type="STS_VAULT_SECRET",
        )
        assert rb.auth_method == "vault-secret"
        assert rb.connection_type == OktaConnectionType.STS_VAULT_SECRET


# ============================================================================
# SyncResult
# ============================================================================

class TestSyncResult:

    def test_basic_creation(self):
        sr = SyncResult(
            added=["a"], removed=["b"], modified=["c"],
            unresolved=["d"], total=4, synced_at=datetime.utcnow(),
        )
        assert sr.total == 4
        assert len(sr.added) == 1

    def test_empty_sync(self):
        sr = SyncResult(total=0, synced_at=datetime.utcnow())
        assert sr.added == []
        assert sr.removed == []
        assert sr.modified == []
        assert sr.unresolved == []


# ============================================================================
# OktaConnectionType / OktaScopeCondition enums
# ============================================================================

class TestEnums:

    def test_connection_type_values(self):
        assert OktaConnectionType.IDENTITY_ASSERTION_CUSTOM_AS.value == "IDENTITY_ASSERTION_CUSTOM_AS"
        assert OktaConnectionType.STS_VAULT_SECRET.value == "STS_VAULT_SECRET"
        assert OktaConnectionType.STS_SERVICE_ACCOUNT.value == "STS_SERVICE_ACCOUNT"
        # Legacy aliases
        assert OktaConnectionType.SECRET.value == "SECRET"
        assert OktaConnectionType.SERVICE_ACCOUNT.value == "SERVICE_ACCOUNT"

    def test_new_enum_parses_from_string(self):
        assert OktaConnectionType("STS_VAULT_SECRET") == OktaConnectionType.STS_VAULT_SECRET
        assert OktaConnectionType("STS_SERVICE_ACCOUNT") == OktaConnectionType.STS_SERVICE_ACCOUNT

    def test_scope_condition_values(self):
        assert OktaScopeCondition.INCLUDE_ONLY.value == "INCLUDE_ONLY"
        assert OktaScopeCondition.DISALLOW.value == "DISALLOW"
        assert OktaScopeCondition.ALLOW_ALL.value == "ALLOW_ALL"


# ============================================================================
# ResourceMapStore — CRUD
# ============================================================================

class TestResourceMapStoreCRUD:

    def test_create_and_load(self, rm_store, sample_entry):
        rm_store.create(sample_entry)
        count = rm_store.load_cache()
        assert count == 1

    def test_get_by_id(self, rm_store, sample_entry):
        rm_store.create(sample_entry)
        rm_store.load_cache()
        result = rm_store.get_by_id("aus1234567890")
        assert len(result) == 1
        assert result[0].name == "hr-system"

    def test_get_by_name(self, rm_store, sample_entry):
        rm_store.create(sample_entry)
        rm_store.load_cache()
        result = rm_store.get_by_name("hr-system")
        assert result is not None
        assert result.resource_id == "aus1234567890"

    def test_get_all(self, rm_store, sample_entry, sample_entry_b):
        rm_store.create(sample_entry)
        rm_store.create(sample_entry_b)
        rm_store.load_cache()
        all_entries = rm_store.get_all()
        assert len(all_entries) == 2

    def test_update(self, rm_store, sample_entry):
        rm_store.create(sample_entry)
        updated = rm_store.update("aus1234567890", {"description": "Updated HR"})
        assert updated is not None
        assert updated.description == "Updated HR"

    def test_update_nonexistent(self, rm_store):
        result = rm_store.update("nonexistent", {"description": "nope"})
        assert result is None

    def test_delete(self, rm_store, sample_entry):
        rm_store.create(sample_entry)
        assert rm_store.delete("aus1234567890") is True

    def test_delete_nonexistent(self, rm_store):
        assert rm_store.delete("nonexistent") is False

    def test_delete_by_name(self, rm_store, sample_entry, sample_entry_b):
        """delete_by_name removes a single entry by its unique name."""
        rm_store.create(sample_entry)
        rm_store.create(sample_entry_b)
        assert rm_store.delete_by_name("hr-system") is True
        rm_store.load_cache()
        assert rm_store.get_by_name("hr-system") is None
        assert rm_store.get_by_name("finance-api") is not None

    def test_delete_by_name_nonexistent(self, rm_store):
        assert rm_store.delete_by_name("nonexistent") is False

    def test_create_updates_db_not_cache(self, rm_store, sample_entry):
        """Create writes to DB but doesn't auto-refresh cache."""
        rm_store.create(sample_entry)
        # Cache not loaded yet
        assert rm_store.get_by_id("aus1234567890") == []
        # After load, it's there
        rm_store.load_cache()
        assert len(rm_store.get_by_id("aus1234567890")) == 1


# ============================================================================
# ResourceMapStore — L1 cache behavior
# ============================================================================

class TestResourceMapStoreCache:

    def test_empty_cache_on_init(self, rm_store):
        assert rm_store.get_all() == []
        assert rm_store.get_by_id("anything") == []
        assert rm_store.get_by_name("anything") is None

    def test_load_cache_sets_last_loaded(self, rm_store):
        assert rm_store._last_loaded is None
        rm_store.load_cache()
        assert rm_store._last_loaded is not None

    def test_load_cache_refreshes(self, rm_store, sample_entry, sample_entry_b):
        rm_store.create(sample_entry)
        rm_store.load_cache()
        assert len(rm_store.get_all()) == 1

        rm_store.create(sample_entry_b)
        rm_store.load_cache()
        assert len(rm_store.get_all()) == 2

    def test_cache_survives_without_reload(self, rm_store, sample_entry):
        rm_store.create(sample_entry)
        rm_store.load_cache()
        # Delete from DB
        rm_store.delete("aus1234567890")
        # Cache still has it (stale until reload)
        assert len(rm_store.get_by_id("aus1234567890")) == 1
        # After reload, gone
        rm_store.load_cache()
        assert rm_store.get_by_id("aus1234567890") == []


# ============================================================================
# ResourceMapStore — unique constraint enforcement
# ============================================================================

class TestResourceMapStoreUnique:

    def test_same_resource_id_different_name_allowed(self, rm_store, sample_entry):
        """One resource_id can map to multiple resources with different names."""
        rm_store.create(sample_entry)
        second = ResourceMapEntry(
            resource_id="aus1234567890",  # same resource_id
            name="hr-system-v2",
            mcp_url="https://hr-v2.example.com/mcp",
        )
        rm_store.create(second)
        rm_store.load_cache()
        entries = rm_store.get_by_id("aus1234567890")
        assert len(entries) == 2
        names = {e.name for e in entries}
        assert names == {"hr-system", "hr-system-v2"}

    def test_duplicate_resource_id_and_name(self, rm_store, sample_entry):
        """Same (resource_id, name) pair is rejected."""
        rm_store.create(sample_entry)
        dupe = ResourceMapEntry(
            resource_id="aus1234567890",
            name="hr-system",  # same resource_id AND name
            mcp_url="http://other.example.com",
        )
        with pytest.raises(IntegrityError):
            rm_store.create(dupe)

    def test_duplicate_name(self, rm_store, sample_entry):
        rm_store.create(sample_entry)
        dupe = ResourceMapEntry(
            resource_id="different-id",
            name="hr-system",  # same name
            mcp_url="http://other.example.com",
        )
        with pytest.raises(IntegrityError):
            rm_store.create(dupe)


# ============================================================================
# OktaSyncStateModel — save and retrieve
# ============================================================================

class TestOktaSyncState:

    def test_save_and_get(self, rm_store):
        rm_store.save_sync_state(
            status="success", resources_count=5,
            unresolved_count=1, duration_ms=250,
        )
        state = rm_store.get_latest_sync_state()
        assert state is not None
        assert state["status"] == "success"
        assert state["resources_count"] == 5
        assert state["unresolved_count"] == 1
        assert state["sync_duration_ms"] == 250
        assert state["last_sync_at"] is not None

    def test_get_latest_returns_most_recent(self, rm_store):
        rm_store.save_sync_state("first", 1, 0, 100)
        rm_store.save_sync_state("second", 2, 0, 200)
        state = rm_store.get_latest_sync_state()
        assert state["status"] == "second"
        assert state["resources_count"] == 2

    def test_no_sync_state_returns_none(self, rm_store):
        assert rm_store.get_latest_sync_state() is None


# ============================================================================
# Empty table on startup
# ============================================================================

class TestEmptyStartup:

    def test_adapter_starts_with_zero_resources(self, rm_store):
        """On first deploy, resource_map is empty."""
        count = rm_store.load_cache()
        assert count == 0
        assert rm_store.get_all() == []

    def test_admin_adds_entries_via_api(self, rm_store):
        """Admin creates entries; after cache reload they are visible."""
        assert rm_store.load_cache() == 0
        entry = ResourceMapEntry(
            resource_id="aus-new", name="new-svc",
            mcp_url="https://new.example.com/mcp",
        )
        rm_store.create(entry)
        assert rm_store.load_cache() == 1
        assert rm_store.get_by_name("new-svc") is not None


# ============================================================================
# resourceIndicator extraction
# ============================================================================

class TestResourceIndicatorExtraction:

    def test_xaa_resource_indicator(self):
        from okta_agent_proxy.resources.utils import extract_resource_id
        conn = {
            "type": "IDENTITY_ASSERTION_CUSTOM_AS",
            "resourceIndicator": "orn:okta:idp:00oabc:authorization_servers:aus5rb5mt2H3d1TJd0h7",
        }
        result = extract_resource_id(conn, OktaConnectionType.IDENTITY_ASSERTION_CUSTOM_AS)
        assert result == "aus5rb5mt2H3d1TJd0h7"

    def test_sts_vault_secret_resource_indicator(self):
        from okta_agent_proxy.resources.utils import extract_resource_id
        conn = {
            "type": "STS_VAULT_SECRET",
            "resourceIndicator": "orn:okta:pam:00oabc:secrets:d2642f68-df50-4ba8-a898-6c0f82f89d8a",
        }
        result = extract_resource_id(conn, OktaConnectionType.STS_VAULT_SECRET)
        assert result == "d2642f68-df50-4ba8-a898-6c0f82f89d8a"

    def test_sts_service_account_resource_indicator(self):
        from okta_agent_proxy.resources.utils import extract_resource_id
        conn = {
            "type": "STS_SERVICE_ACCOUNT",
            "resourceIndicator": "orn:okta:pam:00oabc:apps:slack:0oa123:service_accounts:4923897d-c665-488a-9480-a415b4080861",
        }
        result = extract_resource_id(conn, OktaConnectionType.STS_SERVICE_ACCOUNT)
        assert result == "4923897d-c665-488a-9480-a415b4080861"

    def test_legacy_secret_resource_indicator(self):
        from okta_agent_proxy.resources.utils import extract_resource_id
        conn = {
            "type": "SECRET",
            "resourceIndicator": "orn:okta:pam:00oabc:secrets:abcd-1234",
        }
        result = extract_resource_id(conn, OktaConnectionType.SECRET)
        assert result == "abcd-1234"

    def test_legacy_service_account_resource_indicator(self):
        from okta_agent_proxy.resources.utils import extract_resource_id
        conn = {
            "type": "SERVICE_ACCOUNT",
            "resourceIndicator": "orn:okta:pam:00oabc:apps:myapp:0oa:service_accounts:sa-uuid-1234",
        }
        result = extract_resource_id(conn, OktaConnectionType.SERVICE_ACCOUNT)
        assert result == "sa-uuid-1234"

    def test_fallback_when_no_resource_indicator_xaa(self):
        """Falls back to authorizationServer.orn when resourceIndicator absent."""
        from okta_agent_proxy.resources.utils import extract_resource_id
        conn = {
            "type": "IDENTITY_ASSERTION_CUSTOM_AS",
            "authorizationServer": {
                "orn": "orn:oktapreview:idp:00oabc:authorization_servers:ausOLD123"
            },
        }
        result = extract_resource_id(conn, OktaConnectionType.IDENTITY_ASSERTION_CUSTOM_AS)
        assert result == "ausOLD123"

    def test_fallback_when_no_resource_indicator_secret(self):
        """Falls back to secretId when resourceIndicator absent."""
        from okta_agent_proxy.resources.utils import extract_resource_id
        conn = {"type": "STS_VAULT_SECRET", "secretId": "sec-fallback"}
        result = extract_resource_id(conn, OktaConnectionType.STS_VAULT_SECRET)
        assert result == "sec-fallback"

    def test_fallback_when_no_resource_indicator_service_account(self):
        """Falls back to serviceAccountId when resourceIndicator absent."""
        from okta_agent_proxy.resources.utils import extract_resource_id
        conn = {"type": "STS_SERVICE_ACCOUNT", "serviceAccountId": "sa-fallback"}
        result = extract_resource_id(conn, OktaConnectionType.STS_SERVICE_ACCOUNT)
        assert result == "sa-fallback"

    def test_resource_indicator_takes_precedence_over_legacy(self):
        """resourceIndicator wins even when legacy fields are also present."""
        from okta_agent_proxy.resources.utils import extract_resource_id
        conn = {
            "type": "IDENTITY_ASSERTION_CUSTOM_AS",
            "resourceIndicator": "orn:okta:idp:00o:authorization_servers:ausNEW",
            "authorizationServer": {"orn": "orn:okta:idp:00o:authorization_servers:ausOLD"},
        }
        result = extract_resource_id(conn, OktaConnectionType.IDENTITY_ASSERTION_CUSTOM_AS)
        assert result == "ausNEW"

    def test_extract_resource_id_from_connection_convenience(self):
        """extract_resource_id_from_connection combines type parsing + extraction."""
        from okta_agent_proxy.resources.utils import extract_resource_id_from_connection
        conn = {
            "type": "IDENTITY_ASSERTION_CUSTOM_AS",
            "resourceIndicator": "orn:okta:idp:00o:authorization_servers:aus123",
        }
        resource_id, conn_type = extract_resource_id_from_connection(conn)
        assert resource_id == "aus123"
        assert conn_type == OktaConnectionType.IDENTITY_ASSERTION_CUSTOM_AS

    def test_extract_resource_id_from_connection_unknown_type(self):
        from okta_agent_proxy.resources.utils import extract_resource_id_from_connection
        conn = {"type": "UNKNOWN_TYPE"}
        resource_id, conn_type = extract_resource_id_from_connection(conn)
        assert resource_id is None
        assert conn_type is None


# ============================================================================
# Syncer _merge_connections — one connection to multiple resources
# ============================================================================

class TestSyncerMergeOneToMany:

    def test_one_connection_resolves_to_multiple_resources(self, rm_store):
        """One Okta connection → multiple resource_map entries → multiple ResolvedResources."""
        from okta_agent_proxy.resources.syncer import OktaConnectionSyncer
        from unittest.mock import MagicMock

        # Create two entries with the same resource_id
        rm_store.create(ResourceMapEntry(
            resource_id="aus5rb5mt2H3d1TJd0h7",
            name="hr-employees",
            mcp_url="https://hr.example.com/employees/mcp",
        ))
        rm_store.create(ResourceMapEntry(
            resource_id="aus5rb5mt2H3d1TJd0h7",
            name="hr-payroll",
            mcp_url="https://hr.example.com/payroll/mcp",
        ))
        rm_store.load_cache()

        event_bus = MagicMock()
        syncer = OktaConnectionSyncer(
            okta_domain="https://test.okta.com",
            api_token="test-token",
            resource_map_store=rm_store,
            event_bus=event_bus,
        )

        connections = [{
            "id": "conn-001",
            "type": "IDENTITY_ASSERTION_CUSTOM_AS",
            "status": "ACTIVE",
            "resourceIndicator": "orn:okta:idp:00o:authorization_servers:aus5rb5mt2H3d1TJd0h7",
            "scopes": ["read", "write"],
        }]

        resolved, unresolved = syncer._merge_connections(connections)

        assert len(resolved) == 2
        assert "hr-employees" in resolved
        assert "hr-payroll" in resolved
        assert resolved["hr-employees"].connection_id == "conn-001"
        assert resolved["hr-payroll"].connection_id == "conn-001"
        assert resolved["hr-employees"].mcp_url == "https://hr.example.com/employees/mcp"
        assert resolved["hr-payroll"].mcp_url == "https://hr.example.com/payroll/mcp"
        assert resolved["hr-employees"].auth_method == "okta-cross-app"
        assert unresolved == []

    def test_unresolved_when_no_resource_map_entry(self, rm_store):
        """Connection with no matching resource_map entry is unresolved."""
        from okta_agent_proxy.resources.syncer import OktaConnectionSyncer
        from unittest.mock import MagicMock

        rm_store.load_cache()

        event_bus = MagicMock()
        syncer = OktaConnectionSyncer(
            okta_domain="https://test.okta.com",
            api_token="test-token",
            resource_map_store=rm_store,
            event_bus=event_bus,
        )

        connections = [{
            "id": "conn-002",
            "type": "IDENTITY_ASSERTION_CUSTOM_AS",
            "status": "ACTIVE",
            "resourceIndicator": "orn:okta:idp:00o:authorization_servers:ausNONEXISTENT",
        }]

        resolved, unresolved = syncer._merge_connections(connections)
        assert len(resolved) == 0
        assert "ausNONEXISTENT" in unresolved

    def test_sts_vault_secret_connection_resolves(self, rm_store):
        """STS_VAULT_SECRET connection resolves via resourceIndicator."""
        from okta_agent_proxy.resources.syncer import OktaConnectionSyncer
        from unittest.mock import MagicMock

        rm_store.create(ResourceMapEntry(
            resource_id="d2642f68-df50-4ba8-a898-6c0f82f89d8a",
            name="vault-secret",
            mcp_url="https://vault.example.com/mcp",
        ))
        rm_store.load_cache()

        event_bus = MagicMock()
        syncer = OktaConnectionSyncer(
            okta_domain="https://test.okta.com",
            api_token="test-token",
            resource_map_store=rm_store,
            event_bus=event_bus,
        )

        connections = [{
            "id": "conn-003",
            "type": "STS_VAULT_SECRET",
            "status": "ACTIVE",
            "resourceIndicator": "orn:okta:pam:00o:secrets:d2642f68-df50-4ba8-a898-6c0f82f89d8a",
        }]

        resolved, unresolved = syncer._merge_connections(connections)
        assert len(resolved) == 1
        assert "vault-secret" in resolved
        assert resolved["vault-secret"].auth_method == "vault-secret"
        assert resolved["vault-secret"].connection_type == OktaConnectionType.STS_VAULT_SECRET
