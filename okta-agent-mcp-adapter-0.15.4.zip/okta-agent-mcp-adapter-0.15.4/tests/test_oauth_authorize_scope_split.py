"""Unit tests for the OIDC / custom scope splitter in oauth_authorize.

Custom scopes (e.g. `bedrock:InvokeAgent`) discovered via RFC 9728 must be
peeled off the client's scope request BEFORE it reaches Okta's org
authorization server, which rejects anything outside the OIDC set with
`invalid_scope`. The splitter in app.py is the seam that makes this safe.
"""

import sys
from unittest.mock import MagicMock

import pytest


def _ensure_app_imported():
    """Mirror the pattern from tests/test_oauth_discovery.py."""
    mod = sys.modules.get("okta_agent_proxy.app")
    if mod is not None and hasattr(mod, "_split_oidc_custom_scopes"):
        return

    sys.modules.pop("okta_agent_proxy.app", None)

    import okta_agent_proxy.database as _db_mod
    _orig_get = _db_mod.get_config_store
    _orig_store = _db_mod._config_store
    _mock_store = MagicMock()
    _mock_store.get_all_resources.return_value = []
    _mock_store.get_all_agents.return_value = []
    _db_mod.get_config_store = lambda **kw: _mock_store
    _db_mod._config_store = _mock_store
    try:
        import importlib
        import okta_agent_proxy.app
        importlib.reload(okta_agent_proxy.app)
    finally:
        _db_mod.get_config_store = _orig_get
        _db_mod._config_store = _orig_store


@pytest.fixture(autouse=True)
def _app_ready():
    _ensure_app_imported()


def _split(scope_str):
    from okta_agent_proxy.app import _split_oidc_custom_scopes
    return _split_oidc_custom_scopes(scope_str)


class TestSplitOidcCustomScopes:

    def test_pure_oidc_passes_through(self):
        oidc, custom = _split("openid offline_access")
        assert oidc == "openid offline_access"
        assert custom == []

    def test_pure_custom_extracted(self):
        oidc, custom = _split("bedrock:InvokeAgent repo:read")
        # openid is auto-prepended so Okta login still works
        assert "openid" in oidc.split()
        assert custom == ["bedrock:InvokeAgent", "repo:read"]

    def test_mixed_partitions_correctly(self):
        oidc, custom = _split("openid offline_access bedrock:InvokeAgent")
        assert set(oidc.split()) == {"openid", "offline_access"}
        assert custom == ["bedrock:InvokeAgent"]

    def test_empty_string_yields_default_openid(self):
        oidc, custom = _split("")
        assert oidc == "openid"
        assert custom == []

    def test_none_yields_default_openid(self):
        oidc, custom = _split(None)
        assert oidc == "openid"
        assert custom == []

    def test_ordering_preserves_custom_request_order(self):
        oidc, custom = _split("openid bedrock:A repo:B bedrock:C")
        assert custom == ["bedrock:A", "repo:B", "bedrock:C"]

    def test_openid_always_present_even_if_not_requested(self):
        # Client only asked for custom scopes — adapter still injects openid
        # so the Okta leg has a valid OIDC login request.
        oidc, _ = _split("bedrock:InvokeAgent")
        assert "openid" in oidc.split()

    def test_all_oidc_scopes_recognized(self):
        # Full OIDC set per the hoisted _OIDC_SCOPES constant.
        oidc, custom = _split("openid profile email address phone offline_access")
        assert set(oidc.split()) == {
            "openid", "profile", "email", "address", "phone", "offline_access"
        }
        assert custom == []

    def test_duplicate_oidc_scopes_deduped_via_openid_guard(self):
        # Not a formal dedup of all tokens, but openid is guaranteed-once.
        oidc, _ = _split("openid openid")
        assert oidc.count("openid") >= 1  # at least present

    def test_custom_scope_with_colon_preserved_verbatim(self):
        # Okta/AgentCore use `ns:verb` style. Must not be mangled.
        _, custom = _split("openid urn:aws:iam::123:role/MyRole")
        assert custom == ["urn:aws:iam::123:role/MyRole"]

    def test_vscode_wildcard_dropped(self):
        # VS Code sends `scope=*` meaning "all". `*` is not a real Okta scope;
        # we drop it so downstream ID-JAG legs don't send it.
        oidc, custom = _split("* offline_access openid")
        assert "*" not in oidc
        assert "*" not in custom
        assert "openid" in oidc
        assert "offline_access" in oidc

    def test_wildcard_alone_still_yields_openid_default(self):
        oidc, custom = _split("*")
        assert "openid" in oidc
        assert custom == []
