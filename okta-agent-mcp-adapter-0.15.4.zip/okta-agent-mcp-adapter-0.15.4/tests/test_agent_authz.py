"""
Tests for agent authorization and extraction.

Tests agent permission checking, authorization errors, and middleware.
"""

import logging
import sys
import pytest
import json
from unittest.mock import MagicMock, patch, AsyncMock

import types

# Pre-mock okta_agent_proxy.app to prevent database initialization on import.
# The real module triggers PostgreSQL connections at import time.
if "okta_agent_proxy.app" not in sys.modules:
    _mock_app_module = types.ModuleType("okta_agent_proxy.app")
    _mock_app_module.get_resource_syncer = MagicMock(return_value=None)
    _mock_app_module.get_resource_store = MagicMock(return_value=None)
    sys.modules["okta_agent_proxy.app"] = _mock_app_module

from okta_agent_proxy.auth.agent_authz import (
    check_agent_can_access_resource,
    create_authorization_error_response,
    create_missing_agent_error_response,
    create_invalid_agent_header_response,
    AgentAuthorizationError,
    AgentAuthorizationChecker
)
from okta_agent_proxy.middleware.agent_extractor import (
    AgentExtractor,
    extract_agent_id_from_headers,
)


@pytest.fixture
def agent_config():
    """Sample agent configuration."""
    return {
        "agent_id": "cursor",
        "client_id": "0oa_cursor",
        "private_key": "-----BEGIN PRIVATE KEY-----\nkey\n-----END PRIVATE KEY-----",
    }


@pytest.fixture
def mock_syncer_with_resource():
    """Mock syncer that resolves a resource."""
    syncer = MagicMock()
    resolved = MagicMock()
    resolved.connection_id = "conn-123"
    syncer.get_resource.return_value = resolved
    return syncer


@pytest.fixture
def mock_syncer_without_resource():
    """Mock syncer that does NOT resolve a resource."""
    syncer = MagicMock()
    syncer.get_resource.return_value = None
    return syncer


@pytest.fixture
def mock_resource_store_with_entry():
    """Mock resource store that has the requested entry."""
    store = MagicMock()
    entry = MagicMock()
    entry.resource_id = "res-001"
    store.get_by_name.return_value = entry
    return store


@pytest.fixture
def mock_resource_store_without_entry():
    """Mock resource store that does NOT have the requested entry."""
    store = MagicMock()
    store.get_by_name.return_value = None
    return store


@pytest.fixture
def postgres_store_with_agents(postgres_store):
    """Create a PostgreSQL store with test agents for authorization tests."""
    cursor_data = {
        "agent_id": "cursor",
        "client_id": "0oa_cursor",
        "private_key": json.dumps({"kty": "RSA", "n": "cursor_n", "e": "AQAB"}),
        "scopes": [],
        "enabled": True
    }
    postgres_store.create_agent("cursor", cursor_data, user="test-fixture")

    claude_data = {
        "agent_id": "claude-code",
        "client_id": "0oa_claude",
        "private_key": json.dumps({"kty": "RSA", "n": "claude_n", "e": "AQAB"}),
        "scopes": [],
        "enabled": True
    }
    postgres_store.create_agent("claude-code", claude_data, user="test-fixture")

    return postgres_store


class TestAgentResourceAccess:
    """Test agent resource access checks (async, syncer/store based)."""

    @pytest.mark.asyncio
    async def test_agent_can_access_resource_via_syncer(self, agent_config, mock_syncer_with_resource):
        """Test agent authorized when syncer resolves the resource."""
        with patch("okta_agent_proxy.app.get_resource_syncer", return_value=mock_syncer_with_resource), \
             patch("okta_agent_proxy.auth.agent_authz.emit_audit_event", new_callable=AsyncMock):
            result = await check_agent_can_access_resource("cursor", agent_config, "employees")
            assert result is True

    @pytest.mark.asyncio
    async def test_agent_can_access_resource_via_store(
        self, agent_config, mock_syncer_without_resource, mock_resource_store_with_entry
    ):
        """Test agent authorized when resource store has entry."""
        with patch("okta_agent_proxy.app.get_resource_syncer", return_value=mock_syncer_without_resource), \
             patch("okta_agent_proxy.app.get_resource_store", return_value=mock_resource_store_with_entry), \
             patch("okta_agent_proxy.auth.agent_authz.emit_audit_event", new_callable=AsyncMock):
            result = await check_agent_can_access_resource("cursor", agent_config, "employees")
            assert result is True

    @pytest.mark.asyncio
    async def test_agent_cannot_access_resource(
        self, agent_config, mock_syncer_without_resource, mock_resource_store_without_entry
    ):
        """Test agent denied when neither syncer nor store has the resource."""
        with patch("okta_agent_proxy.app.get_resource_syncer", return_value=mock_syncer_without_resource), \
             patch("okta_agent_proxy.app.get_resource_store", return_value=mock_resource_store_without_entry), \
             patch("okta_agent_proxy.auth.agent_authz.emit_audit_event", new_callable=AsyncMock):
            with pytest.raises(AgentAuthorizationError) as exc_info:
                await check_agent_can_access_resource("cursor", agent_config, "hr")

            error = exc_info.value
            assert error.agent_id == "cursor"
            assert "Not authorized" in error.reason
            assert error.details["resource_requested"] == "hr"

    @pytest.mark.asyncio
    async def test_agent_with_no_config(self):
        """Test error when agent config is None."""
        with patch("okta_agent_proxy.auth.agent_authz.emit_audit_event", new_callable=AsyncMock):
            with pytest.raises(AgentAuthorizationError) as exc_info:
                await check_agent_can_access_resource("unknown", None, "employees")

            assert exc_info.value.agent_id == "unknown"


class TestErrorResponses:
    """Test error response generation."""

    @pytest.mark.asyncio
    async def test_authorization_error_response(self, agent_config, mock_syncer_without_resource, mock_resource_store_without_entry):
        """Test authorization error response format."""
        with patch("okta_agent_proxy.app.get_resource_syncer", return_value=mock_syncer_without_resource), \
             patch("okta_agent_proxy.app.get_resource_store", return_value=mock_resource_store_without_entry), \
             patch("okta_agent_proxy.auth.agent_authz.emit_audit_event", new_callable=AsyncMock):
            try:
                await check_agent_can_access_resource("cursor", agent_config, "denied")
            except AgentAuthorizationError as e:
                response = create_authorization_error_response(e)

        assert response["error"] == "authorization_denied"
        assert "agent_id" in response
        assert response["agent_id"] == "cursor"
        assert "details" in response

    def test_missing_agent_error_response(self):
        """Test missing agent error response."""
        response = create_missing_agent_error_response("Agent 'unknown' not found")

        assert response["error"] == "agent_not_found"
        assert "unknown" in response["message"]

    def test_invalid_agent_header_response(self):
        """Test invalid agent header response."""
        response = create_invalid_agent_header_response()

        assert response["error"] == "agent_header_missing"
        assert "X-Agent-ID" in response["message"]


class TestAgentExtractor:
    """Test agent extraction from headers."""

    def test_extract_agent_id_from_headers(self):
        """Test extracting agent ID from headers."""
        headers = {
            "Authorization": "Bearer token",
            "X-Agent-ID": "cursor"
        }

        agent_id = extract_agent_id_from_headers(headers)
        assert agent_id == "cursor"

    def test_extract_agent_id_case_insensitive(self):
        """Test agent ID extraction is case-insensitive."""
        headers = {
            "x-agent-id": "cursor",
            "Authorization": "Bearer token"
        }

        agent_id = extract_agent_id_from_headers(headers)
        assert agent_id == "cursor"

    def test_extract_agent_id_missing(self):
        """Test missing agent ID header."""
        headers = {
            "Authorization": "Bearer token"
        }

        agent_id = extract_agent_id_from_headers(headers)
        assert agent_id is None

    def test_agent_extractor_from_store(self, postgres_store_with_agents):
        """Test AgentExtractor with real store."""
        store = postgres_store_with_agents
        extractor = AgentExtractor(store)

        headers = {
            "X-Agent-ID": "cursor",
            "Authorization": "Bearer token"
        }

        agent_id, agent_config = extractor.extract_agent_from_headers(headers)

        assert agent_id == "cursor"
        assert agent_config is not None
        assert agent_config["client_id"] == "0oa_cursor"

    def test_agent_extractor_disabled_agent(self, postgres_store_with_agents):
        """Test extractor with disabled agent."""
        store = postgres_store_with_agents
        store.disable_agent("cursor")

        extractor = AgentExtractor(store)

        headers = {"X-Agent-ID": "cursor"}
        agent_id, agent_config = extractor.extract_agent_from_headers(headers)

        assert agent_id == "cursor"
        assert agent_config is None  # Disabled

    def test_agent_extractor_missing_agent(self, postgres_store_with_agents):
        """Test extractor with non-existent agent."""
        store = postgres_store_with_agents
        extractor = AgentExtractor(store)

        headers = {"X-Agent-ID": "nonexistent"}
        agent_id, agent_config = extractor.extract_agent_from_headers(headers)

        assert agent_id == "nonexistent"
        assert agent_config is None

    def test_get_agent_resource_access(self, postgres_store_with_agents):
        """Test getting agent's resource access list."""
        store = postgres_store_with_agents
        extractor = AgentExtractor(store)

        resources = extractor.get_agent_resource_access("cursor")
        assert isinstance(resources, list)

        resources = extractor.get_agent_resource_access("claude-code")
        assert isinstance(resources, list)


class TestAuthorizationChecker:
    """Test AgentAuthorizationChecker for chaining."""

    @pytest.mark.asyncio
    async def test_checker_resource_access(self, agent_config, mock_syncer_with_resource):
        """Test checker for resource access."""
        with patch("okta_agent_proxy.app.get_resource_syncer", return_value=mock_syncer_with_resource), \
             patch("okta_agent_proxy.auth.agent_authz.emit_audit_event", new_callable=AsyncMock):
            checker = AgentAuthorizationChecker("cursor", agent_config)

            # Should succeed
            result = await checker.check_resource_access("employees")
            assert result is checker  # Returns self for chaining

    @pytest.mark.asyncio
    async def test_checker_resource_access_denied(
        self, agent_config, mock_syncer_without_resource, mock_resource_store_without_entry
    ):
        """Test checker denies unauthorized resource."""
        with patch("okta_agent_proxy.app.get_resource_syncer", return_value=mock_syncer_without_resource), \
             patch("okta_agent_proxy.app.get_resource_store", return_value=mock_resource_store_without_entry), \
             patch("okta_agent_proxy.auth.agent_authz.emit_audit_event", new_callable=AsyncMock):
            checker = AgentAuthorizationChecker("cursor", agent_config)

            with pytest.raises(AgentAuthorizationError):
                await checker.check_resource_access("denied")

    @pytest.mark.asyncio
    async def test_checker_chaining_fails(
        self, agent_config, mock_syncer_with_resource, mock_resource_store_without_entry
    ):
        """Test checker chaining stops on first error."""
        # syncer resolves "employees" but not "denied"
        def selective_resolve(name):
            if name == "employees":
                m = MagicMock()
                m.connection_id = "conn-123"
                return m
            return None
        mock_syncer_with_resource.get_resource.side_effect = selective_resolve

        with patch("okta_agent_proxy.app.get_resource_syncer", return_value=mock_syncer_with_resource), \
             patch("okta_agent_proxy.app.get_resource_store", return_value=mock_resource_store_without_entry), \
             patch("okta_agent_proxy.auth.agent_authz.emit_audit_event", new_callable=AsyncMock):
            checker = AgentAuthorizationChecker("cursor", agent_config)

            with pytest.raises(AgentAuthorizationError):
                result = await checker.check_resource_access("employees")
                await result.check_resource_access("denied")  # Should fail here
