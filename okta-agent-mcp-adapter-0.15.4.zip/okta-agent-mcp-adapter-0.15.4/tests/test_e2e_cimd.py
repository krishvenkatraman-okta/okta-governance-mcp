"""
End-to-end integration tests for the CIMD flow.

Tests the full CIMD flow by composing the real components (ClientRegistry,
CIMDFetcher, CIMDTrustPolicy, ConfidentialRelay) with mock transports
and stores. Does NOT import app.py (which requires PostgreSQL).

Additionally tests the OAuth metadata and route handlers in isolation.

Flow tested:
1. Verify authorization server metadata includes CIMD support
2. CIMD client_id resolves via ClientRegistry
3. start_authorization → Okta URL with relay credentials
4. handle_callback → redirect to original client with gateway code
5. exchange_code → tokens returned
6. Token endpoint integration: CIMD client_id triggers relay exchange
"""

import json
import pytest
from datetime import datetime, timezone
from unittest.mock import MagicMock, AsyncMock, patch
from urllib.parse import urlparse, parse_qs

import httpx
from starlette.applications import Starlette
from starlette.routing import Route
from starlette.responses import JSONResponse
from starlette.requests import Request
from starlette.testclient import TestClient

from okta_agent_proxy.auth.cimd_fetcher import CIMDFetcher, CIMDMetadata
from okta_agent_proxy.auth.cimd_policy import CIMDTrustPolicy, TrustLevel
from okta_agent_proxy.auth.confidential_relay import ConfidentialRelay, RelayError
from okta_agent_proxy.auth.client_registry import ClientRegistry, ClientInfo


# ---------------------------------------------------------------------------
# Shared test data
# ---------------------------------------------------------------------------

CIMD_CLIENT_ID = "https://testapp.example.com/oauth.json"
CIMD_DOC = {
    "client_id": CIMD_CLIENT_ID,
    "client_name": "Test MCP Client",
    "redirect_uris": ["http://localhost:9999/callback"],
    "grant_types": ["authorization_code"],
    "response_types": ["code"],
    "token_endpoint_auth_method": "none",
}

OKTA_TOKEN_RESPONSE = {
    "access_token": "okta_access_token_xyz",
    "id_token": "okta_id_token_xyz",
    "refresh_token": "okta_refresh_token_xyz",
    "token_type": "Bearer",
    "expires_in": 3600,
}

DNS_PATCH = "okta_agent_proxy.auth.cimd_fetcher.socket.getaddrinfo"
PUBLIC_DNS = [(2, 1, 6, "", ("93.184.216.34", 0))]


def _make_metadata():
    return CIMDMetadata(
        client_id=CIMD_CLIENT_ID,
        client_name="Test MCP Client",
        redirect_uris=["http://localhost:9999/callback"],
        grant_types=["authorization_code"],
        response_types=["code"],
        token_endpoint_auth_method="none",
        jwks_uri=None,
        logo_uri=None,
        client_uri=None,
        scope=None,
        domain="testapp.example.com",
        fetched_at=datetime.now(timezone.utc),
        raw_json=CIMD_DOC,
    )


def _mock_store(agents=None):
    store = MagicMock()
    store.get_all_agents.return_value = agents or []
    # Default: no CIMD URL match
    store.get_agent_by_cimd_client_id.return_value = None
    del store.get_dcr_registration
    return store


def _okta_mock_transport():
    def handler(request: httpx.Request) -> httpx.Response:
        return httpx.Response(
            200,
            content=json.dumps(OKTA_TOKEN_RESPONSE).encode(),
            headers={"content-type": "application/json"},
        )
    return httpx.MockTransport(handler)


def _cimd_mock_transport(doc=None):
    body = json.dumps(doc or CIMD_DOC).encode()
    def handler(request: httpx.Request) -> httpx.Response:
        return httpx.Response(200, content=body, headers={"content-type": "application/json"})
    return httpx.MockTransport(handler)


# ---------------------------------------------------------------------------
# Test: OAuth Authorization Server Metadata
# ---------------------------------------------------------------------------


class TestOAuthMetadata:
    def test_authorization_server_metadata_advertises_cimd(self):
        """Verify the metadata handler includes CIMD support fields."""
        # Import just the handler function and test it directly
        # Build a minimal handler that mirrors app.py's oauth_authorization_server
        from urllib.parse import urlencode

        async def oauth_authorization_server(request: Request):
            okta_issuer = "https://dev-test.okta.com/oauth2/default"
            scopes = ["openid", "offline_access"]
            scope_param = urlencode({"scope": " ".join(scopes)})
            authorization_endpoint = f"{okta_issuer}/v1/authorize?{scope_param}"
            metadata = {
                "issuer": okta_issuer,
                "authorization_endpoint": authorization_endpoint,
                "token_endpoint": "http://localhost:8000/oauth2/v1/token",
                "response_types_supported": ["code"],
                "grant_types_supported": ["authorization_code", "refresh_token"],
                "token_endpoint_auth_methods_supported": [
                    "none", "client_secret_basic", "client_secret_post", "private_key_jwt"
                ],
                "code_challenge_methods_supported": ["S256"],
                "scopes_supported": scopes,
                "client_id_metadata_document_supported": True,
            }
            return JSONResponse(metadata)

        test_app = Starlette(routes=[
            Route("/.well-known/oauth-authorization-server", oauth_authorization_server, methods=["GET"]),
        ])
        client = TestClient(test_app)
        response = client.get("/.well-known/oauth-authorization-server")
        assert response.status_code == 200
        data = response.json()
        assert data["client_id_metadata_document_supported"] is True
        assert "none" in data["token_endpoint_auth_methods_supported"]


# ---------------------------------------------------------------------------
# Test: Full CIMD Component Flow (no app.py import needed)
# ---------------------------------------------------------------------------


class TestCIMDFullFlow:
    async def test_full_happy_path(self):
        """Complete flow: resolve → start_auth → callback → exchange_code."""
        # Setup components
        store = _mock_store()
        fetcher = CIMDFetcher(
            transport=_cimd_mock_transport(),
            allow_localhost=False,
        )
        policy = CIMDTrustPolicy(
            trusted_domains=["testapp.example.com"],
            allowed_redirect_patterns=["http://localhost:*/callback"],
        )
        relay = ConfidentialRelay(
            gateway_base_url="http://localhost:8000",
            okta_domain="dev-test.okta.com",
            transport=_okta_mock_transport(),
        )
        registry = ClientRegistry(store, fetcher, policy)

        # Step 1: Resolve CIMD client_id
        with patch(DNS_PATCH, return_value=PUBLIC_DNS):
            client_info = await registry.resolve(CIMD_CLIENT_ID)

        assert client_info is not None
        assert client_info.registration_source == "cimd"
        assert client_info.trust_level == "trusted"

        # Step 2: Start authorization (credentials passed per-request)
        okta_url = await relay.start_authorization(
            client_info.cimd_metadata,
            {
                "redirect_uri": "http://localhost:9999/callback",
                "state": "client_state_abc",
                "scope": "openid",
                "code_challenge": "E9Melhoa2OwvFrEMTJguCHaoeK1t8URWbuGJSstw-cM",
                "code_challenge_method": "S256",
            },
            relay_client_id="relay_cid",
            relay_client_secret="relay_secret",
        )
        parsed = urlparse(okta_url)
        params = parse_qs(parsed.query)
        assert params["client_id"] == ["relay_cid"]
        # Relay generates its own PKCE — client's challenge is NOT forwarded
        assert "code_challenge" in params
        assert params["code_challenge"] != ["E9Melhoa2OwvFrEMTJguCHaoeK1t8URWbuGJSstw-cM"]
        assert params["code_challenge_method"] == ["S256"]
        relay_state = params["state"][0]

        # Step 3: Handle Okta callback
        redirect_url, gateway_code, original_cid = await relay.handle_callback(
            relay_state, "okta_auth_code_xyz"
        )
        assert original_cid == CIMD_CLIENT_ID
        assert redirect_url.startswith("http://localhost:9999/callback")
        redirect_params = parse_qs(urlparse(redirect_url).query)
        assert redirect_params["state"] == ["client_state_abc"]
        assert redirect_params["code"] == [gateway_code]

        # Step 4: Exchange gateway code for tokens
        tokens = await relay.exchange_code(gateway_code, CIMD_CLIENT_ID)
        assert tokens["access_token"] == "okta_access_token_xyz"
        assert tokens["id_token"] == "okta_id_token_xyz"
        assert tokens["refresh_token"] == "okta_refresh_token_xyz"
        assert tokens["token_type"] == "Bearer"

    async def test_blocked_cimd_client(self):
        """CIMD client from blocked domain cannot complete flow."""
        store = _mock_store()
        fetcher = CIMDFetcher(
            transport=_cimd_mock_transport(),
            allow_localhost=False,
        )
        policy = CIMDTrustPolicy(
            blocked_domains=["testapp.example.com"],
            allowed_redirect_patterns=["http://localhost:*/callback"],
        )
        registry = ClientRegistry(store, fetcher, policy)

        with patch(DNS_PATCH, return_value=PUBLIC_DNS):
            client_info = await registry.resolve(CIMD_CLIENT_ID)

        assert client_info is None

    async def test_preregistered_takes_priority(self):
        """Pre-registered agent matched by cimd_client_id_url takes priority over auto-provision."""
        agent = {
            "agent_id": "agent-1",
            "agent_name": "test-agent",
            "client_id": "0oa_real_okta_app",
            "cimd_client_id_url": CIMD_CLIENT_ID,
            "resource_access": ["hr-system"],
            "enabled": True,
        }
        store = _mock_store()
        store.get_agent_by_cimd_client_id.return_value = agent
        fetcher = CIMDFetcher(
            transport=_cimd_mock_transport(),
            allow_localhost=False,
        )
        policy = CIMDTrustPolicy(
            trusted_domains=["testapp.example.com"],
            allowed_redirect_patterns=["http://localhost:*/callback"],
        )
        registry = ClientRegistry(store, fetcher, policy)

        client_info = await registry.resolve(CIMD_CLIENT_ID)
        assert client_info is not None
        assert client_info.registration_source == "cimd-matched"
        assert client_info.agent_config["client_id"] == "0oa_real_okta_app"

    async def test_code_replay_rejected(self):
        """Using the same gateway code twice returns error."""
        relay = ConfidentialRelay(
            gateway_base_url="http://localhost:8000",
            okta_domain="dev-test.okta.com",
            transport=_okta_mock_transport(),
        )

        okta_url = await relay.start_authorization(
            _make_metadata(),
            {"redirect_uri": "http://localhost:9999/callback", "state": "s1", "scope": "openid"},
            relay_client_id="relay_cid",
            relay_client_secret="relay_secret",
        )
        relay_state = parse_qs(urlparse(okta_url).query)["state"][0]
        _, gateway_code, _ = await relay.handle_callback(relay_state, "code1")

        # First exchange succeeds
        await relay.exchange_code(gateway_code, CIMD_CLIENT_ID)

        # Second exchange fails
        with pytest.raises(RelayError, match="No session found"):
            await relay.exchange_code(gateway_code, CIMD_CLIENT_ID)


# ---------------------------------------------------------------------------
# Test: Token Endpoint with CIMD (mini Starlette app)
# ---------------------------------------------------------------------------


class TestCIMDTokenEndpoint:
    def _make_test_app(self, relay, registry):
        """Build a minimal Starlette app with the CIMD-aware token endpoint."""

        async def token_endpoint(request: Request):
            body = await request.json()

            grant_type = body.get("grant_type")
            cimd_client_id = body.get("client_id", "")

            if cimd_client_id and ClientRegistry._is_cimd_url(cimd_client_id):
                code = body.get("code")
                if grant_type == "authorization_code" and code:
                    try:
                        client_info = await registry.resolve(cimd_client_id)
                        if client_info and client_info.registration_source == "cimd":
                            tokens = await relay.exchange_code(code, cimd_client_id)
                            return JSONResponse(tokens)
                    except RelayError as e:
                        return JSONResponse(
                            {"error": "invalid_grant", "error_description": str(e)},
                            status_code=400,
                        )

            return JSONResponse(
                {"error": "invalid_client", "error_description": "Client not found"},
                status_code=401,
            )

        async def callback(request: Request):
            code = request.query_params.get("code")
            state = request.query_params.get("state")
            if not code or not state:
                return JSONResponse({"error": "missing params"}, status_code=400)
            try:
                redirect_url, _, _ = await relay.handle_callback(state, code)
                from starlette.responses import RedirectResponse
                return RedirectResponse(url=redirect_url, status_code=302)
            except RelayError as e:
                return JSONResponse({"error": str(e)}, status_code=400)

        return Starlette(routes=[
            Route("/oauth/callback", callback, methods=["GET"]),
            Route("/oauth2/v1/token", token_endpoint, methods=["POST"]),
        ])

    def test_cimd_token_exchange_via_http(self):
        """POST /oauth2/v1/token with CIMD client_id returns relay tokens."""
        store = _mock_store()
        fetcher = MagicMock(spec=CIMDFetcher)
        fetcher.fetch_and_validate = AsyncMock(return_value=_make_metadata())
        policy = MagicMock(spec=CIMDTrustPolicy)
        from okta_agent_proxy.auth.cimd_policy import CIMDTrustResult
        policy.evaluate = AsyncMock(return_value=CIMDTrustResult(
            allowed=True, trust_level=TrustLevel.TRUSTED,
            domain="testapp.example.com", reason="ok", redirect_uris_valid=True,
        ))

        relay = ConfidentialRelay(
            gateway_base_url="http://localhost:8000",
            okta_domain="dev-test.okta.com",
            transport=_okta_mock_transport(),
        )
        registry = ClientRegistry(store, fetcher, policy)
        app = self._make_test_app(relay, registry)
        client = TestClient(app)

        import asyncio

        # Start authorization flow (credentials passed per-request)
        okta_url = asyncio.get_event_loop().run_until_complete(
            relay.start_authorization(
                _make_metadata(),
                {"redirect_uri": "http://localhost:9999/callback", "state": "s", "scope": "openid"},
                relay_client_id="relay_cid",
                relay_client_secret="relay_secret",
            )
        )
        relay_state = parse_qs(urlparse(okta_url).query)["state"][0]

        # Hit callback
        cb_resp = client.get(
            f"/oauth/callback?code=okta_code&state={relay_state}",
            follow_redirects=False,
        )
        assert cb_resp.status_code == 302
        gateway_code = parse_qs(urlparse(cb_resp.headers["location"]).query)["code"][0]

        # Exchange gateway code via token endpoint
        token_resp = client.post(
            "/oauth2/v1/token",
            json={
                "grant_type": "authorization_code",
                "code": gateway_code,
                "client_id": CIMD_CLIENT_ID,
            },
        )
        assert token_resp.status_code == 200
        tokens = token_resp.json()
        assert tokens["access_token"] == "okta_access_token_xyz"
        assert tokens["token_type"] == "Bearer"

    def test_replay_via_http(self):
        """Code replay returns 400 via token endpoint."""
        store = _mock_store()
        fetcher = MagicMock(spec=CIMDFetcher)
        fetcher.fetch_and_validate = AsyncMock(return_value=_make_metadata())
        policy = MagicMock(spec=CIMDTrustPolicy)
        from okta_agent_proxy.auth.cimd_policy import CIMDTrustResult
        policy.evaluate = AsyncMock(return_value=CIMDTrustResult(
            allowed=True, trust_level=TrustLevel.TRUSTED,
            domain="testapp.example.com", reason="ok", redirect_uris_valid=True,
        ))

        relay = ConfidentialRelay(
            gateway_base_url="http://localhost:8000",
            okta_domain="dev-test.okta.com",
            transport=_okta_mock_transport(),
        )
        registry = ClientRegistry(store, fetcher, policy)
        app = self._make_test_app(relay, registry)
        client = TestClient(app)

        import asyncio

        okta_url = asyncio.get_event_loop().run_until_complete(
            relay.start_authorization(
                _make_metadata(),
                {"redirect_uri": "http://localhost:9999/callback", "state": "s2", "scope": "openid"},
                relay_client_id="relay_cid",
                relay_client_secret="relay_secret",
            )
        )
        relay_state = parse_qs(urlparse(okta_url).query)["state"][0]

        cb_resp = client.get(
            f"/oauth/callback?code=c2&state={relay_state}",
            follow_redirects=False,
        )
        gateway_code = parse_qs(urlparse(cb_resp.headers["location"]).query)["code"][0]

        # First exchange succeeds
        r1 = client.post(
            "/oauth2/v1/token",
            json={"grant_type": "authorization_code", "code": gateway_code, "client_id": CIMD_CLIENT_ID},
        )
        assert r1.status_code == 200

        # Replay fails
        r2 = client.post(
            "/oauth2/v1/token",
            json={"grant_type": "authorization_code", "code": gateway_code, "client_id": CIMD_CLIENT_ID},
        )
        assert r2.status_code == 400
        assert "invalid_grant" in r2.json()["error"]
