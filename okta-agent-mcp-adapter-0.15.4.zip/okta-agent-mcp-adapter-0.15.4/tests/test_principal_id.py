"""
Tests for the principal_id field in agent configuration.

Covers:
- OktaCrossAppAccessManager uses principal_id as issuer+subject in JWTBearerClaims
- Missing principal_id raises ValueError
- Env var fallback does NOT affect principal_id when agent has its own key
- PLACEHOLDER key fallback sets principal_id from gateway env vars
"""

import pytest
import os
import json
from unittest.mock import patch, MagicMock


# ============================================================================
# OktaCrossAppAccessManager principal_id tests
# ============================================================================

@pytest.fixture(autouse=True)
def clean_env(monkeypatch):
    """Ensure env vars don't leak between tests."""
    monkeypatch.delenv("OKTA_AI_AGENT_ID", raising=False)
    monkeypatch.delenv("OKTA_AI_AGENT_PRIVATE_KEY", raising=False)
    monkeypatch.delenv("OKTA_AI_AGENT_CLIENT_ID", raising=False)
    monkeypatch.setenv("OKTA_DOMAIN", "dev-test.okta.com")


SAMPLE_JWK = json.dumps({
    "kty": "RSA",
    "n": "test-n-value",
    "e": "AQAB",
    "d": "test-d-value",
    "kid": "test-key-1",
    "use": "sig",
    "alg": "RS256",
})


@patch("okta_agent_proxy.auth.cross_app_access.OAuth2Client")
@patch("okta_agent_proxy.auth.cross_app_access.OAuth2ClientConfiguration")
@patch("okta_agent_proxy.auth.cross_app_access.ClientAssertionAuthorization")
@patch("okta_agent_proxy.auth.cross_app_access.JWTBearerClaims")
@patch("okta_agent_proxy.auth.cross_app_access.LocalKeyProvider")
def test_principal_id_used_in_jwt_claims(mock_kp, mock_claims, mock_auth, mock_config, mock_client):
    """When principal_id is provided, it appears as issuer+subject in JWTBearerClaims."""
    from okta_agent_proxy.auth.cross_app_access import OktaCrossAppAccessManager

    manager = OktaCrossAppAccessManager(
        agent_id="claude-code",
        client_id="0oaXXXX",
        agent_private_key=SAMPLE_JWK,
        okta_domain="dev-test.okta.com",
        target_auth_server_id="ausXXXX",
        principal_id="agt1234567890",
    )

    assert manager.principal_id == "agt1234567890"
    assert manager.agent_id == "claude-code"

    # Verify JWTBearerClaims was called with the correct principal_id
    claims_call = mock_claims.call_args
    assert claims_call.kwargs["issuer"] == "agt1234567890"
    assert claims_call.kwargs["subject"] == "agt1234567890"


def test_principal_id_required_raises_value_error():
    """When principal_id is not provided, ValueError is raised."""
    from okta_agent_proxy.auth.cross_app_access import OktaCrossAppAccessManager

    with pytest.raises(ValueError, match="principal_id is required"):
        OktaCrossAppAccessManager(
            agent_id="claude-code",
            client_id="0oaXXXX",
            agent_private_key=SAMPLE_JWK,
            okta_domain="dev-test.okta.com",
            target_auth_server_id="ausXXXX",
            principal_id=None,
        )


@patch("okta_agent_proxy.auth.cross_app_access.OAuth2Client")
@patch("okta_agent_proxy.auth.cross_app_access.OAuth2ClientConfiguration")
@patch("okta_agent_proxy.auth.cross_app_access.ClientAssertionAuthorization")
@patch("okta_agent_proxy.auth.cross_app_access.JWTBearerClaims")
@patch("okta_agent_proxy.auth.cross_app_access.LocalKeyProvider")
def test_principal_id_ignores_env_var_when_agent_has_key(mock_kp, mock_claims, mock_auth, mock_config, mock_client, monkeypatch):
    """When agent has its own key, OKTA_AI_AGENT_ID env var does NOT affect principal_id."""
    monkeypatch.setenv("OKTA_AI_AGENT_ID", "agt-from-env")

    from okta_agent_proxy.auth.cross_app_access import OktaCrossAppAccessManager

    manager = OktaCrossAppAccessManager(
        agent_id="claude-code",
        client_id="0oaXXXX",
        agent_private_key=SAMPLE_JWK,
        okta_domain="dev-test.okta.com",
        target_auth_server_id="ausXXXX",
        principal_id="agt-from-db",
    )

    # principal_id should be the explicit param, NOT the env var
    assert manager.principal_id == "agt-from-db"

    # Verify JWTBearerClaims used the DB value
    claims_call = mock_claims.call_args
    assert claims_call.kwargs["issuer"] == "agt-from-db"
    assert claims_call.kwargs["subject"] == "agt-from-db"


@patch("okta_agent_proxy.auth.cross_app_access.OAuth2Client")
@patch("okta_agent_proxy.auth.cross_app_access.OAuth2ClientConfiguration")
@patch("okta_agent_proxy.auth.cross_app_access.ClientAssertionAuthorization")
@patch("okta_agent_proxy.auth.cross_app_access.JWTBearerClaims")
@patch("okta_agent_proxy.auth.cross_app_access.LocalKeyProvider")
def test_placeholder_fallback_sets_principal_id(mock_kp, mock_claims, mock_auth, mock_config, mock_client, monkeypatch):
    """When agent has PLACEHOLDER key and AI Agent env vars exist, principal_id should be set."""
    monkeypatch.setenv("OKTA_AI_AGENT_PRIVATE_KEY", SAMPLE_JWK)
    monkeypatch.setenv("OKTA_AI_AGENT_CLIENT_ID", "0oaAIAgent")
    monkeypatch.setenv("OKTA_AI_AGENT_ID", "agtAIAgent")

    from okta_agent_proxy.auth.cross_app_access import OktaCrossAppAccessManager

    manager = OktaCrossAppAccessManager(
        agent_id="some-agent",
        client_id="0oaOldClient",
        agent_private_key="PLACEHOLDER",
        okta_domain="dev-test.okta.com",
        target_auth_server_id="ausXXXX",
        principal_id="agt-original",
    )

    assert manager.principal_id == "agtAIAgent"
    assert manager.client_id == "0oaAIAgent"
    assert manager._using_gateway_key is True
