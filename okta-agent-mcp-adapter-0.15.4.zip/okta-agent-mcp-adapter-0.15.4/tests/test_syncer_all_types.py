"""
Tests for syncer handling of all three production connection types
with nested response shapes.

Covers:
- extract_resource_id for nested authorizationServer, secret, serviceAccount objects
- extract_connection_metadata for all three types
- _merge_connections producing ResolvedResource with correct auth_method and metadata
- End-to-end sync for mixed connection types
"""

import pytest
from unittest.mock import MagicMock
from datetime import datetime

from okta_agent_proxy.resources.models import (
    OktaConnectionType,
    OktaScopeCondition,
    ResolvedResource,
    ResourceMapEntry,
)
from okta_agent_proxy.resources.utils import (
    extract_resource_id,
    extract_connection_metadata,
    parse_connection_type,
)


# ============================================================================
# Production API response fixtures
# ============================================================================

IDENTITY_ASSERTION_CONN = {
    "id": "conn-ia-1",
    "connectionType": "IDENTITY_ASSERTION_CUSTOM_AS",
    "status": "ACTIVE",
    "authorizationServer": {
        "orn": "orn:oktapreview:idp:00oabc:authorization_servers:aus5rb5mt",
        "issuerUrl": "https://dev-test.okta.com/oauth2/aus5rb5mt",
    },
    "resourceIndicator": "orn:okta:idp:00oabc:authorization_servers:aus5rb5mt",
    "scopes": ["mcp:read", "mcp:write"],
    "scopeCondition": "INCLUDE_ONLY",
}

STS_VAULT_SECRET_CONN = {
    "id": "conn-vs-1",
    "connectionType": "STS_VAULT_SECRET",
    "status": "ACTIVE",
    "secret": {
        "orn": "orn:okta:pam:00oabc:secrets:d2642f68-df50-4ba8-a898-6c0f82f89d8a",
        "name": "slack-api-key",
        "path": "/vault/integrations/slack",
    },
    "resourceIndicator": "orn:okta:pam:00oabc:secrets:d2642f68-df50-4ba8-a898-6c0f82f89d8a",
}

STS_SERVICE_ACCOUNT_CONN = {
    "id": "conn-sa-1",
    "connectionType": "STS_SERVICE_ACCOUNT",
    "status": "ACTIVE",
    "serviceAccount": {
        "orn": "orn:okta:pam:00oabc:service_accounts:4923897d-abcd-1234",
        "name": "jira-bot",
    },
    "app": {
        "orn": "orn:okta:idp:00oabc:apps:jira:0oa999",
    },
    "resourceIndicator": "orn:okta:pam:00oabc:apps:jira:0oa999:service_accounts:4923897d-abcd-1234",
}

INACTIVE_CONN = {
    "id": "conn-inactive",
    "connectionType": "IDENTITY_ASSERTION_CUSTOM_AS",
    "status": "INACTIVE",
    "authorizationServer": {"orn": "orn:okta:idp:00o:authorization_servers:ausXXX"},
}


# ============================================================================
# extract_resource_id — nested objects
# ============================================================================

class TestExtractResourceIdNested:

    def test_identity_assertion_from_resource_indicator(self):
        result = extract_resource_id(
            IDENTITY_ASSERTION_CONN, OktaConnectionType.IDENTITY_ASSERTION_CUSTOM_AS
        )
        assert result == "aus5rb5mt"

    def test_identity_assertion_fallback_to_nested_orn(self):
        conn = {
            "connectionType": "IDENTITY_ASSERTION_CUSTOM_AS",
            "authorizationServer": {
                "orn": "orn:oktapreview:idp:00o:authorization_servers:ausFALLBACK",
            },
        }
        result = extract_resource_id(conn, OktaConnectionType.IDENTITY_ASSERTION_CUSTOM_AS)
        assert result == "ausFALLBACK"

    def test_identity_assertion_fallback_to_nested_id(self):
        conn = {
            "connectionType": "IDENTITY_ASSERTION_CUSTOM_AS",
            "authorizationServer": {"id": "aus-direct-id"},
        }
        result = extract_resource_id(conn, OktaConnectionType.IDENTITY_ASSERTION_CUSTOM_AS)
        assert result == "aus-direct-id"

    def test_vault_secret_from_resource_indicator(self):
        result = extract_resource_id(
            STS_VAULT_SECRET_CONN, OktaConnectionType.STS_VAULT_SECRET
        )
        assert result == "d2642f68-df50-4ba8-a898-6c0f82f89d8a"

    def test_vault_secret_from_nested_orn(self):
        conn = {
            "connectionType": "STS_VAULT_SECRET",
            "secret": {"orn": "orn:okta:pam:00o:secrets:uuid-from-nested"},
        }
        result = extract_resource_id(conn, OktaConnectionType.STS_VAULT_SECRET)
        assert result == "uuid-from-nested"

    def test_vault_secret_from_nested_id(self):
        conn = {
            "connectionType": "STS_VAULT_SECRET",
            "secret": {"id": "secret-direct-id"},
        }
        result = extract_resource_id(conn, OktaConnectionType.STS_VAULT_SECRET)
        assert result == "secret-direct-id"

    def test_vault_secret_legacy_field(self):
        conn = {"connectionType": "STS_VAULT_SECRET", "secretId": "legacy-secret-id"}
        result = extract_resource_id(conn, OktaConnectionType.STS_VAULT_SECRET)
        assert result == "legacy-secret-id"

    def test_service_account_from_resource_indicator(self):
        result = extract_resource_id(
            STS_SERVICE_ACCOUNT_CONN, OktaConnectionType.STS_SERVICE_ACCOUNT
        )
        assert result == "4923897d-abcd-1234"

    def test_service_account_from_nested_orn(self):
        conn = {
            "connectionType": "STS_SERVICE_ACCOUNT",
            "serviceAccount": {
                "orn": "orn:okta:pam:00o:service_accounts:sa-from-nested",
            },
        }
        result = extract_resource_id(conn, OktaConnectionType.STS_SERVICE_ACCOUNT)
        assert result == "sa-from-nested"

    def test_service_account_from_nested_id(self):
        conn = {
            "connectionType": "STS_SERVICE_ACCOUNT",
            "serviceAccount": {"id": "sa-direct-id"},
        }
        result = extract_resource_id(conn, OktaConnectionType.STS_SERVICE_ACCOUNT)
        assert result == "sa-direct-id"

    def test_service_account_legacy_field(self):
        conn = {"connectionType": "STS_SERVICE_ACCOUNT", "serviceAccountId": "legacy-sa-id"}
        result = extract_resource_id(conn, OktaConnectionType.STS_SERVICE_ACCOUNT)
        assert result == "legacy-sa-id"


# ============================================================================
# extract_connection_metadata
# ============================================================================

class TestExtractConnectionMetadata:

    def test_identity_assertion_metadata(self):
        meta = extract_connection_metadata(
            IDENTITY_ASSERTION_CONN, OktaConnectionType.IDENTITY_ASSERTION_CUSTOM_AS
        )
        assert meta["authorization_server_orn"] == "orn:oktapreview:idp:00oabc:authorization_servers:aus5rb5mt"
        assert meta["issuer_url"] == "https://dev-test.okta.com/oauth2/aus5rb5mt"

    def test_identity_assertion_no_issuer_url(self):
        conn = {
            "authorizationServer": {"orn": "orn:okta:idp:00o:authorization_servers:aus1"},
        }
        meta = extract_connection_metadata(conn, OktaConnectionType.IDENTITY_ASSERTION_CUSTOM_AS)
        assert meta["authorization_server_orn"] == "orn:okta:idp:00o:authorization_servers:aus1"
        assert "issuer_url" not in meta

    def test_vault_secret_metadata(self):
        meta = extract_connection_metadata(
            STS_VAULT_SECRET_CONN, OktaConnectionType.STS_VAULT_SECRET
        )
        assert meta["secret_orn"] == "orn:okta:pam:00oabc:secrets:d2642f68-df50-4ba8-a898-6c0f82f89d8a"
        assert meta["secret_name"] == "slack-api-key"
        assert meta["secret_path"] == "/vault/integrations/slack"

    def test_vault_secret_minimal(self):
        conn = {"secret": {"orn": "orn:okta:pam:00o:secrets:uuid"}}
        meta = extract_connection_metadata(conn, OktaConnectionType.STS_VAULT_SECRET)
        assert meta["secret_orn"] == "orn:okta:pam:00o:secrets:uuid"
        assert "secret_name" not in meta
        assert "secret_path" not in meta

    def test_service_account_metadata(self):
        meta = extract_connection_metadata(
            STS_SERVICE_ACCOUNT_CONN, OktaConnectionType.STS_SERVICE_ACCOUNT
        )
        assert meta["service_account_orn"] == "orn:okta:pam:00oabc:service_accounts:4923897d-abcd-1234"
        assert meta["service_account_name"] == "jira-bot"
        assert meta["app_orn"] == "orn:okta:idp:00oabc:apps:jira:0oa999"

    def test_service_account_no_app(self):
        conn = {"serviceAccount": {"orn": "orn:okta:pam:00o:service_accounts:sa1", "name": "bot"}}
        meta = extract_connection_metadata(conn, OktaConnectionType.STS_SERVICE_ACCOUNT)
        assert meta["service_account_name"] == "bot"
        assert "app_orn" not in meta

    def test_empty_conn_returns_empty_metadata(self):
        meta = extract_connection_metadata({}, OktaConnectionType.IDENTITY_ASSERTION_CUSTOM_AS)
        assert meta == {}

    def test_legacy_secret_type(self):
        conn = {"secret": {"orn": "orn:okta:pam:00o:secrets:uuid", "name": "key"}}
        meta = extract_connection_metadata(conn, OktaConnectionType.SECRET)
        assert meta["secret_orn"] == "orn:okta:pam:00o:secrets:uuid"
        assert meta["secret_name"] == "key"


# ============================================================================
# Syncer _merge_connections with all types
# ============================================================================

def _mock_store_with_entries(entries_by_id: dict):
    """Create a mock ResourceMapStore with entries keyed by resource_id."""
    store = MagicMock()

    def get_by_id(resource_id):
        return entries_by_id.get(resource_id, [])

    store.get_by_id = get_by_id
    return store


class TestMergeAllTypes:

    def _make_syncer(self, store):
        from okta_agent_proxy.resources.syncer import OktaConnectionSyncer
        bus = MagicMock()
        syncer = OktaConnectionSyncer(
            okta_domain="https://dev-test.okta.com",
            api_token="tok",
            resource_map_store=store,
            event_bus=bus,
        )
        return syncer

    def test_identity_assertion_resolves(self):
        entries = {
            "aus5rb5mt": [ResourceMapEntry(
                resource_id="aus5rb5mt", name="deploy-server",
                mcp_url="https://deploy.example.com", protocol="mcp",
            )],
        }
        syncer = self._make_syncer(_mock_store_with_entries(entries))
        resolved, unresolved = syncer._merge_connections([IDENTITY_ASSERTION_CONN])

        assert "deploy-server" in resolved
        rb = resolved["deploy-server"]
        assert rb.auth_method == "okta-cross-app"
        assert rb.connection_type == OktaConnectionType.IDENTITY_ASSERTION_CUSTOM_AS
        assert rb.scopes == ["mcp:read", "mcp:write"]
        assert rb.scope_condition == OktaScopeCondition.INCLUDE_ONLY
        assert rb.metadata["issuer_url"] == "https://dev-test.okta.com/oauth2/aus5rb5mt"

    def test_vault_secret_resolves(self):
        entries = {
            "d2642f68-df50-4ba8-a898-6c0f82f89d8a": [ResourceMapEntry(
                resource_id="d2642f68-df50-4ba8-a898-6c0f82f89d8a",
                name="slack-resource", mcp_url="https://slack.example.com",
            )],
        }
        syncer = self._make_syncer(_mock_store_with_entries(entries))
        resolved, unresolved = syncer._merge_connections([STS_VAULT_SECRET_CONN])

        assert "slack-resource" in resolved
        rb = resolved["slack-resource"]
        assert rb.auth_method == "vault-secret"
        assert rb.connection_type == OktaConnectionType.STS_VAULT_SECRET
        assert rb.metadata["secret_name"] == "slack-api-key"
        assert rb.metadata["secret_path"] == "/vault/integrations/slack"

    def test_service_account_resolves(self):
        entries = {
            "4923897d-abcd-1234": [ResourceMapEntry(
                resource_id="4923897d-abcd-1234",
                name="jira-resource", mcp_url="https://jira.example.com",
            )],
        }
        syncer = self._make_syncer(_mock_store_with_entries(entries))
        resolved, unresolved = syncer._merge_connections([STS_SERVICE_ACCOUNT_CONN])

        assert "jira-resource" in resolved
        rb = resolved["jira-resource"]
        assert rb.auth_method == "sts-service-account"
        assert rb.connection_type == OktaConnectionType.STS_SERVICE_ACCOUNT
        assert rb.metadata["service_account_name"] == "jira-bot"
        assert rb.metadata["app_orn"] == "orn:okta:idp:00oabc:apps:jira:0oa999"

    def test_mixed_types_all_resolve(self):
        entries = {
            "aus5rb5mt": [ResourceMapEntry(
                resource_id="aus5rb5mt", name="deploy-server",
                mcp_url="https://deploy.example.com",
            )],
            "d2642f68-df50-4ba8-a898-6c0f82f89d8a": [ResourceMapEntry(
                resource_id="d2642f68-df50-4ba8-a898-6c0f82f89d8a",
                name="slack-resource", mcp_url="https://slack.example.com",
            )],
            "4923897d-abcd-1234": [ResourceMapEntry(
                resource_id="4923897d-abcd-1234",
                name="jira-resource", mcp_url="https://jira.example.com",
            )],
        }
        syncer = self._make_syncer(_mock_store_with_entries(entries))
        resolved, unresolved = syncer._merge_connections([
            IDENTITY_ASSERTION_CONN,
            STS_VAULT_SECRET_CONN,
            STS_SERVICE_ACCOUNT_CONN,
        ])

        assert len(resolved) == 3
        assert len(unresolved) == 0
        assert resolved["deploy-server"].auth_method == "okta-cross-app"
        assert resolved["slack-resource"].auth_method == "vault-secret"
        assert resolved["jira-resource"].auth_method == "sts-service-account"

    def test_inactive_connection_skipped(self):
        entries = {
            "ausXXX": [ResourceMapEntry(
                resource_id="ausXXX", name="inactive-resource",
                mcp_url="https://example.com",
            )],
        }
        syncer = self._make_syncer(_mock_store_with_entries(entries))
        resolved, unresolved = syncer._merge_connections([INACTIVE_CONN])

        assert len(resolved) == 0
        assert len(unresolved) == 0

    def test_unresolved_resource_id(self):
        syncer = self._make_syncer(_mock_store_with_entries({}))
        resolved, unresolved = syncer._merge_connections([STS_VAULT_SECRET_CONN])

        assert len(resolved) == 0
        assert "d2642f68-df50-4ba8-a898-6c0f82f89d8a" in unresolved

    def test_one_to_many_with_metadata(self):
        """One resource_id mapped to two resources — both get metadata."""
        entries = {
            "aus5rb5mt": [
                ResourceMapEntry(
                    resource_id="aus5rb5mt", name="deploy-server",
                    mcp_url="https://deploy.example.com",
                ),
                ResourceMapEntry(
                    resource_id="aus5rb5mt", name="deploy-server-v2",
                    mcp_url="https://deploy-v2.example.com",
                ),
            ],
        }
        syncer = self._make_syncer(_mock_store_with_entries(entries))
        resolved, _ = syncer._merge_connections([IDENTITY_ASSERTION_CONN])

        assert len(resolved) == 2
        for name in ("deploy-server", "deploy-server-v2"):
            assert resolved[name].metadata["issuer_url"] == "https://dev-test.okta.com/oauth2/aus5rb5mt"


# ============================================================================
# parse_connection_type
# ============================================================================

class TestParseConnectionType:

    def test_all_canonical_types(self):
        for ct in ("IDENTITY_ASSERTION_CUSTOM_AS", "STS_VAULT_SECRET", "STS_SERVICE_ACCOUNT"):
            result = parse_connection_type({"connectionType": ct})
            assert result is not None
            assert result.value == ct

    def test_legacy_types(self):
        assert parse_connection_type({"connectionType": "SECRET"}) == OktaConnectionType.SECRET
        assert parse_connection_type({"connectionType": "SERVICE_ACCOUNT"}) == OktaConnectionType.SERVICE_ACCOUNT

    def test_type_field(self):
        result = parse_connection_type({"type": "STS_VAULT_SECRET"})
        assert result == OktaConnectionType.STS_VAULT_SECRET

    def test_unknown_type(self):
        result = parse_connection_type({"connectionType": "UNKNOWN_TYPE"})
        assert result is None
