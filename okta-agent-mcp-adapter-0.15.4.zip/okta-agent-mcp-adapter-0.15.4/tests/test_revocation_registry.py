"""Tests for RevocationRegistry — the sub-based kill-switch used on the
hot request path to reject JWTs held by MCP clients after global logout."""

from unittest.mock import AsyncMock

import pytest

from okta_agent_proxy.auth.revocation_registry import (
    RevocationRegistry,
    get_revocation_registry,
    reset_revocation_registry,
)


@pytest.fixture(autouse=True)
def _reset():
    reset_revocation_registry()
    yield
    reset_revocation_registry()


@pytest.mark.asyncio
async def test_revoke_then_is_revoked():
    reg = RevocationRegistry(ttl_seconds=60)
    assert await reg.is_revoked("user-1") is False
    await reg.revoke("user-1")
    assert await reg.is_revoked("user-1") is True


@pytest.mark.asyncio
async def test_is_revoked_returns_false_for_empty_sub():
    reg = RevocationRegistry(ttl_seconds=60)
    assert await reg.is_revoked("") is False
    assert await reg.is_revoked(None) is False


@pytest.mark.asyncio
async def test_revoke_writes_to_l2():
    cache = AsyncMock()
    cache.set = AsyncMock(return_value=None)
    reg = RevocationRegistry(ttl_seconds=120, cache_service=cache)

    await reg.revoke("user-1")
    cache.set.assert_awaited_once_with("revoked_sub:user-1", "1", ttl_seconds=120)


@pytest.mark.asyncio
async def test_is_revoked_primes_l1_from_l2():
    cache = AsyncMock()
    cache.get = AsyncMock(return_value="1")
    reg = RevocationRegistry(ttl_seconds=60, cache_service=cache)

    # L1 miss → L2 hit
    assert await reg.is_revoked("user-1") is True
    # Second call should hit L1 directly (no extra L2 call)
    cache.get.reset_mock()
    assert await reg.is_revoked("user-1") is True
    cache.get.assert_not_awaited()


@pytest.mark.asyncio
async def test_revoke_publishes_pubsub():
    bus = AsyncMock()
    bus.publish = AsyncMock(return_value=None)
    reg = RevocationRegistry(ttl_seconds=60, event_bus=bus)

    await reg.revoke("user-1")
    assert bus.publish.await_count == 1
    channel, payload = bus.publish.await_args.args
    assert channel == "user_logout"
    assert '"key": "user-1"' in payload


@pytest.mark.asyncio
async def test_revoke_swallows_l2_and_pubsub_errors():
    cache = AsyncMock()
    cache.set = AsyncMock(side_effect=RuntimeError("L2 down"))
    bus = AsyncMock()
    bus.publish = AsyncMock(side_effect=RuntimeError("pubsub down"))
    reg = RevocationRegistry(ttl_seconds=60, cache_service=cache, event_bus=bus)

    # Must not raise; L1 is still populated
    await reg.revoke("user-1")
    assert reg.is_revoked_sync("user-1") is True


def test_note_revoked_local_primes_l1_only():
    reg = RevocationRegistry(ttl_seconds=60)
    reg.note_revoked_local("user-1")
    assert reg.is_revoked_sync("user-1") is True


def test_singleton_accessor_same_instance():
    r1 = get_revocation_registry()
    r2 = get_revocation_registry()
    assert r1 is r2


def test_singleton_late_binds_cache_service_and_event_bus():
    r1 = get_revocation_registry()
    assert r1._cache_service is None

    cache = AsyncMock()
    bus = AsyncMock()
    r2 = get_revocation_registry(cache_service=cache, event_bus=bus)
    assert r2 is r1
    assert r2._cache_service is cache
    assert r2._event_bus is bus
