"""
Tests for Outbound DCR Client and Resource Router auth resolution.

Validates:
- OutboundDCRClient registration with resource DCR endpoints
- Resource discovery of registration_endpoint from OAuth metadata
- Resource discovery fallback when no endpoint found
- ResourceRouter.resolve_resource_auth for each registration_strategy
- XAA fallback to gateway signing key when agent has no private key
- XAA uses agent's own key when available (unchanged behavior)
"""

import json
from unittest.mock import AsyncMock, MagicMock, patch

import httpx
import pytest

from okta_agent_proxy.auth.outbound_dcr import OutboundDCRClient, OutboundRegistration
from okta_agent_proxy.auth.adapter_cimd import AdapterCIMDServer


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _mock_adapter_cimd():
    """Create a mock AdapterCIMDServer."""
    cimd = MagicMock(spec=AdapterCIMDServer)
    cimd.client_id = "https://gateway.test/oauth/client-metadata.json"
    cimd.get_client_metadata.return_value = {
        "client_id": "https://gateway.test/oauth/client-metadata.json",
        "client_name": "Okta MCP Adapter",
        "client_uri": "https://gateway.test",
        "redirect_uris": ["https://gateway.test/oauth/backend-callback"],
        "grant_types": ["authorization_code", "refresh_token"],
        "response_types": ["code"],
        "token_endpoint_auth_method": "private_key_jwt",
        "jwks_uri": "https://gateway.test/oauth/jwks.json",
        "scope": "openid profile email offline_access mcp:read mcp:write",
    }
    cimd.sign_client_assertion.return_value = "mock.jwt.assertion"
    return cimd


def _mock_request(method="POST", url="https://backend.test/register"):
    """Create a mock httpx.Request."""
    return httpx.Request(method, url)


def _dcr_success_response():
    """Build a successful DCR response."""
    resp = httpx.Response(
        201,
        json={
            "client_id": "backend-assigned-id",
            "client_secret": "backend-secret-xyz",
            "client_id_issued_at": 1700000000,
            "client_secret_expires_at": 0,
            "registration_client_uri": "https://backend.test/register/backend-assigned-id",
        },
        request=_mock_request(),
    )
    return resp


def _oauth_metadata_response(*, registration_endpoint=None, token_endpoint=None,
                              cimd_supported=False, url="https://backend.test/.well-known/oauth-authorization-server"):
    """Build an OAuth authorization server metadata response."""
    data = {
        "issuer": "https://backend.test",
        "authorization_endpoint": "https://backend.test/authorize",
    }
    if token_endpoint:
        data["token_endpoint"] = token_endpoint
    if registration_endpoint:
        data["registration_endpoint"] = registration_endpoint
    if cimd_supported:
        data["client_id_metadata_document_supported"] = True
    return httpx.Response(200, json=data, request=_mock_request("GET", url))


def _mock_httpx_context(get_side_effect=None, post_return=None):
    """Create a properly mocked httpx.AsyncClient context manager."""
    mock_http = AsyncMock()
    if get_side_effect:
        mock_http.get = AsyncMock(side_effect=get_side_effect)
    if post_return:
        mock_http.post = AsyncMock(return_value=post_return)
    mock_http.__aenter__ = AsyncMock(return_value=mock_http)
    mock_http.__aexit__ = AsyncMock(return_value=False)
    return mock_http


# ---------------------------------------------------------------------------
# OutboundDCRClient Tests
# ---------------------------------------------------------------------------


class TestOutboundDCRClientRegistration:
    """Tests for direct registration with a known endpoint."""

    async def test_successful_registration(self):
        """Resource with registration_endpoint → successful registration."""
        cimd = _mock_adapter_cimd()
        client = OutboundDCRClient(cimd)

        mock_http = _mock_httpx_context(post_return=_dcr_success_response())

        with patch("okta_agent_proxy.auth.outbound_dcr.httpx.AsyncClient", return_value=mock_http):
            reg = await client.register_with_resource(
                "https://backend.test",
                "https://backend.test/register",
            )

        assert isinstance(reg, OutboundRegistration)
        assert reg.client_id == "backend-assigned-id"
        assert reg.client_secret == "backend-secret-xyz"
        assert reg.registration_client_uri == "https://backend.test/register/backend-assigned-id"

        # Verify the POST body used adapter metadata
        call_kwargs = mock_http.post.call_args
        body = call_kwargs[1].get("json") or call_kwargs[0][1]
        assert body["client_name"] == "Okta MCP Adapter"
        assert body["token_endpoint_auth_method"] == "private_key_jwt"

    async def test_registration_missing_client_id_raises(self):
        """DCR response missing client_id raises ValueError."""
        cimd = _mock_adapter_cimd()
        client = OutboundDCRClient(cimd)

        bad_response = httpx.Response(
            201, json={"client_secret": "x"},
            request=_mock_request(),
        )
        mock_http = _mock_httpx_context(post_return=bad_response)

        with patch("okta_agent_proxy.auth.outbound_dcr.httpx.AsyncClient", return_value=mock_http):
            with pytest.raises(ValueError, match="missing client_id"):
                await client.register_with_resource(
                    "https://backend.test",
                    "https://backend.test/register",
                )


class TestOutboundDCRClientDiscovery:
    """Tests for discover_and_register."""

    async def test_discovery_finds_registration_endpoint(self):
        """Resource discovery finds registration_endpoint in OAuth metadata."""
        cimd = _mock_adapter_cimd()
        client = OutboundDCRClient(cimd)

        metadata_resp = _oauth_metadata_response(
            registration_endpoint="https://backend.test/register"
        )

        # Discovery uses one httpx client, registration uses another
        mock_discover = _mock_httpx_context(
            get_side_effect=lambda *a, **kw: metadata_resp,
        )
        mock_register = _mock_httpx_context(post_return=_dcr_success_response())

        clients = iter([mock_discover, mock_register])

        with patch(
            "okta_agent_proxy.auth.outbound_dcr.httpx.AsyncClient",
            side_effect=lambda **kw: next(clients),
        ):
            reg = await client.discover_and_register("https://backend.test")

        assert reg is not None
        assert reg.client_id == "backend-assigned-id"

    async def test_discovery_no_registration_endpoint(self):
        """Resource discovery with no registration_endpoint returns None."""
        cimd = _mock_adapter_cimd()
        client = OutboundDCRClient(cimd)

        no_reg_resp = httpx.Response(
            200, json={"issuer": "https://backend.test"},
            request=_mock_request("GET", "https://backend.test/.well-known/x"),
        )
        mock_http = _mock_httpx_context(
            get_side_effect=lambda *a, **kw: no_reg_resp,
        )

        with patch("okta_agent_proxy.auth.outbound_dcr.httpx.AsyncClient", return_value=mock_http):
            reg = await client.discover_and_register("https://backend.test")

        assert reg is None

    async def test_discovery_metadata_fetch_fails(self):
        """Discovery returns None when metadata fetch fails."""
        cimd = _mock_adapter_cimd()
        client = OutboundDCRClient(cimd)

        mock_http = _mock_httpx_context(
            get_side_effect=httpx.ConnectError("connection refused"),
        )

        with patch("okta_agent_proxy.auth.outbound_dcr.httpx.AsyncClient", return_value=mock_http):
            reg = await client.discover_and_register("https://backend.test")

        assert reg is None


# ---------------------------------------------------------------------------
# ResourceRouter.resolve_resource_auth Tests
# ---------------------------------------------------------------------------


class TestResolveResourceAuth:
    """Tests for ResourceRouter.resolve_resource_auth strategy dispatch."""

    def _make_router(self, **kwargs):
        """Create a minimal ResourceRouter for testing."""
        from okta_agent_proxy.routing.router import ResourceRouter

        return ResourceRouter(resources_config={}, **kwargs)

    async def test_static_strategy(self):
        """Static strategy returns immediately with no discovery."""
        router = self._make_router()
        result = await router.resolve_resource_auth(
            "hr-system",
            {"registration_strategy": "static", "url": "https://hr.test"},
            {},
            "user-token",
        )
        assert result["strategy"] == "static"
        assert "error" not in result

    async def test_xaa_strategy(self):
        """XAA strategy returns immediately."""
        router = self._make_router()
        result = await router.resolve_resource_auth(
            "hr-system",
            {"registration_strategy": "xaa", "url": "https://hr.test"},
            {},
            "user-token",
        )
        assert result["strategy"] == "xaa"
        assert "error" not in result

    async def test_cimd_strategy_discovers_token_endpoint(self):
        """CIMD strategy discovers token_endpoint from resource and signs assertion."""
        router = self._make_router()

        metadata_resp = _oauth_metadata_response(
            token_endpoint="https://backend.test/oauth2/v1/token"
        )
        mock_http = _mock_httpx_context(
            get_side_effect=lambda *a, **kw: metadata_resp,
        )

        with patch(
            "okta_agent_proxy.routing.router.httpx_lib.AsyncClient",
            return_value=mock_http,
        ):
            with patch(
                "okta_agent_proxy.routing.router.AdapterCIMDServer"
            ) as mock_cimd_cls:
                mock_cimd = _mock_adapter_cimd()
                mock_cimd_cls.return_value = mock_cimd

                result = await router.resolve_resource_auth(
                    "hr-system",
                    {"registration_strategy": "cimd", "url": "https://backend.test"},
                    {},
                    "user-token",
                )

        assert result["strategy"] == "cimd"
        assert result["client_id"] == "https://gateway.test/oauth/client-metadata.json"
        assert result["client_assertion"] == "mock.jwt.assertion"
        assert result["token_endpoint"] == "https://backend.test/oauth2/v1/token"

    async def test_dcr_strategy_uses_cached_credentials(self):
        """DCR strategy returns cached credentials without re-registering."""
        router = self._make_router()
        result = await router.resolve_resource_auth(
            "hr-system",
            {
                "registration_strategy": "dcr",
                "url": "https://backend.test",
                "auth_config": {
                    "dcr_client_id": "cached-id",
                    "dcr_client_secret": "cached-secret",
                },
            },
            {},
            "user-token",
        )
        assert result["strategy"] == "dcr"
        assert result["client_id"] == "cached-id"
        assert result["client_secret"] == "cached-secret"

    async def test_auto_strategy_tries_cimd_then_dcr(self):
        """Auto strategy falls through CIMD to DCR when resource has no token_endpoint."""
        router = self._make_router()

        # CIMD discovery will fail (no token_endpoint in metadata)
        no_token_resp = httpx.Response(
            200, json={"issuer": "https://backend.test"},
            request=_mock_request("GET", "https://backend.test/.well-known/x"),
        )
        mock_http = _mock_httpx_context(
            get_side_effect=lambda *a, **kw: no_token_resp,
        )

        with patch(
            "okta_agent_proxy.routing.router.httpx_lib.AsyncClient",
            return_value=mock_http,
        ):
            with patch(
                "okta_agent_proxy.routing.router.AdapterCIMDServer"
            ) as mock_cimd_cls:
                mock_cimd = _mock_adapter_cimd()
                mock_cimd_cls.return_value = mock_cimd

                with patch(
                    "okta_agent_proxy.routing.router.OutboundDCRClient"
                ) as mock_dcr_cls:
                    mock_dcr = AsyncMock()
                    mock_dcr.discover_and_register = AsyncMock(
                        return_value=OutboundRegistration(
                            client_id="auto-dcr-id",
                            client_secret="auto-dcr-secret",
                            registration_client_uri=None,
                        )
                    )
                    mock_dcr_cls.return_value = mock_dcr

                    result = await router.resolve_resource_auth(
                        "hr-system",
                        {
                            "registration_strategy": "auto",
                            "url": "https://backend.test",
                            "auth_config": {},
                        },
                        {},
                        "user-token",
                    )

        assert result["strategy"] == "dcr"
        assert result["client_id"] == "auto-dcr-id"


# ---------------------------------------------------------------------------
# XAA Gateway Key Fallback Tests
# ---------------------------------------------------------------------------


class TestXAAGatewayKeyFallback:
    """Tests for OktaCrossAppAccessManager fallback to gateway signing key."""

    def test_agent_no_private_key_uses_gateway_key(self):
        """Agent with no private_key uses gateway signing key fallback."""
        from okta_agent_proxy.auth.adapter_cimd import _generate_rsa_keypair
        from okta_agent_proxy.auth.cross_app_access import OktaCrossAppAccessManager

        test_jwk = _generate_rsa_keypair()

        env = {
            "OKTA_DOMAIN": "dev-test.okta.com",
            "OKTA_CHAT_ASSISTANT_AGENT_ID": "",
            "OKTA_CHAT_ASSISTANT_AGENT_PRIVATE_KEY": "",
            "OKTA_CLIENT_ID": "original-client",
            "OKTA_AI_AGENT_ID": "ai-agent-id",
            # No AI Agent credentials → fallback to adapter signing key
            "OKTA_AI_AGENT_CLIENT_ID": "",
            "OKTA_AI_AGENT_PRIVATE_KEY": "",
        }

        with patch.dict("os.environ", env, clear=False):
            mock_cimd = MagicMock()
            mock_cimd._private_jwk = test_jwk
            with patch(
                "okta_agent_proxy.auth.cross_app_access.AdapterCIMDServer",
                return_value=mock_cimd,
            ):
                manager = OktaCrossAppAccessManager(
                    agent_id="some-agent",
                    client_id="some-client",
                    agent_private_key=None,
                    okta_domain="dev-test.okta.com",
                    target_auth_server_id="aus123",
                    principal_id="agt-test-principal",
                )

        assert manager._using_gateway_key is True
        assert manager.client_id == "some-client"
        assert manager.agent_id == "ai-agent-id"

    def test_agent_no_key_uses_okta_ai_agent_credentials(self):
        """Agent with no private_key uses Okta AI Agent credentials when configured."""
        from okta_agent_proxy.auth.cross_app_access import OktaCrossAppAccessManager

        ai_agent_jwk = '{"kty":"RSA","n":"test","e":"AQAB","d":"secret"}'

        env = {
            "OKTA_DOMAIN": "dev-test.okta.com",
            "OKTA_CHAT_ASSISTANT_AGENT_ID": "",
            "OKTA_CHAT_ASSISTANT_AGENT_PRIVATE_KEY": "",
            "OKTA_AI_AGENT_ID": "agt-principal-123",
            "OKTA_AI_AGENT_CLIENT_ID": "0oa-ai-agent-app",
            "OKTA_AI_AGENT_PRIVATE_KEY": ai_agent_jwk,
        }

        with patch.dict("os.environ", env, clear=False):
            manager = OktaCrossAppAccessManager(
                agent_id="some-agent",
                client_id="some-client",
                agent_private_key=None,
                okta_domain="dev-test.okta.com",
                target_auth_server_id="aus123",
                principal_id="agt-test-principal",
            )

        assert manager._using_gateway_key is True
        assert manager.client_id == "0oa-ai-agent-app"
        assert manager.agent_id == "agt-principal-123"
        assert manager.agent_private_key == json.loads(ai_agent_jwk)

    def test_agent_with_private_key_unchanged(self):
        """Agent with private_key uses its own key (unchanged behavior)."""
        from okta_agent_proxy.auth.adapter_cimd import _generate_rsa_keypair
        from okta_agent_proxy.auth.cross_app_access import OktaCrossAppAccessManager

        agent_jwk = _generate_rsa_keypair()

        manager = OktaCrossAppAccessManager(
            agent_id="my-agent",
            client_id="my-client",
            agent_private_key=json.dumps(agent_jwk),
            okta_domain="dev-test.okta.com",
            target_auth_server_id="aus123",
            principal_id="agt-my-principal",
        )

        assert manager._using_gateway_key is False
        assert manager.client_id == "my-client"
        assert manager.agent_id == "my-agent"

    def test_placeholder_private_key_triggers_fallback(self):
        """Agent with private_key='PLACEHOLDER' falls back to gateway key."""
        from okta_agent_proxy.auth.adapter_cimd import _generate_rsa_keypair
        from okta_agent_proxy.auth.cross_app_access import OktaCrossAppAccessManager

        test_jwk = _generate_rsa_keypair()

        env = {
            "OKTA_AI_AGENT_ID": "",
        }

        with patch.dict("os.environ", env, clear=False):
            mock_cimd = MagicMock()
            mock_cimd._private_jwk = test_jwk
            with patch(
                "okta_agent_proxy.auth.cross_app_access.AdapterCIMDServer",
                return_value=mock_cimd,
            ):
                manager = OktaCrossAppAccessManager(
                    agent_id="dcr-agent",
                    client_id="dcr-client",
                    agent_private_key="PLACEHOLDER",
                    okta_domain="dev-test.okta.com",
                    target_auth_server_id="aus123",
                    principal_id="agt-dcr-principal",
                )

        assert manager._using_gateway_key is True
        # With no OKTA_AI_AGENT_ID, agent_id stays as passed in
        assert manager.agent_id == "dcr-agent"
