"""
Tests for end-to-end STS resource mapping:
Okta Managed Connection → syncer → ResolvedResource → proxy dispatch.

Verifies that the GitHub STS_ACCESS_TOKEN connection flows correctly
through the entire pipeline from API response to auth method dispatch.
Resources are created by the admin in the store — the syncer resolves
connections against them, same as all other connection types.
"""

import pytest
from unittest.mock import AsyncMock, MagicMock, patch

from okta_agent_proxy.resources.syncer import OktaConnectionSyncer
from okta_agent_proxy.resources.models import (
    OktaConnectionType,
    OktaScopeCondition,
    ResolvedResource,
    Resource,
)


# Real GitHub STS_ACCESS_TOKEN connection from the Okta API
GITHUB_STS_CONNECTION = {
    "id": "mcnwecqhmwbcHp7ig1d7",
    "orn": "orn:oktapreview:idp:00oudv75opUSqDo3B1d7:connections:mcnwecqhmwbcHp7ig1d7",
    "resource": {
        "appInstanceId": "0oaweclvlpWSkuYXX1d7",
        "appInstanceName": "Github Enterprise Cloud - Organization",
        "orn": "orn:oktapreview:idp:00oudv75opUSqDo3B1d7:client-auth-settings:rscwecmwxmK9skZBD1d7",
        "resourceType": "APP_INSTANCE",
    },
    "resourceIndicator": "orn:oktapreview:idp:00oudv75opUSqDo3B1d7:client-auth-settings:rscwecmwxmK9skZBD1d7",
    "status": "ACTIVE",
    "connectionType": "STS_ACCESS_TOKEN",
}

# Identity assertion connection for mixed-type testing
IDENTITY_CONN = {
    "id": "conn-ia-1",
    "connectionType": "IDENTITY_ASSERTION_CUSTOM_AS",
    "status": "ACTIVE",
    "authorizationServer": {
        "orn": "orn:okta:idp:00o:authorization_servers:aus123",
        "issuerUrl": "https://dev.okta.com/oauth2/aus123",
    },
    "resourceIndicator": "orn:okta:idp:00o:authorization_servers:aus123",
    "scopes": ["mcp:read"],
    "scopeCondition": "INCLUDE_ONLY",
}

# Pre-configured resource entries (as the admin would create them)
GITHUB_RESOURCE = Resource(
    resource_id="rscwecmwxmK9skZBD1d7",
    name="github-proxy",
    mcp_url="https://api.githubcopilot.com/mcp/",
    protocol="mcp",
    description="GitHub Enterprise Cloud MCP endpoint",
)

DEPLOY_RESOURCE = Resource(
    resource_id="aus123",
    name="deploy-server",
    mcp_url="https://deploy.example.com",
    protocol="mcp",
)


def _mock_store(entries_by_id=None, entries_by_name=None):
    store = MagicMock()
    entries_by_id = entries_by_id or {}
    entries_by_name = entries_by_name or {}
    store.get_by_id.side_effect = lambda rid: entries_by_id.get(rid, [])
    store.get_by_connection_id = store.get_by_id
    store.get_by_name.side_effect = lambda name: entries_by_name.get(name)
    store.get_all.return_value = list(entries_by_name.values())
    store.save_sync_state.return_value = None
    return store


def _make_syncer(store=None):
    store = store or _mock_store()
    event_bus = MagicMock()
    event_bus.subscribe = MagicMock()
    event_bus.publish = MagicMock()
    return OktaConnectionSyncer(
        okta_domain="https://dev-test.okta.com",
        api_token="test-token",
        resource_store=store,
        event_bus=event_bus,
    )


# ============================================================================
# Syncer → ResolvedResource
# ============================================================================


class TestSyncerToResolvedResource:

    def test_github_connection_becomes_resolved_resource(self):
        """STS_ACCESS_TOKEN connection produces a ResolvedResource."""
        store = _mock_store(entries_by_id={"rscwecmwxmK9skZBD1d7": [GITHUB_RESOURCE]})
        syncer = _make_syncer(store)
        resources, unresolved = syncer._merge_connections([GITHUB_STS_CONNECTION])

        assert len(resources) == 1
        assert len(unresolved) == 0
        resolved = resources["github-proxy"]
        assert isinstance(resolved, ResolvedResource)

    def test_resolved_resource_has_okta_sts_auth_method(self):
        """auth_method is auto-derived as 'okta-sts' from connection type."""
        store = _mock_store(entries_by_id={"rscwecmwxmK9skZBD1d7": [GITHUB_RESOURCE]})
        syncer = _make_syncer(store)
        resources, _ = syncer._merge_connections([GITHUB_STS_CONNECTION])
        resolved = resources["github-proxy"]

        assert resolved.auth_method == "okta-sts"
        assert resolved.connection_type == OktaConnectionType.STS_ACCESS_TOKEN

    def test_resolved_resource_keeps_configured_url_and_protocol(self):
        """Resource URL and protocol come from admin-configured resource, not overridden."""
        store = _mock_store(entries_by_id={"rscwecmwxmK9skZBD1d7": [GITHUB_RESOURCE]})
        syncer = _make_syncer(store)
        resources, _ = syncer._merge_connections([GITHUB_STS_CONNECTION])
        resolved = resources["github-proxy"]

        assert resolved.mcp_url == "https://api.githubcopilot.com/mcp/"
        assert resolved.protocol == "mcp"

    def test_resource_indicator_in_metadata(self):
        """metadata.resource_indicator is set for the token exchanger."""
        store = _mock_store(entries_by_id={"rscwecmwxmK9skZBD1d7": [GITHUB_RESOURCE]})
        syncer = _make_syncer(store)
        resources, _ = syncer._merge_connections([GITHUB_STS_CONNECTION])
        resolved = resources["github-proxy"]

        assert resolved.metadata["resource_indicator"] == GITHUB_STS_CONNECTION["resourceIndicator"]

    def test_app_instance_metadata_present(self):
        """Metadata includes ISV app instance fields."""
        store = _mock_store(entries_by_id={"rscwecmwxmK9skZBD1d7": [GITHUB_RESOURCE]})
        syncer = _make_syncer(store)
        resources, _ = syncer._merge_connections([GITHUB_STS_CONNECTION])
        resolved = resources["github-proxy"]

        assert resolved.metadata["app_instance_id"] == "0oaweclvlpWSkuYXX1d7"
        assert resolved.metadata["app_instance_name"] == "Github Enterprise Cloud - Organization"
        assert resolved.metadata["resource_type"] == "APP_INSTANCE"


# ============================================================================
# Metadata flows through to proxy handler
# ============================================================================


class TestMetadataFlowsToProxy:

    @pytest.mark.asyncio
    async def test_handle_sts_exchange_reads_metadata(self):
        """ResourceTokenResolver extracts resource_indicator from metadata."""
        from okta_agent_proxy.auth.resource_token_resolver import ResourceTokenResolver
        from okta_agent_proxy.cache.token_cache import TokenCache

        token_cache = TokenCache(max_size=100, ttl_seconds=3600)
        resolver = ResourceTokenResolver(token_cache)

        # Build a ResolvedResource as the syncer would produce
        rm_store = _mock_store(entries_by_id={"rscwecmwxmK9skZBD1d7": [GITHUB_RESOURCE]})
        syncer = _make_syncer(rm_store)
        resources, _ = syncer._merge_connections([GITHUB_STS_CONNECTION])
        resolved = resources["github-proxy"]

        agent_config = {
            "agent_id": "test-agent",
            "client_id": "0oa_test",
            "private_key": "PLACEHOLDER",
            "principal_id": "agt123",
        }

        mock_exchanger = MagicMock()
        mock_exchanger.exchange = AsyncMock(return_value={
            "status": "success",
            "access_token": "gho_from_metadata_test",
            "token_type": "Bearer",
            "expires_in": 28800,
            "provider": "github-proxy",
        })

        with patch(
            "okta_agent_proxy.auth.okta_sts_exchanger.OktaSTSTokenExchanger",
            return_value=mock_exchanger,
        ):
            result = await resolver.resolve_auth_headers(
                resource_name="github-proxy",
                resource_config=resolved,
                agent_config=agent_config,
                user_id="user@example.com",
                user_id_token="eyJ.test.token",
            )

        assert result.ok
        assert result.headers["Authorization"] == "Bearer gho_from_metadata_test"

        # Verify exchange was called with the correct resource_indicator
        mock_exchanger.exchange.assert_called_once_with(
            user_id_token="eyJ.test.token",
            resource_indicator=GITHUB_STS_CONNECTION["resourceIndicator"],
            resource_name="github-proxy",
        )


# ============================================================================
# Mixed connection types in single sync
# ============================================================================


class TestMixedConnectionSync:

    def test_sts_and_identity_assertion_coexist(self):
        """Both STS_ACCESS_TOKEN and IDENTITY_ASSERTION resolve in one sync."""
        store = _mock_store(entries_by_id={
            "aus123": [DEPLOY_RESOURCE],
            "rscwecmwxmK9skZBD1d7": [GITHUB_RESOURCE],
        })
        syncer = _make_syncer(store)

        resources, unresolved = syncer._merge_connections([
            IDENTITY_CONN,
            GITHUB_STS_CONNECTION,
        ])

        assert len(resources) == 2
        assert len(unresolved) == 0

        ia_resource = resources["deploy-server"]
        assert ia_resource.auth_method == "okta-cross-app"

        sts_resource = resources["github-proxy"]
        assert sts_resource.auth_method == "okta-sts"

    def test_different_auth_methods_for_proxy_dispatch(self):
        """Proxy handler would route to different auth paths based on auth_method."""
        store = _mock_store(entries_by_id={
            "aus123": [DEPLOY_RESOURCE],
            "rscwecmwxmK9skZBD1d7": [GITHUB_RESOURCE],
        })
        syncer = _make_syncer(store)

        resources, _ = syncer._merge_connections([
            IDENTITY_CONN,
            GITHUB_STS_CONNECTION,
        ])

        auth_methods = {name: r.auth_method for name, r in resources.items()}
        assert auth_methods["deploy-server"] == "okta-cross-app"
        assert auth_methods["github-proxy"] == "okta-sts"


# ============================================================================
# Resource config available to proxy pipeline
# ============================================================================


class TestResourceConfigForPipeline:

    def test_resolved_resource_has_all_proxy_required_fields(self):
        """ResolvedResource has every field the proxy handler needs."""
        store = _mock_store(entries_by_id={"rscwecmwxmK9skZBD1d7": [GITHUB_RESOURCE]})
        syncer = _make_syncer(store)
        resources, _ = syncer._merge_connections([GITHUB_STS_CONNECTION])
        resolved = resources["github-proxy"]

        assert resolved.name
        assert resolved.mcp_url
        assert resolved.protocol
        assert resolved.auth_method
        assert resolved.connection_id
        assert resolved.connection_type
        assert "resource_indicator" in resolved.metadata

    def test_connection_id_matches_okta_connection(self):
        """connection_id comes from the Okta connection."""
        store = _mock_store(entries_by_id={"rscwecmwxmK9skZBD1d7": [GITHUB_RESOURCE]})
        syncer = _make_syncer(store)
        resources, _ = syncer._merge_connections([GITHUB_STS_CONNECTION])
        resolved = resources["github-proxy"]

        assert resolved.connection_id == "mcnwecqhmwbcHp7ig1d7"
