"""Tests for Okta Event Hook endpoint."""

import json
import os
from unittest.mock import AsyncMock, MagicMock, patch

import pytest
from starlette.applications import Starlette
from starlette.routing import Route
from starlette.testclient import TestClient

from okta_agent_proxy.admin.okta_event_hook import (
    okta_event_hook_receive,
    okta_event_hook_verify,
)
from okta_agent_proxy.auth.okta_agent_import import ImportResult


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

@pytest.fixture(autouse=True)
def _reset_singletons():
    """Reset module-level singletons between tests."""
    import okta_agent_proxy.admin.okta_event_hook as mod
    mod._service_auth = None
    mod._client = None
    mod._importer = None
    yield
    mod._service_auth = None
    mod._client = None
    mod._importer = None


@pytest.fixture
def mock_importer():
    importer = AsyncMock()
    importer.sync_agent_from_event.return_value = ImportResult(
        success=True,
        agent_name="test-agent",
        okta_agent_id="agt123",
        message="Agent synced",
        resources_linked=["hr-system"],
        warnings=[],
    )
    return importer


def _make_app(env_overrides=None, mock_importer=None):
    """Build test app with event hook routes."""
    env = {
        "OKTA_EVENT_HOOK_SECRET": "test-secret-key",
    }
    if env_overrides:
        env.update(env_overrides)

    routes = [
        Route("/api/hooks/okta/events", okta_event_hook_verify, methods=["GET"]),
        Route("/api/hooks/okta/events", okta_event_hook_receive, methods=["POST"]),
    ]

    app = Starlette(routes=routes)

    patches = [patch.dict(os.environ, env, clear=False)]
    if mock_importer:
        patches.append(
            patch(
                "okta_agent_proxy.admin.okta_event_hook._get_import_service",
                return_value=mock_importer,
            )
        )

    for p in patches:
        p.start()

    client = TestClient(app)

    return client, patches


def _cleanup(patches):
    for p in patches:
        p.stop()


def _ai_agent_event(agent_id="agt123", event_type="ai_agent.lifecycle.activate"):
    """Build a minimal Okta event hook payload."""
    return {
        "data": {
            "events": [
                {
                    "uuid": "test-uuid-1",
                    "eventType": event_type,
                    "target": [
                        {
                            "id": agent_id,
                            "type": "AI_AGENT",
                            "displayName": "Test Agent",
                        }
                    ],
                }
            ]
        }
    }


# ---------------------------------------------------------------------------
# Verification Tests
# ---------------------------------------------------------------------------

class TestVerification:
    def test_verify_with_challenge(self):
        """GET with x-okta-verification-challenge echoes it back."""
        client, patches = _make_app()
        try:
            resp = client.get(
                "/api/hooks/okta/events",
                headers={"x-okta-verification-challenge": "abc123"},
            )
            assert resp.status_code == 200
            assert resp.json() == {"verification": "abc123"}
        finally:
            _cleanup(patches)

    def test_verify_without_challenge(self):
        """GET without challenge returns 400."""
        client, patches = _make_app()
        try:
            resp = client.get("/api/hooks/okta/events")
            assert resp.status_code == 400
            assert resp.json()["error"] == "missing_challenge"
        finally:
            _cleanup(patches)


# ---------------------------------------------------------------------------
# Authentication Tests
# ---------------------------------------------------------------------------

class TestAuthentication:
    def test_valid_shared_key(self, mock_importer):
        """POST with correct shared key returns 200."""
        client, patches = _make_app(mock_importer=mock_importer)
        try:
            resp = client.post(
                "/api/hooks/okta/events",
                json=_ai_agent_event(),
                headers={"Authorization": "test-secret-key"},
            )
            assert resp.status_code == 200
            assert resp.json()["status"] == "received"
        finally:
            _cleanup(patches)

    def test_invalid_shared_key(self):
        """POST with wrong shared key returns 401."""
        client, patches = _make_app()
        try:
            resp = client.post(
                "/api/hooks/okta/events",
                json=_ai_agent_event(),
                headers={"Authorization": "wrong-key"},
            )
            assert resp.status_code == 401
            assert resp.json()["error"] == "unauthorized"
        finally:
            _cleanup(patches)

    def test_secret_not_configured(self):
        """POST when OKTA_EVENT_HOOK_SECRET is not set returns 503."""
        client, patches = _make_app(env_overrides={"OKTA_EVENT_HOOK_SECRET": ""})
        try:
            resp = client.post(
                "/api/hooks/okta/events",
                json=_ai_agent_event(),
                headers={"Authorization": "any-key"},
            )
            assert resp.status_code == 503
            assert resp.json()["error"] == "not_configured"
        finally:
            _cleanup(patches)


# ---------------------------------------------------------------------------
# Event Processing Tests
# ---------------------------------------------------------------------------

class TestEventProcessing:
    def test_ai_agent_event_triggers_sync(self, mock_importer):
        """AI Agent target triggers sync_agent_from_event."""
        client, patches = _make_app(mock_importer=mock_importer)
        try:
            resp = client.post(
                "/api/hooks/okta/events",
                json=_ai_agent_event(agent_id="agt456"),
                headers={"Authorization": "test-secret-key"},
            )
            assert resp.status_code == 200
            assert resp.json()["processed"] == 1
            mock_importer.sync_agent_from_event.assert_called_once_with("agt456")
        finally:
            _cleanup(patches)

    def test_no_ai_agent_targets_skipped(self, mock_importer):
        """Events without AI Agent targets are skipped."""
        client, patches = _make_app(mock_importer=mock_importer)
        try:
            payload = {
                "data": {
                    "events": [
                        {
                            "eventType": "user.lifecycle.activate",
                            "target": [
                                {
                                    "id": "usr123",
                                    "type": "User",
                                    "displayName": "John",
                                }
                            ],
                        }
                    ]
                }
            }
            resp = client.post(
                "/api/hooks/okta/events",
                json=payload,
                headers={"Authorization": "test-secret-key"},
            )
            assert resp.status_code == 200
            assert resp.json()["processed"] == 1
            mock_importer.sync_agent_from_event.assert_not_called()
        finally:
            _cleanup(patches)

    def test_multiple_events_all_processed(self, mock_importer):
        """Multiple events in one delivery are all processed."""
        client, patches = _make_app(mock_importer=mock_importer)
        try:
            payload = {
                "data": {
                    "events": [
                        {
                            "eventType": "ai_agent.lifecycle.activate",
                            "target": [
                                {"id": "agt001", "type": "AI_AGENT"}
                            ],
                        },
                        {
                            "eventType": "ai_agent.lifecycle.deactivate",
                            "target": [
                                {"id": "agt002", "type": "AI_AGENT"}
                            ],
                        },
                    ]
                }
            }
            resp = client.post(
                "/api/hooks/okta/events",
                json=payload,
                headers={"Authorization": "test-secret-key"},
            )
            assert resp.status_code == 200
            assert resp.json()["processed"] == 2
            assert mock_importer.sync_agent_from_event.call_count == 2
        finally:
            _cleanup(patches)

    def test_empty_events_list(self, mock_importer):
        """Empty events list returns 200 with 0 processed."""
        client, patches = _make_app(mock_importer=mock_importer)
        try:
            resp = client.post(
                "/api/hooks/okta/events",
                json={"data": {"events": []}},
                headers={"Authorization": "test-secret-key"},
            )
            assert resp.status_code == 200
            assert resp.json()["processed"] == 0
            mock_importer.sync_agent_from_event.assert_not_called()
        finally:
            _cleanup(patches)


# ---------------------------------------------------------------------------
# sync_agent_from_event uses service auth
# ---------------------------------------------------------------------------

class TestServiceAuth:
    def test_sync_uses_service_auth_no_okta_token(self, mock_importer):
        """sync_agent_from_event is called (which uses service auth, no user token)."""
        client, patches = _make_app(mock_importer=mock_importer)
        try:
            resp = client.post(
                "/api/hooks/okta/events",
                json=_ai_agent_event(agent_id="agt789"),
                headers={"Authorization": "test-secret-key"},
            )
            assert resp.status_code == 200
            # sync_agent_from_event takes only agent_id, no okta_token
            mock_importer.sync_agent_from_event.assert_called_once_with("agt789")
        finally:
            _cleanup(patches)
