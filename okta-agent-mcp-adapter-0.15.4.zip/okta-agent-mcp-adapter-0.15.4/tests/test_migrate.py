"""Tests for the SQL migration runner (P03).

Requires a reachable superuser Postgres. By default this is the throwaway
``postgres:15`` container started alongside the suite on port 55432 with
credentials ``postgres:test``. Override via the ``TEST_PG_ADMIN_URL`` env
var. Tests that need a live database are skipped when one is not reachable
so the suite stays portable.

To spin up a compatible container locally:

    docker run -d --rm --name pg-test-p03 \
        -e POSTGRES_PASSWORD=test -p 55432:5432 postgres:15
"""

from __future__ import annotations

import os
import subprocess
import sys
import uuid
from pathlib import Path
from typing import Iterator

import psycopg
import pytest

from okta_agent_proxy.storage import migrate as migrate_mod
from okta_agent_proxy.storage.migrate import (
    Migration,
    apply_migration,
    discover_migrations,
    ensure_bootstrap,
    get_applied_versions,
    get_current_version,
    status,
    upgrade,
)


REPO_ROOT = Path(__file__).resolve().parents[1]
MIGRATIONS_DIR = REPO_ROOT / "deploy" / "migrations" / "sql"
DEFAULT_ADMIN_URL = "postgresql://postgres:test@localhost:55432/postgres"


def _admin_url() -> str:
    return os.environ.get("TEST_PG_ADMIN_URL", DEFAULT_ADMIN_URL)


def _postgres_reachable(url: str) -> bool:
    try:
        with psycopg.connect(url, connect_timeout=2) as conn:
            with conn.cursor() as cur:
                cur.execute("SELECT 1")
                cur.fetchone()
        return True
    except Exception:
        return False


@pytest.fixture(scope="session")
def admin_url() -> str:
    url = _admin_url()
    if not _postgres_reachable(url):
        pytest.skip(
            f"No reachable superuser Postgres at {url}. "
            f"Start one with: docker run -d --rm --name pg-test-p03 "
            f"-e POSTGRES_PASSWORD=test -p 55432:5432 postgres:15"
        )
    return url


@pytest.fixture()
def fresh_db(admin_url: str) -> Iterator[str]:
    """Create a throwaway database, yield its URL, drop it on teardown."""
    name = f"p03_{uuid.uuid4().hex[:16]}"
    with psycopg.connect(admin_url, autocommit=True) as conn:
        with conn.cursor() as cur:
            cur.execute(f'CREATE DATABASE "{name}"')
    # Rebuild the admin URL with a swapped database path.
    parsed = psycopg.conninfo.conninfo_to_dict(admin_url)
    parsed["dbname"] = name
    test_url = psycopg.conninfo.make_conninfo(**parsed)
    try:
        yield test_url
    finally:
        with psycopg.connect(admin_url, autocommit=True) as conn:
            with conn.cursor() as cur:
                # Terminate any lingering connections before dropping.
                cur.execute(
                    "SELECT pg_terminate_backend(pid) FROM pg_stat_activity "
                    "WHERE datname = %s AND pid <> pg_backend_pid()",
                    (name,),
                )
                cur.execute(f'DROP DATABASE IF EXISTS "{name}"')


# ---------------------------------------------------------------------------
# Pure unit tests — no database required
# ---------------------------------------------------------------------------


def test_discover_migrations_returns_sorted():
    migrations = discover_migrations(MIGRATIONS_DIR)
    versions = [m.version for m in migrations]
    assert versions == sorted(versions)
    assert versions == ["001", "002", "003"]


def test_discover_migrations_excludes_bootstrap():
    migrations = discover_migrations(MIGRATIONS_DIR)
    assert all(not m.version.startswith("000") for m in migrations)
    # And yet the bootstrap file exists on disk so ensure_bootstrap can find it.
    assert (MIGRATIONS_DIR / "000__bootstrap.up.sql").exists()


def test_migration_load_computes_stable_checksum():
    path = MIGRATIONS_DIR / "001__initial_schema.up.sql"
    a = Migration.load(path)
    b = Migration.load(path)
    assert a.checksum == b.checksum
    assert len(a.checksum) == 64  # sha256 hex


def test_migration_load_finds_paired_down_file():
    m = Migration.load(MIGRATIONS_DIR / "001__initial_schema.up.sql")
    assert m.down_path is not None
    assert m.down_path.name == "001__initial_schema.down.sql"


# ---------------------------------------------------------------------------
# Live-database tests
# ---------------------------------------------------------------------------


def test_bootstrap_table_idempotent(fresh_db: str):
    with psycopg.connect(fresh_db) as conn:
        ensure_bootstrap(conn, MIGRATIONS_DIR)
        ensure_bootstrap(conn, MIGRATIONS_DIR)  # second call must be a no-op
        with conn.cursor() as cur:
            cur.execute(
                "SELECT to_regclass('schema_migrations')"
            )
            assert cur.fetchone()[0] == "schema_migrations"
            cur.execute("SELECT COUNT(*) FROM schema_migrations")
            assert cur.fetchone()[0] == 0


def test_get_current_version_empty_returns_none(fresh_db: str):
    with psycopg.connect(fresh_db) as conn:
        ensure_bootstrap(conn, MIGRATIONS_DIR)
        assert get_current_version(conn) is None


def test_apply_migration_records_to_schema_migrations(fresh_db: str):
    with psycopg.connect(fresh_db) as conn:
        ensure_bootstrap(conn, MIGRATIONS_DIR)
        m = Migration.load(MIGRATIONS_DIR / "001__initial_schema.up.sql")
        apply_migration(conn, m, applied_by="unit-test")
        with conn.cursor() as cur:
            cur.execute(
                "SELECT version, applied_by, checksum, execution_ms "
                "FROM schema_migrations"
            )
            rows = cur.fetchall()
        assert len(rows) == 1
        version, applied_by, checksum, execution_ms = rows[0]
        assert version == "001"
        assert applied_by == "unit-test"
        assert checksum == m.checksum
        assert execution_ms >= 0


def test_apply_migration_rolls_back_on_error(fresh_db: str, tmp_path: Path):
    # Construct a migration whose SQL will fail mid-way. The failure must
    # leave schema_migrations empty.
    bad_up = tmp_path / "999__bad.up.sql"
    bad_up.write_text("CREATE TABLE will_exist (id INT);\nSELECT 1/0;\n")
    # Bring a bootstrap file alongside so ensure_bootstrap can find it.
    (tmp_path / "000__bootstrap.up.sql").write_text(
        (MIGRATIONS_DIR / "000__bootstrap.up.sql").read_text()
    )
    m = Migration.load(bad_up)
    with psycopg.connect(fresh_db) as conn:
        ensure_bootstrap(conn, tmp_path)
        with pytest.raises(psycopg.Error):
            apply_migration(conn, m, applied_by="unit-test")
        with conn.cursor() as cur:
            cur.execute("SELECT COUNT(*) FROM schema_migrations")
            assert cur.fetchone()[0] == 0
            cur.execute("SELECT to_regclass('will_exist')")
            assert cur.fetchone()[0] is None


def test_upgrade_idempotent(fresh_db: str):
    first = upgrade(fresh_db, MIGRATIONS_DIR, applied_by="unit-test")
    second = upgrade(fresh_db, MIGRATIONS_DIR, applied_by="unit-test")
    assert first == ["001", "002", "003"]
    assert second == []


def test_upgrade_target_version_stops_at_target(fresh_db: str):
    applied = upgrade(
        fresh_db, MIGRATIONS_DIR, applied_by="unit-test", target_version="002"
    )
    assert applied == ["001", "002"]
    with psycopg.connect(fresh_db) as conn:
        assert get_current_version(conn) == "002"
    # A subsequent unbounded upgrade applies the remaining versions.
    applied2 = upgrade(fresh_db, MIGRATIONS_DIR, applied_by="unit-test")
    assert applied2 == ["003"]


def test_upgrade_checksum_mismatch_raises(fresh_db: str, tmp_path: Path):
    # Copy a known-good set of migration files into tmp_path, run upgrade,
    # then mutate one of them on disk — the second upgrade call must refuse.
    for name in (
        "000__bootstrap.up.sql",
        "001__initial_schema.up.sql",
        "001__initial_schema.down.sql",
    ):
        (tmp_path / name).write_text((MIGRATIONS_DIR / name).read_text())

    upgrade(fresh_db, tmp_path, applied_by="unit-test", target_version="001")
    # Tamper with 001's file.
    tampered = (tmp_path / "001__initial_schema.up.sql").read_text()
    (tmp_path / "001__initial_schema.up.sql").write_text(
        tampered + "\n-- tampered\n"
    )
    with pytest.raises(RuntimeError, match="Checksum mismatch"):
        upgrade(fresh_db, tmp_path, applied_by="unit-test")


def test_status_returns_correct_shape(fresh_db: str):
    # Before any migrations are applied.
    s = status(fresh_db, MIGRATIONS_DIR)
    assert s == {
        "current_version": None,
        "applied": [],
        "pending": ["001", "002", "003"],
    }
    upgrade(fresh_db, MIGRATIONS_DIR, applied_by="unit-test", target_version="002")
    s = status(fresh_db, MIGRATIONS_DIR)
    assert s == {
        "current_version": "002",
        "applied": ["001", "002"],
        "pending": ["003"],
    }


def test_migrations_001_through_003_match_alembic_schema(
    fresh_db: str, admin_url: str
):
    """Apply our runner's migrations, then apply Alembic's migrations to a
    separate DB, and assert the two schemas are identical at the column level.
    This guarantees the SQL port has no drift from the Alembic source of truth.
    """
    # Apply via our runner.
    upgrade(fresh_db, MIGRATIONS_DIR, applied_by="unit-test")

    # Apply via Alembic against a parallel throwaway database.
    alembic_name = f"p03alembic_{uuid.uuid4().hex[:16]}"
    with psycopg.connect(admin_url, autocommit=True) as conn:
        with conn.cursor() as cur:
            cur.execute(f'CREATE DATABASE "{alembic_name}"')
    try:
        parsed = psycopg.conninfo.conninfo_to_dict(admin_url)
        parsed["dbname"] = alembic_name
        alembic_url = psycopg.conninfo.make_conninfo(**parsed)

        # Build the libpq URL form Alembic's env.py accepts via DATABASE_URL.
        parts = psycopg.conninfo.conninfo_to_dict(alembic_url)
        import urllib.parse

        db_url = (
            f"postgresql://{parts['user']}:"
            f"{urllib.parse.quote(parts['password'], safe='')}"
            f"@{parts['host']}:{parts['port']}/{parts['dbname']}"
        )
        env = os.environ.copy()
        env["DATABASE_URL"] = db_url
        result = subprocess.run(
            [sys.executable, "-m", "alembic", "upgrade", "head"],
            cwd=str(REPO_ROOT),
            env=env,
            capture_output=True,
            text=True,
            timeout=120,
        )
        if result.returncode != 0:
            pytest.skip(
                "alembic is not installed in this environment; skipping "
                "schema-parity check. alembic stderr:\n" + result.stderr
            )

        # Extract (table, column, data_type, is_nullable, column_default-presence) tuples.
        def schema_fingerprint(url: str) -> set:
            with psycopg.connect(url) as conn:
                with conn.cursor() as cur:
                    cur.execute(
                        """
                        SELECT table_name, column_name, data_type, is_nullable,
                               (column_default IS NOT NULL) AS has_default
                        FROM information_schema.columns
                        WHERE table_schema = 'public'
                          AND table_name NOT IN ('schema_migrations', 'alembic_version')
                        ORDER BY table_name, column_name
                        """
                    )
                    return set(cur.fetchall())

        runner_fp = schema_fingerprint(fresh_db)
        alembic_fp = schema_fingerprint(alembic_url)

        # Tables should match exactly.
        runner_tables = {row[0] for row in runner_fp}
        alembic_tables = {row[0] for row in alembic_fp}
        assert runner_tables == alembic_tables, (
            f"tables only in runner: {runner_tables - alembic_tables}; "
            f"tables only in alembic: {alembic_tables - runner_tables}"
        )

        # Column-level diff. Normalize SERIAL vs integer-with-sequence: both
        # show up in information_schema as data_type='integer' with has_default=True,
        # so equality is expected.
        only_runner = runner_fp - alembic_fp
        only_alembic = alembic_fp - runner_fp
        assert not only_runner and not only_alembic, (
            f"columns only in runner: {only_runner}\n"
            f"columns only in alembic: {only_alembic}"
        )
    finally:
        with psycopg.connect(admin_url, autocommit=True) as conn:
            with conn.cursor() as cur:
                cur.execute(
                    "SELECT pg_terminate_backend(pid) FROM pg_stat_activity "
                    "WHERE datname = %s AND pid <> pg_backend_pid()",
                    (alembic_name,),
                )
                cur.execute(f'DROP DATABASE IF EXISTS "{alembic_name}"')


# ---------------------------------------------------------------------------
# CLI entrypoint smoke tests
# ---------------------------------------------------------------------------


def test_cli_main_upgrade_then_status(fresh_db: str, capsys):
    rc = migrate_mod.main(
        [
            "upgrade",
            "--conninfo",
            fresh_db,
            "--migrations-dir",
            str(MIGRATIONS_DIR),
            "--applied-by",
            "cli-smoke",
        ]
    )
    assert rc == 0
    out = capsys.readouterr().out
    assert "Applied 3 migration(s)" in out

    rc = migrate_mod.main(
        [
            "status",
            "--conninfo",
            fresh_db,
            "--migrations-dir",
            str(MIGRATIONS_DIR),
        ]
    )
    assert rc == 0
    out = capsys.readouterr().out
    assert "Current version: 003" in out


def test_cli_main_missing_conninfo_returns_2(monkeypatch, capsys):
    monkeypatch.delenv("DATABASE_URL", raising=False)
    rc = migrate_mod.main(
        ["status", "--migrations-dir", str(MIGRATIONS_DIR)]
    )
    assert rc == 2
    err = capsys.readouterr().err
    assert "DATABASE_URL" in err
