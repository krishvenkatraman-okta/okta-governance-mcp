"""
End-to-end governance integration test.

Tests the full lifecycle:
1. DCR registration → agent created → verify agent exists in adapter DB
2. AI Agent promotion → verify okta_ai_agent_id populated (mocked Okta)
3. Managed Connections sync → resource scopes updated
4. XAA with scope constraints → verify only allowed scopes in token request
5. Revocation → agent disabled → verify access denied
6. Full lifecycle: register → promote → sync → use → revoke → deny
"""

import json
from datetime import datetime
from unittest.mock import AsyncMock, MagicMock, patch

import httpx
import pytest

from okta_agent_proxy.auth.ai_agent_promoter import AIAgentPromoter
from okta_agent_proxy.auth.dcr_handler import DCRHandler
from okta_agent_proxy.auth.dcr_policy import DCRPolicy
from okta_agent_proxy.auth.managed_connections import ManagedConnectionsSync


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _mock_request(method="POST", url="https://okta.test/api"):
    return httpx.Request(method, url)


def _make_store():
    """In-memory store mock that tracks agents and DCR registrations."""
    agents = {}
    dcr_regs = {}

    store = MagicMock()

    def create_agent(agent_id, config, **kwargs):
        agents[agent_id] = {**config, "agent_id": agent_id, "enabled": config.get("enabled", True)}
        return True

    def get_agent(agent_id, enabled_only=True):
        agent = agents.get(agent_id)
        if agent is None:
            return None
        if enabled_only and not agent.get("enabled", True):
            return None
        return dict(agent)

    def get_all_agents(enabled_only=True):
        result = []
        for a in agents.values():
            if enabled_only and not a.get("enabled", True):
                continue
            result.append(dict(a))
        return result

    def update_agent(agent_id, updates, **kwargs):
        if agent_id in agents:
            agents[agent_id].update(updates)
            return True
        return False

    def disable_agent(agent_id, **kwargs):
        if agent_id in agents:
            agents[agent_id]["enabled"] = False
            return True
        return False

    def create_dcr_registration(*, client_id, client_name, agent_name=None,
                                okta_app_id=None, redirect_uris=None,
                                grant_types=None, provision_mode="virtual",
                                source_ip="127.0.0.1"):
        dcr_regs[client_id] = {
            "client_id": client_id,
            "client_name": client_name,
            "agent_name": agent_name,
            "okta_app_id": okta_app_id,
            "redirect_uris": redirect_uris or [],
            "grant_types": grant_types or [],
            "provision_mode": provision_mode,
            "source_ip": source_ip,
            "status": "active",
        }

    def get_dcr_registration(client_id):
        return dcr_regs.get(client_id)

    def revoke_dcr_registration(client_id, user="admin"):
        if client_id in dcr_regs:
            dcr_regs[client_id]["status"] = "revoked"
            return True
        return False

    def update_dcr_registration_ai_agent_id(agent_name, ai_agent_id):
        for reg in dcr_regs.values():
            if reg.get("agent_name") == agent_name:
                reg["okta_ai_agent_id"] = ai_agent_id
                return True
        return False

    # Resource store
    resources = {}

    def create_resource(name, config, **kwargs):
        resources[name] = {**config, "name": name}
        return True

    def get_resource(name):
        return resources.get(name)

    def get_all_resources():
        return list(resources.values())

    def update_resource(name, updates, **kwargs):
        if name in resources:
            resources[name].update(updates)
            return True
        return False

    store.create_agent.side_effect = create_agent
    store.get_agent.side_effect = get_agent
    store.get_all_agents.side_effect = get_all_agents
    store.update_agent.side_effect = update_agent
    store.disable_agent.side_effect = disable_agent
    store.create_dcr_registration.side_effect = create_dcr_registration
    store.get_dcr_registration.side_effect = get_dcr_registration
    store.revoke_dcr_registration.side_effect = revoke_dcr_registration
    store.update_dcr_registration_ai_agent_id.side_effect = update_dcr_registration_ai_agent_id
    store.create_resource.side_effect = create_resource
    store.get_resource.side_effect = get_resource
    store.get_all_resources.side_effect = get_all_resources
    store.update_resource.side_effect = update_resource

    # Expose internal dicts for assertions
    store._agents = agents
    store._dcr_regs = dcr_regs
    store._resources = resources

    return store


def _make_policy(**overrides):
    """Create a DCRPolicy with testing defaults."""
    defaults = dict(
        enabled=True,
        provision_okta_app=False,
        auto_enable_agent=True,
        default_resource_access=["hr-system"],
        allowed_redirect_patterns=["http://localhost:*/callback"],
    )
    defaults.update(overrides)
    return DCRPolicy(**defaults)


def _make_promoter(store, *, auto_register=True):
    """Create an AIAgentPromoter with env vars configured."""
    env = {
        "OKTA_AI_AGENT_AUTO_REGISTER": str(auto_register).lower(),
        "OKTA_AI_AGENT_ID": "agt_adapter_001",
        "OKTA_AI_AGENT_DEFAULT_OWNER": "00u_owner",
        "OKTA_API_TOKEN": "ssws-test-token",
        "OKTA_DOMAIN": "dev-test.okta.com",
    }
    with patch.dict("os.environ", env, clear=False):
        return AIAgentPromoter(store=store)


def _mock_okta_create_agent(ai_agent_id="agt_promoted_123"):
    """Return a mock httpx client that returns success for AI Agent creation."""
    mock_http = AsyncMock()

    async def _route_post(url, **kwargs):
        url_str = str(url)
        if "ai-agents" in url_str and "owners" not in url_str and "credentials" not in url_str:
            return httpx.Response(
                201,
                json={"id": ai_agent_id, "status": "STAGED"},
                request=_mock_request(),
            )
        return httpx.Response(200, json={}, request=_mock_request())

    mock_http.post = AsyncMock(side_effect=_route_post)
    mock_http.__aenter__ = AsyncMock(return_value=mock_http)
    mock_http.__aexit__ = AsyncMock(return_value=False)
    return mock_http


def _make_managed_connections_sync(store, *, enabled=True):
    """Create a ManagedConnectionsSync with env configured."""
    env = {
        "OKTA_MANAGED_CONNECTIONS_ENABLED": str(enabled).lower(),
        "OKTA_MANAGED_CONNECTIONS_SYNC_SECONDS": "60",
        "OKTA_AI_AGENT_ID": "agt_adapter_001",
        "OKTA_API_TOKEN": "ssws-test-token",
        "OKTA_DOMAIN": "dev-test.okta.com",
    }
    with patch.dict("os.environ", env, clear=False):
        return ManagedConnectionsSync(store=store)


# ---------------------------------------------------------------------------
# Test Classes
# ---------------------------------------------------------------------------


class TestDCRRegistrationGovernance:
    """Step 1: DCR registration → registration record created (no agent record)."""

    async def test_dcr_creates_registration_without_agent(self):
        """DCR registration creates a registration record but no agent record."""
        store = _make_store()
        policy = _make_policy(default_resource_access=["hr-system", "finance"])
        handler = DCRHandler(dcr_policy=policy, store=store)

        status, body = await handler.handle_registration(
            {
                "client_name": "Governance Test Client",
                "redirect_uris": ["http://localhost:9999/callback"],
                "grant_types": ["authorization_code"],
            },
            source_ip="10.0.0.1",
        )

        assert status == 201
        client_id = body["client_id"]

        # No agent record created
        agent_id = f"dcr-{client_id}"
        assert store.get_agent(agent_id, enabled_only=False) is None

        # DCR registration must exist
        reg = store.get_dcr_registration(client_id)
        assert reg is not None
        assert reg["client_name"] == "Governance Test Client"
        assert reg["status"] == "active"

    async def test_dcr_registration_no_agent_name(self):
        """DCR registration has agent_name=None (no agent record)."""
        store = _make_store()
        policy = _make_policy()
        handler = DCRHandler(dcr_policy=policy, store=store)

        status, body = await handler.handle_registration(
            {
                "client_name": "No Agent Client",
                "redirect_uris": ["http://localhost:9999/callback"],
            },
            source_ip="10.0.0.1",
        )

        assert status == 201
        reg = store.get_dcr_registration(body["client_id"])
        assert reg is not None
        assert reg.get("agent_name") is None


class TestAIAgentPromotionGovernance:
    """Step 2: AI Agent promotion — best-effort, non-blocking."""

    async def test_dcr_works_when_promotion_fails(self):
        """DCR registration succeeds even if AI Agent promotion fails."""
        store = _make_store()
        policy = _make_policy()
        promoter = _make_promoter(store)

        # Okta API returns 500
        mock_http = AsyncMock()
        mock_http.post = AsyncMock(
            return_value=httpx.Response(500, json={}, request=_mock_request())
        )
        mock_http.__aenter__ = AsyncMock(return_value=mock_http)
        mock_http.__aexit__ = AsyncMock(return_value=False)

        handler = DCRHandler(
            dcr_policy=policy, store=store, ai_agent_promoter=promoter
        )

        with patch(
            "okta_agent_proxy.auth.ai_agent_promoter.httpx.AsyncClient",
            return_value=mock_http,
        ):
            status, body = await handler.handle_registration(
                {
                    "client_name": "Resilient Agent",
                    "redirect_uris": ["http://localhost:9999/callback"],
                },
                source_ip="10.0.0.1",
            )

        # Registration should still succeed
        assert status == 201

    async def test_promotion_skipped_when_disabled(self):
        """No promotion attempt when feature is disabled."""
        store = _make_store()
        policy = _make_policy()
        promoter = _make_promoter(store, auto_register=False)

        handler = DCRHandler(
            dcr_policy=policy, store=store, ai_agent_promoter=promoter
        )

        status, body = await handler.handle_registration(
            {
                "client_name": "No Promotion Agent",
                "redirect_uris": ["http://localhost:9999/callback"],
            },
            source_ip="10.0.0.1",
        )

        assert status == 201


class TestManagedConnectionsSyncGovernance:
    """Step 3: ManagedConnectionsSync is DEPRECATED.

    Replaced by OktaConnectionSyncer (tested in test_okta_syncer.py).
    These tests verify the deprecated stub returns empty results.
    """

    async def test_deprecated_sync_returns_empty(self):
        """Deprecated sync returns empty ManagedConnectionsSyncResult."""
        import warnings
        with warnings.catch_warnings():
            warnings.simplefilter("ignore", DeprecationWarning)
            sync = ManagedConnectionsSync()
        result = await sync.sync()
        assert result.authorization_servers == []
        assert result.secrets == []
        assert result.service_accounts == []

    async def test_deprecated_get_managed_scopes_returns_none(self):
        """Deprecated get_managed_scopes always returns None."""
        import warnings
        with warnings.catch_warnings():
            warnings.simplefilter("ignore", DeprecationWarning)
            sync = ManagedConnectionsSync()
        assert sync.get_managed_scopes("hr-system") is None
        assert sync.get_managed_scopes("unknown") is None

    async def test_sync_disabled_returns_empty(self):
        """Deprecated sync returns empty regardless of config."""
        import warnings
        with warnings.catch_warnings():
            warnings.simplefilter("ignore", DeprecationWarning)
            sync = ManagedConnectionsSync()
        result = await sync.sync()
        assert len(result.authorization_servers) == 0
        assert len(result.secrets) == 0


class TestRevocationGovernance:
    """Step 5: Revocation → agent disabled → access denied."""

    async def test_revoke_marks_registration_revoked(self):
        """Revoking a DCR registration sets status to revoked."""
        store = _make_store()
        policy = _make_policy()
        handler = DCRHandler(dcr_policy=policy, store=store)

        # Register
        status, body = await handler.handle_registration(
            {
                "client_name": "Revocable Client",
                "redirect_uris": ["http://localhost:9999/callback"],
            },
            source_ip="10.0.0.1",
        )
        assert status == 201
        client_id = body["client_id"]

        # Revoke
        success, msg = await handler.revoke_registration(client_id)
        assert success is True

        # DCR registration is revoked
        reg = store.get_dcr_registration(client_id)
        assert reg["status"] == "revoked"

    async def test_revoke_nonexistent_returns_false(self):
        """Revoking a non-existent registration returns failure."""
        store = _make_store()
        handler = DCRHandler(dcr_policy=_make_policy(), store=store)
        success, msg = await handler.revoke_registration("nonexistent_client")
        assert success is False

    async def test_double_revoke_returns_false(self):
        """Revoking an already-revoked registration returns failure."""
        store = _make_store()
        handler = DCRHandler(dcr_policy=_make_policy(), store=store)

        status, body = await handler.handle_registration(
            {
                "client_name": "Double Revoke Client",
                "redirect_uris": ["http://localhost:9999/callback"],
            },
            source_ip="10.0.0.1",
        )
        assert status == 201

        # First revoke succeeds
        success, _ = await handler.revoke_registration(body["client_id"])
        assert success is True

        # Second revoke fails
        success, msg = await handler.revoke_registration(body["client_id"])
        assert success is False
        assert "already revoked" in msg.lower()


class TestFullGovernanceLifecycle:
    """Step 6: Full lifecycle — register → promote → sync → revoke → deny."""

    async def test_full_governance_lifecycle(self):
        """Complete governance lifecycle from registration to revocation."""
        store = _make_store()

        # Seed a resource that will be matched by managed connections
        store.create_resource("hr-system", {
            "name": "hr-system",
            "url": "http://hr-mcp:8001",
            "paths": ["/hr"],
            "auth_method": "okta-cross-app",
            "auth_config": json.dumps({
                "target_authorization_server": "https://dev.okta.com/oauth2/aus_hr",
            }),
            "enabled": True,
        })

        # --- Phase 1: DCR Registration ---
        policy = _make_policy(default_resource_access=["hr-system"])
        promoter = _make_promoter(store)
        handler = DCRHandler(
            dcr_policy=policy, store=store, ai_agent_promoter=promoter
        )

        mock_okta_http = _mock_okta_create_agent("agt_lifecycle_001")

        with patch(
            "okta_agent_proxy.auth.ai_agent_promoter.httpx.AsyncClient",
            return_value=mock_okta_http,
        ):
            status, body = await handler.handle_registration(
                {
                    "client_name": "Lifecycle Test Client",
                    "redirect_uris": ["http://localhost:9999/callback"],
                    "grant_types": ["authorization_code"],
                },
                source_ip="10.0.0.1",
            )

        assert status == 201
        client_id = body["client_id"]

        # Verify: no agent record created (lightweight DCR registration)
        agent_id = f"dcr-{client_id}"
        assert store.get_agent(agent_id, enabled_only=False) is None

        # Verify: DCR registration is active
        reg = store.get_dcr_registration(client_id)
        assert reg is not None
        assert reg["status"] == "active"

        # --- Phase 2: Revocation ---
        success, msg = await handler.revoke_registration(client_id)
        assert success is True

        # Verify: DCR registration is revoked
        revoked_reg = store.get_dcr_registration(client_id)
        assert revoked_reg["status"] == "revoked"

        # --- Phase 3: Re-registration after revocation creates new registration ---
        status2, body2 = await handler.handle_registration(
            {
                "client_name": "Lifecycle Test Client v2",
                "redirect_uris": ["http://localhost:9999/callback"],
            },
            source_ip="10.0.0.1",
        )

        assert status2 == 201
        new_client_id = body2["client_id"]
        assert new_client_id != client_id

        # New registration is active, old is revoked
        assert store.get_dcr_registration(new_client_id)["status"] == "active"
        assert store.get_dcr_registration(client_id)["status"] == "revoked"

    async def test_multiple_registrations_independent_revocation(self):
        """Revoking one registration does not affect others."""
        store = _make_store()
        policy = _make_policy(default_resource_access=["hr-system"])
        handler = DCRHandler(dcr_policy=policy, store=store)

        # Register two clients
        _, body1 = await handler.handle_registration(
            {
                "client_name": "Agent Alpha",
                "redirect_uris": ["http://localhost:9999/callback"],
            },
            source_ip="10.0.0.1",
        )
        _, body2 = await handler.handle_registration(
            {
                "client_name": "Agent Beta",
                "redirect_uris": ["http://localhost:9999/callback"],
            },
            source_ip="10.0.0.2",
        )

        client_id_1 = body1["client_id"]
        client_id_2 = body2["client_id"]

        # Both registrations active
        assert store.get_dcr_registration(client_id_1)["status"] == "active"
        assert store.get_dcr_registration(client_id_2)["status"] == "active"

        # Revoke registration 1
        success, _ = await handler.revoke_registration(client_id_1)
        assert success is True

        # Registration 1 revoked, Registration 2 still active
        assert store.get_dcr_registration(client_id_1)["status"] == "revoked"
        assert store.get_dcr_registration(client_id_2)["status"] == "active"

    async def test_deprecated_sync_is_noop(self):
        """Deprecated ManagedConnectionsSync.sync() is a no-op."""
        import warnings
        with warnings.catch_warnings():
            warnings.simplefilter("ignore", DeprecationWarning)
            sync = ManagedConnectionsSync()
        result = await sync.sync()
        assert result.secrets == []

    async def _REMOVED_test_sync_secret_connection_updates_resource(self):
        """REMOVED — ManagedConnectionsSync is deprecated.

        Secret connection sync is now handled by OktaConnectionSyncer
        (tested in test_okta_syncer.py::TestSyncAllTypes::test_secret_creates_pre_shared_key).
        """
        pass  # pragma: no cover

    async def _REMOVED_original_test_sync_secret(self):
        """Placeholder — original test code below for reference during migration.
        Managed Connections sync applies secret connections to resources."""
        store = _make_store()

        store.create_resource("api-resource", {
            "name": "api-resource",
            "url": "https://api.example.com/mcp",
            "paths": ["/api"],
            "auth_method": "pre-shared-key",
            "auth_config": json.dumps({"api_key": "old-key"}),
        })

        sync = _make_managed_connections_sync(store)

        connections = [
            {
                "type": "secret",
                "name": "api-resource",
                "properties": {
                    "resourceIndicator": "https://api.example.com",
                },
            },
        ]

        mock_http = AsyncMock()
        mock_http.get = AsyncMock(
            return_value=httpx.Response(200, json=connections, request=_mock_request("GET"))
        )
        mock_http.__aenter__ = AsyncMock(return_value=mock_http)
        mock_http.__aexit__ = AsyncMock(return_value=False)

        with patch(
            "okta_agent_proxy.auth.managed_connections.httpx.AsyncClient",
            return_value=mock_http,
        ):
            result = await sync.sync()

        assert len(result.secrets) == 1
        resource = store.get_resource("api-resource")
        assert resource["managed_connection_id"] == "api-resource"
