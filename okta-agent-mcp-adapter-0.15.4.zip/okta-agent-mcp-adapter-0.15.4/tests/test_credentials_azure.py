"""Tests for the Azure Entra ID database credential provider (P11).

``azure.identity.DefaultAzureCredential`` is mocked — these tests
never touch Azure. End-to-end validation against a real Azure
Postgres Flexible Server is covered by the ACA smoke test in P14.
"""

from __future__ import annotations

import time
from unittest.mock import MagicMock

import pytest

from okta_agent_proxy.storage.credentials import (
    DatabaseCredentialProvider,
    get_credential_provider,
)
from okta_agent_proxy.storage.credentials_azure import (
    _AZURE_POSTGRES_SCOPE,
    _MIN_TTL_SECONDS,
    AzureEntraCredentialProvider,
)


@pytest.fixture()
def azure_env(monkeypatch):
    """Populate the env vars the Entra provider requires."""
    monkeypatch.setenv(
        "DB_HOST", "my-server.postgres.database.azure.com"
    )
    monkeypatch.setenv("DB_PORT", "5432")
    monkeypatch.setenv("DB_NAME", "gateway_db")
    monkeypatch.setenv("DB_USERNAME", "okta-adapter-app")
    monkeypatch.delenv("DB_SSLROOTCERT", raising=False)


def _token_obj(token: str, ttl_seconds: int = 3600):
    """Mimic ``azure.core.credentials.AccessToken`` — only two fields used."""
    obj = MagicMock()
    obj.token = token
    obj.expires_on = int(time.time()) + ttl_seconds
    return obj


@pytest.fixture()
def fake_azure_credential():
    """A DefaultAzureCredential-like mock that returns distinct tokens."""
    cred = MagicMock()
    # Each call returns a fresh token so freshness assertions are meaningful.
    cred.get_token.side_effect = [
        _token_obj(f"aad-token-{i}") for i in range(100)
    ]
    return cred


def test_azure_provider_uses_correct_scope(azure_env, fake_azure_credential):
    provider = AzureEntraCredentialProvider(
        azure_credential=fake_azure_credential
    )
    provider.get_credential()

    fake_azure_credential.get_token.assert_called_once_with(
        _AZURE_POSTGRES_SCOPE
    )
    # Spot-check the canonical URL so future refactors don't silently
    # break auth against Flexible Server.
    assert (
        _AZURE_POSTGRES_SCOPE
        == "https://ossrdbms-aad.database.windows.net/.default"
    )


def test_azure_provider_returns_token_as_password(
    azure_env, fake_azure_credential
):
    provider = AzureEntraCredentialProvider(
        azure_credential=fake_azure_credential
    )
    cred = provider.get_credential()

    assert cred.password == "aad-token-0"
    assert cred.username == "okta-adapter-app"
    assert cred.host == "my-server.postgres.database.azure.com"
    assert cred.port == 5432
    assert cred.dbname == "gateway_db"


def test_azure_provider_ttl_derived_from_token_expiry(
    azure_env, fake_azure_credential
):
    # Override with a tightly controlled expires_on so the derived TTL
    # is predictable without mocking time.time.
    now = int(time.time())
    token = MagicMock()
    token.token = "custom"
    token.expires_on = now + 1800
    fake_azure_credential.get_token.side_effect = [token]

    provider = AzureEntraCredentialProvider(
        azure_credential=fake_azure_credential
    )
    cred = provider.get_credential()

    # Allow a small window for wall-clock drift between expires_on math
    # inside the provider and the assertion below.
    assert 1795 <= cred.ttl_seconds <= 1800


def test_azure_provider_ttl_floor_when_token_already_expired(
    azure_env, fake_azure_credential
):
    # A token whose expires_on is in the immediate past must still
    # report the minimum TTL so the pool doesn't multiply by zero.
    expired = MagicMock()
    expired.token = "expired"
    expired.expires_on = int(time.time()) - 30
    fake_azure_credential.get_token.side_effect = [expired]

    provider = AzureEntraCredentialProvider(
        azure_credential=fake_azure_credential
    )
    cred = provider.get_credential()

    assert cred.ttl_seconds == _MIN_TTL_SECONDS
    assert cred.ttl_seconds >= 60


def test_azure_provider_supports_rotation_true(
    azure_env, fake_azure_credential
):
    provider = AzureEntraCredentialProvider(
        azure_credential=fake_azure_credential
    )
    assert provider.supports_rotation() is True
    assert provider.name == "azure_entra"
    assert isinstance(provider, DatabaseCredentialProvider)


def test_azure_provider_sslmode_require(azure_env, fake_azure_credential):
    provider = AzureEntraCredentialProvider(
        azure_credential=fake_azure_credential
    )
    cred = provider.get_credential()

    # Azure Postgres Flexible Server requires SSL; confirm the provider
    # doesn't accidentally downgrade to 'prefer' or 'disable'.
    assert cred.sslmode == "require"
    # sslrootcert defaults to None — system trust store is sufficient
    # for Azure's public CAs.
    assert cred.sslrootcert is None


def test_azure_provider_honors_custom_sslrootcert(
    azure_env, fake_azure_credential, monkeypatch
):
    monkeypatch.setenv("DB_SSLROOTCERT", "/etc/ssl/DigiCertGlobalRootCA.crt.pem")
    provider = AzureEntraCredentialProvider(
        azure_credential=fake_azure_credential
    )
    cred = provider.get_credential()

    assert cred.sslrootcert == "/etc/ssl/DigiCertGlobalRootCA.crt.pem"


def test_azure_provider_get_credential_called_twice_returns_fresh_token(
    azure_env, fake_azure_credential
):
    provider = AzureEntraCredentialProvider(
        azure_credential=fake_azure_credential
    )

    cred1 = provider.get_credential()
    cred2 = provider.get_credential()

    assert cred1.password != cred2.password
    assert (cred1.password, cred2.password) == ("aad-token-0", "aad-token-1")
    assert fake_azure_credential.get_token.call_count == 2


def test_missing_env_vars_raises_clear_error(monkeypatch):
    for var in ("DB_HOST", "DB_PORT", "DB_NAME", "DB_USERNAME", "DB_SSLROOTCERT"):
        monkeypatch.delenv(var, raising=False)

    with pytest.raises(RuntimeError) as exc:
        AzureEntraCredentialProvider(azure_credential=MagicMock())

    msg = str(exc.value)
    assert "DB_HOST" in msg
    assert "DB_NAME" in msg
    assert "DB_USERNAME" in msg
    # Error must point the operator at the runbook.
    assert "Azure Entra ID" in msg


def test_get_credential_provider_azure_entra_returns_azure_provider(
    azure_env, monkeypatch
):
    # P11 makes azure_entra a real provider, not a stub.
    monkeypatch.setenv("DB_CREDENTIAL_PROVIDER", "azure_entra")

    # Patch at the import site so no real DefaultAzureCredential is
    # constructed (which would trigger Azure SDK network probes).
    fake_azure_identity = MagicMock()
    fake_azure_identity.DefaultAzureCredential.return_value = MagicMock()
    import sys

    monkeypatch.setitem(sys.modules, "azure.identity", fake_azure_identity)

    provider = get_credential_provider()
    assert isinstance(provider, AzureEntraCredentialProvider)
    assert provider.supports_rotation() is True
    fake_azure_identity.DefaultAzureCredential.assert_called_once_with()
