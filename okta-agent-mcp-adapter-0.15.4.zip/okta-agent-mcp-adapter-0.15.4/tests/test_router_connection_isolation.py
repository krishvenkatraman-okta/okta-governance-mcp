"""
Tests for agent-scoped resource routing via resolve_resource().

Covers:
- Agent A resolves to own scopes
- Agent B resolves to own scopes
- Agent A cannot resolve Agent B-only resources
- Local resource available to all agents
- Agent-scoped resource takes precedence over unscoped syncer
- No agent_id falls back to local/syncer
- ResolvedResourceConfigAdapter exposes agent_id, connection_id, isolation_key
"""

import pytest
from unittest.mock import MagicMock, patch

from okta_agent_proxy.config import BackendConfig, BackendAuthConfig
from okta_agent_proxy.routing.router import ResourceRouter, ResolvedResourceConfigAdapter
from okta_agent_proxy.resources.models import (
    OktaConnectionType,
    OktaScopeCondition,
    ResolvedResource,
)


# ============================================================================
# Fixtures
# ============================================================================


def _make_resolved(
    name,
    agent_id=None,
    agent_name=None,
    connection_id="conn-1",
    scopes=None,
    mcp_url=None,
):
    return ResolvedResource(
        resource_id=f"aus-{name}",
        name=name,
        mcp_url=mcp_url or f"https://{name}.example.com/mcp",
        connection_id=connection_id,
        connection_type=OktaConnectionType.IDENTITY_ASSERTION_CUSTOM_AS,
        agent_id=agent_id,
        agent_name=agent_name,
        scopes=scopes or [],
    )


def _make_router_with_syncer(syncer_mock, static_resources=None):
    """Create a ResourceRouter with a mocked syncer and no store."""
    router = ResourceRouter(
        resources_config=static_resources or {},
        store=None,
        syncer=syncer_mock,
    )
    return router


# ============================================================================
# resolve_resource() tests
# ============================================================================


class TestResolveResource:

    def test_agent_a_gets_own_resource(self):
        """Agent A resolves to its own scoped resource with scopes=["read:employees"]."""
        r_a = _make_resolved(
            "hr-system", agent_id="agent-a", connection_id="conn-a",
            scopes=["read:employees"],
        )
        syncer = MagicMock()
        syncer.get_resolved_resources_for_agent.return_value = {"hr-system": r_a}
        syncer.get_resource.return_value = r_a

        router = _make_router_with_syncer(syncer)
        config = router.resolve_resource("hr-system", agent_id="agent-a")

        assert config is not None
        assert config.name == "hr-system"
        assert config.scopes == ["read:employees"]
        assert config.agent_id == "agent-a"
        syncer.get_resolved_resources_for_agent.assert_called_once_with("agent-a")

    def test_agent_b_gets_own_resource(self):
        """Agent B resolves to its own scoped resource with scopes=["read:payroll"]."""
        r_b = _make_resolved(
            "hr-system", agent_id="agent-b", connection_id="conn-b",
            scopes=["read:payroll"],
        )
        syncer = MagicMock()
        syncer.get_resolved_resources_for_agent.return_value = {"hr-system": r_b}
        syncer.get_resource.return_value = r_b

        router = _make_router_with_syncer(syncer)
        config = router.resolve_resource("hr-system", agent_id="agent-b")

        assert config is not None
        assert config.scopes == ["read:payroll"]
        assert config.agent_id == "agent-b"

    def test_agent_a_cannot_resolve_agent_b_only_resource(self):
        """Agent A cannot resolve a resource only available to Agent B."""
        syncer = MagicMock()
        # Agent A has no resources
        syncer.get_resolved_resources_for_agent.return_value = {}
        syncer.get_resource.return_value = None

        router = _make_router_with_syncer(syncer)
        config = router.resolve_resource("finance-system", agent_id="agent-a")

        assert config is None

    def test_local_resource_available_to_all_agents(self):
        """A locally-configured (static) resource is available regardless of agent_id."""
        static_config = BackendConfig(
            name="internal-api",
            url="https://internal.example.com/mcp",
            paths=["/internal"],
            auth_method="pre-shared-key",
            auth_config=BackendAuthConfig(),
        )
        syncer = MagicMock()
        syncer.get_resolved_resources_for_agent.return_value = {}
        syncer.get_resource.return_value = None

        router = _make_router_with_syncer(syncer, static_resources={"internal-api": static_config})
        config = router.resolve_resource("internal-api", agent_id="agent-x")

        assert config is not None
        assert config.name == "internal-api"

    def test_agent_scoped_resource_takes_precedence_over_unscoped(self):
        """Agent-scoped entry is preferred over unscoped syncer fallback."""
        r_scoped = _make_resolved(
            "hr-system", agent_id="agent-a", connection_id="conn-a",
            scopes=["read:employees"],
        )
        r_unscoped = _make_resolved("hr-system", connection_id="conn-generic")

        syncer = MagicMock()
        syncer.get_resolved_resources_for_agent.return_value = {"hr-system": r_scoped}
        syncer.get_resource.return_value = r_unscoped  # Would be used without agent scoping

        router = _make_router_with_syncer(syncer)
        config = router.resolve_resource("hr-system", agent_id="agent-a")

        assert config is not None
        assert config.agent_id == "agent-a"
        assert config.scopes == ["read:employees"]

    def test_no_agent_id_falls_back_to_syncer(self):
        """No agent_id → syncer unscoped lookup."""
        r = _make_resolved("hr-system", connection_id="conn-1")
        syncer = MagicMock()
        syncer.get_resource.return_value = r

        router = _make_router_with_syncer(syncer)
        config = router.resolve_resource("hr-system")

        assert config is not None
        assert config.name == "hr-system"
        syncer.get_resolved_resources_for_agent.assert_not_called()

    def test_no_agent_id_falls_back_to_local(self):
        """No agent_id, no syncer match → static config."""
        static_config = BackendConfig(
            name="api-target",
            url="https://api.example.com",
            paths=[],
            auth_method="pre-shared-key",
            auth_config=BackendAuthConfig(),
        )
        syncer = MagicMock()
        syncer.get_resource.return_value = None

        router = _make_router_with_syncer(syncer, static_resources={"api-target": static_config})
        config = router.resolve_resource("api-target")

        assert config is not None
        assert config.name == "api-target"

    def test_nonexistent_resource_returns_none(self):
        """Completely unknown resource returns None."""
        syncer = MagicMock()
        syncer.get_resolved_resources_for_agent.return_value = {}
        syncer.get_resource.return_value = None

        router = _make_router_with_syncer(syncer)
        config = router.resolve_resource("does-not-exist", agent_id="agent-a")

        assert config is None


# ============================================================================
# ResolvedResourceConfigAdapter property tests
# ============================================================================


class TestAdapterProperties:

    def test_adapter_exposes_agent_id(self):
        r = _make_resolved("hr-system", agent_id="agent-abc", connection_id="conn-1")
        adapter = ResolvedResourceConfigAdapter(r)
        assert adapter.agent_id == "agent-abc"

    def test_adapter_exposes_connection_id(self):
        r = _make_resolved("hr-system", agent_id="agent-abc", connection_id="conn-xyz")
        adapter = ResolvedResourceConfigAdapter(r)
        assert adapter.connection_id == "conn-xyz"

    def test_adapter_exposes_isolation_key(self):
        r = _make_resolved("hr-system", agent_id="agent-abc", connection_id="conn-xyz")
        adapter = ResolvedResourceConfigAdapter(r)
        assert adapter.isolation_key == "agent-abc:conn-xyz:hr-system"

    def test_adapter_agent_id_none_for_local(self):
        r = _make_resolved("hr-system", connection_id="conn-1")
        adapter = ResolvedResourceConfigAdapter(r)
        assert adapter.agent_id is None

    def test_adapter_isolation_key_without_agent(self):
        r = _make_resolved("hr-system", connection_id="conn-1")
        adapter = ResolvedResourceConfigAdapter(r)
        assert adapter.isolation_key == "conn-1:hr-system"
