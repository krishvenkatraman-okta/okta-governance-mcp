"""Tests for OktaServiceAuth (private_key_jwt client_credentials flow)."""

import asyncio
import json
import time
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from okta_agent_proxy.auth.okta_service_auth import OktaServiceAuth, DEFAULT_SCOPES


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _make_jwk():
    """Generate a real RSA JWK for testing."""
    from okta_agent_proxy.auth.adapter_cimd import _generate_rsa_keypair
    return _generate_rsa_keypair()


def _mock_token_response(access_token="tok_service_123", expires_in=3600, status_code=200):
    """Create a mock httpx response."""
    resp = MagicMock()
    resp.status_code = status_code
    resp.json.return_value = {
        "access_token": access_token,
        "token_type": "Bearer",
        "expires_in": expires_in,
        "scope": " ".join(DEFAULT_SCOPES),
    }
    resp.text = json.dumps(resp.json.return_value)
    return resp


# ---------------------------------------------------------------------------
# Not configured
# ---------------------------------------------------------------------------

class TestNotConfigured:
    """Service auth returns None gracefully when not configured."""

    @pytest.mark.asyncio
    async def test_no_client_id_returns_none(self, monkeypatch):
        monkeypatch.delenv("OKTA_SERVICE_CLIENT_ID", raising=False)
        monkeypatch.setenv("OKTA_DOMAIN", "dev-test.okta.com")
        auth = OktaServiceAuth()
        assert await auth.get_access_token() is None

    @pytest.mark.asyncio
    async def test_no_domain_returns_none(self, monkeypatch):
        monkeypatch.setenv("OKTA_SERVICE_CLIENT_ID", "0oaXXX")
        monkeypatch.delenv("OKTA_DOMAIN", raising=False)
        auth = OktaServiceAuth()
        assert await auth.get_access_token() is None

    @pytest.mark.asyncio
    async def test_empty_client_id_returns_none(self, monkeypatch):
        monkeypatch.setenv("OKTA_SERVICE_CLIENT_ID", "")
        monkeypatch.setenv("OKTA_DOMAIN", "dev-test.okta.com")
        auth = OktaServiceAuth()
        assert await auth.get_access_token() is None


# ---------------------------------------------------------------------------
# JWT assertion
# ---------------------------------------------------------------------------

class TestJWTAssertion:
    """JWT assertion is built correctly per RFC 7523."""

    def test_assertion_claims(self, monkeypatch):
        monkeypatch.setenv("OKTA_SERVICE_CLIENT_ID", "0oaABC123")
        monkeypatch.setenv("OKTA_DOMAIN", "dev-test.okta.com")
        monkeypatch.delenv("ADAPTER_SIGNING_KEY", raising=False)

        jwk = _make_jwk()
        auth = OktaServiceAuth()
        auth._signing_key = jwk

        assertion = auth._generate_jwt_assertion(DEFAULT_SCOPES)
        assert assertion is not None

        from jose import jwt as jose_jwt
        claims = jose_jwt.get_unverified_claims(assertion)
        header = jose_jwt.get_unverified_header(assertion)

        assert claims["iss"] == "0oaABC123"
        assert claims["sub"] == "0oaABC123"
        assert claims["aud"] == "https://dev-test.okta.com/oauth2/v1/token"
        assert "jti" in claims
        assert "iat" in claims
        assert "exp" in claims
        assert claims["exp"] - claims["iat"] == 60
        assert header["alg"] == "RS256"
        assert header["kid"] == jwk["kid"]

    def test_assertion_with_https_domain(self, monkeypatch):
        monkeypatch.setenv("OKTA_SERVICE_CLIENT_ID", "0oaABC123")
        monkeypatch.setenv("OKTA_DOMAIN", "https://dev-test.okta.com")
        monkeypatch.delenv("ADAPTER_SIGNING_KEY", raising=False)

        auth = OktaServiceAuth()
        auth._signing_key = _make_jwk()

        assertion = auth._generate_jwt_assertion(DEFAULT_SCOPES)
        from jose import jwt as jose_jwt
        claims = jose_jwt.get_unverified_claims(assertion)
        assert claims["aud"] == "https://dev-test.okta.com/oauth2/v1/token"

    def test_no_signing_key_returns_none(self, monkeypatch):
        monkeypatch.setenv("OKTA_SERVICE_CLIENT_ID", "0oaABC123")
        monkeypatch.setenv("OKTA_DOMAIN", "dev-test.okta.com")
        monkeypatch.delenv("ADAPTER_SIGNING_KEY", raising=False)

        auth = OktaServiceAuth()
        # Prevent fallback to AdapterCIMDServer
        with patch.object(auth, "_load_signing_key", return_value=None):
            assertion = auth._generate_jwt_assertion(DEFAULT_SCOPES)
        assert assertion is None


# ---------------------------------------------------------------------------
# Token acquisition
# ---------------------------------------------------------------------------

class TestGetAccessToken:
    """get_access_token makes correct HTTP request and caches."""

    @pytest.mark.asyncio
    async def test_successful_token_request(self, monkeypatch):
        monkeypatch.setenv("OKTA_SERVICE_CLIENT_ID", "0oaABC123")
        monkeypatch.setenv("OKTA_DOMAIN", "dev-test.okta.com")
        monkeypatch.delenv("ADAPTER_SIGNING_KEY", raising=False)

        auth = OktaServiceAuth()
        auth._signing_key = _make_jwk()

        mock_resp = _mock_token_response()

        mock_client = AsyncMock()
        mock_client.post = AsyncMock(return_value=mock_resp)
        mock_client.__aenter__ = AsyncMock(return_value=mock_client)
        mock_client.__aexit__ = AsyncMock(return_value=False)

        with patch("okta_agent_proxy.auth.okta_service_auth.httpx") as mock_httpx:
            mock_httpx.AsyncClient.return_value = mock_client
            token = await auth.get_access_token()

        assert token == "tok_service_123"

        # Verify POST parameters
        call_args = mock_client.post.call_args
        assert call_args[0][0] == "https://dev-test.okta.com/oauth2/v1/token"
        post_data = call_args[1]["data"]
        assert post_data["grant_type"] == "client_credentials"
        assert post_data["client_id"] == "0oaABC123"
        assert post_data["client_assertion_type"] == "urn:ietf:params:oauth:client-assertion-type:jwt-bearer"
        assert "client_assertion" in post_data
        assert post_data["scope"] == " ".join(DEFAULT_SCOPES)

    @pytest.mark.asyncio
    async def test_custom_scopes(self, monkeypatch):
        monkeypatch.setenv("OKTA_SERVICE_CLIENT_ID", "0oaABC123")
        monkeypatch.setenv("OKTA_DOMAIN", "dev-test.okta.com")
        monkeypatch.delenv("ADAPTER_SIGNING_KEY", raising=False)

        auth = OktaServiceAuth()
        auth._signing_key = _make_jwk()

        mock_resp = _mock_token_response()
        mock_client = AsyncMock()
        mock_client.post = AsyncMock(return_value=mock_resp)
        mock_client.__aenter__ = AsyncMock(return_value=mock_client)
        mock_client.__aexit__ = AsyncMock(return_value=False)

        custom_scopes = ["okta.aiAgents.read"]
        with patch("okta_agent_proxy.auth.okta_service_auth.httpx") as mock_httpx:
            mock_httpx.AsyncClient.return_value = mock_client
            token = await auth.get_access_token(scopes=custom_scopes)

        assert token == "tok_service_123"
        post_data = mock_client.post.call_args[1]["data"]
        assert post_data["scope"] == "okta.aiAgents.read"


# ---------------------------------------------------------------------------
# Token caching
# ---------------------------------------------------------------------------

class TestTokenCaching:
    """Token is cached and reused until near expiry."""

    @pytest.mark.asyncio
    async def test_second_call_uses_cache(self, monkeypatch):
        monkeypatch.setenv("OKTA_SERVICE_CLIENT_ID", "0oaABC123")
        monkeypatch.setenv("OKTA_DOMAIN", "dev-test.okta.com")
        monkeypatch.delenv("ADAPTER_SIGNING_KEY", raising=False)

        auth = OktaServiceAuth()
        auth._signing_key = _make_jwk()

        mock_resp = _mock_token_response()
        mock_client = AsyncMock()
        mock_client.post = AsyncMock(return_value=mock_resp)
        mock_client.__aenter__ = AsyncMock(return_value=mock_client)
        mock_client.__aexit__ = AsyncMock(return_value=False)

        with patch("okta_agent_proxy.auth.okta_service_auth.httpx") as mock_httpx:
            mock_httpx.AsyncClient.return_value = mock_client
            token1 = await auth.get_access_token()
            token2 = await auth.get_access_token()

        assert token1 == token2 == "tok_service_123"
        # Only one HTTP call — second used cache
        assert mock_client.post.call_count == 1

    @pytest.mark.asyncio
    async def test_expired_cache_triggers_refresh(self, monkeypatch):
        monkeypatch.setenv("OKTA_SERVICE_CLIENT_ID", "0oaABC123")
        monkeypatch.setenv("OKTA_DOMAIN", "dev-test.okta.com")
        monkeypatch.delenv("ADAPTER_SIGNING_KEY", raising=False)

        auth = OktaServiceAuth()
        auth._signing_key = _make_jwk()

        # First response — short-lived token
        mock_resp1 = _mock_token_response(access_token="tok_1", expires_in=3600)
        mock_resp2 = _mock_token_response(access_token="tok_2", expires_in=3600)

        mock_client = AsyncMock()
        mock_client.post = AsyncMock(side_effect=[mock_resp1, mock_resp2])
        mock_client.__aenter__ = AsyncMock(return_value=mock_client)
        mock_client.__aexit__ = AsyncMock(return_value=False)

        with patch("okta_agent_proxy.auth.okta_service_auth.httpx") as mock_httpx:
            mock_httpx.AsyncClient.return_value = mock_client

            token1 = await auth.get_access_token()
            assert token1 == "tok_1"

            # Simulate expiry
            auth._token_expiry = time.time() - 1

            token2 = await auth.get_access_token()
            assert token2 == "tok_2"

        assert mock_client.post.call_count == 2


# ---------------------------------------------------------------------------
# Error handling
# ---------------------------------------------------------------------------

class TestErrorHandling:
    """Errors return None and log, never raise."""

    @pytest.mark.asyncio
    async def test_401_returns_none(self, monkeypatch):
        monkeypatch.setenv("OKTA_SERVICE_CLIENT_ID", "0oaABC123")
        monkeypatch.setenv("OKTA_DOMAIN", "dev-test.okta.com")
        monkeypatch.delenv("ADAPTER_SIGNING_KEY", raising=False)

        auth = OktaServiceAuth()
        auth._signing_key = _make_jwk()

        mock_resp = _mock_token_response(status_code=401)
        mock_resp.text = '{"error":"invalid_client"}'

        mock_client = AsyncMock()
        mock_client.post = AsyncMock(return_value=mock_resp)
        mock_client.__aenter__ = AsyncMock(return_value=mock_client)
        mock_client.__aexit__ = AsyncMock(return_value=False)

        with patch("okta_agent_proxy.auth.okta_service_auth.httpx") as mock_httpx:
            mock_httpx.AsyncClient.return_value = mock_client
            token = await auth.get_access_token()

        assert token is None

    @pytest.mark.asyncio
    async def test_network_error_returns_none(self, monkeypatch):
        monkeypatch.setenv("OKTA_SERVICE_CLIENT_ID", "0oaABC123")
        monkeypatch.setenv("OKTA_DOMAIN", "dev-test.okta.com")
        monkeypatch.delenv("ADAPTER_SIGNING_KEY", raising=False)

        auth = OktaServiceAuth()
        auth._signing_key = _make_jwk()

        mock_client = AsyncMock()
        mock_client.post = AsyncMock(side_effect=Exception("Connection refused"))
        mock_client.__aenter__ = AsyncMock(return_value=mock_client)
        mock_client.__aexit__ = AsyncMock(return_value=False)

        with patch("okta_agent_proxy.auth.okta_service_auth.httpx") as mock_httpx:
            mock_httpx.AsyncClient.return_value = mock_client
            token = await auth.get_access_token()

        assert token is None

    @pytest.mark.asyncio
    async def test_403_returns_none(self, monkeypatch):
        monkeypatch.setenv("OKTA_SERVICE_CLIENT_ID", "0oaABC123")
        monkeypatch.setenv("OKTA_DOMAIN", "dev-test.okta.com")
        monkeypatch.delenv("ADAPTER_SIGNING_KEY", raising=False)

        auth = OktaServiceAuth()
        auth._signing_key = _make_jwk()

        mock_resp = _mock_token_response(status_code=403)
        mock_resp.text = '{"error":"insufficient_scope"}'

        mock_client = AsyncMock()
        mock_client.post = AsyncMock(return_value=mock_resp)
        mock_client.__aenter__ = AsyncMock(return_value=mock_client)
        mock_client.__aexit__ = AsyncMock(return_value=False)

        with patch("okta_agent_proxy.auth.okta_service_auth.httpx") as mock_httpx:
            mock_httpx.AsyncClient.return_value = mock_client
            token = await auth.get_access_token()

        assert token is None


# ---------------------------------------------------------------------------
# Signing key loading
# ---------------------------------------------------------------------------

class TestSigningKeyLoading:
    """Signing key loaded from env var or adapter CIMD fallback."""

    def test_load_from_env_jwk(self, monkeypatch):
        jwk = _make_jwk()
        monkeypatch.setenv("OKTA_SERVICE_CLIENT_ID", "0oaABC123")
        monkeypatch.setenv("OKTA_DOMAIN", "dev-test.okta.com")
        monkeypatch.setenv("ADAPTER_SIGNING_KEY", json.dumps(jwk))

        auth = OktaServiceAuth()
        loaded = auth._load_signing_key()
        assert loaded is not None
        assert loaded["kid"] == jwk["kid"]
        assert loaded["kty"] == "RSA"

    def test_fallback_to_adapter_cimd(self, monkeypatch):
        monkeypatch.setenv("OKTA_SERVICE_CLIENT_ID", "0oaABC123")
        monkeypatch.setenv("OKTA_DOMAIN", "dev-test.okta.com")
        monkeypatch.delenv("ADAPTER_SIGNING_KEY", raising=False)

        auth = OktaServiceAuth()
        # AdapterCIMDServer will auto-generate a key
        loaded = auth._load_signing_key()
        assert loaded is not None
        assert "kid" in loaded
        assert loaded["kty"] == "RSA"
