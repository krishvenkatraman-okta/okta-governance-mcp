"""Tests for the two-role bootstrap SQL script (P09).

Exercises ``deploy/migrations/sql/bootstrap_roles.sql`` end-to-end against a
throwaway Postgres database. Each test creates a fresh DB + fresh role names
so runs are isolated and cleanup is deterministic.

Requires a reachable superuser Postgres. By default this is the throwaway
``postgres:15`` container started alongside P02/P03 on port 55432 with
credentials ``postgres:test``. Override via the ``TEST_PG_ADMIN_URL`` env
var. Tests that need a live database are skipped when one is not reachable
so the suite stays portable.

To spin up a compatible container locally:

    docker run -d --rm --name pg-test-p09 \
        -e POSTGRES_PASSWORD=test -p 55432:5432 postgres:15
"""

from __future__ import annotations

import os
import shutil
import subprocess
import uuid
from pathlib import Path
from typing import Iterator, Tuple

import psycopg
import pytest


REPO_ROOT = Path(__file__).resolve().parents[1]
BOOTSTRAP_SQL = REPO_ROOT / "deploy" / "migrations" / "sql" / "bootstrap_roles.sql"
DEFAULT_ADMIN_URL = "postgresql://postgres:test@localhost:55432/postgres"


def _admin_url() -> str:
    return os.environ.get("TEST_PG_ADMIN_URL", DEFAULT_ADMIN_URL)


def _postgres_reachable(url: str) -> bool:
    try:
        with psycopg.connect(url, connect_timeout=2) as conn:
            with conn.cursor() as cur:
                cur.execute("SELECT 1")
                cur.fetchone()
        return True
    except Exception:
        return False


def _psql_available() -> bool:
    return shutil.which("psql") is not None


@pytest.fixture(scope="session")
def admin_url() -> str:
    if not _psql_available():
        pytest.skip(
            "psql is not on PATH; bootstrap_roles.sql is a psql script and "
            "cannot be exercised without the client binary."
        )
    url = _admin_url()
    if not _postgres_reachable(url):
        pytest.skip(
            f"No reachable superuser Postgres at {url}. "
            f"Start one with: docker run -d --rm --name pg-test-p09 "
            f"-e POSTGRES_PASSWORD=test -p 55432:5432 postgres:15"
        )
    return url


def _parts(url: str) -> dict:
    return psycopg.conninfo.conninfo_to_dict(url)


def _url_for(admin_url: str, *, dbname: str, user: str, password: str = "") -> str:
    p = _parts(admin_url)
    p["dbname"] = dbname
    p["user"] = user
    if password:
        p["password"] = password
    else:
        p.pop("password", None)
    return psycopg.conninfo.make_conninfo(**p)


def _run_bootstrap(admin_url: str, *, dbname: str, owner: str, app: str) -> subprocess.CompletedProcess:
    p = _parts(admin_url)
    env = os.environ.copy()
    env["PGPASSWORD"] = p.get("password", "")
    env["DB_OWNER_ROLE"] = owner
    env["DB_APP_ROLE"] = app
    env["DB_NAME"] = dbname
    cmd = [
        "psql",
        "-h", p.get("host", "localhost"),
        "-p", str(p.get("port", 5432)),
        "-U", p.get("user", "postgres"),
        "-d", dbname,
        "-v", "ON_ERROR_STOP=1",
        "-f", str(BOOTSTRAP_SQL),
    ]
    return subprocess.run(cmd, env=env, capture_output=True, text=True, timeout=30)


@pytest.fixture()
def bootstrapped_db(admin_url: str) -> Iterator[Tuple[str, str, str, str]]:
    """Create DB + two roles via bootstrap_roles.sql; yield (db_url, db_name,
    owner, app). Cleans up on teardown."""
    suffix = uuid.uuid4().hex[:10]
    db_name = f"p09_db_{suffix}"
    owner = f"p09_owner_{suffix}"
    app = f"p09_app_{suffix}"
    admin_parts = _parts(admin_url)

    with psycopg.connect(admin_url, autocommit=True) as conn:
        with conn.cursor() as cur:
            cur.execute(f'CREATE DATABASE "{db_name}"')

    try:
        result = _run_bootstrap(admin_url, dbname=db_name, owner=owner, app=app)
        assert result.returncode == 0, (
            f"bootstrap_roles.sql failed (rc={result.returncode})\n"
            f"STDOUT:\n{result.stdout}\nSTDERR:\n{result.stderr}"
        )
        # Give the roles a password so tests can log in as them. ALTER ROLE
        # does not accept parameterized passwords, so compose a literal SQL
        # statement via psycopg.sql (safe: owner/app come from uuid4, password
        # is a hardcoded test constant).
        from psycopg import sql

        with psycopg.connect(admin_url, autocommit=True) as conn:
            with conn.cursor() as cur:
                cur.execute(
                    sql.SQL("ALTER ROLE {} WITH PASSWORD {}").format(
                        sql.Identifier(owner), sql.Literal("owner_pw")
                    )
                )
                cur.execute(
                    sql.SQL("ALTER ROLE {} WITH PASSWORD {}").format(
                        sql.Identifier(app), sql.Literal("app_pw")
                    )
                )
        db_admin_url = _url_for(
            admin_url,
            dbname=db_name,
            user=admin_parts.get("user", "postgres"),
            password=admin_parts.get("password", ""),
        )
        yield (db_admin_url, db_name, owner, app)
    finally:
        # Terminate connections, then strip dependencies and drop.
        with psycopg.connect(admin_url, autocommit=True) as conn:
            with conn.cursor() as cur:
                cur.execute(
                    "SELECT pg_terminate_backend(pid) FROM pg_stat_activity "
                    "WHERE datname = %s AND pid <> pg_backend_pid()",
                    (db_name,),
                )
                cur.execute(f'DROP DATABASE IF EXISTS "{db_name}"')
                # Default privileges are attached to the owner role; revoke
                # before dropping so the DROP ROLE succeeds.
                for stmt in (
                    f'ALTER DEFAULT PRIVILEGES FOR ROLE "{owner}" IN SCHEMA public '
                    f'REVOKE SELECT, INSERT, UPDATE, DELETE ON TABLES FROM "{app}"',
                    f'ALTER DEFAULT PRIVILEGES FOR ROLE "{owner}" IN SCHEMA public '
                    f'REVOKE USAGE, SELECT ON SEQUENCES FROM "{app}"',
                    f'REVOKE ALL ON SCHEMA public FROM "{app}"',
                    f'DROP ROLE IF EXISTS "{owner}"',
                    f'DROP ROLE IF EXISTS "{app}"',
                ):
                    try:
                        cur.execute(stmt)
                    except psycopg.Error:
                        pass


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------


def test_bootstrap_roles_idempotent(bootstrapped_db, admin_url):
    """Re-running the script must be a no-op (no duplicate-role errors)."""
    db_admin_url, db_name, owner, app = bootstrapped_db
    result = _run_bootstrap(admin_url, dbname=db_name, owner=owner, app=app)
    assert result.returncode == 0, (
        f"Second bootstrap run failed (rc={result.returncode})\n"
        f"STDOUT:\n{result.stdout}\nSTDERR:\n{result.stderr}"
    )
    with psycopg.connect(db_admin_url) as conn:
        with conn.cursor() as cur:
            cur.execute(
                "SELECT COUNT(*) FROM pg_roles WHERE rolname IN (%s, %s)",
                (owner, app),
            )
            assert cur.fetchone()[0] == 2


def test_app_role_cannot_create_table(bootstrapped_db, admin_url):
    """The app role must NOT be able to create tables in the public schema."""
    db_admin_url, db_name, owner, app = bootstrapped_db
    app_url = _url_for(admin_url, dbname=db_name, user=app, password="app_pw")
    with psycopg.connect(app_url) as conn:
        with conn.cursor() as cur:
            with pytest.raises(psycopg.errors.InsufficientPrivilege):
                cur.execute("CREATE TABLE forbidden (id INT)")


def test_app_role_can_select_insert_update_delete(bootstrapped_db, admin_url):
    """Owner creates a table; app role must be able to DML against it."""
    db_admin_url, db_name, owner, app = bootstrapped_db
    # Owner creates a table (exercises default privileges → app).
    owner_url = _url_for(admin_url, dbname=db_name, user=owner, password="owner_pw")
    with psycopg.connect(owner_url) as conn:
        with conn.cursor() as cur:
            cur.execute(
                "CREATE TABLE widgets (id SERIAL PRIMARY KEY, name TEXT NOT NULL)"
            )
        conn.commit()

    # App role can DML.
    app_url = _url_for(admin_url, dbname=db_name, user=app, password="app_pw")
    with psycopg.connect(app_url) as conn:
        with conn.cursor() as cur:
            cur.execute("INSERT INTO widgets (name) VALUES (%s) RETURNING id", ("sprocket",))
            new_id = cur.fetchone()[0]
            cur.execute("SELECT name FROM widgets WHERE id = %s", (new_id,))
            assert cur.fetchone()[0] == "sprocket"
            cur.execute("UPDATE widgets SET name = %s WHERE id = %s", ("gadget", new_id))
            cur.execute("SELECT name FROM widgets WHERE id = %s", (new_id,))
            assert cur.fetchone()[0] == "gadget"
            cur.execute("DELETE FROM widgets WHERE id = %s", (new_id,))
            cur.execute("SELECT COUNT(*) FROM widgets")
            assert cur.fetchone()[0] == 0
        conn.commit()


def test_owner_role_can_create_table_and_app_inherits_privileges(
    bootstrapped_db, admin_url
):
    """Default privileges: a table created by owner AFTER bootstrap must be
    readable + writable by app without any additional GRANTs."""
    db_admin_url, db_name, owner, app = bootstrapped_db
    owner_url = _url_for(admin_url, dbname=db_name, user=owner, password="owner_pw")
    with psycopg.connect(owner_url) as conn:
        with conn.cursor() as cur:
            cur.execute("CREATE TABLE late_arrival (id SERIAL PRIMARY KEY, v TEXT)")
        conn.commit()

    app_url = _url_for(admin_url, dbname=db_name, user=app, password="app_pw")
    with psycopg.connect(app_url) as conn:
        with conn.cursor() as cur:
            # No explicit GRANT was issued post-CREATE — default privileges
            # alone must carry these.
            cur.execute("INSERT INTO late_arrival (v) VALUES (%s)", ("hello",))
            cur.execute("SELECT v FROM late_arrival")
            assert cur.fetchone()[0] == "hello"
        conn.commit()


# ---------------------------------------------------------------------------
# credentials.py owner-role warning
# ---------------------------------------------------------------------------


def test_static_provider_warns_when_user_is_owner_role(monkeypatch, caplog):
    """StaticUrlCredentialProvider must log a warning if DATABASE_URL points
    at the migration owner role — the adapter should run as the DML app role.
    """
    import logging

    from okta_agent_proxy.storage.credentials import StaticUrlCredentialProvider

    monkeypatch.delenv("DB_OWNER_ROLE", raising=False)
    monkeypatch.delenv("DB_APP_ROLE", raising=False)
    with caplog.at_level(logging.WARNING, logger="okta_agent_proxy.storage.credentials"):
        StaticUrlCredentialProvider(
            "postgresql://okta_adapter_owner:secret@db/gateway_db"
        )
    assert any(
        "migration owner role" in rec.message for rec in caplog.records
    ), f"expected warning; got: {[r.message for r in caplog.records]}"


def test_static_provider_no_warning_when_user_is_app_role(monkeypatch, caplog):
    import logging

    from okta_agent_proxy.storage.credentials import StaticUrlCredentialProvider

    monkeypatch.delenv("DB_OWNER_ROLE", raising=False)
    monkeypatch.delenv("DB_APP_ROLE", raising=False)
    with caplog.at_level(logging.WARNING, logger="okta_agent_proxy.storage.credentials"):
        StaticUrlCredentialProvider(
            "postgresql://okta_adapter_app:secret@db/gateway_db"
        )
    assert not any(
        "migration owner role" in rec.message for rec in caplog.records
    )


def test_static_provider_respects_custom_owner_env(monkeypatch, caplog):
    """If DB_OWNER_ROLE is customized, warn when the URL user matches it."""
    import logging

    from okta_agent_proxy.storage.credentials import StaticUrlCredentialProvider

    monkeypatch.setenv("DB_OWNER_ROLE", "custom_owner")
    with caplog.at_level(logging.WARNING, logger="okta_agent_proxy.storage.credentials"):
        StaticUrlCredentialProvider(
            "postgresql://custom_owner:secret@db/gateway_db"
        )
    assert any(
        "migration owner role" in rec.message for rec in caplog.records
    ), f"expected warning; got: {[r.message for r in caplog.records]}"
