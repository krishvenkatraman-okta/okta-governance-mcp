"""End-to-end RFC 8414 §3.3 compliance tests (prompt R6).

This test file is the programmatic equivalent of the security-review
round-trip check documented in ``docs/prompts/RFC8414_ISSUER_FIX_PROMPTS.md``.

The §3.3 contract is:

    PRM.authorization_servers[0]  byte-equals  AS_metadata.issuer
    and both equal GATEWAY_BASE_URL.

If any test here fails, §3.3 compliance has regressed and the original
security finding reopens. The tests exercise the full Starlette application
via ``TestClient`` with external dependencies (Okta JWKS, DB, client
registry) mocked so the suite runs offline.
"""

import json
import sys
from unittest.mock import AsyncMock, MagicMock, patch

import pytest
from starlette.testclient import TestClient

from okta_agent_proxy.audit.events import AuditEventType


GATEWAY_BASE_URL = "http://localhost:8000"
OKTA_DOMAIN = "dev-test.okta.com"
OKTA_ISSUER = f"https://{OKTA_DOMAIN}/oauth2/default"

SAMPLE_JWKS = {
    "keys": [
        {
            "kty": "RSA",
            "alg": "RS256",
            "use": "sig",
            "kid": "test-kid-rfc8414",
            "n": "AQAB-base64-modulus",
            "e": "AQAB",
        }
    ]
}


# ---------------------------------------------------------------------------
# App import helper (mirrors pattern used in tests/test_oauth_discovery.py)
# ---------------------------------------------------------------------------

def _ensure_app_imported():
    mod = sys.modules.get("okta_agent_proxy.app")
    if mod is not None and hasattr(mod, "oauth_authorization_server"):
        return

    sys.modules.pop("okta_agent_proxy.app", None)

    import okta_agent_proxy.database as _db_mod
    _orig_get = _db_mod.get_config_store
    _orig_store = _db_mod._config_store
    _mock_store = MagicMock()
    _mock_store.get_all_resources.return_value = []
    _mock_store.get_all_agents.return_value = []
    _db_mod.get_config_store = lambda **kw: _mock_store
    _db_mod._config_store = _mock_store
    try:
        import importlib
        import okta_agent_proxy.app
        importlib.reload(okta_agent_proxy.app)
    except Exception:
        sys.modules.pop("okta_agent_proxy.app", None)
        raise
    finally:
        _db_mod.get_config_store = _orig_get
        _db_mod._config_store = _orig_store


@pytest.fixture
def client(monkeypatch):
    """Yield a TestClient backed by the full app with external deps mocked."""
    _ensure_app_imported()

    # oauth_protected_resource (root PRM) reads GATEWAY_BASE_URL from env at
    # request time; align with the patched config value so the §3.3 byte-
    # identity check holds.
    monkeypatch.setenv("GATEWAY_BASE_URL", GATEWAY_BASE_URL)
    monkeypatch.setenv("OKTA_ISSUER", OKTA_ISSUER)
    monkeypatch.setenv("OKTA_DOMAIN", OKTA_DOMAIN)

    patches = [
        patch("okta_agent_proxy.app.emit_audit_event", new_callable=AsyncMock),
        patch("okta_agent_proxy.app.config"),
        patch("okta_agent_proxy.app.router"),
        patch("okta_agent_proxy.app.validator"),
        patch("okta_agent_proxy.app.client_registry"),
        patch("okta_agent_proxy.app.dcr_handler"),
    ]
    started = [p.start() for p in patches]
    mocks = {
        "audit": started[0],
        "config": started[1],
        "router": started[2],
        "validator": started[3],
        "registry": started[4],
        "dcr": started[5],
    }

    mocks["config"].gateway.gateway_base_url = GATEWAY_BASE_URL
    mocks["config"].gateway.okta_domain = OKTA_DOMAIN

    # Router: default to no resource; per-test code may override for
    # per-resource discovery assertions.
    mocks["router"].get_resource_for_path = MagicMock(return_value=None)
    mocks["router"].resolve_resource = MagicMock(return_value=None)

    # JWKS proxy: pretend cache is empty and fetch returns a valid JWKS.
    mocks["validator"].jwks_cache = {}
    mocks["validator"]._jwks_cache_ttl = 3600
    mocks["validator"].fetch_jwks = AsyncMock(return_value=SAMPLE_JWKS)

    # oauth_authorize: traditional branch requires CIMD/DCR checks to fall
    # through. Both return "no match" so a plain opaque client_id reaches
    # the 302 redirect to Okta.
    mocks["registry"]._is_cimd_url = staticmethod(
        lambda cid: cid.startswith("https://") or cid.startswith("http://localhost")
    )
    mocks["registry"]._resolve_dcr = MagicMock(return_value=None)
    mocks["registry"].resolve = AsyncMock(return_value=None)

    mocks["dcr"].get_selectable_agents = MagicMock(return_value=[])

    from okta_agent_proxy import app as _app
    tc = TestClient(_app.app)

    yield tc, mocks

    for p in patches:
        p.stop()


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------

class TestRFC8414ComplianceE2E:
    """End-to-end round-trip tests for RFC 8414 §3.3 compliance."""

    def test_prm_authorization_servers_is_gateway_base_url(self, client):
        """PRM MUST advertise exactly one authorization_servers entry equal
        to GATEWAY_BASE_URL."""
        tc, _ = client
        resp = tc.get("/.well-known/oauth-protected-resource")
        assert resp.status_code == 200
        body = resp.json()
        assert isinstance(body["authorization_servers"], list)
        assert len(body["authorization_servers"]) == 1
        assert body["authorization_servers"][0] == GATEWAY_BASE_URL

    def test_byte_identity_contract_prm_matches_as_issuer(self, client):
        """§3.3 byte-identity: PRM.authorization_servers[0] MUST byte-equal
        AS_metadata.issuer.

        This is the core contract a spec-strict client enforces. Any
        normalization drift (scheme casing, trailing slash, port omission)
        would break this equality and cause clients to reject the metadata
        per §3.3's MUST NOT clause.
        """
        tc, _ = client

        prm = tc.get("/.well-known/oauth-protected-resource").json()
        prm_issuer = prm["authorization_servers"][0]

        as_meta = tc.get("/.well-known/oauth-authorization-server").json()
        as_issuer = as_meta["issuer"]

        # Byte-equal string comparison. No normalization.
        assert prm_issuer == as_issuer
        assert prm_issuer == GATEWAY_BASE_URL

    def test_as_metadata_is_self_consistent_under_gateway(self, client):
        """All advertised endpoints MUST live under GATEWAY_BASE_URL and
        the response MUST NOT leak Okta's domain anywhere."""
        tc, _ = client
        resp = tc.get("/.well-known/oauth-authorization-server")
        assert resp.status_code == 200
        body = resp.json()

        assert body["issuer"] == GATEWAY_BASE_URL
        for field in (
            "authorization_endpoint",
            "token_endpoint",
            "jwks_uri",
            "registration_endpoint",
        ):
            assert body[field].startswith(GATEWAY_BASE_URL), (
                f"{field} not under gateway: {body[field]}"
            )

        serialized = json.dumps(body)
        assert OKTA_DOMAIN not in serialized, (
            f"Okta domain leaked in AS metadata: {serialized}"
        )

    def test_all_advertised_endpoints_actually_respond(self, client):
        """Each URL advertised in AS metadata MUST resolve to a live
        handler on this origin."""
        tc, _ = client
        meta = tc.get("/.well-known/oauth-authorization-server").json()

        # jwks_uri: GET 200 with keys array
        jwks_path = meta["jwks_uri"].replace(GATEWAY_BASE_URL, "")
        jwks_resp = tc.get(jwks_path)
        assert jwks_resp.status_code == 200
        assert isinstance(jwks_resp.json()["keys"], list)
        assert len(jwks_resp.json()["keys"]) >= 1

        # registration_endpoint: GET returns a JSON document (200 or 501)
        reg_path = meta["registration_endpoint"].replace(GATEWAY_BASE_URL, "")
        reg_resp = tc.get(reg_path)
        assert reg_resp.status_code in (200, 501)

        # authorization_endpoint: missing client_id ⇒ 400 invalid_request
        auth_path = meta["authorization_endpoint"].replace(GATEWAY_BASE_URL, "")
        # Strip any pre-existing query string; the root handler's endpoint
        # is path-only, but be defensive in case a per-resource variant leaks in.
        auth_path_no_qs = auth_path.split("?", 1)[0]
        bad = tc.get(auth_path_no_qs)
        assert bad.status_code == 400
        assert bad.json()["error"] == "invalid_request"

        # authorization_endpoint: full OAuth params ⇒ 302 to Okta
        good = tc.get(
            auth_path_no_qs,
            params={
                "client_id": "test-client-id",
                "redirect_uri": "https://app.example.com/cb",
                "response_type": "code",
                "code_challenge": "E9Melhoa2OwvFrEMTJguCHaoeK1t8URWbuGJSstw-cM",
                "code_challenge_method": "S256",
                "state": "opaque-state",
            },
            follow_redirects=False,
        )
        assert good.status_code == 302
        assert good.headers["location"].startswith(OKTA_ISSUER)

    def test_per_resource_as_metadata_is_compliant(self, client):
        """The per-resource AS metadata handler MUST also be §3.3 compliant
        (issuer = gateway, all core endpoints on the gateway)."""
        tc, mocks = client
        mocks["router"].get_resource_for_path = MagicMock(return_value="hr")

        resp = tc.get("/.well-known/oauth-authorization-server/hr")
        assert resp.status_code == 200
        body = resp.json()

        assert body["issuer"] == GATEWAY_BASE_URL
        assert body["jwks_uri"] == f"{GATEWAY_BASE_URL}/oauth2/v1/keys"
        # authorization_endpoint includes a scope query param; assert prefix only
        assert body["authorization_endpoint"].startswith(
            f"{GATEWAY_BASE_URL}/oauth/authorize"
        )
        assert body["token_endpoint"] == f"{GATEWAY_BASE_URL}/oauth2/v1/token"

        serialized = json.dumps(body)
        assert OKTA_DOMAIN not in serialized, (
            f"Okta domain leaked in per-resource AS metadata: {serialized}"
        )

    def test_per_resource_prm_points_at_gateway(self, client):
        """Per-resource PRM MUST advertise the gateway as the AS and the
        resource URL under the gateway origin."""
        tc, mocks = client
        mocks["router"].get_resource_for_path = MagicMock(return_value="hr")

        resp = tc.get("/.well-known/oauth-protected-resource/hr")
        assert resp.status_code == 200
        body = resp.json()

        assert body["authorization_servers"][0] == GATEWAY_BASE_URL
        assert body["resource"].startswith(GATEWAY_BASE_URL)
        # resource MUST be the specific per-path resource, not the root
        assert body["resource"] == f"{GATEWAY_BASE_URL}/hr"

    def test_discovery_emits_oauth_discovery_served_audit_event(self, client):
        """Both discovery handlers MUST emit OAUTH_DISCOVERY_SERVED so the
        metadata read pattern is observable in SIEM."""
        tc, mocks = client

        tc.get("/.well-known/oauth-authorization-server")
        mocks["router"].get_resource_for_path = MagicMock(return_value="hr")
        tc.get("/.well-known/oauth-authorization-server/hr")

        served_events = [
            c for c in mocks["audit"].call_args_list
            if c.args and c.args[0] == AuditEventType.OAUTH_DISCOVERY_SERVED
        ]
        assert len(served_events) == 2
        endpoints = {c.kwargs["details"]["endpoint"] for c in served_events}
        assert endpoints == {
            "oauth-authorization-server",
            "oauth-authorization-server-by-name",
        }
