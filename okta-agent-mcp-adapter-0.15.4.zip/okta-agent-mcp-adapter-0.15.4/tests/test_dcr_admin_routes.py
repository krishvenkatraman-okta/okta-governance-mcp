"""Tests for DCR admin API routes: unlink and dcr_selectable.

Validates:
- POST /api/admin/dcr/registrations/{client_id}/unlink
- PUT /api/admin/agents/{agent_id}/dcr-selectable
- Auth requirements
- Error handling
- Audit event emission
"""

import json
import sys
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from okta_agent_proxy.audit.events import AuditEventType


# ---------------------------------------------------------------------------
# App import helper
# ---------------------------------------------------------------------------

def _ensure_app_imported():
    mod = sys.modules.get("okta_agent_proxy.app")
    if mod is not None and hasattr(mod, "client_registry"):
        return

    sys.modules.pop("okta_agent_proxy.app", None)

    import okta_agent_proxy.database as _db_mod
    _orig_get = _db_mod.get_config_store
    _orig_store = _db_mod._config_store
    _mock_store = MagicMock()
    _mock_store.get_all_resources.return_value = []
    _mock_store.get_all_agents.return_value = []
    _db_mod.get_config_store = lambda **kw: _mock_store
    _db_mod._config_store = _mock_store
    try:
        import importlib
        import okta_agent_proxy.app
        importlib.reload(okta_agent_proxy.app)
    except Exception:
        sys.modules.pop("okta_agent_proxy.app", None)
        raise
    finally:
        _db_mod.get_config_store = _orig_get
        _db_mod._config_store = _orig_store


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _mock_request(path_params=None, body=None, admin_user="admin"):
    """Build a mock Starlette Request with admin auth."""
    req = MagicMock()
    req.path_params = path_params or {}
    req.state = MagicMock()
    req.state.admin_payload = {"username": admin_user}

    async def _json():
        return body or {}

    req.json = _json
    return req


def _mock_request_no_auth(path_params=None):
    """Build a mock request without admin auth."""
    req = MagicMock()
    req.path_params = path_params or {}
    req.state = MagicMock(spec=[])  # No admin_payload attribute
    return req


# ---------------------------------------------------------------------------
# Unlink DCR Registration
# ---------------------------------------------------------------------------

class TestUnlinkDCRRegistration:

    @pytest.fixture(autouse=True)
    def setup(self):
        _ensure_app_imported()

    @patch("okta_agent_proxy.admin.dcr_routes.get_store")
    async def test_admin_unlink_dcr_registration(self, mock_get_store):
        """Unlink clears creds and linked_agent_name."""
        with patch("okta_agent_proxy.app.dcr_handler") as mock_dcr:
            mock_dcr.unlink_agent = AsyncMock(return_value=(True, "Agent unlinked"))

            from okta_agent_proxy.admin.dcr_routes import unlink_dcr_registration

            # Call directly (bypassing @admin_required which checks request.state)
            req = _mock_request(path_params={"client_id": "dcr_abc123"})
            resp = await unlink_dcr_registration.__wrapped__(req)

            assert resp.status_code == 200
            body = json.loads(resp.body)
            assert body["status"] == "unlinked"
            mock_dcr.unlink_agent.assert_called_once_with(
                "dcr_abc123", user="admin"
            )

    @patch("okta_agent_proxy.admin.dcr_routes.get_store")
    async def test_admin_unlink_not_found(self, mock_get_store):
        """404 for non-existent registration."""
        with patch("okta_agent_proxy.app.dcr_handler") as mock_dcr:
            mock_dcr.unlink_agent = AsyncMock(
                return_value=(False, "DCR registration not found")
            )

            from okta_agent_proxy.admin.dcr_routes import unlink_dcr_registration
            req = _mock_request(path_params={"client_id": "nonexistent"})
            resp = await unlink_dcr_registration.__wrapped__(req)

            assert resp.status_code == 404
            body = json.loads(resp.body)
            assert "not found" in body["message"].lower()

    async def test_admin_unlink_requires_auth(self):
        """Unlink endpoint requires admin authentication."""
        from okta_agent_proxy.admin.dcr_routes import unlink_dcr_registration

        # The @admin_required decorator checks for valid admin auth.
        # Verify the function is wrapped (has __wrapped__ attribute).
        assert hasattr(unlink_dcr_registration, "__wrapped__"), \
            "unlink_dcr_registration should be decorated with @admin_required"


# ---------------------------------------------------------------------------
# Update DCR Selectable
# ---------------------------------------------------------------------------

class TestUpdateDCRSelectable:

    @pytest.fixture(autouse=True)
    def setup(self):
        _ensure_app_imported()

    @patch("okta_agent_proxy.admin.dcr_routes.emit_audit_event", new_callable=AsyncMock)
    @patch("okta_agent_proxy.admin.dcr_routes.get_store")
    async def test_admin_update_dcr_selectable_true(self, mock_get_store, mock_emit):
        """Sets dcr_selectable=True on agent."""
        mock_store = MagicMock()
        mock_store.get_agent.return_value = {
            "agent_name": "test-agent",
            "agent_id": "test-agent",
            "dcr_selectable": False,
        }
        mock_store.update_agent.return_value = True
        mock_get_store.return_value = mock_store

        from okta_agent_proxy.admin.dcr_routes import update_dcr_selectable
        req = _mock_request(
            path_params={"agent_id": "test-agent"},
            body={"dcr_selectable": True},
        )
        resp = await update_dcr_selectable.__wrapped__(req)

        assert resp.status_code == 200
        body = json.loads(resp.body)
        assert body["dcr_selectable"] is True
        mock_store.update_agent.assert_called_once_with(
            "test-agent", {"dcr_selectable": True}, user="admin"
        )

    @patch("okta_agent_proxy.admin.dcr_routes.emit_audit_event", new_callable=AsyncMock)
    @patch("okta_agent_proxy.admin.dcr_routes.get_store")
    async def test_admin_update_dcr_selectable_false(self, mock_get_store, mock_emit):
        """Sets dcr_selectable=False on agent."""
        mock_store = MagicMock()
        mock_store.get_agent.return_value = {
            "agent_name": "test-agent",
            "agent_id": "test-agent",
            "dcr_selectable": True,
        }
        mock_store.update_agent.return_value = True
        mock_get_store.return_value = mock_store

        from okta_agent_proxy.admin.dcr_routes import update_dcr_selectable
        req = _mock_request(
            path_params={"agent_id": "test-agent"},
            body={"dcr_selectable": False},
        )
        resp = await update_dcr_selectable.__wrapped__(req)

        assert resp.status_code == 200
        body = json.loads(resp.body)
        assert body["dcr_selectable"] is False

    @patch("okta_agent_proxy.admin.dcr_routes.emit_audit_event", new_callable=AsyncMock)
    @patch("okta_agent_proxy.admin.dcr_routes.get_store")
    async def test_admin_update_dcr_selectable_not_found(self, mock_get_store, mock_emit):
        """404 for non-existent agent."""
        mock_store = MagicMock()
        mock_store.get_agent.return_value = None
        mock_get_store.return_value = mock_store

        from okta_agent_proxy.admin.dcr_routes import update_dcr_selectable
        req = _mock_request(
            path_params={"agent_id": "nonexistent"},
            body={"dcr_selectable": True},
        )
        resp = await update_dcr_selectable.__wrapped__(req)

        assert resp.status_code == 404

    @patch("okta_agent_proxy.admin.dcr_routes.emit_audit_event", new_callable=AsyncMock)
    @patch("okta_agent_proxy.admin.dcr_routes.get_store")
    async def test_admin_update_dcr_selectable_audit_event(self, mock_get_store, mock_emit):
        """CONFIG_AGENT_UPDATED audit event emitted."""
        mock_store = MagicMock()
        mock_store.get_agent.return_value = {
            "agent_name": "test-agent",
            "agent_id": "test-agent",
            "dcr_selectable": False,
        }
        mock_store.update_agent.return_value = True
        mock_get_store.return_value = mock_store

        from okta_agent_proxy.admin.dcr_routes import update_dcr_selectable
        req = _mock_request(
            path_params={"agent_id": "test-agent"},
            body={"dcr_selectable": True},
            admin_user="admin-joey",
        )
        resp = await update_dcr_selectable.__wrapped__(req)
        assert resp.status_code == 200

        mock_emit.assert_called_once()
        call = mock_emit.call_args
        assert call[0][0] == AuditEventType.CONFIG_AGENT_UPDATED
        details = call[1]["details"]
        assert details["agent_id"] == "test-agent"
        assert details["dcr_selectable"] is True
        assert details["user"] == "admin-joey"

    async def test_admin_update_dcr_selectable_requires_auth(self):
        """dcr-selectable endpoint requires admin authentication."""
        from okta_agent_proxy.admin.dcr_routes import update_dcr_selectable
        assert hasattr(update_dcr_selectable, "__wrapped__"), \
            "update_dcr_selectable should be decorated with @admin_required"
