"""End-to-end tests for DCR redirect patterns admin feature.

Exercises the full chain — DCRPolicy dynamic patterns, store persistence,
cross-worker invalidation via fake event bus, and the HTTP admin endpoint —
without requiring a real Redis instance.
"""

import json
import sys
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from okta_agent_proxy.audit.events import AuditEventType
from okta_agent_proxy.auth.dcr_policy import (
    DCRPolicy,
    DCRPolicyResult,
    DEFAULT_REDIRECT_PATTERNS,
    GATEWAY_CONFIG_KEY_REDIRECT_PATTERNS,
)
from okta_agent_proxy.cache.pubsub import CHANNEL_DCR_PATTERNS_INVALIDATE


# ---------------------------------------------------------------------------
# Fake store (dict-backed, same shape as gateway_config interface)
# ---------------------------------------------------------------------------

class _FakeStore:
    """Dict-backed store implementing gateway_config methods."""

    def __init__(self):
        self._data: dict = {}
        self._meta: dict = {}

    def get_gateway_config(self, key: str):
        return self._data.get(key)

    def get_gateway_config_entry(self, key: str):
        if key not in self._data:
            return None
        return {
            "value": self._data[key],
            "updated_at": self._meta.get(key, {}).get("updated_at"),
            "updated_by": self._meta.get(key, {}).get("updated_by"),
        }

    def set_gateway_config(self, key, value, user="admin", **kwargs):
        self._data[key] = value
        self._meta[key] = {
            "updated_at": "2026-04-09T12:00:00",
            "updated_by": user,
        }


# ---------------------------------------------------------------------------
# Fake event bus (in-process pub/sub, simulates Redis)
# ---------------------------------------------------------------------------

class _FakeEventBus:
    """In-process pub/sub that dispatches to registered callbacks locally."""

    def __init__(self):
        self.callbacks: dict[str, list] = {}

    async def subscribe(self, channel: str, callback):
        self.callbacks.setdefault(channel, []).append(callback)

    async def publish(self, channel: str, message: str):
        for cb in self.callbacks.get(channel, []):
            await cb(message)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _valid_dcr_body(redirect_uri: str) -> dict:
    """Minimal valid DCR registration request body."""
    return {
        "client_name": "test-client",
        "redirect_uris": [redirect_uri],
        "grant_types": ["authorization_code"],
    }


def _ensure_app_imported():
    mod = sys.modules.get("okta_agent_proxy.app")
    if mod is not None and hasattr(mod, "client_registry"):
        return

    sys.modules.pop("okta_agent_proxy.app", None)

    import okta_agent_proxy.database as _db_mod
    _orig_get = _db_mod.get_config_store
    _orig_store = _db_mod._config_store
    _mock_store = MagicMock()
    _mock_store.get_all_resources.return_value = []
    _mock_store.get_all_agents.return_value = []
    _db_mod.get_config_store = lambda **kw: _mock_store
    _db_mod._config_store = _mock_store
    try:
        import importlib
        import okta_agent_proxy.app
        importlib.reload(okta_agent_proxy.app)
    except Exception:
        sys.modules.pop("okta_agent_proxy.app", None)
        raise
    finally:
        _db_mod.get_config_store = _orig_get
        _db_mod._config_store = _orig_store


def _mock_request(body=None, admin_user="admin"):
    req = MagicMock()
    req.state = MagicMock()
    req.state.admin_payload = {"username": admin_user}
    req.client = MagicMock()
    req.client.host = "127.0.0.1"
    req.headers = {"user-agent": "test-agent"}

    async def _json():
        return body

    req.json = _json
    return req


# ---------------------------------------------------------------------------
# End-to-end test class
# ---------------------------------------------------------------------------

class TestE2EDCRPatternsAdmin:
    """Full-chain DCR redirect patterns: store → policy → pub/sub → admin API."""

    @pytest.fixture(autouse=True)
    def setup(self):
        _ensure_app_imported()

    async def test_full_chain_cross_worker_invalidation(self, monkeypatch):
        """
        Steps a-h: Two DCRPolicy instances sharing a store and fake event bus.
        Verifies seeding, L1 caching, cross-worker invalidation via pub/sub,
        and that stale caches are not silently retained.
        """
        # (a) Fresh store — empty gateway_config
        store = _FakeStore()

        # (b) Seed env var to a known default list
        seed_patterns = [
            "http://localhost:*/callback",
            "http://127.0.0.1:*/callback",
        ]
        monkeypatch.setenv(
            "DCR_ALLOWED_REDIRECT_PATTERNS",
            ",".join(seed_patterns),
        )

        # (c) Create fake event bus
        fake_bus = _FakeEventBus()

        # (d) Instantiate two DCRPolicy instances sharing the same store and bus
        policy_a = DCRPolicy(
            enabled=True,
            store=store,
            event_bus=fake_bus,
            allowed_redirect_patterns=seed_patterns,
            pattern_cache_ttl_seconds=300.0,
        )
        policy_b = DCRPolicy(
            enabled=True,
            store=store,
            event_bus=fake_bus,
            allowed_redirect_patterns=seed_patterns,
            pattern_cache_ttl_seconds=300.0,
        )
        await policy_a.register_pubsub_subscriber()
        await policy_b.register_pubsub_subscriber()

        # Both should be subscribed
        subs = fake_bus.callbacks.get(CHANNEL_DCR_PATTERNS_INVALIDATE, [])
        assert len(subs) == 2

        # (e) First validate on policy_a with a localhost URI should succeed
        #     AND trigger the seed write to gateway_config
        result_a = await policy_a.validate(
            _valid_dcr_body("http://localhost:8080/callback"),
            source_ip="10.0.0.1",
        )
        assert result_a.allowed, f"Expected allowed, got: {result_a.reason}"

        # Assert store was seeded
        stored = store.get_gateway_config(GATEWAY_CONFIG_KEY_REDIRECT_PATTERNS)
        assert stored == seed_patterns

        # policy_b should also validate the same URI (reads seeded value)
        result_b = await policy_b.validate(
            _valid_dcr_body("http://localhost:9999/callback"),
            source_ip="10.0.0.2",
        )
        assert result_b.allowed, f"Expected allowed, got: {result_b.reason}"

        # (f) Simulate admin API path: update to a NEW list via store
        new_patterns = ["https://*.consent.azure-apim.net/redirect/*"]
        store.set_gateway_config(
            GATEWAY_CONFIG_KEY_REDIRECT_PATTERNS,
            new_patterns,
            user="admin",
        )

        # Invalidate the writer's own L1
        policy_a.invalidate_pattern_cache()

        # Broadcast invalidation via fake event bus
        await fake_bus.publish(
            CHANNEL_DCR_PATTERNS_INVALIDATE,
            json.dumps({"user": "admin", "ts": "2026-04-09T12:00:00Z"}),
        )

        # (g) policy_b should now accept the new pattern
        result_g = await policy_b.validate(
            _valid_dcr_body("https://foo.consent.azure-apim.net/redirect/abc"),
            source_ip="10.0.0.3",
        )
        assert result_g.allowed, (
            f"Expected allowed after pub/sub invalidation, got: {result_g.reason}"
        )

        # (h) policy_b should now REJECT localhost (not in new list)
        result_h = await policy_b.validate(
            _valid_dcr_body("http://localhost:8080/callback"),
            source_ip="10.0.0.4",
        )
        assert not result_h.allowed, (
            "Expected rejection for localhost after pattern list changed"
        )
        assert "does not match" in result_h.reason

    @patch("okta_agent_proxy.admin.dcr_routes.emit_audit_event", new_callable=AsyncMock)
    @patch("okta_agent_proxy.admin.dcr_routes.get_store")
    async def test_admin_put_success_with_audit(self, mock_get_store, mock_audit):
        """
        Step (i): PUT /api/admin/dcr/policy/redirect-patterns with valid
        patterns via admin test client. Assert 200 and exactly one
        DCR_REDIRECT_PATTERNS_UPDATED audit event.
        """
        store = _FakeStore()
        mock_get_store.return_value = store

        mock_policy = MagicMock()
        mock_bus = MagicMock()
        mock_bus.publish = AsyncMock()

        from okta_agent_proxy.admin.dcr_routes import update_dcr_redirect_patterns

        patterns = [
            "https://app.example.com/oauth/callback",
            "http://localhost:*/callback",
        ]

        with patch("okta_agent_proxy.app.get_dcr_policy", return_value=mock_policy):
            with patch("okta_agent_proxy.app.get_event_bus", return_value=mock_bus):
                req = _mock_request(
                    body={"patterns": patterns},
                    admin_user="e2e-admin",
                )
                resp = await update_dcr_redirect_patterns.__wrapped__(req)

        assert resp.status_code == 200
        body = json.loads(resp.body)
        assert body["source"] == "database"
        assert body["patterns"] == patterns

        # Verify persisted in store
        assert store.get_gateway_config(GATEWAY_CONFIG_KEY_REDIRECT_PATTERNS) == patterns

        # Verify exactly one audit event of the right type
        assert mock_audit.await_count == 1
        call_args = mock_audit.call_args
        assert call_args[0][0] == AuditEventType.DCR_REDIRECT_PATTERNS_UPDATED
        assert call_args[1]["details"]["user"] == "e2e-admin"
        assert call_args[1]["details"]["pattern_count"] == 2

        # Verify local cache invalidation was called
        mock_policy.invalidate_pattern_cache.assert_called_once()

        # Verify pub/sub broadcast was sent
        mock_bus.publish.assert_awaited_once()
        pub_channel = mock_bus.publish.call_args[0][0]
        assert pub_channel == CHANNEL_DCR_PATTERNS_INVALIDATE

    @patch("okta_agent_proxy.admin.dcr_routes.emit_audit_event", new_callable=AsyncMock)
    @patch("okta_agent_proxy.admin.dcr_routes.get_store")
    async def test_admin_put_invalid_pattern_returns_400_no_partial_write(
        self, mock_get_store, mock_audit
    ):
        """
        Step (j): PUT an invalid pattern. Assert 400. Verify the previously
        persisted valid list is still active (no partial write). Assert no
        DCR_REDIRECT_PATTERNS_UPDATED audit event for the failed call.
        """
        store = _FakeStore()
        # Pre-populate with a valid list
        valid_patterns = ["http://localhost:*/callback"]
        store.set_gateway_config(
            GATEWAY_CONFIG_KEY_REDIRECT_PATTERNS,
            valid_patterns,
            user="prior-admin",
        )
        mock_get_store.return_value = store

        from okta_agent_proxy.admin.dcr_routes import update_dcr_redirect_patterns

        # Try to save an invalid pattern
        req = _mock_request(
            body={"patterns": ["https://*/*"]},
            admin_user="bad-admin",
        )
        resp = await update_dcr_redirect_patterns.__wrapped__(req)

        assert resp.status_code == 400
        body = json.loads(resp.body)
        assert body["error"] == "invalid_pattern"

        # The previously persisted valid list must still be active
        assert store.get_gateway_config(GATEWAY_CONFIG_KEY_REDIRECT_PATTERNS) == valid_patterns

        # No audit event should have been emitted for the failed call
        mock_audit.assert_not_awaited()

    async def test_policy_a_also_reflects_new_patterns_after_invalidation(
        self, monkeypatch
    ):
        """
        After the admin write + invalidation, the writer's own policy
        (policy_a) should also reflect the new patterns.
        """
        store = _FakeStore()
        seed = ["http://localhost:*/callback"]
        monkeypatch.setenv("DCR_ALLOWED_REDIRECT_PATTERNS", ",".join(seed))

        fake_bus = _FakeEventBus()
        policy_a = DCRPolicy(
            enabled=True,
            store=store,
            event_bus=fake_bus,
            allowed_redirect_patterns=seed,
            pattern_cache_ttl_seconds=300.0,
        )
        await policy_a.register_pubsub_subscriber()

        # Trigger seed
        result = await policy_a.validate(
            _valid_dcr_body("http://localhost:3000/callback"),
            source_ip="10.0.0.1",
        )
        assert result.allowed

        # Admin updates patterns
        new_patterns = ["https://app.example.com/cb"]
        store.set_gateway_config(
            GATEWAY_CONFIG_KEY_REDIRECT_PATTERNS, new_patterns, user="admin"
        )
        policy_a.invalidate_pattern_cache()

        # The old pattern should no longer match
        result2 = await policy_a.validate(
            _valid_dcr_body("http://localhost:3000/callback"),
            source_ip="10.0.0.1",
        )
        assert not result2.allowed

        # The new pattern should match
        result3 = await policy_a.validate(
            _valid_dcr_body("https://app.example.com/cb"),
            source_ip="10.0.0.1",
        )
        assert result3.allowed

    async def test_pubsub_idempotent_registration(self):
        """register_pubsub_subscriber is idempotent — calling twice registers only once."""
        store = _FakeStore()
        fake_bus = _FakeEventBus()
        policy = DCRPolicy(
            enabled=True,
            store=store,
            event_bus=fake_bus,
            allowed_redirect_patterns=["http://localhost:*/callback"],
        )

        await policy.register_pubsub_subscriber()
        await policy.register_pubsub_subscriber()  # second call = no-op

        subs = fake_bus.callbacks.get(CHANNEL_DCR_PATTERNS_INVALIDATE, [])
        assert len(subs) == 1

    async def test_no_event_bus_works_without_error(self, monkeypatch):
        """DCRPolicy without an event bus (single-pod mode) works fine."""
        store = _FakeStore()
        monkeypatch.setenv("DCR_ALLOWED_REDIRECT_PATTERNS", "http://localhost:*/callback")

        policy = DCRPolicy(
            enabled=True,
            store=store,
            event_bus=None,
            allowed_redirect_patterns=["http://localhost:*/callback"],
        )
        # register_pubsub_subscriber should be a no-op
        await policy.register_pubsub_subscriber()

        result = await policy.validate(
            _valid_dcr_body("http://localhost:8080/callback"),
            source_ip="10.0.0.1",
        )
        assert result.allowed
