"""Tests for audit sinks and the AuditEventEmitter."""

import asyncio
import json
import os
import tempfile
from typing import List
from unittest.mock import AsyncMock

import pytest

from okta_agent_proxy.audit.events import AuditEvent, AuditEventType, AuditSeverity
from okta_agent_proxy.audit.sinks.base import AuditSink
from okta_agent_proxy.audit.sinks.stdout import StdoutSink
from okta_agent_proxy.audit.sinks.file import FileSink
from okta_agent_proxy.audit.emitter import AuditEventEmitter


def _make_event(event_type=AuditEventType.MCP_TOOL_CALL, corr_id="test-corr") -> AuditEvent:
    return AuditEvent(
        event_type=event_type,
        severity=AuditSeverity.INFO,
        correlation_id=corr_id,
    )


# --- StdoutSink ---


class TestStdoutSink:
    @pytest.mark.asyncio
    async def test_writes_json_to_stdout(self, capsys):
        sink = StdoutSink()
        event = _make_event()
        await sink.write(event)
        captured = capsys.readouterr().out.strip()
        parsed = json.loads(captured)
        assert parsed["event_type"] == "mcp.tool.call"

    @pytest.mark.asyncio
    async def test_one_line_per_event(self, capsys):
        sink = StdoutSink()
        await sink.write(_make_event(corr_id="a"))
        await sink.write(_make_event(corr_id="b"))
        lines = capsys.readouterr().out.strip().split("\n")
        assert len(lines) == 2
        assert json.loads(lines[0])["correlation_id"] == "a"
        assert json.loads(lines[1])["correlation_id"] == "b"

    def test_name(self):
        assert StdoutSink().name == "stdout"

    @pytest.mark.asyncio
    async def test_flush_and_close_are_noop(self):
        sink = StdoutSink()
        await sink.flush()
        await sink.close()


# --- FileSink ---


class TestFileSink:
    @pytest.mark.asyncio
    async def test_writes_jsonl_to_file(self):
        with tempfile.NamedTemporaryFile(suffix=".jsonl", delete=False) as f:
            path = f.name
        try:
            sink = FileSink(file_path=path)
            await sink.write(_make_event(corr_id="file-1"))
            await sink.write(_make_event(corr_id="file-2"))
            await sink.flush()
            await sink.close()

            with open(path) as fh:
                lines = [l.strip() for l in fh if l.strip()]
            assert len(lines) == 2
            assert json.loads(lines[0])["correlation_id"] == "file-1"
            assert json.loads(lines[1])["correlation_id"] == "file-2"
        finally:
            os.unlink(path)

    def test_name(self):
        with tempfile.NamedTemporaryFile(suffix=".jsonl", delete=False) as f:
            path = f.name
        try:
            sink = FileSink(file_path=path)
            assert sink.name == "file"
            sink._handler.close()
        finally:
            os.unlink(path)


# --- Mock sink helper ---


class MockSink(AuditSink):
    """Collectable sink for testing the emitter."""

    def __init__(self, fail: bool = False):
        self.events: List[AuditEvent] = []
        self.flushed = False
        self.closed = False
        self._fail = fail

    async def write(self, event: AuditEvent) -> None:
        if self._fail:
            raise RuntimeError("sink error")
        self.events.append(event)

    async def flush(self) -> None:
        self.flushed = True

    async def close(self) -> None:
        self.closed = True

    @property
    def name(self) -> str:
        return "mock"


# --- AuditEventEmitter ---


class TestAuditEventEmitter:
    @pytest.mark.asyncio
    async def test_queues_and_drains_events(self):
        sink = MockSink()
        emitter = AuditEventEmitter(sinks=[sink], flush_interval=0.05)
        await emitter.start()
        await emitter.emit(_make_event(corr_id="e1"))
        await emitter.emit(_make_event(corr_id="e2"))
        # Give drain loop time to process
        await asyncio.sleep(0.2)
        await emitter.stop()
        assert len(sink.events) == 2
        corr_ids = {e.correlation_id for e in sink.events}
        assert corr_ids == {"e1", "e2"}

    @pytest.mark.asyncio
    async def test_emit_when_queue_full_does_not_block(self):
        sink = MockSink()
        emitter = AuditEventEmitter(sinks=[sink], buffer_size=2, flush_interval=10.0)
        # Don't start the drain loop so the queue stays full
        emitter._running = True
        await emitter.emit(_make_event(corr_id="a"))
        await emitter.emit(_make_event(corr_id="b"))
        # Queue is now full — third emit should drop, not block
        await emitter.emit(_make_event(corr_id="dropped"))
        assert emitter._queue.qsize() == 2
        emitter._running = False

    @pytest.mark.asyncio
    async def test_stop_flushes_remaining_events(self):
        sink = MockSink()
        emitter = AuditEventEmitter(sinks=[sink], flush_interval=10.0)
        await emitter.start()
        for i in range(5):
            await emitter.emit(_make_event(corr_id=f"flush-{i}"))
        await emitter.stop()
        assert len(sink.events) == 5
        assert sink.flushed is True
        assert sink.closed is True

    @pytest.mark.asyncio
    async def test_sink_failure_does_not_affect_other_sinks(self):
        failing = MockSink(fail=True)
        good = MockSink()
        emitter = AuditEventEmitter(sinks=[failing, good], flush_interval=0.05)
        await emitter.start()
        await emitter.emit(_make_event(corr_id="multi"))
        await asyncio.sleep(0.2)
        await emitter.stop()
        assert len(good.events) == 1
        assert good.events[0].correlation_id == "multi"

    @pytest.mark.asyncio
    async def test_multiple_sinks_all_receive_events(self):
        s1 = MockSink()
        s2 = MockSink()
        emitter = AuditEventEmitter(sinks=[s1, s2], flush_interval=0.05)
        await emitter.start()
        await emitter.emit(_make_event(corr_id="both"))
        await asyncio.sleep(0.2)
        await emitter.stop()
        assert len(s1.events) == 1
        assert len(s2.events) == 1

    @pytest.mark.asyncio
    async def test_empty_sinks_list(self):
        emitter = AuditEventEmitter(sinks=[], flush_interval=0.05)
        await emitter.start()
        await emitter.emit(_make_event())
        await asyncio.sleep(0.1)
        await emitter.stop()
        # No crash — just a no-op


# --- init_audit_emitter ---


class TestInitAuditEmitter:
    @pytest.mark.asyncio
    async def test_default_creates_stdout_sink(self, monkeypatch):
        monkeypatch.delenv("AUDIT_ENABLED", raising=False)
        monkeypatch.delenv("AUDIT_SINKS", raising=False)

        import okta_agent_proxy.audit as audit_mod
        emitter = await audit_mod.init_audit_emitter()
        try:
            assert len(emitter.sinks) == 1
            assert emitter.sinks[0].name == "stdout"
            assert audit_mod.get_audit_emitter() is emitter
        finally:
            await audit_mod.shutdown_audit_emitter()

    @pytest.mark.asyncio
    async def test_disabled_creates_no_sinks(self, monkeypatch):
        monkeypatch.setenv("AUDIT_ENABLED", "false")

        import okta_agent_proxy.audit as audit_mod
        emitter = await audit_mod.init_audit_emitter()
        try:
            assert len(emitter.sinks) == 0
        finally:
            await audit_mod.shutdown_audit_emitter()

    @pytest.mark.asyncio
    async def test_file_sink_from_env(self, monkeypatch, tmp_path):
        monkeypatch.setenv("AUDIT_SINKS", "file")
        monkeypatch.setenv("AUDIT_FILE_PATH", str(tmp_path / "audit.jsonl"))

        import okta_agent_proxy.audit as audit_mod
        emitter = await audit_mod.init_audit_emitter()
        try:
            assert len(emitter.sinks) == 1
            assert emitter.sinks[0].name == "file"
        finally:
            await audit_mod.shutdown_audit_emitter()

    @pytest.mark.asyncio
    async def test_multiple_sinks_from_env(self, monkeypatch, tmp_path):
        monkeypatch.setenv("AUDIT_SINKS", "stdout,file")
        monkeypatch.setenv("AUDIT_FILE_PATH", str(tmp_path / "audit.jsonl"))

        import okta_agent_proxy.audit as audit_mod
        emitter = await audit_mod.init_audit_emitter()
        try:
            assert len(emitter.sinks) == 2
            names = {s.name for s in emitter.sinks}
            assert names == {"stdout", "file"}
        finally:
            await audit_mod.shutdown_audit_emitter()

    @pytest.mark.asyncio
    async def test_shutdown_clears_emitter(self, monkeypatch):
        monkeypatch.setenv("AUDIT_ENABLED", "false")

        import okta_agent_proxy.audit as audit_mod
        await audit_mod.init_audit_emitter()
        assert audit_mod.get_audit_emitter() is not None
        await audit_mod.shutdown_audit_emitter()
        assert audit_mod.get_audit_emitter() is None
