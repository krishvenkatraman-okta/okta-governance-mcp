"""Tests for the fail-fast schema version check (DB migration P08).

Requires a reachable Postgres instance (same convention as
``tests/test_database_pool.py``); skipped otherwise.
"""

from __future__ import annotations

import os
from typing import Iterator

import psycopg
import pytest

from okta_agent_proxy.storage.constants import (
    MIN_SCHEMA_VERSION,
    SCHEMA_MIGRATIONS_TABLE,
)
from okta_agent_proxy.storage.credentials import StaticUrlCredentialProvider
from okta_agent_proxy.storage.pool import DatabasePool
from okta_agent_proxy.storage.schema_check import (
    SchemaNotInitializedError,
    SchemaVersionMismatchError,
    verify_schema,
)


DEFAULT_POSTGRES_URL = (
    "postgresql://postgres:test@localhost:55432/gateway_test"
)


def _postgres_url() -> str:
    return os.environ.get("TEST_POSTGRES_URL", DEFAULT_POSTGRES_URL)


def _postgres_reachable(url: str) -> bool:
    try:
        with psycopg.connect(url, connect_timeout=2) as conn:
            with conn.cursor() as cur:
                cur.execute("SELECT 1")
                cur.fetchone()
        return True
    except Exception:
        return False


@pytest.fixture(scope="module")
def postgres_url() -> str:
    url = _postgres_url()
    if not _postgres_reachable(url):
        pytest.skip(f"No reachable Postgres at {url}")
    return url


@pytest.fixture
def pool(postgres_url) -> Iterator[DatabasePool]:
    p = DatabasePool(StaticUrlCredentialProvider(postgres_url))
    yield p
    p.close()


def _drop_schema_migrations(pool: DatabasePool) -> None:
    with pool.connection() as conn:
        with conn.cursor() as cur:
            cur.execute(
                f"DROP TABLE IF EXISTS {SCHEMA_MIGRATIONS_TABLE}"
            )
        conn.commit()


def _create_empty_schema_migrations(pool: DatabasePool) -> None:
    with pool.connection() as conn:
        with conn.cursor() as cur:
            cur.execute(
                f"""
                CREATE TABLE IF NOT EXISTS {SCHEMA_MIGRATIONS_TABLE} (
                    version      VARCHAR(16) PRIMARY KEY,
                    applied_at   TIMESTAMPTZ NOT NULL DEFAULT NOW(),
                    applied_by   VARCHAR(255),
                    checksum     VARCHAR(64) NOT NULL,
                    execution_ms INTEGER NOT NULL DEFAULT 0
                )
                """
            )
            cur.execute(
                f"TRUNCATE {SCHEMA_MIGRATIONS_TABLE}"
            )
        conn.commit()


def _insert_version(pool: DatabasePool, version: str) -> None:
    with pool.connection() as conn:
        with conn.cursor() as cur:
            cur.execute(
                f"INSERT INTO {SCHEMA_MIGRATIONS_TABLE} "
                "(version, checksum) VALUES (%s, %s) "
                "ON CONFLICT (version) DO NOTHING",
                (version, "deadbeef"),
            )
        conn.commit()


def _reset_public_schema(url: str) -> None:
    """Drop + recreate ``public`` so migrations can re-apply cleanly."""
    with psycopg.connect(url) as conn:
        with conn.cursor() as cur:
            cur.execute("DROP SCHEMA public CASCADE")
            cur.execute("CREATE SCHEMA public")
        conn.commit()


def _restore_migrations(url: str) -> None:
    """Reset public schema and re-apply all migrations via the runner.

    Tests in this module intentionally mutate ``schema_migrations`` in ways
    that break future migration attempts; wiping the schema gives each test
    a clean baseline without leaking state.
    """
    from pathlib import Path

    from okta_agent_proxy.storage.migrate import upgrade

    _reset_public_schema(url)
    migrations_dir = (
        Path(__file__).resolve().parents[1] / "deploy" / "migrations" / "sql"
    )
    upgrade(url, migrations_dir, applied_by="pytest-schema-check")


def test_verify_schema_success_returns_current_version(pool, postgres_url):
    """Happy path — migrations already applied by the session fixture."""
    _restore_migrations(postgres_url)
    current = verify_schema(pool)
    assert current is not None
    assert current >= MIN_SCHEMA_VERSION


def test_verify_schema_missing_table_raises_not_initialized(pool, postgres_url):
    """Drop schema_migrations and assert the correct error is raised."""
    _drop_schema_migrations(pool)
    try:
        with pytest.raises(SchemaNotInitializedError) as exc:
            verify_schema(pool)
        msg = str(exc.value)
        assert SCHEMA_MIGRATIONS_TABLE in msg
        assert "migrate upgrade" in msg
        assert "does not create database schema at runtime" in msg
    finally:
        _restore_migrations(postgres_url)


def test_verify_schema_old_version_raises_mismatch(pool, postgres_url):
    """schema_migrations exists but current version < MIN_SCHEMA_VERSION."""
    _drop_schema_migrations(pool)
    _create_empty_schema_migrations(pool)
    # Insert a version guaranteed to be below the minimum.
    _insert_version(pool, "000")
    try:
        with pytest.raises(SchemaVersionMismatchError) as exc:
            verify_schema(pool)
        msg = str(exc.value)
        assert "requires" in msg
        assert MIN_SCHEMA_VERSION in msg
        assert "migrate upgrade" in msg
    finally:
        _restore_migrations(postgres_url)


def test_verify_schema_empty_table_raises_mismatch(pool, postgres_url):
    """schema_migrations exists but has no rows → treated as mismatch."""
    _drop_schema_migrations(pool)
    _create_empty_schema_migrations(pool)
    try:
        with pytest.raises(SchemaVersionMismatchError):
            verify_schema(pool)
    finally:
        _restore_migrations(postgres_url)


def test_verify_schema_unreachable_db_raises_runtime_error():
    """Point the pool at a closed socket and assert a friendly RuntimeError."""
    # Fast-fail URL: random unused port on localhost.
    url = "postgresql://postgres:postgres@127.0.0.1:1/postgres?connect_timeout=1"
    with pytest.raises(Exception) as exc:
        pool = DatabasePool(
            StaticUrlCredentialProvider(url),
            timeout=1.0,
        )
        try:
            verify_schema(pool)
        finally:
            try:
                pool.close()
            except Exception:
                pass
    # Opening the pool itself may fail before verify_schema runs — either
    # path is acceptable; what matters is that startup does NOT silently
    # proceed against an unreachable DB.
    assert exc.value is not None


def test_schema_check_classes_are_runtime_errors():
    """Both sentinel exceptions extend RuntimeError so broad ``except Exception``
    blocks in callers still catch them."""
    assert issubclass(SchemaNotInitializedError, RuntimeError)
    assert issubclass(SchemaVersionMismatchError, RuntimeError)


def test_app_startup_exits_when_schema_missing(
    monkeypatch, postgres_url
):
    """Dropping schema_migrations, clearing the global store, and re-entering
    ``get_config_store`` must surface a SchemaNotInitializedError (which
    ``app.py`` then translates into ``sys.exit(1)``)."""
    from okta_agent_proxy import database as db_mod

    # Ensure a fresh pool/store for this test.
    db_mod.reset_config_store()

    # Drop the table, point get_config_store at the same test DB.
    p = DatabasePool(StaticUrlCredentialProvider(postgres_url))
    try:
        _drop_schema_migrations(p)
    finally:
        p.close()

    monkeypatch.setenv("DATABASE_URL", postgres_url)
    try:
        with pytest.raises(SchemaNotInitializedError):
            db_mod.get_config_store()
    finally:
        _restore_migrations(postgres_url)
        db_mod.reset_config_store()
