"""Pytest configuration and fixtures (psycopg3).

Post-P07: the test database is a real Postgres reached via ``psycopg3``.
Tests that touch the DB are skipped when the database is unreachable,
mirroring how the earlier SQLite-based fixture handled CI-only tests.
"""

import json
import os
from pathlib import Path
from unittest.mock import MagicMock

# Enable the Phase 1 Redis static-password gate for the test suite so modules
# that import okta_agent_proxy.app (which loads .env and may configure Redis)
# can construct the StaticPasswordProvider without erroring at import time.
# Individual tests can still monkeypatch this if they want to exercise the
# gate-enforcement path explicitly.
os.environ.setdefault("ALLOW_STATIC_REDIS_PASSWORD", "true")

import pytest

from okta_agent_proxy.cache import TokenCache
from okta_agent_proxy.cache.cache_service import CacheService
from okta_agent_proxy.cache.memory_provider import MemoryCacheProvider
from okta_agent_proxy.config import (
    CacheConfig,
    GatewayConfig,
    GatewaySettings,
    ResourceConfig,
)
from okta_agent_proxy.crypto.encryption import EncryptionService
from okta_agent_proxy.routing import ResourceRouter


# ============================================================================
# Environment Fixtures
# ============================================================================

@pytest.fixture
def mock_env_vars(monkeypatch):
    """Mock environment variables for testing"""
    monkeypatch.setenv("OKTA_DOMAIN", "dev-12345.okta.com")
    monkeypatch.setenv("OKTA_CLIENT_SECRET", "test_client_secret")
    monkeypatch.setenv("OKTA_ISSUER", "https://dev-12345.okta.com")
    monkeypatch.setenv("GATEWAY_BASE_URL", "http://localhost:8000")
    monkeypatch.setenv("GATEWAY_PORT", "8000")
    monkeypatch.setenv("LOG_LEVEL", "INFO")


@pytest.fixture
def gateway_settings(mock_env_vars):
    return GatewaySettings()


@pytest.fixture
def resource_config():
    return ResourceConfig(
        name="test_backend",
        url="http://localhost:8001",
        paths=["/test"],
        description="Test resource",
        timeout_seconds=30,
    )


@pytest.fixture
def resource_router(resource_config, mock_env_vars):
    resources = {"test_backend": resource_config}
    return ResourceRouter(resources)


@pytest.fixture
def token_cache():
    return TokenCache(max_size=100, ttl_seconds=3600)


@pytest.fixture
def gateway_config(gateway_settings, resource_config):
    return GatewayConfig(
        gateway=gateway_settings,
        cache=CacheConfig(max_size=100, ttl_seconds=3600),
        resources={"test_backend": resource_config},
    )


# ============================================================================
# Encryption Fixtures
# ============================================================================

@pytest.fixture(scope="session")
def test_encryption_key():
    return EncryptionService.generate_key()


@pytest.fixture
def encryption_service(test_encryption_key, monkeypatch):
    monkeypatch.setenv("ENCRYPTION_KEY", test_encryption_key)
    return EncryptionService(key_id="test-key")


# ============================================================================
# Cache Service Fixtures
# ============================================================================

@pytest.fixture
def cache_service():
    l2 = MemoryCacheProvider(max_size=1000, default_ttl=3600)
    svc = CacheService(l2_provider=l2)
    yield svc
    svc.close()


# ============================================================================
# Database Fixtures (psycopg3 — real Postgres required)
# ============================================================================

_DEFAULT_POSTGRES_URL = (
    "postgresql://postgres:test@localhost:55432/gateway_test"
)
_TABLES_TO_TRUNCATE = [
    "dcr_registrations",
    "audit_log",
    "resources",
    "agents",
    "okta_sync_state",
    "gateway_config",
]


def _postgres_url_env() -> str:
    return os.environ.get("TEST_POSTGRES_URL", _DEFAULT_POSTGRES_URL)


def _postgres_reachable(url: str) -> bool:
    try:
        import psycopg
    except ImportError:  # pragma: no cover - psycopg3 is a hard dep post-P07
        return False
    try:
        with psycopg.connect(url, connect_timeout=2) as conn:
            with conn.cursor() as cur:
                cur.execute("SELECT 1")
                cur.fetchone()
        return True
    except Exception:
        return False


def _apply_migrations(url: str) -> None:
    from okta_agent_proxy.storage.migrate import upgrade

    migrations_dir = (
        Path(__file__).resolve().parents[1] / "deploy" / "migrations" / "sql"
    )
    upgrade(url, migrations_dir, applied_by="pytest")


@pytest.fixture(scope="session")
def postgres_url() -> str:
    """Shared Postgres URL for live-database tests; skips when unreachable."""
    url = _postgres_url_env()
    if not _postgres_reachable(url):
        pytest.skip(f"No reachable Postgres at {url}")
    _apply_migrations(url)
    return url


@pytest.fixture(scope="session")
def test_pool(postgres_url):
    """Session-scoped :class:`DatabasePool` connected to the test database."""
    from okta_agent_proxy.storage.credentials import StaticUrlCredentialProvider
    from okta_agent_proxy.storage.pool import DatabasePool

    pool = DatabasePool(StaticUrlCredentialProvider(postgres_url))
    yield pool
    pool.close()


# Backward-compat alias: a few tests still import ``test_engine`` as a
# fixture name. After P07 it returns the DatabasePool instead of a
# SQLAlchemy engine; the only call sites that used it for DDL have been
# retired with ``storage/models.py``.
@pytest.fixture(scope="session")
def test_engine(test_pool):
    return test_pool


@pytest.fixture
def db_session(test_pool):
    """Yield a psycopg connection for each test. Autocommit disabled so the
    caller can run their own transactions; connections are returned to the
    pool on exit. Data cleanup is handled by ``reset_database_state``.
    """
    with test_pool.connection() as conn:
        yield conn


@pytest.fixture
def postgres_store(test_pool, encryption_service):
    """Return a :class:`PsycopgResourceStore` sharing the session pool."""
    from okta_agent_proxy.storage.psycopg_store import PsycopgResourceStore

    return PsycopgResourceStore(pool=test_pool, encryption_service=encryption_service)


# ``resource_store`` was P04's parametrized fixture covering both backends.
# Post-P07 there is only one backend, so ``resource_store`` is an alias.
@pytest.fixture
def resource_store(postgres_store):
    return postgres_store


# ============================================================================
# Sample Data Fixtures
# ============================================================================

@pytest.fixture
def sample_agent_data():
    return {
        "agent_name": "test-agent",
        "agent_id": "test-agent-123",
        "client_id": "0oa_test_client",
        "client_secret": "test_secret_value",
        "private_key": json.dumps(
            {
                "kty": "RSA",
                "use": "sig",
                "kid": "test-key-id",
                "n": "test-n-value",
                "e": "AQAB",
                "d": "test-d-value",
            }
        ),
        "scopes": [],
        "enabled": True,
    }


@pytest.fixture
def sample_resource_data():
    return {
        "name": "test-backend",
        "url": "http://localhost:9000/mcp",
        "paths": ["/test", "/api/test"],
        "auth_method": "okta-cross-app",
        "auth_config": {
            "id_jag_mode": "static",
            "target_authorization_server": "https://test.okta.com/oauth2/default",
            "target_audience": "https://test.mcp.example.com",
        },
        "description": "Test resource MCP server",
        "timeout_seconds": 30,
        "enabled": True,
    }


@pytest.fixture
def sample_agent_minimal():
    return {
        "agent_id": "minimal-agent",
        "client_id": "0oa_minimal",
        "private_key": json.dumps({"kty": "RSA", "n": "test", "e": "AQAB"}),
    }


@pytest.fixture
def sample_resource_static_key():
    return {
        "name": "static-key-resource",
        "url": "http://localhost:9001/mcp",
        "paths": ["/static"],
        "auth_method": "static-key",
        "auth_config": {
            "api_key": "test_api_key_12345",
            "header_name": "X-API-Key",
        },
        "description": "Static key authenticated resource",
        "timeout_seconds": 30,
        "enabled": True,
    }


@pytest.fixture
def sample_resource_service_account():
    return {
        "name": "service-account-resource",
        "url": "http://localhost:9002/mcp",
        "paths": ["/service"],
        "auth_method": "service-account",
        "auth_config": {
            "username": "service_user",
            "password": "service_password_123",
        },
        "description": "Service account authenticated resource",
        "timeout_seconds": 30,
        "enabled": True,
    }


# ============================================================================
# Seeded Database Fixtures
# ============================================================================

def _seed_synced_resource(
    postgres_store,
    *,
    agent_id: str,
    connection_id: str,
    name: str,
    url: str = "http://localhost:9000/mcp",
    connection_type: str = "IDENTITY_ASSERTION_CUSTOM_AS",
    scopes=None,
    scope_condition: str = "ALLOW_ALL",
    auth_method: str = "okta-cross-app",
    enabled: bool = True,
):
    """Create a synced resource row via the new upsert API and enable it."""
    postgres_store._resources.upsert_synced(
        agent_id=agent_id,
        connection_id=connection_id,
        name=name,
        connection_type=connection_type,
        scopes=list(scopes or []),
        scope_condition=scope_condition,
        auth_method=auth_method,
        metadata={},
        user="test-fixture",
    )
    if url or enabled:
        postgres_store.update_resource(
            name,
            {"url": url, "enabled": enabled},
            user="test-fixture",
        )
    return postgres_store.get_resource(name)


@pytest.fixture
def seeded_db(postgres_store, sample_agent_data, sample_resource_data):
    agent_success = postgres_store.create_agent(
        sample_agent_data["agent_id"], sample_agent_data, user="test-fixture"
    )
    resource = _seed_synced_resource(
        postgres_store,
        agent_id=sample_agent_data["agent_id"],
        connection_id=f"conn-{sample_resource_data['name']}",
        name=sample_resource_data["name"],
        url=sample_resource_data.get("url", "http://localhost:9000/mcp"),
        auth_method=sample_resource_data.get("auth_method", "okta-cross-app"),
    )
    agent = postgres_store.get_agent(
        sample_agent_data["agent_id"], enabled_only=False
    )
    return {
        "agent": agent,
        "resource": resource,
        "agent_success": agent_success,
        "resource_success": resource is not None,
    }


@pytest.fixture
def multi_seeded_db(
    postgres_store,
    sample_agent_data,
    sample_resource_data,
    sample_resource_static_key,
    sample_resource_service_account,
):
    agent1_data = sample_agent_data.copy()
    postgres_store.create_agent(
        agent1_data["agent_id"], agent1_data, user="test-fixture"
    )
    agent2_data = {
        "agent_id": "test-agent-2",
        "client_id": "0oa_test_client_2",
        "private_key": json.dumps({"kty": "RSA", "n": "test2", "e": "AQAB"}),
        "enabled": True,
    }
    postgres_store.create_agent(
        agent2_data["agent_id"], agent2_data, user="test-fixture"
    )

    r1 = _seed_synced_resource(
        postgres_store,
        agent_id=agent1_data["agent_id"],
        connection_id="conn-1",
        name=sample_resource_data["name"],
        url=sample_resource_data.get("url", "http://localhost:9000/mcp"),
        auth_method="okta-cross-app",
    )
    r2 = _seed_synced_resource(
        postgres_store,
        agent_id=agent1_data["agent_id"],
        connection_id="conn-2",
        name=sample_resource_static_key["name"],
        url=sample_resource_static_key.get("url", "http://localhost:9001/mcp"),
        auth_method="pre-shared-key",
    )
    r3 = _seed_synced_resource(
        postgres_store,
        agent_id=agent1_data["agent_id"],
        connection_id="conn-3",
        name=sample_resource_service_account["name"],
        url=sample_resource_service_account.get("url", "http://localhost:9002/mcp"),
        auth_method="service-account",
    )
    return {
        "agents": [
            postgres_store.get_agent(agent1_data["agent_id"], enabled_only=False),
            postgres_store.get_agent(agent2_data["agent_id"], enabled_only=False),
        ],
        "resources": [r1, r2, r3],
    }


# ============================================================================
# Mock Fixtures
# ============================================================================

@pytest.fixture
def mock_okta_validator():
    mock = MagicMock()
    mock.validate_token.return_value = {
        "sub": "test-user-id",
        "client_id": "0oa_test_client",
        "scope": "openid profile mcp:read",
    }
    return mock


@pytest.fixture
def mock_resource_response():
    mock = MagicMock()
    mock.status_code = 200
    mock.json.return_value = {"result": "success"}
    mock.headers = {"Content-Type": "application/json"}
    return mock


@pytest.fixture
def mock_encryption_service():
    mock = MagicMock(spec=EncryptionService)

    def mock_encrypt(plaintext):
        return (
            plaintext.encode("utf-8"),
            b"fake_iv_12_bytes",
            b"fake_tag_16_byte",
        )

    def mock_decrypt(ciphertext, iv, tag):
        return ciphertext.decode("utf-8")

    mock.encrypt.side_effect = mock_encrypt
    mock.decrypt.side_effect = mock_decrypt
    mock.key_id = "mock-key"
    return mock


# ============================================================================
# Utility Fixtures
# ============================================================================

@pytest.fixture
def clean_db(postgres_store):
    agents = postgres_store.get_all_agents(enabled_only=False)
    resources = postgres_store.get_all_resources()
    for agent in agents:
        postgres_store.delete_agent(agent["agent_id"], user="test-cleanup")
    for resource in resources:
        postgres_store.delete_resource(resource["name"], user="test-cleanup")
    yield postgres_store


@pytest.fixture(autouse=True)
def reset_database_state(request):
    """Truncate all test tables after each test.

    Autouse so every test starts from a clean slate, regardless of which
    fixture (or none) touched the database. Only triggers when ``test_pool``
    was explicitly requested via the fixture graph for this test — tests
    that never touch the DB (or modules that override ``postgres_url`` at
    a narrower scope, like ``test_database_pool.py``) skip the cost.
    """
    yield
    # Only resolve ``test_pool`` if it is already in this test's fixture
    # chain. Calling getfixturevalue() unconditionally would trigger a
    # ScopeMismatch in modules that override ``postgres_url`` at module
    # or function scope.
    if "test_pool" not in request.fixturenames:
        return
    try:
        pool = request.getfixturevalue("test_pool")
    except Exception:
        return
    try:
        with pool.connection() as conn:
            with conn.cursor() as cur:
                for table in _TABLES_TO_TRUNCATE:
                    cur.execute(f"DELETE FROM {table}")
            conn.commit()
    except Exception:
        pass
