"""Tests for redirect pattern syntax validator."""

import pytest

from okta_agent_proxy.auth.redirect_pattern_validator import (
    RedirectPatternError,
    validate_redirect_pattern,
    validate_redirect_patterns,
)


# ---------------------------------------------------------------------------
# Family A (http/https web) — ACCEPTED
# ---------------------------------------------------------------------------
@pytest.mark.parametrize("pattern", [
    "https://global.consent.azure-apim.net/redirect/*",
    "https://*.consent.azure-apim.net/redirect/*",
    "https://app.example.com/oauth/callback",
    "http://example.com/cb",
    "https://a.b.c.d.example.com/cb",
    "https://example.com:8443/cb",
    "https://example.com:*/cb",
    "https://example.com/cb/*/done",
])
def test_family_a_accepted(pattern):
    validate_redirect_pattern(pattern)  # should not raise


# ---------------------------------------------------------------------------
# Family A — REJECTED
# ---------------------------------------------------------------------------
@pytest.mark.parametrize("pattern, expected_substr", [
    ("https://*/*", "host must contain at least one dot"),
    ("https://*", "host must contain at least one dot"),
    ("https://*.com/*", "rightmost label"),
    ("https://consent.*.net/redirect/*", "wildcard"),
    ("https://a*.foo.com/*", "entire leftmost"),
    ("https://*b.foo.com/*", "entire leftmost"),
    ("https:///cb", "empty"),
    ("https://a.b.com/cb?x=1", "query"),
    ("https://a.b.com/cb#frag", "fragment"),
    ("https://a.b.com/a//b", "empty"),
    ("HTTPS://a.b.com/cb", "lowercase"),
])
def test_family_a_rejected(pattern, expected_substr):
    with pytest.raises(RedirectPatternError, match=f"(?i){expected_substr}"):
        validate_redirect_pattern(pattern)


# ---------------------------------------------------------------------------
# Family B (loopback) — ACCEPTED
# ---------------------------------------------------------------------------
@pytest.mark.parametrize("pattern", [
    "http://localhost/callback",
    "http://localhost:*/callback",
    "http://localhost:8080/callback",
    "http://127.0.0.1/callback",
    "http://127.0.0.1:*/callback",
    "http://[::1]/callback",
    "http://[::1]:*/callback",
])
def test_family_b_accepted(pattern):
    validate_redirect_pattern(pattern)


# ---------------------------------------------------------------------------
# Family B — REJECTED
# ---------------------------------------------------------------------------
def test_family_b_https_rejected():
    """Loopback requires http per RFC 8252 §8.3."""
    with pytest.raises(RedirectPatternError, match="(?i)loopback.*http"):
        validate_redirect_pattern("https://localhost/callback")


def test_localhost_evil_com_is_family_a_accepted():
    """'localhost.evil.com' is NOT Family B — the host isn't exactly 'localhost'.
    It falls through to Family A and IS accepted because it has a valid dotted
    host with a proper TLD."""
    validate_redirect_pattern("http://localhost.evil.com/cb")


def test_127_0_0_2_rejected_as_family_a():
    """127.0.0.2 is not a recognised loopback host, so it falls to Family A.
    Family A rejects it because '2' is not an alphabetic TLD."""
    with pytest.raises(RedirectPatternError, match="(?i)rightmost label|TLD"):
        validate_redirect_pattern("http://127.0.0.2/cb")


# ---------------------------------------------------------------------------
# Family C (private-use URI scheme) — ACCEPTED
# ---------------------------------------------------------------------------
@pytest.mark.parametrize("pattern", [
    "com.example.app:/oauth2redirect",
    "com.example.app:/oauth2redirect/*",
    "io.company.product:/callback",
    "org.example.my-app:/cb",
    # With authority — valid per C3
    "com.example.app://host/path",
    # No leading slash, scheme-specific part is non-empty — valid per C4
    "com.example.app:oauth2redirect",
    # Single-word schemes from real-world IDEs (Cursor, VS Code, Windsurf)
    "cursor://anysphere.cursor-mcp/oauth/callback",
    "vscode://vscode.vscode-mcp/oauth/callback",
    "windsurf://callback",
    "myapp:/callback",
])
def test_family_c_accepted(pattern):
    validate_redirect_pattern(pattern)


# ---------------------------------------------------------------------------
# Family C — REJECTED
# ---------------------------------------------------------------------------
@pytest.mark.parametrize("pattern, expected_substr", [
    ("com.example.app:", "non-empty path"),
    ("com.example.app://*/path", "wildcard"),
    ("COM.Example.App:/cb", "lowercase"),
    ("com.example.*.app:/cb", "wildcard"),
])
def test_family_c_rejected(pattern, expected_substr):
    with pytest.raises(RedirectPatternError, match=f"(?i){expected_substr}"):
        validate_redirect_pattern(pattern)


# ---------------------------------------------------------------------------
# Network-protocol schemes — REJECTED via DANGEROUS_SCHEMES
# ---------------------------------------------------------------------------
@pytest.mark.parametrize("pattern", [
    "ws://example.com/cb",
    "wss://example.com/cb",
    "mailto:user@example.com",
    "tel:+15555550100",
    "sms:+15555550100",
    "gopher://example.com/",
    "telnet://example.com/",
    "ssh://user@example.com/",
    "ldap://example.com/",
    "ldaps://example.com/",
])
def test_network_protocol_schemes_rejected(pattern):
    with pytest.raises(RedirectPatternError, match="(?i)not allowed|dangerous"):
        validate_redirect_pattern(pattern)


# ---------------------------------------------------------------------------
# Dangerous schemes — REJECTED
# ---------------------------------------------------------------------------
@pytest.mark.parametrize("pattern", [
    "javascript:alert(1)",
    "data:text/html,foo",
    "file:///etc/passwd",
    "vbscript:msgbox",
    "about:blank",
    "blob:https://a.b.com/x",
])
def test_dangerous_schemes_rejected(pattern):
    with pytest.raises(RedirectPatternError, match="(?i)dangerous"):
        validate_redirect_pattern(pattern)


# ---------------------------------------------------------------------------
# Common-rule violations — REJECTED
# ---------------------------------------------------------------------------
def test_empty_string_rejected():
    with pytest.raises(RedirectPatternError, match="(?i)empty|length"):
        validate_redirect_pattern("")


def test_too_long_rejected():
    with pytest.raises(RedirectPatternError, match="512"):
        validate_redirect_pattern("x" * 513)


def test_whitespace_rejected():
    with pytest.raises(RedirectPatternError, match="(?i)whitespace"):
        validate_redirect_pattern("https://a.b.com /cb")


def test_control_char_rejected():
    with pytest.raises(RedirectPatternError, match="(?i)control"):
        validate_redirect_pattern("https://a.b.com/\x00")


def test_bare_star_rejected():
    """'*' alone — urlparse gives empty scheme."""
    with pytest.raises(RedirectPatternError, match="(?i)scheme|absolute"):
        validate_redirect_pattern("*")


def test_star_callback_rejected():
    with pytest.raises(RedirectPatternError, match="(?i)scheme|absolute"):
        validate_redirect_pattern("*/callback")


def test_no_scheme_rejected():
    with pytest.raises(RedirectPatternError, match="(?i)scheme"):
        validate_redirect_pattern("example.com/cb")


def test_ftp_scheme_rejected():
    with pytest.raises(RedirectPatternError, match="(?i)ftp.*not allowed|reverse-DNS|RFC 8252"):
        validate_redirect_pattern("ftp://example.com/cb")


# ---------------------------------------------------------------------------
# validate_redirect_patterns — list-level behavior
# ---------------------------------------------------------------------------
def test_empty_list():
    assert validate_redirect_patterns([]) == []


def test_strips_whitespace():
    result = validate_redirect_patterns(["  https://a.b.com/cb  "])
    assert result == ["https://a.b.com/cb"]


def test_drops_empty_strings_after_stripping():
    result = validate_redirect_patterns(["", "  ", "https://a.b.com/cb"])
    assert result == ["https://a.b.com/cb"]


def test_deduplicates_preserving_order():
    result = validate_redirect_patterns([
        "https://a.b.com/cb",
        "https://c.d.com/cb",
        "https://a.b.com/cb",
    ])
    assert result == ["https://a.b.com/cb", "https://c.d.com/cb"]


def test_raises_on_first_bad_entry_with_index():
    with pytest.raises(RedirectPatternError, match=r"pattern\[1\].*javascript"):
        validate_redirect_patterns([
            "https://a.b.com/cb",
            "javascript:alert(1)",
            "https://c.d.com/cb",
        ])


def test_mixed_valid_invalid_raises_no_partial():
    """Does NOT return a partial list — raises on the first invalid entry."""
    with pytest.raises(RedirectPatternError):
        validate_redirect_patterns([
            "https://a.b.com/cb",
            "invalid",
        ])
