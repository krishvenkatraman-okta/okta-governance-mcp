"""
Tests for connection-scoped token cache key isolation.

Covers:
- _build_cache_key format with various field combinations
- Agent A's token not returned for Agent B
- Correct token returned for the same agent
- Invalidation scoped to specific agent+connection
- Backward compatibility: no agent_id behaves like legacy
"""

import pytest
from okta_agent_proxy.cache.token_cache import TokenCache


# ============================================================================
# Cache key format tests
# ============================================================================


class TestBuildCacheKey:

    def test_cache_key_includes_agent_and_connection(self):
        key = TokenCache._build_cache_key(
            "user-1", "hr-system", agent_id="agent-A", connection_id="conn-A1"
        )
        assert key == "user-1:agent-A:conn-A1:hr-system"

    def test_cache_key_without_agent_falls_back(self):
        key = TokenCache._build_cache_key("user-1", "hr-system")
        assert key == "user-1:hr-system"

    def test_cache_key_agent_only_no_connection(self):
        key = TokenCache._build_cache_key(
            "user-1", "hr-system", agent_id="agent-A"
        )
        assert key == "user-1:agent-A:hr-system"

    def test_cache_key_connection_only_no_agent(self):
        key = TokenCache._build_cache_key(
            "user-1", "hr-system", connection_id="conn-A1"
        )
        assert key == "user-1:conn-A1:hr-system"

    def test_different_agents_different_cache_keys(self):
        key_a = TokenCache._build_cache_key(
            "user-1", "hr-system", agent_id="agent-A", connection_id="conn-A1"
        )
        key_b = TokenCache._build_cache_key(
            "user-1", "hr-system", agent_id="agent-B", connection_id="conn-B1"
        )
        assert key_a != key_b

    def test_same_agent_different_connections_different_keys(self):
        key_1 = TokenCache._build_cache_key(
            "user-1", "hr-system", agent_id="agent-A", connection_id="conn-1"
        )
        key_2 = TokenCache._build_cache_key(
            "user-1", "hr-system", agent_id="agent-A", connection_id="conn-2"
        )
        assert key_1 != key_2

    def test_different_users_different_keys(self):
        key_1 = TokenCache._build_cache_key(
            "user-1", "hr-system", agent_id="agent-A", connection_id="conn-1"
        )
        key_2 = TokenCache._build_cache_key(
            "user-2", "hr-system", agent_id="agent-A", connection_id="conn-1"
        )
        assert key_1 != key_2


# ============================================================================
# Integration tests using real TokenCache (in-memory mode)
# ============================================================================


class TestTokenCacheIsolation:

    @pytest.fixture
    def cache(self):
        return TokenCache(max_size=1000, ttl_seconds=3600)

    def test_agent_a_token_not_returned_for_agent_b(self, cache):
        """Cache token for agent-A. Lookup for agent-B must return None."""
        cache.set(
            "user-1", "hr-system", "token-for-agent-A",
            agent_id="agent-A", connection_id="conn-A1",
        )
        result = cache.get(
            "user-1", "hr-system",
            agent_id="agent-B", connection_id="conn-B1",
        )
        assert result is None

    def test_agent_a_token_returned_for_same_agent(self, cache):
        """Cache token for agent-A. Lookup for agent-A must return it."""
        cache.set(
            "user-1", "hr-system", "token-for-agent-A",
            agent_id="agent-A", connection_id="conn-A1",
        )
        result = cache.get(
            "user-1", "hr-system",
            agent_id="agent-A", connection_id="conn-A1",
        )
        assert result == "token-for-agent-A"

    def test_invalidation_scoped_to_agent(self, cache):
        """Invalidate agent-A. Agent-B's token must still be there."""
        cache.set(
            "user-1", "hr-system", "token-A",
            agent_id="agent-A", connection_id="conn-A1",
        )
        cache.set(
            "user-1", "hr-system", "token-B",
            agent_id="agent-B", connection_id="conn-B1",
        )

        # Invalidate only agent-A
        cache.invalidate(
            "user-1", "hr-system",
            agent_id="agent-A", connection_id="conn-A1",
        )

        assert cache.get(
            "user-1", "hr-system",
            agent_id="agent-A", connection_id="conn-A1",
        ) is None
        assert cache.get(
            "user-1", "hr-system",
            agent_id="agent-B", connection_id="conn-B1",
        ) == "token-B"

    def test_local_resource_cache_backward_compatible(self, cache):
        """Cache with no agent_id. Lookup with no agent_id returns token."""
        cache.set("user-1", "hr-system", "legacy-token")
        result = cache.get("user-1", "hr-system")
        assert result == "legacy-token"

    def test_scoped_and_unscoped_coexist(self, cache):
        """Agent-scoped and legacy (unscoped) tokens for same resource don't collide."""
        cache.set("user-1", "hr-system", "legacy-token")
        cache.set(
            "user-1", "hr-system", "scoped-token",
            agent_id="agent-A", connection_id="conn-A1",
        )

        assert cache.get("user-1", "hr-system") == "legacy-token"
        assert cache.get(
            "user-1", "hr-system",
            agent_id="agent-A", connection_id="conn-A1",
        ) == "scoped-token"

    def test_invalidate_scoped_does_not_affect_unscoped(self, cache):
        """Invalidating an agent-scoped token leaves the unscoped one intact."""
        cache.set("user-1", "hr-system", "legacy-token")
        cache.set(
            "user-1", "hr-system", "scoped-token",
            agent_id="agent-A", connection_id="conn-A1",
        )

        cache.invalidate(
            "user-1", "hr-system",
            agent_id="agent-A", connection_id="conn-A1",
        )

        assert cache.get("user-1", "hr-system") == "legacy-token"
        assert cache.get(
            "user-1", "hr-system",
            agent_id="agent-A", connection_id="conn-A1",
        ) is None

    def test_invalidate_all_clears_scoped_tokens(self, cache):
        """Invalidating all tokens for a user clears both scoped and unscoped."""
        cache.set("user-1", "hr-system", "legacy-token")
        cache.set(
            "user-1", "hr-system", "scoped-token",
            agent_id="agent-A", connection_id="conn-A1",
        )

        cache.invalidate("user-1")

        assert cache.get("user-1", "hr-system") is None
        assert cache.get(
            "user-1", "hr-system",
            agent_id="agent-A", connection_id="conn-A1",
        ) is None
