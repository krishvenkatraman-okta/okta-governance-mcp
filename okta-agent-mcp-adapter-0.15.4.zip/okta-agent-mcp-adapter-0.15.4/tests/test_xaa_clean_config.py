"""
Tests for XAA resource config — verifying 410 after migration to Resources.

Resource CRUD endpoints are now deprecated (410 Gone).
GET /api/admin/resources proxies to the resource store + syncer.
"""

import pytest
from unittest.mock import MagicMock, AsyncMock
from starlette.requests import Request
from starlette.datastructures import Headers


def _make_request(method: str, body: dict = None, path_params: dict = None):
    """Build a minimal mock Starlette Request."""
    req = MagicMock(spec=Request)
    req.method = method
    req.headers = Headers({})
    req.client = MagicMock()
    req.client.host = "127.0.0.1"
    req.state = MagicMock()
    req.state.admin_user = "admin-user"
    req.path_params = path_params or {}

    async def json_body():
        return body or {}

    req.json = json_body
    return req


@pytest.mark.asyncio
async def test_get_xaa_resource_no_dead_fields():
    """GET /api/admin/resources/{name} proxies to get_resource (enriched view)."""
    from okta_agent_proxy.admin.routes import get_resource
    from okta_agent_proxy.resources.models import (
        ResolvedBackend, OktaConnectionType, Resource,
    )

    # Mock resource store entry
    entry = Resource(
        resource_id="aus123", name="hr-system", mcp_url="http://hr:8001/mcp",
    )
    mock_store = MagicMock()
    mock_store.get_by_name.return_value = entry

    # Mock syncer resolved resource
    rb = ResolvedBackend(
        resource_id="aus123", name="hr-system", mcp_url="http://hr:8001/mcp",
        connection_id="conn-1",
        connection_type=OktaConnectionType.IDENTITY_ASSERTION_CUSTOM_AS,
    )
    mock_syncer = MagicMock()
    mock_syncer.get_resource.return_value = rb

    mock_app = MagicMock()
    mock_app.get_resource_store.return_value = mock_store
    mock_app.get_resource_syncer.return_value = mock_syncer

    request = _make_request("GET", path_params={"name": "hr-system"})

    from unittest.mock import patch
    import sys
    with patch.dict(sys.modules, {"okta_agent_proxy.app": mock_app}):
        response = await get_resource.__wrapped__(request)

    assert response.status_code == 200
    import json
    body = json.loads(response.body)
    assert body["name"] == "hr-system"
    assert body["auth_method"] == "okta-cross-app"
    assert "target_client_id" not in body
    assert "target_client_secret" not in body


@pytest.mark.asyncio
async def test_other_auth_methods_unaffected():
    """GET /api/admin/resources (list) still returns resources from store+syncer."""
    from okta_agent_proxy.admin.routes import list_resources
    from okta_agent_proxy.resources.models import (
        ResolvedBackend, OktaConnectionType, Resource,
    )

    # Mock resource store
    entry = Resource(
        resource_id="sec1", name="psk-resource", mcp_url="http://psk:8001/mcp",
    )
    mock_store = MagicMock()
    mock_store.get_all.return_value = [entry]

    # Mock syncer with matching resolved resource
    rb = ResolvedBackend(
        resource_id="sec1", name="psk-resource", mcp_url="http://psk:8001/mcp",
        connection_id="conn-2",
        connection_type=OktaConnectionType.SECRET,
    )
    mock_syncer = MagicMock()
    mock_syncer.get_resource.return_value = rb

    mock_app = MagicMock()
    mock_app.get_resource_store.return_value = mock_store
    mock_app.get_resource_syncer.return_value = mock_syncer

    request = _make_request("GET")

    from unittest.mock import patch
    import sys
    with patch.dict(sys.modules, {"okta_agent_proxy.app": mock_app}):
        response = await list_resources.__wrapped__(request)

    assert response.status_code == 200
    import json
    body = json.loads(response.body)
    assert len(body["resources"]) == 1
    assert body["resources"][0]["auth_method"] == "vault-secret"
