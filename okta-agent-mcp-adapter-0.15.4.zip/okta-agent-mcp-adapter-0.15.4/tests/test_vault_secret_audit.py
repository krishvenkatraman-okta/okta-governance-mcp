"""
Tests for vault-secret and sts-service-account audit event emission.

Covers:
- AuditEventType entries exist with correct values
- AuditEvent serialization for new types
- Router emits correct audit events on success, failure, cache hit
- Unified handler emits correct audit events on success, failure
- Detail fields include connection_id and resource_orn
"""

import base64
import pytest
from datetime import datetime, timedelta
from unittest.mock import AsyncMock, MagicMock, patch

from okta_agent_proxy.audit.events import AuditEvent, AuditEventType, AuditSeverity
from okta_agent_proxy.auth.resource_token_resolver import ResourceTokenResolver, ResourceAuthResult
from okta_agent_proxy.cache.token_cache import TokenCache
from okta_agent_proxy.routing.router import ResourceRouter, ResolvedResourceConfigAdapter


FAKE_TOKEN = "eyJ.fake.id-token"
VAULT_ORN = "orn:okta:pam:00o123:secrets:abc-456"
SA_ORN = "orn:okta:pam:00o123:service_accounts:sa-789"

AGENT_CONFIG = {
    "agent_id": "test-agent",
    "client_id": "0oa_test",
    "private_key": '{"kty":"RSA","kid":"k1","n":"test","e":"AQAB","d":"test"}',
    "principal_id": "wlpTest",
}


def _make_rr(auth_method="vault-secret", connection_id="conn-1", metadata=None, name="test-res"):
    rb = MagicMock()
    rb.name = name
    rb.mcp_url = "https://mcp.example.com"
    rb.auth_method = auth_method
    rb.resource_id = "res-1"
    rb.connection_id = connection_id
    rb.connection_type = MagicMock(value=auth_method)
    rb.protocol = "mcp"
    rb.description = "test"
    rb.scopes = []
    rb.scope_condition = MagicMock(value="ALLOW_ALL")
    rb.metadata = metadata or {"resource_indicator": VAULT_ORN}
    rb.enabled = True
    rb.url = "https://mcp.example.com"
    return rb


def _mock_exchanger(vault_result=None, sa_result=None):
    e = MagicMock()
    e.exchange_vault_secret = AsyncMock(return_value=vault_result)
    e.exchange_service_account = AsyncMock(return_value=sa_result)
    return e


def _vault_ok(token="secret-val", ttl=300):
    return {"status": "success", "access_token": token, "expires_in": ttl, "provider": "test-res"}


def _sa_ok(u="svc", p="pass"):
    return {"status": "success", "username": u, "password": p, "provider": "test-res"}


# ============================================================================
# Event type tests
# ============================================================================

class TestEventTypes:

    def test_vault_secret_event_types_exist(self):
        assert hasattr(AuditEventType, "VAULT_SECRET_EXCHANGE_SUCCESS")
        assert hasattr(AuditEventType, "VAULT_SECRET_EXCHANGE_FAILURE")
        assert hasattr(AuditEventType, "VAULT_SECRET_CACHE_HIT")
        assert hasattr(AuditEventType, "STS_SERVICE_ACCOUNT_EXCHANGE_SUCCESS")
        assert hasattr(AuditEventType, "STS_SERVICE_ACCOUNT_EXCHANGE_FAILURE")
        assert hasattr(AuditEventType, "STS_SERVICE_ACCOUNT_CACHE_HIT")

    def test_vault_secret_event_type_values(self):
        assert AuditEventType.VAULT_SECRET_EXCHANGE_SUCCESS.value == "vault.secret.exchange.success"
        assert AuditEventType.VAULT_SECRET_EXCHANGE_FAILURE.value == "vault.secret.exchange.failure"
        assert AuditEventType.VAULT_SECRET_CACHE_HIT.value == "vault.secret.cache.hit"
        assert AuditEventType.STS_SERVICE_ACCOUNT_EXCHANGE_SUCCESS.value == "sts.service_account.exchange.success"
        assert AuditEventType.STS_SERVICE_ACCOUNT_EXCHANGE_FAILURE.value == "sts.service_account.exchange.failure"
        assert AuditEventType.STS_SERVICE_ACCOUNT_CACHE_HIT.value == "sts.service_account.cache.hit"

    def test_audit_event_serialization(self):
        event = AuditEvent(
            event_type=AuditEventType.VAULT_SECRET_EXCHANGE_SUCCESS,
            severity=AuditSeverity.INFO,
            correlation_id="corr-123",
            resource_name="my-vault",
            details={"connection_id": "conn-1", "resource_orn": VAULT_ORN},
        )
        d = event.to_dict()
        assert d["event_type"] == "vault.secret.exchange.success"
        assert d["severity"] == "info"
        assert d["details"]["connection_id"] == "conn-1"
        assert d["details"]["resource_orn"] == VAULT_ORN


# ============================================================================
# Router audit emission tests
# ============================================================================

class TestRouterAudit:

    @pytest.mark.asyncio
    async def test_vault_secret_success_emits_audit(self):
        router = ResourceRouter(resources_config={})
        adapter = ResolvedResourceConfigAdapter(_make_rr())
        exchanger = _mock_exchanger(vault_result=_vault_ok())

        with patch("okta_agent_proxy.routing.router.OktaVaultSecretExchanger", return_value=exchanger), \
             patch("okta_agent_proxy.routing.router.emit_audit_event", new_callable=AsyncMock) as mock_emit:
            await router._get_vault_secret_token("test-res", adapter, AGENT_CONFIG, FAKE_TOKEN)

        success_calls = [c for c in mock_emit.call_args_list if c[0][0] == AuditEventType.VAULT_SECRET_EXCHANGE_SUCCESS]
        assert len(success_calls) == 1
        assert success_calls[0].kwargs.get("resource_name") == "test-res"

    @pytest.mark.asyncio
    async def test_vault_secret_failure_emits_audit(self):
        router = ResourceRouter(resources_config={})
        adapter = ResolvedResourceConfigAdapter(_make_rr())
        exchanger = _mock_exchanger(vault_result=None)

        with patch("okta_agent_proxy.routing.router.OktaVaultSecretExchanger", return_value=exchanger), \
             patch("okta_agent_proxy.routing.router.emit_audit_event", new_callable=AsyncMock) as mock_emit:
            await router._get_vault_secret_token("test-res", adapter, AGENT_CONFIG, FAKE_TOKEN)

        fail_calls = [c for c in mock_emit.call_args_list if c[0][0] == AuditEventType.VAULT_SECRET_EXCHANGE_FAILURE]
        assert len(fail_calls) == 1
        assert fail_calls[0].kwargs.get("outcome") == "failure"

    @pytest.mark.asyncio
    async def test_vault_secret_cache_hit_emits_audit(self):
        router = ResourceRouter(resources_config={})
        adapter = ResolvedResourceConfigAdapter(_make_rr(connection_id="conn-cache"))

        router.resource_token_cache.set(
            "secret:test-res", "conn-cache",
            {"token": "cached", "expires_at": datetime.now() + timedelta(seconds=300)},
            ttl_seconds=300,
        )

        with patch("okta_agent_proxy.routing.router.emit_audit_event", new_callable=AsyncMock) as mock_emit:
            await router._get_vault_secret_token("test-res", adapter, AGENT_CONFIG, FAKE_TOKEN)

        cache_calls = [c for c in mock_emit.call_args_list if c[0][0] == AuditEventType.VAULT_SECRET_CACHE_HIT]
        assert len(cache_calls) == 1

    @pytest.mark.asyncio
    async def test_sts_sa_success_emits_audit(self):
        router = ResourceRouter(resources_config={})
        adapter = ResolvedResourceConfigAdapter(_make_rr(auth_method="sts-service-account", metadata={"resource_indicator": SA_ORN}))
        exchanger = _mock_exchanger(sa_result=_sa_ok())

        with patch("okta_agent_proxy.routing.router.OktaVaultSecretExchanger", return_value=exchanger), \
             patch("okta_agent_proxy.routing.router.emit_audit_event", new_callable=AsyncMock) as mock_emit:
            await router._get_sts_service_account_token("test-res", adapter, AGENT_CONFIG, FAKE_TOKEN)

        success_calls = [c for c in mock_emit.call_args_list if c[0][0] == AuditEventType.STS_SERVICE_ACCOUNT_EXCHANGE_SUCCESS]
        assert len(success_calls) == 1

    @pytest.mark.asyncio
    async def test_sts_sa_failure_emits_audit(self):
        router = ResourceRouter(resources_config={})
        adapter = ResolvedResourceConfigAdapter(_make_rr(auth_method="sts-service-account", metadata={"resource_indicator": SA_ORN}))
        exchanger = _mock_exchanger(sa_result=None)

        with patch("okta_agent_proxy.routing.router.OktaVaultSecretExchanger", return_value=exchanger), \
             patch("okta_agent_proxy.routing.router.emit_audit_event", new_callable=AsyncMock) as mock_emit:
            await router._get_sts_service_account_token("test-res", adapter, AGENT_CONFIG, FAKE_TOKEN)

        fail_calls = [c for c in mock_emit.call_args_list if c[0][0] == AuditEventType.STS_SERVICE_ACCOUNT_EXCHANGE_FAILURE]
        assert len(fail_calls) == 1
        assert fail_calls[0].kwargs.get("outcome") == "failure"

    @pytest.mark.asyncio
    async def test_sts_sa_cache_hit_emits_audit(self):
        router = ResourceRouter(resources_config={})
        adapter = ResolvedResourceConfigAdapter(_make_rr(auth_method="sts-service-account", connection_id="conn-sa-cache", metadata={"resource_indicator": SA_ORN}))

        router.resource_token_cache.set(
            "secret:test-res", "conn-sa-cache",
            {"token": "Basic dTpw", "expires_at": datetime.now() + timedelta(seconds=300)},
            ttl_seconds=300,
        )

        with patch("okta_agent_proxy.routing.router.emit_audit_event", new_callable=AsyncMock) as mock_emit:
            await router._get_sts_service_account_token("test-res", adapter, AGENT_CONFIG, FAKE_TOKEN)

        cache_calls = [c for c in mock_emit.call_args_list if c[0][0] == AuditEventType.STS_SERVICE_ACCOUNT_CACHE_HIT]
        assert len(cache_calls) == 1


# ============================================================================
# Unified handler audit emission tests
# ============================================================================

class TestUnifiedHandlerAudit:
    """Tests that ResourceTokenResolver emits correct audit events for vault-secret and sts-service-account exchanges."""

    def _make_rc(self, auth_method="vault-secret", metadata=None):
        rc = MagicMock()
        rc.auth_method = auth_method
        rc.metadata = metadata or {"resource_indicator": VAULT_ORN}
        rc.connection_id = "conn-1"
        rc.enabled = True
        rc.url = "https://mcp.example.com"
        ac = MagicMock()
        ac.model_dump.return_value = {}
        rc.auth_config = ac
        return rc

    @pytest.mark.asyncio
    async def test_vault_secret_success_emits_audit(self):
        token_cache = TokenCache(max_size=100, ttl_seconds=60)
        resolver = ResourceTokenResolver(token_cache)
        rc = self._make_rc()
        exchanger = _mock_exchanger(vault_result=_vault_ok())

        with patch("okta_agent_proxy.auth.okta_vault_exchanger.OktaVaultSecretExchanger", return_value=exchanger), \
             patch("okta_agent_proxy.auth.resource_token_resolver.emit_audit_event", new_callable=AsyncMock) as mock_emit:
            await resolver.resolve_auth_headers("test-res", rc, AGENT_CONFIG, "u1", FAKE_TOKEN)

        success_calls = [c for c in mock_emit.call_args_list if c[0][0] == AuditEventType.VAULT_SECRET_EXCHANGE_SUCCESS]
        assert len(success_calls) == 1
        assert success_calls[0].kwargs.get("resource_name") == "test-res"

    @pytest.mark.asyncio
    async def test_vault_secret_failure_emits_audit(self):
        token_cache = TokenCache(max_size=100, ttl_seconds=60)
        resolver = ResourceTokenResolver(token_cache)
        rc = self._make_rc()
        exchanger = _mock_exchanger(vault_result=None)

        with patch("okta_agent_proxy.auth.okta_vault_exchanger.OktaVaultSecretExchanger", return_value=exchanger), \
             patch("okta_agent_proxy.auth.resource_token_resolver.emit_audit_event", new_callable=AsyncMock) as mock_emit:
            await resolver.resolve_auth_headers("test-res", rc, AGENT_CONFIG, "u1", FAKE_TOKEN)

        fail_calls = [c for c in mock_emit.call_args_list if c[0][0] == AuditEventType.VAULT_SECRET_EXCHANGE_FAILURE]
        assert len(fail_calls) >= 1

    @pytest.mark.asyncio
    async def test_sts_sa_success_emits_audit(self):
        token_cache = TokenCache(max_size=100, ttl_seconds=60)
        resolver = ResourceTokenResolver(token_cache)
        rc = self._make_rc(auth_method="sts-service-account", metadata={"resource_indicator": SA_ORN})
        exchanger = _mock_exchanger(sa_result=_sa_ok())

        with patch("okta_agent_proxy.auth.okta_vault_exchanger.OktaVaultSecretExchanger", return_value=exchanger), \
             patch("okta_agent_proxy.auth.resource_token_resolver.emit_audit_event", new_callable=AsyncMock) as mock_emit:
            await resolver.resolve_auth_headers("test-res", rc, AGENT_CONFIG, "u1", FAKE_TOKEN)

        success_calls = [c for c in mock_emit.call_args_list if c[0][0] == AuditEventType.STS_SERVICE_ACCOUNT_EXCHANGE_SUCCESS]
        assert len(success_calls) == 1

    @pytest.mark.asyncio
    async def test_sts_sa_failure_emits_audit(self):
        token_cache = TokenCache(max_size=100, ttl_seconds=60)
        resolver = ResourceTokenResolver(token_cache)
        rc = self._make_rc(auth_method="sts-service-account", metadata={"resource_indicator": SA_ORN})
        exchanger = _mock_exchanger(sa_result=None)

        with patch("okta_agent_proxy.auth.okta_vault_exchanger.OktaVaultSecretExchanger", return_value=exchanger), \
             patch("okta_agent_proxy.auth.resource_token_resolver.emit_audit_event", new_callable=AsyncMock) as mock_emit:
            await resolver.resolve_auth_headers("test-res", rc, AGENT_CONFIG, "u1", FAKE_TOKEN)

        fail_calls = [c for c in mock_emit.call_args_list if c[0][0] == AuditEventType.STS_SERVICE_ACCOUNT_EXCHANGE_FAILURE]
        assert len(fail_calls) >= 1


# ============================================================================
# Detail field tests
# ============================================================================

class TestDetailFields:

    @pytest.mark.asyncio
    async def test_vault_audit_details_include_connection_id(self):
        router = ResourceRouter(resources_config={})
        adapter = ResolvedResourceConfigAdapter(_make_rr(connection_id="conn-detail"))
        exchanger = _mock_exchanger(vault_result=_vault_ok())

        with patch("okta_agent_proxy.routing.router.OktaVaultSecretExchanger", return_value=exchanger), \
             patch("okta_agent_proxy.routing.router.emit_audit_event", new_callable=AsyncMock) as mock_emit:
            await router._get_vault_secret_token("test-res", adapter, AGENT_CONFIG, FAKE_TOKEN)

        success_calls = [c for c in mock_emit.call_args_list if c[0][0] == AuditEventType.VAULT_SECRET_EXCHANGE_SUCCESS]
        assert success_calls[0].kwargs["details"]["connection_id"] == "conn-detail"

    @pytest.mark.asyncio
    async def test_vault_audit_details_include_resource_orn(self):
        router = ResourceRouter(resources_config={})
        adapter = ResolvedResourceConfigAdapter(_make_rr(metadata={"resource_indicator": VAULT_ORN}))
        exchanger = _mock_exchanger(vault_result=_vault_ok())

        with patch("okta_agent_proxy.routing.router.OktaVaultSecretExchanger", return_value=exchanger), \
             patch("okta_agent_proxy.routing.router.emit_audit_event", new_callable=AsyncMock) as mock_emit:
            await router._get_vault_secret_token("test-res", adapter, AGENT_CONFIG, FAKE_TOKEN)

        success_calls = [c for c in mock_emit.call_args_list if c[0][0] == AuditEventType.VAULT_SECRET_EXCHANGE_SUCCESS]
        assert success_calls[0].kwargs["details"]["resource_orn"] == VAULT_ORN
