---
description: Run comprehensive read-only codebase analysis using all 7 specialist subagents in parallel. Includes domain-specific OAuth/MCP compliance and architecture health checks. Reports written to reports/ directory.
---

## Instructions

First, ensure the `reports/` directory exists:
```bash
mkdir -p reports
```

Then run the following 7 subagents **IN PARALLEL** against the `okta_agent_proxy/` codebase. Each subagent writes its own report to `reports/`. **No source files may be modified by any subagent.**

### Subagents to invoke (all in parallel):

**Core Analysis (6 agents):**
1. **dedup-analyzer** → `reports/duplication-analysis.md`
2. **perf-analyzer** → `reports/performance-analysis.md`
3. **best-practice-reviewer** → `reports/best-practices-analysis.md`
4. **comment-analyzer** → `reports/documentation-analysis.md`
5. **security-auditor** → `reports/security-audit.md`
6. **test-coverage-analyzer** → `reports/test-coverage-analysis.md`

**Domain-Specific Analysis (1 agents):**
7. **architecture-health** → `reports/architecture-health.md`

### After all 7 complete:

Read each report from `reports/` and produce a unified executive summary in `reports/EXECUTIVE_SUMMARY.md` with:

- **Top 10 most impactful findings** across all reports, ranked by severity and effort
- **Recommended priority order** for remediation
- **Estimated effort** for each (small: <1hr, medium: 1-4hr, large: 4hr+)
- **A sequenced remediation plan** that won't break the existing 397+ tests
- **Cross-cutting themes** — patterns that appear in multiple reports
- **Quick wins** — high impact, low effort items to tackle first
- **Protocol compliance summary** — any spec violations that could cause interop issues
- **Architecture health score** — overall assessment with key concerns
