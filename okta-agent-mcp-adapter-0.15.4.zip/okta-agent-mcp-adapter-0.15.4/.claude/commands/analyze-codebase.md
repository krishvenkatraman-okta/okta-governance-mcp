---
description: Run read-only codebase analysis. Invoke with no args to run all 6 specialists in parallel, or pass one or more agent names (e.g., "dedup-analyzer") to run only those.
argument-hint: [subagent-name ...]
---

## Instructions

Target subagent(s): `$ARGUMENTS`

First, ensure the `reports/` directory exists:
```bash
mkdir -p reports
```

### Dispatch logic

**If `$ARGUMENTS` is empty** → run ALL 6 subagents IN PARALLEL (original behavior), then produce the executive summary.

**If `$ARGUMENTS` names one subagent** → invoke ONLY that subagent. Skip the executive summary (it's single-report, not cross-cutting).

**If `$ARGUMENTS` names multiple (space- or comma-separated)** → invoke those in parallel. Produce the executive summary only if ≥3 are named.

Validate names against the table below before dispatching. If an unknown name is passed, stop and list the valid names.

### Available subagents

| Name | Focus | Report path |
|---|---|---|
| `dedup-analyzer` | Code duplication | `reports/duplication-analysis.md` |
| `perf-analyzer` | Async pipeline bottlenecks | `reports/performance-analysis.md` |
| `best-practice-reviewer` | Python/FastAPI best practices | `reports/best-practices-analysis.md` |
| `comment-analyzer` | Doc + comment quality | `reports/documentation-analysis.md` |
| `security-auditor` | OAuth/OIDC security | `reports/security-audit.md` |
| `test-coverage-analyzer` | Test coverage gaps | `reports/test-coverage-analysis.md` |

All subagents run read-only against `okta_agent_proxy/`. No source files may be modified.

### Executive summary (only when running all 6 or ≥3)

Read each report from `reports/` and produce `reports/EXECUTIVE_SUMMARY.md` with:

- **Top 10 most impactful findings** across all reports, ranked by severity and effort
- **Recommended priority order** for remediation
- **Estimated effort** for each (small: <1hr, medium: 1-4hr, large: 4hr+)
- **A sequenced remediation plan** that won't break the existing 397+ tests
- **Cross-cutting themes** — patterns that appear in multiple reports
- **Quick wins** — high impact, low effort items to tackle first
