# -----------------------------------------------------------------------------
# outputs.tf — Outputs for the Okta MCP Adapter ECS Fargate deployment
# -----------------------------------------------------------------------------
# Outputs are added incrementally as resources are created in each prompt.

# --- E1: VPC + ECR ---

output "vpc_id" {
  description = "VPC ID"
  value       = local.vpc_id
}

output "private_subnet_ids" {
  description = "Private subnet IDs (ECS tasks, RDS, ElastiCache)"
  value       = local.private_subnet_ids
}

output "public_subnet_ids" {
  description = "Public subnet IDs (ALB)"
  value       = local.public_subnet_ids
}

output "ecr_adapter_url" {
  description = "ECR repository URL for the adapter image"
  value       = local.ecr_adapter_url
}

output "ecr_admin_ui_url" {
  description = "ECR repository URL for the admin UI image"
  value       = local.ecr_admin_ui_url
}

# --- E2: Data Tier ---

output "rds_endpoint" {
  description = "RDS PostgreSQL endpoint (host:port)"
  value       = aws_db_instance.this.endpoint
}

output "rds_db_name" {
  description = "RDS database name"
  value       = aws_db_instance.this.db_name
}

output "redis_endpoint" {
  description = "Redis endpoint (instance primary or serverless)"
  value = (
    var.cache_type == "instance"
    ? aws_elasticache_replication_group.main[0].primary_endpoint_address
    : aws_elasticache_serverless_cache.main[0].endpoint[0].address
  )
}

# --- E3: Secrets Manager + IAM Roles ---

output "ecs_task_execution_role_arn" {
  description = "ARN of the ECS task execution role"
  value       = aws_iam_role.ecs_task_execution.arn
}

output "ecs_task_role_arn" {
  description = "ARN of the ECS task role"
  value       = aws_iam_role.ecs_task.arn
}

output "ecs_task_migrate_role_arn" {
  description = "ARN of the migrate task role (db owner). P13 — used by the one-shot migration task only."
  value       = aws_iam_role.ecs_task_migrate.arn
}

output "migrate_task_definition_arn" {
  description = "ARN of the one-shot migrate task definition. P13 — run via `aws ecs run-task` before the adapter service is updated."
  value       = aws_ecs_task_definition.migrate.arn
}

output "migrate_task_definition_family" {
  description = "Family name of the migrate task definition. Convenient for deploy.sh / CI callers."
  value       = aws_ecs_task_definition.migrate.family
}

output "use_rds_iam" {
  description = "Whether the adapter authenticates to RDS via IAM (true) or a static password (false). P13."
  value       = var.use_rds_iam
}

output "secrets_db_arn" {
  description = "ARN of the database secrets"
  value       = aws_secretsmanager_secret.db.arn
}

# Phase 2: no secrets_redis_arn — Redis uses ElastiCache IAM auth,
# with no Secrets Manager entry.

output "secrets_okta_arn" {
  description = "ARN of the Okta secrets"
  value       = aws_secretsmanager_secret.okta.arn
}

output "secrets_app_arn" {
  description = "ARN of the application secrets"
  value       = aws_secretsmanager_secret.app.arn
}

# --- E6: ALB + DNS ---

output "alb_dns_name" {
  description = "ALB DNS name"
  value       = aws_lb.main.dns_name
}

output "adapter_url" {
  description = "Adapter public URL"
  value       = "https://${var.adapter_hostname}"
}

output "admin_url" {
  description = "Admin UI public URL"
  value       = "https://${var.admin_hostname}"
}

output "acm_certificate_arn" {
  description = "ACM certificate ARN"
  value       = local.acm_certificate_arn
}

# --- E11: DNS Provider ---

output "dns_provider_tier" {
  description = "Active DNS provider tier"
  value       = var.dns_provider
}

output "acm_validation_records" {
  description = "DNS validation records for the ACM certificate. In Tier 1/2 Terraform creates these automatically. In Tier 3 the operator creates them manually in the external DNS provider. Empty when using BYO certificate."
  value = var.existing_acm_certificate_arn != "" ? [] : [
    for dvo in aws_acm_certificate.this[0].domain_validation_options : {
      name  = dvo.resource_record_name
      value = dvo.resource_record_value
      type  = dvo.resource_record_type
    }
  ]
}

output "alb_hostname_records_required" {
  description = "CNAME records the operator must create when dns_provider = 'external'. In Tier 1/2 Terraform creates these automatically and this output is informational only."
  value = var.dns_provider == "external" ? [
    {
      name  = var.adapter_hostname
      value = aws_lb.main.dns_name
      type  = "CNAME"
    },
    {
      name  = var.admin_hostname
      value = aws_lb.main.dns_name
      type  = "CNAME"
    }
  ] : []
}

# --- E9: CodeBuild (conditional) ---

output "codebuild_project_name" {
  description = "CodeBuild project name for image builds"
  value       = var.enable_codebuild ? aws_codebuild_project.image_builder[0].name : null
}

output "codebuild_source_bucket" {
  description = "S3 bucket for CodeBuild source uploads"
  value       = var.enable_codebuild ? local.codebuild_source_bucket : null
}

output "codebuild_role_name" {
  description = "Name of the CodeBuild IAM role. Examples project attaches a scoped ECR push policy for its ECR repos."
  value       = var.enable_codebuild ? aws_iam_role.codebuild[0].name : null
}

# --- E15: Enterprise BYO status ---

output "using_existing_vpc" {
  description = "Whether the deployment uses an existing VPC"
  value       = var.use_existing_vpc
}

output "using_existing_acm_cert" {
  description = "Whether the deployment uses an existing ACM certificate"
  value       = var.existing_acm_certificate_arn != ""
}

output "using_existing_ecr_repos" {
  description = "Whether the deployment uses existing ECR repositories"
  value       = var.byo_ecr_repos
}

output "alb_scheme" {
  description = "ALB scheme (internet-facing or internal)"
  value       = var.alb_scheme
}

output "waf_attached" {
  description = "Whether a WAF Web ACL is attached to the ALB"
  value       = var.existing_waf_web_acl_arn != ""
}

# -----------------------------------------------------------------------------
# Shared contract — consumed by deploy/aws-ecs-examples
# -----------------------------------------------------------------------------
# These outputs are read by the examples project via core-outputs.json.
# Do not remove without updating deploy/aws-ecs-examples/deploy.sh.

output "aws_region" {
  value       = var.aws_region
  description = "Region of this deployment; examples consume for their provider."
}

output "project_name" {
  value       = local.project_name
  description = "Project name prefix; examples use for resource naming."
}

output "cluster_arn" {
  value       = aws_ecs_cluster.main.arn
  description = "ECS cluster ARN; examples run tasks here."
}

output "cluster_name" {
  value       = aws_ecs_cluster.main.name
  description = "ECS cluster name."
}

output "service_discovery_namespace_arn" {
  value       = aws_service_discovery_private_dns_namespace.main.arn
  description = "Service Connect namespace ARN; examples attach here."
}

output "ecs_tasks_sg_id" {
  value       = aws_security_group.ecs_tasks_sg.id
  description = "ECS tasks security group ID; examples reuse."
}

output "alb_sg_id" {
  value       = aws_security_group.alb_sg.id
  description = "ALB security group ID."
}

output "common_tags" {
  value       = local.common_tags
  description = "Tags applied to core resources; examples should merge."
}

# --- Ports ---

output "gateway_port" {
  value       = var.gateway_port
  description = "Adapter gateway port; examples and operators reference."
}

output "admin_ui_port" {
  value       = var.admin_ui_port
  description = "Admin UI port."
}
