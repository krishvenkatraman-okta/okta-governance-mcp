#!/usr/bin/env bash
set -euo pipefail

# =============================================================
# deploy-ui.sh — Quick redeploy of just the Admin UI
# =============================================================
# Builds a new admin-ui image, pushes to ECR, and forces a new
# ECS service deployment. Run from the deploy/aws-ecs/ directory.
# ~2-3 minutes for a full rebuild + deploy cycle.
# =============================================================

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
REPO_ROOT="$(cd "$SCRIPT_DIR/../.." && pwd)"

# ---- Colors ----
if [[ -n "${NO_COLOR:-}" ]] || [[ ! -t 1 ]]; then
  RED='' GREEN='' CYAN='' YELLOW='' NC=''
else
  RED='\033[0;31m'
  GREEN='\033[0;32m'
  CYAN='\033[0;36m'
  YELLOW='\033[1;33m'
  NC='\033[0m'
fi

info() { printf "${CYAN}[INFO]${NC}  %s\n" "$*"; }
ok()   { printf "${GREEN}[  OK]${NC}  %s\n" "$*"; }
warn() { printf "${YELLOW}[WARN]${NC}  %s\n" "$*" >&2; }
die()  { printf "${RED}[FAIL]${NC}  %s\n" "$*" >&2; exit 1; }

# ---- Required env vars ----
AWS_REGION="${AWS_REGION:-us-east-1}"
AWS_ACCOUNT_ID="${AWS_ACCOUNT_ID:-$(aws sts get-caller-identity --query Account --output text)}"
ECR_REGISTRY="${AWS_ACCOUNT_ID}.dkr.ecr.${AWS_REGION}.amazonaws.com"
CLUSTER_NAME="${CLUSTER_NAME:-oktaps-mcp-cluster}"
SERVICE_NAME="admin-ui"

# Build tag with timestamp for traceability
BUILD_TAG="build-$(date +%Y%m%d-%H%M%S)"

echo ""
info "Redeploying admin-ui (${BUILD_TAG})"
echo ""

# ---- Authenticate to ECR ----
info "Authenticating to ECR..."
aws ecr get-login-password --region "$AWS_REGION" | \
  docker login --username AWS --password-stdin "$ECR_REGISTRY" 2>/dev/null
ok "ECR authentication successful"

# ---- Build and push ----
info "Building admin-ui image ($BUILD_TAG)..."
docker buildx build \
  --platform linux/amd64 \
  -t "${ECR_REGISTRY}/oktaps-mcp-admin-ui:${BUILD_TAG}" \
  -t "${ECR_REGISTRY}/oktaps-mcp-admin-ui:latest" \
  -f "${REPO_ROOT}/okta_agent_proxy_admin_ui/Dockerfile" \
  --push \
  "${REPO_ROOT}/okta_agent_proxy_admin_ui"
ok "Image pushed: oktaps-mcp-admin-ui:${BUILD_TAG}"

# ---- Force new deployment ----
info "Forcing new ECS deployment..."
aws ecs update-service \
  --cluster "$CLUSTER_NAME" \
  --service "$SERVICE_NAME" \
  --force-new-deployment \
  --region "$AWS_REGION" \
  --no-cli-pager >/dev/null
ok "Deployment triggered"

# ---- Wait for service to stabilize ----
info "Waiting for service to stabilize..."
if aws ecs wait services-stable \
     --cluster "$CLUSTER_NAME" \
     --services "$SERVICE_NAME" \
     --region "$AWS_REGION" 2>/dev/null; then
  ok "Service stable"
else
  warn "Stabilization timed out. Check: aws ecs describe-services --cluster $CLUSTER_NAME --services $SERVICE_NAME --region $AWS_REGION"
fi

# ---- Health check ----
ADMIN_HOSTNAME="${TF_VAR_admin_hostname:-}"
if [[ -n "$ADMIN_HOSTNAME" ]]; then
  info "Running health check..."
  elapsed=0
  while (( elapsed < 120 )); do
    HTTP_CODE=$(curl -so /dev/null -w '%{http_code}' "https://$ADMIN_HOSTNAME/" 2>/dev/null || echo "000")
    if [[ "$HTTP_CODE" == "200" ]] || [[ "$HTTP_CODE" == "302" ]]; then
      ok "Admin UI responding (HTTP $HTTP_CODE) after ${elapsed}s"
      echo ""
      ok "Admin UI redeployed: ${BUILD_TAG}"
      exit 0
    fi
    printf "."
    sleep 5
    elapsed=$((elapsed + 5))
  done
  echo ""
  die "Health check timed out. Check: aws ecs describe-services --cluster $CLUSTER_NAME --services $SERVICE_NAME --region $AWS_REGION"
else
  ok "No TF_VAR_admin_hostname set — skipping health check"
  echo ""
  ok "Admin UI redeployed: ${BUILD_TAG}"
fi
