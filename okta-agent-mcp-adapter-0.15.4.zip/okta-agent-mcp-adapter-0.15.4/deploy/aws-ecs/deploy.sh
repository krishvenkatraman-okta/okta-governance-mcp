#!/usr/bin/env bash
set -euo pipefail

# =============================================================
# deploy.sh — Terraform wrapper for the Okta MCP Adapter
#              ECS Fargate deployment
# =============================================================
# Default: pulls prebuilt images from public.ecr.aws/${ECR_PUBLIC_ALIAS:-oktaps}/
# at tag v<pyproject version>. No Docker, no CodeBuild, no private ECR repos.
#
# Usage:
#   ./deploy.sh --apply                      Deploy (default if no args)
#   ./deploy.sh --plan                       Preview changes
#   ./deploy.sh --destroy                    Tear down all resources
#   ./deploy.sh --apply --build-from-source  Build+push via CodeBuild (opt-in)
# =============================================================

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
cd "$SCRIPT_DIR"

# ---- Colors ----
if [[ -n "${NO_COLOR:-}" ]] || [[ ! -t 1 ]]; then
  RED='' GREEN='' CYAN='' YELLOW='' BOLD='' NC=''
else
  RED='\033[0;31m'
  GREEN='\033[0;32m'
  CYAN='\033[0;36m'
  YELLOW='\033[0;33m'
  BOLD='\033[1m'
  NC='\033[0m'
fi

info()  { printf "${CYAN}[INFO]${NC}  %b\n" "$*"; }
ok()    { printf "${GREEN}[  OK]${NC}  %b\n" "$*"; }
warn()  { printf "${YELLOW}[WARN]${NC}  %b\n" "$*"; }
die()   { printf "${RED}[FAIL]${NC}  %b\n" "$*" >&2; exit 1; }

# ---- Parse arguments ----
# Flag aliasing (P15):
#   --skip-migrate  ≡  --no-bootstrap   (both set RUN_DB_BOOTSTRAP=false)
#   --migrate       ≡  --migrate-only   (both skip terraform apply and
#                                        only run the bootstrap path)
ACTION="apply"
SKIP_MIGRATE=false
BUILD_FROM_SOURCE=false
USE_LOCAL_DOCKER=false
PUBLIC_IMAGE_TAG=""

while [[ $# -gt 0 ]]; do
  case "$1" in
    --apply)            ACTION="apply"; shift ;;
    --plan)             ACTION="plan"; shift ;;
    --destroy)          ACTION="destroy"; shift ;;
    --migrate|--migrate-only)           ACTION="migrate"; shift ;;
    --skip-migrate|--no-bootstrap)      SKIP_MIGRATE=true; shift ;;
    --build-from-source) BUILD_FROM_SOURCE=true; shift ;;
    --use-local-docker)  USE_LOCAL_DOCKER=true; BUILD_FROM_SOURCE=true; shift ;;
    --tag=*)             PUBLIC_IMAGE_TAG="${1#--tag=}"; shift ;;
    -h|--help)
      echo "Usage: ./deploy.sh [--apply|--plan|--destroy|--migrate] [--build-from-source [--use-local-docker]] [--tag=vX.Y.Z] [--skip-migrate]"
      echo ""
      echo "  --apply                     Deploy infrastructure and services (default)."
      echo "                              Default image source: public.ecr.aws/\${ECR_PUBLIC_ALIAS:-oktaps}/"
      echo "                              at tag v<pyproject version>."
      echo "  --plan                      Preview Terraform changes"
      echo "  --destroy                   Tear down all resources"
      echo "  --migrate, --migrate-only   Run the one-shot DB bootstrap task only (no infra changes)"
      echo "  --skip-migrate, --no-bootstrap"
      echo "                              On --apply: do not run the bootstrap task (advanced;"
      echo "                              DB schema must already be at the required version). Equivalent to"
      echo "                              RUN_DB_BOOTSTRAP=false."
      echo "  --build-from-source         Opt out of public images. Build and push adapter + admin-ui"
      echo "                              to a private ECR in this account via AWS CodeBuild."
      echo "  --use-local-docker          With --build-from-source, build locally with Docker instead"
      echo "                              of CodeBuild. Implies --build-from-source."
      echo "  --tag=vX.Y.Z                Override the public-image tag. Accepts 'latest' or any"
      echo "                              published tag. Ignored with a warning when --build-from-source."
      echo "  -h, --help                  Show this help"
      echo ""
      echo "Environment variables (P15):"
      echo "  RUN_DB_BOOTSTRAP=true|false"
      echo "      true  (default): run bootstrap_roles.sql + migrations as part of deploy."
      echo "      false          : skip; print an operator handoff block. Same as --no-bootstrap."
      echo "  DB_BOOTSTRAP_FORCE_LOCAL=true|false"
      echo "      Skip the cloud-native ECS job attempt and run bootstrap from the"
      echo "      deploy host via psql + the project venv."
      echo "  DB_BOOTSTRAP_TIMEOUT=<seconds>"
      echo "      Max seconds to wait for the cloud-native job (default 600)."
      exit 0
      ;;
    *) die "Unknown argument: $1. Use --help for usage." ;;
  esac
done

# Honor RUN_DB_BOOTSTRAP=false as an alias for --skip-migrate / --no-bootstrap
# so operators can set it in their pipeline config without touching the CLI.
if [[ "${RUN_DB_BOOTSTRAP:-true}" != "true" ]]; then
  SKIP_MIGRATE=true
fi

# --build-from-source requires the source tree at ../../. If it's missing
# this is the deploy-only packaged tarball. Fail fast with a concrete fix
# before touching AWS or Terraform.
if [[ "$BUILD_FROM_SOURCE" == "true" ]]; then
  for required in Dockerfile okta_agent_proxy; do
    if [[ ! -e "$SCRIPT_DIR/../../$required" ]]; then
      die "--build-from-source requires the source tree (missing: ../../${required}).\n\n  This looks like the deploy-only bundle. To build from source, either:\n    - Extract the okta-ps-adapter-aws-ecs-source-<version>.tar.gz bundle, or\n    - Run from a git checkout of the repository.\n\n  Otherwise drop --build-from-source to pull prebuilt images from ECR Public."
    fi
  done
fi

# Source the cross-cloud bootstrap helper (P15). Lives one level up so it
# can be shared by Azure ACA scripts too.
# shellcheck disable=SC1091
source "$SCRIPT_DIR/../shell-lib/db_bootstrap.sh"

# ---- Secrets file helpers ----
SECRETS_FILE="$SCRIPT_DIR/.generated-secrets"

save_secrets() {
  cat > "$SECRETS_FILE" <<EOF
# Auto-generated secrets — do not commit
TF_VAR_encryption_key="${TF_VAR_encryption_key}"
EOF
  chmod 600 "$SECRETS_FILE"
}

load_secrets() {
  if [[ -f "$SECRETS_FILE" ]]; then
    info "Loading saved secrets from .generated-secrets"
    # shellcheck disable=SC1090
    set -a
    source "$SECRETS_FILE"
    set +a
  fi
}

# ---- Pre-flight checks ----
info "Running pre-flight checks..."

# AWS CLI
if ! aws sts get-caller-identity --no-cli-pager >/dev/null 2>&1; then
  die "AWS CLI not authenticated. Run 'aws configure' or set AWS_PROFILE."
fi
AWS_ACCOUNT_ID=$(aws sts get-caller-identity --query Account --output text)
export AWS_ACCOUNT_ID
ok "AWS account: ${AWS_ACCOUNT_ID}"

# Resolve region: TF_VAR_aws_region > AWS_REGION > default us-east-1
# Sync both so Terraform and build scripts use the same value.
AWS_REGION="${TF_VAR_aws_region:-${AWS_REGION:-us-east-1}}"
export AWS_REGION
export TF_VAR_aws_region="$AWS_REGION"
ok "AWS region: ${AWS_REGION}"

# ---- Image source wiring ----
# Default path: task defs pull from public.ecr.aws/${ECR_PUBLIC_ALIAS:-oktaps}/.
# Terraform is steered via TF_VAR_* so no tfvars edits are needed:
#   - byo_ecr_repos=true            -> skip creating private ECR repos
#   - existing_ecr_*_url            -> point task defs at public registry
#   - adapter/admin_ui_image_tag    -> pin to the released version
#   - enable_codebuild=false        -> no CodeBuild project needed for pull-only
#
# --build-from-source skips this block so TF defaults apply (private ECR +
# CodeBuild). --use-local-docker also builds from source but swaps CodeBuild
# for local Docker in the build phase below.
if [[ "$BUILD_FROM_SOURCE" == "true" ]]; then
  if [[ -n "$PUBLIC_IMAGE_TAG" ]]; then
    warn "--tag=${PUBLIC_IMAGE_TAG} ignored when --build-from-source is set."
  fi
else
  if [[ -z "$PUBLIC_IMAGE_TAG" ]]; then
    PYPROJECT="$SCRIPT_DIR/../../pyproject.toml"
    if [[ -f "$PYPROJECT" ]]; then
      VERSION=$(grep -m1 '^version' "$PYPROJECT" | sed 's/.*= *"\(.*\)"/\1/')
      [[ -n "$VERSION" ]] && PUBLIC_IMAGE_TAG="v${VERSION}"
    fi
    [[ -n "$PUBLIC_IMAGE_TAG" ]] || die "Could not resolve version from pyproject.toml; pass --tag= explicitly."
  fi

  ECR_PUBLIC_ALIAS="${ECR_PUBLIC_ALIAS:-oktaps}"
  export TF_VAR_byo_ecr_repos=true
  export TF_VAR_existing_ecr_adapter_url="public.ecr.aws/${ECR_PUBLIC_ALIAS}/okta-mcp-adapter"
  export TF_VAR_existing_ecr_admin_ui_url="public.ecr.aws/${ECR_PUBLIC_ALIAS}/okta-mcp-admin-ui"
  export TF_VAR_adapter_image_tag="$PUBLIC_IMAGE_TAG"
  export TF_VAR_admin_ui_image_tag="$PUBLIC_IMAGE_TAG"
  export TF_VAR_enable_codebuild=false

  ok "Public images: public.ecr.aws/${ECR_PUBLIC_ALIAS}/okta-mcp-{adapter,admin-ui}:${PUBLIC_IMAGE_TAG}"
  ok "Build step will be skipped."
fi

# ---- Terraform credential visibility check ----
# The AWS CLI's credential chain and Terraform's AWS SDK credential chain
# are not identical. Specifically, the Go SDK that Terraform uses does
# NOT read credentials cached in the macOS Keychain (a common default for
# Okta federated CLIs and some SSO tools). So `aws sts get-caller-identity`
# can succeed while `terraform apply` immediately fails with:
#   "No valid credential sources found"
# or bails mid-apply with an expired session token.
#
# This check probes the three sources Terraform actually reads:
#   1. Env vars AWS_ACCESS_KEY_ID + AWS_SECRET_ACCESS_KEY
#   2. Static keys in ~/.aws/credentials [profile]
#   3. SSO profile in ~/.aws/config with a valid cache
#
# To bypass (not recommended): export SKIP_TF_CREDS_CHECK=true
preflight_tf_creds_check() {
  # Source 1: env vars — Terraform's highest-priority source
  if [[ -n "${AWS_ACCESS_KEY_ID:-}" && -n "${AWS_SECRET_ACCESS_KEY:-}" ]]; then
    ok "Terraform credentials: env vars (AWS_ACCESS_KEY_ID set)"
    return 0
  fi

  local profile="${AWS_PROFILE:-default}"

  # Source 2: static keys in ~/.aws/credentials for active profile.
  # The section header is [<profile>] (no "profile " prefix in credentials file).
  if [[ -f "$HOME/.aws/credentials" ]]; then
    if _TF_CREDS_SECTION="[${profile}]" awk '
      BEGIN { target = ENVIRON["_TF_CREDS_SECTION"] }
      { sub(/[[:space:]]+$/, "") }
      $0 == target { in_s = 1; next }
      /^\[/ { in_s = 0 }
      in_s && /^[[:space:]]*aws_access_key_id[[:space:]]*=/ { found = 1; exit }
      END { exit !found }
    ' "$HOME/.aws/credentials" 2>/dev/null; then
      ok "Terraform credentials: ~/.aws/credentials [${profile}]"
      return 0
    fi
  fi

  # Source 3: SSO profile in ~/.aws/config (Terraform AWS provider v5+ supports this).
  # Section header in config: [default] for default, [profile <name>] otherwise.
  if [[ -f "$HOME/.aws/config" ]]; then
    local target_section
    if [[ "$profile" == "default" ]]; then
      target_section="[default]"
    else
      target_section="[profile ${profile}]"
    fi
    if _TF_CREDS_SECTION="$target_section" awk '
      BEGIN { target = ENVIRON["_TF_CREDS_SECTION"] }
      { sub(/[[:space:]]+$/, "") }
      $0 == target { in_s = 1; next }
      /^\[/ { in_s = 0 }
      in_s && /^[[:space:]]*sso_/ { found = 1; exit }
      END { exit !found }
    ' "$HOME/.aws/config" 2>/dev/null; then
      ok "Terraform credentials: SSO profile [${profile}]"
      info "  If apply fails with 'No valid credential sources found' or"
      info "  'ExpiredToken' mid-apply, your SSO cache needs to be exported"
      info "  as env vars (some Terraform/SDK versions don't read SSO cache"
      info "  directly): aws sso login --profile ${profile} && \\"
      info "    eval \"\$(aws configure export-credentials --profile ${profile} --format env)\""
      return 0
    fi
  fi

  fail "AWS CLI is authenticated, but Terraform's AWS SDK won't find the same credentials."
  echo ""
  echo "  Terraform reads credentials from (in order):"
  echo "    1. Env vars AWS_ACCESS_KEY_ID / AWS_SECRET_ACCESS_KEY / AWS_SESSION_TOKEN"
  echo "    2. ~/.aws/credentials   [${profile}]"
  echo "    3. ~/.aws/config        (with AWS_PROFILE, for SSO / role profiles)"
  echo "    4. EC2 IMDS / ECS container credentials"
  echo ""
  echo "  It does NOT read credentials cached in the macOS Keychain,"
  echo "  which is where Okta federated CLIs and some SSO tools store them."
  echo "  This is the most common cause of this failure."
  echo ""
  echo "  Fix — SSO profile (most common with Okta federation):"
  echo "      aws sso login --profile <your-profile>"
  echo "      eval \"\$(aws configure export-credentials --profile <your-profile> --format env)\""
  echo ""
  echo "  Fix — static IAM user key:"
  echo "      aws configure                     # writes ~/.aws/credentials"
  echo ""
  echo "  Fix — temporary (paste session creds, ~1 hour TTL):"
  echo "      export AWS_ACCESS_KEY_ID=..."
  echo "      export AWS_SECRET_ACCESS_KEY=..."
  echo "      export AWS_SESSION_TOKEN=..."
  echo ""
  echo "  Re-run ./deploy.sh after fixing. To bypass this check (not recommended):"
  echo "      export SKIP_TF_CREDS_CHECK=true"

  [[ "${SKIP_TF_CREDS_CHECK:-}" == "true" ]] || exit 1
}
preflight_tf_creds_check

# Terraform
if ! command -v terraform >/dev/null 2>&1; then
  die "Terraform not found. Install from https://terraform.io"
fi
TF_VERSION=$(terraform version -json 2>/dev/null | python3 -c "import sys,json; print(json.load(sys.stdin)['terraform_version'])" 2>/dev/null || terraform version | head -1 | grep -oE '[0-9]+\.[0-9]+')
ok "Terraform version: ${TF_VERSION}"

# Docker / build source reporting. Only probe Docker when the user asked for
# a local build; the default path (pull from ECR Public) needs neither Docker
# nor CodeBuild.
if [[ "$BUILD_FROM_SOURCE" != "true" ]]; then
  ok "Image source: ECR Public (no build required)"
elif [[ "$USE_LOCAL_DOCKER" == "true" ]]; then
  if command -v docker >/dev/null 2>&1 && docker info >/dev/null 2>&1; then
    ok "Docker available (--use-local-docker)"
  else
    die "Docker not available but --use-local-docker was specified. Install Docker, or drop --use-local-docker to build via CodeBuild."
  fi
else
  ok "Using AWS CodeBuild for image builds (--build-from-source)"
fi

# Required TF_VAR_ environment variables
REQUIRED_VARS=(
  TF_VAR_okta_domain
  TF_VAR_adapter_hostname
  TF_VAR_admin_hostname
)

# route53_zone_id is required unless dns_provider is "external"
if [[ "${TF_VAR_dns_provider:-route53}" != "external" ]]; then
  REQUIRED_VARS+=( TF_VAR_route53_zone_id )
fi

missing=()
for var in "${REQUIRED_VARS[@]}"; do
  if [[ -z "${!var:-}" ]]; then
    missing+=("$var")
  fi
done

if [[ ${#missing[@]} -gt 0 ]]; then
  die "Missing required environment variables:\n  ${missing[*]}\n\n  See deploy/aws-ecs/README.md for the full list."
fi
ok "Required environment variables present"

# ---- BYO mode pre-flight verification ----

if [[ "${TF_VAR_use_existing_vpc:-false}" == "true" ]]; then
  info "BYO VPC mode: verifying VPC and subnets..."
  if aws ec2 describe-vpcs --vpc-ids "${TF_VAR_existing_vpc_id}" \
       --region "${AWS_REGION}" --no-cli-pager >/dev/null 2>&1; then
    ok "VPC ${TF_VAR_existing_vpc_id} exists"
  else
    die "VPC ${TF_VAR_existing_vpc_id} not found in ${AWS_REGION}"
  fi
fi

if [[ "${TF_VAR_byo_ecr_repos:-false}" == "true" ]]; then
  info "BYO ECR mode: verifying repositories..."
  # hr_backend URL lives in aws-ecs-examples now (deprecated here); only
  # the core images (adapter, admin-ui) are required by this stack.
  for url_var in TF_VAR_existing_ecr_adapter_url TF_VAR_existing_ecr_admin_ui_url; do
    if [[ -z "${!url_var:-}" ]]; then
      die "BYO ECR mode requires ${url_var}"
    fi
  done
  ok "ECR repository URLs provided"
fi

if [[ -n "${TF_VAR_existing_acm_certificate_arn:-}" ]]; then
  info "BYO ACM mode: verifying certificate..."
  cert_status=$(aws acm describe-certificate \
    --certificate-arn "${TF_VAR_existing_acm_certificate_arn}" \
    --region "${AWS_REGION}" \
    --query "Certificate.Status" --output text 2>/dev/null || echo "NOT_FOUND")
  if [[ "$cert_status" == "ISSUED" ]]; then
    ok "ACM certificate is ISSUED"
  else
    die "ACM certificate status is '${cert_status}' (expected ISSUED)"
  fi
fi

echo ""

# ---- Pre-flight IAM permission checks ----

preflight_iam_check() {
  local failures=()

  info "Running pre-flight IAM permission checks..."

  # Probe STS (foundational)
  if ! aws sts get-caller-identity --no-cli-pager >/dev/null 2>&1; then
    failures+=("sts:GetCallerIdentity — is AWS CLI configured?")
  fi

  # Probe EC2
  if ! aws ec2 describe-vpcs --max-results 5 \
       --region "${AWS_REGION:-us-east-1}" \
       --no-cli-pager >/dev/null 2>&1; then
    failures+=("ec2:DescribeVpcs — cannot read VPCs")
  fi

  # Probe ECS
  if ! aws ecs list-clusters \
       --region "${AWS_REGION:-us-east-1}" \
       --no-cli-pager >/dev/null 2>&1; then
    failures+=("ecs:ListClusters — cannot read ECS")
  fi

  # Probe RDS
  if ! aws rds describe-db-instances \
       --region "${AWS_REGION:-us-east-1}" \
       --max-items 1 --no-cli-pager >/dev/null 2>&1; then
    failures+=("rds:DescribeDBInstances — cannot read RDS")
  fi

  # Probe IAM (most commonly restricted)
  if ! aws iam list-roles --max-items 1 \
       --no-cli-pager >/dev/null 2>&1; then
    failures+=("iam:ListRoles — cannot read IAM roles")
  fi

  # Probe Secrets Manager
  if ! aws secretsmanager list-secrets --max-results 1 \
       --region "${AWS_REGION:-us-east-1}" \
       --no-cli-pager >/dev/null 2>&1; then
    failures+=("secretsmanager:ListSecrets — cannot read Secrets Manager")
  fi

  # Probe Route53 (zone-scoped, skip for external DNS)
  if [[ "${TF_VAR_dns_provider:-route53}" != "external" && -n "${TF_VAR_route53_zone_id:-}" ]]; then
    if ! aws route53 get-hosted-zone \
         --id "$TF_VAR_route53_zone_id" \
         --no-cli-pager >/dev/null 2>&1; then
      failures+=("route53:GetHostedZone — cannot read zone $TF_VAR_route53_zone_id")
    fi
  fi

  if [[ ${#failures[@]} -gt 0 ]]; then
    echo ""
    echo "✗ Pre-flight IAM checks failed:"
    for f in "${failures[@]}"; do
      echo "  - $f"
    done
    echo ""
    echo "The operator principal is missing required permissions."
    echo "See: deploy/aws-ecs/iam/README.md for the concrete IAM"
    echo "policy an AWS administrator must attach."
    echo ""
    echo "To skip this check (NOT recommended): export SKIP_IAM_CHECK=true"
    exit 1
  fi

  ok "Pre-flight IAM checks passed"
}

# ---- DB bootstrap wrapper (P15) ----
# Populates the env-var contract the shared db_bootstrap lib expects from
# Terraform outputs, then delegates to db_bootstrap_run. The shared lib
# picks cloud-native job or local-exec automatically, prints the operator
# handoff block when RUN_DB_BOOTSTRAP=false, and verifies the schema
# post-condition when running locally.
run_migrate_task() {
  local cluster task_family task_def_arn
  cluster=$(terraform output -raw cluster_name 2>/dev/null || echo "oktaps-mcp-cluster")
  task_family=$(terraform output -raw migrate_task_definition_family 2>/dev/null || echo "oktaps-mcp-migrate")

  local subnets_json sg_id use_iam db_secret_arn db_name
  subnets_json=$(terraform output -json private_subnet_ids 2>/dev/null || echo "[]")
  sg_id=$(terraform output -raw ecs_tasks_sg_id 2>/dev/null || echo "")
  use_iam=$(terraform output -raw use_rds_iam 2>/dev/null || echo "true")
  db_secret_arn=$(terraform output -raw secrets_db_arn 2>/dev/null || echo "")
  db_name=$(terraform output -raw rds_db_name 2>/dev/null || echo "gateway_db")

  if [[ -z "$sg_id" || "$subnets_json" == "[]" ]]; then
    die "Could not resolve network config for migrate task (private_subnet_ids / ecs_tasks_sg_id). Run terraform apply first."
  fi

  # Resolve the migrate task definition to its current ARN so a rolled
  # revision is picked up without editing the deploy script.
  task_def_arn=$(aws ecs describe-task-definition \
      --task-definition "$task_family" --region "$AWS_REGION" \
      --query 'taskDefinition.taskDefinitionArn' --output text --no-cli-pager 2>/dev/null || echo "")
  [[ -n "$task_def_arn" && "$task_def_arn" != "None" ]] || die \
    "Could not describe migrate task definition '$task_family'. Check IAM and terraform state."

  # Compact the JSON array to a comma-separated list for awsvpcConfiguration.
  local subnets
  subnets=$(python3 -c "import sys,json; print(','.join(json.load(sys.stdin)))" <<<"$subnets_json")

  # db_bootstrap_run caller contract
  export PLATFORM=aws
  export AWS_REGION
  export ECS_CLUSTER="$cluster"
  export MIGRATE_TASK_DEF_ARN="$task_def_arn"
  export ECS_SUBNETS="$subnets"
  export ECS_SECURITY_GROUPS="$sg_id"
  export DB_MASTER_SECRET_ARN="$db_secret_arn"
  export USE_RDS_IAM="$use_iam"
  export DB_HOST="$(terraform output -raw rds_endpoint 2>/dev/null | cut -d: -f1 || echo "")"
  export DB_PORT=5432
  export DB_NAME="$db_name"
  export DB_OWNER_ROLE="${DB_OWNER_ROLE:-okta_adapter_owner}"
  export DB_APP_ROLE="${DB_APP_ROLE:-okta_adapter_app}"
  export MIGRATIONS_DIR="$SCRIPT_DIR/../migrations/sql"

  db_bootstrap_run
}

# ---- Load or auto-generate secrets ----
load_secrets

generated_new=false

if [[ -z "${TF_VAR_encryption_key:-}" ]]; then
  export TF_VAR_encryption_key
  TF_VAR_encryption_key=$(openssl rand -base64 32)
  generated_new=true
fi

if [[ "$generated_new" == "true" ]]; then
  info "Auto-generated ENCRYPTION_KEY"
  save_secrets
fi

# ---- Execute action ----

case "$ACTION" in

  # ==== APPLY ====
  apply)
    [[ "${SKIP_IAM_CHECK:-}" == "true" ]] || preflight_iam_check

    info "Initializing Terraform..."
    terraform init -upgrade

    info "Planning..."
    terraform plan -out=tfplan

    echo ""
    printf "${BOLD}Apply this plan? [y/N]:${NC} "
    read -r confirm
    if [[ ! "$confirm" =~ ^[Yy]$ ]]; then
      info "Aborted."
      exit 0
    fi

    info "Applying Terraform plan..."
    terraform apply tfplan

    # Build and push images (skipped when pulling from ECR Public)
    echo ""
    if [[ "$BUILD_FROM_SOURCE" != "true" ]]; then
      info "Skipping image build — task defs will pull from public.ecr.aws"
    elif [[ "$USE_LOCAL_DOCKER" == "true" ]]; then
      info "Building and pushing Docker images..."
      bash "$SCRIPT_DIR/build-images.sh"
    else
      # Ensure CodeBuild resources exist
      if ! terraform output -raw codebuild_project_name 2>/dev/null; then
        echo ""
        info "CodeBuild not provisioned. Re-applying with enable_codebuild=true..."
        export TF_VAR_enable_codebuild=true
        terraform apply -auto-approve
      fi
      info "Building images via CodeBuild..."
      bash "$SCRIPT_DIR/build-codebuild.sh"
    fi

    # Run DB bootstrap BEFORE rolling the adapter service (P13/P15). The
    # adapter fails fast on a missing/stale schema, so bootstrap must succeed
    # first. When SKIP_MIGRATE=true (or RUN_DB_BOOTSTRAP=false), the shared lib
    # prints an operator handoff block instead — the adapter will stay in
    # CrashLoopBackoff with the schema-check error until the DBA completes the
    # runbook, which is the intended hand-off behavior.
    echo ""
    if [[ "$SKIP_MIGRATE" == "true" ]]; then
      export RUN_DB_BOOTSTRAP=false
    fi
    run_migrate_task

    # Force new deployment on ECS services to pull latest images
    echo ""
    info "Forcing new deployment on ECS services..."
    for svc in adapter admin-ui; do
      aws ecs update-service --cluster oktaps-mcp-cluster \
        --service "$svc" --force-new-deployment \
        --region "${AWS_REGION}" --no-cli-pager >/dev/null 2>&1 \
        && ok "  ${svc} — new deployment triggered" \
        || warn "  ${svc} — could not trigger (may not exist yet)"
    done

    # Wait for services to stabilize
    echo ""
    info "Waiting for services to stabilize (timeout 10 min)..."
    aws ecs wait services-stable --cluster oktaps-mcp-cluster \
      --services adapter admin-ui \
      --region "${AWS_REGION}" \
      && ok "All services stable" \
      || warn "Timeout waiting for services — check ECS console"

    # Write core-outputs.json for the examples project to consume.
    echo ""
    info "Writing core outputs for examples project..."
    terraform output -json > core-outputs.json
    ok "core-outputs.json written"

    # Check DNS provider for post-deploy instructions
    DNS_PROVIDER=$(terraform output -raw dns_provider_tier 2>/dev/null || echo "route53")
    SKIP_SMOKE_TESTS=false

    if [[ "$DNS_PROVIDER" == "external" ]]; then
      echo ""
      echo "═══════════════════════════════════════════════════════════"
      echo "  POST-DEPLOY: Create hostname CNAMEs in your DNS provider"
      echo "═══════════════════════════════════════════════════════════"
      echo ""
      echo "Create these CNAME records so customers can reach the adapter:"
      echo ""
      terraform output -json alb_hostname_records_required | \
        python3 -c "import sys,json; [print(f'  {r[\"name\"]}  CNAME  {r[\"value\"]}') for r in json.load(sys.stdin)]"
      echo ""
      echo "Until these records are created, smoke tests will fail"
      echo "and the adapter URL will not resolve."
      echo ""
      SKIP_SMOKE_TESTS=true
    fi

    # Smoke tests
    echo ""
    if [[ "$SKIP_SMOKE_TESTS" == "true" ]]; then
      warn "Skipping smoke tests — external DNS CNAMEs not yet created"
    else
      info "Running smoke tests..."
      bash "$SCRIPT_DIR/smoke-test.sh" || true
    fi

    # Summary box
    ADAPTER_HOST="${TF_VAR_adapter_hostname}"
    ADMIN_HOST="${TF_VAR_admin_hostname}"
    DEPLOY_SIZE="${TF_VAR_deployment_size:-demo}"

    # BYO status
    BYO_VPC="new"
    [[ "${TF_VAR_use_existing_vpc:-false}" == "true" ]] && BYO_VPC="${TF_VAR_existing_vpc_id} (BYO)"
    BYO_ACM="created"
    [[ -n "${TF_VAR_existing_acm_certificate_arn:-}" ]] && BYO_ACM="BYO"
    if [[ "$BUILD_FROM_SOURCE" != "true" ]]; then
      BYO_ECR="public.ecr.aws/${ECR_PUBLIC_ALIAS:-oktaps} @ ${PUBLIC_IMAGE_TAG}"
    elif [[ "${TF_VAR_byo_ecr_repos:-false}" == "true" ]]; then
      BYO_ECR="BYO: using existing repos"
    else
      BYO_ECR="3 new repos"
    fi
    BYO_ALB="${TF_VAR_alb_scheme:-internet-facing}"
    [[ "$BYO_ALB" == "internal" ]] && BYO_ALB="internal — use TGW/PrivateLink"
    BYO_WAF="not attached"
    [[ -n "${TF_VAR_existing_waf_web_acl_arn:-}" ]] && BYO_WAF="attached"

    echo ""
    echo "┌──────────────────────────────────────────────────────────┐"
    echo "│  Okta MCP Adapter — ECS Fargate Deployment              │"
    echo "│                                                         │"
    echo "│  Adapter:   https://${ADAPTER_HOST}"
    echo "│  Admin UI:  https://${ADMIN_HOST}"
    echo "│  Profile:   A (Standalone)                              │"
    echo "│  Size:      ${DEPLOY_SIZE}"
    echo "│                                                         │"
    echo "│  VPC:       ${BYO_VPC}"
    echo "│  ACM:       ${BYO_ACM}"
    echo "│  ECR:       ${BYO_ECR}"
    echo "│  ALB:       ${BYO_ALB}"
    echo "│  WAF:       ${BYO_WAF}"
    echo "│                                                         │"
    echo "│  Admin sign-in: Okta OIDC (https://${ADMIN_HOST})"
    echo "│                                                         │"
    echo "│  Cost: ~\$90-120/mo (demo) or ~\$200-250/mo (small-prod) │"
    echo "│  Stop between demos: ./stop.sh (~\$15-20/mo idle)       │"
    echo "│                                                         │"
    echo "│  Examples:   cd ../aws-ecs-examples && ./deploy.sh --apply     │"
    echo "│  Tear down:  ./deploy.sh --destroy (examples first, then core) │"
    echo "│                                                         │"
    printf "│  ⚠ Update Okta redirect URIs to:                       │\n"
    echo "│    Adapter: https://${ADAPTER_HOST}/oauth/callback"
    echo "│    Admin:   https://${ADMIN_HOST}/api/auth/callback/okta"
    echo "└──────────────────────────────────────────────────────────┘"
    ;;

  # ==== DESTROY ====
  destroy)
    [[ "${SKIP_IAM_CHECK:-}" == "true" ]] || preflight_iam_check

    # Warn if the examples project still has resources. Destroying core
    # first can orphan examples resources (ECR repos, log groups) that
    # reference core VPC/cluster.
    EXAMPLES_DIR="$SCRIPT_DIR/../aws-ecs-examples"
    if [[ -d "$EXAMPLES_DIR/.terraform" && -f "$EXAMPLES_DIR/terraform.tfstate" ]]; then
      ex_resources=$(cd "$EXAMPLES_DIR" && terraform state list 2>/dev/null | wc -l | tr -d ' ')
      if [[ -n "$ex_resources" && "$ex_resources" -gt 0 ]]; then
        echo ""
        warn "Examples project appears to still have resources:"
        warn "  ${ex_resources} resources in ${EXAMPLES_DIR}/terraform.tfstate"
        echo ""
        warn "Destroy examples FIRST to avoid orphaned resources:"
        warn "  cd ../aws-ecs-examples && ./deploy.sh --destroy"
        echo ""
        printf "${BOLD}Continue destroying core anyway? [y/N]:${NC} "
        read -r ex_confirm
        if [[ ! "$ex_confirm" =~ ^[Yy]$ ]]; then
          info "Aborted."
          exit 0
        fi
      fi
    fi

    echo ""
    printf "${RED}${BOLD}Destroy all ECS resources? This is irreversible. [y/N]:${NC} "
    read -r confirm
    if [[ ! "$confirm" =~ ^[Yy]$ ]]; then
      info "Aborted."
      exit 0
    fi

    info "Initializing Terraform..."
    terraform init -upgrade

    info "Destroying all resources..."
    terraform destroy -auto-approve

    # Clean up secrets file + generated artifacts
    rm -f "$SECRETS_FILE"
    rm -f tfplan
    rm -f core-outputs.json

    ok "All resources destroyed."
    ;;

  # ==== PLAN ====
  plan)
    [[ "${SKIP_IAM_CHECK:-}" == "true" ]] || preflight_iam_check

    info "Initializing Terraform..."
    terraform init -upgrade

    info "Planning..."
    terraform plan
    ;;

  # ==== MIGRATE (one-shot) ====
  migrate)
    [[ "${SKIP_IAM_CHECK:-}" == "true" ]] || preflight_iam_check

    info "Initializing Terraform (to read state only)..."
    terraform init -upgrade >/dev/null

    # Confirm the migrate task definition exists in state.
    if ! terraform output -raw migrate_task_definition_family >/dev/null 2>&1; then
      die "migrate_task_definition_family output not found. Run ./deploy.sh --apply first to provision the migrate task."
    fi

    run_migrate_task
    ;;

esac
