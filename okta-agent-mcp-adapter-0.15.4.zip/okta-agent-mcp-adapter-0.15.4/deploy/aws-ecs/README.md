# AWS ECS Fargate Deployment

Deploy the Okta MCP Adapter on AWS ECS Fargate with managed RDS PostgreSQL, ElastiCache Redis, ALB with ACM TLS, and CloudWatch observability. Profile A (Standalone) — a single `deploy.sh` command provisions everything.

> **Example MCP servers** (HR backend) were previously deployed by this Terraform project. They have been moved to a separate sibling project at [`deploy/aws-ecs-examples/`](../aws-ecs-examples/README.md) to allow independent lifecycle and to prevent example failures from affecting core adapter deployment.

> **⚠️ Direct `terraform apply` drift warning.** `deploy.sh` exports several `TF_VAR_*` values (ECR image URLs, image tags, encryption key from `.generated-secrets`) into its own shell before calling Terraform. Running `terraform apply` **directly** from a fresh shell — e.g. to rotate admin UI credentials — will overwrite the task definitions with defaults and clear `ENCRYPTION_KEY` in Secrets Manager, rendering any encrypted DB rows unreadable. Pin these values in `terraform.tfvars` (see [`terraform.tfvars.example`](terraform.tfvars.example) and the [Using `terraform.tfvars`](#using-terraformtfvars-recommended-for-direct-terraform-apply) section below) before running any direct apply.

## Overview

This deployment creates a fully managed, serverless-compute stack on AWS:

- **ECS Fargate** — runs the adapter and admin UI as containers
- **RDS PostgreSQL** — encrypted configuration and credential storage
- **ElastiCache Redis** — token cache and cross-container cache invalidation
- **ALB + ACM** — HTTPS termination with auto-validated certificates
- **Service Connect** — east-west service mesh for internal communication (shared with examples)
- **Secrets Manager** — all credentials stored as managed secrets
- **CloudWatch** — structured JSON logs via FireLens (Fluent Bit)

Example MCP servers (HR backend) are deployed separately from [`deploy/aws-ecs-examples/`](../aws-ecs-examples/README.md) and attach to the Service Connect namespace created here.

Two deployment sizes are available via a single Terraform variable:


| Size           | Adapter Tasks         | RDS                      | ElastiCache                               | Multi-AZ | Monthly Cost |
| -------------- | --------------------- | ------------------------ | ----------------------------------------- | -------- | ------------ |
| `demo`         | 1                     | `db.t4g.micro` Single-AZ | `cache.t4g.micro` or Serverless           | No       | ~$90–120     |
| `small-prod`   | 2 (spread across AZs) | `db.t4g.small` Multi-AZ  | `cache.t4g.small` + replica or Serverless | Yes      | ~$200–250    |
| Stopped (demo) | 0                     | Stopped (storage only)   | Running or deleted                        | —        | ~$15–20      |


## Architecture

```
Internet
  │
  ├── Route53 DNS (mcp.example.com, admin-mcp.example.com)
  │
  ├── ACM Certificate (auto-validated via Route53)
  │
  └── ALB (public subnets, 2 AZs)
        ├── HTTPS :443 → adapter target group
        ├── HTTPS :443 → admin-ui target group (host-based routing)
        └── HTTP :80 → redirect to HTTPS
              │
        ┌─────┴─────┐
        │  Private   │
        │  Subnets   │
        ├────────────┤
        │ ECS Fargate│
        │  ├ adapter │──→ Service Connect ──→ hr-backend*
        │  └ admin-ui│     (* provisioned by
        ├────────────┤         aws-ecs-examples)
        │ ECS Fargate│
        ├────────────┤
        │ RDS Postgres│
        │ ElastiCache │
        └─────────────┘
              │
        NAT Gateway → Internet (Okta API calls)
```

## For AWS Administrators

Before the operator runs `./deploy.sh`, an AWS administrator must grant the operator's IAM principal the permissions to create the resources in this deployment.

See `**iam/README.md**` for:

- The IAM policies (`iam/example-operator-policy-1-network-data.json` and `iam/example-operator-policy-2-compute-ingress.json`)
- Instructions for attaching it directly or via an assume-role pattern
- Guidance on SCP conflicts, permission boundaries, and regulated environments
- A smaller runtime-only policy for post-deployment operations

*The operator policy scopes every resource to names matching `oktaps-mcp` where AWS supports ARN-level conditions.** It is not administrator-equivalent.

## Prerequisites

- **AWS CLI v2** authenticated (`aws sts get-caller-identity` succeeds)
- **Terraform** >= 1.6
- **AWS CodeBuild access** only if you pass `--build-from-source`. Docker only if you additionally pass `--use-local-docker`. The default path pulls prebuilt images from ECR Public and requires neither.
- **Okta org** with Custom Authorization Server + OIDC Web App configured
- **DNS** for your adapter and admin hostnames. See "DNS Provider Options" below for supported tiers.

### AWS Credentials for Terraform

The AWS CLI and Terraform's AWS SDK use **different credential chains**. This is the most common cause of a deployment failure that looks like it "should" have worked.

Terraform reads credentials from (in order):

1. Env vars `AWS_ACCESS_KEY_ID` / `AWS_SECRET_ACCESS_KEY` / `AWS_SESSION_TOKEN`
2. `~/.aws/credentials` for the active profile (static IAM user keys)
3. `~/.aws/config` with `AWS_PROFILE` (SSO, role-based, credential_process)
4. EC2 IMDS / ECS container credentials

Terraform does **not** read credentials cached in the macOS Keychain. Several Okta-federated CLIs (and the default AWS CLI install on some machines) put credentials there by default. In that case `aws sts get-caller-identity` succeeds but `terraform apply` fails immediately with `No valid credential sources found`.

**Before running `./deploy.sh --apply`:**

- **If you use AWS Identity Center (SSO):** log in and export the creds as env vars so Terraform can see them. Do this every time before a fresh shell deploys or after your SSO token expires.

  ```bash
  aws sso login --profile <your-profile>
  export AWS_PROFILE=<your-profile>
  eval "$(aws configure export-credentials --profile <your-profile> --format env)"
  aws sts get-caller-identity   # verify fresh
  ```

- **If you use a static IAM user key:** put it in `~/.aws/credentials` under `[default]` (or a named profile + `AWS_PROFILE`). Nothing else needed.

  ```bash
  aws configure                  # writes ~/.aws/credentials
  ```

- **If you use temporary session creds:** paste them directly into the shell.

  ```bash
  export AWS_ACCESS_KEY_ID=...
  export AWS_SECRET_ACCESS_KEY=...
  export AWS_SESSION_TOKEN=...
  ```

`deploy.sh` now runs a pre-flight probe of the three sources Terraform reads and fails fast with a fix suggestion if none are present. Set `SKIP_TF_CREDS_CHECK=true` to bypass (not recommended).

**SSO token TTL caveat.** Core apply takes 30+ minutes. If your SSO role session is 1 hour, Terraform will hit `ExpiredToken` mid-apply while waiting on RDS or ElastiCache. Two mitigations:

- Extend your SSO role session duration (in IAM Identity Center, set the permission set's session duration to 12 hours — requires admin access)
- Just refresh and resume: `aws sso login --profile <name> && eval "$(aws configure export-credentials --profile <name> --format env)" && ./deploy.sh --apply`. Terraform picks up where it stopped; RDS/ElastiCache that were mid-creation finish on their own and the second apply is much faster.

## DNS Provider Options

The deployment supports three DNS tiers. Choose based on where your domain lives:

### Tier 1: Route53 (recommended — fully automated)

Your domain's authoritative DNS is in Route53 in this AWS account. Terraform handles everything: ACM certificate validation, hostname records, health check integration. No manual DNS steps.

```bash
export TF_VAR_dns_provider="route53"
export TF_VAR_route53_zone_id="Z0123456789ABCDEF"
```

### Tier 2: Route53 Delegated Subdomain (recommended for external domains)

Your primary domain is at GoDaddy/Cloudflare/etc., but you've delegated a subdomain (e.g., `aws.example.com`) to a Route53 hosted zone in this AWS account. From the deployment's perspective this is identical to Tier 1.

**One-time setup:**

1. Create a public hosted zone in Route53 for `aws.example.com`
  ```bash
   aws route53 create-hosted-zone \
     --name aws.example.com \
     --caller-reference "oktaps-mcp-$(date +%s)"
  ```
2. Route53 returns 4 nameservers (e.g., `ns-123.awsdns-15.com`).
3. In your external DNS provider, create NS records for `aws.example.com` pointing to the 4 Route53 nameservers.
4. Wait 5–60 minutes for NS propagation.
5. Deploy with `adapter_hostname=mcp.aws.example.com` etc.

```bash
export TF_VAR_dns_provider="route53_delegated"
export TF_VAR_route53_zone_id="Z0987654321FEDCBA"  # The delegated zone
export TF_VAR_adapter_hostname="mcp.aws.example.com"
export TF_VAR_admin_hostname="admin-mcp.aws.example.com"
```

Costs: $0.50/month for the Route53 zone. Zero operational overhead.

### Tier 3: External DNS (GoDaddy, Cloudflare, corporate)

Your DNS stays entirely at your existing provider. Terraform creates the ACM certificate but cannot create the validation records — you do that manually. Same for hostname CNAMEs.

```bash
export TF_VAR_dns_provider="external"
# route53_zone_id NOT needed
```

Deployment flow:

1. Run `./deploy.sh --apply`
2. Terraform creates the ACM cert and pauses with instructions:
  ```
   Create the following CNAME in your DNS:
     Name:  _abc123.mcp.example.com
     Value: _xyz789.acm-validations.aws
     Type:  CNAME
  ```
3. Create the CNAME in your DNS provider (GoDaddy/Cloudflare/etc.)
4. Terraform waits up to 30 minutes for validation to complete.
5. After validation, the ALB is created and deploy.sh prints the ALB DNS name along with two more CNAMEs to create:
  ```
     mcp.example.com         CNAME  oktaps-mcp-alb-1234567890.us-east-1.elb.amazonaws.com
     admin-mcp.example.com   CNAME  oktaps-mcp-alb-1234567890.us-east-1.elb.amazonaws.com
  ```
6. Create the hostname CNAMEs in your DNS provider.
7. Run `./smoke-test.sh` once DNS propagates.

**Caveats for Tier 3:**

- No health-check-based DNS failover (Route53 alias feature). Not meaningful for a single-region deployment.
- If you rebuild the ALB (terraform destroy + apply), you get a new ALB DNS name and must update the hostname CNAMEs again. ALB DNS names don't change within a deployment's lifetime, only across recreations.
- ACM certificate renewal also uses DNS-01 validation. ACM auto-renews 60 days before expiry; if the validation CNAME is still in your DNS (you didn't delete it), renewal is automatic. **Keep the validation CNAMEs in your DNS permanently.**
- GoDaddy's DNS API is rate-limited and not well-supported by IaC tools. Manual record creation via the GoDaddy UI works fine but adds friction to redeployments.

### Which tier should you use?

- **You control DNS and domain is in AWS or you're willing to put it there:** Tier 1.
- **Your domain is elsewhere but you can get a subdomain delegated:** Tier 2. Best experience for most external-DNS customers.
- **Corporate DNS team controls everything and delegation isn't an option:** Tier 3. Works but requires coordination with the DNS team at deploy time.

## Enterprise Deployment

If your AWS account is part of an Organization with existing infrastructure, SCPs, permission boundaries, or centralized resource management, run the enterprise pre-flight check first:

```bash
./preflight-enterprise.sh
```

This probes your account for 10 common enterprise blockers and prints actionable remediation steps.

### BYO (Bring Your Own) resource modes

Every major AWS resource supports BYO mode — you provide an existing resource ARN/ID instead of having Terraform create one:

| Resource | BYO Variable | When to use |
|---|---|---|
| VPC + subnets | `TF_VAR_use_existing_vpc=true` + IDs | VPC quota exceeded; networking team manages VPCs |
| ECR repositories | `TF_VAR_byo_ecr_repos=true` + URLs | Central image registry; immutable tag policy |
| ACM certificate | `TF_VAR_existing_acm_certificate_arn=<arn>` | Wildcard cert managed centrally |
| KMS keys (RDS/Redis/Secrets/Logs) | `TF_VAR_existing_kms_key_arn_*=<arn>` | KMS creation restricted to security team |
| S3 bucket (CodeBuild) | `TF_VAR_existing_codebuild_source_bucket=<name>` | Bucket naming restrictions |
| WAF Web ACL | `TF_VAR_existing_waf_web_acl_arn=<arn>` | Central WAF with shared rules |

### Other enterprise variables

| Variable | Default | Enterprise Use |
|---|---|---|
| `alb_scheme` | `internet-facing` | Set to `internal` when public ALBs are denied (requires TGW/PrivateLink for external access) |
| `alb_access_logs_s3_bucket` | (none) | Set to central log bucket name |
| `ecr_image_tag_mutability` | `MUTABLE` | Set to `IMMUTABLE` if SCP requires |
| `ecr_scan_on_push` | `true` | Set to `false` if account uses Enhanced Scanning |
| `log_group_prefix` | `/ecs/oktaps-mcp` | Adjust to match naming convention (e.g., `/aws/app/oktaps-mcp`) |
| `log_group_retention_days` | `30` | Set to 90+ for compliance requirements |
| `rds_parameter_group_name` | (AWS default) | Specify custom parameter group |
| `rds_deletion_protection` | `false` | Set to `true` for production |
| `rds_backup_retention_days` | `7` | Set to 30+ for compliance |
| `fargate_spot_enabled` | `false` | Default for enterprise (some SCPs block spot) |
| `additional_tags` | `{}` | Required tag keys (CostCenter, Owner, etc.) |
| `skip_resource_tagging_on_secrets` | `false` | Set when SCP blocks `secretsmanager:UntagResource` |
| `iam_role_path` | `/` | Set to required path (e.g., `/app/`) |
| `iam_permissions_boundary` | (none) | Set to required boundary ARN |
| `iam_role_name_prefix` | `oktaps-mcp` | Adjust to match naming convention |

### Information to gather from your AWS administrator

Before deployment, use this checklist:

| Item | Example | Where to find it |
|---|---|---|
| VPC ID | `vpc-0abc...` | VPC Console > Your VPCs (filter by team tag) |
| Private subnet IDs | `subnet-0aaa...`, `subnet-0bbb...` | VPC Console > Subnets |
| Public subnet IDs | `subnet-0ccc...`, `subnet-0ddd...` | VPC Console > Subnets |
| Internet-facing ALB allowed? | yes/no | Ask platform team (check SCPs) |
| WAF Web ACL ARN | `arn:aws:wafv2:...` | WAF Console > Web ACLs (regional) |
| Existing ACM cert ARN | `arn:aws:acm:...` | ACM Console (must cover your hostnames) |
| Required tag keys | CostCenter, Owner, Team | Ask platform team |
| IAM role path | `/app/` or `/` | Ask security team |
| Permissions boundary ARN | `arn:aws:iam::...` | Ask security team |
| KMS CMK ARNs (RDS, Redis, Secrets, Logs) | `arn:aws:kms:...` | KMS Console (ask for pre-approved keys) |
| Log group naming convention | `/aws/app/<team>/...` | Ask platform team |
| Log retention policy | 30 / 90 / 365 days | Ask security/compliance team |
| RDS parameter group name | `custom-postgres15-audit` | Ask platform team |
| S3 bucket for CodeBuild source | `myorg-deployments-us-east-1` | Ask platform team |
| Route53 zone ID (if BYO DNS) | `Z0123456...` | Route53 Console (or Tier 2/3 from DNS guide) |
| Fargate Spot allowed? | yes/no | Check SCPs |

### Sample enterprise deployment

```bash
# Networking (from your networking team)
export TF_VAR_use_existing_vpc=true
export TF_VAR_existing_vpc_id="vpc-0abc123"
export TF_VAR_existing_private_subnet_ids='["subnet-0aaa","subnet-0bbb"]'
export TF_VAR_existing_public_subnet_ids='["subnet-0ccc","subnet-0ddd"]'

# ALB + WAF (from your platform team)
export TF_VAR_alb_scheme="internet-facing"
export TF_VAR_existing_waf_web_acl_arn="arn:aws:wafv2:us-east-1:123456789012:regional/webacl/central-waf/abc-123"
export TF_VAR_alb_access_logs_s3_bucket="myorg-alb-logs-us-east-1"

# Certificate (from your certificate management team)
export TF_VAR_existing_acm_certificate_arn="arn:aws:acm:us-east-1:123456789012:certificate/wildcard-abc"

# KMS (from your security team)
export TF_VAR_existing_kms_key_arn_rds="arn:aws:kms:us-east-1:123456789012:key/rds-cmk-id"
export TF_VAR_existing_kms_key_arn_secrets="arn:aws:kms:us-east-1:123456789012:key/secrets-cmk-id"
export TF_VAR_existing_kms_key_arn_logs="arn:aws:kms:us-east-1:123456789012:key/logs-cmk-id"

# IAM (from your security team)
export TF_VAR_iam_role_path="/app/oktaps/"
export TF_VAR_iam_permissions_boundary="arn:aws:iam::123456789012:policy/AppBoundary"

# Tags (from your platform team)
export TF_VAR_additional_tags='{"CostCenter":"IT-12345","Owner":"joey@okta.com","DataClassification":"Internal"}'
export TF_VAR_skip_resource_tagging_on_secrets=true  # if SCP blocks untag

# Logs
export TF_VAR_log_group_prefix="/aws/app/oktaps-mcp"
export TF_VAR_log_group_retention_days=90

# RDS hardening
export TF_VAR_rds_deletion_protection=true
export TF_VAR_rds_backup_retention_days=30

# Standard deployment variables (same as greenfield)
export TF_VAR_okta_domain="..."
export TF_VAR_adapter_hostname="..."
# etc.

# Run pre-flight, then deploy
./preflight-enterprise.sh
./deploy.sh --apply
```

## Image source (default: ECR Public)

`./deploy.sh --apply` pulls prebuilt adapter + admin-ui images from ECR Public
at tag `v<pyproject version>`. No Docker, no CodeBuild, no private ECR
repositories — Terraform runs straight through to apply + ECS service rollout.

```bash
cd deploy/aws-ecs

# Default — pulls public.ecr.aws/${ECR_PUBLIC_ALIAS:-oktaps}/okta-mcp-{adapter,admin-ui}
# at tag v<pyproject version>.
./deploy.sh --apply

# Pin to a specific published version:
./deploy.sh --apply --tag=v0.15.0

# Use the moving :latest tag (not recommended for anything but smoke tests):
./deploy.sh --apply --tag=latest
```

Under the hood `deploy.sh` sets these TF vars on the default path:

| Terraform variable             | Value                                                        |
| ------------------------------ | ------------------------------------------------------------ |
| `byo_ecr_repos`                | `true` (no private ECR repos created)                        |
| `existing_ecr_adapter_url`     | `public.ecr.aws/${ECR_PUBLIC_ALIAS:-oktaps}/okta-mcp-adapter`  |
| `existing_ecr_admin_ui_url`    | `public.ecr.aws/${ECR_PUBLIC_ALIAS:-oktaps}/okta-mcp-admin-ui` |
| `adapter_image_tag`            | from `--tag=` or pyproject version (`v<semver>`)             |
| `admin_ui_image_tag`           | same                                                         |
| `enable_codebuild`             | `false` (no CodeBuild project provisioned)                   |

> **If the `oktaps` ECR Public alias is still pending AWS approval,** export
> `ECR_PUBLIC_ALIAS=<your-auto-assigned-alias>` before deploying. Look the
> alias up with:
>
> ```bash
> aws ecr-public describe-registries --region us-east-1 \
>   --query 'registries[0].aliases[?status==`ACTIVE`].name'
> ```

The default path is compatible with every BYO-infrastructure setting
(`use_existing_vpc`, `existing_acm_certificate_arn`, etc.).

To build from source instead — in-account CodeBuild and private ECR repos —
pass `--build-from-source` (or `--use-local-docker` to build on the
workstation). See [Build from source (opt-in)](#build-from-source-opt-in)
below.

Example backends (`hr-server`, `deploy-server`) follow the same default in
`deploy/aws-ecs-examples/deploy.sh`.

## Publishing to ECR Public (maintainers only)

Two paths, for two situations:

| When | How |
| --- | --- |
| Cutting a release (canonical) | Push a `v*.*.*` tag to `atko-proservices/okta-agent-mcp-adapter` — GitHub Actions builds and publishes all four images. |
| Ad-hoc dev publish from a laptop | `./deploy/aws-ecs/publish-public.sh` (uses Docker Desktop + your current AWS profile). |

### One-time setup

1. Create the four ECR Public repositories (console or CLI; ECR Public lives in `us-east-1` only):

   ```bash
   for name in okta-mcp-adapter okta-mcp-admin-ui okta-mcp-hr-server okta-mcp-deploy-server; do
     aws ecr-public create-repository --region us-east-1 --repository-name "$name"
   done
   ```

   **If `oktaps` is still pending AWS review:** every ECR Public registry
   also has an **auto-assigned alias** (8-char random string) that works
   immediately. Look it up:

   ```bash
   aws ecr-public describe-registries --region us-east-1 \
     --query 'registries[0].aliases[?status==`ACTIVE`].name'
   ```

   Use that alias below via the `ECR_PUBLIC_ALIAS` env var (scripts) or the
   `ECR_PUBLIC_ALIAS` repo variable (workflow). When `oktaps` is approved,
   remove the override and the defaults kick back in.

2. Provision the GitHub OIDC role used by the workflow:

   ```bash
   cd deploy/github-oidc
   terraform init
   terraform apply
   terraform output -raw role_arn   # paste into the workflow if the default ARN differs
   ```

   See [deploy/github-oidc/README.md](../github-oidc/README.md) for the trust
   scope (tag pushes on this repo only) and why we create a dedicated role
   instead of extending the shared `GitHubActionsOIDCRole`.

### Tag-driven release (canonical)

```bash
# After bumping pyproject.toml + CHANGELOG.md and merging to main:
git tag v0.15.0
git push enterprise v0.15.0
```

The workflow at `.github/workflows/publish-public-ecr.yml` fires, builds all
four images in parallel (matrix: adapter, admin-ui, hr-server, deploy-server),
and pushes each as `:v0.15.0` + `:latest` to `public.ecr.aws/${alias}/`.

Two repo variables override the defaults (GitHub → **Settings → Secrets and
variables → Actions → Variables**):

| Variable | Default | When to set |
| --- | --- | --- |
| `ECR_PUBLIC_ALIAS` | `oktaps` | While `oktaps` is pending review, set to your auto-assigned alias. |
| `ECR_PUBLIC_PUBLISHER_ROLE_ARN` | `arn:aws:iam::640706953729:role/oktaps-mcp-gh-publisher` | If you renamed the role or deployed to a different account. |

Manual re-publish from the Actions UI: **Run workflow** → supply a tag input.

### Ad-hoc laptop publish

For testing an image before cutting a tag, or for a one-off push between
releases. Requires Docker Desktop running and `docker buildx` available.

```bash
# Core: adapter + admin-ui, tag = v<pyproject version> + :latest
./deploy/aws-ecs/publish-public.sh

# Examples: hr-server + deploy-server
./deploy/aws-ecs-examples/publish-public.sh

# Narrow to a single image
./deploy/aws-ecs/publish-public.sh --images=adapter

# Pin an explicit tag (any string; doesn't have to match pyproject)
./deploy/aws-ecs/publish-public.sh --tag=v0.15.0-rc1

# Skip the :latest tag push (versioned tag only)
./deploy/aws-ecs/publish-public.sh --no-latest

# Override the alias (defaults to oktaps)
ECR_PUBLIC_ALIAS=otheralias ./deploy/aws-ecs/publish-public.sh
```

The scripts use the currently-active AWS profile. PowerUser and Admin
roles already have `ecr-public:*` + `sts:GetServiceBearerToken` — no
Terraform apply required. Builds are `linux/amd64` only (matches
Fargate X86_64 task defs).

## Quick Start

```bash
# Set required environment variables
export AWS_REGION="us-east-1"              # default; deploy.sh syncs this to Terraform automatically
export TF_VAR_okta_domain="dev-12345.okta.com"
export TF_VAR_adapter_hostname="mcp.example.com"
export TF_VAR_admin_hostname="admin-mcp.example.com"
export TF_VAR_route53_zone_id="Z0123456789ABCDEF"

# Admin UI Okta OIDC (separate app from the adapter relay)
export TF_VAR_admin_ui_okta_domain="dev-12345.okta.com"
export TF_VAR_admin_ui_okta_client_id="0oaYYYYY"
export TF_VAR_admin_ui_okta_client_secret="your-admin-ui-secret"

# Optional: deployment size (default: demo)
export TF_VAR_deployment_size="demo"   # or "small-prod"

# Deploy everything. Pulls adapter + admin-ui from ECR Public by default.
# Pass --build-from-source to build in-account via CodeBuild instead.
./deploy.sh --apply
```

The script auto-generates `ENCRYPTION_KEY` if not set, saves to `.generated-secrets` which is loaded automatically on subsequent runs.

## Environment Variables

### Using `terraform.tfvars` (recommended for direct `terraform apply`)

`deploy.sh` sets a number of `TF_VAR_*` exports before calling `terraform apply` — ECR URLs, image tags, and `encryption_key` from `.generated-secrets`. If you run `terraform apply` directly from a fresh shell, those exports are missing and Terraform will "correct" the task definitions with default values (flipping adapter/admin-ui images to empty private ECR repos) and rewrite `ENCRYPTION_KEY` in Secrets Manager to `""`.

**Clearing `ENCRYPTION_KEY` is destructive:** any agent/resource credentials previously encrypted in the DB (`client_secret`, `private_key`, `api_key`) become undecryptable. The previous value can sometimes be recovered from the `AWSPREVIOUS` version of the `{project_name}/app` secret, but only before it's aged out.

The durable fix is a local `terraform.tfvars` file:

```bash
cp terraform.tfvars.example terraform.tfvars
# fill in values, including the encryption_key from .generated-secrets
```

`terraform.tfvars` is gitignored. Once it exists, every `terraform apply` from this directory — with or without `deploy.sh` — is self-contained, and credential rotations can be done with a direct `terraform apply` without risk of drift.

### Required (set before running `deploy.sh`)

| Variable | Description |
|---|---|
| `TF_VAR_okta_domain` | Okta org domain (e.g. `dev-12345.okta.com`) |
| `TF_VAR_adapter_hostname` | Adapter FQDN (e.g. `mcp.example.com`) |
| `TF_VAR_admin_hostname` | Admin UI FQDN (e.g. `admin-mcp.example.com`) |
| `TF_VAR_route53_zone_id` | Route53 hosted zone ID (not required if `dns_provider=external`) |
| `TF_VAR_admin_ui_okta_domain` | Admin UI Okta org domain |
| `TF_VAR_admin_ui_okta_client_id` | Admin UI OIDC client ID |
| `TF_VAR_admin_ui_okta_client_secret` | Admin UI OIDC client secret |

### Auto-detected by `deploy.sh`

These are resolved automatically — you only need to set them if you want to override the defaults.

| Variable | How it's resolved |
|---|---|
| `AWS_REGION` | Defaults to `us-east-1`. Set `AWS_REGION` to override. Synced to `TF_VAR_aws_region` automatically. |
| `AWS_ACCOUNT_ID` | Detected from `aws sts get-caller-identity` |
| `TF_VAR_encryption_key` | Auto-generated via `openssl rand`, saved to `.generated-secrets` |

### Optional

| Variable | Default | Description |
|---|---|---|
| `TF_VAR_deployment_size` | `demo` | `demo` or `small-prod` |
| `TF_VAR_cache_type` | `instance` | `instance` or `serverless` |
| `TF_VAR_dns_provider` | `route53` | `route53`, `route53_delegated`, or `external` |
| `TF_VAR_enable_codebuild` | `true` (TF default) | Provision CodeBuild for server-side image builds. `deploy.sh` sets this to `false` on the default public-image path and back to `true` under `--build-from-source`. |
| `TF_VAR_project_name` | `oktaps-mcp` | Naming prefix for every stack resource (VPC, ECR, ALB, RDS, ElastiCache, Secrets Manager paths, ECS cluster, Service Connect namespace, task families, `REDIS_KEY_PREFIX`). Lowercase alphanumeric + hyphens, ≤ 24 chars. **Two coupling points Terraform doesn't reach:** (1) `deploy/aws-ecs/iam/example-operator-policy-*.json` pin ARN conditions to `oktaps-mcp-*` — regenerate or `sed` them before the operator principal attaches them. (2) `stop.sh`, `start.sh`, `build-codebuild.sh`, `deploy-backend.sh` hardcode `oktaps-mcp` as a fallback — edit them or export `CLUSTER_NAME` / `RDS_IDENTIFIER` / `PROJECT_NAME` / `IMAGE_NAME` to override. The examples project already consumes this value via `core-outputs.json` — nothing extra to configure there. |

## Port Configuration

Container ports for the adapter and admin UI are controlled by Terraform variables. Changing a value propagates automatically to the container port, ALB target group, Service Connect alias, security-group ingress, task-definition env var, and health check — you do not have to edit any wiring.

| Variable | Default | Range | Controls |
|---|---|---|---|
| `gateway_port` | `8000` | 1–65535 | Adapter container port, ALB target group, Service Connect alias, SG ingress, `GATEWAY_PORT` env var, health check (`GET /.well-known/oauth-protected-resource`) |
| `admin_ui_port` | `3001` | 1–65535 | Admin UI container port, `PORT`/`ADMIN_UI_PORT` env vars |

Override in `terraform.tfvars`:

```hcl
gateway_port  = 9000
admin_ui_port = 4001
```

…or via env var before `deploy.sh`:

```bash
TF_VAR_gateway_port=9000 TF_VAR_admin_ui_port=4001 ./deploy.sh --apply
```

> Privileged ports (`<1024`) require `CAP_NET_BIND_SERVICE` on the task. The adapter emits a `config.port.validation_warning` audit event at startup if a privileged port is configured.

See [docs/OPERATIONS.md#port-configuration](../../docs/OPERATIONS.md#port-configuration) for the canonical reference, the full list of canonical env vars, and the `SERVER_PORT` deprecation.

## Database: RDS IAM Authentication (default)

Starting with the DB migration work (P13), the adapter authenticates to RDS **without a static password on the data plane**. The adapter task role is granted `rds-db:connect` for a single DB user (`okta_adapter_app`), and the adapter mints a 15-minute auth token on each new connection.

### What Terraform provisions

- `iam_database_authentication_enabled = true` on the RDS instance (safe to enable regardless; it has no cost).
- Two database roles created idempotently by the one-shot migrate task:
  - `okta_adapter_owner` — owns the schema, runs migrations (DDL).
  - `okta_adapter_app` — runtime DML only (SELECT / INSERT / UPDATE / DELETE). Never granted CREATE.
- Two IAM policies, each scoped to a single `dbuser` ARN:
  - Adapter task role → `rds-db:connect` for `okta_adapter_app`.
  - Migrate task role → `rds-db:connect` for `okta_adapter_owner`.
- The RDS master password remains in Secrets Manager (`${project}/db`) for break-glass admin access only. It is not consumed by the adapter at runtime.

### Disabling RDS IAM (legacy static-password mode)

Some environments (e.g. no IAM authentication permitted on RDS, or integration with an external secret rotation system) require the static-password path. Set:

```bash
export TF_VAR_use_rds_iam=false
./deploy.sh --apply
```

When `use_rds_iam=false`, the adapter is injected with the legacy `DATABASE_URL` secret that authenticates as the RDS master user — matching pre-P13 behavior.

### What the adapter gets at runtime (RDS IAM mode)

```
DB_CREDENTIAL_PROVIDER = rds_iam
DB_HOST                = <rds-endpoint>
DB_PORT                = 5432
DB_NAME                = gateway_db
DB_USERNAME            = okta_adapter_app
AWS_REGION             = <deployment region>
DB_SSLROOTCERT         = /opt/rds-ca/global-bundle.pem
```

No password env var. `DB_SSLROOTCERT` points at the RDS global CA bundle baked into the image (controlled by the `INSTALL_RDS_CA` Dockerfile build arg, default `true`).

## Migration Task (one-shot)

The adapter fails fast at startup if the DB schema is not at the expected `MIN_SCHEMA_VERSION`. A separate ECS task runs the SQL migration runner before the adapter service is updated.

### Automatic (default during `./deploy.sh --apply`)

```
terraform apply
  ↓
build & push images (CodeBuild or local Docker)
  ↓
run migrate task (bootstrap_roles.sql as master, then migration runner as owner)  ← new in P13
  ↓
ECS update-service --force-new-deployment  for adapter + admin-ui
```

If the migrate task exits non-zero, the adapter service is **not** rolled over — the old task set keeps running on the prior schema version, preserving availability.

### Manual: run migrations independently

```bash
./deploy.sh --migrate         # alias: --migrate-only (P15)
```

Starts the migrate task against the live cluster. Useful when:

- You applied Terraform but skipped the deploy step.
- You need to re-run migrations after a pipeline failure.
- You are rolling in a new image that requires a fresh migration before the adapter restarts.
- A new code release ships migrations but no infra change (DBAs typically drive this).

### Advanced: skip the migration step / hand off to a DBA (P15)

```bash
./deploy.sh --apply --skip-migrate    # aliases: --no-bootstrap
# or set the env var, same effect:
RUN_DB_BOOTSTRAP=false ./deploy.sh --apply
```

Does **not** run the migrate task. Instead, the deploy prints a copy-pasteable
**operator handoff block** with the resolved migrate-task ARN, cluster name,
subnets, security groups, and master-secret ARN already substituted. The
adapter container stays in `CrashLoopBackoff` with the explicit "schema not
initialized" error until the DBA completes the bootstrap. That's intentional.

Run the DBA's command from the handoff block (or re-deploy with
`./deploy.sh --migrate-only`) to bring the adapter up.

### Environment variables (P15)

| Variable                    | Default | Effect                                                                                      |
|-----------------------------|---------|---------------------------------------------------------------------------------------------|
| `RUN_DB_BOOTSTRAP`          | `true`  | `false` skips the migrate step; deploy prints an operator handoff block.                    |
| `DB_BOOTSTRAP_FORCE_LOCAL`  | `false` | `true` skips the ECS RunTask attempt and runs bootstrap from the deploy host via psql + the migrate runner. **Not supported when `use_rds_iam=true`** (no standing owner password). |
| `DB_BOOTSTRAP_TIMEOUT`      | `600`   | Max seconds to wait for the ECS migrate task.                                               |

### Per-revision redeploys (P15)

`./deploy-adapter.sh` (used for fast code-only redeploys) now also runs the
bootstrap step before forcing a new ECS deployment. New releases that ship
migrations are applied automatically. Pass `--no-bootstrap` if you're certain
no migrations are pending and want to skip.

### Inspecting a migration run

The migrate task streams to the `adapter` CloudWatch log group under the `migrate/` stream prefix:

```bash
aws logs tail /ecs/oktaps-mcp/adapter --follow \
  --region $AWS_REGION --log-stream-name-prefix migrate
```

### First-deploy vs subsequent deploys

- **First deploy:** the master user connects and runs `bootstrap_roles.sql`, which creates `okta_adapter_owner` + `okta_adapter_app` and sets default privileges. The runner then applies migrations 001..N as the owner.
- **Subsequent deploys:** `bootstrap_roles.sql` is idempotent (it uses `DO … IF NOT EXISTS …` blocks) — running it again is a no-op. The runner applies any new migrations and is itself idempotent.

## Deployment Sizes

### demo (default)

Best for technical demos, POCs, and individual development.

- 1 adapter task (single AZ)
- `db.t4g.micro` RDS (single AZ, no standby)
- `cache.t4g.micro` ElastiCache (or serverless)
- ~$90–120/month running, ~$15–20/month stopped

### small-prod

Best for small production workloads and multi-user environments.

- 2 adapter tasks (spread across AZs)
- `db.t4g.small` RDS (Multi-AZ with standby)
- `cache.t4g.small` ElastiCache with replica (or serverless)
- ~$200–250/month running

Set with: `export TF_VAR_deployment_size="small-prod"`

## Cost Breakdown


| Resource                            | demo             | small-prod                 |
| ----------------------------------- | ---------------- | -------------------------- |
| ECS Fargate (adapter)               | ~$15 (1 task)    | ~$30 (2 tasks)             |
| ECS Fargate (admin-ui)              | ~$10             | ~$10                       |
| RDS PostgreSQL                      | ~$15 (t4g.micro) | ~$50 (t4g.small Multi-AZ)  |
| ElastiCache (instance)              | ~$13 (t4g.micro) | ~$50 (t4g.small + replica) |
| ALB                                 | ~$18             | ~$18                       |
| NAT Gateway                         | ~$35             | ~$35                       |
| Route53 + ACM                       | ~$1              | ~$1                        |
| Secrets Manager                     | ~$2              | ~$2                        |
| CloudWatch Logs                     | ~$1              | ~$3                        |
| **Total**                           | **~$90–120**     | **~$200–250**              |


## ElastiCache Options

Two ElastiCache modes are available:

### Instance (default)

Traditional node-based Redis. Predictable pricing, fixed capacity.

```bash
export TF_VAR_cache_type="instance"  # default
```

### Serverless

Pay-per-use Redis with automatic scaling. Better for variable workloads.

```bash
export TF_VAR_cache_type="serverless"
```

## Build from source (opt-in)

By default `./deploy.sh --apply` pulls prebuilt images from ECR Public. To
build adapter + admin-ui from this working tree instead — for custom patches,
air-gapped publishes, or pre-release testing — opt into the build path:

```bash
./deploy.sh --apply --build-from-source
```

`--build-from-source` flips `enable_codebuild=true` and `byo_ecr_repos=false`,
which provisions:

- Private ECR repositories for adapter + admin-ui
- An S3 bucket for source upload (~$0.02/GB)
- A CodeBuild project (~$0.005/build-minute, typically 5-10 min)

Both core images are built on AWS and pushed to the private ECR repos.
Example server images (HR backend, deploy-server) are built separately by
`deploy/aws-ecs-examples/build-codebuild.sh`.

Subsequent image rebuilds (after initial deployment):

```bash
./build-codebuild.sh
```

### Building locally with Docker

If you have Docker available and prefer to build on your workstation instead
of CodeBuild, pass `--use-local-docker` — it implies `--build-from-source`:

```bash
./deploy.sh --apply --use-local-docker
```

This skips CodeBuild provisioning and builds images locally. Note: Mac
Silicon workstations build ARM64 images by default, which will fail on
Fargate's x86_64 tasks — drop `--use-local-docker` (CodeBuild builds the
right architecture), or pass `--platform linux/amd64` to `docker build`.

### Existing-tfstate migration note

If you previously ran `./deploy.sh --apply` before this default flipped, your
Terraform state has private ECR repos. Re-running without `--build-from-source`
plans to destroy them. Two safe paths:
1. Keep the build path: pass `--build-from-source` on subsequent runs.
2. Cut over: confirm the release tag exists under `public.ecr.aws/${ECR_PUBLIC_ALIAS}/`,
   then let Terraform destroy the private repos on the next apply.

## Stop/Start for Cost Savings

Scale down between demos to reduce costs to ~$15–20/month:

```bash
# Stop — scales ECS to 0, stops RDS
./stop.sh

# Start — restarts RDS, scales ECS back up, runs smoke tests
./start.sh
```

**Note:** AWS auto-restarts stopped RDS instances after 7 days. Re-run `./stop.sh` if needed.

## Okta Redirect URIs

After deployment, update your Okta OIDC applications with the URLs printed in the deploy summary:

**Adapter relay app:**

- Sign-in redirect URI: `https://<adapter_hostname>/oauth/callback`

**Admin UI OIDC app:**

- Sign-in redirect URI: `https://<admin_hostname>/api/auth/callback/okta`
- Sign-out redirect URI: `https://<admin_hostname>/login`

## deploy.sh Reference

```bash
./deploy.sh --apply                   # Init, plan, confirm, apply (pulls from ECR Public), run migrations, deploy, smoke test
./deploy.sh --apply --tag=v0.15.0     # Pin a specific public-image tag (default is v<pyproject version>)
./deploy.sh --plan                    # Init + plan only (no changes)
./deploy.sh --destroy                 # Destroy all resources (irreversible)
./deploy.sh --migrate                 # Run the one-shot DB migration task only (no infra changes)
./deploy.sh --apply --skip-migrate    # Apply infra + redeploy services WITHOUT running migrations (advanced)
./deploy.sh --apply --build-from-source           # Opt into building via CodeBuild + private ECR
./deploy.sh --apply --use-local-docker            # Build locally with Docker (implies --build-from-source)
./deploy.sh --help                    # Show usage
```

## Quick Redeploy

After the initial `./deploy.sh --apply`, use these scripts to redeploy individual components without rerunning the full Terraform cycle (~2-3 min each):

```bash
# Redeploy just the adapter (build + push + force new deployment + health check)
./deploy-adapter.sh

# Redeploy just the Admin UI
./deploy-ui.sh
```

To redeploy example MCP servers (HR backend), use the examples project:

```bash
cd ../aws-ecs-examples
# Default path: pull latest public images and roll the task defs.
./deploy.sh --apply

# Opt-in build paths:
./deploy.sh --build-from-source --build-only   # rebuild and push image only
./deploy.sh --apply --build-from-source        # full apply with in-account CodeBuild
```

Each script builds a timestamped image tag (e.g., `build-20260417-143022`) for traceability, pushes both the timestamped tag and `:latest` to ECR, and forces a new ECS service deployment.

**Note:** The quick-redeploy scripts (`deploy-adapter.sh`, `deploy-ui.sh`, `deploy-backend.sh`) auto-detect `AWS_ACCOUNT_ID` and default `AWS_REGION` to `us-east-1`. However, `build-images.sh` requires both to be explicitly set:

```bash
export AWS_REGION="us-east-1"
export AWS_ACCOUNT_ID=$(aws sts get-caller-identity --query Account --output text)
./build-images.sh
```

### Manual redeploy commands

If you prefer to run the commands directly:

```bash
# Set common variables
AWS_REGION="${AWS_REGION:-us-east-1}"
AWS_ACCOUNT_ID=$(aws sts get-caller-identity --query Account --output text)
ECR="${AWS_ACCOUNT_ID}.dkr.ecr.${AWS_REGION}.amazonaws.com"
CLUSTER="oktaps-mcp-cluster"

# Authenticate to ECR
aws ecr get-login-password --region "$AWS_REGION" | \
  docker login --username AWS --password-stdin "$ECR"

# --- Adapter ---
docker buildx build --platform linux/amd64 \
  -t "${ECR}/oktaps-mcp-adapter:latest" \
  -f ../../Dockerfile ../.. --push
aws ecs update-service --cluster "$CLUSTER" --service adapter \
  --force-new-deployment --region "$AWS_REGION" --no-cli-pager

# --- Admin UI ---
docker buildx build --platform linux/amd64 \
  -t "${ECR}/oktaps-mcp-admin-ui:latest" \
  -f ../../okta_agent_proxy_admin_ui/Dockerfile \
  ../../okta_agent_proxy_admin_ui --push
aws ecs update-service --cluster "$CLUSTER" --service admin-ui \
  --force-new-deployment --region "$AWS_REGION" --no-cli-pager

# --- Example backends (HR) live in deploy/aws-ecs-examples/ ---
# cd ../aws-ecs-examples && ./deploy.sh --build-only

# Wait for core services to stabilize
aws ecs wait services-stable --cluster "$CLUSTER" \
  --services adapter admin-ui --region "$AWS_REGION"
```

### CodeBuild rebuild

When you previously deployed with `--build-from-source` and want to rebuild
both core images (adapter, admin-ui) in one server-side build without a
workstation Docker dependency:

```bash
./build-codebuild.sh
aws ecs update-service --cluster oktaps-mcp-cluster --service adapter \
  --force-new-deployment --region "$AWS_REGION" --no-cli-pager
aws ecs update-service --cluster oktaps-mcp-cluster --service admin-ui \
  --force-new-deployment --region "$AWS_REGION" --no-cli-pager
```

For example servers, run `cd ../aws-ecs-examples && ./deploy.sh --build-from-source --build-only`. The local-Docker block above is an alternative for operators who prefer `docker buildx build` on their workstation.

## Troubleshooting

- **ECS tasks failing to start:** Check CloudWatch log groups `/ecs/oktaps-mcp/adapter`, `/ecs/oktaps-mcp/admin-ui` (HR backend log group lives in the examples project at `/ecs/oktaps-mcp-hr-backend`)
- **ACM certificate pending:** Verify Route53 CNAME validation records were created. The Terraform `aws_acm_certificate_validation` resource waits for this automatically.
- **Adapter can't reach RDS/Redis:** Check security group rules allow traffic from the ECS security group to the RDS and ElastiCache security groups on ports 5432 and 6379.
- **"exec format error":** Images were built for the wrong architecture. Rebuild with `--platform linux/amd64` (the default in `build-images.sh`).
- **RDS auto-restarted after stop.sh:** AWS stops RDS for a maximum of 7 days. Re-run `./stop.sh` to stop it again.
- **Service Connect DNS not resolving:** Verify the Cloud Map namespace and service registration in the ECS console. Services must be in the same namespace.
- **Secrets Manager permission denied:** Verify the task execution role has `secretsmanager:GetSecretValue` on all 4 secret ARNs.
- **Services not stabilizing:** Check desired count, task health checks, and that target groups are receiving healthy responses. Run `aws ecs describe-services --cluster oktaps-mcp-cluster --services adapter admin-ui` for details.
- **Pre-flight check failed** -- the operator's IAM principal is missing permissions. See `iam/README.md` for the full policy and `aws iam simulate-principal-policy` instructions.
- **ACM cert stuck in PENDING_VALIDATION (Tier 1/2):** Check that `TF_VAR_route53_zone_id` is correct and the zone contains your hostname's parent domain. For Tier 2, verify NS delegation from the parent domain has propagated (`dig NS aws.example.com`).
- **ACM cert stuck in PENDING_VALIDATION (Tier 3):** Verify the validation CNAME exists in your DNS with `dig CNAME _abc123.mcp.example.com`. Common mistake: DNS provider UIs sometimes auto-append the domain, turning `_abc123.mcp.example.com` into `_abc123.mcp.example.com.example.com`.
- **Smoke tests fail with DNS resolution error (Tier 3):** The hostname CNAMEs weren't created yet, or DNS hasn't propagated. Wait a few minutes or check with `dig CNAME mcp.example.com`.
- **Terraform destroy leaves ACM cert behind (Tier 3):** The cert can't be deleted while it's validating. If stuck, manually disassociate it from any ALB listeners and retry destroy.
- **terraform apply fails with AccessDenied** -- Terraform reveals which specific action is denied. Match it to the statements in the operator policy files and verify the operator's attached policies include it.
- **`Error: No valid credential sources found`** — Terraform's AWS SDK can't find credentials even though `aws sts get-caller-identity` works. Typically means your creds are in the macOS Keychain (Okta federated CLI, some SSO tools). See ["AWS Credentials for Terraform"](#aws-credentials-for-terraform) above. Fix: `aws sso login --profile <name> && eval "$(aws configure export-credentials --profile <name> --format env)"`, then re-run `./deploy.sh --apply`.
- **`api error ExpiredToken: The security token included in the request is expired`** — mid-apply, your SSO / assumed-role session hit its TTL. Resources already being created in AWS (RDS, ElastiCache) keep provisioning on their own. Fix: refresh creds with `aws sso login` + `eval "$(aws configure export-credentials ...)"` and re-run `./deploy.sh --apply` — Terraform refreshes state and continues from where it stopped. Prevent by extending SSO role session duration to 12 hours in IAM Identity Center.
- **"Cannot assume role X"** -- the operator has permission to create IAM roles but not to pass them to the ECS service. Verify the `iam:PassRole` statement in the operator policy includes `ecs-tasks.amazonaws.com` in the condition.

## Deploying Example MCP Servers

After the core deployment succeeds, you can optionally deploy example MCP servers (HR backend) for demonstration:

```bash
cd ../aws-ecs-examples
./deploy.sh --apply
./smoke-test.sh
```

The examples project reads shared resource IDs (cluster ARN, subnet IDs, Service Connect namespace, IAM roles) from `core-outputs.json` which is written automatically after each core `./deploy.sh --apply`. If you need to regenerate it:

```bash
cd deploy/aws-ecs
terraform output -json > core-outputs.json
```

See [`deploy/aws-ecs-examples/README.md`](../aws-ecs-examples/README.md) for full details.

## Tear Down

Destroy in reverse dependency order — examples first, then core:

```bash
# 1. Tear down examples (if deployed)
cd deploy/aws-ecs-examples
./deploy.sh --destroy

# 2. Tear down core
cd ../aws-ecs
./deploy.sh --destroy
```

Core takes ~10 minutes to fully deprovision (RDS deletion is the slowest step). The core destroy also removes local state files and `core-outputs.json`.

Destroying core while examples are still deployed will **orphan** the HR backend ECR repo, log group, and security group rule, because those live in the examples state file but reference core resources (VPC, cluster) that will be destroyed. The AWS API may block some destroys (e.g., security group in use), but ECR repos and log groups will silently orphan. Always destroy examples first — core's `deploy.sh --destroy` warns if it detects leftover examples state.

## Redis Authentication: ElastiCache IAM

This deployment uses ElastiCache IAM authentication. The ECS task
role is granted `elasticache:Connect` permission against the cache
and the adapter's IAM-enabled ElastiCache user. At connection time,
the adapter's `aws-iam` Redis credential provider mints a SigV4-
signed token (15-minute TTL) and presents it as the Redis AUTH
password.

**No shared secret exists for Redis access** — there is no random
password resource, no Secrets Manager entry for `REDIS_PASSWORD`,
no `auth_token` on the cluster, and no static-password gate flag.
Customer security review will see only the IAM permission grant and
the user/user-group resources.

### Resources involved

| Terraform resource                              | Purpose                              |
| ----------------------------------------------- | ------------------------------------ |
| `aws_elasticache_user.adapter`                  | IAM-authenticated ElastiCache user   |
| `aws_elasticache_user_group.adapter`            | User group attached to the cache     |
| `aws_iam_role_policy.ecs_task_elasticache_iam`  | Grants `elasticache:Connect` to tasks |

### Task environment

The adapter task receives the following credential-provider env:

- `REDIS_AUTH_MODE=aws-iam`
- `REDIS_AWS_USER_ID` (matches `var.redis_iam_user_id`)
- `REDIS_AWS_CACHE_NAME` (the cache's primary endpoint address)
- `REDIS_AWS_SERVERLESS` (`true` for serverless, `false` for instance mode)
- `AWS_REGION`
- `REDIS_URL` (host/port only — no embedded password)

### Auditability

Every credential mint emits a `redis.credential.minted` audit event
with the IAM principal in the `principal` field. Every scheduled
refresh emits `redis.credential.refresh.success` (or `.failed`).
Search the adapter audit stream for these event types to confirm
credential lifecycle activity.

### Migrating from Phase 1

If upgrading from a Phase-1 deployment that used static passwords:

1. Apply the new Terraform — the `aws_elasticache_user`,
   `aws_elasticache_user_group`, and IAM policy attach to existing
   resources without disruption.
2. The next ECS deployment picks up the new task definition.
   New tasks come up with IAM auth before old static-auth tasks
   drain.
3. Once all tasks are on the new revision, the old
   `random_password.redis_password` and `aws_secretsmanager_secret.redis`
   resources are gone (Terraform plan should show "destroy" for
   these — confirm before applying).