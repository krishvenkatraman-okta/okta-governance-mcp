#!/usr/bin/env bash
set -euo pipefail

# =============================================================
# smoke-test.sh — Validate the ECS Fargate deployment is healthy
# =============================================================
# Runs 5 tests against the deployed adapter and admin UI.
# Reads hostnames from TF_VAR_ env vars or terraform output.
# =============================================================

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"

# --- Resolve hostnames ---
ADAPTER_HOSTNAME="${TF_VAR_adapter_hostname:-}"
ADMIN_HOSTNAME="${TF_VAR_admin_hostname:-}"

if [[ -z "$ADAPTER_HOSTNAME" || -z "$ADMIN_HOSTNAME" ]]; then
  echo "Reading hostnames from terraform output..."
  cd "$SCRIPT_DIR"
  ADAPTER_HOSTNAME="${ADAPTER_HOSTNAME:-$(terraform output -raw adapter_url 2>/dev/null | sed 's|https://||' || true)}"
  ADMIN_HOSTNAME="${ADMIN_HOSTNAME:-$(terraform output -raw admin_url 2>/dev/null | sed 's|https://||' || true)}"
fi

if [[ -z "$ADAPTER_HOSTNAME" || -z "$ADMIN_HOSTNAME" ]]; then
  echo "✗ Could not determine hostnames."
  echo "  Set TF_VAR_adapter_hostname and TF_VAR_admin_hostname, or run from deploy/aws-ecs/ with terraform state."
  exit 1
fi

echo "Smoke testing deployment..."
echo "  Adapter: https://${ADAPTER_HOSTNAME}"
echo "  Admin:   https://${ADMIN_HOSTNAME}"
echo ""

tests_passed=0
tests_total=5

# --- Test 1: Adapter health (OAuth protected resource metadata) ---
printf "  [1/5] Adapter protected-resource metadata... "
if response=$(curl -sf --max-time 10 "https://${ADAPTER_HOSTNAME}/.well-known/oauth-protected-resource" 2>/dev/null) && \
   echo "$response" | grep -q "resource" 2>/dev/null; then
  printf "✓ passed\n"
  tests_passed=$(( tests_passed + 1 ))
else
  printf "✗ failed\n"
fi

# --- Test 2: Adapter /health endpoint ---
printf "  [2/5] Adapter /health...................... "
if curl -sf --max-time 10 "https://${ADAPTER_HOSTNAME}/health" >/dev/null 2>&1; then
  printf "✓ passed\n"
  tests_passed=$(( tests_passed + 1 ))
else
  printf "✗ failed\n"
fi

# --- Test 3: Admin UI reachable ---
printf "  [3/5] Admin UI reachable................... "
admin_code=$(curl -sf -o /dev/null -w "%{http_code}" --max-time 10 "https://${ADMIN_HOSTNAME}/" 2>/dev/null || true)
if [[ "$admin_code" == "200" || "$admin_code" == "302" ]]; then
  printf "✓ passed (HTTP %s)\n" "$admin_code"
  tests_passed=$(( tests_passed + 1 ))
else
  printf "✗ failed (HTTP %s)\n" "${admin_code:-timeout}"
fi

# --- Test 4: TLS certificate valid ---
printf "  [4/5] TLS certificate valid................ "
if echo | openssl s_client -connect "${ADAPTER_HOSTNAME}:443" \
    -servername "${ADAPTER_HOSTNAME}" 2>/dev/null | \
    openssl x509 -noout -dates >/dev/null 2>&1; then
  printf "✓ passed\n"
  tests_passed=$(( tests_passed + 1 ))
else
  printf "✗ failed\n"
fi

# --- Test 5: Adapter processing requests (not connection timeout) ---
printf "  [5/5] Adapter request processing........... "
test5_code=$(curl -sf -o /dev/null -w "%{http_code}" --max-time 10 "https://${ADAPTER_HOSTNAME}/api/admin/resources" 2>/dev/null || true)
if [[ "$test5_code" == "200" || "$test5_code" == "401" || "$test5_code" == "403" ]]; then
  printf "✓ passed (HTTP %s)\n" "$test5_code"
  tests_passed=$(( tests_passed + 1 ))
else
  printf "✗ failed (HTTP %s)\n" "${test5_code:-timeout}"
fi

# --- Summary ---
echo ""
if [[ $tests_passed -eq $tests_total ]]; then
  echo "✓ ${tests_passed}/${tests_total} tests passed — deployment is healthy"
else
  echo "✗ ${tests_passed}/${tests_total} tests passed — check CloudWatch logs"
  echo "  Log groups: /ecs/oktaps-mcp/adapter, /ecs/oktaps-mcp/admin-ui"
  exit 1
fi
