# IAM Prerequisites for AWS Administrators

This document is for the **AWS administrator** who grants the operator (SE, deployment engineer, or CI/CD pipeline) the permissions needed to deploy the Okta MCP Adapter to AWS ECS.

## TL;DR

Create two managed policies and attach both to the operator's IAM user or role. The policies are minimum-scoped: every resource ARN is restricted to names matching `oktaps-mcp`* where AWS supports ARN-level conditions.

Copy both example files to customized copies before executing:

```bash
# Copy the example files
cp deploy/aws-ecs/iam/example-operator-policy-1-network-data.json \
   deploy/aws-ecs/iam/operator-policy-1.json
cp deploy/aws-ecs/iam/example-operator-policy-2-compute-ingress.json \
   deploy/aws-ecs/iam/operator-policy-2.json

# Replace <ROUTE53_ZONE_ID> in policy 2
sed -i '' 's/<ROUTE53_ZONE_ID>/Z0123456789ABCDEF/g' \
  deploy/aws-ecs/iam/operator-policy-2.json

# Create both managed policies
aws iam create-policy \
  --policy-name OktaMcpAdapterDeployment-NetworkData \
  --policy-document file://deploy/aws-ecs/iam/operator-policy-1.json

aws iam create-policy \
  --policy-name OktaMcpAdapterDeployment-ComputeIngress \
  --policy-document file://deploy/aws-ecs/iam/operator-policy-2.json

# Attach both to the operator (replace ACCOUNT and OPERATOR_USER)
aws iam attach-user-policy \
  --user-name <OPERATOR_USER> \
  --policy-arn arn:aws:iam::ACCOUNT:policy/OktaMcpAdapterDeployment-NetworkData

aws iam attach-user-policy \
  --user-name <OPERATOR_USER> \
  --policy-arn arn:aws:iam::ACCOUNT:policy/OktaMcpAdapterDeployment-ComputeIngress
```

## What the deployment creates

When the operator runs `./deploy.sh --apply`, Terraform creates:


| Resource type                | Scope                                | Why the operator needs permissions |
| ---------------------------- | ------------------------------------ | ---------------------------------- |
| VPC + subnets + IGW + NAT GW | One VPC (10.0.0.0/16)                | Network isolation                  |
| Security groups (4)          | In the created VPC                   | Least-privilege network rules      |
| ECR repos (3)                | `oktaps-mcp-*`                       | Image storage                      |
| RDS PostgreSQL               | `oktaps-mcp-db`                      | Adapter state                      |
| ElastiCache Redis            | `oktaps-mcp-redis`                   | Token/session cache                |
| ElastiCache IAM user + group | `oktaps-mcp-*`                       | IAM-authenticated Redis access     |
| Secrets Manager (4)          | `oktaps-mcp/*`                       | Config and credentials             |
| IAM roles (3-4)              | `oktaps-mcp-*`                       | ECS execution + task + migrate (+ optional CodeBuild) |
| ECS cluster + 3 services     | `oktaps-mcp-cluster`                 | Runtime                            |
| ALB + ACM cert               | `oktaps-mcp-alb`, provided hostnames | TLS ingress                        |
| Route53 records (3)          | The provided hosted zone             | DNS                                |
| CloudWatch log groups (3)    | `/ecs/oktaps-mcp/*`                  | Observability                      |
| CodeBuild + S3 (optional)    | `oktaps-mcp*`                        | Server-side image builds           |


## Placeholders the administrator must customize

The `operator-policy-2.json` file contains placeholders:


| Placeholder         | Replace with                                       | Notes                                                                                  |
| ------------------- | -------------------------------------------------- | -------------------------------------------------------------------------------------- |
| `<ROUTE53_ZONE_ID>` | Actual Route53 zone ID (e.g., `Z0123456789ABCDEF`) | Restrict Route53 access to one zone. Use `*` for all zones only if policy requires it. |


```
Why two options? Scoping to one zone means the operator can only modify DNS in that specific hosted zone — a compromised credential or operator mistake cannot affect other zones in your account. Use * only if your organization's operational model requires it (shared deployment roles across many zones, CI/CD pipelines that target multiple environments, etc.). Default to the scoped version.
```

## DNS provider conditionals

The operator's Route53 permissions depend on the deployment's `dns_provider` setting:


| DNS Provider Tier                                          | Route53 permissions needed?          |
| ---------------------------------------------------------- | ------------------------------------ |
| `route53` (zone in this AWS account)                       | Yes — full scope to zone ID          |
| `route53_delegated` (subdomain NS-delegated from external) | Yes — scope to the delegated zone ID |
| `external` (GoDaddy, Cloudflare, corporate)                | No — remove the Route53 statements   |


For Tier 3 deployments, delete the `Route53DNSManagement` and `Route53ListZones` statements from `operator-policy-2.json` before attaching it. The operator will not create or modify any Route53 resources.

## Data-plane IAM auth (RDS + ElastiCache)

By default the deployment authenticates the adapter to RDS and ElastiCache via IAM — there are no static Redis passwords or standing DB passwords on the data plane. Two things follow from this:

- **Task-role inline policies, not operator policies.** The `rds-db:connect` grants (adapter + migrate task roles) and the `elasticache:Connect` grant live as inline policies on the ECS task roles. The operator only needs the `IAMRolePolicyManagement` statement (already present in policy 1) to create them during `terraform apply`.
- **ElastiCache IAM resources.** Terraform creates an `aws_elasticache_user` and `aws_elasticache_user_group` with authentication mode `iam`. Policy 1 grants `elasticache:CreateUser`/`CreateUserGroup` (and their Delete/Modify/Describe siblings) scoped to `oktaps-mcp*` so the operator can provision these.

### Disabling RDS IAM (legacy static-password mode)

If your environment prohibits IAM authentication on RDS, the operator can set `TF_VAR_use_rds_iam=false`. The `ecs_task_rds_iam_connect` and `ecs_task_migrate_rds_iam_connect` inline policies are then skipped (guarded by `count`), and the adapter reads `DATABASE_URL` from Secrets Manager instead. No change to the operator policies is required for either mode. See the top-level `README.md` section "Database: RDS IAM Authentication" for the runtime trade-offs.

ElastiCache IAM is not currently feature-flagged — `elasticache:Connect` and the IAM user/group are created in every deployment.

## Common enterprise blockers

### Service Control Policies (SCPs)

If your AWS Organization has SCPs, verify the operator's principal is not denied any of these actions. Common SCP conflicts:

- **Region restriction** -- SCPs often limit actions to approved regions. Ensure your deployment region is allowed.
- **Required tags** -- SCPs may require specific tags (cost center, owner, data classification). If so, add them to `local.common_tags` in `main.tf` before deployment.
- **Forbidden services** -- Some orgs block ElastiCache Serverless, public ALBs, or NAT Gateways. Adjust the deployment accordingly.
- **IAM role creation** -- Many SCPs restrict `iam:CreateRole` unless a permission boundary is attached. See next section.

### Permission boundaries

Some organizations require every IAM role to have a permission boundary attached. If that applies:

1. The operator policy needs `iam:PutRolePermissionsBoundary` and `iam:DeleteRolePermissionsBoundary` added (scoped to `arn:aws:iam::*:role/oktaps-mcp`*).
2. You must modify `main.tf` to attach the boundary when creating the ECS task roles. Add to each `aws_iam_role`:
  ```hcl
   permissions_boundary = "arn:aws:iam::ACCOUNT:policy/YourBoundaryName"
  ```
3. Pass the boundary ARN as a Terraform variable so it's environment-specific.

### Assume-role pattern (recommended for regulated orgs)

In regulated environments, rather than attaching the operator policy directly to a user, create a dedicated deployment role that the operator assumes:

```bash
# 1. Create the deployment role (admin does this once):
aws iam create-role \
  --role-name OktaMcpAdapterDeploymentRole \
  --assume-role-policy-document '{
    "Version": "2012-10-17",
    "Statement": [{
      "Effect": "Allow",
      "Principal": { "AWS": "arn:aws:iam::ACCOUNT:user/OPERATOR" },
      "Action": "sts:AssumeRole",
      "Condition": {
        "Bool": { "aws:MultiFactorAuthPresent": "true" }
      }
    }]
  }'

# 2. Attach both managed policies to that role:
aws iam attach-role-policy \
  --role-name OktaMcpAdapterDeploymentRole \
  --policy-arn arn:aws:iam::ACCOUNT:policy/OktaMcpAdapterDeployment-NetworkData

aws iam attach-role-policy \
  --role-name OktaMcpAdapterDeploymentRole \
  --policy-arn arn:aws:iam::ACCOUNT:policy/OktaMcpAdapterDeployment-ComputeIngress

# 3. Operator assumes the role before running deploy.sh:
eval $(aws sts assume-role \
  --role-arn arn:aws:iam::ACCOUNT:role/OktaMcpAdapterDeploymentRole \
  --role-session-name oktaps-mcp-deploy \
  --query 'Credentials.[AccessKeyId,SecretAccessKey,SessionToken]' \
  --output text | awk '{
    print "export AWS_ACCESS_KEY_ID="$1;
    print "export AWS_SECRET_ACCESS_KEY="$2;
    print "export AWS_SESSION_TOKEN="$3
  }')

# 4. Now run deploy.sh:
cd deploy/aws-ecs && ./deploy.sh --apply
```

This pattern gives you MFA enforcement, time-bounded credentials, and a clean audit trail in CloudTrail.

## Verifying the operator has the right permissions

Run this command as the operator to simulate the deployment:

```bash
./deploy.sh --plan
```

If permissions are missing, Terraform will fail with specific `AccessDenied` errors. The pre-flight probe in `deploy.sh` catches the most common cases before Terraform runs.

For a more thorough check, use `aws iam simulate-principal-policy`:

```bash
aws iam simulate-principal-policy \
  --policy-source-arn arn:aws:iam::ACCOUNT:user/OPERATOR \
  --action-names ec2:CreateVpc rds:CreateDBInstance iam:CreateRole \
                 ecs:CreateCluster elasticloadbalancing:CreateLoadBalancer
```

## Revoking access after deployment

Once deployed, if the operator only needs to run stop/start/smoke tests (not re-deploy), you can swap the operator policy for a much smaller runtime policy:

- `ecs:UpdateService` on the 3 service ARNs
- `rds:StartDBInstance`, `rds:StopDBInstance` on the DB ARN
- `ecs:DescribeServices`, `ecs:ListTasks` on the cluster
- `sts:GetCallerIdentity` (for smoke tests)

Runtime data-plane auth (RDS IAM + ElastiCache IAM) is carried by the ECS task roles, not by the operator principal, so nothing in this runtime policy relates to Postgres or Redis access.

Re-attach both operator policies when a redeploy is needed.