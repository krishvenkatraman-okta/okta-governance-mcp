#!/usr/bin/env bash
set -euo pipefail

# =============================================================
# deploy-backend.sh — Quick redeploy of a demo backend
# =============================================================
# Usage:
#   ./deploy-backend.sh hr          # Redeploy hr-backend
#   ./deploy-backend.sh deploy      # Redeploy deploy-server
#   ./deploy-backend.sh             # Defaults to hr-backend
# =============================================================

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
REPO_ROOT="$(cd "$SCRIPT_DIR/../.." && pwd)"

# ---- Colors ----
if [[ -n "${NO_COLOR:-}" ]] || [[ ! -t 1 ]]; then
  RED='' GREEN='' CYAN='' YELLOW='' NC=''
else
  RED='\033[0;31m'
  GREEN='\033[0;32m'
  CYAN='\033[0;36m'
  YELLOW='\033[1;33m'
  NC='\033[0m'
fi

info() { printf "${CYAN}[INFO]${NC}  %s\n" "$*"; }
ok()   { printf "${GREEN}[  OK]${NC}  %s\n" "$*"; }
warn() { printf "${YELLOW}[WARN]${NC}  %s\n" "$*" >&2; }
die()  { printf "${RED}[FAIL]${NC}  %s\n" "$*" >&2; exit 1; }

# ---- Parse backend argument ----
BACKEND="${1:-hr}"

case "$BACKEND" in
  hr|hr-backend)
    IMAGE_NAME="oktaps-mcp-hr-backend"
    DOCKERFILE="${REPO_ROOT}/examples/01-hr-system/Dockerfile"
    BUILD_CONTEXT="${REPO_ROOT}/examples/01-hr-system"
    SERVICE_NAME="hr-backend"
    ;;
  deploy|deploy-server)
    IMAGE_NAME="oktaps-mcp-deploy-server"
    DOCKERFILE="${REPO_ROOT}/examples/05-deploy-server/Dockerfile"
    BUILD_CONTEXT="${REPO_ROOT}/examples/05-deploy-server"
    SERVICE_NAME="deploy-server"
    ;;
  *)
    die "Unknown backend: $BACKEND. Use 'hr' or 'deploy'."
    ;;
esac

# ---- Required env vars ----
AWS_REGION="${AWS_REGION:-us-east-1}"
AWS_ACCOUNT_ID="${AWS_ACCOUNT_ID:-$(aws sts get-caller-identity --query Account --output text)}"
ECR_REGISTRY="${AWS_ACCOUNT_ID}.dkr.ecr.${AWS_REGION}.amazonaws.com"
CLUSTER_NAME="${CLUSTER_NAME:-oktaps-mcp-cluster}"

# Build tag with timestamp for traceability
BUILD_TAG="build-$(date +%Y%m%d-%H%M%S)"

echo ""
info "Redeploying ${SERVICE_NAME} (${BUILD_TAG})"
echo ""

# ---- Verify Dockerfile exists ----
[[ -f "$DOCKERFILE" ]] || die "Dockerfile not found: $DOCKERFILE"

# ---- Authenticate to ECR ----
info "Authenticating to ECR..."
aws ecr get-login-password --region "$AWS_REGION" | \
  docker login --username AWS --password-stdin "$ECR_REGISTRY" 2>/dev/null
ok "ECR authentication successful"

# ---- Build and push ----
info "Building ${SERVICE_NAME} image ($BUILD_TAG)..."
docker buildx build \
  --platform linux/amd64 \
  -t "${ECR_REGISTRY}/${IMAGE_NAME}:${BUILD_TAG}" \
  -t "${ECR_REGISTRY}/${IMAGE_NAME}:latest" \
  -f "${DOCKERFILE}" \
  --push \
  "${BUILD_CONTEXT}"
ok "Image pushed: ${IMAGE_NAME}:${BUILD_TAG}"

# ---- Force new deployment ----
info "Forcing new ECS deployment..."
aws ecs update-service \
  --cluster "$CLUSTER_NAME" \
  --service "$SERVICE_NAME" \
  --force-new-deployment \
  --region "$AWS_REGION" \
  --no-cli-pager >/dev/null
ok "Deployment triggered"

# ---- Wait for service to stabilize ----
info "Waiting for service to stabilize..."
if aws ecs wait services-stable \
     --cluster "$CLUSTER_NAME" \
     --services "$SERVICE_NAME" \
     --region "$AWS_REGION" 2>/dev/null; then
  ok "Service stable"
else
  warn "Stabilization timed out. Check: aws ecs describe-services --cluster $CLUSTER_NAME --services $SERVICE_NAME --region $AWS_REGION"
fi

echo ""
ok "${SERVICE_NAME} redeployed: ${BUILD_TAG}"
