#!/usr/bin/env bash
set -euo pipefail

# =============================================================
# build-images.sh — Build and push Docker images to ECR
# =============================================================
# Builds the core images (adapter, admin-ui) for linux/amd64
# (Fargate) and pushes to ECR. Idempotent — safe to re-run to
# push updated images.
#
# Example server images (HR backend) are built by
# deploy/aws-ecs-examples/build-images.sh.
# =============================================================

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
REPO_ROOT="$(cd "$SCRIPT_DIR/../.." && pwd)"

# ---- Colors ----
if [[ -n "${NO_COLOR:-}" ]] || [[ ! -t 1 ]]; then
  RED='' GREEN='' CYAN='' BOLD='' NC=''
else
  RED='\033[0;31m'
  GREEN='\033[0;32m'
  CYAN='\033[0;36m'
  BOLD='\033[1m'
  NC='\033[0m'
fi

info()  { printf "${CYAN}[INFO]${NC}  %b\n" "$*"; }
ok()    { printf "${GREEN}[  OK]${NC}  %b\n" "$*"; }
die()   { printf "${RED}[FAIL]${NC}  %b\n" "$*" >&2; exit 1; }

# ---- Required env vars ----
: "${AWS_REGION:?AWS_REGION must be set}"
: "${AWS_ACCOUNT_ID:?AWS_ACCOUNT_ID must be set}"

ECR_REGISTRY="${AWS_ACCOUNT_ID}.dkr.ecr.${AWS_REGION}.amazonaws.com"

# ---- Authenticate Docker to ECR ----
info "Authenticating Docker to ECR (${ECR_REGISTRY})..."
aws ecr get-login-password --region "$AWS_REGION" | \
  docker login --username AWS --password-stdin "$ECR_REGISTRY"
ok "ECR authentication successful"

# ---- Build and push adapter image ----
info "Building adapter image (linux/amd64)..."
docker buildx build \
  --platform linux/amd64 \
  -t "${ECR_REGISTRY}/oktaps-mcp-adapter:latest" \
  -f "${REPO_ROOT}/Dockerfile" \
  --push \
  "${REPO_ROOT}"
ok "Adapter image pushed"

# ---- Build and push admin UI image ----
info "Building admin UI image (linux/amd64)..."
docker buildx build \
  --platform linux/amd64 \
  -t "${ECR_REGISTRY}/oktaps-mcp-admin-ui:latest" \
  -f "${REPO_ROOT}/okta_agent_proxy_admin_ui/Dockerfile" \
  --push \
  "${REPO_ROOT}/okta_agent_proxy_admin_ui"
ok "Admin UI image pushed"

# ---- Summary ----
echo ""
echo "┌─────────────────────────────────────────────────────────────┐"
echo "│  Images pushed to ECR                                      │"
echo "│                                                            │"
echo "│  adapter:    ${ECR_REGISTRY}/oktaps-mcp-adapter:latest"
echo "│  admin-ui:   ${ECR_REGISTRY}/oktaps-mcp-admin-ui:latest"
echo "└─────────────────────────────────────────────────────────────┘"
