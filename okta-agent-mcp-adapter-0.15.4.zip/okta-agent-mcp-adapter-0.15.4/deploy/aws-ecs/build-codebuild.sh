#!/usr/bin/env bash
set -euo pipefail

# =============================================================
# build-codebuild.sh — Build images via AWS CodeBuild
# =============================================================
# Packages the source, uploads to S3, triggers CodeBuild, and
# waits for completion. Use when Docker is not available locally.
# =============================================================

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
REPO_ROOT="$(cd "$SCRIPT_DIR/../.." && pwd)"

# ---- Colors ----
if [[ -n "${NO_COLOR:-}" ]] || [[ ! -t 1 ]]; then
  RED='' GREEN='' CYAN='' BOLD='' NC=''
else
  RED='\033[0;31m'
  GREEN='\033[0;32m'
  CYAN='\033[0;36m'
  BOLD='\033[1m'
  NC='\033[0m'
fi

info()  { printf "${CYAN}[INFO]${NC}  %b\n" "$*"; }
ok()    { printf "${GREEN}[  OK]${NC}  %b\n" "$*"; }
die()   { printf "${RED}[FAIL]${NC}  %b\n" "$*" >&2; exit 1; }

# ---- Configuration ----
AWS_REGION="${AWS_REGION:-us-east-1}"
PROJECT_NAME="oktaps-mcp"
ACCOUNT_ID=$(aws sts get-caller-identity --query Account --output text)
S3_BUCKET="${PROJECT_NAME}-codebuild-${ACCOUNT_ID}"
CODEBUILD_PROJECT="${PROJECT_NAME}-image-builder"

# ---- Package source for CodeBuild ----
info "Packaging source for CodeBuild..."
TMPDIR=$(mktemp -d)
trap "rm -rf $TMPDIR" EXIT

cd "$REPO_ROOT"
zip -rq "$TMPDIR/source.zip" \
  Dockerfile .dockerignore requirements.txt pyproject.toml \
  deploy/migrations/ \
  okta_agent_proxy/ \
  okta_agent_proxy_admin_ui/ \
  examples/01-hr-system/ \
  scripts/ \
  -x "*.pyc" "__pycache__/*" "node_modules/*" \
     ".git/*" "tests/*" ".claude/*" "*.md"

info "Uploading source to S3 (s3://${S3_BUCKET}/source.zip)..."
aws s3 cp "$TMPDIR/source.zip" "s3://${S3_BUCKET}/source.zip" \
  --region "$AWS_REGION" --quiet
ok "Source uploaded"

# ---- Start CodeBuild ----
info "Starting CodeBuild project: ${CODEBUILD_PROJECT}..."
BUILD_ID=$(aws codebuild start-build \
  --project-name "$CODEBUILD_PROJECT" \
  --region "$AWS_REGION" \
  --query 'build.id' --output text)

echo "  Build ID: $BUILD_ID"
info "Waiting for build to complete (typically 5-10 min)..."

# ---- Poll until complete ----
while true; do
  STATUS=$(aws codebuild batch-get-builds --ids "$BUILD_ID" \
    --region "$AWS_REGION" \
    --query 'builds[0].buildStatus' --output text)
  case "$STATUS" in
    SUCCEEDED)
      ok "CodeBuild completed successfully"
      break ;;
    FAILED|FAULT|TIMED_OUT|STOPPED)
      die "CodeBuild failed: $STATUS\n  View logs:\n    aws codebuild batch-get-builds --ids $BUILD_ID --region $AWS_REGION\n    aws logs tail /codebuild/${PROJECT_NAME} --region $AWS_REGION"
      ;;
    *)
      printf "\r  Status: %-20s" "$STATUS"
      sleep 10 ;;
  esac
done
