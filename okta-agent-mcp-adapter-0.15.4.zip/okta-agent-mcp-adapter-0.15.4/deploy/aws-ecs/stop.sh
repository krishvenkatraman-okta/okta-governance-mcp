#!/usr/bin/env bash
set -euo pipefail

# =============================================================
# stop.sh — Scale down ECS services and stop RDS to save costs
# =============================================================
# Scales all ECS services to 0 desired count and stops the RDS
# instance. ElastiCache stays running to avoid data loss.
# Restart with: ./start.sh
# =============================================================

AWS_REGION="${AWS_REGION:-us-east-1}"
CLUSTER_NAME="oktaps-mcp-cluster"
RDS_IDENTIFIER="oktaps-mcp-postgres"

export AWS_PAGER=""

echo "Stopping ECS deployment (region: ${AWS_REGION})..."
echo ""

# --- Step 1: Scale ECS services to 0 ---
echo "Scaling ECS services to 0..."
for svc in adapter admin-ui hr-backend; do
  aws ecs update-service --cluster "$CLUSTER_NAME" \
    --service "$svc" --desired-count 0 \
    --region "$AWS_REGION" --no-cli-pager >/dev/null 2>&1 \
    && echo "  ✓ ${svc} → 0" \
    || echo "  ⚠ ${svc} — may already be stopped or not found"
done
echo "✓ ECS services scaled to 0"
echo ""

# --- Step 2: Stop RDS instance ---
echo "Stopping RDS instance..."
aws rds stop-db-instance \
  --db-instance-identifier "$RDS_IDENTIFIER" \
  --region "$AWS_REGION" --no-cli-pager >/dev/null 2>&1 \
  && echo "✓ RDS instance stopping (takes ~5 min)" \
  || echo "⚠ RDS may already be stopped"
echo "⚠ RDS auto-restarts after 7 days. Re-run stop.sh if needed."
echo ""

# --- Cost estimate while stopped ---
echo "┌────────────────────────────────────────┐"
echo "│  Monthly cost while stopped: ~\$15-20   │"
echo "│                                        │"
echo "│  ALB:          ~\$18 (fixed charge)     │"
echo "│  ElastiCache:  ~\$0-15 (depends)        │"
echo "│  RDS storage:  ~\$3                     │"
echo "│  ECR:          ~\$1                     │"
echo "│                                        │"
echo "│  Restart: ./start.sh                   │"
echo "└────────────────────────────────────────┘"
