# -----------------------------------------------------------------------------
# main.tf — Okta MCP Adapter ECS Fargate Deployment
# -----------------------------------------------------------------------------
# Built incrementally across prompts E1–E9, E11, E15.
# E1: VPC, subnets, IGW, NAT GW, ECR repositories
# E3: Secrets Manager, IAM roles (execution + task)
# E5: ECS cluster, log groups, Service Connect namespace, task definitions
# E6: ACM certificate, ALB, target groups, ECS services, Route53 DNS
# E9: CodeBuild project for server-side image builds (conditional)
# E15: Enterprise BYO compatibility (count-gated VPC, ECR, ACM, S3; WAF;
#      KMS; IAM path/boundary/naming; Fargate spot; conditional tagging)
# -----------------------------------------------------------------------------

terraform {
  required_version = ">= 1.6"

  required_providers {
    aws = {
      source  = "hashicorp/aws"
      version = "~> 5.0"
    }
  }
}

provider "aws" {
  region = var.aws_region
}

# -----------------------------------------------------------------------------
# Locals
# -----------------------------------------------------------------------------

locals {
  project_name = var.project_name

  common_tags = merge(
    {
      Project     = "${var.project_name}-adapter"
      Environment = var.deployment_size
      ManagedBy   = "terraform"
    },
    var.additional_tags
  )

  # Computed defaults — use variable override if provided, else derive from deployment_size
  db_instance_class     = var.db_instance_class != "" ? var.db_instance_class : (var.deployment_size == "demo" ? "db.t4g.micro" : "db.t4g.small")
  db_multi_az           = var.db_multi_az != null ? var.db_multi_az : (var.deployment_size == "small-prod")
  adapter_desired_count = var.adapter_desired_count != null ? var.adapter_desired_count : (var.deployment_size == "demo" ? 1 : 2)

  # ElastiCache computed defaults
  cache_instance_class = var.deployment_size == "demo" ? "cache.t4g.micro" : "cache.t4g.small"
  cache_replicas       = var.deployment_size == "demo" ? 1 : 2

  azs = ["${var.aws_region}a", "${var.aws_region}b"]

  # Redis URL — differs by cache_type (instance vs serverless)
  redis_endpoint = (
    var.cache_type == "instance"
    ? aws_elasticache_replication_group.main[0].primary_endpoint_address
    : aws_elasticache_serverless_cache.main[0].endpoint[0].address
  )
  # Phase 2: REDIS_URL no longer embeds credentials. ElastiCache IAM
  # supplies a short-lived SigV4-signed AUTH token at connect time
  # via the adapter's aws-iam credential provider.
  redis_url = "rediss://${local.redis_endpoint}:6379/0"

  # ElastiCache IAM SigV4 auth signs the token against the cache's resource
  # identifier (ReplicationGroupId / ServerlessCacheName), NOT the DNS
  # endpoint. Signing with the endpoint produces a token ElastiCache rejects
  # as "invalid username-password pair or user is disabled."
  redis_cache_name = (
    var.cache_type == "instance"
    ? aws_elasticache_replication_group.main[0].replication_group_id
    : aws_elasticache_serverless_cache.main[0].name
  )

  # Cache-mode flag used by the ElastiCache IAM Connect policy.
  is_serverless = var.cache_type == "serverless"

  # --- BYO computed references ---

  # VPC and networking
  vpc_id = var.use_existing_vpc ? var.existing_vpc_id : aws_vpc.main[0].id

  private_subnet_ids = var.use_existing_vpc ? var.existing_private_subnet_ids : [
    aws_subnet.private_a[0].id,
    aws_subnet.private_b[0].id,
  ]

  public_subnet_ids = var.use_existing_vpc ? var.existing_public_subnet_ids : [
    aws_subnet.public_a[0].id,
    aws_subnet.public_b[0].id,
  ]

  # ECR
  ecr_adapter_url  = var.byo_ecr_repos ? var.existing_ecr_adapter_url : aws_ecr_repository.adapter[0].repository_url
  ecr_admin_ui_url = var.byo_ecr_repos ? var.existing_ecr_admin_ui_url : aws_ecr_repository.admin_ui[0].repository_url

  # ACM
  acm_certificate_arn = var.existing_acm_certificate_arn != "" ? var.existing_acm_certificate_arn : aws_acm_certificate.this[0].arn

  # CodeBuild S3
  codebuild_source_bucket = var.existing_codebuild_source_bucket != "" ? var.existing_codebuild_source_bucket : (
    var.codebuild_source_bucket_name != "" ? var.codebuild_source_bucket_name : "${var.project_name}-codebuild-${data.aws_caller_identity.current.account_id}"
  )

  # IAM role names — default to project_name when iam_role_name_prefix is empty
  iam_role_name_prefix_effective = var.iam_role_name_prefix != "" ? var.iam_role_name_prefix : var.project_name
  iam_role_ecs_task_execution    = "${local.iam_role_name_prefix_effective}-ecs-task-execution"
  iam_role_ecs_task              = "${local.iam_role_name_prefix_effective}-ecs-task"
  iam_role_ecs_task_migrate      = "${local.iam_role_name_prefix_effective}-ecs-task-migrate"
  iam_role_codebuild             = "${local.iam_role_name_prefix_effective}-codebuild"

  # ALB
  alb_scheme = var.alb_scheme
}

# =============================================================================
# VPC
# =============================================================================

resource "aws_vpc" "main" {
  count = var.use_existing_vpc ? 0 : 1

  cidr_block           = "10.0.0.0/16"
  enable_dns_support   = true
  enable_dns_hostnames = true

  tags = merge(local.common_tags, {
    Name = "${local.project_name}-vpc"
  })
}

# --- Public Subnets ---

resource "aws_subnet" "public_a" {
  count = var.use_existing_vpc ? 0 : 1

  vpc_id                  = aws_vpc.main[0].id
  cidr_block              = "10.0.1.0/24"
  availability_zone       = local.azs[0]
  map_public_ip_on_launch = true

  tags = merge(local.common_tags, {
    Name = "${local.project_name}-public-a"
  })
}

resource "aws_subnet" "public_b" {
  count = var.use_existing_vpc ? 0 : 1

  vpc_id                  = aws_vpc.main[0].id
  cidr_block              = "10.0.2.0/24"
  availability_zone       = local.azs[1]
  map_public_ip_on_launch = true

  tags = merge(local.common_tags, {
    Name = "${local.project_name}-public-b"
  })
}

# --- Private Subnets ---

resource "aws_subnet" "private_a" {
  count = var.use_existing_vpc ? 0 : 1

  vpc_id            = aws_vpc.main[0].id
  cidr_block        = "10.0.10.0/24"
  availability_zone = local.azs[0]

  tags = merge(local.common_tags, {
    Name = "${local.project_name}-private-a"
  })
}

resource "aws_subnet" "private_b" {
  count = var.use_existing_vpc ? 0 : 1

  vpc_id            = aws_vpc.main[0].id
  cidr_block        = "10.0.11.0/24"
  availability_zone = local.azs[1]

  tags = merge(local.common_tags, {
    Name = "${local.project_name}-private-b"
  })
}

# =============================================================================
# Internet Gateway
# =============================================================================

resource "aws_internet_gateway" "main" {
  count = var.use_existing_vpc ? 0 : 1

  vpc_id = aws_vpc.main[0].id

  tags = merge(local.common_tags, {
    Name = "${local.project_name}-igw"
  })
}

# =============================================================================
# NAT Gateway
# =============================================================================
# Single NAT GW keeps demo costs low. For production HA, add a second NAT GW
# in subnet b.

resource "aws_eip" "nat" {
  count  = var.use_existing_vpc ? 0 : 1
  domain = "vpc"

  tags = merge(local.common_tags, {
    Name = "${local.project_name}-nat-eip"
  })
}

resource "aws_nat_gateway" "main" {
  count = var.use_existing_vpc ? 0 : 1

  allocation_id = aws_eip.nat[0].id
  subnet_id     = aws_subnet.public_a[0].id

  tags = merge(local.common_tags, {
    Name = "${local.project_name}-nat"
  })

  depends_on = [aws_internet_gateway.main]
}

# =============================================================================
# Route Tables
# =============================================================================

# --- Public Route Table ---

resource "aws_route_table" "public" {
  count = var.use_existing_vpc ? 0 : 1

  vpc_id = aws_vpc.main[0].id

  route {
    cidr_block = "0.0.0.0/0"
    gateway_id = aws_internet_gateway.main[0].id
  }

  tags = merge(local.common_tags, {
    Name = "${local.project_name}-public-rt"
  })
}

resource "aws_route_table_association" "public_a" {
  count = var.use_existing_vpc ? 0 : 1

  subnet_id      = aws_subnet.public_a[0].id
  route_table_id = aws_route_table.public[0].id
}

resource "aws_route_table_association" "public_b" {
  count = var.use_existing_vpc ? 0 : 1

  subnet_id      = aws_subnet.public_b[0].id
  route_table_id = aws_route_table.public[0].id
}

# --- Private Route Table ---

resource "aws_route_table" "private" {
  count = var.use_existing_vpc ? 0 : 1

  vpc_id = aws_vpc.main[0].id

  route {
    cidr_block     = "0.0.0.0/0"
    nat_gateway_id = aws_nat_gateway.main[0].id
  }

  tags = merge(local.common_tags, {
    Name = "${local.project_name}-private-rt"
  })
}

resource "aws_route_table_association" "private_a" {
  count = var.use_existing_vpc ? 0 : 1

  subnet_id      = aws_subnet.private_a[0].id
  route_table_id = aws_route_table.private[0].id
}

resource "aws_route_table_association" "private_b" {
  count = var.use_existing_vpc ? 0 : 1

  subnet_id      = aws_subnet.private_b[0].id
  route_table_id = aws_route_table.private[0].id
}

# =============================================================================
# ECR Repositories
# =============================================================================

resource "aws_ecr_repository" "adapter" {
  count = var.byo_ecr_repos ? 0 : 1

  name                 = "${local.project_name}-adapter"
  image_tag_mutability = var.ecr_image_tag_mutability
  force_delete         = true

  image_scanning_configuration {
    scan_on_push = var.ecr_scan_on_push
  }

  tags = local.common_tags
}

resource "aws_ecr_repository" "admin_ui" {
  count = var.byo_ecr_repos ? 0 : 1

  name                 = "${local.project_name}-admin-ui"
  image_tag_mutability = var.ecr_image_tag_mutability
  force_delete         = true

  image_scanning_configuration {
    scan_on_push = var.ecr_scan_on_push
  }

  tags = local.common_tags
}

# --- ECR Lifecycle Policies ---

resource "aws_ecr_lifecycle_policy" "adapter" {
  count = var.byo_ecr_repos ? 0 : 1

  repository = aws_ecr_repository.adapter[0].name

  policy = jsonencode({
    rules = [
      {
        rulePriority = 1
        description  = "Expire untagged images after 7 days"
        selection = {
          tagStatus   = "untagged"
          countType   = "sinceImagePushed"
          countUnit   = "days"
          countNumber = 7
        }
        action = {
          type = "expire"
        }
      },
      {
        rulePriority = 2
        description  = "Keep last 10 images"
        selection = {
          tagStatus   = "any"
          countType   = "imageCountMoreThan"
          countNumber = 10
        }
        action = {
          type = "expire"
        }
      }
    ]
  })
}

resource "aws_ecr_lifecycle_policy" "admin_ui" {
  count = var.byo_ecr_repos ? 0 : 1

  repository = aws_ecr_repository.admin_ui[0].name

  policy = jsonencode({
    rules = [
      {
        rulePriority = 1
        description  = "Expire untagged images after 7 days"
        selection = {
          tagStatus   = "untagged"
          countType   = "sinceImagePushed"
          countUnit   = "days"
          countNumber = 7
        }
        action = {
          type = "expire"
        }
      },
      {
        rulePriority = 2
        description  = "Keep last 10 images"
        selection = {
          tagStatus   = "any"
          countType   = "imageCountMoreThan"
          countNumber = 10
        }
        action = {
          type = "expire"
        }
      }
    ]
  })
}

# =============================================================================
# E2: Data Tier — RDS PostgreSQL + ElastiCache Redis
# =============================================================================

# --- Random Passwords ---

resource "random_password" "db_password" {
  length           = 24
  special          = true
  override_special = "!#$%^&*()-_=+"
}

# Phase 2: no random_password.redis_password. Redis authentication uses
# ElastiCache IAM — the adapter's task role is granted elasticache:Connect
# (see aws_iam_role_policy.ecs_task_elasticache_iam below) and mints a
# short-lived SigV4-signed AUTH token per connection.

# =============================================================================
# Security Groups
# =============================================================================

# --- ALB Security Group (forward declaration — ALB created in E6) ---
# Rules are defined as separate resources to avoid circular dependency
# between ALB SG and ECS tasks SG.

resource "aws_security_group" "alb_sg" {
  name_prefix = "${local.project_name}-alb-"
  description = "ALB security group"
  vpc_id      = local.vpc_id

  tags = merge(local.common_tags, {
    Name = "${local.project_name}-alb"
  })
}

resource "aws_security_group_rule" "alb_ingress_https" {
  security_group_id = aws_security_group.alb_sg.id
  type              = "ingress"
  description       = "HTTPS from internet"
  from_port         = 443
  to_port           = 443
  protocol          = "tcp"
  cidr_blocks       = ["0.0.0.0/0"]
}

resource "aws_security_group_rule" "alb_ingress_http" {
  security_group_id = aws_security_group.alb_sg.id
  type              = "ingress"
  description       = "HTTP from internet (redirect to HTTPS)"
  from_port         = 80
  to_port           = 80
  protocol          = "tcp"
  cidr_blocks       = ["0.0.0.0/0"]
}

resource "aws_security_group_rule" "alb_egress_adapter" {
  security_group_id        = aws_security_group.alb_sg.id
  type                     = "egress"
  description              = "To adapter"
  from_port                = var.gateway_port
  to_port                  = var.gateway_port
  protocol                 = "tcp"
  source_security_group_id = aws_security_group.ecs_tasks_sg.id
}

resource "aws_security_group_rule" "alb_egress_admin_ui" {
  security_group_id        = aws_security_group.alb_sg.id
  type                     = "egress"
  description              = "To admin UI"
  from_port                = var.admin_ui_port
  to_port                  = var.admin_ui_port
  protocol                 = "tcp"
  source_security_group_id = aws_security_group.ecs_tasks_sg.id
}

# --- ECS Tasks Security Group (forward declaration — services attach later) ---

resource "aws_security_group" "ecs_tasks_sg" {
  name_prefix = "${local.project_name}-ecs-tasks-"
  description = "ECS tasks security group"
  vpc_id      = local.vpc_id

  tags = merge(local.common_tags, {
    Name = "${local.project_name}-ecs-tasks"
  })
}

resource "aws_security_group_rule" "ecs_ingress_adapter" {
  security_group_id        = aws_security_group.ecs_tasks_sg.id
  type                     = "ingress"
  description              = "Adapter from ALB"
  from_port                = var.gateway_port
  to_port                  = var.gateway_port
  protocol                 = "tcp"
  source_security_group_id = aws_security_group.alb_sg.id
}

resource "aws_security_group_rule" "ecs_ingress_admin_ui" {
  security_group_id        = aws_security_group.ecs_tasks_sg.id
  type                     = "ingress"
  description              = "Admin UI from ALB"
  from_port                = var.admin_ui_port
  to_port                  = var.admin_ui_port
  protocol                 = "tcp"
  source_security_group_id = aws_security_group.alb_sg.id
}

resource "aws_security_group_rule" "ecs_ingress_adapter_east_west" {
  security_group_id        = aws_security_group.ecs_tasks_sg.id
  type                     = "ingress"
  description              = "Adapter east-west (admin-ui to adapter via Service Connect)"
  from_port                = var.gateway_port
  to_port                  = var.gateway_port
  protocol                 = "tcp"
  source_security_group_id = aws_security_group.ecs_tasks_sg.id
}

resource "aws_security_group_rule" "ecs_egress_all" {
  security_group_id = aws_security_group.ecs_tasks_sg.id
  type              = "egress"
  description       = "All outbound (Okta, ECR, etc.)"
  from_port         = 0
  to_port           = 0
  protocol          = "-1"
  cidr_blocks       = ["0.0.0.0/0"]
}

# --- RDS Security Group ---

resource "aws_security_group" "rds_sg" {
  name_prefix = "${local.project_name}-rds-"
  description = "RDS PostgreSQL security group"
  vpc_id      = local.vpc_id

  ingress {
    description     = "PostgreSQL from ECS tasks"
    from_port       = 5432
    to_port         = 5432
    protocol        = "tcp"
    security_groups = [aws_security_group.ecs_tasks_sg.id]
  }

  tags = merge(local.common_tags, {
    Name = "${local.project_name}-rds"
  })
}

# --- Redis Security Group ---

resource "aws_security_group" "redis_sg" {
  name_prefix = "${local.project_name}-redis-"
  description = "ElastiCache Redis security group"
  vpc_id      = local.vpc_id

  ingress {
    description     = "Redis from ECS tasks"
    from_port       = 6379
    to_port         = 6379
    protocol        = "tcp"
    security_groups = [aws_security_group.ecs_tasks_sg.id]
  }

  tags = merge(local.common_tags, {
    Name = "${local.project_name}-redis"
  })
}

# =============================================================================
# RDS PostgreSQL
# =============================================================================

resource "aws_db_subnet_group" "main" {
  name       = "${local.project_name}-db"
  subnet_ids = local.private_subnet_ids

  tags = merge(local.common_tags, {
    Name = "${local.project_name}-db-subnet-group"
  })
}

# The master username/password is kept for break-glass admin access only —
# the adapter and migrate task authenticate via RDS IAM when use_rds_iam=true
# (P13). The password is still stored in Secrets Manager (aws_secretsmanager_secret.db)
# so a DBA can connect directly if IAM is misconfigured.
resource "aws_db_instance" "this" {
  identifier = "${local.project_name}-postgres"

  engine         = "postgres"
  engine_version = "15"
  instance_class = local.db_instance_class

  allocated_storage     = 20
  max_allocated_storage = 50
  storage_type          = "gp3"

  db_name  = "gateway_db"
  username = "gateway_user"
  password = random_password.db_password.result

  # Enable IAM database authentication on the instance. The feature is free;
  # individual roles still need `GRANT rds_iam TO <role>` to use it (done by
  # bootstrap_roles.sql / the migrate task).
  iam_database_authentication_enabled = true

  multi_az               = local.db_multi_az
  db_subnet_group_name   = aws_db_subnet_group.main.name
  vpc_security_group_ids = [aws_security_group.rds_sg.id]

  storage_encrypted            = true
  kms_key_id                   = var.existing_kms_key_arn_rds != "" ? var.existing_kms_key_arn_rds : null
  parameter_group_name         = var.rds_parameter_group_name != "" ? var.rds_parameter_group_name : null
  deletion_protection          = var.rds_deletion_protection
  backup_retention_period      = var.rds_backup_retention_days
  skip_final_snapshot          = true
  performance_insights_enabled = true
  apply_immediately            = true

  tags = local.common_tags
}

# =============================================================================
# ElastiCache Redis
# =============================================================================

# --- Instance mode (cache_type = "instance") ---

resource "aws_elasticache_subnet_group" "main" {
  count = var.cache_type == "instance" ? 1 : 0

  name       = "${local.project_name}-redis"
  subnet_ids = local.private_subnet_ids

  tags = local.common_tags
}

resource "aws_elasticache_replication_group" "main" {
  count = var.cache_type == "instance" ? 1 : 0

  replication_group_id = "${local.project_name}-redis"
  description          = "Okta MCP Adapter Redis"

  engine         = "redis"
  engine_version = "7.1"
  node_type      = local.cache_instance_class

  num_cache_clusters         = local.cache_replicas
  automatic_failover_enabled = var.deployment_size == "small-prod"

  at_rest_encryption_enabled = true
  kms_key_id                 = var.existing_kms_key_arn_elasticache != "" ? var.existing_kms_key_arn_elasticache : null
  transit_encryption_enabled = true # required for IAM authentication
  # Phase 2: auth_token removed — ElastiCache IAM authentication is the
  # authorization path, wired via user_group_ids below.

  parameter_group_name = var.elasticache_parameter_group_name != "" ? var.elasticache_parameter_group_name : null

  subnet_group_name  = aws_elasticache_subnet_group.main[0].name
  security_group_ids = [aws_security_group.redis_sg.id]

  user_group_ids = [aws_elasticache_user_group.adapter.user_group_id]

  port = 6379

  tags = local.common_tags
}

# --- Serverless mode (cache_type = "serverless") ---

resource "aws_elasticache_serverless_cache" "main" {
  count = var.cache_type == "serverless" ? 1 : 0

  engine = "redis"
  name   = "${local.project_name}-redis"

  subnet_ids         = local.private_subnet_ids
  security_group_ids = [aws_security_group.redis_sg.id]

  user_group_id = aws_elasticache_user_group.adapter.user_group_id

  tags = local.common_tags
}

# --- IAM-enabled ElastiCache user + user group (Phase 2) ---
# Phase 2: Redis AUTH is delegated to IAM via this user. The ECS task
# role (see aws_iam_role_policy.ecs_task_elasticache_iam) is granted
# elasticache:Connect on this user and the cache; the adapter mints a
# SigV4-signed AUTH token at connection time.

resource "aws_elasticache_user" "adapter" {
  user_id   = var.redis_iam_user_id
  user_name = var.redis_iam_user_id
  engine    = "REDIS"

  authentication_mode {
    type = "iam"
  }

  access_string = "on ~* +@all"

  tags = local.common_tags
}

resource "aws_elasticache_user_group" "adapter" {
  engine        = "REDIS"
  user_group_id = "${local.project_name}-adapter"
  user_ids      = [aws_elasticache_user.adapter.user_id, "default"]

  tags = local.common_tags

  lifecycle {
    ignore_changes = [user_ids]
  }
}

# =============================================================================
# E3: Secrets Manager + IAM Roles
# =============================================================================

data "aws_caller_identity" "current" {}

# --- Random password for NextAuth secret ---

resource "random_password" "nextauth_secret" {
  length  = 48
  special = false
}

# --- AES-256 encryption key (32 bytes, base64-encoded into secret value) ---
#
# Terraform owns this value so it survives any shell that runs `terraform apply`
# without the TF_VAR_encryption_key export that deploy.sh sets. Regenerating
# this key after agents/resources are seeded in the DB makes previously
# encrypted rows unreadable, so pair with ignore_changes on the consuming
# secret version below. If var.encryption_key is supplied (e.g. restoring
# from .generated-secrets), that takes precedence.
resource "random_password" "encryption_key" {
  length  = 32
  special = false
}

# =============================================================================
# Secrets Manager — 4 JSON secrets
# =============================================================================

# Tags are conditionally applied because some AWS Organizations
# restrict secretsmanager:UntagResource via SCP. Set
# skip_resource_tagging_on_secrets = true in those environments.

resource "aws_secretsmanager_secret" "db" {
  name                    = "${local.project_name}/db"
  recovery_window_in_days = 0
  kms_key_id              = var.existing_kms_key_arn_secrets != "" ? var.existing_kms_key_arn_secrets : null

  tags = var.skip_resource_tagging_on_secrets ? {} : local.common_tags
}

resource "aws_secretsmanager_secret_version" "db" {
  secret_id = aws_secretsmanager_secret.db.id
  secret_string = jsonencode({
    # sslmode=require is required because pg_hba.conf on an IAM-enabled RDS
    # instance routes non-SSL connections to PAM auth (= IAM token), which
    # rejects the master password. The master must connect over SSL to hit
    # the password-auth rule.
    DATABASE_URL = "postgresql://gateway_user:${urlencode(random_password.db_password.result)}@${aws_db_instance.this.endpoint}/gateway_db?sslmode=require"
  })
}

# Phase 2: no aws_secretsmanager_secret.redis. REDIS_URL is a plain env
# var (host/port only — no password) and REDIS_PASSWORD is not stored or
# referenced anywhere. ElastiCache IAM supplies credentials at connect time.

resource "aws_secretsmanager_secret" "okta" {
  name                    = "${local.project_name}/okta"
  recovery_window_in_days = 0
  kms_key_id              = var.existing_kms_key_arn_secrets != "" ? var.existing_kms_key_arn_secrets : null

  tags = var.skip_resource_tagging_on_secrets ? {} : local.common_tags
}

resource "aws_secretsmanager_secret_version" "okta" {
  secret_id = aws_secretsmanager_secret.okta.id
  secret_string = jsonencode({
    OKTA_DOMAIN = var.okta_domain
  })
}

resource "aws_secretsmanager_secret" "app" {
  name                    = "${local.project_name}/app"
  recovery_window_in_days = 0
  kms_key_id              = var.existing_kms_key_arn_secrets != "" ? var.existing_kms_key_arn_secrets : null

  tags = var.skip_resource_tagging_on_secrets ? {} : local.common_tags
}

resource "aws_secretsmanager_secret_version" "app" {
  secret_id = aws_secretsmanager_secret.app.id
  secret_string = jsonencode({
    # ENCRYPTION_KEY: prefer caller-supplied var.encryption_key (e.g. restored
    # from .generated-secrets); otherwise generate a fresh one via
    # random_password.encryption_key so the key exists even when
    # TF_VAR_encryption_key is not exported.
    ENCRYPTION_KEY              = var.encryption_key != "" ? var.encryption_key : base64encode(random_password.encryption_key.result)
    GATEWAY_BASE_URL            = "https://${var.adapter_hostname}"
    ADMIN_UI_NEXTAUTH_SECRET    = random_password.nextauth_secret.result
    ADMIN_UI_OKTA_CLIENT_SECRET = var.admin_ui_okta_client_secret
  })

  # Seed-once semantics. After first apply the secret contents live in AWS;
  # Terraform leaves them alone so any subsequent apply that lacks the
  # var.encryption_key / admin_ui_okta_client_secret exports cannot rewrite
  # ENCRYPTION_KEY="" and render previously encrypted DB rows unreadable.
  # Rotations are an explicit out-of-band op: update the secret via AWS CLI
  # or `terraform taint aws_secretsmanager_secret_version.app` + apply.
  lifecycle {
    ignore_changes = [secret_string]
  }
}

# =============================================================================
# IAM — ECS Task Execution Role
# =============================================================================
# This role is assumed by the ECS agent to pull images, read secrets, and
# write logs on behalf of the task.

resource "aws_iam_role" "ecs_task_execution" {
  name                 = local.iam_role_ecs_task_execution
  path                 = var.iam_role_path
  permissions_boundary = var.iam_permissions_boundary != "" ? var.iam_permissions_boundary : null

  assume_role_policy = jsonencode({
    Version = "2012-10-17"
    Statement = [
      {
        Effect = "Allow"
        Principal = {
          Service = "ecs-tasks.amazonaws.com"
        }
        Action = "sts:AssumeRole"
      }
    ]
  })

  tags = local.common_tags
}

resource "aws_iam_role_policy_attachment" "ecs_task_execution_managed" {
  role       = aws_iam_role.ecs_task_execution.name
  policy_arn = "arn:aws:iam::aws:policy/service-role/AmazonECSTaskExecutionRolePolicy"
}

resource "aws_iam_role_policy" "ecs_task_execution_secrets" {
  name = "secrets-access"
  role = aws_iam_role.ecs_task_execution.id

  policy = jsonencode({
    Version = "2012-10-17"
    Statement = [
      {
        Effect = "Allow"
        Action = "secretsmanager:GetSecretValue"
        Resource = [
          aws_secretsmanager_secret.db.arn,
          aws_secretsmanager_secret.okta.arn,
          aws_secretsmanager_secret.app.arn,
        ]
      }
    ]
  })
}

resource "aws_iam_role_policy" "ecs_task_execution_ecr" {
  name = "ecr-access"
  role = aws_iam_role.ecs_task_execution.id

  policy = jsonencode({
    Version = "2012-10-17"
    Statement = [
      {
        Effect   = "Allow"
        Action   = "ecr:GetAuthorizationToken"
        Resource = "*"
      },
      {
        Effect = "Allow"
        Action = [
          "ecr:BatchCheckLayerAvailability",
          "ecr:GetDownloadUrlForLayer",
          "ecr:BatchGetImage",
        ]
        Resource = var.byo_ecr_repos ? ["*"] : [
          aws_ecr_repository.adapter[0].arn,
          aws_ecr_repository.admin_ui[0].arn,
        ]
      }
    ]
  })
}

resource "aws_iam_role_policy" "ecs_task_execution_logs" {
  name = "logs"
  role = aws_iam_role.ecs_task_execution.id

  policy = jsonencode({
    Version = "2012-10-17"
    Statement = [
      {
        Effect = "Allow"
        Action = [
          "logs:CreateLogGroup",
          "logs:CreateLogStream",
          "logs:PutLogEvents",
        ]
        Resource = "arn:aws:logs:${var.aws_region}:${data.aws_caller_identity.current.account_id}:*"
      }
    ]
  })
}

# =============================================================================
# IAM — ECS Task Role
# =============================================================================
# This role is assumed by the running container. Kept minimal — only secrets
# read access for potential runtime secret rotation.

resource "aws_iam_role" "ecs_task" {
  name                 = local.iam_role_ecs_task
  path                 = var.iam_role_path
  permissions_boundary = var.iam_permissions_boundary != "" ? var.iam_permissions_boundary : null

  assume_role_policy = jsonencode({
    Version = "2012-10-17"
    Statement = [
      {
        Effect = "Allow"
        Principal = {
          Service = "ecs-tasks.amazonaws.com"
        }
        Action = "sts:AssumeRole"
      }
    ]
  })

  tags = local.common_tags
}

resource "aws_iam_role_policy" "ecs_task_secrets" {
  name = "secrets-read"
  role = aws_iam_role.ecs_task.id

  policy = jsonencode({
    Version = "2012-10-17"
    Statement = [
      {
        Effect = "Allow"
        Action = "secretsmanager:GetSecretValue"
        Resource = [
          aws_secretsmanager_secret.db.arn,
          aws_secretsmanager_secret.okta.arn,
          aws_secretsmanager_secret.app.arn,
        ]
      }
    ]
  })
}

# rds-db:connect permission for the adapter task role — used only when
# use_rds_iam=true. The resource ARN is scoped to a single dbuser (the
# app role), so the adapter cannot mint tokens for the owner or master.
resource "aws_iam_role_policy" "ecs_task_rds_iam_connect" {
  count = var.use_rds_iam ? 1 : 0

  name = "rds-iam-connect-app"
  role = aws_iam_role.ecs_task.id

  policy = jsonencode({
    Version = "2012-10-17"
    Statement = [
      {
        Effect   = "Allow"
        Action   = "rds-db:connect"
        Resource = "arn:aws:rds-db:${var.aws_region}:${data.aws_caller_identity.current.account_id}:dbuser:${aws_db_instance.this.resource_id}/${var.db_app_role}"
      }
    ]
  })
}

# Phase 2: elasticache:Connect policy for IAM authentication to Redis.
# The task role is granted Connect permission against both the cache
# (replication group or serverless cache) and the IAM-enabled user.
resource "aws_iam_role_policy" "ecs_task_elasticache_iam" {
  name = "${local.project_name}-elasticache-iam"
  role = aws_iam_role.ecs_task.id

  policy = jsonencode({
    Version = "2012-10-17"
    Statement = [{
      Effect = "Allow"
      Action = "elasticache:Connect"
      Resource = local.is_serverless ? [
        aws_elasticache_serverless_cache.main[0].arn,
        aws_elasticache_user.adapter.arn,
        ] : [
        aws_elasticache_replication_group.main[0].arn,
        aws_elasticache_user.adapter.arn,
      ]
    }]
  })
}

# =============================================================================
# IAM — Migrate Task Role (DB Owner)
# =============================================================================
# Used exclusively by the one-shot migration ECS task. Has rds-db:connect
# to the owner DB user (IAM-enabled when use_rds_iam=true) and read access
# to the master-credentials secret for the very first bootstrap (which
# creates the two roles via bootstrap_roles.sql). Never attached to the
# adapter or admin-ui services.

resource "aws_iam_role" "ecs_task_migrate" {
  name                 = local.iam_role_ecs_task_migrate
  path                 = var.iam_role_path
  permissions_boundary = var.iam_permissions_boundary != "" ? var.iam_permissions_boundary : null

  assume_role_policy = jsonencode({
    Version = "2012-10-17"
    Statement = [
      {
        Effect = "Allow"
        Principal = {
          Service = "ecs-tasks.amazonaws.com"
        }
        Action = "sts:AssumeRole"
      }
    ]
  })

  tags = local.common_tags
}

# Migrate task needs the master URL (for bootstrap_roles.sql on first deploy)
# and, in static-password mode, the app secret for encryption-key access.
resource "aws_iam_role_policy" "ecs_task_migrate_secrets" {
  name = "secrets-read"
  role = aws_iam_role.ecs_task_migrate.id

  policy = jsonencode({
    Version = "2012-10-17"
    Statement = [
      {
        Effect   = "Allow"
        Action   = "secretsmanager:GetSecretValue"
        Resource = [aws_secretsmanager_secret.db.arn]
      }
    ]
  })
}

# rds-db:connect for the owner DB user (IAM-enabled). Scoped to a single
# dbuser ARN so the migrate task cannot connect as app or master.
resource "aws_iam_role_policy" "ecs_task_migrate_rds_iam_connect" {
  count = var.use_rds_iam ? 1 : 0

  name = "rds-iam-connect-owner"
  role = aws_iam_role.ecs_task_migrate.id

  policy = jsonencode({
    Version = "2012-10-17"
    Statement = [
      {
        Effect   = "Allow"
        Action   = "rds-db:connect"
        Resource = "arn:aws:rds-db:${var.aws_region}:${data.aws_caller_identity.current.account_id}:dbuser:${aws_db_instance.this.resource_id}/${var.db_owner_role}"
      }
    ]
  })
}

# =============================================================================
# E5: ECS Cluster + Task Definitions
# =============================================================================

# --- ECS Cluster ---

resource "aws_ecs_cluster" "main" {
  name = "${local.project_name}-cluster"

  setting {
    name  = "containerInsights"
    value = "enabled"
  }

  tags = local.common_tags
}

# --- Capacity Providers ---

resource "aws_ecs_cluster_capacity_providers" "main" {
  cluster_name = aws_ecs_cluster.main.name

  capacity_providers = ["FARGATE", "FARGATE_SPOT"]

  default_capacity_provider_strategy {
    capacity_provider = var.deployment_size == "demo" ? "FARGATE" : "FARGATE_SPOT"
    weight            = 1
    base              = 1
  }
}

# --- CloudWatch Log Groups ---

resource "aws_cloudwatch_log_group" "adapter" {
  name              = "${var.log_group_prefix}/adapter"
  retention_in_days = var.log_group_retention_days
  kms_key_id        = var.existing_kms_key_arn_logs != "" ? var.existing_kms_key_arn_logs : null

  tags = local.common_tags
}

resource "aws_cloudwatch_log_group" "admin_ui" {
  name              = "${var.log_group_prefix}/admin-ui"
  retention_in_days = var.log_group_retention_days
  kms_key_id        = var.existing_kms_key_arn_logs != "" ? var.existing_kms_key_arn_logs : null

  tags = local.common_tags
}

# --- Service Connect Namespace ---

resource "aws_service_discovery_private_dns_namespace" "main" {
  name = "${local.project_name}.local"
  vpc  = local.vpc_id

  tags = local.common_tags
}

# =============================================================================
# Task Definitions
# =============================================================================

# --- Adapter Task Definition ---

resource "aws_ecs_task_definition" "adapter" {
  family                   = "${local.project_name}-adapter"
  requires_compatibilities = ["FARGATE"]
  network_mode             = "awsvpc"
  cpu                      = 512
  memory                   = 1024
  execution_role_arn       = aws_iam_role.ecs_task_execution.arn
  task_role_arn            = aws_iam_role.ecs_task.arn

  container_definitions = jsonencode([
    {
      name      = "adapter"
      image     = "${local.ecr_adapter_url}:${var.adapter_image_tag}"
      essential = true

      portMappings = [
        {
          containerPort = var.gateway_port
          name          = "adapter-http"
          protocol      = "tcp"
        }
      ]

      healthCheck = {
        command     = ["CMD-SHELL", "curl -f http://localhost:${var.gateway_port}/.well-known/oauth-protected-resource || exit 1"]
        interval    = 30
        timeout     = 5
        retries     = 3
        startPeriod = 30
      }

      environment = concat(
        [
          { name = "GATEWAY_PORT", value = tostring(var.gateway_port) },
          { name = "CACHE_PROVIDER", value = "redis" },
          { name = "REDIS_KEY_PREFIX", value = "${var.project_name}:" },
          { name = "REDIS_TLS_ENABLED", value = "true" },
          { name = "LOG_LEVEL", value = "INFO" },
          { name = "LOG_FORMAT", value = "json" },
          { name = "DEPLOYMENT_MODE", value = "standalone" },
          { name = "CIMD_ENABLED", value = "true" },
          { name = "CIMD_REQUIRE_HTTPS", value = "true" },
          { name = "CIMD_TRUSTED_BACKEND_ACCESS", value = "hr-system,deploy-server" },
          { name = "CIMD_UNKNOWN_BACKEND_ACCESS", value = "hr-system,deploy-server" },
          { name = "PYTHONUNBUFFERED", value = "1" },
          { name = "PYTHONDONTWRITEBYTECODE", value = "1" },

          # --- Redis credential provider (Phase 2) ---
          # IAM authentication: no shared secret. The task role's
          # elasticache:Connect permission (see
          # aws_iam_role_policy.ecs_task_elasticache_iam) authorizes this
          # task to mint short-lived AUTH tokens at connect time via the
          # adapter's aws-iam credential provider.
          { name = "REDIS_AUTH_MODE", value = "aws-iam" },
          { name = "REDIS_AWS_USER_ID", value = var.redis_iam_user_id },
          { name = "REDIS_AWS_CACHE_NAME", value = local.redis_cache_name },
          { name = "REDIS_AWS_SERVERLESS", value = local.is_serverless ? "true" : "false" },
          { name = "AWS_REGION", value = var.aws_region },

          # REDIS_URL is host/port only — no embedded password.
          { name = "REDIS_URL", value = local.redis_url },
        ],
        # RDS IAM mode (P13): no password in DATABASE_URL. The adapter calls
        # rds:generate-db-auth-token on each new connection via its task role.
        var.use_rds_iam ? [
          { name = "DB_CREDENTIAL_PROVIDER", value = "rds_iam" },
          { name = "DB_HOST", value = aws_db_instance.this.address },
          { name = "DB_PORT", value = "5432" },
          { name = "DB_NAME", value = aws_db_instance.this.db_name },
          { name = "DB_USERNAME", value = var.db_app_role },
          { name = "DB_SSLROOTCERT", value = "/opt/rds-ca/global-bundle.pem" },
        ] : []
      )

      secrets = concat(
        # Static-password mode: legacy DATABASE_URL secret injected as before.
        var.use_rds_iam ? [] : [
          { name = "DATABASE_URL", valueFrom = "${aws_secretsmanager_secret.db.arn}:DATABASE_URL::" },
        ],
        [
          { name = "OKTA_DOMAIN", valueFrom = "${aws_secretsmanager_secret.okta.arn}:OKTA_DOMAIN::" },
          { name = "ENCRYPTION_KEY", valueFrom = "${aws_secretsmanager_secret.app.arn}:ENCRYPTION_KEY::" },
          { name = "GATEWAY_BASE_URL", valueFrom = "${aws_secretsmanager_secret.app.arn}:GATEWAY_BASE_URL::" },
        ]
      )

      logConfiguration = {
        logDriver = "awslogs"
        options = {
          "awslogs-group"         = aws_cloudwatch_log_group.adapter.name
          "awslogs-region"        = var.aws_region
          "awslogs-stream-prefix" = "adapter"
        }
      }
    }
  ])

  tags = local.common_tags
}

# --- Migrate Task Definition (one-shot; run before adapter service update) ---
# Runs bootstrap_roles.sql as the master user (idempotent), then applies
# pending SQL migrations as the owner role via the in-tree migrate runner.
# P13: the runner replaces the prior Alembic upgrade step.

resource "aws_ecs_task_definition" "migrate" {
  family                   = "${local.project_name}-migrate"
  requires_compatibilities = ["FARGATE"]
  network_mode             = "awsvpc"
  cpu                      = 256
  memory                   = 512
  execution_role_arn       = aws_iam_role.ecs_task_execution.arn
  task_role_arn            = aws_iam_role.ecs_task_migrate.arn

  container_definitions = jsonencode([
    {
      name      = "migrate"
      image     = "${local.ecr_adapter_url}:${var.adapter_image_tag}"
      essential = true

      # Step 1: bootstrap two roles idempotently using the RDS master user
      #         (BOOTSTRAP_URL from Secrets Manager).
      # Step 2: apply pending migrations via the SQL runner. When
      #         use_rds_iam=true, the runner picks up DB_CREDENTIAL_PROVIDER
      #         env vars and mints an auth token for the owner role.
      #         Otherwise it falls back to BOOTSTRAP_URL (master) — static
      #         mode does not provision an owner password.
      command = [
        "/bin/sh",
        "-c",
        join(" && ", [
          "psql \"$BOOTSTRAP_URL\" -v ON_ERROR_STOP=1 -f /app/deploy/migrations/sql/bootstrap_roles.sql",
          "python -m okta_agent_proxy.storage.migrate upgrade --migrations-dir /app/deploy/migrations/sql${var.use_rds_iam ? "" : " --conninfo \"$BOOTSTRAP_URL\""}"
        ])
      ]

      environment = concat(
        [
          { name = "DB_OWNER_ROLE", value = var.db_owner_role },
          { name = "DB_APP_ROLE", value = var.db_app_role },
          { name = "DB_NAME", value = aws_db_instance.this.db_name },
          { name = "PYTHONUNBUFFERED", value = "1" },
        ],
        # In IAM mode the runner uses the provider abstraction to mint a
        # fresh token for the owner role on each connection.
        var.use_rds_iam ? [
          { name = "DB_CREDENTIAL_PROVIDER", value = "rds_iam" },
          { name = "DB_HOST", value = aws_db_instance.this.address },
          { name = "DB_PORT", value = "5432" },
          { name = "DB_USERNAME", value = var.db_owner_role },
          { name = "AWS_REGION", value = var.aws_region },
          { name = "DB_SSLROOTCERT", value = "/opt/rds-ca/global-bundle.pem" },
        ] : []
      )

      secrets = [
        # Master creds — required for the bootstrap_roles.sql run (creates the
        # two roles, grants default privileges). Never loaded by the adapter.
        { name = "BOOTSTRAP_URL", valueFrom = "${aws_secretsmanager_secret.db.arn}:DATABASE_URL::" },
      ]

      logConfiguration = {
        logDriver = "awslogs"
        options = {
          "awslogs-group"         = aws_cloudwatch_log_group.adapter.name
          "awslogs-region"        = var.aws_region
          "awslogs-stream-prefix" = "migrate"
        }
      }
    }
  ])

  tags = local.common_tags
}

# --- Admin UI Task Definition ---

resource "aws_ecs_task_definition" "admin_ui" {
  family                   = "${local.project_name}-admin-ui"
  requires_compatibilities = ["FARGATE"]
  network_mode             = "awsvpc"
  cpu                      = 256
  memory                   = 512
  execution_role_arn       = aws_iam_role.ecs_task_execution.arn
  task_role_arn            = aws_iam_role.ecs_task.arn

  container_definitions = jsonencode([
    {
      name      = "admin-ui"
      image     = "${local.ecr_admin_ui_url}:${var.admin_ui_image_tag}"
      essential = true

      portMappings = [
        {
          containerPort = var.admin_ui_port
          name          = "admin-ui-http"
          protocol      = "tcp"
        }
      ]

      healthCheck = {
        command     = ["CMD-SHELL", "wget --spider -q http://localhost:${var.admin_ui_port}/ || exit 1"]
        interval    = 30
        timeout     = 5
        retries     = 3
        startPeriod = 30
      }

      environment = [
        { name = "NEXT_PUBLIC_API_URL", value = "http://adapter.${local.project_name}.local:${var.gateway_port}" },
        { name = "API_URL", value = "http://adapter.${local.project_name}.local:${var.gateway_port}" },
        { name = "NEXT_PUBLIC_APP_NAME", value = "Okta MCP Adapter Admin" },
        { name = "NODE_ENV", value = "production" },
        { name = "PORT", value = tostring(var.admin_ui_port) },
        { name = "ADMIN_UI_PORT", value = tostring(var.admin_ui_port) },
        { name = "HOSTNAME", value = "0.0.0.0" },
        { name = "NEXTAUTH_URL", value = "https://${var.admin_hostname}" },
        { name = "OKTA_DOMAIN", value = var.admin_ui_okta_domain },
        { name = "OKTA_CLIENT_ID", value = var.admin_ui_okta_client_id },
      ]

      secrets = [
        { name = "NEXTAUTH_SECRET", valueFrom = "${aws_secretsmanager_secret.app.arn}:ADMIN_UI_NEXTAUTH_SECRET::" },
        { name = "OKTA_CLIENT_SECRET", valueFrom = "${aws_secretsmanager_secret.app.arn}:ADMIN_UI_OKTA_CLIENT_SECRET::" },
      ]

      logConfiguration = {
        logDriver = "awslogs"
        options = {
          "awslogs-group"         = aws_cloudwatch_log_group.admin_ui.name
          "awslogs-region"        = var.aws_region
          "awslogs-stream-prefix" = "admin-ui"
        }
      }
    }
  ])

  tags = local.common_tags
}

# =============================================================================
# E6: ACM Certificate + ALB + ECS Services + Route53 DNS
# =============================================================================

# --- ACM Certificate ---

resource "aws_acm_certificate" "this" {
  count = var.existing_acm_certificate_arn == "" ? 1 : 0

  domain_name               = var.adapter_hostname
  subject_alternative_names = [var.admin_hostname]
  validation_method         = "DNS"

  tags = local.common_tags

  lifecycle {
    create_before_destroy = true
  }
}

# --- Route53 DNS Validation Records (Tier 1/2 only, skip when BYO cert) ---

resource "aws_route53_record" "cert_validation" {
  for_each = var.existing_acm_certificate_arn == "" && var.dns_provider != "external" ? {
    for dvo in aws_acm_certificate.this[0].domain_validation_options : dvo.domain_name => {
      name   = dvo.resource_record_name
      record = dvo.resource_record_value
      type   = dvo.resource_record_type
    }
  } : {}

  allow_overwrite = true
  name            = each.value.name
  records         = [each.value.record]
  ttl             = 60
  type            = each.value.type
  zone_id         = var.route53_zone_id
}

# --- External DNS: instructions for manual CNAME creation (Tier 3 only, skip when BYO cert) ---

resource "null_resource" "external_dns_instructions" {
  count = var.existing_acm_certificate_arn == "" && var.dns_provider == "external" ? 1 : 0

  triggers = {
    cert_arn = aws_acm_certificate.this[0].arn
  }

  provisioner "local-exec" {
    command = <<-EOT
      echo ""
      echo "═══════════════════════════════════════════════════════════"
      echo "  EXTERNAL DNS ACTION REQUIRED"
      echo "═══════════════════════════════════════════════════════════"
      echo ""
      echo "The ACM certificate is pending DNS validation. Create the"
      echo "following CNAME records in your DNS provider:"
      echo ""
      ${join("\n", [
    for dvo in aws_acm_certificate.this[0].domain_validation_options :
    "echo '  Name:  ${dvo.resource_record_name}'\n      echo '  Value: ${dvo.resource_record_value}'\n      echo '  Type:  ${dvo.resource_record_type}'\n      echo ''"
])}
      echo "Terraform will wait up to ${var.external_dns_validation_timeout}"
      echo "for these records to propagate. Press Ctrl+C if you need"
      echo "more time — re-run deploy.sh --apply when records are set."
      echo ""
      echo "═══════════════════════════════════════════════════════════"
    EOT
}
}

# --- ACM Certificate Validation (Tier 1/2: Route53-based) ---

resource "aws_acm_certificate_validation" "route53" {
  count                   = var.existing_acm_certificate_arn == "" && var.dns_provider != "external" ? 1 : 0
  certificate_arn         = aws_acm_certificate.this[0].arn
  validation_record_fqdns = [for record in aws_route53_record.cert_validation : record.fqdn]

  timeouts {
    create = "15m"
  }
}

# --- ACM Certificate Validation (Tier 3: External DNS) ---

resource "aws_acm_certificate_validation" "external" {
  count           = var.existing_acm_certificate_arn == "" && var.dns_provider == "external" ? 1 : 0
  certificate_arn = aws_acm_certificate.this[0].arn
  validation_record_fqdns = [
    for dvo in aws_acm_certificate.this[0].domain_validation_options :
    dvo.resource_record_name
  ]

  timeouts {
    create = var.external_dns_validation_timeout
  }

  depends_on = [null_resource.external_dns_instructions]
}

# --- Application Load Balancer ---

resource "aws_lb" "main" {
  name               = "${local.project_name}-alb"
  internal           = var.alb_scheme == "internal"
  load_balancer_type = "application"
  security_groups    = [aws_security_group.alb_sg.id]
  subnets            = var.alb_scheme == "internal" ? local.private_subnet_ids : local.public_subnet_ids

  enable_deletion_protection = false

  dynamic "access_logs" {
    for_each = var.alb_access_logs_s3_bucket != "" ? [1] : []
    content {
      bucket  = var.alb_access_logs_s3_bucket
      enabled = true
      prefix  = "${var.project_name}-alb"
    }
  }

  tags = local.common_tags
}

# --- WAF Web ACL Association (conditional) ---

resource "aws_wafv2_web_acl_association" "alb" {
  count        = var.existing_waf_web_acl_arn != "" ? 1 : 0
  resource_arn = aws_lb.main.arn
  web_acl_arn  = var.existing_waf_web_acl_arn
}

# --- Target Groups ---

resource "aws_lb_target_group" "adapter" {
  name                 = "${local.project_name}-adapter"
  port                 = var.gateway_port
  protocol             = "HTTP"
  target_type          = "ip"
  vpc_id               = local.vpc_id
  deregistration_delay = 30

  health_check {
    path                = "/.well-known/oauth-protected-resource"
    port                = "traffic-port"
    healthy_threshold   = 2
    unhealthy_threshold = 3
    interval            = 30
    timeout             = 5
  }

  tags = local.common_tags
}

resource "aws_lb_target_group" "admin_ui" {
  name                 = "${local.project_name}-admin-ui"
  port                 = var.admin_ui_port
  protocol             = "HTTP"
  target_type          = "ip"
  vpc_id               = local.vpc_id
  deregistration_delay = 30

  health_check {
    path                = "/"
    port                = "traffic-port"
    healthy_threshold   = 2
    unhealthy_threshold = 3
    interval            = 30
    timeout             = 5
  }

  tags = local.common_tags
}

# --- ALB Listeners ---

resource "aws_lb_listener" "https" {
  load_balancer_arn = aws_lb.main.arn
  port              = 443
  protocol          = "HTTPS"
  certificate_arn = (
    var.existing_acm_certificate_arn != ""
    ? var.existing_acm_certificate_arn
    : (
      var.dns_provider != "external"
      ? aws_acm_certificate_validation.route53[0].certificate_arn
      : aws_acm_certificate_validation.external[0].certificate_arn
    )
  )
  ssl_policy = "ELBSecurityPolicy-TLS13-1-2-2021-06"

  default_action {
    type = "fixed-response"

    fixed_response {
      content_type = "text/plain"
      message_body = "Not Found"
      status_code  = "404"
    }
  }

  tags = local.common_tags
}

resource "aws_lb_listener" "http" {
  load_balancer_arn = aws_lb.main.arn
  port              = 80
  protocol          = "HTTP"

  default_action {
    type = "redirect"

    redirect {
      port        = "443"
      protocol    = "HTTPS"
      status_code = "HTTP_301"
    }
  }

  tags = local.common_tags
}

# --- Listener Rules ---

resource "aws_lb_listener_rule" "adapter" {
  listener_arn = aws_lb_listener.https.arn
  priority     = 100

  condition {
    host_header {
      values = [var.adapter_hostname]
    }
  }

  action {
    type             = "forward"
    target_group_arn = aws_lb_target_group.adapter.arn
  }

  tags = local.common_tags
}

resource "aws_lb_listener_rule" "admin_ui" {
  listener_arn = aws_lb_listener.https.arn
  priority     = 200

  condition {
    host_header {
      values = [var.admin_hostname]
    }
  }

  action {
    type             = "forward"
    target_group_arn = aws_lb_target_group.admin_ui.arn
  }

  tags = local.common_tags
}

# --- ECS Service: Adapter ---

resource "aws_ecs_service" "adapter" {
  name                              = "adapter"
  cluster                           = aws_ecs_cluster.main.id
  task_definition                   = aws_ecs_task_definition.adapter.arn
  desired_count                     = local.adapter_desired_count
  launch_type                       = "FARGATE"
  platform_version                  = "LATEST"
  health_check_grace_period_seconds = 60
  force_new_deployment              = true

  network_configuration {
    subnets          = local.private_subnet_ids
    security_groups  = [aws_security_group.ecs_tasks_sg.id]
    assign_public_ip = false
  }

  load_balancer {
    target_group_arn = aws_lb_target_group.adapter.arn
    container_name   = "adapter"
    container_port   = var.gateway_port
  }

  service_connect_configuration {
    enabled   = true
    namespace = aws_service_discovery_private_dns_namespace.main.arn

    service {
      port_name      = "adapter-http"
      discovery_name = "adapter"

      client_alias {
        port     = var.gateway_port
        dns_name = "adapter.${local.project_name}.local"
      }
    }
  }

  deployment_circuit_breaker {
    enable   = true
    rollback = true
  }

  tags = local.common_tags
}

# --- Adapter Auto-Scaling (small-prod only) ---

resource "aws_appautoscaling_target" "adapter" {
  count = var.deployment_size == "small-prod" ? 1 : 0

  max_capacity       = 4
  min_capacity       = 2
  resource_id        = "service/${aws_ecs_cluster.main.name}/${aws_ecs_service.adapter.name}"
  scalable_dimension = "ecs:service:DesiredCount"
  service_namespace  = "ecs"
}

resource "aws_appautoscaling_policy" "adapter_cpu" {
  count = var.deployment_size == "small-prod" ? 1 : 0

  name               = "${local.project_name}-adapter-cpu"
  policy_type        = "TargetTrackingScaling"
  resource_id        = aws_appautoscaling_target.adapter[0].resource_id
  scalable_dimension = aws_appautoscaling_target.adapter[0].scalable_dimension
  service_namespace  = aws_appautoscaling_target.adapter[0].service_namespace

  target_tracking_scaling_policy_configuration {
    predefined_metric_specification {
      predefined_metric_type = "ECSServiceAverageCPUUtilization"
    }
    target_value = 70
  }
}

# --- ECS Service: Admin UI ---

resource "aws_ecs_service" "admin_ui" {
  name                              = "admin-ui"
  cluster                           = aws_ecs_cluster.main.id
  task_definition                   = aws_ecs_task_definition.admin_ui.arn
  desired_count                     = 1
  launch_type                       = "FARGATE"
  platform_version                  = "LATEST"
  health_check_grace_period_seconds = 60
  force_new_deployment              = true

  network_configuration {
    subnets          = local.private_subnet_ids
    security_groups  = [aws_security_group.ecs_tasks_sg.id]
    assign_public_ip = false
  }

  load_balancer {
    target_group_arn = aws_lb_target_group.admin_ui.arn
    container_name   = "admin-ui"
    container_port   = var.admin_ui_port
  }

  service_connect_configuration {
    enabled   = true
    namespace = aws_service_discovery_private_dns_namespace.main.arn
  }

  deployment_circuit_breaker {
    enable   = true
    rollback = true
  }

  tags = local.common_tags
}

# =============================================================================
# CodeBuild — Server-Side Image Builds (conditional)
# =============================================================================

resource "aws_s3_bucket" "codebuild_source" {
  count         = var.existing_codebuild_source_bucket == "" && var.enable_codebuild ? 1 : 0
  bucket        = local.codebuild_source_bucket
  force_destroy = true

  tags = local.common_tags
}

resource "aws_s3_bucket_versioning" "codebuild_source" {
  count  = var.existing_codebuild_source_bucket == "" && var.enable_codebuild ? 1 : 0
  bucket = aws_s3_bucket.codebuild_source[0].id

  versioning_configuration {
    status = "Enabled"
  }
}

resource "aws_iam_role" "codebuild" {
  count                = var.enable_codebuild ? 1 : 0
  name                 = local.iam_role_codebuild
  path                 = var.iam_role_path
  permissions_boundary = var.iam_permissions_boundary != "" ? var.iam_permissions_boundary : null

  assume_role_policy = jsonencode({
    Version = "2012-10-17"
    Statement = [
      {
        Effect = "Allow"
        Principal = {
          Service = "codebuild.amazonaws.com"
        }
        Action = "sts:AssumeRole"
      }
    ]
  })

  tags = local.common_tags
}

resource "aws_iam_role_policy" "codebuild" {
  count = var.enable_codebuild ? 1 : 0
  name  = "${local.project_name}-codebuild-policy"
  role  = aws_iam_role.codebuild[0].id

  policy = jsonencode({
    Version = "2012-10-17"
    Statement = [
      {
        Sid      = "ECRAuth"
        Effect   = "Allow"
        Action   = ["ecr:GetAuthorizationToken"]
        Resource = "*"
      },
      {
        Sid    = "ECRPush"
        Effect = "Allow"
        Action = [
          "ecr:BatchCheckLayerAvailability",
          "ecr:PutImage",
          "ecr:InitiateLayerUpload",
          "ecr:UploadLayerPart",
          "ecr:CompleteLayerUpload",
          "ecr:BatchGetImage",
          "ecr:GetDownloadUrlForLayer"
        ]
        Resource = var.byo_ecr_repos ? ["*"] : [
          aws_ecr_repository.adapter[0].arn,
          aws_ecr_repository.admin_ui[0].arn
        ]
      },
      {
        Sid    = "CloudWatchLogs"
        Effect = "Allow"
        Action = [
          "logs:CreateLogGroup",
          "logs:CreateLogStream",
          "logs:PutLogEvents"
        ]
        Resource = "arn:aws:logs:${var.aws_region}:${data.aws_caller_identity.current.account_id}:log-group:/codebuild/${local.project_name}*"
      },
      {
        Sid    = "S3Source"
        Effect = "Allow"
        Action = [
          "s3:GetObject",
          "s3:GetBucketLocation"
        ]
        Resource = [
          "arn:aws:s3:::${local.codebuild_source_bucket}",
          "arn:aws:s3:::${local.codebuild_source_bucket}/*"
        ]
      }
    ]
  })
}

resource "aws_codebuild_project" "image_builder" {
  count        = var.enable_codebuild ? 1 : 0
  name         = "${local.project_name}-image-builder"
  service_role = aws_iam_role.codebuild[0].arn

  source {
    type      = "S3"
    location  = "${local.codebuild_source_bucket}/source.zip"
    buildspec = file("${path.module}/buildspec.yml")
  }

  environment {
    compute_type    = "BUILD_GENERAL1_SMALL"
    image           = "aws/codebuild/amazonlinux2-x86_64-standard:5.0"
    type            = "LINUX_CONTAINER"
    privileged_mode = true

    environment_variable {
      name  = "AWS_ACCOUNT_ID"
      value = data.aws_caller_identity.current.account_id
    }

    environment_variable {
      name  = "AWS_DEFAULT_REGION"
      value = var.aws_region
    }

    environment_variable {
      name  = "ECR_ADAPTER_REPO"
      value = local.ecr_adapter_url
    }

    environment_variable {
      name  = "ECR_ADMIN_UI_REPO"
      value = local.ecr_admin_ui_url
    }
  }

  artifacts {
    type = "NO_ARTIFACTS"
  }

  logs_config {
    cloudwatch_logs {
      group_name  = "/codebuild/${local.project_name}"
      stream_name = "image-build"
    }
  }

  tags = local.common_tags
}

# --- Route53 Alias Records (Tier 1/2 only, skip for internal ALB) ---

resource "aws_route53_record" "adapter" {
  count   = var.dns_provider != "external" && var.alb_scheme != "internal" ? 1 : 0
  zone_id = var.route53_zone_id
  name    = var.adapter_hostname
  type    = "A"

  alias {
    name                   = aws_lb.main.dns_name
    zone_id                = aws_lb.main.zone_id
    evaluate_target_health = true
  }
}

resource "aws_route53_record" "admin_ui" {
  count   = var.dns_provider != "external" && var.alb_scheme != "internal" ? 1 : 0
  zone_id = var.route53_zone_id
  name    = var.admin_hostname
  type    = "A"

  alias {
    name                   = aws_lb.main.dns_name
    zone_id                = aws_lb.main.zone_id
    evaluate_target_health = true
  }
}
