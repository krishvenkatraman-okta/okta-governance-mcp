#!/usr/bin/env bash
set -euo pipefail

# =============================================================
# start.sh — Restart ECS services and RDS after stop.sh
# =============================================================
# Starts RDS, waits for it to be available, then scales ECS
# services back up and runs smoke tests.
# =============================================================

AWS_REGION="${AWS_REGION:-us-east-1}"
CLUSTER_NAME="oktaps-mcp-cluster"
RDS_IDENTIFIER="oktaps-mcp-postgres"
ADAPTER_COUNT="${ADAPTER_COUNT:-1}"

export AWS_PAGER=""

echo "Starting ECS deployment (region: ${AWS_REGION})..."
echo ""

# --- Step 1: Start RDS instance ---
echo "Starting RDS instance..."
aws rds start-db-instance \
  --db-instance-identifier "$RDS_IDENTIFIER" \
  --region "$AWS_REGION" --no-cli-pager >/dev/null 2>&1 \
  && echo "Starting RDS instance (takes ~5 min)..." \
  || echo "⚠ RDS may already be running"

echo "Waiting for RDS to become available..."
aws rds wait db-instance-available \
  --db-instance-identifier "$RDS_IDENTIFIER" \
  --region "$AWS_REGION"
echo "✓ RDS instance available"
echo ""

# --- Step 2: Scale ECS services back up ---
echo "Scaling ECS services up..."
aws ecs update-service --cluster "$CLUSTER_NAME" \
  --service adapter --desired-count "$ADAPTER_COUNT" \
  --region "$AWS_REGION" --no-cli-pager >/dev/null
echo "  ✓ adapter → ${ADAPTER_COUNT}"

aws ecs update-service --cluster "$CLUSTER_NAME" \
  --service admin-ui --desired-count 1 \
  --region "$AWS_REGION" --no-cli-pager >/dev/null
echo "  ✓ admin-ui → 1"

aws ecs update-service --cluster "$CLUSTER_NAME" \
  --service hr-backend --desired-count 1 \
  --region "$AWS_REGION" --no-cli-pager >/dev/null
echo "  ✓ hr-backend → 1"

echo "✓ ECS services scaling up"
echo ""

# --- Step 3: Wait for services to stabilize ---
echo "Waiting for services to stabilize..."
aws ecs wait services-stable --cluster "$CLUSTER_NAME" \
  --services adapter admin-ui hr-backend \
  --region "$AWS_REGION"
echo "✓ All services stable"
echo ""

# --- Step 4: Run smoke tests ---
echo "Running smoke tests..."
bash "$(dirname "$0")/smoke-test.sh"
