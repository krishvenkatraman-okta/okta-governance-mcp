#!/usr/bin/env bash
set -euo pipefail

# =============================================================
# preflight-enterprise.sh — Enterprise compatibility pre-flight
# =============================================================
# Run BEFORE deploy.sh to identify organizational blockers before
# Terraform fails halfway through.
# =============================================================

# ---- Colors ----
if [[ -n "${NO_COLOR:-}" ]] || [[ ! -t 1 ]]; then
  RED='' GREEN='' CYAN='' YELLOW='' BOLD='' NC=''
else
  RED='\033[0;31m'
  GREEN='\033[0;32m'
  CYAN='\033[0;36m'
  YELLOW='\033[0;33m'
  BOLD='\033[1m'
  NC='\033[0m'
fi

info()  { printf "${CYAN}[INFO]${NC}  %b\n" "$*"; }
ok()    { printf "${GREEN}[  OK]${NC}  %b\n" "$*"; }
warn()  { printf "${YELLOW}[WARN]${NC}  %b\n" "$*"; }
die()   { printf "${RED}[FAIL]${NC}  %b\n" "$*" >&2; exit 1; }

AWS_REGION="${AWS_REGION:-us-east-1}"

echo "Enterprise Pre-Flight Checks"
echo "============================"
echo ""
failures=()
warnings=()

# 1. VPC quota
info "Checking VPC quota..."
current_vpcs=$(aws ec2 describe-vpcs --region "$AWS_REGION" \
  --query "length(Vpcs)" --output text)
vpc_quota=$(aws service-quotas get-service-quota \
  --service-code vpc --quota-code L-F678F1CE \
  --region "$AWS_REGION" \
  --query "Quota.Value" --output text 2>/dev/null || echo "5")
echo "  VPCs: ${current_vpcs}/${vpc_quota}"
if (( ${current_vpcs%.*} >= ${vpc_quota%.*} )); then
  if [[ "${TF_VAR_use_existing_vpc:-false}" != "true" ]]; then
    failures+=("VPC quota reached. Set: export TF_VAR_use_existing_vpc=true")
  fi
fi

# 2. EIP quota
info "Checking EIP quota..."
current_eips=$(aws ec2 describe-addresses --region "$AWS_REGION" \
  --query "length(Addresses)" --output text)
eip_quota=$(aws service-quotas get-service-quota \
  --service-code ec2 --quota-code L-0263D0A3 \
  --region "$AWS_REGION" \
  --query "Quota.Value" --output text 2>/dev/null || echo "5")
echo "  Elastic IPs: ${current_eips}/${eip_quota}"
if (( ${current_eips%.*} >= ${eip_quota%.*} )) && [[ "${TF_VAR_use_existing_vpc:-false}" != "true" ]]; then
  failures+=("EIP quota reached. Use BYO-VPC mode.")
fi

# 3. Secrets Manager: test create + tag + untag
echo ""
info "Testing Secrets Manager permissions..."
test_secret="oktaps-mcp-preflight-test-$$-$(date +%s)"
if aws secretsmanager create-secret \
     --name "$test_secret" \
     --secret-string "test" \
     --tags Key=PreflightTest,Value=true \
     --region "$AWS_REGION" --no-cli-pager >/dev/null 2>&1; then
  if aws secretsmanager untag-resource \
       --secret-id "$test_secret" \
       --tag-keys PreflightTest \
       --region "$AWS_REGION" --no-cli-pager >/dev/null 2>&1; then
    ok "Secrets Manager tag/untag: OK"
  else
    warnings+=("Secrets Manager UntagResource denied. Set: export TF_VAR_skip_resource_tagging_on_secrets=true")
  fi
  aws secretsmanager delete-secret \
    --secret-id "$test_secret" \
    --force-delete-without-recovery \
    --region "$AWS_REGION" --no-cli-pager >/dev/null 2>&1 || true
else
  failures+=("secretsmanager:CreateSecret denied. Check SCPs and IAM.")
fi

# 4. ECR tag mutability test
echo ""
info "Testing ECR tag mutability policy..."
test_repo="oktaps-mcp-preflight-test-$$-$(date +%s)"
if aws ecr create-repository \
     --repository-name "$test_repo" \
     --image-tag-mutability MUTABLE \
     --region "$AWS_REGION" --no-cli-pager >/dev/null 2>&1; then
  ok "ECR MUTABLE tags: OK"
  aws ecr delete-repository --repository-name "$test_repo" \
    --region "$AWS_REGION" --force --no-cli-pager >/dev/null 2>&1 || true
else
  warnings+=("ECR MUTABLE tags denied. Set: export TF_VAR_ecr_image_tag_mutability=IMMUTABLE or use: export TF_VAR_byo_ecr_repos=true")
fi

# 5. ACM certificate request test (soft — may fail in enterprise)
echo ""
info "Testing ACM certificate creation..."
if aws acm list-certificates --region "$AWS_REGION" --no-cli-pager >/dev/null 2>&1; then
  ok "ACM API accessible"
else
  warnings+=("ACM API denied. Use: export TF_VAR_existing_acm_certificate_arn=<arn>")
fi

# 6. ALB creation — test describe (soft)
echo ""
info "Testing ALB permissions..."
if aws elbv2 describe-load-balancers --region "$AWS_REGION" --no-cli-pager >/dev/null 2>&1; then
  ok "ELBv2 API accessible"
else
  failures+=("elasticloadbalancing:DescribeLoadBalancers denied.")
fi

# 7. KMS key creation test (soft — don't actually create)
echo ""
info "Testing KMS permissions..."
if aws kms list-keys --limit 1 --region "$AWS_REGION" --no-cli-pager >/dev/null 2>&1; then
  ok "KMS API accessible"
else
  warnings+=("KMS API restricted. Provide existing CMK ARNs via TF_VAR_existing_kms_key_arn_*.")
fi

# 8. IAM role creation test with specified path
echo ""
iam_path="${TF_VAR_iam_role_path:-/}"
info "Testing IAM role creation (path=$iam_path)..."
test_role="oktaps-mcp-preflight-test-$$-$(date +%s)"
if aws iam create-role \
     --role-name "$test_role" \
     --path "$iam_path" \
     --assume-role-policy-document '{
       "Version":"2012-10-17",
       "Statement":[{
         "Effect":"Allow",
         "Principal":{"Service":"ecs-tasks.amazonaws.com"},
         "Action":"sts:AssumeRole"
       }]
     }' --no-cli-pager >/dev/null 2>&1; then
  ok "IAM role creation at $iam_path: OK"
  aws iam delete-role --role-name "$test_role" --no-cli-pager >/dev/null 2>&1 || true
else
  failures+=("iam:CreateRole denied at path '$iam_path'. Check SCPs/permission boundaries.")
fi

# 9. Tag policies check
echo ""
info "Checking for Organization tag policies..."
if aws organizations list-policies --filter TAG_POLICY \
     --no-cli-pager >/dev/null 2>&1; then
  tag_policies=$(aws organizations list-policies --filter TAG_POLICY \
    --query "length(Policies)" --output text 2>/dev/null || echo "0")
  if (( tag_policies > 0 )); then
    warnings+=("Organization has ${tag_policies} tag policies. Set required tags via TF_VAR_additional_tags.")
  fi
else
  echo "  Cannot query Organization policies (not an error — may be cross-account)"
fi

# 10. Internet-facing ALB test
echo ""
info "Checking internet-facing ALB eligibility..."
if [[ "${TF_VAR_alb_scheme:-internet-facing}" == "internet-facing" ]]; then
  echo "  Cannot pre-verify internet-facing ALB SCP — will fail at apply if denied."
  echo "  If it fails: export TF_VAR_alb_scheme=internal + set up alternate ingress."
fi

# Summary
echo ""
echo "============================"
if [[ ${#failures[@]} -eq 0 && ${#warnings[@]} -eq 0 ]]; then
  ok "All pre-flight checks passed"
elif [[ ${#failures[@]} -eq 0 ]]; then
  ok "No blockers found"
  echo ""
  echo "${#warnings[@]} warning(s):"
  for w in "${warnings[@]}"; do
    warn "  $w"
  done
  echo ""
  echo "Warnings are recommendations based on detected policies."
  echo "The deployment may still work; adjust variables as needed."
else
  echo "${#failures[@]} blocker(s) found:"
  for f in "${failures[@]}"; do
    die "  $f"
  done
  if [[ ${#warnings[@]} -gt 0 ]]; then
    echo ""
    echo "${#warnings[@]} warning(s):"
    for w in "${warnings[@]}"; do
      warn "  $w"
    done
  fi
  echo ""
  echo "Fix blockers before running deploy.sh."
  exit 1
fi
