#!/usr/bin/env bash
set -euo pipefail

# =============================================================
# package.sh — Build ECS deployment tarballs
# =============================================================
# Produces one or both of:
#
#   okta-ps-adapter-aws-ecs-${VERSION}.tar.gz         (deploy-only)
#     deploy/aws-ecs + deploy/aws-ecs-examples + deploy/shell-lib.
#     For customers using public ECR images; no source or build
#     context. ./deploy.sh --apply works; --build-from-source dies
#     fast with a message pointing at the source bundle.
#
#   okta-ps-adapter-aws-ecs-source-${VERSION}.tar.gz  (source)
#     Everything above plus the adapter / admin-UI / example-server
#     source, Dockerfiles, requirements, and deploy/migrations. Drop
#     this on top of an existing extract (or use standalone) to
#     enable ./deploy.sh --apply --build-from-source.
# =============================================================

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
REPO_ROOT="$(cd "$SCRIPT_DIR/../.." && pwd)"

# ---- Colors ----
if [[ -n "${NO_COLOR:-}" ]] || [[ ! -t 1 ]]; then
  RED='' GREEN='' YELLOW='' CYAN='' BOLD='' NC=''
else
  RED='\033[0;31m'
  GREEN='\033[0;32m'
  YELLOW='\033[1;33m'
  CYAN='\033[0;36m'
  BOLD='\033[1m'
  NC='\033[0m'
fi

info()  { printf "${CYAN}[INFO]${NC}  %b\n" "$*"; }
ok()    { printf "${GREEN}[  OK]${NC}  %b\n" "$*"; }
warn()  { printf "${YELLOW}[WARN]${NC}  %b\n" "$*" >&2; }
die()   { printf "${RED}[FAIL]${NC}  %b\n" "$*" >&2; exit 1; }

# ---- Defaults ----
VERSION=""
OUTPUT_DIR=""
DRY_RUN=false
BUNDLE="both"   # deploy | source | both

# ---- Parse flags ----
while [[ $# -gt 0 ]]; do
  case "$1" in
    --version)    VERSION="$2"; shift 2 ;;
    --output-dir) OUTPUT_DIR="$2"; shift 2 ;;
    --bundle)     BUNDLE="$2"; shift 2 ;;
    --bundle=*)   BUNDLE="${1#--bundle=}"; shift ;;
    --dry-run)    DRY_RUN=true; shift ;;
    -h|--help)
      cat <<EOF
Usage: package.sh [--bundle=deploy|source|both] [--version VERSION]
                  [--output-dir DIR] [--dry-run]

Builds one or both AWS ECS deployment tarballs.

Options:
  --bundle BUNDLE     deploy | source | both (default: both)
                        deploy  = slim tarball for customers pulling from
                                  public.ecr.aws (default public-image path).
                                  --build-from-source will NOT work from
                                  this bundle.
                        source  = full source tarball including Dockerfile,
                                  adapter source, admin UI, example servers,
                                  and migrations. Supports every deploy.sh
                                  flag including --build-from-source.
                        both    = produce both tarballs.
  --version VERSION   Override version (default: from pyproject.toml)
  --output-dir DIR    Output directory (default: ./dist)
  --dry-run           List files without creating tarball(s)
EOF
      exit 0
      ;;
    *) die "Unknown flag: $1" ;;
  esac
done

case "$BUNDLE" in
  deploy|source|both) ;;
  *) die "--bundle must be one of: deploy, source, both (got: $BUNDLE)" ;;
esac

# Resolve version from pyproject.toml
if [[ -z "$VERSION" ]]; then
  PYPROJECT="$REPO_ROOT/pyproject.toml"
  if [[ -f "$PYPROJECT" ]]; then
    VERSION="$(grep -m1 '^version' "$PYPROJECT" | sed 's/.*= *"\(.*\)"/\1/')"
  fi
  VERSION="${VERSION:-dev}"
fi

OUTPUT_DIR="${OUTPUT_DIR:-$SCRIPT_DIR/dist}"

info "Version:    ${BOLD}${VERSION}${NC}"
info "Bundle(s):  ${BOLD}${BUNDLE}${NC}"
info "Output dir: ${OUTPUT_DIR}"
echo ""

# ---- Verify source files exist ----
[[ -f "$REPO_ROOT/Dockerfile" ]]        || die "Cannot find Dockerfile in $REPO_ROOT"
[[ -d "$REPO_ROOT/okta_agent_proxy" ]]  || die "Cannot find okta_agent_proxy/ in $REPO_ROOT"
[[ -f "$SCRIPT_DIR/deploy.sh" ]]        || die "Cannot find deploy.sh in $SCRIPT_DIR"
[[ -f "$SCRIPT_DIR/main.tf" ]]          || die "Cannot find main.tf in $SCRIPT_DIR"

# =============================================================
# Stage functions
# =============================================================

# Files shared by both bundles: deploy scripts, Terraform, shell-lib,
# LICENSE, and pyproject.toml (deploy.sh reads it for the default tag).
stage_common() {
  local staging="$1"

  info "Staging deploy/aws-ecs scripts and Terraform..."
  local ecs_dir="$staging/deploy/aws-ecs"
  mkdir -p "$ecs_dir"

  for f in deploy.sh build-images.sh build-codebuild.sh buildspec.yml \
           smoke-test.sh stop.sh start.sh \
           deploy-adapter.sh deploy-ui.sh deploy-backend.sh \
           preflight-enterprise.sh \
           main.tf variables.tf outputs.tf \
           .gitignore README.md; do
    [[ -f "$SCRIPT_DIR/$f" ]] && cp "$SCRIPT_DIR/$f" "$ecs_dir/"
  done

  [[ -f "$SCRIPT_DIR/.terraform.lock.hcl" ]] && \
    cp "$SCRIPT_DIR/.terraform.lock.hcl" "$ecs_dir/"

  [[ -d "$SCRIPT_DIR/iam" ]] && cp -r "$SCRIPT_DIR/iam" "$ecs_dir/"

  # Shared shell-lib (db_bootstrap helper sourced by deploy.sh at runtime)
  local shared_src="$REPO_ROOT/deploy/shell-lib"
  [[ -d "$shared_src" ]] || die "Cannot find deploy/shell-lib in $REPO_ROOT (required by deploy.sh)"
  info "Staging deploy/shell-lib..."
  mkdir -p "$staging/deploy/shell-lib"
  cp -r "$shared_src/." "$staging/deploy/shell-lib/"

  # Examples project (Terraform + deploy.sh for hr-server / deploy-server)
  local examples_src="$REPO_ROOT/deploy/aws-ecs-examples"
  if [[ -d "$examples_src" ]]; then
    info "Staging deploy/aws-ecs-examples..."
    local examples_dir="$staging/deploy/aws-ecs-examples"
    mkdir -p "$examples_dir"
    for f in deploy.sh build-images.sh build-codebuild.sh buildspec.yml \
             smoke-test.sh \
             main.tf variables.tf outputs.tf locals.tf providers.tf versions.tf \
             example.tfvars \
             .gitignore README.md; do
      [[ -f "$examples_src/$f" ]] && cp "$examples_src/$f" "$examples_dir/"
    done
    [[ -f "$examples_src/.terraform.lock.hcl" ]] && \
      cp "$examples_src/.terraform.lock.hcl" "$examples_dir/"
    [[ -d "$examples_src/shell-lib" ]] && \
      cp -r "$examples_src/shell-lib" "$examples_dir/"
  fi

  # Raw SQL migrations. Needed by:
  #   - db_bootstrap.sh local-exec fallback (reads deploy/migrations/sql/*)
  #   - RUN_DB_BOOTSTRAP=false DBA handoff Option B (psql -f bootstrap_roles.sql)
  # The cloud-job path doesn't need these on the deploy host (migrations
  # ship inside the adapter image pulled from ECR Public), but shipping
  # them keeps secondary paths working and is cheap (~40 KB).
  local migrations_src="$REPO_ROOT/deploy/migrations"
  [[ -d "$migrations_src" ]] || die "Cannot find deploy/migrations in $REPO_ROOT"
  info "Staging deploy/migrations..."
  mkdir -p "$staging/deploy/migrations"
  cp -r "$migrations_src/." "$staging/deploy/migrations/"

  # LICENSE at tarball root
  cp "$REPO_ROOT/LICENSE" "$staging/"

  # pyproject.toml — deploy.sh grep's 'version = "X.Y.Z"' out of it to
  # resolve the default public-image tag. Tiny, not sensitive, keeps
  # deploy.sh identical across both bundles.
  cp "$REPO_ROOT/pyproject.toml" "$staging/"
}

# Additions for the source bundle: Dockerfile + adapter source + admin UI
# + example servers + migrations + entrypoint.
stage_source() {
  local staging="$1"

  info "Staging adapter source + Docker build context..."
  cp "$REPO_ROOT/Dockerfile"         "$staging/"
  cp "$REPO_ROOT/.dockerignore"      "$staging/"
  cp "$REPO_ROOT/requirements.txt"   "$staging/"
  cp -r "$REPO_ROOT/okta_agent_proxy" "$staging/"
  # (deploy/migrations/ is staged by stage_common — shared by both bundles.)

  # docker-entrypoint.sh (only production script from scripts/)
  info "Staging scripts/docker-entrypoint.sh..."
  mkdir -p "$staging/scripts"
  cp "$REPO_ROOT/scripts/docker-entrypoint.sh" "$staging/scripts/"

  # Admin UI (for admin-ui image build)
  if [[ -d "$REPO_ROOT/okta_agent_proxy_admin_ui" ]]; then
    info "Staging Admin UI source..."
    cp -r "$REPO_ROOT/okta_agent_proxy_admin_ui" "$staging/"
  fi

  # Example backends (for hr-server and deploy-server image builds)
  info "Staging example demo servers..."
  mkdir -p "$staging/examples"
  [[ -d "$REPO_ROOT/examples/01-hr-system" ]] && \
    cp -r "$REPO_ROOT/examples/01-hr-system" "$staging/examples/"
  [[ -d "$REPO_ROOT/examples/05-deploy-server" ]] && \
    cp -r "$REPO_ROOT/examples/05-deploy-server" "$staging/examples/"
}

# Remove dev-only / stateful / sensitive files from the staged tree.
# Runs against the whole staging dir so it's safe for both bundles.
clean_staging() {
  local staging="$1"
  info "Cleaning excluded files..."

  # VCS and CI
  find "$staging" -type d -name ".git"    -exec rm -rf {} + 2>/dev/null || true
  find "$staging" -type d -name ".github" -exec rm -rf {} + 2>/dev/null || true
  find "$staging" -name ".gitignore" -not -path "*/deploy/aws-ecs/.gitignore" \
    -delete 2>/dev/null || true

  # Claude / AI tooling
  find "$staging" -name "CLAUDE.md"             -delete 2>/dev/null || true
  find "$staging" -name "CLAUDE_CONVENTIONS.md" -delete 2>/dev/null || true
  find "$staging" -type d -name ".claude" -exec rm -rf {} + 2>/dev/null || true

  # Tests
  find "$staging" -type d -name "tests" -exec rm -rf {} + 2>/dev/null || true
  find "$staging" -name "pytest.ini"  -delete 2>/dev/null || true
  find "$staging" -name "conftest.py" -delete 2>/dev/null || true
  find "$staging" -type d -name ".pytest_cache" -exec rm -rf {} + 2>/dev/null || true

  # Python cache
  find "$staging" -type d -name "__pycache__" -exec rm -rf {} + 2>/dev/null || true
  find "$staging" -name "*.pyc"     -delete 2>/dev/null || true
  find "$staging" -name "*.pyo"     -delete 2>/dev/null || true
  find "$staging" -name ".coverage" -delete 2>/dev/null || true

  # Node.js build artifacts
  find "$staging" -type d -name "node_modules" -exec rm -rf {} + 2>/dev/null || true
  find "$staging" -type d -name ".next"        -exec rm -rf {} + 2>/dev/null || true

  # Office docs (design notes, not deployment artifacts)
  find "$staging" -name "*.docx" -delete 2>/dev/null || true
  find "$staging" -name "*.pptx" -delete 2>/dev/null || true
  find "$staging" -name "*.xlsx" -delete 2>/dev/null || true

  # Internal development prompts and analysis docs
  find "$staging" -name "*_PROMPTS*.md"  -delete 2>/dev/null || true
  find "$staging" -name "*_ANALYSIS*.md" -delete 2>/dev/null || true
  find "$staging" -name "*ADR_*.md"      -delete 2>/dev/null || true

  # .env files (keep .env.example if present)
  find "$staging" -maxdepth 2 -name ".env" -not -name ".env.*" \
    -delete 2>/dev/null || true

  # Terraform state (should not be packaged)
  find "$staging" -name "*.tfstate"        -delete 2>/dev/null || true
  find "$staging" -name "*.tfstate.backup" -delete 2>/dev/null || true
  find "$staging" -name "tfplan"           -delete 2>/dev/null || true
  find "$staging" -type d -name ".terraform" -exec rm -rf {} + 2>/dev/null || true
  find "$staging" -name ".generated-secrets" -delete 2>/dev/null || true

  # Root-level setup.sh (dev-only Docker Compose)
  rm -f "$staging/setup.sh" 2>/dev/null || true
}

# =============================================================
# Build one tarball
# =============================================================
# Args: $1=kind (deploy|source)
build_bundle() {
  local kind="$1"
  local suffix=""
  [[ "$kind" == "source" ]] && suffix="-source"

  local tarball_base="okta-ps-adapter-aws-ecs${suffix}-${VERSION}"
  local tarball_name="${tarball_base}.tar.gz"
  local staging="/tmp/${tarball_base}"

  echo ""
  info "================================================================"
  info "Building ${BOLD}${kind}${NC} bundle → ${BOLD}${tarball_name}${NC}"
  info "================================================================"

  rm -rf "$staging"
  mkdir -p "$staging"

  stage_common "$staging"
  if [[ "$kind" == "source" ]]; then
    stage_source "$staging"
  fi
  clean_staging "$staging"

  local file_count total_size
  file_count=$(find "$staging" -type f | wc -l | tr -d ' ')
  total_size=$(du -sh "$staging" | cut -f1)
  echo ""
  info "Package contents: ${BOLD}${file_count}${NC} files, ${BOLD}${total_size}${NC}"

  if $DRY_RUN; then
    echo ""
    info "${YELLOW}--dry-run${NC}: listing files (no tarball created)"
    echo ""
    (cd /tmp && find "$tarball_base" -type f | sort)
    echo ""
    info "Total: ${file_count} files, ${total_size}"
    rm -rf "$staging"
    return 0
  fi

  mkdir -p "$OUTPUT_DIR"
  (cd /tmp && tar czf "${OUTPUT_DIR}/${tarball_name}" "$tarball_base")

  local path size checksum
  path="${OUTPUT_DIR}/${tarball_name}"
  size=$(du -h "$path" | cut -f1)
  checksum=$(shasum -a 256 "$path" | cut -d' ' -f1)

  rm -rf "$staging"

  echo ""
  ok "Tarball created: ${BOLD}${path}${NC}"
  printf "  %-12s %s\n" "Files:"      "$file_count"
  printf "  %-12s %s\n" "Unpacked:"   "$total_size"
  printf "  %-12s %s\n" "Compressed:" "$size"
  printf "  %-12s %s\n" "SHA-256:"    "$checksum"

  # Per-bundle extract hint
  echo ""
  echo "  To deploy from this bundle:"
  echo "    tar xzf ${tarball_name}"
  echo "    cd ${tarball_base}/deploy/aws-ecs"
  echo "    export TF_VAR_okta_domain=..."
  if [[ "$kind" == "source" ]]; then
    echo "    ./deploy.sh --apply                   # pull public images (default)"
    echo "    ./deploy.sh --apply --build-from-source   # or build from this tree"
  else
    echo "    ./deploy.sh --apply"
    echo ""
    echo "  Note: this bundle does not include source — --build-from-source"
    echo "        requires the okta-ps-adapter-aws-ecs-source-${VERSION}.tar.gz bundle."
  fi
}

# =============================================================
# Dispatch
# =============================================================
case "$BUNDLE" in
  deploy) build_bundle deploy ;;
  source) build_bundle source ;;
  both)
    build_bundle deploy
    build_bundle source
    ;;
esac

echo ""
ok "Done."
