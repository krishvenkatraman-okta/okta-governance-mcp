#!/usr/bin/env bash
set -euo pipefail

# =============================================================
# deploy-adapter.sh — Quick redeploy of just the adapter
# =============================================================
# Builds a new adapter image, pushes to ECR, and forces a new
# ECS service deployment. Run from the deploy/aws-ecs/ directory.
# ~2-3 minutes for a full rebuild + deploy cycle.
# =============================================================

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
REPO_ROOT="$(cd "$SCRIPT_DIR/../.." && pwd)"

# ---- Colors ----
if [[ -n "${NO_COLOR:-}" ]] || [[ ! -t 1 ]]; then
  RED='' GREEN='' CYAN='' YELLOW='' NC=''
else
  RED='\033[0;31m'
  GREEN='\033[0;32m'
  CYAN='\033[0;36m'
  YELLOW='\033[1;33m'
  NC='\033[0m'
fi

info() { printf "${CYAN}[INFO]${NC}  %s\n" "$*"; }
ok()   { printf "${GREEN}[  OK]${NC}  %s\n" "$*"; }
warn() { printf "${YELLOW}[WARN]${NC}  %s\n" "$*" >&2; }
die()  { printf "${RED}[FAIL]${NC}  %s\n" "$*" >&2; exit 1; }

# ---- Parse args (P15) ----
# Flag aliasing: --skip-migrate ≡ --no-bootstrap, both ≡ RUN_DB_BOOTSTRAP=false
SKIP_MIGRATE=false
while [[ $# -gt 0 ]]; do
  case "$1" in
    --skip-migrate|--no-bootstrap) SKIP_MIGRATE=true; shift ;;
    -h|--help)
      echo "Usage: ./deploy-adapter.sh [--skip-migrate]"
      echo ""
      echo "Per-revision adapter redeploy. Builds a new image, pushes to ECR,"
      echo "runs any pending DB migrations, then forces a new ECS deployment."
      echo ""
      echo "  --skip-migrate, --no-bootstrap"
      echo "      Skip the bootstrap step (prints an operator handoff block)."
      echo "      Equivalent to RUN_DB_BOOTSTRAP=false."
      exit 0
      ;;
    *) die "Unknown argument: $1. Use --help for usage." ;;
  esac
done
if [[ "${RUN_DB_BOOTSTRAP:-true}" != "true" ]]; then
  SKIP_MIGRATE=true
fi

# ---- Required env vars ----
AWS_REGION="${AWS_REGION:-us-east-1}"
AWS_ACCOUNT_ID="${AWS_ACCOUNT_ID:-$(aws sts get-caller-identity --query Account --output text)}"
ECR_REGISTRY="${AWS_ACCOUNT_ID}.dkr.ecr.${AWS_REGION}.amazonaws.com"
CLUSTER_NAME="${CLUSTER_NAME:-oktaps-mcp-cluster}"
SERVICE_NAME="adapter"

# Build tag with timestamp for traceability
BUILD_TAG="build-$(date +%Y%m%d-%H%M%S)"

# ---- Cross-cloud bootstrap helper (P15) ----
# shellcheck disable=SC1091
source "$SCRIPT_DIR/../shell-lib/db_bootstrap.sh"

echo ""
info "Redeploying adapter (${BUILD_TAG})"
echo ""

# ---- Authenticate to ECR ----
info "Authenticating to ECR..."
aws ecr get-login-password --region "$AWS_REGION" | \
  docker login --username AWS --password-stdin "$ECR_REGISTRY" 2>/dev/null
ok "ECR authentication successful"

# ---- Build and push ----
info "Building adapter image ($BUILD_TAG)..."
docker buildx build \
  --platform linux/amd64 \
  -t "${ECR_REGISTRY}/oktaps-mcp-adapter:${BUILD_TAG}" \
  -t "${ECR_REGISTRY}/oktaps-mcp-adapter:latest" \
  -f "${REPO_ROOT}/Dockerfile" \
  --push \
  "${REPO_ROOT}"
ok "Image pushed: oktaps-mcp-adapter:${BUILD_TAG}"

# ---- Run DB bootstrap before rolling the service (P15) ----
# New releases can ship new migrations. The adapter fails fast on a
# stale schema, so bootstrap must succeed before the service is rolled.
info "Checking / applying DB bootstrap..."
cd "$SCRIPT_DIR"

task_family=$(terraform output -raw migrate_task_definition_family 2>/dev/null || echo "oktaps-mcp-migrate")
task_def_arn=$(aws ecs describe-task-definition \
    --task-definition "$task_family" --region "$AWS_REGION" \
    --query 'taskDefinition.taskDefinitionArn' --output text --no-cli-pager 2>/dev/null || echo "")
subnets_json=$(terraform output -json private_subnet_ids 2>/dev/null || echo "[]")
sg_id=$(terraform output -raw ecs_tasks_sg_id 2>/dev/null || echo "")
use_iam=$(terraform output -raw use_rds_iam 2>/dev/null || echo "true")
db_secret_arn=$(terraform output -raw secrets_db_arn 2>/dev/null || echo "")
db_name=$(terraform output -raw rds_db_name 2>/dev/null || echo "gateway_db")
subnets=$(python3 -c "import sys,json; print(','.join(json.load(sys.stdin)))" <<<"$subnets_json")

export PLATFORM=aws
export AWS_REGION
export ECS_CLUSTER="$CLUSTER_NAME"
export MIGRATE_TASK_DEF_ARN="$task_def_arn"
export ECS_SUBNETS="$subnets"
export ECS_SECURITY_GROUPS="$sg_id"
export DB_MASTER_SECRET_ARN="$db_secret_arn"
export USE_RDS_IAM="$use_iam"
export DB_HOST="$(terraform output -raw rds_endpoint 2>/dev/null | cut -d: -f1 || echo "")"
export DB_PORT=5432
export DB_NAME="$db_name"
export DB_OWNER_ROLE="${DB_OWNER_ROLE:-okta_adapter_owner}"
export DB_APP_ROLE="${DB_APP_ROLE:-okta_adapter_app}"
export MIGRATIONS_DIR="$SCRIPT_DIR/../migrations/sql"
if [[ "$SKIP_MIGRATE" == "true" ]]; then
  export RUN_DB_BOOTSTRAP=false
fi

db_bootstrap_run

# ---- Force new deployment ----
info "Forcing new ECS deployment..."
aws ecs update-service \
  --cluster "$CLUSTER_NAME" \
  --service "$SERVICE_NAME" \
  --force-new-deployment \
  --region "$AWS_REGION" \
  --no-cli-pager >/dev/null
ok "Deployment triggered"

# ---- Wait for service to stabilize ----
info "Waiting for service to stabilize..."
if aws ecs wait services-stable \
     --cluster "$CLUSTER_NAME" \
     --services "$SERVICE_NAME" \
     --region "$AWS_REGION" 2>/dev/null; then
  ok "Service stable"
else
  warn "Stabilization timed out. Check: aws ecs describe-services --cluster $CLUSTER_NAME --services $SERVICE_NAME --region $AWS_REGION"
fi

# ---- Health check ----
ADAPTER_HOSTNAME="${TF_VAR_adapter_hostname:-}"
if [[ -n "$ADAPTER_HOSTNAME" ]]; then
  info "Running health check..."
  elapsed=0
  while (( elapsed < 120 )); do
    if curl -sf "https://$ADAPTER_HOSTNAME/health" >/dev/null 2>&1; then
      ok "Adapter healthy after ${elapsed}s"
      echo ""
      ok "Adapter redeployed: ${BUILD_TAG}"
      exit 0
    fi
    printf "."
    sleep 5
    elapsed=$((elapsed + 5))
  done
  echo ""
  die "Health check timed out. Check: aws ecs describe-services --cluster $CLUSTER_NAME --services $SERVICE_NAME --region $AWS_REGION"
else
  ok "No TF_VAR_adapter_hostname set — skipping health check"
  echo ""
  ok "Adapter redeployed: ${BUILD_TAG}"
fi
