#!/usr/bin/env bash
set -euo pipefail

# =============================================================
# teardown.sh — Remove all AWS resources created by awsetup.sh
# =============================================================
# Reads .awsetup.state and deletes resources in reverse
# dependency order. Handles already-deleted resources gracefully.
# =============================================================

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
cd "$SCRIPT_DIR"

# Source shared functions
source "$SCRIPT_DIR/shell-lib/common.sh"

# Disable AWS CLI pager (prevents `less` from blocking automation)
export AWS_PAGER=""

# ---- Defaults ----
SKIP_CONFIRM=false
KEEP_STACK=false
KEEP_CERT=false
DRY_RUN=false

# ---- Parse flags ----
while [[ $# -gt 0 ]]; do
  case "$1" in
    --profile)    export AWS_PROFILE="$2"; shift 2 ;;
    --yes)        SKIP_CONFIRM=true; shift ;;
    --keep-stack) KEEP_STACK=true; shift ;;
    --keep-cert)  KEEP_CERT=true; shift ;;
    --dry-run)    DRY_RUN=true; shift ;;
    -h|--help)
      cat <<'USAGE'
Usage: teardown.sh [OPTIONS]

Options:
  --profile PROFILE AWS CLI profile to use (default: current profile)
  --yes             Skip confirmation prompt
  --keep-stack      Only remove AWS resources, keep Docker running
  --keep-cert       Don't delete ACM certificate (reuse on next deploy)
  --dry-run         Show what would be deleted without doing it
  --help            Show this help
USAGE
      exit 0
      ;;
    *) die "Unknown flag: $1 (use --help)" ;;
  esac
done

# ---- Load state ----
[[ -f "$SCRIPT_DIR/.awsetup.state" ]] || die "No deployment state found. Nothing to tear down."

load_state

AWS_REGION="$(get_state AWS_REGION || true)"
EC2_SG_ID="$(get_state EC2_SG_ID || true)"
ALB_ARN="$(get_state ALB_ARN || true)"
ALB_DNS="$(get_state ALB_DNS || true)"
ALB_SG_ID="$(get_state ALB_SG_ID || true)"
HTTPS_LISTENER_ARN="$(get_state HTTPS_LISTENER_ARN || true)"
ADAPTER_TG_ARN="$(get_state ADAPTER_TG_ARN || true)"
ADMIN_TG_ARN="$(get_state ADMIN_TG_ARN || true)"
ACM_CERT_ARN="$(get_state ACM_CERT_ARN || true)"
DOMAIN="$(get_state DOMAIN || true)"
MCP_HOSTNAME="$(get_state MCP_HOSTNAME || true)"
ADMIN_HOSTNAME="$(get_state ADMIN_HOSTNAME || true)"

# Counters
DELETED=0
SKIPPED=0

# ---- Helper: track result ----
mark_deleted() { printf "  ${GREEN}✓${NC} Deleted %s\n" "$*"; DELETED=$(( DELETED + 1 )); }
mark_skipped() { printf "  ${CYAN}→${NC} Skipped %s\n" "$*"; SKIPPED=$(( SKIPPED + 1 )); }

# ---- Summary of what will be deleted ----
echo ""
printf "${RED}${BOLD}Teardown — Okta MCP Adapter AWS Resources${NC}\n"
echo ""
printf "  ${BOLD}This will delete:${NC}\n"

[[ -n "$ALB_ARN" ]]        && printf "    • ALB: ${BOLD}okta-mcp-alb${NC} (%s)\n" "${ALB_DNS:-unknown}"
[[ -n "$ADAPTER_TG_ARN" ]] && printf "    • Target group: ${BOLD}okta-mcp-adapter-tg${NC}\n"
[[ -n "$ADMIN_TG_ARN" ]]   && printf "    • Target group: ${BOLD}okta-mcp-admin-ui-tg${NC}\n"
[[ -n "$ALB_SG_ID" ]]      && printf "    • Security group: ${BOLD}okta-mcp-alb-sg${NC} (%s)\n" "$ALB_SG_ID"
if [[ -n "$EC2_SG_ID" && -n "$ALB_SG_ID" ]]; then
  printf "    • EC2 SG ingress rules (8000, 3001 from ALB SG)\n"
fi
if [[ -n "$ACM_CERT_ARN" ]]; then
  if $KEEP_CERT; then
    printf "    • ACM certificate: ${YELLOW}kept${NC} (--keep-cert)\n"
  else
    printf "    • ACM certificate: ${BOLD}*.%s${NC}\n" "${DOMAIN:-unknown}"
  fi
fi
if $KEEP_STACK; then
  printf "    • Docker stack: ${YELLOW}kept${NC} (--keep-stack)\n"
else
  printf "    • Docker stack (docker compose down -v)\n"
fi

printf "    • State file: .awsetup.state\n"
echo ""

# ---- Dry run exits here ----
if $DRY_RUN; then
  info "Dry run — no resources were modified."
  exit 0
fi

# ---- Confirmation ----
if ! $SKIP_CONFIRM; then
  printf "${RED}${BOLD}Type YES to confirm teardown:${NC} "
  local_reply=""
  read -r local_reply
  [[ "$local_reply" == "YES" ]] || die "Aborted."
fi

echo ""
info "Starting teardown..."
echo ""

# ============================================================
# a. Delete ALB listener rules (all non-default)
# ============================================================
if [[ -n "$HTTPS_LISTENER_ARN" && -n "$AWS_REGION" ]]; then
  info "Removing listener rules..."

  rule_arns=$(aws elbv2 describe-rules \
    --region "$AWS_REGION" \
    --listener-arn "$HTTPS_LISTENER_ARN" \
    --query 'Rules[?!IsDefault].RuleArn' \
    --output text 2>/dev/null || true)

  if [[ -n "$rule_arns" ]]; then
    for rule_arn in $rule_arns; do
      aws elbv2 delete-rule \
        --region "$AWS_REGION" \
        --rule-arn "$rule_arn" 2>/dev/null \
        && mark_deleted "listener rule ${rule_arn##*/}" \
        || mark_skipped "listener rule ${rule_arn##*/} (already deleted or error)"
    done
  else
    mark_skipped "listener rules (none found)"
  fi
else
  mark_skipped "listener rules (no listener ARN in state)"
fi

# ============================================================
# b. Delete HTTPS and HTTP listeners
# ============================================================
if [[ -n "$ALB_ARN" && -n "$AWS_REGION" ]]; then
  info "Removing listeners..."

  listener_arns=$(aws elbv2 describe-listeners \
    --region "$AWS_REGION" \
    --load-balancer-arn "$ALB_ARN" \
    --query 'Listeners[*].ListenerArn' \
    --output text 2>/dev/null || true)

  if [[ -n "$listener_arns" ]]; then
    for listener_arn in $listener_arns; do
      local_port=$(aws elbv2 describe-listeners \
        --region "$AWS_REGION" \
        --listener-arns "$listener_arn" \
        --query 'Listeners[0].Port' \
        --output text 2>/dev/null || echo "?")

      aws elbv2 delete-listener \
        --region "$AWS_REGION" \
        --listener-arn "$listener_arn" 2>/dev/null \
        && mark_deleted "listener port ${local_port}" \
        || mark_skipped "listener port ${local_port} (already deleted or error)"
    done
  else
    mark_skipped "listeners (none found)"
  fi
else
  mark_skipped "listeners (no ALB ARN in state)"
fi

# ============================================================
# c. Delete ALB
# ============================================================
if [[ -n "$ALB_ARN" && -n "$AWS_REGION" ]]; then
  info "Deleting ALB..."

  if aws elbv2 delete-load-balancer \
    --region "$AWS_REGION" \
    --load-balancer-arn "$ALB_ARN" 2>/dev/null; then
    mark_deleted "ALB okta-mcp-alb (${ALB_DNS:-})"

    # Wait for ALB to fully delete before removing dependent resources
    info "Waiting for ALB deletion to complete (up to 60s)..."
    elapsed=0
    while [[ $elapsed -lt 60 ]]; do
      alb_exists=$(aws elbv2 describe-load-balancers \
        --region "$AWS_REGION" \
        --load-balancer-arns "$ALB_ARN" \
        --query 'LoadBalancers[0].State.Code' \
        --output text 2>/dev/null || echo "gone")

      [[ "$alb_exists" == "gone" ]] && break
      sleep 5
      elapsed=$(( elapsed + 5 ))
    done
  else
    mark_skipped "ALB (already deleted or error)"
  fi
else
  mark_skipped "ALB (not found in state)"
fi

# ============================================================
# d. Delete target groups
# ============================================================
info "Deleting target groups..."

if [[ -n "$ADAPTER_TG_ARN" && -n "$AWS_REGION" ]]; then
  aws elbv2 delete-target-group \
    --region "$AWS_REGION" \
    --target-group-arn "$ADAPTER_TG_ARN" 2>/dev/null \
    && mark_deleted "target group okta-mcp-adapter-tg" \
    || mark_skipped "target group okta-mcp-adapter-tg (already deleted or error)"
else
  mark_skipped "adapter target group (not found in state)"
fi

if [[ -n "$ADMIN_TG_ARN" && -n "$AWS_REGION" ]]; then
  aws elbv2 delete-target-group \
    --region "$AWS_REGION" \
    --target-group-arn "$ADMIN_TG_ARN" 2>/dev/null \
    && mark_deleted "target group okta-mcp-admin-ui-tg" \
    || mark_skipped "target group okta-mcp-admin-ui-tg (already deleted or error)"
else
  mark_skipped "admin target group (not found in state)"
fi

# ============================================================
# e. Revoke EC2 SG ingress rules (8000, 3001 from ALB SG)
# ============================================================
if [[ -n "$EC2_SG_ID" && -n "$ALB_SG_ID" && -n "$AWS_REGION" ]]; then
  info "Revoking EC2 security group ingress rules..."

  aws ec2 revoke-security-group-ingress \
    --region "$AWS_REGION" \
    --group-id "$EC2_SG_ID" \
    --protocol tcp --port 8000 \
    --source-group "$ALB_SG_ID" 2>/dev/null \
    && mark_deleted "EC2 SG rule: 8000/tcp from ALB" \
    || mark_skipped "EC2 SG rule: 8000/tcp (already removed or error)"

  aws ec2 revoke-security-group-ingress \
    --region "$AWS_REGION" \
    --group-id "$EC2_SG_ID" \
    --protocol tcp --port 3001 \
    --source-group "$ALB_SG_ID" 2>/dev/null \
    && mark_deleted "EC2 SG rule: 3001/tcp from ALB" \
    || mark_skipped "EC2 SG rule: 3001/tcp (already removed or error)"
else
  mark_skipped "EC2 SG ingress rules (missing SG IDs in state)"
fi

# ============================================================
# f. Delete ALB security group
# ============================================================
if [[ -n "$ALB_SG_ID" && -n "$AWS_REGION" ]]; then
  info "Deleting ALB security group..."

  # Retry a few times — the SG may still be referenced briefly after ALB deletion
  sg_deleted=false
  for attempt in 1 2 3; do
    if aws ec2 delete-security-group \
      --region "$AWS_REGION" \
      --group-id "$ALB_SG_ID" 2>/dev/null; then
      sg_deleted=true
      break
    fi
    [[ $attempt -lt 3 ]] && sleep 10
  done

  if $sg_deleted; then
    mark_deleted "security group okta-mcp-alb-sg (${ALB_SG_ID})"
  else
    mark_skipped "security group okta-mcp-alb-sg (dependency may still exist — delete manually)"
  fi
else
  mark_skipped "ALB security group (not found in state)"
fi

# ============================================================
# g. Delete ACM certificate
# ============================================================
if [[ -n "$ACM_CERT_ARN" && -n "$AWS_REGION" ]]; then
  if $KEEP_CERT; then
    mark_skipped "ACM certificate (--keep-cert)"
  else
    info "Deleting ACM certificate..."

    aws acm delete-certificate \
      --region "$AWS_REGION" \
      --certificate-arn "$ACM_CERT_ARN" 2>/dev/null \
      && mark_deleted "ACM certificate *.${DOMAIN:-unknown}" \
      || mark_skipped "ACM certificate (already deleted, in use, or error)"
  fi
else
  mark_skipped "ACM certificate (not found in state)"
fi

# ============================================================
# h. Docker compose down
# ============================================================
if $KEEP_STACK; then
  mark_skipped "Docker stack (--keep-stack)"
else
  info "Stopping Docker stack..."

  if docker compose down -v 2>/dev/null; then
    mark_deleted "Docker stack (containers + volumes)"
  else
    mark_skipped "Docker stack (not running or error)"
  fi
fi

# ============================================================
# Clean up state file
# ============================================================
echo ""
info "Removing state file..."
rm -f "$SCRIPT_DIR/.awsetup.state"
mark_deleted ".awsetup.state"

# ============================================================
# Summary
# ============================================================
echo ""
printf "${GREEN}${BOLD}Teardown complete.${NC} ${BOLD}%d${NC} deleted, ${BOLD}%d${NC} skipped.\n" "$DELETED" "$SKIPPED"
echo ""

# DNS reminder
if [[ -n "$DOMAIN" ]]; then
  printf "  ${YELLOW}Remember to remove DNS CNAME records for:${NC}\n"
  [[ -n "$MCP_HOSTNAME" ]]   && printf "    • %s\n" "$MCP_HOSTNAME"
  [[ -n "$ADMIN_HOSTNAME" ]] && printf "    • %s\n" "$ADMIN_HOSTNAME"
  if ! $KEEP_CERT; then
    printf "    • ACM validation CNAME (if certificate was deleted)\n"
  fi
  echo ""
fi
