# Okta MCP Adapter — AWS EC2 Deployment

Deploy the Okta MCP Adapter on an EC2 instance with HTTPS via Application Load Balancer.

## Prerequisites

- **EC2 instance** — Amazon Linux 2023 or Ubuntu 22.04+, t3.medium or larger (x86_64) or t4g.medium or larger (ARM/Graviton)
- **Docker** + **Docker Compose** plugin installed
- **AWS CLI v2** configured with credentials that have permissions for:
  - EC2 (security groups), ELBv2 (ALB, target groups, listeners), ACM (certificates)
- **Domain name** you control (for HTTPS — e.g., `yourdomain.com`)
- **Okta org** (the adapter uses the Org authorization server by default)

## Quick Start

```bash
# Run all 3 phases in sequence
./awsetup.sh

# Or run phases individually for staged rollout
./awsetup.sh --phase 1    # Local Docker stack
./awsetup.sh --phase 2    # ALB + ACM certificate
./awsetup.sh --phase 3    # Routing, verification, cutover
```

## Architecture / Platform

Docker images must match the EC2 instance architecture. Set `DOCKER_PLATFORM` in your `.env` file before building:

| Instance type | Architecture | `DOCKER_PLATFORM` value |
|---------------|-------------|------------------------|
| t3, m5, c5, r5, etc. | x86_64 | `linux/amd64` (default) |
| t4g, m7g, c7g, r7g, etc. | ARM64 (Graviton) | `linux/arm64` |

If you see `exec format error` during `docker compose build` or at container startup, this value doesn't match your instance architecture. Fix it and rebuild with `docker compose build --no-cache`.

## Phase Overview

### Phase 1: Local Stack

Validates prerequisites, detects EC2 metadata, collects your public domain
and subdomain prefixes (so `GATEWAY_BASE_URL` is RFC 8414-compliant from the
start), collects Okta configuration for the adapter and the deploy example
backend, generates secrets, builds Docker images, starts the stack, and runs
smoke tests.

After Phase 1 the adapter is running on `localhost:8000` with the Admin UI on
`localhost:3001`, but the OAuth discovery doc advertises the final public
issuer `https://mcp.<your-domain>` — public traffic will only reach the
adapter after Phase 2 and Phase 3 complete.

### Phase 2: ALB + ACM + HTTPS

Requests a wildcard ACM certificate for the domain collected in Phase 1,
creates an ALB security group, target groups, the ALB itself, and HTTPS/HTTP
listeners.

**Requires a DNS action** — you must add an ACM validation CNAME record (see [DNS Configuration](#dns-configuration)).

### Phase 3: Routing + Verification

Verifies listener routing rules, enables sticky sessions for MCP streaming,
updates the adapter to use HTTPS URLs, prints DNS instructions for your ALB
hostnames, and runs end-to-end verification.

**Requires a DNS action** — you must add CNAME records for your MCP and Admin hostnames (see [DNS Configuration](#dns-configuration)).

**Requires a Okta OIDC Application** - The Adapter Admin UI requires an Okta OIDC web application.

| Field | Value |
|-------|-------|
| **App integration name** | Okta MCP Adapter Admin UI |
| **Grant type** | Authorization Code, Refresh Token |
| **Sign-in redirect URIs** | `http://localhost:3001/api/auth/callback/okta` (for local dev)<br/>`https://your-domain.com/api/auth/callback/okta` (for production) |
| **Sign-out redirect URIs** | `http://localhost:3001/login` (for local dev)<br/>`https://your-domain.com/login` (for production) |
| **Controlled access** | Choose based on your requirements (Highly recommended to leverage Okta Group) |

7. Click **Save**
8. Note the **Client ID** and **Client secret** from the application page

***Enable OAuth for Okta Scopes (Required for AI Agent Import)***

The Admin UI's OIDC app must be granted Okta Management API scopes so the admin's token can call Okta's AI Agent APIs directly.

***Why This Is Needed***

When an admin imports agents, the adapter forwards the admin's own Okta access token to Okta's AI Agent Management APIs. The OIDC app must be authorized to request these scopes, and the admin must have an Okta role that permits them.

***Grant Okta API Scopes***

1. In **Okta Admin Console** → **Applications > Applications**
2. Click on your **Admin UI OIDC application**
3. Go to the **Okta API Scopes** tab
4. Click **Grant** next to each:

   | Scope | Purpose |
   |-------|---------|
   | `okta.aiAgents.read` | List and read AI Agent details |
   | `okta.aiAgents.manage` | Import and sync operations |
   | `okta.apps.read` | Read linked OIDC app details |
   | `okta.groups.read` | Read group information |
   | `okta.authorizationServers.read` | Match connections to adapter backends |

5. Verify each shows **Granted** (green checkmark)

***Verify Admin User Role***

1. Navigate to **Security > Administrators**
2. Verify the admin user has **Super Administrator** or a custom role with: Manage AI agents, View applications, View groups, View authorization servers

---

## DNS Configuration

The wizard pauses at two points and asks you to create DNS records.
How you do this depends on where your domain's DNS is managed.

### DNS Record #1: ACM Certificate Validation (Phase 2)

ACM requires a CNAME record to prove you own the domain. Phase 2 prints
the exact Name and Value. Example:

```
Name:  _abc123.oktaproserv.com.
Type:  CNAME
Value: _def456.acm-validations.aws.
```

### DNS Records #2 and #3: ALB Hostnames (Phase 3)

Point your MCP and Admin hostnames to the ALB. Phase 3 prints the exact values.
Example:

```
mcp.oktaproserv.com.    CNAME  okta-mcp-alb-123456.us-east-1.elb.amazonaws.com.
admin.oktaproserv.com.  CNAME  okta-mcp-alb-123456.us-east-1.elb.amazonaws.com.
```

**Recommended TTL:** 300 seconds.

---

### Option A: Route 53 (AWS-Managed Domain)

If your domain uses Route 53, you can add records via the AWS CLI.

#### Find your Hosted Zone ID

```bash
aws route53 list-hosted-zones-by-name \
  --dns-name oktaproserv.com \
  --query 'HostedZones[0].Id' --output text
# Returns: /hostedzone/Z1234567890
```

#### Add the ACM validation CNAME

Replace the values with what Phase 2 printed:

```bash
aws route53 change-resource-record-sets \
  --hosted-zone-id Z1234567890 \
  --change-batch '{
    "Changes": [{
      "Action": "UPSERT",
      "ResourceRecordSet": {
        "Name": "_abc123.oktaproserv.com.",
        "Type": "CNAME",
        "TTL": 300,
        "ResourceRecords": [{"Value": "_def456.acm-validations.aws."}]
      }
    }]
  }'
```

#### Add ALB hostname CNAMEs

Both records in one call:

```bash
aws route53 change-resource-record-sets \
  --hosted-zone-id Z1234567890 \
  --change-batch '{
    "Changes": [
      {
        "Action": "UPSERT",
        "ResourceRecordSet": {
          "Name": "mcp.oktaproserv.com.",
          "Type": "CNAME",
          "TTL": 300,
          "ResourceRecords": [{"Value": "okta-mcp-alb-123456.us-east-1.elb.amazonaws.com."}]
        }
      },
      {
        "Action": "UPSERT",
        "ResourceRecordSet": {
          "Name": "admin.oktaproserv.com.",
          "Type": "CNAME",
          "TTL": 300,
          "ResourceRecords": [{"Value": "okta-mcp-alb-123456.us-east-1.elb.amazonaws.com."}]
        }
      }
    ]
  }'
```

> **ALIAS records:** If `mcp` or `mcp_admin` is the zone apex (bare domain), CNAME records
> are not allowed by DNS standards. Use a Route 53 ALIAS record instead, pointing to
> the ALB with its hosted zone ID (printed by `./status.sh` as `ALB_ZONE_ID`).

---

### Option B: External DNS Provider (Cloudflare, GoDaddy, etc.)

Log in to your DNS provider's management console and add the records manually.

#### ACM Validation Record

| Name | Type | Value | TTL |
|------|------|-------|-----|
| `_abc123.oktaproserv.com` | CNAME | `_def456.acm-validations.aws` | 300 |

#### ALB Hostname Records

| Name | Type | Value | TTL |
|------|------|-------|-----|
| `mcp.oktaproserv.com` | CNAME | `okta-mcp-alb-123456.us-east-1.elb.amazonaws.com` | 300 |
| `admin.oktaproserv.com` | CNAME | `okta-mcp-alb-123456.us-east-1.elb.amazonaws.com` | 300 |

#### Cloudflare-specific notes

- **ACM validation:** Set the proxy toggle to **DNS only** (grey cloud) for the
  `_abc123` validation record. ACM needs to resolve the CNAME directly — Cloudflare's
  proxy will prevent validation.
- **ALB hostnames:** You may use proxied mode (orange cloud) for `mcp.*` and `admin.*`
  after the certificate is issued, but DNS-only mode is simpler and avoids
  double-TLS overhead.

---

### DNS Verification

After adding records, verify they resolve:

```bash
# Check CNAME resolution
dig +short mcp.oktaproserv.com CNAME
# Expected: okta-mcp-alb-123456.us-east-1.elb.amazonaws.com.

# Alternative using nslookup
nslookup mcp.oktaproserv.com
```

#### Common issues

| Issue | Cause | Fix |
|-------|-------|-----|
| CNAME not resolving | Propagation delay | Wait 5-60 min (up to 48h for some registrars) |
| ACM stuck in PENDING_VALIDATION | Validation CNAME not added or not resolving | Verify the record exists: `dig +short _abc123.domain.com CNAME` |
| Cloudflare blocks ACM validation | Proxy mode enabled on validation record | Switch to DNS-only (grey cloud) |
| CNAME at zone apex rejected | DNS standard prohibits CNAME at apex | Use a subdomain (e.g., `mcp.domain.com`) or Route 53 ALIAS |

---

### DNS Cleanup (After Teardown)

`./teardown.sh` removes AWS resources but cannot delete your DNS records.
Remove them manually after teardown.

#### Route 53

```bash
# Delete ALB hostname records
aws route53 change-resource-record-sets \
  --hosted-zone-id Z1234567890 \
  --change-batch '{
    "Changes": [
      {"Action": "DELETE", "ResourceRecordSet": {
        "Name": "mcp.oktaproserv.com.", "Type": "CNAME", "TTL": 300,
        "ResourceRecords": [{"Value": "okta-mcp-alb-123456.us-east-1.elb.amazonaws.com."}]
      }},
      {"Action": "DELETE", "ResourceRecordSet": {
        "Name": "admin.oktaproserv.com.", "Type": "CNAME", "TTL": 300,
        "ResourceRecords": [{"Value": "okta-mcp-alb-123456.us-east-1.elb.amazonaws.com."}]
      }}
    ]
  }'

# Delete ACM validation CNAME (if certificate was deleted)
aws route53 change-resource-record-sets \
  --hosted-zone-id Z1234567890 \
  --change-batch '{
    "Changes": [{"Action": "DELETE", "ResourceRecordSet": {
      "Name": "_abc123.oktaproserv.com.", "Type": "CNAME", "TTL": 300,
      "ResourceRecords": [{"Value": "_def456.acm-validations.aws."}]
    }}]
  }'
```

#### External DNS

Remove the three CNAME records from your provider's console:
- `_abc123.oktaproserv.com` (ACM validation — only if you deleted the certificate)
- `mcp.oktaproserv.com`
- `admin.oktaproserv.com`

---

## Command Reference

### awsetup.sh

| Flag | Description |
|------|-------------|
| `--phase 1\|2\|3\|all` | Run a specific phase (default: `all`) |
| `--profile PROFILE` | AWS CLI profile to use (default: current profile) |
| `--non-interactive` | Use values from `.env` and `.awsetup.state`, never prompt |
| `--skip-build` | Skip `docker compose build` (use existing images) |
| `--with-observability` | Also start Grafana + Loki + Promtail |

### teardown.sh

| Flag | Description |
|------|-------------|
| `--profile PROFILE` | AWS CLI profile to use (default: current profile) |
| `--yes` | Skip confirmation prompt |
| `--keep-stack` | Only remove AWS resources, keep Docker running |
| `--keep-cert` | Don't delete ACM certificate (reuse on next deploy) |
| `--dry-run` | Show what would be deleted without doing it |

### status.sh

| Flag | Description |
|------|-------------|
| `--profile PROFILE` | AWS CLI profile to use (default: current profile) |
| `--json` | Output machine-readable JSON |
| `--quick` | Skip AWS checks (local Docker health only) |

---

## Troubleshooting

### ACM certificate stuck in PENDING_VALIDATION

The validation CNAME record may not have propagated yet:

```bash
dig +short _abc123.yourdomain.com CNAME
```

If empty, the record hasn't propagated. Wait and retry. If you're using Cloudflare,
ensure the record is in DNS-only mode (grey cloud).

Rerun Phase 2 to resume waiting: `./awsetup.sh --phase 2`

### Target group showing unhealthy

Check that the adapter is running and healthy locally:

```bash
curl -sf localhost:8000/.well-known/oauth-protected-resource
docker compose ps
docker compose logs okta-agent-mcp-adapter --tail=50
```

Verify the EC2 security group allows traffic from the ALB security group on ports 8000 and 3001.

### 502 Bad Gateway from ALB

The ALB can reach the instance but the container isn't responding:

```bash
# Check container health
docker compose ps

# Check adapter logs
docker compose logs okta-agent-mcp-adapter --tail=100

# Verify ports are listening
ss -tlnp | grep -E '8000|3001'
```

### `exec format error` during build or startup

The Docker images were built for the wrong architecture. Check your instance type and set the correct platform:

```bash
# Check instance architecture
uname -m
# x86_64 → DOCKER_PLATFORM=linux/amd64
# aarch64 → DOCKER_PLATFORM=linux/arm64

# Update .env
sed -i 's/DOCKER_PLATFORM=.*/DOCKER_PLATFORM=linux\/arm64/' .env

# Rebuild from scratch (--no-cache forces fresh base image pulls)
docker compose build --no-cache
```

### Docker stack won't start

```bash
# Check disk space
df -h /

# Check memory
free -h

# View startup errors
docker compose logs --tail=50

# Rebuild images
docker compose build --no-cache
```

---

## File Layout

```
.
├── awsetup.sh              # Deployment wizard (Phases 1-3)
├── teardown.sh             # Remove all AWS resources
├── status.sh               # Operational dashboard
├── package.sh              # Build deployment tarball (for release engineers)
├── VERSION                 # Current version
├── .env.template           # Environment variable template
├── README.md               # This file
├── shell-lib/
│   └── common.sh           # Shared bash functions
├── Dockerfile              # Adapter container image
├── docker-compose.yml      # Full stack definition
├── okta_agent_proxy/       # Adapter source code
├── okta_agent_proxy_admin_ui/  # Admin UI source code
├── examples/               # Example backend services
│   ├── 01-hr-system/
│   └── 05-deploy-server/
├── deploy/
│   └── observability/      # Grafana + Loki + Promtail overlay
├── scripts/                # Utility scripts
└── docs/
    └── ARCHITECTURE_DIAGRAM.md
```
