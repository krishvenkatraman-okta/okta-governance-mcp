#!/usr/bin/env bash
set -euo pipefail

# =============================================================
# package.sh — Build a self-contained deployment tarball
# =============================================================
# Run from the root of the okta-agent-mcp-adapter repo.
# Produces: okta-mcp-aws-${VERSION}.tar.gz
# =============================================================

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
REPO_ROOT="$(cd "$SCRIPT_DIR/../.." && pwd)"

# ---- Colors ----
# Respect NO_COLOR (https://no-color.org/) and detect non-TTY output
if [[ -n "${NO_COLOR:-}" ]] || [[ ! -t 1 ]]; then
  RED='' GREEN='' YELLOW='' CYAN='' BOLD='' NC=''
else
  RED='\033[0;31m'
  GREEN='\033[0;32m'
  YELLOW='\033[1;33m'
  CYAN='\033[0;36m'
  BOLD='\033[1m'
  NC='\033[0m'
fi

info()  { printf "${CYAN}[INFO]${NC}  %b\n" "$*"; }
ok()    { printf "${GREEN}[  OK]${NC}  %b\n" "$*"; }
warn()  { printf "${YELLOW}[WARN]${NC}  %b\n" "$*" >&2; }
die()   { printf "${RED}[FAIL]${NC}  %b\n" "$*" >&2; exit 1; }

# ---- Defaults ----
VERSION=""
OUTPUT_DIR=""
DRY_RUN=false

# ---- Parse flags ----
while [[ $# -gt 0 ]]; do
  case "$1" in
    --version)    VERSION="$2"; shift 2 ;;
    --output-dir) OUTPUT_DIR="$2"; shift 2 ;;
    --dry-run)    DRY_RUN=true; shift ;;
    -h|--help)
      echo "Usage: package.sh [--version VERSION] [--output-dir DIR] [--dry-run]"
      exit 0
      ;;
    *) die "Unknown flag: $1" ;;
  esac
done

# Resolve version from pyproject.toml (single source of truth)
if [[ -z "$VERSION" ]]; then
  PYPROJECT="$REPO_ROOT/pyproject.toml"
  if [[ -f "$PYPROJECT" ]]; then
    VERSION="$(grep -m1 '^version' "$PYPROJECT" | sed 's/.*= *"\(.*\)"/\1/')"
  fi
  VERSION="${VERSION:-dev}"
fi

# Resolve output dir
OUTPUT_DIR="${OUTPUT_DIR:-$SCRIPT_DIR/dist}"

STAGING_DIR="/tmp/okta-mcp-aws-${VERSION}"
TARBALL_NAME="okta-mcp-aws-${VERSION}.tar.gz"

info "Version:    ${BOLD}${VERSION}${NC}"
info "Output dir: ${OUTPUT_DIR}"
info "Staging:    ${STAGING_DIR}"
echo ""

# ---- Verify we're in the repo ----
[[ -f "$REPO_ROOT/Dockerfile" ]] || die "Cannot find Dockerfile at repo root: $REPO_ROOT"
[[ -d "$REPO_ROOT/okta_agent_proxy" ]] || die "Cannot find okta_agent_proxy/ at repo root"

# ---- Clean staging ----
rm -rf "$STAGING_DIR"
mkdir -p "$STAGING_DIR"

# ---- Copy included files ----
info "Copying adapter source..."
cp "$REPO_ROOT/LICENSE" "$STAGING_DIR/"
cp "$REPO_ROOT/Dockerfile" "$STAGING_DIR/"
cp "$REPO_ROOT/docker-compose.yml" "$STAGING_DIR/"
cp "$REPO_ROOT/requirements.txt" "$STAGING_DIR/"
# Raw SQL migrations (replaced Alembic in v0.15.0). The Dockerfile
# COPYs deploy/migrations/ into the image.
if [[ -d "$REPO_ROOT/deploy/migrations" ]]; then
  mkdir -p "$STAGING_DIR/deploy/migrations"
  cp -r "$REPO_ROOT/deploy/migrations/." "$STAGING_DIR/deploy/migrations/"
else
  die "Cannot find deploy/migrations in $REPO_ROOT (required by Dockerfile)"
fi
cp -r "$REPO_ROOT/okta_agent_proxy" "$STAGING_DIR/"
cp -r "$REPO_ROOT/scripts" "$STAGING_DIR/"

info "Copying admin UI..."
cp -r "$REPO_ROOT/okta_agent_proxy_admin_ui" "$STAGING_DIR/"
rm -rf "$STAGING_DIR/okta_agent_proxy_admin_ui/node_modules"

info "Copying example backends..."
mkdir -p "$STAGING_DIR/examples"
cp -r "$REPO_ROOT/examples/01-hr-system" "$STAGING_DIR/examples/"
cp -r "$REPO_ROOT/examples/05-deploy-server" "$STAGING_DIR/examples/"

info "Copying observability overlay..."
mkdir -p "$STAGING_DIR/deploy"
cp -r "$REPO_ROOT/deploy/observability" "$STAGING_DIR/deploy/"

info "Copying documentation..."
mkdir -p "$STAGING_DIR/docs"
[[ -f "$REPO_ROOT/docs/ARCHITECTURE_DIAGRAM.md" ]] && cp "$REPO_ROOT/docs/ARCHITECTURE_DIAGRAM.md" "$STAGING_DIR/docs/"
[[ -f "$REPO_ROOT/.env.example" ]] && cp "$REPO_ROOT/.env.example" "$STAGING_DIR/"

info "Copying wizard scripts..."
[[ -f "$SCRIPT_DIR/awsetup.sh" ]]     && cp "$SCRIPT_DIR/awsetup.sh" "$STAGING_DIR/"
[[ -f "$SCRIPT_DIR/teardown.sh" ]]    && cp "$SCRIPT_DIR/teardown.sh" "$STAGING_DIR/"
[[ -f "$SCRIPT_DIR/status.sh" ]]      && cp "$SCRIPT_DIR/status.sh" "$STAGING_DIR/"
[[ -f "$SCRIPT_DIR/README.md" ]]      && cp "$SCRIPT_DIR/README.md" "$STAGING_DIR/"
cp "$REPO_ROOT/pyproject.toml" "$STAGING_DIR/"
cp "$SCRIPT_DIR/.env.template" "$STAGING_DIR/"
mkdir -p "$STAGING_DIR/shell-lib"
cp "$SCRIPT_DIR/shell-lib/common.sh" "$STAGING_DIR/shell-lib/"

# ---- Remove excluded patterns ----
info "Cleaning excluded files..."

find "$STAGING_DIR" -type d -name ".git" -exec rm -rf {} + 2>/dev/null || true
find "$STAGING_DIR" -type d -name ".github" -exec rm -rf {} + 2>/dev/null || true
find "$STAGING_DIR" -name ".gitignore" -delete 2>/dev/null || true

find "$STAGING_DIR" -name "CLAUDE.md" -delete 2>/dev/null || true
find "$STAGING_DIR" -name "CLAUDE_CONVENTIONS.md" -delete 2>/dev/null || true
find "$STAGING_DIR" -type d -name ".claude" -exec rm -rf {} + 2>/dev/null || true

find "$STAGING_DIR" -type d -name "tests" -exec rm -rf {} + 2>/dev/null || true
find "$STAGING_DIR" -name "pytest.ini" -delete 2>/dev/null || true
find "$STAGING_DIR" -name "conftest.py" -delete 2>/dev/null || true
find "$STAGING_DIR" -type d -name ".pytest_cache" -exec rm -rf {} + 2>/dev/null || true

find "$STAGING_DIR" -type d -name "__pycache__" -exec rm -rf {} + 2>/dev/null || true
find "$STAGING_DIR" -name "*.pyc" -delete 2>/dev/null || true
find "$STAGING_DIR" -name "*.pyo" -delete 2>/dev/null || true

# Remove .env but keep .env.template and .env.example
find "$STAGING_DIR" -maxdepth 1 -name ".env" -not -name ".env.*" -delete 2>/dev/null || true

find "$STAGING_DIR" -type d -name "node_modules" -exec rm -rf {} + 2>/dev/null || true

find "$STAGING_DIR" -name "*.docx" -delete 2>/dev/null || true
find "$STAGING_DIR" -name "*.pptx" -delete 2>/dev/null || true
find "$STAGING_DIR" -name "*.xlsx" -delete 2>/dev/null || true

# Remove deploy/ subdirectories other than observability and migrations.
# migrations/ is required by the Dockerfile (COPY deploy/migrations/).
find "$STAGING_DIR/deploy" -mindepth 1 -maxdepth 1 -type d \
  ! -name "observability" ! -name "migrations" \
  -exec rm -rf {} + 2>/dev/null || true

find "$STAGING_DIR" -name "*_PROMPTS*.md" -delete 2>/dev/null || true
find "$STAGING_DIR" -name "*_ANALYSIS*.md" -delete 2>/dev/null || true
find "$STAGING_DIR" -name "*ADR_*.md" -delete 2>/dev/null || true

rm -f "$STAGING_DIR/setup.sh" 2>/dev/null || true

# ---- File listing ----
FILE_COUNT=$(find "$STAGING_DIR" -type f | wc -l | tr -d ' ')
TOTAL_SIZE=$(du -sh "$STAGING_DIR" | cut -f1)

echo ""
info "Package contents: ${BOLD}${FILE_COUNT}${NC} files, ${BOLD}${TOTAL_SIZE}${NC}"
echo ""

if $DRY_RUN; then
  info "${YELLOW}--dry-run${NC}: listing files (no tarball created)"
  echo ""
  (cd /tmp && find "okta-mcp-aws-${VERSION}" -type f | sort)
  echo ""
  info "Total: ${FILE_COUNT} files, ${TOTAL_SIZE}"
  rm -rf "$STAGING_DIR"
  exit 0
fi

# ---- Create tarball ----
info "Creating tarball..."
mkdir -p "$OUTPUT_DIR"
(cd /tmp && tar czf "${OUTPUT_DIR}/${TARBALL_NAME}" "okta-mcp-aws-${VERSION}")

TARBALL_PATH="${OUTPUT_DIR}/${TARBALL_NAME}"
TARBALL_SIZE=$(du -h "$TARBALL_PATH" | cut -f1)
CHECKSUM=$(shasum -a 256 "$TARBALL_PATH" | cut -d' ' -f1)

# ---- Cleanup ----
rm -rf "$STAGING_DIR"

# ---- Summary ----
echo ""
ok "Tarball created: ${BOLD}${TARBALL_PATH}${NC}"
echo ""
printf "  %-12s %s\n" "Files:" "$FILE_COUNT"
printf "  %-12s %s\n" "Unpacked:" "$TOTAL_SIZE"
printf "  %-12s %s\n" "Compressed:" "$TARBALL_SIZE"
printf "  %-12s %s\n" "SHA-256:" "$CHECKSUM"
echo ""
