#!/usr/bin/env bash
set -euo pipefail

# =============================================================
# awsetup.sh — Okta MCP Adapter AWS Deployment Wizard
# =============================================================
# Interactive wizard that configures and deploys the adapter
# on an AWS EC2 instance.
#
# Phase 1: Prerequisites, Okta config, secrets, Docker stack
# Phase 2: ALB + ACM + HTTPS + target groups
# Phase 3: Hostname routing, verification, final cutover
# =============================================================

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
cd "$SCRIPT_DIR"

# Source shared functions
source "$SCRIPT_DIR/shell-lib/common.sh"

# Disable AWS CLI pager (prevents `less` from blocking automation)
export AWS_PAGER=""

# ---- Ctrl+C handler ----
cleanup() {
  echo ""
  warn "Interrupted. State saved to .awsetup.state — rerun to resume."
  exit 130
}
trap cleanup INT TERM

# ---- Read version from pyproject.toml (single source of truth) ----
VERSION="dev"
if [[ -f "$SCRIPT_DIR/pyproject.toml" ]]; then
  VERSION="$(grep -m1 '^version' "$SCRIPT_DIR/pyproject.toml" | sed 's/.*= *"\(.*\)"/\1/')"
fi

# ---- Defaults ----
PHASE="all"
NON_INTERACTIVE=false
SKIP_BUILD=false
WITH_OBSERVABILITY=false

# ---- Port defaults (configurable via environment) ----
GATEWAY_PORT="${GATEWAY_PORT:-8000}"
ADMIN_UI_PORT="${ADMIN_UI_PORT:-3001}"
DCR_CALLBACK_PORT="${DCR_CALLBACK_PORT:-3000}"

# ---- Parse flags ----
while [[ $# -gt 0 ]]; do
  case "$1" in
    --phase)
      PHASE="$2"; shift 2
      [[ "$PHASE" =~ ^(1|2|3|all)$ ]] || die "--phase must be 1, 2, 3, or all"
      ;;
    --profile)           export AWS_PROFILE="$2"; shift 2 ;;
    --non-interactive)   NON_INTERACTIVE=true; shift ;;
    --skip-build)        SKIP_BUILD=true; shift ;;
    --with-observability) WITH_OBSERVABILITY=true; shift ;;
    -h|--help)
      cat <<'USAGE'
Usage: awsetup.sh [OPTIONS]

Options:
  --phase PHASE           Run specific phase: 1, 2, 3, or all (default: all)
  --profile PROFILE       AWS CLI profile to use (default: current profile)
  --non-interactive       Use values from .env and .awsetup.state, never prompt
  --skip-build            Skip docker compose build (use existing images)
  --with-observability    Also start the Grafana/Loki/Promtail stack
  --help                  Show this help

Phases:
  1  Prerequisites, Okta config, secrets, Docker stack
  2  ALB + ACM + HTTPS + target groups
  3  Hostname routing, verification, final cutover
USAGE
      exit 0
      ;;
    *) die "Unknown flag: $1 (use --help)" ;;
  esac
done

# ---- Helper: non-interactive prompt wrappers ----
# In non-interactive mode, these return existing values or fail.
ni_prompt_required() {
  local var_name="$1" prompt_text="$2"
  if $NON_INTERACTIVE; then
    local val="${!var_name:-}"
    [[ -z "$val" ]] && die "Non-interactive mode: $var_name is required but not set"
    return 0
  fi
  prompt_required "$var_name" "$prompt_text"
}

ni_prompt_default() {
  local var_name="$1" prompt_text="$2" default="$3"
  if $NON_INTERACTIVE; then
    eval "$var_name=\"\${$var_name:-$default}\""
    return 0
  fi
  prompt_default "$var_name" "$prompt_text" "$default"
}

ni_prompt_yesno() {
  local prompt_text="$1" default="${2:-y}"
  if $NON_INTERACTIVE; then
    [[ "$default" == "y" ]]
    return $?
  fi
  prompt_yesno "$prompt_text" "$default"
}

# ---- Helper: update a key=value in .env ----
_env_set() {
  local key="$1" value="$2"
  local env_file="$SCRIPT_DIR/.env"
  # Escape sed replacement metacharacters so values containing `|`, `&`, or `\`
  # don't corrupt the substitution. Passwords are alphanumeric today, but
  # Okta secrets and hostnames can include any of these.
  local esc
  esc=$(printf '%s' "$value" | sed -e 's/[&|\\]/\\&/g')
  if grep -q "^${key}=" "$env_file" 2>/dev/null; then
    local tmp
    tmp=$(mktemp)
    sed "s|^${key}=.*|${key}=${esc}|" "$env_file" > "$tmp" && mv "$tmp" "$env_file"
  else
    echo "${key}=${value}" >> "$env_file"
  fi
}

# ============================================================
#  PHASE 1: Prerequisites & Docker Stack
# ============================================================

phase1() {
  # ----------------------------------------------------------
  # Step 1.1: Banner + Prerequisites
  # ----------------------------------------------------------
  echo ""
  printf "${CYAN}┌──────────────────────────────────────────────────┐${NC}\n"
  printf "${CYAN}│${NC}  ${BOLD}Okta MCP Adapter — AWS Deployment Wizard${NC}        ${CYAN}│${NC}\n"
  printf "${CYAN}│${NC}  Version: ${GREEN}%-39s${NC}${CYAN}│${NC}\n" "$VERSION"
  printf "${CYAN}└──────────────────────────────────────────────────┘${NC}\n"
  echo ""

  info "Step 1.1: Checking prerequisites..."
  echo ""

  # Required commands
  validate_command docker "Install: https://docs.docker.com/engine/install/"
  docker info >/dev/null 2>&1 || die "Docker daemon is not running. Start it with: sudo systemctl start docker"
  ok "docker"

  docker compose version >/dev/null 2>&1 || die "docker compose plugin not found. Install: https://docs.docker.com/compose/install/"
  ok "docker compose"

  validate_command aws "Install: https://docs.aws.amazon.com/cli/latest/userguide/install-cliv2.html"
  ok "aws cli"

  validate_command curl
  ok "curl"

  validate_command openssl
  ok "openssl"

  # jq or python3 fallback
  if command -v jq &>/dev/null; then
    ok "jq"
    JQ_CMD="jq"
  elif command -v python3 &>/dev/null; then
    warn "jq not found — using python3 as JSON parser fallback"
    JQ_CMD="python3 -c 'import sys,json; print(json.dumps(json.load(sys.stdin)))'"
  else
    die "'jq' or 'python3' is required for JSON parsing. Install jq: sudo yum install -y jq"
  fi

  echo ""

  # Verify AWS credentials
  info "Verifying AWS credentials..."
  local caller_identity
  caller_identity=$(aws sts get-caller-identity --output json 2>/dev/null) \
    || die "AWS CLI not configured. Run: aws configure"

  local account_id arn
  account_id=$(echo "$caller_identity" | jq -r '.Account' 2>/dev/null || echo "unknown")
  arn=$(echo "$caller_identity" | jq -r '.Arn' 2>/dev/null || echo "unknown")

  printf "  Account: ${BOLD}%s${NC}\n" "$account_id"
  printf "  IAM:     ${BOLD}%s${NC}\n" "$arn"
  echo ""

  if ! ni_prompt_yesno "Is this the correct AWS account?" "y"; then
    die "Aborted. Configure the correct AWS profile with: aws configure"
  fi

  # Disk space check (>= 5GB)
  local avail_kb
  avail_kb=$(df -k "$SCRIPT_DIR" | awk 'NR==2 {print $4}')
  local avail_gb=$(( avail_kb / 1048576 ))
  if [[ $avail_gb -lt 5 ]]; then
    die "Insufficient disk space: ${avail_gb}GB available, need at least 5GB"
  fi
  ok "Disk space: ${avail_gb}GB available"

  # Memory check (warn if < 4GB)
  local mem_kb=0
  if [[ -f /proc/meminfo ]]; then
    mem_kb=$(grep MemAvailable /proc/meminfo 2>/dev/null | awk '{print $2}' || echo 0)
  elif command -v sysctl &>/dev/null; then
    mem_kb=$(( $(sysctl -n hw.memsize 2>/dev/null || echo 0) / 1024 ))
  fi
  if [[ $mem_kb -gt 0 ]]; then
    local mem_gb=$(( mem_kb / 1048576 ))
    if [[ $mem_gb -lt 4 ]]; then
      warn "Low memory: ${mem_gb}GB available (recommend >= 4GB)"
    else
      ok "Memory: ${mem_gb}GB available"
    fi
  fi

  echo ""
  ok "All prerequisites satisfied"
  echo ""

  # ----------------------------------------------------------
  # Step 1.2: Detect AWS Environment
  # ----------------------------------------------------------
  info "Step 1.2: Detecting AWS environment..."
  echo ""

  local on_ec2=true
  local detected_region="" detected_instance="" detected_vpc="" detected_sg=""

  detected_region=$(detect_region 2>/dev/null || true)
  detected_instance=$(detect_instance_id 2>/dev/null || true)
  detected_vpc=$(detect_vpc_id 2>/dev/null || true)
  detected_sg=$(detect_ec2_sg 2>/dev/null || true)

  if [[ -n "$detected_instance" ]]; then
    ok "EC2 instance metadata detected"
    printf "  Region:      ${BOLD}%s${NC}\n" "$detected_region"
    printf "  Instance:    ${BOLD}%s${NC}\n" "$detected_instance"
    printf "  VPC:         ${BOLD}%s${NC}\n" "$detected_vpc"
    printf "  Security Grp:${BOLD}%s${NC}\n" "$detected_sg"
    echo ""

    if ! ni_prompt_yesno "Use these detected values?" "y"; then
      on_ec2=false
    fi
  else
    warn "EC2 instance metadata not available (not running on EC2?)"
    on_ec2=false
  fi

  # Set values — prompt if not detected
  AWS_REGION="${detected_region:-}"
  EC2_INSTANCE_ID="${detected_instance:-}"
  VPC_ID="${detected_vpc:-}"
  EC2_SG_ID="${detected_sg:-}"

  if ! $on_ec2 || [[ -z "$AWS_REGION" ]]; then
    ni_prompt_required AWS_REGION "AWS Region (e.g., us-east-1)"
  fi
  if ! $on_ec2 || [[ -z "$EC2_INSTANCE_ID" ]]; then
    ni_prompt_required EC2_INSTANCE_ID "EC2 Instance ID (e.g., i-0abc123...)"
  fi
  if ! $on_ec2 || [[ -z "$VPC_ID" ]]; then
    ni_prompt_required VPC_ID "VPC ID (e.g., vpc-0abc123...)"
  fi
  if ! $on_ec2 || [[ -z "$EC2_SG_ID" ]]; then
    ni_prompt_required EC2_SG_ID "EC2 Security Group ID (e.g., sg-0abc123...)"
  fi

  save_state AWS_REGION "$AWS_REGION"
  save_state EC2_INSTANCE_ID "$EC2_INSTANCE_ID"
  save_state VPC_ID "$VPC_ID"
  save_state EC2_SG_ID "$EC2_SG_ID"

  echo ""
  info "Finding public subnets in VPC ${VPC_ID}..."
  local subnet_pair SUBNET_1 SUBNET_2
  if subnet_pair=$(find_public_subnets "$VPC_ID" 2>/dev/null); then
    SUBNET_1=$(echo "$subnet_pair" | awk '{print $1}')
    SUBNET_2=$(echo "$subnet_pair" | awk '{print $2}')
    ok "Public subnets: ${SUBNET_1}, ${SUBNET_2}"
  else
    warn "Auto-discovery failed (ec2:DescribeSubnets may be restricted by SCP)."
    info "Please provide two public subnet IDs in different AZs manually."
    ni_prompt_required SUBNET_1 "Public Subnet 1 (e.g., subnet-0abc123...)"
    ni_prompt_required SUBNET_2 "Public Subnet 2 (e.g., subnet-0def456..., different AZ)"
    ok "Using manually provided subnets: ${SUBNET_1}, ${SUBNET_2}"
  fi
  save_state PUBLIC_SUBNET_1 "$SUBNET_1"
  save_state PUBLIC_SUBNET_2 "$SUBNET_2"

  echo ""

  # ----------------------------------------------------------
  # Step 1.2b: Public hostnames
  # ----------------------------------------------------------
  # Collected up front (previously collected in phase 2) so GATEWAY_BASE_URL
  # can be written as the final public https URL from the start. Matters
  # for RFC 8414 §3.3: the issuer advertised in the OAuth discovery doc must
  # match the request URL, so localhost:8000 cannot be used once the ALB
  # registers public targets in phase 2.
  info "Step 1.2b: Public hostnames..."
  echo ""

  DOMAIN="$(get_state DOMAIN || true)"
  MCP_HOSTNAME="$(get_state MCP_HOSTNAME || true)"
  ADMIN_HOSTNAME="$(get_state ADMIN_HOSTNAME || true)"
  local mcp_prefix admin_prefix
  mcp_prefix="$(get_state MCP_PREFIX || echo mcp)"
  admin_prefix="$(get_state ADMIN_PREFIX || echo admin)"

  ni_prompt_required DOMAIN "Public DNS base domain (e.g., oktaproserv.com)"
  ni_prompt_default mcp_prefix "MCP gateway subdomain prefix" "${mcp_prefix}"
  ni_prompt_default admin_prefix "Admin UI subdomain prefix" "${admin_prefix}"

  MCP_HOSTNAME="${mcp_prefix}.${DOMAIN}"
  ADMIN_HOSTNAME="${admin_prefix}.${DOMAIN}"

  echo ""
  printf "  MCP endpoint: ${BOLD}%s${NC}\n" "$MCP_HOSTNAME"
  printf "  Admin UI:     ${BOLD}%s${NC}\n" "$ADMIN_HOSTNAME"
  echo ""

  save_state DOMAIN "$DOMAIN"
  save_state MCP_HOSTNAME "$MCP_HOSTNAME"
  save_state ADMIN_HOSTNAME "$ADMIN_HOSTNAME"
  save_state MCP_PREFIX "$mcp_prefix"
  save_state ADMIN_PREFIX "$admin_prefix"

  echo ""

  # ----------------------------------------------------------
  # Step 1.3: Okta Configuration
  # ----------------------------------------------------------
  info "Step 1.3: Configuring Okta..."
  echo ""

  OKTA_DOMAIN=""
  OKTA_ISSUER=""
  CIMD_ENABLED="false"
  RELAY_OKTA_CLIENT_ID=""
  RELAY_OKTA_CLIENT_SECRET=""

  # Check for existing .env values
  local reuse_okta=false
  if [[ -f "$SCRIPT_DIR/.env" ]]; then
    local existing_domain
    existing_domain=$(grep "^OKTA_DOMAIN=" "$SCRIPT_DIR/.env" 2>/dev/null | cut -d= -f2- || true)
    if [[ -n "$existing_domain" ]]; then
      echo ""
      if ni_prompt_yesno "Found existing Okta config (OKTA_DOMAIN=${existing_domain}). Keep it?" "y"; then
        reuse_okta=true
        # Source existing values
        OKTA_DOMAIN="$existing_domain"
        OKTA_ISSUER=$(grep "^OKTA_ISSUER=" "$SCRIPT_DIR/.env" 2>/dev/null | cut -d= -f2- || true)
        CIMD_ENABLED=$(grep "^CIMD_ENABLED=" "$SCRIPT_DIR/.env" 2>/dev/null | cut -d= -f2- || echo "false")
        RELAY_OKTA_CLIENT_ID=$(grep "^RELAY_OKTA_CLIENT_ID=" "$SCRIPT_DIR/.env" 2>/dev/null | cut -d= -f2- || true)
        RELAY_OKTA_CLIENT_SECRET=$(grep "^RELAY_OKTA_CLIENT_SECRET=" "$SCRIPT_DIR/.env" 2>/dev/null | cut -d= -f2- || true)
        ok "Reusing existing Okta configuration"
      fi
    fi
  fi

  if ! $reuse_okta; then
    # Prompt for Okta domain
    while true; do
      ni_prompt_required OKTA_DOMAIN "Okta Domain (e.g., dev-12345.okta.com)"
      # Validate domain format
      if [[ "$OKTA_DOMAIN" =~ \.(okta\.com|oktapreview\.com)$ ]]; then
        # Test connectivity
        local oidc_url="https://${OKTA_DOMAIN}/.well-known/openid-configuration"
        if curl -sf "$oidc_url" >/dev/null 2>&1; then
          ok "Okta domain reachable: ${OKTA_DOMAIN}"
        else
          warn "Could not reach ${oidc_url} — verify domain is correct"
        fi
        break
      else
        warn "Domain must end with .okta.com or .oktapreview.com"
        $NON_INTERACTIVE && die "Invalid OKTA_DOMAIN: $OKTA_DOMAIN"
      fi
    done

    # Derive issuer from domain (Org authorization server)
    OKTA_ISSUER="https://${OKTA_DOMAIN}"

    echo ""

    # CIMD
    if ni_prompt_yesno "Enable Confidential Client Registration (CIMD)?" "n"; then
      CIMD_ENABLED="true"
      ni_prompt_required RELAY_OKTA_CLIENT_ID "CIMD Relay Okta Client ID"
      ni_prompt_required RELAY_OKTA_CLIENT_SECRET "CIMD Relay Okta Client Secret"
    fi
  fi

  # Construct issuer if not already set (Org authorization server)
  if [[ -z "$OKTA_ISSUER" ]]; then
    OKTA_ISSUER="https://${OKTA_DOMAIN}"
  fi

  save_state OKTA_DOMAIN "$OKTA_DOMAIN"
  save_state OKTA_ISSUER "$OKTA_ISSUER"
  save_state CIMD_ENABLED "$CIMD_ENABLED"

  echo ""

  # ----------------------------------------------------------
  # Step 1.3b: Deploy example backend configuration
  # ----------------------------------------------------------
  # The deploy-mcp-server container validates AT-2 tokens via okta-jwt-verifier
  # and raises at startup if DEPLOY_OKTA_DOMAIN / DEPLOY_OKTA_AUTH_SERVER_ID
  # are empty. DEPLOY_AUTH_DISABLED is not honored by the verifier today, so
  # we always prompt.
  info "Step 1.3b: Deploy example backend configuration..."
  echo ""

  DEPLOY_OKTA_DOMAIN="$(get_state DEPLOY_OKTA_DOMAIN || true)"
  DEPLOY_OKTA_AUTH_SERVER_ID="$(get_state DEPLOY_OKTA_AUTH_SERVER_ID || true)"
  DEPLOY_OKTA_AUDIENCE="$(get_state DEPLOY_OKTA_AUDIENCE || true)"

  # Reuse from .env if present
  if [[ -f "$SCRIPT_DIR/.env" ]]; then
    DEPLOY_OKTA_DOMAIN="${DEPLOY_OKTA_DOMAIN:-$(grep "^DEPLOY_OKTA_DOMAIN=" "$SCRIPT_DIR/.env" 2>/dev/null | cut -d= -f2- || true)}"
    DEPLOY_OKTA_AUTH_SERVER_ID="${DEPLOY_OKTA_AUTH_SERVER_ID:-$(grep "^DEPLOY_OKTA_AUTH_SERVER_ID=" "$SCRIPT_DIR/.env" 2>/dev/null | cut -d= -f2- || true)}"
    DEPLOY_OKTA_AUDIENCE="${DEPLOY_OKTA_AUDIENCE:-$(grep "^DEPLOY_OKTA_AUDIENCE=" "$SCRIPT_DIR/.env" 2>/dev/null | cut -d= -f2- || true)}"
  fi

  ni_prompt_default DEPLOY_OKTA_DOMAIN "Deploy backend Okta domain" "${DEPLOY_OKTA_DOMAIN:-$OKTA_DOMAIN}"
  ni_prompt_default DEPLOY_OKTA_AUTH_SERVER_ID "Deploy backend auth server ID (e.g., 'default' or a custom ID)" "${DEPLOY_OKTA_AUTH_SERVER_ID:-default}"
  ni_prompt_default DEPLOY_OKTA_AUDIENCE "Deploy backend audience" "${DEPLOY_OKTA_AUDIENCE:-api://deploy-server}"

  save_state DEPLOY_OKTA_DOMAIN "$DEPLOY_OKTA_DOMAIN"
  save_state DEPLOY_OKTA_AUTH_SERVER_ID "$DEPLOY_OKTA_AUTH_SERVER_ID"
  save_state DEPLOY_OKTA_AUDIENCE "$DEPLOY_OKTA_AUDIENCE"

  echo ""

  # ----------------------------------------------------------
  # Step 1.4: Generate Secrets
  # ----------------------------------------------------------
  info "Step 1.4: Generating secrets..."
  echo ""

  # Load existing .env secrets if present
  ENCRYPTION_KEY="${ENCRYPTION_KEY:-}"
  POSTGRES_PASSWORD="${POSTGRES_PASSWORD:-}"
  REDIS_PASSWORD="${REDIS_PASSWORD:-}"
  HR_PSK_SECRET="${HR_PSK_SECRET:-}"
  ADMIN_UI_NEXTAUTH_SECRET="${ADMIN_UI_NEXTAUTH_SECRET:-}"

  if [[ -f "$SCRIPT_DIR/.env" ]]; then
    ENCRYPTION_KEY="${ENCRYPTION_KEY:-$(grep "^ENCRYPTION_KEY=" "$SCRIPT_DIR/.env" 2>/dev/null | cut -d= -f2- || true)}"
    POSTGRES_PASSWORD="${POSTGRES_PASSWORD:-$(grep "^POSTGRES_PASSWORD=" "$SCRIPT_DIR/.env" 2>/dev/null | cut -d= -f2- || true)}"
    REDIS_PASSWORD="${REDIS_PASSWORD:-$(grep "^REDIS_PASSWORD=" "$SCRIPT_DIR/.env" 2>/dev/null | cut -d= -f2- || true)}"
    HR_PSK_SECRET="${HR_PSK_SECRET:-$(grep "^HR_PSK_SECRET=" "$SCRIPT_DIR/.env" 2>/dev/null | cut -d= -f2- || true)}"
    ADMIN_UI_NEXTAUTH_SECRET="${ADMIN_UI_NEXTAUTH_SECRET:-$(grep "^ADMIN_UI_NEXTAUTH_SECRET=" "$SCRIPT_DIR/.env" 2>/dev/null | cut -d= -f2- || true)}"
  fi

  if [[ -z "$ENCRYPTION_KEY" ]]; then
    ENCRYPTION_KEY=$(openssl rand -base64 32)
    ok "Generated ENCRYPTION_KEY"
  else
    ok "ENCRYPTION_KEY (existing)"
  fi

  if [[ -z "$POSTGRES_PASSWORD" ]]; then
    POSTGRES_PASSWORD=$(openssl rand -base64 16 | tr -dc 'a-zA-Z0-9' | head -c20)
    ok "Generated POSTGRES_PASSWORD"
  else
    ok "POSTGRES_PASSWORD (existing)"
  fi

  # Guard: stale postgres_data volume vs. fresh POSTGRES_PASSWORD
  # If the volume already exists with a password baked in from a previous run
  # and we generated a new one, alembic will fail with:
  #   FATAL: password authentication failed for user "gateway_user"
  local pg_vol_exists=false
  local vol_name=""
  for vol in aws-ec2_postgres_data okta-agent-mcp-adapter_postgres_data postgres_data; do
    if docker volume inspect "$vol" &>/dev/null; then
      pg_vol_exists=true
      vol_name="$vol"
      break
    fi
  done
  if $pg_vol_exists; then
    local env_pw=""
    if [[ -f "$SCRIPT_DIR/.env" ]]; then
      env_pw=$(grep "^POSTGRES_PASSWORD=" "$SCRIPT_DIR/.env" 2>/dev/null | cut -d= -f2- || true)
    fi
    if [[ -z "$env_pw" || "$env_pw" != "$POSTGRES_PASSWORD" ]]; then
      echo ""
      warn "Existing postgres volume detected (${vol_name}) but POSTGRES_PASSWORD"
      warn "does not match. The volume retains the ORIGINAL password; alembic"
      warn "migrations will fail with:"
      warn "  FATAL: password authentication failed for user \"gateway_user\""
      warn ""
      warn "Recovery (destroys postgres data):"
      warn "  docker compose down -v"
      warn "  ./awsetup.sh --phase 1"
      warn ""
      warn "OR paste the original POSTGRES_PASSWORD into .env before continuing."
      echo ""
      if ! ni_prompt_yesno "Continue anyway (will likely fail)?" "n"; then
        die "Aborted. Resolve the password mismatch and retry."
      fi
    fi
  fi

  if [[ -z "$REDIS_PASSWORD" ]]; then
    REDIS_PASSWORD=$(openssl rand -base64 12 | tr -dc 'a-zA-Z0-9' | head -c16)
    ok "Generated REDIS_PASSWORD"
  else
    ok "REDIS_PASSWORD (existing)"
  fi

  if [[ -z "$HR_PSK_SECRET" ]]; then
    HR_PSK_SECRET=$(openssl rand -base64 32)
    ok "Generated HR_PSK_SECRET"
  else
    ok "HR_PSK_SECRET (existing)"
  fi

  if [[ -z "$ADMIN_UI_NEXTAUTH_SECRET" ]]; then
    ADMIN_UI_NEXTAUTH_SECRET=$(openssl rand -base64 32)
    ok "Generated ADMIN_UI_NEXTAUTH_SECRET"
  else
    ok "ADMIN_UI_NEXTAUTH_SECRET (existing)"
  fi

  echo ""
  printf "  ${YELLOW}╔══════════════════════════════════════════════════════╗${NC}\n"
  printf "  ${YELLOW}║${NC}  ${BOLD}Admin UI Sign-In${NC}                                    ${YELLOW}║${NC}\n"
  printf "  ${YELLOW}║${NC}  Authentication uses your Okta OIDC app (configured   ${YELLOW}║${NC}\n"
  printf "  ${YELLOW}║${NC}  in Phase 3 as ADMIN_UI_OKTA_CLIENT_ID).              ${YELLOW}║${NC}\n"
  printf "  ${YELLOW}║${NC}  No local username/password is used.                  ${YELLOW}║${NC}\n"
  printf "  ${YELLOW}╚══════════════════════════════════════════════════════╝${NC}\n"
  echo ""

  # ----------------------------------------------------------
  # Step 1.5: Write .env
  # ----------------------------------------------------------
  info "Step 1.5: Writing .env file..."

  local env_file="$SCRIPT_DIR/.env"

  # Start from template
  cp "$SCRIPT_DIR/.env.template" "$env_file"

  # Required: Okta
  _env_set OKTA_DOMAIN "$OKTA_DOMAIN"
  _env_set OKTA_ISSUER "$OKTA_ISSUER"

  # Auto-generated secrets
  _env_set ENCRYPTION_KEY "$ENCRYPTION_KEY"
  _env_set POSTGRES_PASSWORD "$POSTGRES_PASSWORD"
  _env_set REDIS_PASSWORD "$REDIS_PASSWORD"
  _env_set HR_PSK_SECRET "$HR_PSK_SECRET"

  # Adapter defaults — GATEWAY_BASE_URL is the public https URL from the
  # start (see Step 1.2b). Required for RFC 8414 §3.3 issuer compliance once
  # the ALB routes public traffic to the adapter in phase 2.
  _env_set GATEWAY_BASE_URL "https://${MCP_HOSTNAME}"
  _env_set GATEWAY_PORT "$GATEWAY_PORT"
  _env_set DOMAIN "$DOMAIN"
  _env_set MCP_HOSTNAME "$MCP_HOSTNAME"
  _env_set ADMIN_HOSTNAME "$ADMIN_HOSTNAME"
  _env_set LOG_LEVEL "INFO"
  _env_set POSTGRES_DB "gateway_db"
  _env_set POSTGRES_USER "gateway_user"

  # CIMD
  _env_set CIMD_ENABLED "$CIMD_ENABLED"
  if [[ "$CIMD_ENABLED" == "true" ]]; then
    _env_set RELAY_OKTA_CLIENT_ID "$RELAY_OKTA_CLIENT_ID"
    _env_set RELAY_OKTA_CLIENT_SECRET "$RELAY_OKTA_CLIENT_SECRET"
  fi

  # AWS
  _env_set AWS_REGION "$AWS_REGION"
  _env_set EC2_INSTANCE_ID "$EC2_INSTANCE_ID"
  _env_set VPC_ID "$VPC_ID"
  _env_set EC2_SG_ID "$EC2_SG_ID"

  # Admin UI (Okta OIDC configured in Phase 3) — NextAuth URL matches the
  # final public hostname so the callback URL the user configures in Okta
  # stays valid through all phases.
  _env_set ADMIN_UI_NEXTAUTH_URL "https://${ADMIN_HOSTNAME}"
  _env_set ADMIN_UI_NEXTAUTH_SECRET "$ADMIN_UI_NEXTAUTH_SECRET"

  # Deployment
  _env_set DEPLOYMENT_MODE "standalone"

  # Deploy example backend (token verification)
  _env_set DEPLOY_AUTH_DISABLED "false"
  _env_set DEPLOY_OKTA_DOMAIN "$DEPLOY_OKTA_DOMAIN"
  _env_set DEPLOY_OKTA_AUTH_SERVER_ID "$DEPLOY_OKTA_AUTH_SERVER_ID"
  _env_set DEPLOY_OKTA_AUDIENCE "$DEPLOY_OKTA_AUDIENCE"

  # MCP protocol version (gateway-initiated initialize; left empty for SDK default)
  _env_set MCP_PROTOCOL_VERSION ""

  ok ".env written"
  echo ""

  # ----------------------------------------------------------
  # Step 1.6: Build Docker Images
  # ----------------------------------------------------------
  if $SKIP_BUILD; then
    info "Step 1.6: Skipping Docker build (--skip-build)"
  else
    info "Step 1.6: Building Docker images from source (2-4 minutes)..."
    echo ""

    local build_start
    build_start=$(date +%s)

    # Build with progress output
    if ! docker compose build 2>&1 | while IFS= read -r line; do
      printf "\r  ${CYAN}Building...${NC} %s" "$(echo "$line" | tail -c 70)"
    done; then
      echo ""
      fail "Docker build failed. Check output above."
      die "Fix the build errors and rerun: ./awsetup.sh --phase 1 --skip-build (to skip if images exist)"
    fi
    echo ""

    local build_end build_duration
    build_end=$(date +%s)
    build_duration=$(( build_end - build_start ))
    ok "Docker images built in ${build_duration}s"
  fi

  echo ""

  # ----------------------------------------------------------
  # Step 1.7: Start the Stack
  # ----------------------------------------------------------
  info "Step 1.7: Starting the Docker stack..."
  echo ""

  # Stop any existing containers first
  docker compose down --remove-orphans 2>&1 || true

  # Force-remove named containers from prior runs that may have used a
  # different Compose project name (explicit container_name: in compose
  # file causes conflicts when the project name changes between runs).
  docker rm -f okta-mcp-postgres okta-mcp-redis okta-agent-mcp-adapter \
    okta-mcp-admin-ui hr-mcp-server deploy-mcp-server 2>/dev/null || true

  if $WITH_OBSERVABILITY && [[ -f "$SCRIPT_DIR/deploy/observability/docker-compose.observability.yml" ]]; then
    if ! docker compose \
      -f docker-compose.yml \
      -f deploy/observability/docker-compose.observability.yml \
      up -d; then
      fail "Docker stack failed to start."
      docker compose logs --tail=30 2>/dev/null || true
      die "Fix the issues and rerun: ./awsetup.sh --phase 1 --skip-build"
    fi
  else
    if ! docker compose up -d; then
      fail "Docker stack failed to start."
      docker compose logs --tail=30 2>/dev/null || true
      die "Fix the issues and rerun: ./awsetup.sh --phase 1 --skip-build"
    fi
  fi

  # Wait for each service with numbered progress
  local services=("postgres" "redis" "okta-agent-mcp-adapter" "admin-ui" "hr-mcp-server" "deploy-mcp-server")
  local labels=("PostgreSQL" "Redis" "Gateway" "Admin UI" "HR Backend" "Deploy Backend")
  local total=${#services[@]}
  local all_healthy=true

  for i in "${!services[@]}"; do
    local svc="${services[$i]}"
    local label="${labels[$i]}"
    local num=$(( i + 1 ))

    printf "  [%d/%d] %-20s" "$num" "$total" "${label}..."

    local elapsed=0 timeout=120
    while [[ $elapsed -lt $timeout ]]; do
      local health
      health=$(docker compose ps --format '{{.Health}}' "$svc" 2>/dev/null || true)
      local state
      state=$(docker compose ps --format '{{.State}}' "$svc" 2>/dev/null || true)

      if [[ "$health" == "healthy" || ("$state" == "running" && -z "$health") ]]; then
        printf "${GREEN}✓ healthy${NC}\n"
        break
      fi

      if [[ "$state" == "exited" || "$state" == "dead" ]]; then
        printf "${RED}✗ failed${NC}\n"
        all_healthy=false
        warn "Logs for ${svc}:"
        docker compose logs --tail=30 "$svc" 2>/dev/null || true
        # Post-mortem: detect the postgres password-mismatch signature
        if [[ "$svc" == "okta-agent-mcp-adapter" ]]; then
          if docker compose logs --tail=100 "$svc" 2>/dev/null \
               | grep -q "password authentication failed for user"; then
            echo ""
            warn "Detected postgres password authentication failure."
            warn "This usually means the postgres_data volume has an older password"
            warn "baked in than the one in .env."
            warn ""
            warn "Recovery (destroys postgres data):"
            warn "  docker compose down -v"
            warn "  ./awsetup.sh --phase 1"
          fi
        fi
        break
      fi

      sleep 2
      elapsed=$(( elapsed + 2 ))
    done

    if [[ $elapsed -ge $timeout ]]; then
      printf "${RED}✗ timeout${NC}\n"
      all_healthy=false
      warn "Logs for ${svc}:"
      docker compose logs --tail=20 "$svc" 2>/dev/null || true
    fi
  done

  echo ""

  if ! $all_healthy; then
    fail "Some services failed to start. Check logs with: docker compose logs"
    die "Fix the issues and rerun: ./awsetup.sh --phase 1 --skip-build"
  fi

  ok "All services running"
  echo ""

  # ----------------------------------------------------------
  # Step 1.8: Local Smoke Test
  # ----------------------------------------------------------
  info "Step 1.8: Running smoke tests..."
  echo ""

  # Test gateway
  local smoke_ok=true

  printf "  Gateway health............"
  if curl -sf "http://localhost:${GATEWAY_PORT}/.well-known/oauth-protected-resource" >/dev/null 2>&1; then
    printf "${GREEN}✓${NC}\n"
  else
    printf "${RED}✗${NC}\n"
    warn "Gateway not responding on localhost:${GATEWAY_PORT}"
    smoke_ok=false
  fi

  # Test admin API rejects unauthenticated requests (password login was
  # removed in v0.15.x — only Okta OAuth access tokens are accepted).
  printf "  Admin API (401 expected).."
  local admin_status
  admin_status=$(curl -s -o /dev/null -w '%{http_code}' "http://localhost:${GATEWAY_PORT}/api/admin/agents" 2>/dev/null || echo "000")
  if [[ "$admin_status" == "401" ]]; then
    printf "${GREEN}✓${NC}\n"
  else
    printf "${RED}✗${NC}\n"
    warn "Admin API unexpected status: ${admin_status}"
    smoke_ok=false
  fi

  echo ""

  if $smoke_ok; then
    save_state PHASE1_COMPLETE "true"

    echo ""
    printf "${GREEN}┌──────────────────────────────────────────────────┐${NC}\n"
    printf "${GREEN}│${NC}  ${BOLD}✓ Phase 1 complete${NC}                                ${GREEN}│${NC}\n"
    printf "${GREEN}│${NC}                                                    ${GREEN}│${NC}\n"
    printf "${GREEN}│${NC}  Adapter running on: ${CYAN}http://localhost:${GATEWAY_PORT}${NC}          ${GREEN}│${NC}\n"
    printf "${GREEN}│${NC}  Admin UI:           ${CYAN}http://localhost:${ADMIN_UI_PORT}${NC}          ${GREEN}│${NC}\n"
    if $WITH_OBSERVABILITY; then
    printf "${GREEN}│${NC}  Grafana:            ${CYAN}http://localhost:3000${NC}          ${GREEN}│${NC}\n"
    fi
    printf "${GREEN}│${NC}                                                    ${GREEN}│${NC}\n"
    printf "${GREEN}│${NC}  Next: ${BOLD}./awsetup.sh --phase 2${NC} for ALB + HTTPS       ${GREEN}│${NC}\n"
    printf "${GREEN}└──────────────────────────────────────────────────┘${NC}\n"
    echo ""
    warn "Local OAuth discovery doc advertises the public issuer https://${MCP_HOSTNAME}."
    warn "Public endpoints only become reachable after phase 2 (ALB) and phase 3 (DNS + TLS) complete."
    echo ""
  else
    warn "Smoke tests had failures — the stack may still be starting"
    warn "Wait 30s and retry: curl http://localhost:${GATEWAY_PORT}/.well-known/oauth-protected-resource"
    save_state PHASE1_COMPLETE "partial"
  fi
}

# ============================================================
#  PHASE 2: ALB + ACM + Target Groups
# ============================================================

phase2() {
  load_state
  [[ "$(get_state PHASE1_COMPLETE)" == "true" ]] || die "Phase 1 not complete. Run: ./awsetup.sh --phase 1"

  # Reload key state vars into shell
  AWS_REGION="$(get_state AWS_REGION)"
  EC2_INSTANCE_ID="$(get_state EC2_INSTANCE_ID)"
  VPC_ID="$(get_state VPC_ID)"
  EC2_SG_ID="$(get_state EC2_SG_ID)"
  PUBLIC_SUBNET_1="$(get_state PUBLIC_SUBNET_1)"
  PUBLIC_SUBNET_2="$(get_state PUBLIC_SUBNET_2)"
  mcp_prefix="$(get_state MCP_PREFIX || echo mcp)"
  admin_prefix="$(get_state ADMIN_PREFIX || echo admin)"

  [[ -z "$AWS_REGION" ]] && die "AWS_REGION missing from state. Rerun Phase 1."
  [[ -z "$VPC_ID" ]]     && die "VPC_ID missing from state. Rerun Phase 1."

  echo ""
  printf "${CYAN}┌──────────────────────────────────────────────────┐${NC}\n"
  printf "${CYAN}│${NC}  ${BOLD}Phase 2: ALB + ACM + HTTPS${NC}                        ${CYAN}│${NC}\n"
  printf "${CYAN}└──────────────────────────────────────────────────┘${NC}\n"
  echo ""

  # ----------------------------------------------------------
  # Step 2.1: Domain Configuration (reused from phase 1)
  # ----------------------------------------------------------
  # Hostnames are collected in phase 1 Step 1.2b so GATEWAY_BASE_URL can be
  # set to the final https URL from the start. This step just reads state
  # and fails closed if phase 1 wasn't run.
  info "Step 2.1: Reading domain configuration from phase 1..."
  echo ""

  DOMAIN="$(get_state DOMAIN || true)"
  MCP_HOSTNAME="$(get_state MCP_HOSTNAME || true)"
  ADMIN_HOSTNAME="$(get_state ADMIN_HOSTNAME || true)"

  if [[ -z "$DOMAIN" || -z "$MCP_HOSTNAME" || -z "$ADMIN_HOSTNAME" ]]; then
    die "Missing DOMAIN / MCP_HOSTNAME / ADMIN_HOSTNAME in state. Run './awsetup.sh --phase 1' first."
  fi

  printf "  MCP endpoint: ${BOLD}%s${NC}\n" "$MCP_HOSTNAME"
  printf "  Admin UI:     ${BOLD}%s${NC}\n" "$ADMIN_HOSTNAME"
  echo ""

  # ----------------------------------------------------------
  # Step 2.2: Request ACM Certificate
  # ----------------------------------------------------------
  info "Step 2.2: ACM certificate..."
  echo ""

  ACM_CERT_ARN="$(get_state ACM_CERT_ARN || true)"

  if [[ -n "$ACM_CERT_ARN" ]]; then
    ok "ACM certificate already exists: ${ACM_CERT_ARN}"

    # Check if already validated
    local cert_status
    cert_status=$(aws acm describe-certificate \
      --region "$AWS_REGION" \
      --certificate-arn "$ACM_CERT_ARN" \
      --query 'Certificate.Status' \
      --output text 2>/dev/null || echo "UNKNOWN")

    if [[ "$cert_status" == "ISSUED" ]]; then
      ok "Certificate already validated"
      save_state CERT_VALIDATED "true"
    fi
  else
    info "Requesting wildcard certificate for *.${DOMAIN}..."

    ACM_CERT_ARN=$(aws acm request-certificate \
      --region "$AWS_REGION" \
      --domain-name "*.${DOMAIN}" \
      --subject-alternative-names "${DOMAIN}" \
      --validation-method DNS \
      --query 'CertificateArn' \
      --output text 2>/dev/null) \
      || die "Failed to request ACM certificate. Check IAM permissions (acm:RequestCertificate)."

    ok "Certificate requested: ${ACM_CERT_ARN}"
    save_state ACM_CERT_ARN "$ACM_CERT_ARN"
  fi

  # Wait for DNS validation records to appear
  if [[ "$(get_state CERT_VALIDATED)" != "true" ]]; then
    info "Retrieving DNS validation records..."

    # ACM may take a moment to populate validation options
    local dns_name="" dns_value="" attempts=0
    while [[ -z "$dns_name" && $attempts -lt 12 ]]; do
      local validation_json
      validation_json=$(aws acm describe-certificate \
        --region "$AWS_REGION" \
        --certificate-arn "$ACM_CERT_ARN" \
        --query 'Certificate.DomainValidationOptions[0].ResourceRecord' \
        --output json 2>/dev/null || echo "{}")

      dns_name=$(echo "$validation_json" | jq -r '.Name // empty' 2>/dev/null || true)
      dns_value=$(echo "$validation_json" | jq -r '.Value // empty' 2>/dev/null || true)

      if [[ -z "$dns_name" ]]; then
        sleep 5
        attempts=$(( attempts + 1 ))
      fi
    done

    [[ -z "$dns_name" ]] && die "Could not retrieve DNS validation records from ACM. Check certificate in AWS Console."

    echo ""
    printf "${YELLOW}┌──────────────────────────────────────────────────────────────┐${NC}\n"
    printf "${YELLOW}│${NC}  ${BOLD}ACTION REQUIRED: Add this DNS CNAME record to your domain${NC}   ${YELLOW}│${NC}\n"
    printf "${YELLOW}├──────────────────────────────────────────────────────────────┤${NC}\n"
    printf "${YELLOW}│${NC}                                                              ${YELLOW}│${NC}\n"
    printf "${YELLOW}│${NC}  Name:  ${CYAN}%-52s${NC} ${YELLOW}│${NC}\n" "$dns_name"
    printf "${YELLOW}│${NC}  Type:  ${CYAN}%-52s${NC} ${YELLOW}│${NC}\n" "CNAME"
    printf "${YELLOW}│${NC}  Value: ${CYAN}%-52s${NC} ${YELLOW}│${NC}\n" "$dns_value"
    printf "${YELLOW}│${NC}                                                              ${YELLOW}│${NC}\n"
    printf "${YELLOW}└──────────────────────────────────────────────────────────────┘${NC}\n"
    echo ""

    if ! $NON_INTERACTIVE; then
      printf "${BOLD}Press ENTER after you have added the DNS record...${NC}"
      read -r
    fi

    # Poll for validation
    info "Waiting for certificate validation..."
    local elapsed=0 max_wait=600 attempt=1 max_attempts=40

    while [[ $elapsed -lt $max_wait ]]; do
      local status
      status=$(aws acm describe-certificate \
        --region "$AWS_REGION" \
        --certificate-arn "$ACM_CERT_ARN" \
        --query 'Certificate.Status' \
        --output text 2>/dev/null || echo "UNKNOWN")

      if [[ "$status" == "ISSUED" ]]; then
        echo ""
        ok "Certificate validated!"
        save_state CERT_VALIDATED "true"
        break
      fi

      if [[ "$status" == "FAILED" || "$status" == "REVOKED" ]]; then
        die "Certificate validation failed (status: ${status}). Delete and retry."
      fi

      printf "\r  Waiting for certificate validation... (attempt %d/%d, elapsed %ds)" \
        "$attempt" "$max_attempts" "$elapsed"
      sleep 15
      elapsed=$(( elapsed + 15 ))
      attempt=$(( attempt + 1 ))
    done

    if [[ "$(get_state CERT_VALIDATED)" != "true" ]]; then
      echo ""
      fail "Certificate not validated within 10 minutes."
      info "The DNS record may take time to propagate. Rerun: ./awsetup.sh --phase 2"
      exit 1
    fi
  fi

  echo ""

  # ----------------------------------------------------------
  # Step 2.3: Create ALB Security Group
  # ----------------------------------------------------------
  info "Step 2.3: ALB security group..."
  echo ""

  ALB_SG_ID="$(get_state ALB_SG_ID || true)"

  if [[ -n "$ALB_SG_ID" ]]; then
    ok "ALB security group already exists: ${ALB_SG_ID}"
  else
    info "Creating security group: ${mcp_prefix}-alb-sg..."

    ALB_SG_ID=$(aws ec2 create-security-group \
      --region "$AWS_REGION" \
      --group-name "${mcp_prefix}-alb-sg" \
      --description "Okta MCP Adapter ALB - allows HTTPS/HTTP ingress" \
      --vpc-id "$VPC_ID" \
      --query 'GroupId' \
      --output text 2>/dev/null) \
      || die "Failed to create ALB security group. Check IAM permissions."

    ok "Created ALB SG: ${ALB_SG_ID}"
    save_state ALB_SG_ID "$ALB_SG_ID"

    # Tag for identification
    aws ec2 create-tags \
      --region "$AWS_REGION" \
      --resources "$ALB_SG_ID" \
      --tags Key=Name,Value=${mcp_prefix}-alb-sg Key=Project,Value=okta-mcp-adapter 2>/dev/null || true

    # Inbound: HTTPS from anywhere
    info "  Adding inbound rule: 443/tcp from 0.0.0.0/0..."
    aws ec2 authorize-security-group-ingress \
      --region "$AWS_REGION" \
      --group-id "$ALB_SG_ID" \
      --protocol tcp --port 443 --cidr "0.0.0.0/0" 2>/dev/null \
      || warn "Rule may already exist (443/tcp)"

    # Inbound: HTTP from anywhere (for redirect)
    info "  Adding inbound rule: 80/tcp from 0.0.0.0/0..."
    aws ec2 authorize-security-group-ingress \
      --region "$AWS_REGION" \
      --group-id "$ALB_SG_ID" \
      --protocol tcp --port 80 --cidr "0.0.0.0/0" 2>/dev/null \
      || warn "Rule may already exist (80/tcp)"

    # Allow ALB → EC2 on adapter port
    info "  Adding EC2 SG inbound: ${GATEWAY_PORT}/tcp from ALB SG..."
    aws ec2 authorize-security-group-ingress \
      --region "$AWS_REGION" \
      --group-id "$EC2_SG_ID" \
      --protocol tcp --port "$GATEWAY_PORT" \
      --source-group "$ALB_SG_ID" 2>/dev/null \
      || warn "Rule may already exist (${GATEWAY_PORT}/tcp from ALB)"

    # Allow ALB → EC2 on admin UI port
    info "  Adding EC2 SG inbound: ${ADMIN_UI_PORT}/tcp from ALB SG..."
    aws ec2 authorize-security-group-ingress \
      --region "$AWS_REGION" \
      --group-id "$EC2_SG_ID" \
      --protocol tcp --port "$ADMIN_UI_PORT" \
      --source-group "$ALB_SG_ID" 2>/dev/null \
      || warn "Rule may already exist (${ADMIN_UI_PORT}/tcp from ALB)"

    ok "Security group rules configured"
  fi

  echo ""

  # ----------------------------------------------------------
  # Step 2.4: Create Target Groups
  # ----------------------------------------------------------
  info "Step 2.4: Target groups..."
  echo ""

  ADAPTER_TG_ARN="$(get_state ADAPTER_TG_ARN || true)"
  ADMIN_TG_ARN="$(get_state ADMIN_TG_ARN || true)"

  if [[ -n "$ADAPTER_TG_ARN" && -n "$ADMIN_TG_ARN" ]]; then
    ok "Target groups already exist"
    printf "  Adapter: ${BOLD}%s${NC}\n" "$ADAPTER_TG_ARN"
    printf "  Admin:   ${BOLD}%s${NC}\n" "$ADMIN_TG_ARN"
  else
    # Adapter target group
    if [[ -z "$ADAPTER_TG_ARN" ]]; then
      info "Creating target group: ${mcp_prefix}-tg (port ${GATEWAY_PORT})..."

      ADAPTER_TG_ARN=$(aws elbv2 create-target-group \
        --region "$AWS_REGION" \
        --name "${mcp_prefix}-tg" \
        --protocol HTTP \
        --port "$GATEWAY_PORT" \
        --vpc-id "$VPC_ID" \
        --target-type instance \
        --health-check-path "/.well-known/oauth-protected-resource" \
        --health-check-interval-seconds 30 \
        --health-check-timeout-seconds 10 \
        --healthy-threshold-count 2 \
        --unhealthy-threshold-count 3 \
        --query 'TargetGroups[0].TargetGroupArn' \
        --output text 2>/dev/null) \
        || die "Failed to create adapter target group."

      ok "Adapter TG: ${ADAPTER_TG_ARN}"
      save_state ADAPTER_TG_ARN "$ADAPTER_TG_ARN"
    fi

    # Admin UI target group
    if [[ -z "$ADMIN_TG_ARN" ]]; then
      info "Creating target group: ${admin_prefix}-tg (port ${ADMIN_UI_PORT})..."

      ADMIN_TG_ARN=$(aws elbv2 create-target-group \
        --region "$AWS_REGION" \
        --name "${admin_prefix}-tg" \
        --protocol HTTP \
        --port "$ADMIN_UI_PORT" \
        --vpc-id "$VPC_ID" \
        --target-type instance \
        --health-check-path "/" \
        --health-check-interval-seconds 30 \
        --health-check-timeout-seconds 10 \
        --healthy-threshold-count 2 \
        --unhealthy-threshold-count 3 \
        --query 'TargetGroups[0].TargetGroupArn' \
        --output text 2>/dev/null) \
        || die "Failed to create admin UI target group."

      ok "Admin TG: ${ADMIN_TG_ARN}"
      save_state ADMIN_TG_ARN "$ADMIN_TG_ARN"
    fi

    # Register EC2 instance in both target groups
    info "Registering instance ${EC2_INSTANCE_ID} in target groups..."

    aws elbv2 register-targets \
      --region "$AWS_REGION" \
      --target-group-arn "$ADAPTER_TG_ARN" \
      --targets "Id=${EC2_INSTANCE_ID}" 2>/dev/null \
      || die "Failed to register instance in adapter target group."

    aws elbv2 register-targets \
      --region "$AWS_REGION" \
      --target-group-arn "$ADMIN_TG_ARN" \
      --targets "Id=${EC2_INSTANCE_ID}" 2>/dev/null \
      || die "Failed to register instance in admin UI target group."

    ok "Instance registered in both target groups"
  fi

  echo ""

  # ----------------------------------------------------------
  # Step 2.5: Create ALB
  # ----------------------------------------------------------
  info "Step 2.5: Application Load Balancer..."
  echo ""

  ALB_ARN="$(get_state ALB_ARN || true)"
  ALB_DNS="$(get_state ALB_DNS || true)"
  ALB_ZONE_ID="$(get_state ALB_ZONE_ID || true)"

  if [[ -n "$ALB_ARN" ]]; then
    ok "ALB already exists: ${ALB_DNS}"
  else
    [[ -z "$PUBLIC_SUBNET_1" || -z "$PUBLIC_SUBNET_2" ]] && \
      die "Public subnets not found in state. Rerun Phase 1."

    info "Creating internet-facing ALB: ${mcp_prefix}-alb..."

    local alb_json
    alb_json=$(aws elbv2 create-load-balancer \
      --region "$AWS_REGION" \
      --name "${mcp_prefix}-alb" \
      --type application \
      --scheme internet-facing \
      --subnets "$PUBLIC_SUBNET_1" "$PUBLIC_SUBNET_2" \
      --security-groups "$ALB_SG_ID" \
      --tags Key=Name,Value=${mcp_prefix}-alb Key=Project,Value=okta-mcp-adapter \
      --query 'LoadBalancers[0]' \
      --output json 2>/dev/null) \
      || die "Failed to create ALB. Check IAM permissions (elasticloadbalancing:CreateLoadBalancer)."

    ALB_ARN=$(echo "$alb_json" | jq -r '.LoadBalancerArn')
    ALB_DNS=$(echo "$alb_json" | jq -r '.DNSName')
    ALB_ZONE_ID=$(echo "$alb_json" | jq -r '.CanonicalHostedZoneId')

    save_state ALB_ARN "$ALB_ARN"
    save_state ALB_DNS "$ALB_DNS"
    save_state ALB_ZONE_ID "$ALB_ZONE_ID"

    ok "ALB created: ${ALB_DNS}"

    # Wait for ALB to become active
    info "Waiting for ALB to become active..."
    local elapsed=0 timeout=120
    while [[ $elapsed -lt $timeout ]]; do
      local alb_state
      alb_state=$(aws elbv2 describe-load-balancers \
        --region "$AWS_REGION" \
        --load-balancer-arns "$ALB_ARN" \
        --query 'LoadBalancers[0].State.Code' \
        --output text 2>/dev/null || echo "unknown")

      if [[ "$alb_state" == "active" ]]; then
        ok "ALB is active"
        break
      fi

      if [[ "$alb_state" == "failed" ]]; then
        die "ALB creation failed. Check AWS Console for details."
      fi

      printf "\r  Waiting for ALB... (state: %s, elapsed: %ds)    " "$alb_state" "$elapsed"
      sleep 10
      elapsed=$(( elapsed + 10 ))
    done

    if [[ $elapsed -ge $timeout ]]; then
      echo ""
      die "ALB did not become active within ${timeout}s."
    fi
  fi

  echo ""

  # ----------------------------------------------------------
  # Step 2.6: Create Listeners
  # ----------------------------------------------------------
  info "Step 2.6: ALB listeners..."
  echo ""

  HTTPS_LISTENER_ARN="$(get_state HTTPS_LISTENER_ARN || true)"

  if [[ -n "$HTTPS_LISTENER_ARN" ]]; then
    ok "Listeners already configured"
  else
    # Default action: 404 JSON for unknown hosts
    local default_body
    default_body="{\"error\":\"unknown_host\",\"message\":\"Use ${MCP_HOSTNAME} or ${ADMIN_HOSTNAME}\"}"

    # HTTPS listener (443)
    info "Creating HTTPS listener (443)..."

    HTTPS_LISTENER_ARN=$(aws elbv2 create-listener \
      --region "$AWS_REGION" \
      --load-balancer-arn "$ALB_ARN" \
      --protocol HTTPS \
      --port 443 \
      --ssl-policy "ELBSecurityPolicy-TLS13-1-2-2021-06" \
      --certificates "CertificateArn=${ACM_CERT_ARN}" \
      --default-actions "Type=fixed-response,FixedResponseConfig={StatusCode=404,ContentType=application/json,MessageBody='${default_body}'}" \
      --query 'Listeners[0].ListenerArn' \
      --output text 2>/dev/null) \
      || die "Failed to create HTTPS listener. Check IAM permissions."

    ok "HTTPS listener: ${HTTPS_LISTENER_ARN}"
    save_state HTTPS_LISTENER_ARN "$HTTPS_LISTENER_ARN"

    # HTTP listener (80) — redirect to HTTPS
    info "Creating HTTP listener (80 → 301 HTTPS redirect)..."

    aws elbv2 create-listener \
      --region "$AWS_REGION" \
      --load-balancer-arn "$ALB_ARN" \
      --protocol HTTP \
      --port 80 \
      --default-actions 'Type=redirect,RedirectConfig={Protocol=HTTPS,Port=443,StatusCode=HTTP_301}' \
      2>/dev/null \
      || die "Failed to create HTTP redirect listener."

    ok "HTTP→HTTPS redirect listener created"

    # Create host-based routing rules on the HTTPS listener
    info "Creating routing rules..."

    # Rule: MCP hostname → adapter target group
    aws elbv2 create-rule \
      --region "$AWS_REGION" \
      --listener-arn "$HTTPS_LISTENER_ARN" \
      --priority 10 \
      --conditions "Field=host-header,Values=${MCP_HOSTNAME}" \
      --actions "Type=forward,TargetGroupArn=${ADAPTER_TG_ARN}" \
      2>/dev/null \
      || die "Failed to create MCP routing rule."

    ok "Rule: ${MCP_HOSTNAME} → adapter"

    # Rule: Admin hostname → admin UI target group
    aws elbv2 create-rule \
      --region "$AWS_REGION" \
      --listener-arn "$HTTPS_LISTENER_ARN" \
      --priority 20 \
      --conditions "Field=host-header,Values=${ADMIN_HOSTNAME}" \
      --actions "Type=forward,TargetGroupArn=${ADMIN_TG_ARN}" \
      2>/dev/null \
      || die "Failed to create admin UI routing rule."

    ok "Rule: ${ADMIN_HOSTNAME} → admin UI"

    # Increase ALB idle timeout to 300s for SSE/MCP streaming
    info "Setting ALB idle timeout to 300s (for SSE/MCP streaming)..."

    aws elbv2 modify-load-balancer-attributes \
      --region "$AWS_REGION" \
      --load-balancer-arn "$ALB_ARN" \
      --attributes Key=idle_timeout.timeout_seconds,Value=300 \
      2>/dev/null \
      || warn "Could not set idle timeout — default 60s will apply"

    ok "ALB idle timeout set to 300s"
  fi

  # Update .env with ALB/domain values
  if [[ -f "$SCRIPT_DIR/.env" ]]; then
    _env_set DOMAIN "$DOMAIN"
    _env_set MCP_HOSTNAME "$MCP_HOSTNAME"
    _env_set ADMIN_HOSTNAME "$ADMIN_HOSTNAME"
    _env_set ALB_ARN "$ALB_ARN"
    _env_set ALB_DNS "$ALB_DNS"
    _env_set ALB_ZONE_ID "$ALB_ZONE_ID"
    _env_set ALB_SG_ID "$ALB_SG_ID"
    _env_set HTTPS_LISTENER_ARN "$HTTPS_LISTENER_ARN"
    _env_set ADAPTER_TG_ARN "$ADAPTER_TG_ARN"
    _env_set ADMIN_TG_ARN "$ADMIN_TG_ARN"
    _env_set ACM_CERT_ARN "$ACM_CERT_ARN"
  fi

  echo ""

  save_state PHASE2_COMPLETE "true"

  printf "${GREEN}┌──────────────────────────────────────────────────────────────┐${NC}\n"
  printf "${GREEN}│${NC}  ${BOLD}✓ Phase 2 complete — ALB infrastructure provisioned${NC}         ${GREEN}│${NC}\n"
  printf "${GREEN}│${NC}                                                              ${GREEN}│${NC}\n"
  printf "${GREEN}│${NC}  ALB DNS:     ${CYAN}%-46s${NC} ${GREEN}│${NC}\n" "$ALB_DNS"
  printf "${GREEN}│${NC}  MCP target:  ${CYAN}%-46s${NC} ${GREEN}│${NC}\n" "$MCP_HOSTNAME"
  printf "${GREEN}│${NC}  Admin target: ${CYAN}%-45s${NC} ${GREEN}│${NC}\n" "$ADMIN_HOSTNAME"
  printf "${GREEN}│${NC}                                                              ${GREEN}│${NC}\n"
  printf "${GREEN}│${NC}  Next: ${BOLD}./awsetup.sh --phase 3${NC} for DNS + final cutover        ${GREEN}│${NC}\n"
  printf "${GREEN}└──────────────────────────────────────────────────────────────┘${NC}\n"
  echo ""
}

# ============================================================
#  PHASE 3: Hostname Routing + Verification
# ============================================================

phase3() {
  load_state
  [[ "$(get_state PHASE2_COMPLETE)" == "true" ]] || die "Phase 2 not complete. Run: ./awsetup.sh --phase 2"

  # Reload state vars
  AWS_REGION="$(get_state AWS_REGION)"
  EC2_INSTANCE_ID="$(get_state EC2_INSTANCE_ID)"
  VPC_ID="$(get_state VPC_ID)"
  DOMAIN="$(get_state DOMAIN)"
  MCP_HOSTNAME="$(get_state MCP_HOSTNAME)"
  ADMIN_HOSTNAME="$(get_state ADMIN_HOSTNAME)"
  ALB_ARN="$(get_state ALB_ARN)"
  ALB_DNS="$(get_state ALB_DNS)"
  ALB_ZONE_ID="$(get_state ALB_ZONE_ID)"
  ALB_SG_ID="$(get_state ALB_SG_ID)"
  HTTPS_LISTENER_ARN="$(get_state HTTPS_LISTENER_ARN)"
  ADAPTER_TG_ARN="$(get_state ADAPTER_TG_ARN)"
  ADMIN_TG_ARN="$(get_state ADMIN_TG_ARN)"
  ACM_CERT_ARN="$(get_state ACM_CERT_ARN)"
  mcp_prefix="$(get_state MCP_PREFIX || echo mcp)"
  admin_prefix="$(get_state ADMIN_PREFIX || echo admin)"

  # Load Admin UI OIDC values from existing .env (for reruns / non-interactive)
  ADMIN_UI_OKTA_DOMAIN="${ADMIN_UI_OKTA_DOMAIN:-$(grep "^ADMIN_UI_OKTA_DOMAIN=" "$SCRIPT_DIR/.env" 2>/dev/null | cut -d= -f2- || true)}"
  ADMIN_UI_OKTA_CLIENT_ID="${ADMIN_UI_OKTA_CLIENT_ID:-$(grep "^ADMIN_UI_OKTA_CLIENT_ID=" "$SCRIPT_DIR/.env" 2>/dev/null | cut -d= -f2- || true)}"
  ADMIN_UI_OKTA_CLIENT_SECRET="${ADMIN_UI_OKTA_CLIENT_SECRET:-$(grep "^ADMIN_UI_OKTA_CLIENT_SECRET=" "$SCRIPT_DIR/.env" 2>/dev/null | cut -d= -f2- || true)}"

  [[ -z "$DOMAIN" ]]             && die "DOMAIN missing from state. Rerun Phase 2."
  [[ -z "$HTTPS_LISTENER_ARN" ]] && die "HTTPS_LISTENER_ARN missing from state. Rerun Phase 2."
  [[ -z "$ALB_DNS" ]]            && die "ALB_DNS missing from state. Rerun Phase 2."

  echo ""
  printf "${CYAN}┌──────────────────────────────────────────────────┐${NC}\n"
  printf "${CYAN}│${NC}  ${BOLD}Phase 3: Hostname Routing + Verification${NC}         ${CYAN}│${NC}\n"
  printf "${CYAN}└──────────────────────────────────────────────────┘${NC}\n"
  echo ""

  # ----------------------------------------------------------
  # Step 3.1: Create / Verify Routing Rules
  # ----------------------------------------------------------
  info "Step 3.1: Verifying listener routing rules..."
  echo ""

  # Check if rules already exist (Phase 2 creates them in Step 2.6)
  local existing_rules
  existing_rules=$(aws elbv2 describe-rules \
    --region "$AWS_REGION" \
    --listener-arn "$HTTPS_LISTENER_ARN" \
    --query 'Rules[?!IsDefault].Priority' \
    --output text 2>/dev/null || true)

  local has_mcp_rule=false has_admin_rule=false
  if [[ -n "$existing_rules" ]]; then
    # Check for rules matching our hostnames
    local rules_json
    rules_json=$(aws elbv2 describe-rules \
      --region "$AWS_REGION" \
      --listener-arn "$HTTPS_LISTENER_ARN" \
      --query 'Rules[?!IsDefault]' \
      --output json 2>/dev/null || echo "[]")

    if echo "$rules_json" | grep -q "$MCP_HOSTNAME" 2>/dev/null; then
      has_mcp_rule=true
    fi
    if echo "$rules_json" | grep -q "$ADMIN_HOSTNAME" 2>/dev/null; then
      has_admin_rule=true
    fi
  fi

  if $has_mcp_rule && $has_admin_rule; then
    ok "Routing rules already exist"
    printf "  Priority 10: ${BOLD}%s${NC} → adapter\n" "$MCP_HOSTNAME"
    printf "  Priority 20: ${BOLD}%s${NC} → admin UI\n" "$ADMIN_HOSTNAME"
  else
    # Create missing rules
    if ! $has_mcp_rule; then
      info "Creating rule: ${MCP_HOSTNAME} → adapter (priority 10)..."
      aws elbv2 create-rule \
        --region "$AWS_REGION" \
        --listener-arn "$HTTPS_LISTENER_ARN" \
        --priority 10 \
        --conditions "Field=host-header,Values=${MCP_HOSTNAME}" \
        --actions "Type=forward,TargetGroupArn=${ADAPTER_TG_ARN}" \
        2>/dev/null \
        || die "Failed to create MCP routing rule."
      ok "Rule: ${MCP_HOSTNAME} → adapter"
    fi

    if ! $has_admin_rule; then
      info "Creating rule: ${ADMIN_HOSTNAME} → admin UI (priority 20)..."
      aws elbv2 create-rule \
        --region "$AWS_REGION" \
        --listener-arn "$HTTPS_LISTENER_ARN" \
        --priority 20 \
        --conditions "Field=host-header,Values=${ADMIN_HOSTNAME}" \
        --actions "Type=forward,TargetGroupArn=${ADMIN_TG_ARN}" \
        2>/dev/null \
        || die "Failed to create admin UI routing rule."
      ok "Rule: ${ADMIN_HOSTNAME} → admin UI"
    fi
  fi

  echo ""

  # ----------------------------------------------------------
  # Step 3.2: Enable Sticky Sessions
  # ----------------------------------------------------------
  info "Step 3.2: Enabling sticky sessions..."
  echo ""

  aws elbv2 modify-target-group-attributes \
    --region "$AWS_REGION" \
    --target-group-arn "$ADAPTER_TG_ARN" \
    --attributes \
      Key=stickiness.enabled,Value=true \
      Key=stickiness.type,Value=lb_cookie \
      Key=stickiness.lb_cookie.duration_seconds,Value=86400 \
    2>/dev/null \
    || warn "Could not enable sticky sessions — MCP streaming may be affected"

  ok "Sticky sessions enabled for MCP streaming (24h cookie)"
  echo ""

  # ----------------------------------------------------------
  # Step 3.3: Update Adapter Configuration
  # ----------------------------------------------------------
  info "Step 3.3: Updating adapter configuration..."
  echo ""

  local new_gateway_url="https://${MCP_HOSTNAME}"
  _env_set GATEWAY_BASE_URL "$new_gateway_url"
  ok "GATEWAY_BASE_URL → ${new_gateway_url}"

  info "Restarting adapter with new configuration..."
  docker compose restart okta-agent-mcp-adapter \
    || die "Failed to restart adapter container."

  # Wait for health
  local elapsed=0 timeout=60
  printf "  Waiting for adapter health..."
  while [[ $elapsed -lt $timeout ]]; do
    if curl -sf "http://localhost:${GATEWAY_PORT}/.well-known/oauth-protected-resource" >/dev/null 2>&1; then
      printf " ${GREEN}✓${NC}\n"
      break
    fi
    sleep 2
    elapsed=$(( elapsed + 2 ))
  done

  if [[ $elapsed -ge $timeout ]]; then
    printf " ${RED}✗${NC}\n"
    warn "Adapter did not pass health check within ${timeout}s"
    warn "Check logs: docker compose logs okta-agent-mcp-adapter"
  fi

  echo ""

  # ----------------------------------------------------------
  # Step 3.4: Update Admin UI
  # ----------------------------------------------------------
  info "Step 3.4: Updating admin UI..."
  echo ""

  # Update the API URL the admin UI uses to reach the adapter
  _env_set NEXT_PUBLIC_API_URL "https://${MCP_HOSTNAME}"

  # Configure Okta OIDC for Admin UI login
  echo ""
  info "Configure Okta OIDC for Admin UI login."
  info "Redirect URI for your Okta OIDC app: ${CYAN}https://${ADMIN_HOSTNAME}/api/auth/callback/okta${NC}"
  echo ""
  ni_prompt_required ADMIN_UI_OKTA_DOMAIN "Admin UI Okta Domain (e.g., dev-12345.okta.com)"
  ni_prompt_required ADMIN_UI_OKTA_CLIENT_ID "Admin UI Okta OIDC Client ID"
  ni_prompt_required ADMIN_UI_OKTA_CLIENT_SECRET "Admin UI Okta OIDC Client Secret"

  _env_set ADMIN_UI_NEXTAUTH_URL "https://${ADMIN_HOSTNAME}"
  _env_set ADMIN_UI_OKTA_DOMAIN "$ADMIN_UI_OKTA_DOMAIN"
  _env_set ADMIN_UI_OKTA_CLIENT_ID "$ADMIN_UI_OKTA_CLIENT_ID"
  _env_set ADMIN_UI_OKTA_CLIENT_SECRET "$ADMIN_UI_OKTA_CLIENT_SECRET"
  echo ""

  info "Recreating admin UI container..."
  docker compose stop admin-ui 2>/dev/null || true
  docker compose up -d admin-ui \
    || die "Failed to start admin UI container."

  # Wait for health
  elapsed=0 timeout=60
  printf "  Waiting for admin UI health..."
  while [[ $elapsed -lt $timeout ]]; do
    local code
    code=$(curl -sf -o /dev/null -w '%{http_code}' "http://localhost:${ADMIN_UI_PORT}/" 2>/dev/null || true)
    if [[ "$code" == "200" || "$code" == "304" ]]; then
      printf " ${GREEN}✓${NC}\n"
      break
    fi
    sleep 2
    elapsed=$(( elapsed + 2 ))
  done

  if [[ $elapsed -ge $timeout ]]; then
    printf " ${RED}✗${NC}\n"
    warn "Admin UI did not respond within ${timeout}s"
  fi

  echo ""

  # ----------------------------------------------------------
  # Step 3.5: DNS Instructions
  # ----------------------------------------------------------
  info "Step 3.5: DNS configuration..."
  echo ""

  printf "${YELLOW}┌──────────────────────────────────────────────────────────────┐${NC}\n"
  printf "${YELLOW}│${NC}  ${BOLD}ACTION REQUIRED: Add these DNS CNAME records${NC}                ${YELLOW}│${NC}\n"
  printf "${YELLOW}├──────────────────────────────────────────────────────────────┤${NC}\n"
  printf "${YELLOW}│${NC}                                                              ${YELLOW}│${NC}\n"
  printf "${YELLOW}│${NC}  ${CYAN}%-30s${NC} → ${BOLD}%s${NC}\n" "$MCP_HOSTNAME" "$ALB_DNS"
  printf "${YELLOW}│${NC}  ${CYAN}%-30s${NC} → ${BOLD}%s${NC}\n" "$ADMIN_HOSTNAME" "$ALB_DNS"
  printf "${YELLOW}│${NC}                                                              ${YELLOW}│${NC}\n"
  printf "${YELLOW}│${NC}  Type: CNAME                                                 ${YELLOW}│${NC}\n"
  printf "${YELLOW}│${NC}  TTL:  300 (recommended)                                     ${YELLOW}│${NC}\n"
  printf "${YELLOW}│${NC}                                                              ${YELLOW}│${NC}\n"
  printf "${YELLOW}└──────────────────────────────────────────────────────────────┘${NC}\n"
  echo ""

  local dns_resolved=false
  if ! $NON_INTERACTIVE; then
    printf "${BOLD}Press ENTER after creating the DNS records (or type 'skip' to continue)...${NC} "
    local dns_reply=""
    read -r dns_reply

    if [[ "$dns_reply" != "skip" ]]; then
      info "Checking DNS propagation..."
      local dns_elapsed=0 dns_timeout=300

      while [[ $dns_elapsed -lt $dns_timeout ]]; do
        local resolved_mcp resolved_admin
        resolved_mcp=$(dig +short "$MCP_HOSTNAME" CNAME 2>/dev/null | head -1 || true)
        resolved_admin=$(dig +short "$ADMIN_HOSTNAME" CNAME 2>/dev/null | head -1 || true)

        # Also try host command as fallback
        if [[ -z "$resolved_mcp" ]]; then
          resolved_mcp=$(host "$MCP_HOSTNAME" 2>/dev/null | grep -o 'is an alias for.*' | head -1 || true)
        fi

        if [[ -n "$resolved_mcp" && -n "$resolved_admin" ]]; then
          ok "DNS resolved for both hostnames"
          dns_resolved=true
          break
        fi

        printf "\r  Waiting for DNS propagation... (elapsed: %ds, timeout: %ds)" "$dns_elapsed" "$dns_timeout"
        sleep 10
        dns_elapsed=$(( dns_elapsed + 10 ))
      done

      echo ""
      if ! $dns_resolved; then
        warn "DNS not yet resolved — this can take a few minutes"
        warn "Verification will fall back to ALB DNS with Host headers"
      fi
    fi
  fi

  echo ""

  # ----------------------------------------------------------
  # Step 3.6: End-to-End Verification
  # ----------------------------------------------------------
  info "Step 3.6: Running end-to-end verification..."
  echo ""

  local tests_passed=0 tests_total=5

  # Helper: try real hostname first, fall back to ALB with Host header
  _curl_https() {
    local hostname="$1" path="$2"
    shift 2
    # Try real hostname
    if $dns_resolved; then
      curl -sf "$@" "https://${hostname}${path}" 2>/dev/null && return 0
    fi
    # Fall back to ALB DNS with Host header
    curl -sf "$@" --insecure -H "Host: ${hostname}" "https://${ALB_DNS}${path}" 2>/dev/null
  }

  # Test 1: HTTPS gateway metadata
  printf "  [1/5] HTTPS gateway metadata........"
  if _curl_https "$MCP_HOSTNAME" "/.well-known/oauth-protected-resource" >/dev/null; then
    printf "${GREEN}✓ passed${NC}\n"
    tests_passed=$(( tests_passed + 1 ))
  else
    printf "${RED}✗ failed${NC}\n"
  fi

  # Test 2: HTTPS admin UI
  printf "  [2/5] HTTPS admin UI................"
  local admin_code
  admin_code=$(_curl_https "$ADMIN_HOSTNAME" "/" -o /dev/null -w '%{http_code}' 2>/dev/null || true)
  if [[ "$admin_code" == "200" || "$admin_code" == "304" ]]; then
    printf "${GREEN}✓ passed${NC}\n"
    tests_passed=$(( tests_passed + 1 ))
  else
    printf "${RED}✗ failed${NC} (HTTP ${admin_code:-timeout})\n"
  fi

  # Test 3: HTTP → HTTPS redirect
  printf "  [3/5] HTTP→HTTPS redirect..........."
  local redirect_code
  redirect_code=$(curl -sf -o /dev/null -w '%{http_code}' "http://${ALB_DNS}/" 2>/dev/null || true)
  if [[ "$redirect_code" == "301" ]]; then
    printf "${GREEN}✓ passed${NC}\n"
    tests_passed=$(( tests_passed + 1 ))
  else
    printf "${RED}✗ failed${NC} (HTTP ${redirect_code:-timeout})\n"
  fi

  # Test 4: Target group health
  printf "  [4/5] Target group health..........."
  local adapter_health admin_health
  adapter_health=$(aws elbv2 describe-target-health \
    --region "$AWS_REGION" \
    --target-group-arn "$ADAPTER_TG_ARN" \
    --query 'TargetHealthDescriptions[0].TargetHealth.State' \
    --output text 2>/dev/null || echo "unknown")
  admin_health=$(aws elbv2 describe-target-health \
    --region "$AWS_REGION" \
    --target-group-arn "$ADMIN_TG_ARN" \
    --query 'TargetHealthDescriptions[0].TargetHealth.State' \
    --output text 2>/dev/null || echo "unknown")

  if [[ "$adapter_health" == "healthy" && "$admin_health" == "healthy" ]]; then
    printf "${GREEN}✓ passed${NC}\n"
    tests_passed=$(( tests_passed + 1 ))
  else
    printf "${RED}✗ failed${NC} (adapter: ${adapter_health}, admin: ${admin_health})\n"
  fi

  # Test 5: Admin API requires Okta auth (returns 401 without bearer)
  printf "  [5/5] Admin API requires auth......."
  local admin_status
  admin_status=$(_curl_https "$MCP_HOSTNAME" "/api/admin/agents" -o /dev/null -w '%{http_code}' 2>/dev/null || echo "000")
  if [[ "$admin_status" == "401" ]]; then
    printf "${GREEN}✓ passed${NC}\n"
    tests_passed=$(( tests_passed + 1 ))
  else
    printf "${RED}✗ failed${NC} (got ${admin_status}, expected 401)\n"
  fi

  echo ""

  if [[ $tests_passed -eq $tests_total ]]; then
    ok "Verification: ${tests_passed}/${tests_total} passed"
  elif [[ $tests_passed -ge 3 ]]; then
    warn "Verification: ${tests_passed}/${tests_total} passed (some failures may resolve after DNS propagation)"
  else
    fail "Verification: ${tests_passed}/${tests_total} passed"
    warn "Check: docker compose logs, aws elbv2 describe-target-health, DNS records"
  fi

  echo ""

  # ----------------------------------------------------------
  # Step 3.7: Write final state to .env
  # ----------------------------------------------------------
  info "Writing final configuration to .env..."

  _env_set GATEWAY_BASE_URL "https://${MCP_HOSTNAME}"
  _env_set DOMAIN "$DOMAIN"
  _env_set MCP_HOSTNAME "$MCP_HOSTNAME"
  _env_set ADMIN_HOSTNAME "$ADMIN_HOSTNAME"
  _env_set ALB_ARN "$ALB_ARN"
  _env_set ALB_DNS "$ALB_DNS"
  _env_set ALB_ZONE_ID "$ALB_ZONE_ID"
  _env_set ALB_SG_ID "$ALB_SG_ID"
  _env_set HTTPS_LISTENER_ARN "$HTTPS_LISTENER_ARN"
  _env_set ADAPTER_TG_ARN "$ADAPTER_TG_ARN"
  _env_set ADMIN_TG_ARN "$ADMIN_TG_ARN"
  _env_set ACM_CERT_ARN "$ACM_CERT_ARN"
  _env_set EC2_INSTANCE_ID "$EC2_INSTANCE_ID"
  _env_set VPC_ID "$VPC_ID"
  _env_set AWS_REGION "$AWS_REGION"
  _env_set ADMIN_UI_NEXTAUTH_URL "https://${ADMIN_HOSTNAME}"
  _env_set ADMIN_UI_OKTA_DOMAIN "$ADMIN_UI_OKTA_DOMAIN"
  _env_set ADMIN_UI_OKTA_CLIENT_ID "$ADMIN_UI_OKTA_CLIENT_ID"
  _env_set ADMIN_UI_OKTA_CLIENT_SECRET "$ADMIN_UI_OKTA_CLIENT_SECRET"

  ok ".env updated with all AWS resource values"
  save_state PHASE3_COMPLETE "true"

  echo ""

  # ----------------------------------------------------------
  # Step 3.7: Final Summary
  # ----------------------------------------------------------
  printf "${GREEN}╔══════════════════════════════════════════════════════════════╗${NC}\n"
  printf "${GREEN}║${NC}              ${BOLD}Deployment Complete!${NC}                            ${GREEN}║${NC}\n"
  printf "${GREEN}╚══════════════════════════════════════════════════════════════╝${NC}\n"
  echo ""
  printf "  ${BOLD}Gateway:${NC}      ${CYAN}https://%s${NC}\n" "$MCP_HOSTNAME"
  printf "  ${BOLD}Admin UI:${NC}     ${CYAN}https://%s${NC}  (sign in with Okta)\n" "$ADMIN_HOSTNAME"
  echo ""
  printf "  ${BOLD}Okta Redirect URI${NC} (add to your Okta OIDC app):\n"
  printf "    ${CYAN}https://%s/oauth2/callback${NC}\n" "$MCP_HOSTNAME"
  echo ""
  printf "  ${BOLD}Connect Claude Code:${NC}\n"
  printf "    ${CYAN}MCP_CLIENT_SECRET='...' claude mcp add okta-gateway \\\\${NC}\n"
  printf "    ${CYAN}  --url https://%s \\\\${NC}\n" "$MCP_HOSTNAME"
  printf "    ${CYAN}  --client-id YOUR_CLIENT_ID \\\\${NC}\n"
  printf "    ${CYAN}  --client-secret \$MCP_CLIENT_SECRET \\\\${NC}\n"
  printf "    ${CYAN}  --callback-port ${DCR_CALLBACK_PORT}${NC}\n"
  echo ""
  printf "  ${BOLD}Management:${NC}\n"
  printf "    ./status.sh       — Health dashboard\n"
  printf "    ./teardown.sh     — Remove all AWS resources\n"
  echo ""
}

# ============================================================
#  Phase dispatch
# ============================================================

case "$PHASE" in
  1)
    phase1
    ;;
  2)
    phase2
    ;;
  3)
    phase3
    ;;
  all)
    phase1
    phase2
    phase3
    ;;
esac
