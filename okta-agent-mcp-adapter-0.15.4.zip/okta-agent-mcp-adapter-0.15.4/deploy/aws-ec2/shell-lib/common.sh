#!/usr/bin/env bash
# =============================================================
# common.sh — Shared functions for AWS EC2 deployment scripts
# =============================================================
# Source this file, do not execute it directly.
# Usage: source "$(dirname "$0")/shell-lib/common.sh"
# =============================================================

# ---- Color constants ----
# Respect NO_COLOR (https://no-color.org/) and detect non-TTY output
if [[ -n "${NO_COLOR:-}" ]] || [[ ! -t 1 ]]; then
  RED='' GREEN='' YELLOW='' CYAN='' BOLD='' NC=''
else
  RED='\033[0;31m'
  GREEN='\033[0;32m'
  YELLOW='\033[1;33m'
  CYAN='\033[0;36m'
  BOLD='\033[1m'
  NC='\033[0m'
fi

# ---- Logging ----

info()  { printf "${CYAN}[INFO]${NC}  %b\n" "$*"; }
ok()    { printf "${GREEN}[  OK]${NC}  %b\n" "$*"; }
warn()  { printf "${YELLOW}[WARN]${NC}  %b\n" "$*" >&2; }
fail()  { printf "${RED}[FAIL]${NC}  %b\n" "$*" >&2; }
die()   { fail "$@"; exit 1; }

# ---- Prompts ----

# prompt_required VAR_NAME PROMPT_TEXT
#   Asks until a non-empty value is provided, stores in the named variable.
prompt_required() {
  local var_name="$1" prompt_text="$2" value=""
  while [[ -z "$value" ]]; do
    printf "${BOLD}%s${NC}: " "$prompt_text"
    read -r value
    [[ -z "$value" ]] && warn "This field is required."
  done
  eval "$var_name=\"\$value\""
}

# prompt_default VAR_NAME PROMPT_TEXT DEFAULT_VALUE
#   Asks for input with a default shown in brackets.
prompt_default() {
  local var_name="$1" prompt_text="$2" default="$3" value=""
  printf "${BOLD}%s${NC} [${CYAN}%s${NC}]: " "$prompt_text" "$default"
  read -r value
  value="${value:-$default}"
  eval "$var_name=\"\$value\""
}

# prompt_yesno PROMPT_TEXT [DEFAULT: y|n]
#   Returns 0 for yes, 1 for no.
prompt_yesno() {
  local prompt_text="$1" default="${2:-y}" reply=""
  local hint="Y/n"
  [[ "$default" == "n" ]] && hint="y/N"
  printf "${BOLD}%s${NC} [${CYAN}%s${NC}]: " "$prompt_text" "$hint"
  read -r reply
  reply="${reply:-$default}"
  [[ "$reply" =~ ^[Yy] ]]
}

# ---- Validation ----

# validate_command CMD [INSTALL_HINT]
#   Exits if CMD is not on PATH.
validate_command() {
  local cmd="$1" hint="${2:-}"
  if ! command -v "$cmd" &>/dev/null; then
    [[ -n "$hint" ]] && die "'$cmd' is required but not found. $hint"
    die "'$cmd' is required but not found."
  fi
}

# check_port_available PORT
#   Returns 0 if port is free, 1 if in use.
check_port_available() {
  local port="$1"
  if ss -tlnp 2>/dev/null | grep -q ":${port} " || \
     lsof -iTCP:"${port}" -sTCP:LISTEN &>/dev/null; then
    return 1
  fi
  return 0
}

# ---- State management ----
# State is stored in .awsetup.state (key=value, one per line).

STATE_FILE="${STATE_FILE:-.awsetup.state}"

# save_state KEY VALUE
#   Append or update a key=value pair in the state file.
save_state() {
  local key="$1" value="$2"
  if [[ -f "$STATE_FILE" ]] && grep -q "^${key}=" "$STATE_FILE" 2>/dev/null; then
    # Update existing key (portable sed in-place)
    local tmp
    tmp=$(mktemp)
    sed "s|^${key}=.*|${key}=${value}|" "$STATE_FILE" > "$tmp" && mv "$tmp" "$STATE_FILE"
  else
    echo "${key}=${value}" >> "$STATE_FILE"
  fi
}

# load_state
#   Source the state file into the current environment.
load_state() {
  [[ -f "$STATE_FILE" ]] && source "$STATE_FILE"
}

# get_state KEY
#   Print the value for KEY or empty string.
get_state() {
  local key="$1"
  if [[ -f "$STATE_FILE" ]]; then
    grep "^${key}=" "$STATE_FILE" 2>/dev/null | head -1 | cut -d= -f2-
  fi
}

# ---- AWS helpers (IMDSv2) ----

# _imds_token — obtain a short-lived IMDSv2 token
_imds_token() {
  curl -sf -X PUT "http://169.254.169.254/latest/api/token" \
    -H "X-aws-ec2-metadata-token-ttl-seconds: 60" 2>/dev/null
}

# _imds_get PATH — fetch a metadata value using IMDSv2
_imds_get() {
  local path="$1"
  local token
  token=$(_imds_token) || return 1
  curl -sf -H "X-aws-ec2-metadata-token: ${token}" \
    "http://169.254.169.254/latest/meta-data/${path}" 2>/dev/null
}

# detect_region — from instance metadata or AWS_DEFAULT_REGION
detect_region() {
  local region=""
  # Try instance metadata first
  local az
  az=$(_imds_get "placement/availability-zone") && region="${az%?}"
  # Fall back to env or AWS CLI config
  [[ -z "$region" ]] && region="${AWS_DEFAULT_REGION:-}"
  [[ -z "$region" ]] && region="$(aws configure get region 2>/dev/null || true)"
  echo "$region"
}

# detect_instance_id — from instance metadata
detect_instance_id() {
  _imds_get "instance-id"
}

# detect_vpc_id — from instance metadata
detect_vpc_id() {
  local mac
  mac=$(_imds_get "mac") || return 1
  _imds_get "network/interfaces/macs/${mac}/vpc-id"
}

# detect_ec2_sg — primary security group from instance metadata
detect_ec2_sg() {
  local mac
  mac=$(_imds_get "mac") || return 1
  _imds_get "network/interfaces/macs/${mac}/security-group-ids" | head -1
}

# find_public_subnets VPC_ID
#   Prints 2 subnet IDs in different AZs that route to an internet gateway.
find_public_subnets() {
  local vpc_id="$1"
  local region
  region=$(detect_region)
  [[ -z "$region" ]] && die "Cannot determine AWS region."

  # Get all subnets in the VPC
  local subnets
  subnets=$(aws ec2 describe-subnets \
    --region "$region" \
    --filters "Name=vpc-id,Values=${vpc_id}" \
    --query 'Subnets[*].[SubnetId,AvailabilityZone]' \
    --output text 2>/dev/null) || return 1

  # Find route tables with an igw route
  local public_rts
  public_rts=$(aws ec2 describe-route-tables \
    --region "$region" \
    --filters "Name=vpc-id,Values=${vpc_id}" \
    --query 'RouteTables[?Routes[?GatewayId!=`null` && starts_with(GatewayId,`igw-`)]].Associations[].SubnetId' \
    --output text 2>/dev/null)

  # Also check the main route table (subnets without explicit association use it)
  local main_has_igw
  main_has_igw=$(aws ec2 describe-route-tables \
    --region "$region" \
    --filters "Name=vpc-id,Values=${vpc_id}" "Name=association.main,Values=true" \
    --query 'RouteTables[?Routes[?GatewayId!=`null` && starts_with(GatewayId,`igw-`)]].RouteTableId' \
    --output text 2>/dev/null)

  local found_azs=() found_subnets=()
  while IFS=$'\t' read -r subnet_id az; do
    [[ -z "$subnet_id" ]] && continue
    # Check if this subnet is explicitly in a public route table,
    # or if it falls back to a public main route table
    local is_public=false
    if echo "$public_rts" | grep -qw "$subnet_id" 2>/dev/null; then
      is_public=true
    elif [[ -n "$main_has_igw" ]]; then
      # Subnet uses the main RT if it has no explicit association
      local explicit
      explicit=$(aws ec2 describe-route-tables \
        --region "$region" \
        --filters "Name=association.subnet-id,Values=${subnet_id}" \
        --query 'RouteTables[0].RouteTableId' \
        --output text 2>/dev/null)
      [[ "$explicit" == "None" || -z "$explicit" ]] && is_public=true
    fi

    if $is_public; then
      # Only take one subnet per AZ
      local az_seen=false
      for seen_az in "${found_azs[@]}"; do
        [[ "$seen_az" == "$az" ]] && az_seen=true && break
      done
      if ! $az_seen; then
        found_azs+=("$az")
        found_subnets+=("$subnet_id")
        [[ ${#found_subnets[@]} -ge 2 ]] && break
      fi
    fi
  done <<< "$subnets"

  [[ ${#found_subnets[@]} -lt 2 ]] && return 1
  echo "${found_subnets[0]} ${found_subnets[1]}"
}

# ---- Docker helpers ----

# wait_for_healthy SERVICE TIMEOUT
#   Poll docker compose until the service reports healthy.
wait_for_healthy() {
  local service="$1" timeout="${2:-120}" elapsed=0
  info "Waiting for ${service} to become healthy (timeout: ${timeout}s)..."
  while [[ $elapsed -lt $timeout ]]; do
    local status
    status=$(docker compose ps --format '{{.Health}}' "$service" 2>/dev/null || true)
    if [[ "$status" == "healthy" ]]; then
      ok "${service} is healthy (${elapsed}s)"
      return 0
    fi
    sleep 2
    elapsed=$((elapsed + 2))
  done
  fail "${service} did not become healthy within ${timeout}s"
  return 1
}

# wait_for_url URL TIMEOUT
#   Poll curl until the URL returns HTTP 200.
wait_for_url() {
  local url="$1" timeout="${2:-60}" elapsed=0
  info "Waiting for ${url} (timeout: ${timeout}s)..."
  while [[ $elapsed -lt $timeout ]]; do
    local code
    code=$(curl -sf -o /dev/null -w '%{http_code}' "$url" 2>/dev/null || true)
    if [[ "$code" == "200" ]]; then
      ok "${url} is reachable (${elapsed}s)"
      return 0
    fi
    sleep 2
    elapsed=$((elapsed + 2))
  done
  fail "${url} did not return 200 within ${timeout}s"
  return 1
}
