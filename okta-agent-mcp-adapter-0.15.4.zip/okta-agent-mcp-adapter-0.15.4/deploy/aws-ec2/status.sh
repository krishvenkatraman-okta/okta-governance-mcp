#!/usr/bin/env bash
set -euo pipefail

# =============================================================
# status.sh — Operational dashboard for Okta MCP Adapter
# =============================================================

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
cd "$SCRIPT_DIR"

source "$SCRIPT_DIR/shell-lib/common.sh"

# Disable AWS CLI pager (prevents `less` from blocking automation)
export AWS_PAGER=""

# ---- Defaults ----
JSON_OUTPUT=false
QUICK_MODE=false

# ---- Parse flags ----
while [[ $# -gt 0 ]]; do
  case "$1" in
    --profile) export AWS_PROFILE="$2"; shift 2 ;;
    --json)    JSON_OUTPUT=true; shift ;;
    --quick)   QUICK_MODE=true; shift ;;
    -h|--help)
      cat <<'USAGE'
Usage: status.sh [OPTIONS]

Options:
  --profile PROFILE  AWS CLI profile to use (default: current profile)
  --json             Output machine-readable JSON
  --quick            Skip AWS checks (local Docker only)
  --help             Show this help
USAGE
      exit 0
      ;;
    *) die "Unknown flag: $1 (use --help)" ;;
  esac
done

# ---- Force no-color for JSON output ----
if $JSON_OUTPUT; then
  RED='' GREEN='' YELLOW='' CYAN='' BOLD='' NC=''
fi

# ---- Load state if available ----
HAS_STATE=false
if [[ -f "$SCRIPT_DIR/.awsetup.state" ]]; then
  HAS_STATE=true
  load_state
fi

AWS_REGION="$(get_state AWS_REGION 2>/dev/null || true)"
ALB_ARN="$(get_state ALB_ARN 2>/dev/null || true)"
ALB_DNS="$(get_state ALB_DNS 2>/dev/null || true)"
ADAPTER_TG_ARN="$(get_state ADAPTER_TG_ARN 2>/dev/null || true)"
ADMIN_TG_ARN="$(get_state ADMIN_TG_ARN 2>/dev/null || true)"
ACM_CERT_ARN="$(get_state ACM_CERT_ARN 2>/dev/null || true)"
DOMAIN="$(get_state DOMAIN 2>/dev/null || true)"
MCP_HOSTNAME="$(get_state MCP_HOSTNAME 2>/dev/null || true)"
ADMIN_HOSTNAME="$(get_state ADMIN_HOSTNAME 2>/dev/null || true)"
PHASE3_COMPLETE="$(get_state PHASE3_COMPLETE 2>/dev/null || true)"

# ---- JSON collector ----
# Build JSON incrementally; output at the end if --json
declare -A JSON_SECTIONS

_json_set() {
  local key="$1" value="$2"
  JSON_SECTIONS["$key"]="$value"
}

# ---- Helpers ----
_check_mark() {
  if [[ "$1" == "true" ]]; then
    printf "${GREEN}✓${NC}"
  else
    printf "${RED}✗${NC}"
  fi
}

_health_word() {
  if [[ "$1" == "true" ]]; then
    printf "${GREEN}healthy${NC}"
  else
    printf "${RED}unhealthy${NC}"
  fi
}

# Format seconds into human-readable uptime
_format_uptime() {
  local raw="$1"
  # docker compose gives "X hours ago", "X minutes ago", etc. — pass through
  echo "$raw"
}

# ============================================================
# 1. Docker Stack Status
# ============================================================

section_docker_stack() {
  local services=("okta-agent-mcp-adapter" "postgres" "redis" "admin-ui" "hr-mcp-server")
  local friendly=("okta-mcp-adapter" "postgres" "redis" "admin-ui" "hr-mcp-server")
  local json_containers="["

  if ! $JSON_OUTPUT; then
    echo ""
    printf "${BOLD}━━━ Docker Stack Status ━━━${NC}\n"
    echo ""
    printf "  ${BOLD}%-24s %-12s %-12s %-10s %s${NC}\n" "NAME" "STATUS" "HEALTH" "PORTS" "UPTIME"
  fi

  for i in "${!services[@]}"; do
    local svc="${services[$i]}"
    local name="${friendly[$i]}"

    local state health ports uptime
    state=$(docker compose ps --format '{{.State}}' "$svc" 2>/dev/null || echo "not found")
    health=$(docker compose ps --format '{{.Health}}' "$svc" 2>/dev/null || echo "")
    ports=$(docker compose ps --format '{{.Ports}}' "$svc" 2>/dev/null || echo "")
    uptime=$(docker compose ps --format '{{.Status}}' "$svc" 2>/dev/null || echo "")

    # Extract just the host port from port mapping
    local display_port
    display_port=$(echo "$ports" | grep -oE '0\.0\.0\.0:[0-9]+' | head -1 | cut -d: -f2 || true)
    [[ -z "$display_port" ]] && display_port="-"

    # Clean up health display
    [[ -z "$health" ]] && health="-"

    # Clean up uptime — extract the relative time
    local display_uptime
    display_uptime=$(echo "$uptime" | sed 's/Up //' | sed 's/ (healthy)//' | sed 's/ (unhealthy)//' || echo "-")

    # Color the state
    local state_colored="$state"
    if [[ "$state" == "running" ]]; then
      state_colored="${GREEN}running${NC}"
    elif [[ "$state" == "exited" || "$state" == "dead" ]]; then
      state_colored="${RED}${state}${NC}"
    elif [[ "$state" == "not found" ]]; then
      state_colored="${YELLOW}not found${NC}"
    fi

    # Color the health
    local health_colored="$health"
    if [[ "$health" == "healthy" ]]; then
      health_colored="${GREEN}healthy${NC}"
    elif [[ "$health" == "unhealthy" ]]; then
      health_colored="${RED}unhealthy${NC}"
    fi

    if ! $JSON_OUTPUT; then
      printf "  %-24s %-21b %-21b %-10s %s\n" "$name" "$state_colored" "$health_colored" "$display_port" "$display_uptime"
    fi

    # JSON
    [[ $i -gt 0 ]] && json_containers+=","
    json_containers+="{\"name\":\"${name}\",\"state\":\"${state}\",\"health\":\"${health}\",\"port\":\"${display_port}\",\"uptime\":\"${display_uptime}\"}"
  done

  json_containers+="]"
  _json_set "docker_stack" "$json_containers"

  $JSON_OUTPUT || echo ""
}

# ============================================================
# 2. Local Health Checks
# ============================================================

section_local_health() {
  if ! $JSON_OUTPUT; then
    printf "${BOLD}━━━ Local Health Checks ━━━${NC}\n"
    echo ""
  fi

  local checks_json="{"

  # Gateway metadata
  local gw_ok=false
  if curl -sf "http://localhost:8000/.well-known/oauth-protected-resource" >/dev/null 2>&1; then
    gw_ok=true
  fi
  if ! $JSON_OUTPUT; then
    printf "  Gateway metadata:   $(_check_mark $gw_ok)  curl localhost:8000/.well-known/oauth-protected-resource\n"
  fi
  checks_json+="\"gateway_metadata\":$gw_ok"

  # Admin API (v0.15.x+: password login removed; unauthenticated GET → 401)
  local admin_ok=false
  local admin_status
  admin_status=$(curl -s -o /dev/null -w '%{http_code}' "http://localhost:8000/api/admin/agents" 2>/dev/null || echo "000")
  if [[ "$admin_status" == "401" ]]; then
    admin_ok=true
  fi
  if ! $JSON_OUTPUT; then
    printf "  Admin API auth:     $(_check_mark $admin_ok)  GET localhost:8000/api/admin/agents → 401\n"
  fi
  checks_json+=",\"admin_api_auth\":$admin_ok"

  # Admin UI
  local ui_ok=false
  local ui_code
  ui_code=$(curl -sf -o /dev/null -w '%{http_code}' "http://localhost:3001/" 2>/dev/null || true)
  if [[ "$ui_code" == "200" || "$ui_code" == "304" ]]; then
    ui_ok=true
  fi
  if ! $JSON_OUTPUT; then
    printf "  Admin UI:           $(_check_mark $ui_ok)  curl localhost:3001/\n"
  fi
  checks_json+=",\"admin_ui\":$ui_ok"

  # Database
  local db_ok=false
  if docker compose exec -T postgres pg_isready -U gateway_user -d gateway_db >/dev/null 2>&1; then
    db_ok=true
  fi
  if ! $JSON_OUTPUT; then
    printf "  Database:           $(_check_mark $db_ok)  pg_isready\n"
  fi
  checks_json+=",\"database\":$db_ok"

  # Redis
  local redis_ok=false
  if docker compose exec -T redis redis-cli ping 2>/dev/null | grep -q "PONG"; then
    redis_ok=true
  fi
  if ! $JSON_OUTPUT; then
    printf "  Redis:              $(_check_mark $redis_ok)  redis-cli ping\n"
  fi
  checks_json+=",\"redis\":$redis_ok"

  checks_json+="}"
  _json_set "local_health" "$checks_json"

  $JSON_OUTPUT || echo ""
}

# ============================================================
# 3. AWS Infrastructure
# ============================================================

section_aws_infra() {
  if $QUICK_MODE || ! $HAS_STATE; then
    _json_set "aws_infrastructure" "{\"skipped\":true}"
    return
  fi

  if [[ -z "$AWS_REGION" ]]; then
    _json_set "aws_infrastructure" "{\"skipped\":true,\"reason\":\"no region\"}"
    return
  fi

  if ! $JSON_OUTPUT; then
    printf "${BOLD}━━━ AWS Infrastructure ━━━${NC}\n"
    echo ""
  fi

  local aws_json="{"

  # ALB Status
  local alb_status="n/a"
  if [[ -n "$ALB_ARN" ]]; then
    alb_status=$(aws elbv2 describe-load-balancers \
      --region "$AWS_REGION" \
      --load-balancer-arns "$ALB_ARN" \
      --query 'LoadBalancers[0].State.Code' \
      --output text 2>/dev/null || echo "not found")
  fi
  local alb_colored="$alb_status"
  [[ "$alb_status" == "active" ]] && alb_colored="${GREEN}active${NC}"
  [[ "$alb_status" == "failed" ]] && alb_colored="${RED}failed${NC}"
  [[ "$alb_status" == "provisioning" ]] && alb_colored="${YELLOW}provisioning${NC}"
  if ! $JSON_OUTPUT; then
    printf "  ALB Status:         %b\n" "$alb_colored"
  fi
  aws_json+="\"alb_status\":\"${alb_status}\""

  # Certificate
  local cert_status="n/a"
  if [[ -n "$ACM_CERT_ARN" ]]; then
    cert_status=$(aws acm describe-certificate \
      --region "$AWS_REGION" \
      --certificate-arn "$ACM_CERT_ARN" \
      --query 'Certificate.Status' \
      --output text 2>/dev/null || echo "not found")
  fi
  local cert_colored="$cert_status"
  [[ "$cert_status" == "ISSUED" ]] && cert_colored="${GREEN}ISSUED${NC}"
  [[ "$cert_status" == "PENDING_VALIDATION" ]] && cert_colored="${YELLOW}PENDING_VALIDATION${NC}"
  [[ "$cert_status" == "FAILED" ]] && cert_colored="${RED}FAILED${NC}"
  if ! $JSON_OUTPUT; then
    printf "  Certificate:        %b\n" "$cert_colored"
  fi
  aws_json+=",\"certificate_status\":\"${cert_status}\""

  # Adapter TG Health
  local adapter_tg_health="n/a"
  if [[ -n "$ADAPTER_TG_ARN" ]]; then
    adapter_tg_health=$(aws elbv2 describe-target-health \
      --region "$AWS_REGION" \
      --target-group-arn "$ADAPTER_TG_ARN" \
      --query 'TargetHealthDescriptions[0].TargetHealth.State' \
      --output text 2>/dev/null || echo "unknown")
  fi
  if ! $JSON_OUTPUT; then
    printf "  Adapter TG Health:  %b\n" "$(_health_word $([[ "$adapter_tg_health" == "healthy" ]] && echo true || echo false))"
  fi
  aws_json+=",\"adapter_tg_health\":\"${adapter_tg_health}\""

  # Admin UI TG Health
  local admin_tg_health="n/a"
  if [[ -n "$ADMIN_TG_ARN" ]]; then
    admin_tg_health=$(aws elbv2 describe-target-health \
      --region "$AWS_REGION" \
      --target-group-arn "$ADMIN_TG_ARN" \
      --query 'TargetHealthDescriptions[0].TargetHealth.State' \
      --output text 2>/dev/null || echo "unknown")
  fi
  if ! $JSON_OUTPUT; then
    printf "  Admin UI TG Health: %b\n" "$(_health_word $([[ "$admin_tg_health" == "healthy" ]] && echo true || echo false))"
  fi
  aws_json+=",\"admin_tg_health\":\"${admin_tg_health}\""

  # ALB DNS
  if ! $JSON_OUTPUT; then
    printf "  ALB DNS:            ${CYAN}%s${NC}\n" "${ALB_DNS:-n/a}"
  fi
  aws_json+=",\"alb_dns\":\"${ALB_DNS:-}\""

  aws_json+="}"
  _json_set "aws_infrastructure" "$aws_json"

  $JSON_OUTPUT || echo ""
}

# ============================================================
# 4. Public Endpoints
# ============================================================

section_public_endpoints() {
  if $QUICK_MODE || [[ "$PHASE3_COMPLETE" != "true" ]]; then
    _json_set "public_endpoints" "{\"skipped\":true}"
    return
  fi

  if [[ -z "$MCP_HOSTNAME" || -z "$ADMIN_HOSTNAME" ]]; then
    _json_set "public_endpoints" "{\"skipped\":true,\"reason\":\"no hostnames\"}"
    return
  fi

  if ! $JSON_OUTPUT; then
    printf "${BOLD}━━━ Public Endpoints ━━━${NC}\n"
    echo ""
  fi

  local ep_json="{"

  # HTTPS Gateway
  local gw_https_ok=false
  if curl -sf --max-time 5 "https://${MCP_HOSTNAME}/.well-known/oauth-protected-resource" >/dev/null 2>&1; then
    gw_https_ok=true
  fi
  if ! $JSON_OUTPUT; then
    printf "  HTTPS Gateway:      $(_check_mark $gw_https_ok)  https://%s\n" "$MCP_HOSTNAME"
  fi
  ep_json+="\"https_gateway\":$gw_https_ok"

  # HTTPS Admin UI
  local admin_https_ok=false
  local admin_code
  admin_code=$(curl -sf --max-time 5 -o /dev/null -w '%{http_code}' "https://${ADMIN_HOSTNAME}/" 2>/dev/null || true)
  if [[ "$admin_code" == "200" || "$admin_code" == "304" ]]; then
    admin_https_ok=true
  fi
  if ! $JSON_OUTPUT; then
    printf "  HTTPS Admin UI:     $(_check_mark $admin_https_ok)  https://%s\n" "$ADMIN_HOSTNAME"
  fi
  ep_json+=",\"https_admin_ui\":$admin_https_ok"

  # HTTP Redirect
  local redirect_ok=false
  if [[ -n "$ALB_DNS" ]]; then
    local redir_code
    redir_code=$(curl -sf --max-time 5 -o /dev/null -w '%{http_code}' "http://${ALB_DNS}/" 2>/dev/null || true)
    if [[ "$redir_code" == "301" ]]; then
      redirect_ok=true
    fi
  fi
  if ! $JSON_OUTPUT; then
    printf "  HTTP Redirect:      $(_check_mark $redirect_ok)  http://%s → 301\n" "${ALB_DNS:-n/a}"
  fi
  ep_json+=",\"http_redirect\":$redirect_ok"

  ep_json+="}"
  _json_set "public_endpoints" "$ep_json"

  $JSON_OUTPUT || echo ""
}

# ============================================================
# 5. Resource Usage
# ============================================================

section_resource_usage() {
  if ! $JSON_OUTPUT; then
    printf "${BOLD}━━━ Resource Usage ━━━${NC}\n"
    echo ""
  fi

  local stats_json="["
  local first=true

  # Capture docker stats in one shot
  local stats_output
  stats_output=$(docker stats --no-stream --format '{{.Name}}\t{{.CPUPerc}}\t{{.MemUsage}}\t{{.MemPerc}}' 2>/dev/null || true)

  if [[ -n "$stats_output" ]]; then
    if ! $JSON_OUTPUT; then
      printf "  ${BOLD}%-28s %-10s %-24s %s${NC}\n" "CONTAINER" "CPU" "MEMORY" "MEM %"
    fi

    while IFS=$'\t' read -r name cpu mem mem_pct; do
      [[ -z "$name" ]] && continue
      if ! $JSON_OUTPUT; then
        printf "  %-28s %-10s %-24s %s\n" "$name" "$cpu" "$mem" "$mem_pct"
      fi

      $first || stats_json+=","
      first=false
      stats_json+="{\"name\":\"${name}\",\"cpu\":\"${cpu}\",\"memory\":\"${mem}\",\"memory_percent\":\"${mem_pct}\"}"
    done <<< "$stats_output"
  else
    if ! $JSON_OUTPUT; then
      warn "  Could not retrieve container stats"
    fi
  fi

  stats_json+="]"
  _json_set "resource_usage" "$stats_json"

  $JSON_OUTPUT || echo ""
}

# ============================================================
# 6. Connection Info
# ============================================================

section_connection_info() {
  # Only show if we have meaningful config
  local gw_url
  gw_url=$(grep "^GATEWAY_BASE_URL=" "$SCRIPT_DIR/.env" 2>/dev/null | cut -d= -f2- || true)

  local conn_json="{"
  conn_json+="\"gateway_url\":\"${gw_url:-http://localhost:8000}\""
  conn_json+=",\"admin_auth\":\"okta_oauth\""

  if [[ -n "$MCP_HOSTNAME" && "$PHASE3_COMPLETE" == "true" ]]; then
    conn_json+=",\"mcp_endpoint\":\"https://${MCP_HOSTNAME}\""
    conn_json+=",\"admin_endpoint\":\"https://${ADMIN_HOSTNAME}\""
    conn_json+=",\"redirect_uri\":\"https://${MCP_HOSTNAME}/oauth2/callback\""

    if ! $JSON_OUTPUT; then
      printf "${BOLD}━━━ Connection Info ━━━${NC}\n"
      echo ""
      printf "  ${BOLD}Gateway:${NC}      ${CYAN}https://%s${NC}\n" "$MCP_HOSTNAME"
      printf "  ${BOLD}Admin UI:${NC}     ${CYAN}https://%s${NC}  (sign in with Okta)\n" "$ADMIN_HOSTNAME"
      echo ""
      printf "  ${BOLD}Okta Redirect URI:${NC}\n"
      printf "    ${CYAN}https://%s/oauth2/callback${NC}\n" "$MCP_HOSTNAME"
      echo ""
      printf "  ${BOLD}Connect Claude Code:${NC}\n"
      printf "    ${CYAN}MCP_CLIENT_SECRET='...' claude mcp add okta-gateway \\\\${NC}\n"
      printf "    ${CYAN}  --url https://%s \\\\${NC}\n" "$MCP_HOSTNAME"
      printf "    ${CYAN}  --client-id YOUR_CLIENT_ID \\\\${NC}\n"
      printf "    ${CYAN}  --client-secret \$MCP_CLIENT_SECRET \\\\${NC}\n"
      printf "    ${CYAN}  --callback-port 3000${NC}\n"
      echo ""
    fi
  else
    conn_json+=",\"mcp_endpoint\":\"${gw_url:-http://localhost:8000}\""
    conn_json+=",\"admin_endpoint\":\"http://localhost:3001\""

    if ! $JSON_OUTPUT; then
      printf "${BOLD}━━━ Connection Info ━━━${NC}\n"
      echo ""
      printf "  ${BOLD}Gateway:${NC}      ${CYAN}%s${NC}\n" "${gw_url:-http://localhost:8000}"
      printf "  ${BOLD}Admin UI:${NC}     ${CYAN}http://localhost:3001${NC}\n"
      printf "  ${BOLD}Admin Login:${NC}  %s / <see .env>\n" "$admin_user"
      echo ""
    fi
  fi

  conn_json+="}"
  _json_set "connection_info" "$conn_json"
}

# ============================================================
# Run all sections
# ============================================================

if ! $JSON_OUTPUT; then
  echo ""
  printf "${CYAN}┌──────────────────────────────────────────────────┐${NC}\n"
  printf "${CYAN}│${NC}  ${BOLD}Okta MCP Adapter — Status Dashboard${NC}              ${CYAN}│${NC}\n"
  printf "${CYAN}└──────────────────────────────────────────────────┘${NC}\n"
fi

section_docker_stack
section_local_health
section_aws_infra
section_public_endpoints
section_resource_usage
section_connection_info

# ============================================================
# JSON output
# ============================================================

if $JSON_OUTPUT; then
  local_ts=$(date -u +"%Y-%m-%dT%H:%M:%SZ")
  printf '{'
  printf '"timestamp":"%s"' "$local_ts"
  for key in docker_stack local_health aws_infrastructure public_endpoints resource_usage connection_info; do
    printf ',"%s":%s' "$key" "${JSON_SECTIONS[$key]:-null}"
  done
  printf '}\n'
fi
