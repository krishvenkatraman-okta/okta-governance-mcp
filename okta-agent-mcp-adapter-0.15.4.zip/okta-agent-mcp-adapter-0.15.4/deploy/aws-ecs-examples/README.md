# ECS Examples Deployment

Deploys example MCP servers for the Okta MCP Adapter. Currently supports two backends:

| Backend | Auth method | Purpose |
|---|---|---|
| **hr-backend** (`examples/01-hr-system`) | Pre-Shared Key | Simple PSK integration example |
| **deploy-server** (`examples/05-deploy-server`) | `okta-cross-app` (ID-JAG) | XAA token-exchange integration example |

This project is a **sibling** to [`deploy/aws-ecs`](../aws-ecs) and reads shared resource IDs (cluster, VPC, subnets, IAM roles, Service Connect namespace) from the core's `core-outputs.json`.

**Why is this separate?** In earlier versions, example servers were provisioned in the same `terraform apply` as core infra. A failure in an example (e.g., HR backend failing to pull its image) could make the whole apply look broken, which confused operators. Separating the projects means:

- Core adapter can deploy successfully even if examples fail.
- Examples can be destroyed without touching core.
- Examples are explicitly opt-in.

## What gets deployed

Each backend is gated independently behind a `deploy_<name>` flag in `terraform.tfvars`.

**HR backend** (`deploy_hr_backend = true`, default on):

- ECR repo: `<project_name>-hr-backend`
- ECR lifecycle policy (7-day untagged expiry, keep last 10)
- Security group rule on core's `ecs_tasks_sg` for east-west traffic (tcp/8001)
- CloudWatch log group: `/ecs/<project_name>-hr-backend`
- ECS task definition: `<project_name>-hr-backend` (Fargate, 256 CPU / 512 MB)
- ECS service: `hr-backend` — Service Connect DNS `hr-backend.<project_name>.local`

**Deploy-server** (`deploy_deploy_server = true`, default off):

- ECR repo: `<project_name>-deploy-server`
- ECR lifecycle policy (same as HR)
- Security group rule on core's `ecs_tasks_sg` (tcp/8005)
- CloudWatch log group: `/ecs/<project_name>-deploy-server`
- ECS task definition: `<project_name>-deploy-server` (Fargate, 256 CPU / 512 MB)
- ECS service: `deploy-server` — Service Connect DNS `deploy-server.<project_name>.local`

Cost: roughly $5-10/month per Fargate task while running (1× task, 0.25 vCPU each).

## Prerequisites

- Core must be deployed first: `cd ../aws-ecs && ./deploy.sh --apply`
- `core-outputs.json` must exist at `deploy/aws-ecs/core-outputs.json` (written automatically by core's `deploy.sh --apply`)
- `jq` and the AWS CLI v2 are on PATH
- The default path pulls prebuilt images from ECR Public — no build tooling required. To opt into building from source, you'll also need AWS CodeBuild access (reuses core's project) or Docker (`--use-local-docker`).
- **For deploy-server only:** the Okta resource server that issues AT-2 tokens must exist before Terraform apply — you need the authorization server ID and audience to configure the task definition (see [Configure](#configure) below).

## Deploy

By default, `./deploy.sh --apply` pulls prebuilt `hr-server` and `deploy-server`
images from ECR Public at tag `v<pyproject version>`. Single-phase apply —
no ECR repos created, no CodeBuild run.

```bash
cd deploy/aws-ecs-examples

# Enable backends in terraform.tfvars (copy from example.tfvars on first run;
# deploy.sh does this automatically if terraform.tfvars is missing).
./deploy.sh --apply

# Pin to a specific published version
./deploy.sh --apply --tag=v0.15.0

# Confirm all enabled backends are healthy
./smoke-test.sh
```

The default path sets these Terraform variables automatically:

| Variable                            | Value                                                             |
| ----------------------------------- | ----------------------------------------------------------------- |
| `byo_ecr_repos`                     | `true`                                                            |
| `existing_ecr_hr_backend_url`       | `public.ecr.aws/${ECR_PUBLIC_ALIAS:-oktaps}/okta-mcp-hr-server`     |
| `existing_ecr_deploy_server_url`    | `public.ecr.aws/${ECR_PUBLIC_ALIAS:-oktaps}/okta-mcp-deploy-server` |
| `hr_backend_image_tag`              | from `--tag=` or pyproject version                                |
| `deploy_server_image_tag`           | same                                                              |

Override `ECR_PUBLIC_ALIAS` to mirror from a different public namespace.
Publishing instructions for maintainers live in
`deploy/aws-ecs/README.md` under **"Publishing to ECR Public"**.

After apply, the script prints an **Admin UI registration hint** block with
the Service Connect URL for each deployed backend — see
[Register in the Admin UI](#register-in-the-admin-ui) below.

### Build from source (opt-in)

To build `hr-server` / `deploy-server` from this working tree instead of
pulling prebuilt images:

```bash
./deploy.sh --apply --build-from-source   # CodeBuild
./deploy.sh --apply --use-local-docker    # local Docker (implies --build-from-source)
```

`--build-from-source` triggers the three-phase apply used previously:

1. Create the ECR repo(s) for every enabled backend (`terraform apply -target=...`)
2. Build and push each backend's image (CodeBuild by default, or local Docker)
3. Full `terraform apply` (task definitions + ECS services)

`--build-only` now requires `--build-from-source`. A bare
`./deploy.sh --build-only` errors out — the default path has nothing to build.

## Configure

Edit `terraform.tfvars` (copy from `example.tfvars` if it doesn't exist — `deploy.sh` does this automatically):

```hcl
# ---- HR backend (default: enabled, PSK auth) ----
deploy_hr_backend             = true
hr_backend_image_tag          = "latest"
hr_backend_log_retention_days = 7
# hr_backend_port             = 8001

# ---- Deploy-server (default: disabled, okta-cross-app / ID-JAG auth) ----
deploy_deploy_server             = true
deploy_server_image_tag          = "latest"
deploy_server_log_retention_days = 7
# deploy_server_port             = 8005

# REQUIRED when deploy_deploy_server = true:
deploy_server_okta_domain         = "dev-123.okta.com"  # bare domain, no scheme
deploy_server_okta_auth_server_id = "default"            # or ausXXXXXXXXXXXXXX
deploy_server_okta_audience       = "api://deploy-server"

additional_tags = {}
```

Terraform will fail with a clear error if `deploy_deploy_server=true` and either `deploy_server_okta_domain` or `deploy_server_okta_auth_server_id` is empty.

The shared inputs (cluster ARN, VPC ID, subnet IDs, IAM role ARNs, Service Connect namespace ARN, tags) come from `core-outputs.json` automatically. For advanced usage — e.g., running `terraform` directly without `deploy.sh` — uncomment the shared input section in `example.tfvars`.

## Register in the Admin UI

The examples project stands up the MCP servers but does **not** wire them up as Resources inside the adapter — that's a separate Admin UI step so operators can set auth credentials (PSK, XAA config, etc.) without exposing them through Terraform state.

After `./deploy.sh --apply` completes, the script prints a banner with the exact URLs you'll need. You can also query them any time with:

```bash
terraform output -raw admin_ui_hr_backend_url
# http://hr-backend.<project_name>.local:8001

terraform output -raw admin_ui_deploy_server_url
# http://deploy-server.<project_name>.local:8005
```

Open the Admin UI (`https://<ADMIN_HOST>/`) → **Resources → New** and fill in the form using the values below.

### HR backend (Pre-Shared Key)

| Field | Value |
|---|---|
| Name | `hr-system` |
| URL | `http://hr-backend.<project_name>.local:8001` (from `terraform output admin_ui_hr_backend_url`) |
| Paths | `/hr` |
| Auth method | Pre-Shared Key |
| Header name | `X-API-Key` |
| Key | Value of `PSK_SECRET` in the HR task definition's environment (default: `demo-psk-secret-do-not-use-in-prod` unless you overrode it) |
| Timeout | `30` |

To read the PSK value currently set on the running HR task:

```bash
CLUSTER=$(terraform output -raw cluster_name)
TASK_DEF=$(aws ecs describe-services \
  --cluster "$CLUSTER" --services hr-backend \
  --query 'services[0].taskDefinition' --output text)
aws ecs describe-task-definition --task-definition "$TASK_DEF" \
  --query "taskDefinition.containerDefinitions[0].environment[?name=='PSK_SECRET'].value" \
  --output text
```

### Deploy-server (`okta-cross-app` / ID-JAG)

| Field | Value |
|---|---|
| Name | `deploy-server` |
| URL | `http://deploy-server.<project_name>.local:8005` (from `terraform output admin_ui_deploy_server_url`) |
| Paths | `/deploy` |
| Auth method | `okta-cross-app` |
| Target audience | Matches `deploy_server_okta_audience` (default: `api://deploy-server`) |
| Target authorization server | Matches `deploy_server_okta_auth_server_id` |
| Timeout | `30` |

You'll also need an Okta **Managed Connection** that binds the agent to the deploy-server resource server; see [`docs/BACKEND_SETUP_GUIDE.md`](../../docs/BACKEND_SETUP_GUIDE.md) for the full `okta-cross-app` wiring and example curl payloads.

## Port Configuration

Each backend's container port is controlled by a Terraform variable. Changing it updates the container port, the Service Connect advertise, and the corresponding `*_PORT` env var in the task definition — no manual wiring needed.

| Variable | Default | Range | Controls |
|---|---|---|---|
| `hr_backend_port` | `8001` | 1–65535 | HR backend container port, Service Connect advertise, `HR_BACKEND_PORT` + `SERVER_PORT` env vars |
| `deploy_server_port` | `8005` | 1–65535 | Deploy-server container port, Service Connect advertise, `DEPLOY_SERVER_PORT` + `SERVER_PORT` env vars |

Override in `terraform.tfvars` or via env var before `deploy.sh`:

```bash
TF_VAR_hr_backend_port=9001 TF_VAR_deploy_server_port=9005 ./deploy.sh --apply
```

See [docs/OPERATIONS.md#port-configuration](../../docs/OPERATIONS.md#port-configuration) for the canonical reference, including the `SERVER_PORT` deprecation that `HR_BACKEND_PORT` / `DEPLOY_SERVER_PORT` replace.

## Destroy

Destroy examples BEFORE destroying core:

```bash
cd deploy/aws-ecs-examples
./deploy.sh --destroy
```

If you destroy core first, the examples state file will still reference destroyed resources and subsequent destroys may silently orphan ECR repos and log groups. Core's `deploy.sh --destroy` warns if it detects leftover examples state.

## Adding more examples

To add a third example MCP server, follow the HR / deploy-server pattern in `main.tf`:

- ECR repo + lifecycle policy
- Security group rule (if east-west traffic needed)
- Log group
- Task definition (reads core-provided IAM roles from `var.ecs_task_role_arn` / `var.ecs_task_execution_role_arn`)
- ECS service (uses core cluster via `var.cluster_arn` and Service Connect namespace via `var.service_discovery_namespace_arn`)

Gate each example behind a `deploy_<name>` variable so operators can enable/disable individually. Add corresponding outputs (including an `admin_ui_<name>_url`) so the smoke test can verify the service and the post-apply banner can print the Admin UI URL.

## `deploy.sh` reference

```bash
./deploy.sh --apply                               # Default. Pull public images, single-phase apply.
./deploy.sh --apply --tag=v0.15.0                 # Pin a specific public-image tag
./deploy.sh --plan                                # Preview Terraform changes
./deploy.sh --destroy                             # Tear down examples (does NOT touch core)
./deploy.sh --apply --build-from-source           # Build in-account via CodeBuild (three-phase apply)
./deploy.sh --apply --use-local-docker            # Build locally with Docker (implies --build-from-source)
./deploy.sh --build-from-source --build-only      # Build and push images without running apply
./deploy.sh --help                                # Show usage
```

## Troubleshooting

### "core-outputs.json not found"

Core hasn't been deployed or `core-outputs.json` wasn't written. Regenerate:

```bash
cd ../aws-ecs
terraform output -json > core-outputs.json
```

If this is a fresh clone of an older deploy (before the split was applied), run `./deploy.sh --apply` in core first — the post-apply step writes the file automatically.

### "core output 'X' is missing from core-outputs.json"

The core deployment is on an older version that predates the split. Re-apply core to regenerate all 12 shared outputs, or regenerate directly:

```bash
cd ../aws-ecs && terraform output -json > core-outputs.json
```

### "hr_backend_ecr_url not yet available" or "deploy_server_ecr_url not yet available"

Only relevant when using `--build-from-source`. The three-phase apply hasn't
run phase 1 yet for that backend. Either run `./deploy.sh --apply --build-from-source`
(which sequences all three phases) or manually target the repo:

```bash
terraform apply -target=aws_ecr_repository.hr_backend
terraform apply -target=aws_ecr_repository.deploy_server
```

On the default path (public images) these outputs resolve to the
`public.ecr.aws/...` URL — no ECR repo is created.

### "deploy_deploy_server=true requires both deploy_server_okta_domain and deploy_server_okta_auth_server_id"

You've enabled deploy-server but haven't filled in the Okta inputs required for token validation. Set them in `terraform.tfvars` (see [Configure](#configure)). Without them the container would fail to start with `Required environment variable(s) not set: DEPLOY_OKTA_DOMAIN, DEPLOY_OKTA_AUTH_SERVER_ID`.

### "Error: error reading ECS service: ServiceNotFoundException"

Usually means the core cluster was destroyed while examples state still references it. Manually remove the dangling resources from examples state:

```bash
cd deploy/aws-ecs-examples
terraform state list | grep -E 'hr_backend|deploy_server' | xargs -I {} terraform state rm {}
```

Then re-deploy core, then re-deploy examples.

### Example backend image won't pull

On the default (public image) path, confirm the tag exists:

```bash
aws ecr-public describe-images --region us-east-1 \
  --repository-name okta-mcp-hr-server \
  --registry-id "${ECR_PUBLIC_REGISTRY_ID:-<numeric-id>}"
```

If you're on `--build-from-source`, build and push first:

```bash
./deploy.sh --build-from-source --build-only
```

Or let `--apply --build-from-source` handle it in sequence:

```bash
./deploy.sh --apply --build-from-source
```

### Example backend service stuck in DEGRADED / PROVISIONING

Most common causes:

- Image tag doesn't exist in ECR (verify with `aws ecr describe-images --repository-name <project_name>-hr-backend` or `-deploy-server`)
- Container health check failing (check `/ecs/<project_name>-hr-backend` or `/ecs/<project_name>-deploy-server` CloudWatch logs)
- Network: task cannot reach ECR or Service Connect (check core's `ecs_tasks_sg` rules)
- **Deploy-server only:** `RuntimeError: Required environment variable(s) not set` — see the preceding troubleshooting entry
- **Deploy-server only:** Okta JWKS unreachable at `https://<deploy_server_okta_domain>/oauth2/<auth_server_id>/v1/keys` — verify the domain/auth server ID are correct and the ECS task SG has egress on tcp/443

Dig in with:

```bash
aws ecs describe-services \
  --cluster "$(jq -r '.cluster_name.value' ../aws-ecs/core-outputs.json)" \
  --services hr-backend deploy-server \
  --region "$(jq -r '.aws_region.value' ../aws-ecs/core-outputs.json)"
```
