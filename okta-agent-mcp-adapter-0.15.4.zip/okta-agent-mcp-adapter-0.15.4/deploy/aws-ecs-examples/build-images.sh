#!/usr/bin/env bash
set -euo pipefail

# =============================================================
# build-images.sh — Build and push example backend images to ECR
# =============================================================
# Local Docker buildx alternative to build-codebuild.sh. Reads
# each ECR URL from examples' terraform output and skips any
# backend whose deploy flag is disabled.
# =============================================================

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
REPO_ROOT="$(cd "$SCRIPT_DIR/../.." && pwd)"

# shellcheck disable=SC1091
source "$SCRIPT_DIR/shell-lib/common.sh"

# ---- Required env vars ----
: "${AWS_REGION:?AWS_REGION must be set}"
: "${AWS_ACCOUNT_ID:?AWS_ACCOUNT_ID must be set}"

validate_command docker "Install Docker (https://docs.docker.com/get-docker/)."
validate_command aws "Install AWS CLI."

ECR_REGISTRY="${AWS_ACCOUNT_ID}.dkr.ecr.${AWS_REGION}.amazonaws.com"
IMAGE_TAG="${IMAGE_TAG:-latest}"

cd "$SCRIPT_DIR"

# ---- Authenticate Docker to ECR (once, covers both repos) ----
info "Authenticating Docker to ECR (${ECR_REGISTRY})..."
aws ecr get-login-password --region "$AWS_REGION" | \
  docker login --username AWS --password-stdin "$ECR_REGISTRY"
ok "ECR authentication successful"

BUILT_IMAGES=()

# ---- HR backend ----
HR_ECR_URL=$(terraform output -raw hr_backend_ecr_url 2>/dev/null || true)
if [[ -z "$HR_ECR_URL" || "$HR_ECR_URL" == "null" ]]; then
  warn "hr_backend_ecr_url not available (deploy_hr_backend=false or phase 1 not applied). Skipping HR build."
else
  info "Building HR backend image (linux/amd64)..."
  docker buildx build \
    --platform linux/amd64 \
    -t "${HR_ECR_URL}:${IMAGE_TAG}" \
    -f "${REPO_ROOT}/examples/01-hr-system/Dockerfile" \
    --push \
    "${REPO_ROOT}/examples/01-hr-system"
  ok "HR backend image pushed"
  BUILT_IMAGES+=("${HR_ECR_URL}:${IMAGE_TAG}")
fi

# ---- Deploy-server ----
DEPLOY_ECR_URL=$(terraform output -raw deploy_server_ecr_url 2>/dev/null || true)
if [[ -z "$DEPLOY_ECR_URL" || "$DEPLOY_ECR_URL" == "null" ]]; then
  warn "deploy_server_ecr_url not available (deploy_deploy_server=false or phase 1 not applied). Skipping deploy-server build."
else
  info "Building deploy-server image (linux/amd64)..."
  docker buildx build \
    --platform linux/amd64 \
    -t "${DEPLOY_ECR_URL}:${IMAGE_TAG}" \
    -f "${REPO_ROOT}/examples/05-deploy-server/Dockerfile" \
    --push \
    "${REPO_ROOT}/examples/05-deploy-server"
  ok "Deploy-server image pushed"
  BUILT_IMAGES+=("${DEPLOY_ECR_URL}:${IMAGE_TAG}")
fi

# ---- Summary ----
if [[ ${#BUILT_IMAGES[@]} -eq 0 ]]; then
  die "No images built — all example backends appear disabled or phase 1 hasn't been applied."
fi

echo ""
echo "┌─────────────────────────────────────────────────────────────┐"
echo "│  Example backend images pushed to ECR                       │"
echo "│                                                             │"
for img in "${BUILT_IMAGES[@]}"; do
  echo "│  ${img}"
done
echo "└─────────────────────────────────────────────────────────────┘"
