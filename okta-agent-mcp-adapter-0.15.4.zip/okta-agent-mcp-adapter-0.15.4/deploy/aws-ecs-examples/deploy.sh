#!/usr/bin/env bash
set -euo pipefail

# =============================================================
# deploy.sh — Terraform wrapper for ECS example MCP servers
#              (HR backend + deploy-server)
# =============================================================
# Reads shared resource IDs (cluster, VPC, subnets, IAM roles,
# Service Connect namespace) from the core deployment's
# core-outputs.json and converts them to TF_VAR_* flags.
#
# Each backend is gated by deploy_<name> (deploy_hr_backend,
# deploy_deploy_server) in terraform.tfvars.
#
# Default: pulls prebuilt hr-server + deploy-server from
# public.ecr.aws/${ECR_PUBLIC_ALIAS:-oktaps}/ at tag v<pyproject version>.
# Collapses to a single terraform apply (no ECR repo creation, no build).
#
# Usage:
#   ./deploy.sh --apply                      Deploy examples (default)
#   ./deploy.sh --plan                       Preview changes
#   ./deploy.sh --destroy                    Tear down examples only
#   ./deploy.sh --apply --build-from-source  Build+push via CodeBuild (opt-in)
#   ./deploy.sh --help                       Show usage
# =============================================================

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
CORE_DIR="$(cd "$SCRIPT_DIR/../aws-ecs" && pwd)"
CORE_OUTPUTS_FILE="$CORE_DIR/core-outputs.json"

# Source shared shell-lib (symlinked to ../aws-ec2/shell-lib).
# shellcheck disable=SC1091
source "$SCRIPT_DIR/shell-lib/common.sh"

# ---- Usage ----
usage() {
  cat <<EOF
Usage: ./deploy.sh [FLAG]

  --apply              Deploy examples (default when no flag given).
                       Default image source: public.ecr.aws/\${ECR_PUBLIC_ALIAS:-oktaps}/
                       at tag v<pyproject version>.
  --plan               Preview Terraform changes
  --destroy            Tear down examples (does NOT touch core)
  --build-from-source  Opt out of public images. Build and push hr-server +
                       deploy-server to private ECR in this account via AWS
                       CodeBuild. Enables the three-phase apply path.
  --use-local-docker   With --build-from-source, build locally with Docker
                       instead of CodeBuild. Implies --build-from-source.
  --build-only         Build and push enabled example backend images; skip
                       terraform apply. Requires --build-from-source.
  --tag=vX.Y.Z         Override the public-image tag. Accepts 'latest' or any
                       published tag. Ignored with a warning when --build-from-source.
  -h, --help           Show this help

Prerequisite:
  The core deployment (deploy/aws-ecs) must have been applied first
  so that core-outputs.json exists at:
    $CORE_OUTPUTS_FILE

  If core was deployed before this split, regenerate with:
    cd $CORE_DIR && terraform output -json > core-outputs.json
EOF
}

# ---- Parse arguments ----
ACTION="apply"
BUILD_FROM_SOURCE=false
USE_LOCAL_DOCKER=false
PUBLIC_IMAGE_TAG=""

while [[ $# -gt 0 ]]; do
  case "$1" in
    --apply)             ACTION="apply"; shift ;;
    --plan)              ACTION="plan"; shift ;;
    --destroy)           ACTION="destroy"; shift ;;
    --build-only)        ACTION="build-only"; shift ;;
    --build-from-source) BUILD_FROM_SOURCE=true; shift ;;
    --use-local-docker)  USE_LOCAL_DOCKER=true; BUILD_FROM_SOURCE=true; shift ;;
    --tag=*)             PUBLIC_IMAGE_TAG="${1#--tag=}"; shift ;;
    -h|--help)           usage; exit 0 ;;
    *) die "Unknown argument: $1. Use --help for usage." ;;
  esac
done

# USE_CODEBUILD is still consumed by build_backend_images below — derive it
# from BUILD_FROM_SOURCE + USE_LOCAL_DOCKER for backward compat with the
# build-backend-images / build-codebuild scripts.
USE_CODEBUILD=true
[[ "$USE_LOCAL_DOCKER" == "true" ]] && USE_CODEBUILD=false

# --build-from-source requires the example server source trees at ../../examples/.
# If they're missing this is the deploy-only packaged tarball. Fail fast with
# a concrete fix before touching AWS or Terraform.
if [[ "$BUILD_FROM_SOURCE" == "true" ]]; then
  for required in examples/01-hr-system examples/05-deploy-server; do
    if [[ ! -d "$SCRIPT_DIR/../../$required" ]]; then
      die "--build-from-source requires the source tree (missing: ../../${required}).\n\n  This looks like the deploy-only bundle. To build from source, either:\n    - Extract the okta-ps-adapter-aws-ecs-source-<version>.tar.gz bundle, or\n    - Run from a git checkout of the repository.\n\n  Otherwise drop --build-from-source to pull prebuilt images from ECR Public."
    fi
  done
fi

# ---- Image source wiring ----
# Default path: task defs pull hr-server + deploy-server from
# public.ecr.aws/${ECR_PUBLIC_ALIAS:-oktaps}/. Phase 1 (ECR repos +
# CodeBuild push IAM) and Phase 2 (build+push) are skipped — single apply.
#
# --build-from-source skips these exports so Terraform creates private ECR
# repos and the three-phase apply runs.
if [[ "$BUILD_FROM_SOURCE" == "true" ]]; then
  if [[ -n "$PUBLIC_IMAGE_TAG" ]]; then
    warn "--tag=${PUBLIC_IMAGE_TAG} ignored when --build-from-source is set."
  fi
else
  if [[ -z "$PUBLIC_IMAGE_TAG" ]]; then
    PYPROJECT="$SCRIPT_DIR/../../pyproject.toml"
    if [[ -f "$PYPROJECT" ]]; then
      VERSION=$(grep -m1 '^version' "$PYPROJECT" | sed 's/.*= *"\(.*\)"/\1/')
      [[ -n "$VERSION" ]] && PUBLIC_IMAGE_TAG="v${VERSION}"
    fi
    [[ -n "$PUBLIC_IMAGE_TAG" ]] || die "Could not resolve version from pyproject.toml; pass --tag= explicitly."
  fi

  ECR_PUBLIC_ALIAS="${ECR_PUBLIC_ALIAS:-oktaps}"
  export TF_VAR_byo_ecr_repos=true
  export TF_VAR_existing_ecr_hr_backend_url="public.ecr.aws/${ECR_PUBLIC_ALIAS}/okta-mcp-hr-server"
  export TF_VAR_existing_ecr_deploy_server_url="public.ecr.aws/${ECR_PUBLIC_ALIAS}/okta-mcp-deploy-server"
  export TF_VAR_hr_backend_image_tag="$PUBLIC_IMAGE_TAG"
  export TF_VAR_deploy_server_image_tag="$PUBLIC_IMAGE_TAG"

  info "Public images: public.ecr.aws/${ECR_PUBLIC_ALIAS}/okta-mcp-{hr-server,deploy-server}:${PUBLIC_IMAGE_TAG}"
  info "Phase 1 (ECR repos) and Phase 2 (build) will be skipped."
fi

# ---- Terraform credential visibility check ----
# See deploy/aws-ecs/deploy.sh preflight_tf_creds_check for full rationale.
# Short version: the AWS CLI's credential chain differs from Terraform's;
# macOS Keychain-cached creds work for CLI but not Terraform, which commonly
# leads to mid-apply failures. Probe the sources Terraform actually reads.
preflight_tf_creds_check() {
  if [[ -n "${AWS_ACCESS_KEY_ID:-}" && -n "${AWS_SECRET_ACCESS_KEY:-}" ]]; then
    ok "Terraform credentials: env vars (AWS_ACCESS_KEY_ID set)"
    return 0
  fi

  local profile="${AWS_PROFILE:-default}"

  if [[ -f "$HOME/.aws/credentials" ]]; then
    if _TF_CREDS_SECTION="[${profile}]" awk '
      BEGIN { target = ENVIRON["_TF_CREDS_SECTION"] }
      { sub(/[[:space:]]+$/, "") }
      $0 == target { in_s = 1; next }
      /^\[/ { in_s = 0 }
      in_s && /^[[:space:]]*aws_access_key_id[[:space:]]*=/ { found = 1; exit }
      END { exit !found }
    ' "$HOME/.aws/credentials" 2>/dev/null; then
      ok "Terraform credentials: ~/.aws/credentials [${profile}]"
      return 0
    fi
  fi

  if [[ -f "$HOME/.aws/config" ]]; then
    local target_section
    if [[ "$profile" == "default" ]]; then
      target_section="[default]"
    else
      target_section="[profile ${profile}]"
    fi
    if _TF_CREDS_SECTION="$target_section" awk '
      BEGIN { target = ENVIRON["_TF_CREDS_SECTION"] }
      { sub(/[[:space:]]+$/, "") }
      $0 == target { in_s = 1; next }
      /^\[/ { in_s = 0 }
      in_s && /^[[:space:]]*sso_/ { found = 1; exit }
      END { exit !found }
    ' "$HOME/.aws/config" 2>/dev/null; then
      ok "Terraform credentials: SSO profile [${profile}]"
      info "  If apply fails with 'No valid credential sources found' or"
      info "  'ExpiredToken' mid-apply, export SSO creds as env vars:"
      info "    aws sso login --profile ${profile}"
      info "    eval \"\$(aws configure export-credentials --profile ${profile} --format env)\""
      return 0
    fi
  fi

  fail "AWS CLI may be authenticated, but Terraform's AWS SDK won't find the credentials."
  echo ""
  echo "  Terraform's SDK does NOT read macOS Keychain creds (common with Okta"
  echo "  federated CLIs). Export SSO creds as env vars before re-running:"
  echo ""
  echo "      aws sso login --profile <your-profile>"
  echo "      eval \"\$(aws configure export-credentials --profile <your-profile> --format env)\""
  echo ""
  echo "  See deploy/aws-ecs/README.md 'AWS Credentials for Terraform' for details."
  echo "  To bypass (not recommended): export SKIP_TF_CREDS_CHECK=true"

  [[ "${SKIP_TF_CREDS_CHECK:-}" == "true" ]] || exit 1
}

# ---- Core outputs loader ----
load_core_outputs() {
  if [[ ! -f "$CORE_OUTPUTS_FILE" ]]; then
    die "core-outputs.json not found at $CORE_OUTPUTS_FILE.

Run the core deployment first:
    cd $CORE_DIR
    ./deploy.sh --apply

If you deployed core before this split was applied, regenerate:
    cd $CORE_DIR
    terraform output -json > core-outputs.json"
  fi

  validate_command jq "Install jq (https://stedolan.github.io/jq/)."

  # Keys published by core and consumed by examples.
  local keys=(
    aws_region
    project_name
    cluster_arn
    cluster_name
    service_discovery_namespace_arn
    ecs_tasks_sg_id
    alb_sg_id
    ecs_task_role_arn
    ecs_task_execution_role_arn
    private_subnet_ids
    vpc_id
    common_tags
    codebuild_role_name
  )

  for key in "${keys[@]}"; do
    local value
    value=$(jq -r --arg k "$key" '.[$k].value // empty' "$CORE_OUTPUTS_FILE")
    if [[ -z "$value" || "$value" == "null" ]]; then
      die "core output '$key' is missing from core-outputs.json.
Core deployment may be incomplete or on an older version.
Regenerate: cd $CORE_DIR && terraform output -json > core-outputs.json"
    fi

    case "$key" in
      private_subnet_ids)
        # List: keep as JSON array
        TF_VAR_private_subnet_ids=$(jq -c --arg k "$key" '.[$k].value' "$CORE_OUTPUTS_FILE")
        export TF_VAR_private_subnet_ids
        ;;
      common_tags)
        # Map: rename to core_tags (our variable name)
        TF_VAR_core_tags=$(jq -c --arg k "$key" '.[$k].value' "$CORE_OUTPUTS_FILE")
        export TF_VAR_core_tags
        ;;
      *)
        # Scalars: export as TF_VAR_<key>
        export "TF_VAR_${key}=$value"
        ;;
    esac
  done

  info "Loaded core outputs from $CORE_OUTPUTS_FILE"
}

# ---- tfvars bootstrap ----
ensure_tfvars() {
  if [[ ! -f "$SCRIPT_DIR/terraform.tfvars" && -f "$SCRIPT_DIR/example.tfvars" ]]; then
    info "Copying example.tfvars → terraform.tfvars"
    cp "$SCRIPT_DIR/example.tfvars" "$SCRIPT_DIR/terraform.tfvars"
  fi
}

# ---- Image build ----
# Builds every enabled backend's image. The build scripts themselves check
# terraform outputs and skip backends whose ECR URL is null (disabled).
build_backend_images() {
  # Export AWS_ACCOUNT_ID for downstream build scripts.
  if [[ -z "${AWS_ACCOUNT_ID:-}" ]]; then
    AWS_ACCOUNT_ID=$(aws sts get-caller-identity --query Account --output text)
    export AWS_ACCOUNT_ID
  fi
  # AWS_REGION comes from core outputs (TF_VAR_aws_region).
  export AWS_REGION="${AWS_REGION:-${TF_VAR_aws_region}}"

  if [[ "$USE_CODEBUILD" == "true" ]]; then
    info "Building example backend images via CodeBuild..."
    bash "$SCRIPT_DIR/build-codebuild.sh"
  else
    info "Building example backend images locally with Docker..."
    bash "$SCRIPT_DIR/build-images.sh"
  fi
}

# ---- Actions ----

# Resolve a tfvar's effective value. Precedence: TF_VAR_ env > terraform.tfvars > default.
# Used during apply to decide which ECR repos to target in phase 1.
tfvar_value() {
  local name="$1"
  local default_value="$2"
  local env_name="TF_VAR_${name}"
  if [[ -n "${!env_name:-}" ]]; then
    echo "${!env_name}"
    return
  fi
  if [[ -f "$SCRIPT_DIR/terraform.tfvars" ]]; then
    # Match: name = true / "true" / false / "false" (ignore comments, whitespace-tolerant)
    local match
    match=$(awk -v k="$name" '
      $0 ~ "^[[:space:]]*"k"[[:space:]]*=" {
        sub("^[[:space:]]*"k"[[:space:]]*=[[:space:]]*", "")
        sub("[[:space:]]*#.*$", "")
        sub("^\"", ""); sub("\"[[:space:]]*$", "")
        print; exit
      }
    ' "$SCRIPT_DIR/terraform.tfvars")
    if [[ -n "$match" ]]; then
      echo "$match"
      return
    fi
  fi
  echo "$default_value"
}

do_apply() {
  preflight_tf_creds_check
  load_core_outputs
  ensure_tfvars
  cd "$SCRIPT_DIR"

  info "Initializing Terraform..."
  terraform init -upgrade

  # Default path: no ECR repos created, no build — one terraform apply.
  # --build-from-source runs the three-phase flow (ECR create → build → apply).
  if [[ "$BUILD_FROM_SOURCE" != "true" ]]; then
    info "Applying (single-phase, public images)..."
    terraform apply -auto-approve
  else
    # Resolve which backends are enabled (defaults mirror variables.tf).
    local deploy_hr deploy_deploy
    deploy_hr=$(tfvar_value deploy_hr_backend true)
    deploy_deploy=$(tfvar_value deploy_deploy_server false)

    # Three-phase apply: create each enabled backend's ECR repo first so
    # the build step has a target, build+push the images, then run the
    # full apply that includes the task definitions referencing those
    # images.
    local phase1_targets=()
    [[ "$deploy_hr" == "true" ]]     && phase1_targets+=( -target=aws_ecr_repository.hr_backend )
    [[ "$deploy_deploy" == "true" ]] && phase1_targets+=( -target=aws_ecr_repository.deploy_server )
    # Must exist before CodeBuild pushes to these ECR repos in Phase 2 — the
    # core CodeBuild role's base policy only whitelists core repos.
    if [[ ${#phase1_targets[@]} -gt 0 ]]; then
      phase1_targets+=( -target=aws_iam_role_policy.codebuild_examples_ecr_push )
    fi

    if [[ ${#phase1_targets[@]} -gt 0 ]]; then
      info "Phase 1: creating ECR repositories (${#phase1_targets[@]} target(s))..."
      terraform apply "${phase1_targets[@]}" -auto-approve

      info "Phase 2: building and pushing example backend images..."
      build_backend_images
    else
      warn "No example backends enabled — skipping image build."
    fi

    info "Phase 3: full apply..."
    terraform apply -auto-approve
  fi

  ok "Examples deployment complete."

  # ---- Post-apply banner: Admin UI registration hints ----
  echo ""
  echo "┌──────────────────────────────────────────────────────────────────────┐"
  echo "│  Register these backends in the Admin UI                             │"
  echo "│  (Admin UI → Resources → New)                                        │"
  echo "├──────────────────────────────────────────────────────────────────────┤"

  local hr_url deploy_url
  hr_url=$(terraform output -raw admin_ui_hr_backend_url 2>/dev/null || true)
  deploy_url=$(terraform output -raw admin_ui_deploy_server_url 2>/dev/null || true)

  if [[ -n "$hr_url" && "$hr_url" != "null" ]]; then
    printf "│  %-68s │\n" "hr-system"
    printf "│    URL:   %-60s │\n" "$hr_url"
    printf "│    Paths: %-60s │\n" "/hr"
    printf "│    Auth:  %-60s │\n" "Pre-Shared Key (X-API-Key = \$PSK_SECRET in task def)"
  else
    printf "│  %-68s │\n" "hr-system: (disabled — deploy_hr_backend=false)"
  fi
  printf "│  %-68s │\n" ""

  if [[ -n "$deploy_url" && "$deploy_url" != "null" ]]; then
    printf "│  %-68s │\n" "deploy-server"
    printf "│    URL:   %-60s │\n" "$deploy_url"
    printf "│    Paths: %-60s │\n" "/deploy"
    printf "│    Auth:  %-60s │\n" "okta-cross-app (ID-JAG)"
  else
    printf "│  %-68s │\n" "deploy-server: (disabled — deploy_deploy_server=false)"
  fi
  echo "└──────────────────────────────────────────────────────────────────────┘"
  echo ""
  info "Smoke test:  ./smoke-test.sh"
  info "Tear down:   ./deploy.sh --destroy"
}

do_plan() {
  preflight_tf_creds_check
  load_core_outputs
  ensure_tfvars
  cd "$SCRIPT_DIR"

  info "Initializing Terraform..."
  terraform init -upgrade

  info "Planning..."
  terraform plan
}

do_destroy() {
  preflight_tf_creds_check
  if [[ ! -f "$CORE_OUTPUTS_FILE" ]]; then
    warn "core-outputs.json not found. Attempting destroy with cached state..."
  else
    load_core_outputs
  fi
  cd "$SCRIPT_DIR"

  echo ""
  printf "${RED}${BOLD}Destroy examples resources? This is irreversible. [y/N]:${NC} "
  read -r confirm
  if [[ ! "$confirm" =~ ^[Yy]$ ]]; then
    info "Aborted."
    return 0
  fi

  info "Initializing Terraform..."
  terraform init -upgrade

  info "Destroying examples..."
  terraform destroy -auto-approve

  ok "Examples destroyed."
  echo ""
  info "Core is untouched. Destroy core separately if needed:"
  info "  cd $CORE_DIR && ./deploy.sh --destroy"
}

do_build_only() {
  if [[ "$BUILD_FROM_SOURCE" != "true" ]]; then
    die "--build-only requires --build-from-source (the default pulls prebuilt images from ECR Public — nothing to build)."
  fi
  preflight_tf_creds_check
  load_core_outputs
  cd "$SCRIPT_DIR"
  build_backend_images
  ok "Example backend images built and pushed."
}

# ---- Dispatch ----
case "$ACTION" in
  apply)      do_apply ;;
  plan)       do_plan ;;
  destroy)    do_destroy ;;
  build-only) do_build_only ;;
  *)          die "Unknown action: $ACTION" ;;
esac
