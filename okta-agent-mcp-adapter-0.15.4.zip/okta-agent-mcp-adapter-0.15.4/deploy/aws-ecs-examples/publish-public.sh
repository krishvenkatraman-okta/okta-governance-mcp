#!/usr/bin/env bash
set -euo pipefail

# =============================================================
# publish-public.sh — Publish example backends to ECR Public
# =============================================================
# Laptop-side ad-hoc publish. Builds with Docker Desktop + buildx and
# pushes to public.ecr.aws/${ECR_PUBLIC_ALIAS:-oktaps}/okta-mcp-{hr-server,deploy-server}
# using the currently logged-in AWS profile.
#
# For canonical tag-driven publishes, use the GitHub Actions workflow
# at .github/workflows/publish-public-ecr.yml.
#
# Prerequisites:
#   1. Docker Desktop (or equivalent) running; `docker buildx` available.
#   2. ECR Public repos exist under the alias for okta-mcp-hr-server
#      and okta-mcp-deploy-server (maintainer creates these once).
#   3. Current AWS principal has ecr-public:* + sts:GetServiceBearerToken.
#
# Usage:
#   ./publish-public.sh                         # both images, v<version> + :latest
#   ./publish-public.sh --images=hr-server      # only one image
#   ./publish-public.sh --tag=v0.15.0           # explicit tag override
#   ./publish-public.sh --no-latest             # skip :latest tag push
#   ECR_PUBLIC_ALIAS=foo ./publish-public.sh    # override alias (default "oktaps")
# =============================================================

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
REPO_ROOT="$(cd "$SCRIPT_DIR/../.." && pwd)"

# ---- Colors ----
if [[ -n "${NO_COLOR:-}" ]] || [[ ! -t 1 ]]; then
  RED='' GREEN='' CYAN='' NC=''
else
  RED='\033[0;31m'; GREEN='\033[0;32m'; CYAN='\033[0;36m'; NC='\033[0m'
fi
info() { printf "${CYAN}[INFO]${NC}  %b\n" "$*"; }
ok()   { printf "${GREEN}[  OK]${NC}  %b\n" "$*"; }
die()  { printf "${RED}[FAIL]${NC}  %b\n" "$*" >&2; exit 1; }

# ---- Args ----
IMAGES_CSV="hr-server,deploy-server"
TAG_OVERRIDE=""
ALSO_TAG_LATEST="true"
while [[ $# -gt 0 ]]; do
  case "$1" in
    --images=*)  IMAGES_CSV="${1#--images=}"; shift ;;
    --tag=*)     TAG_OVERRIDE="${1#--tag=}"; shift ;;
    --no-latest) ALSO_TAG_LATEST="false"; shift ;;
    -h|--help)
      sed -n '4,27p' "$0"; exit 0 ;;
    *) die "Unknown flag: $1" ;;
  esac
done

# ---- Config ----
ECR_PUBLIC_ALIAS="${ECR_PUBLIC_ALIAS:-oktaps}"

# ---- Resolve VERSION from pyproject.toml ----
if [[ -n "$TAG_OVERRIDE" ]]; then
  IMAGE_TAG="$TAG_OVERRIDE"
else
  PYPROJECT="$REPO_ROOT/pyproject.toml"
  [[ -f "$PYPROJECT" ]] || die "pyproject.toml not found at $PYPROJECT"
  VERSION=$(grep -m1 '^version' "$PYPROJECT" | sed 's/.*= *"\(.*\)"/\1/')
  [[ -n "$VERSION" ]] || die "Could not parse version from $PYPROJECT"
  IMAGE_TAG="v${VERSION}"
fi

IMAGES=$(echo "$IMAGES_CSV" | tr ',' ' ')
for img in $IMAGES; do
  case "$img" in
    hr-server|deploy-server) ;;
    *) die "Unknown image '$img'. Allowed: hr-server, deploy-server" ;;
  esac
done

# ---- Preflight ----
command -v docker >/dev/null 2>&1 || die "docker not found in PATH"
docker buildx version >/dev/null 2>&1 || die "docker buildx not available; install/enable buildx"
command -v aws >/dev/null 2>&1 || die "aws CLI not found in PATH"
aws sts get-caller-identity --no-cli-pager >/dev/null 2>&1 \
  || die "AWS CLI not authenticated. Run 'aws sso login' or export credentials."

info "Registry:         public.ecr.aws/${ECR_PUBLIC_ALIAS}/"
info "Images:           ${IMAGES}"
info "Tag:              ${IMAGE_TAG}"
info "Also tag :latest: ${ALSO_TAG_LATEST}"
echo

# ---- Login ----
info "Logging in to ECR Public (us-east-1) using current AWS profile..."
aws ecr-public get-login-password --region us-east-1 \
  | docker login --username AWS --password-stdin public.ecr.aws
ok "Logged in"

# ---- Build + push ----
cd "$REPO_ROOT"
for img in $IMAGES; do
  case "$img" in
    hr-server)
      REPO="public.ecr.aws/${ECR_PUBLIC_ALIAS}/okta-mcp-hr-server"
      CTX="examples/01-hr-system"
      ;;
    deploy-server)
      REPO="public.ecr.aws/${ECR_PUBLIC_ALIAS}/okta-mcp-deploy-server"
      CTX="examples/05-deploy-server"
      ;;
  esac

  TAG_ARGS=( -t "${REPO}:${IMAGE_TAG}" )
  [[ "$ALSO_TAG_LATEST" == "true" ]] && TAG_ARGS+=( -t "${REPO}:latest" )

  info "Building + pushing ${REPO}:${IMAGE_TAG}$([ "$ALSO_TAG_LATEST" = "true" ] && echo " + :latest")..."
  # --provenance=false --sbom=false disables BuildKit's default attestation
  # manifest, matching the GH Actions workflow's behavior. Without this you
  # get an extra 0-byte OCI artifact in ECR Public next to each image.
  docker buildx build \
    --platform linux/amd64 \
    --provenance=false \
    --sbom=false \
    --push \
    "${TAG_ARGS[@]}" \
    "$CTX"
  ok "${img}: pushed"
  echo
done

ok "Published ${IMAGES} to public.ecr.aws/${ECR_PUBLIC_ALIAS}/ as ${IMAGE_TAG}$([ "$ALSO_TAG_LATEST" = "true" ] && echo " + :latest")"
