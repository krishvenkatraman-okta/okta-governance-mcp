locals {
  common_tags = merge(
    var.core_tags,
    var.additional_tags,
    {
      Component = "examples"
    }
  )

  # ECR image URL resolution. When byo_ecr_repos=true, task definitions pull
  # from the provided registry URL (e.g. public.ecr.aws/oktaps/...) and the
  # ECR repo + CodeBuild push IAM resources are not created.
  ecr_hr_backend_url = var.byo_ecr_repos ? var.existing_ecr_hr_backend_url : (
    var.deploy_hr_backend ? aws_ecr_repository.hr_backend[0].repository_url : ""
  )
  ecr_deploy_server_url = var.byo_ecr_repos ? var.existing_ecr_deploy_server_url : (
    var.deploy_deploy_server ? aws_ecr_repository.deploy_server[0].repository_url : ""
  )
}
