# -----------------------------------------------------------------------------
# main.tf — Example MCP backends (HR + deploy-server)
# -----------------------------------------------------------------------------
# Deploys the example MCP servers as ECS Fargate services in the core
# cluster. Shared infrastructure (VPC, subnets, SGs, Service Connect
# namespace, IAM roles) is consumed from the core deployment via the
# core-outputs.json contract.
#
# Every resource is gated by the corresponding deploy_* flag so operators
# can enable/disable each example independently.
# -----------------------------------------------------------------------------

# --- ECR Repository ---

resource "aws_ecr_repository" "hr_backend" {
  count = var.deploy_hr_backend && !var.byo_ecr_repos ? 1 : 0

  name                 = "${var.project_name}-hr-backend"
  image_tag_mutability = "MUTABLE"
  force_delete         = true

  image_scanning_configuration {
    scan_on_push = true
  }

  tags = local.common_tags
}

# --- ECR Lifecycle Policy ---

resource "aws_ecr_lifecycle_policy" "hr_backend" {
  count = var.deploy_hr_backend && !var.byo_ecr_repos ? 1 : 0

  repository = aws_ecr_repository.hr_backend[0].name

  policy = jsonencode({
    rules = [
      {
        rulePriority = 1
        description  = "Expire untagged images after 7 days"
        selection = {
          tagStatus   = "untagged"
          countType   = "sinceImagePushed"
          countUnit   = "days"
          countNumber = 7
        }
        action = {
          type = "expire"
        }
      },
      {
        rulePriority = 2
        description  = "Keep last 10 images"
        selection = {
          tagStatus   = "any"
          countType   = "imageCountMoreThan"
          countNumber = 10
        }
        action = {
          type = "expire"
        }
      }
    ]
  })
}

# --- Security Group Rule (east-west on core's ECS tasks SG) ---

resource "aws_security_group_rule" "ecs_ingress_hr_backend" {
  count = var.deploy_hr_backend ? 1 : 0

  security_group_id        = var.ecs_tasks_sg_id
  type                     = "ingress"
  description              = "HR backend east-west (adapter to backend)"
  from_port                = var.hr_backend_port
  to_port                  = var.hr_backend_port
  protocol                 = "tcp"
  source_security_group_id = var.ecs_tasks_sg_id
}

# --- CloudWatch Log Group ---

resource "aws_cloudwatch_log_group" "hr_backend" {
  count = var.deploy_hr_backend ? 1 : 0

  name              = "/ecs/${var.project_name}-hr-backend"
  retention_in_days = var.hr_backend_log_retention_days

  tags = local.common_tags
}

# --- ECS Task Definition ---

resource "aws_ecs_task_definition" "hr_backend" {
  count = var.deploy_hr_backend ? 1 : 0

  family                   = "${var.project_name}-hr-backend"
  requires_compatibilities = ["FARGATE"]
  network_mode             = "awsvpc"
  cpu                      = 256
  memory                   = 512
  execution_role_arn       = var.ecs_task_execution_role_arn
  task_role_arn            = var.ecs_task_role_arn

  container_definitions = jsonencode([
    {
      name      = "hr-backend"
      image     = "${local.ecr_hr_backend_url}:${var.hr_backend_image_tag}"
      essential = true

      portMappings = [
        {
          containerPort = var.hr_backend_port
          name          = "hr-backend-http"
          protocol      = "tcp"
        }
      ]

      healthCheck = {
        command     = ["CMD-SHELL", "curl -f http://localhost:${var.hr_backend_port}/health || exit 1"]
        interval    = 30
        timeout     = 5
        retries     = 3
        startPeriod = 30
      }

      environment = [
        { name = "HR_BACKEND_PORT", value = tostring(var.hr_backend_port) },
        { name = "SERVER_PORT", value = tostring(var.hr_backend_port) },  # Deprecated fallback, remove in v2.0.0
        { name = "PSK_TOKEN", value = "demo-psk-token" },
      ]

      logConfiguration = {
        logDriver = "awslogs"
        options = {
          "awslogs-group"         = aws_cloudwatch_log_group.hr_backend[0].name
          "awslogs-region"        = var.aws_region
          "awslogs-stream-prefix" = "hr-backend"
        }
      }
    }
  ])

  tags = local.common_tags
}

# --- ECS Service ---

resource "aws_ecs_service" "hr_backend" {
  count = var.deploy_hr_backend ? 1 : 0

  name                 = "hr-backend"
  cluster              = var.cluster_arn
  task_definition      = aws_ecs_task_definition.hr_backend[0].arn
  desired_count        = 1
  launch_type          = "FARGATE"
  platform_version     = "LATEST"
  force_new_deployment = true

  network_configuration {
    subnets          = var.private_subnet_ids
    security_groups  = [var.ecs_tasks_sg_id]
    assign_public_ip = false
  }

  service_connect_configuration {
    enabled   = true
    namespace = var.service_discovery_namespace_arn

    service {
      port_name      = "hr-backend-http"
      discovery_name = "hr-backend"

      client_alias {
        port     = var.hr_backend_port
        dns_name = "hr-backend.${var.project_name}.local"
      }
    }
  }

  deployment_circuit_breaker {
    enable   = true
    rollback = true
  }

  tags = local.common_tags
}

# =============================================================================
# Deploy-server example (okta-cross-app / ID-JAG auth)
# =============================================================================

# --- ECR Repository ---

resource "aws_ecr_repository" "deploy_server" {
  count = var.deploy_deploy_server && !var.byo_ecr_repos ? 1 : 0

  name                 = "${var.project_name}-deploy-server"
  image_tag_mutability = "MUTABLE"
  force_delete         = true

  image_scanning_configuration {
    scan_on_push = true
  }

  tags = local.common_tags
}

# --- ECR Lifecycle Policy ---

resource "aws_ecr_lifecycle_policy" "deploy_server" {
  count = var.deploy_deploy_server && !var.byo_ecr_repos ? 1 : 0

  repository = aws_ecr_repository.deploy_server[0].name

  policy = jsonencode({
    rules = [
      {
        rulePriority = 1
        description  = "Expire untagged images after 7 days"
        selection = {
          tagStatus   = "untagged"
          countType   = "sinceImagePushed"
          countUnit   = "days"
          countNumber = 7
        }
        action = {
          type = "expire"
        }
      },
      {
        rulePriority = 2
        description  = "Keep last 10 images"
        selection = {
          tagStatus   = "any"
          countType   = "imageCountMoreThan"
          countNumber = 10
        }
        action = {
          type = "expire"
        }
      }
    ]
  })
}

# --- CodeBuild ECR push policy (scoped to example ECR repos) ---
# Core's CodeBuild IAM role whitelists only the adapter/admin-ui ECR ARNs.
# Extend it here so the shared CodeBuild project can push images to the
# examples' ECR repos without widening core's policy to Resource = "*".
resource "aws_iam_role_policy" "codebuild_examples_ecr_push" {
  # When byo_ecr_repos=true we don't own the registry (e.g. pulling from
  # public.ecr.aws), so there's no private-ECR ARN to grant push on.
  count = !var.byo_ecr_repos && (var.deploy_hr_backend || var.deploy_deploy_server) ? 1 : 0

  name = "${var.project_name}-codebuild-examples-ecr-push"
  role = var.codebuild_role_name

  policy = jsonencode({
    Version = "2012-10-17"
    Statement = [
      {
        Sid    = "ECRPushExampleRepos"
        Effect = "Allow"
        Action = [
          "ecr:BatchCheckLayerAvailability",
          "ecr:PutImage",
          "ecr:InitiateLayerUpload",
          "ecr:UploadLayerPart",
          "ecr:CompleteLayerUpload",
          "ecr:BatchGetImage",
          "ecr:GetDownloadUrlForLayer",
        ]
        Resource = compact([
          var.deploy_hr_backend ? aws_ecr_repository.hr_backend[0].arn : "",
          var.deploy_deploy_server ? aws_ecr_repository.deploy_server[0].arn : "",
        ])
      },
    ]
  })
}

# --- Security Group Rule (east-west on core's ECS tasks SG) ---

resource "aws_security_group_rule" "ecs_ingress_deploy_server" {
  count = var.deploy_deploy_server ? 1 : 0

  security_group_id        = var.ecs_tasks_sg_id
  type                     = "ingress"
  description              = "Deploy-server east-west (adapter to backend)"
  from_port                = var.deploy_server_port
  to_port                  = var.deploy_server_port
  protocol                 = "tcp"
  source_security_group_id = var.ecs_tasks_sg_id
}

# --- CloudWatch Log Group ---

resource "aws_cloudwatch_log_group" "deploy_server" {
  count = var.deploy_deploy_server ? 1 : 0

  name              = "/ecs/${var.project_name}-deploy-server"
  retention_in_days = var.deploy_server_log_retention_days

  tags = local.common_tags
}

# --- ECS Task Definition ---
#
# Deploy-server is a pure resource server: it validates Bearer tokens using
# okta-jwt-verifier against the issuer derived from DEPLOY_OKTA_DOMAIN +
# DEPLOY_OKTA_AUTH_SERVER_ID. Both are required at startup.

resource "aws_ecs_task_definition" "deploy_server" {
  count = var.deploy_deploy_server ? 1 : 0

  family                   = "${var.project_name}-deploy-server"
  requires_compatibilities = ["FARGATE"]
  network_mode             = "awsvpc"
  cpu                      = 256
  memory                   = 512
  execution_role_arn       = var.ecs_task_execution_role_arn
  task_role_arn            = var.ecs_task_role_arn

  lifecycle {
    precondition {
      condition     = var.deploy_server_okta_domain != "" && var.deploy_server_okta_auth_server_id != ""
      error_message = "deploy_deploy_server=true requires both deploy_server_okta_domain and deploy_server_okta_auth_server_id. Set them in terraform.tfvars or as TF_VAR_* env vars."
    }
  }

  container_definitions = jsonencode([
    {
      name      = "deploy-server"
      image     = "${local.ecr_deploy_server_url}:${var.deploy_server_image_tag}"
      essential = true

      portMappings = [
        {
          containerPort = var.deploy_server_port
          name          = "deploy-server-http"
          protocol      = "tcp"
        }
      ]

      healthCheck = {
        command     = ["CMD-SHELL", "python -c \"import os,socket; s=socket.create_connection(('localhost',int(os.getenv('DEPLOY_SERVER_PORT','${var.deploy_server_port}'))),timeout=5); s.close()\" || exit 1"]
        interval    = 30
        timeout     = 5
        retries     = 3
        startPeriod = 30
      }

      environment = [
        { name = "DEPLOY_SERVER_PORT", value = tostring(var.deploy_server_port) },
        { name = "SERVER_PORT", value = tostring(var.deploy_server_port) }, # Deprecated fallback
        { name = "DEPLOY_OKTA_DOMAIN", value = var.deploy_server_okta_domain },
        { name = "DEPLOY_OKTA_AUTH_SERVER_ID", value = var.deploy_server_okta_auth_server_id },
        { name = "DEPLOY_OKTA_AUDIENCE", value = var.deploy_server_okta_audience },
        { name = "LOG_LEVEL", value = "INFO" },
      ]

      logConfiguration = {
        logDriver = "awslogs"
        options = {
          "awslogs-group"         = aws_cloudwatch_log_group.deploy_server[0].name
          "awslogs-region"        = var.aws_region
          "awslogs-stream-prefix" = "deploy-server"
        }
      }
    }
  ])

  tags = local.common_tags
}

# --- ECS Service ---

resource "aws_ecs_service" "deploy_server" {
  count = var.deploy_deploy_server ? 1 : 0

  name                 = "deploy-server"
  cluster              = var.cluster_arn
  task_definition      = aws_ecs_task_definition.deploy_server[0].arn
  desired_count        = 1
  launch_type          = "FARGATE"
  platform_version     = "LATEST"
  force_new_deployment = true

  network_configuration {
    subnets          = var.private_subnet_ids
    security_groups  = [var.ecs_tasks_sg_id]
    assign_public_ip = false
  }

  service_connect_configuration {
    enabled   = true
    namespace = var.service_discovery_namespace_arn

    service {
      port_name      = "deploy-server-http"
      discovery_name = "deploy-server"

      client_alias {
        port     = var.deploy_server_port
        dns_name = "deploy-server.${var.project_name}.local"
      }
    }
  }

  deployment_circuit_breaker {
    enable   = true
    rollback = true
  }

  tags = local.common_tags
}
