#!/usr/bin/env bash
set -euo pipefail

# =============================================================
# smoke-test.sh — Validate example backend ECS services are healthy
# =============================================================
# Polls each enabled example backend (hr-backend, deploy-server)
# until running count equals desired count AND the latest
# deployment's rolloutState == COMPLETED.
#
# Skips any backend whose Terraform output is null (disabled).
# =============================================================

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
CORE_OUTPUTS_FILE="$SCRIPT_DIR/../aws-ecs/core-outputs.json"

# shellcheck disable=SC1091
source "$SCRIPT_DIR/shell-lib/common.sh"

cd "$SCRIPT_DIR"

# ---- Resolve cluster + region (shared across all backends) ----
CLUSTER_NAME=$(terraform output -raw cluster_name 2>/dev/null || true)
if [[ -z "$CLUSTER_NAME" || "$CLUSTER_NAME" == "null" ]]; then
  if [[ -f "$CORE_OUTPUTS_FILE" ]]; then
    CLUSTER_NAME=$(jq -r '.cluster_name.value' "$CORE_OUTPUTS_FILE")
  fi
fi
[[ -z "$CLUSTER_NAME" || "$CLUSTER_NAME" == "null" ]] && \
  die "Could not determine cluster_name. Run core deploy first."

REGION=$(terraform output -raw aws_region 2>/dev/null || true)
if [[ -z "$REGION" || "$REGION" == "null" ]]; then
  if [[ -f "$CORE_OUTPUTS_FILE" ]]; then
    REGION=$(jq -r '.aws_region.value' "$CORE_OUTPUTS_FILE")
  fi
fi
[[ -z "$REGION" || "$REGION" == "null" ]] && REGION="${AWS_REGION:-us-east-1}"

PROJECT_NAME=$(terraform output -raw project_name 2>/dev/null || echo '<project>')

# check_backend_health <label> <output_name> <log_group_suffix>
check_backend_health() {
  local label="$1"
  local output_name="$2"
  local log_suffix="$3"

  local service_name
  service_name=$(terraform output -raw "$output_name" 2>/dev/null || true)
  if [[ -z "$service_name" || "$service_name" == "null" ]]; then
    info "${label}: not deployed (disabled). Skipping."
    return 0
  fi

  info "Checking ${label} ECS service: $service_name"
  info "  Cluster: $CLUSTER_NAME"
  info "  Region:  $REGION"

  local tries=0
  local max=30
  while (( tries < max )); do
    local state
    state=$(aws ecs describe-services \
      --cluster "$CLUSTER_NAME" \
      --services "$service_name" \
      --region "$REGION" \
      --query 'services[0].[desiredCount,runningCount,deployments[0].rolloutState]' \
      --output text 2>/dev/null || echo "")

    if [[ -z "$state" ]]; then
      warn "${label}: could not read service state. Retrying..."
    else
      local desired running rollout
      desired=$(echo "$state" | awk '{print $1}')
      running=$(echo "$state" | awk '{print $2}')
      rollout=$(echo "$state" | awk '{print $3}')

      if [[ "$running" == "$desired" && "$rollout" == "COMPLETED" ]]; then
        ok "${label} healthy: $running/$desired tasks running."
        return 0
      fi
      info "${label}: $running/$desired running, rollout=$rollout. Retrying..."
    fi

    sleep 10
    tries=$((tries + 1))
  done

  fail "${label} did not reach healthy state in $((max * 10))s."
  info "Diagnose with:"
  info "  aws ecs describe-services --cluster $CLUSTER_NAME \\"
  info "    --services $service_name --region $REGION"
  info "  aws logs tail /ecs/${PROJECT_NAME}-${log_suffix} --region $REGION --follow"
  return 1
}

# ---- Check each backend in sequence ----
FAIL_COUNT=0

check_backend_health "HR backend" "hr_backend_service_name" "hr-backend" || FAIL_COUNT=$((FAIL_COUNT + 1))
echo ""
check_backend_health "Deploy-server" "deploy_server_service_name" "deploy-server" || FAIL_COUNT=$((FAIL_COUNT + 1))

if [[ "$FAIL_COUNT" -gt 0 ]]; then
  echo ""
  fail "$FAIL_COUNT backend(s) failed health check."
  exit 1
fi
