#!/usr/bin/env bash
set -euo pipefail

# =============================================================
# build-codebuild.sh — Build example backend images via AWS CodeBuild
# =============================================================
# Packages each enabled example backend's source, uploads to the
# core's CodeBuild source bucket under a distinct key, and triggers
# the core's CodeBuild project with a buildspec + env override for
# each backend.
#
# This reuses core's CodeBuild project (IAM role + environment) so
# examples doesn't need a second CodeBuild.
#
# Disabled backends (their terraform output is null) are skipped.
# =============================================================

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
REPO_ROOT="$(cd "$SCRIPT_DIR/../.." && pwd)"
CORE_DIR="$(cd "$SCRIPT_DIR/../aws-ecs" && pwd)"
CORE_OUTPUTS_FILE="$CORE_DIR/core-outputs.json"

# shellcheck disable=SC1091
source "$SCRIPT_DIR/shell-lib/common.sh"

# ---- Required env vars ----
: "${AWS_REGION:?AWS_REGION must be set}"

validate_command jq "Install jq (https://stedolan.github.io/jq/)."
validate_command zip "Install zip."
validate_command aws "Install AWS CLI."

# ---- Resolve inputs from core + examples terraform state ----
if [[ ! -f "$CORE_OUTPUTS_FILE" ]]; then
  die "core-outputs.json not found at $CORE_OUTPUTS_FILE. Run core deploy first."
fi

PROJECT_NAME=$(jq -r '.project_name.value' "$CORE_OUTPUTS_FILE")
[[ -z "$PROJECT_NAME" || "$PROJECT_NAME" == "null" ]] && \
  die "Could not read project_name from core-outputs.json"

CODEBUILD_PROJECT="${PROJECT_NAME}-image-builder"
ACCOUNT_ID=$(aws sts get-caller-identity --query Account --output text)
S3_BUCKET="${PROJECT_NAME}-codebuild-${ACCOUNT_ID}"
IMAGE_TAG="${IMAGE_TAG:-latest}"
BUILDSPEC_CONTENTS=$(cat "$SCRIPT_DIR/buildspec.yml")

cd "$SCRIPT_DIR"

# build_backend_image <label> <output_name> <source_subdir> <ecr_env_name> <source_zip_name>
#
# label: human-readable name for logs ("HR backend")
# output_name: terraform output key that exposes the ECR URL
# source_subdir: repo-relative path to the backend source
# ecr_env_name: env var name passed to buildspec (BACKEND_ECR_URL)
# source_zip_name: S3 key for the zipped source
build_backend_image() {
  local label="$1"
  local output_name="$2"
  local source_subdir="$3"
  local ecr_env_name="$4"
  local source_zip_name="$5"

  local ecr_url
  ecr_url=$(terraform output -raw "$output_name" 2>/dev/null || true)
  if [[ -z "$ecr_url" || "$ecr_url" == "null" ]]; then
    warn "${label}: ${output_name} not available (backend disabled or phase 1 not applied). Skipping."
    return 0
  fi

  info "${label}: packaging source for CodeBuild..."
  local tmp_zip
  tmp_zip=$(mktemp -t "${source_zip_name%.zip}.XXXXXX.zip")
  rm -f "$tmp_zip"
  # Shell trap will leave this behind if the script dies mid-run, which is
  # fine — /tmp is ephemeral and the next invocation makes a fresh mktemp.

  (
    cd "$REPO_ROOT"
    zip -rq "$tmp_zip" \
      "$source_subdir" \
      -x "*.pyc" "__pycache__/*" "node_modules/*" \
         ".git/*" "tests/*" ".claude/*"
  )

  info "${label}: uploading source to s3://${S3_BUCKET}/${source_zip_name}..."
  aws s3 cp "$tmp_zip" "s3://${S3_BUCKET}/${source_zip_name}" \
    --region "$AWS_REGION" --quiet
  rm -f "$tmp_zip"
  ok "${label}: source uploaded"

  info "${label}: starting CodeBuild project: ${CODEBUILD_PROJECT}..."
  local build_id
  build_id=$(aws codebuild start-build \
    --project-name "$CODEBUILD_PROJECT" \
    --region "$AWS_REGION" \
    --source-location-override "${S3_BUCKET}/${source_zip_name}" \
    --buildspec-override "$BUILDSPEC_CONTENTS" \
    --environment-variables-override \
      "name=BACKEND_SOURCE_DIR,value=${source_subdir},type=PLAINTEXT" \
      "name=BACKEND_ECR_URL,value=${ecr_url},type=PLAINTEXT" \
      "name=IMAGE_TAG,value=${IMAGE_TAG},type=PLAINTEXT" \
      "name=AWS_ACCOUNT_ID,value=${ACCOUNT_ID},type=PLAINTEXT" \
    --query 'build.id' --output text)

  echo "  Build ID: $build_id"
  info "${label}: waiting for build to complete (typically 3-5 min)..."

  while true; do
    local status
    status=$(aws codebuild batch-get-builds --ids "$build_id" \
      --region "$AWS_REGION" \
      --query 'builds[0].buildStatus' --output text)
    case "$status" in
      SUCCEEDED)
        ok "${label}: CodeBuild completed successfully"
        return 0 ;;
      FAILED|FAULT|TIMED_OUT|STOPPED)
        die "${label}: CodeBuild failed: $status
  View logs:
    aws codebuild batch-get-builds --ids $build_id --region $AWS_REGION
    aws logs tail /codebuild/${PROJECT_NAME} --region $AWS_REGION"
        ;;
      *)
        printf "\r  ${label} status: %-20s" "$status"
        sleep 10 ;;
    esac
  done
}

BUILT_ANY=0

if build_backend_image \
    "HR backend" \
    "hr_backend_ecr_url" \
    "examples/01-hr-system" \
    "BACKEND_ECR_URL" \
    "hr-backend-source.zip"; then
  HR_ECR_URL=$(terraform output -raw hr_backend_ecr_url 2>/dev/null || true)
  [[ -n "$HR_ECR_URL" && "$HR_ECR_URL" != "null" ]] && BUILT_ANY=1
fi
echo ""

if build_backend_image \
    "Deploy-server" \
    "deploy_server_ecr_url" \
    "examples/05-deploy-server" \
    "BACKEND_ECR_URL" \
    "deploy-server-source.zip"; then
  DEPLOY_ECR_URL=$(terraform output -raw deploy_server_ecr_url 2>/dev/null || true)
  [[ -n "$DEPLOY_ECR_URL" && "$DEPLOY_ECR_URL" != "null" ]] && BUILT_ANY=1
fi
echo ""

if [[ "$BUILT_ANY" -eq 0 ]]; then
  die "No images built — all example backends appear disabled or phase 1 hasn't been applied."
fi
