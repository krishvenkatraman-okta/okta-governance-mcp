# -----------------------------------------------------------------------------
# variables.tf — Examples project (HR backend + deploy-server)
# -----------------------------------------------------------------------------
# Inputs are split into two groups:
#   1. Shared-contract inputs loaded from core's core-outputs.json by deploy.sh
#   2. Examples-specific toggles and per-example config
# -----------------------------------------------------------------------------

# --- Inputs from core (required) ---

variable "aws_region" {
  type        = string
  description = "AWS region. Must match the core deployment."
}

variable "project_name" {
  type        = string
  description = "Project name prefix, from core output."

  validation {
    condition     = can(regex("^[a-z0-9-]+$", var.project_name))
    error_message = "project_name must be lowercase alphanumeric with hyphens."
  }
}

variable "cluster_arn" {
  type        = string
  description = "ARN of the core ECS cluster."
}

variable "cluster_name" {
  type        = string
  description = "Name of the core ECS cluster."
}

variable "service_discovery_namespace_arn" {
  type        = string
  description = "ARN of the core Service Connect namespace."
}

variable "ecs_tasks_sg_id" {
  type        = string
  description = "ID of the core ECS tasks security group."
}

variable "alb_sg_id" {
  type        = string
  description = "ID of the core ALB security group (for east-west SG rule)."
}

variable "ecs_task_role_arn" {
  type        = string
  description = "ARN of the core ECS task role."
}

variable "ecs_task_execution_role_arn" {
  type        = string
  description = "ARN of the core ECS task execution role."
}

variable "private_subnet_ids" {
  type        = list(string)
  description = "Private subnet IDs from core."
}

variable "vpc_id" {
  type        = string
  description = "VPC ID from core (used for SG rule scoping)."
}

variable "core_tags" {
  type        = map(string)
  description = "Common tags from core, inherited by examples."
  default     = {}
}

variable "codebuild_role_name" {
  type        = string
  description = "Name of the core CodeBuild IAM role. Examples attaches a scoped ECR push policy for its ECR repos so the shared CodeBuild project can push example images."
}

# --- Examples-specific ---

# --- BYO (Bring Your Own) ECR ---
# Set byo_ecr_repos=true when task defs should pull from an existing registry
# (e.g., ECR Public under public.ecr.aws/oktaps/) instead of ECR repos this
# stack creates. When true, Phase 1 (ECR repo create) and the CodeBuild push
# IAM attachment are skipped; deploy.sh also skips Phase 2 (build-and-push).

variable "byo_ecr_repos" {
  type        = bool
  default     = false
  description = "Use existing registry URLs instead of creating private ECR repos. Pair with existing_ecr_hr_backend_url and existing_ecr_deploy_server_url."
}

variable "existing_ecr_hr_backend_url" {
  type        = string
  default     = ""
  description = "Existing registry URL for the hr-backend image (e.g., public.ecr.aws/oktaps/okta-mcp-hr-server). Required when byo_ecr_repos=true and deploy_hr_backend=true."
}

variable "existing_ecr_deploy_server_url" {
  type        = string
  default     = ""
  description = "Existing registry URL for the deploy-server image (e.g., public.ecr.aws/oktaps/okta-mcp-deploy-server). Required when byo_ecr_repos=true and deploy_deploy_server=true."
}

variable "deploy_hr_backend" {
  type        = bool
  default     = true
  description = "Deploy the HR example backend. Set false to skip."
}

variable "hr_backend_image_tag" {
  type        = string
  default     = "latest"
  description = "Container image tag for HR backend."
}

variable "hr_backend_log_retention_days" {
  type        = number
  default     = 7
  description = "CloudWatch log retention for HR backend."
}

# --- Tags (examples may add its own) ---

variable "additional_tags" {
  type        = map(string)
  default     = {}
  description = "Extra tags applied to examples resources only."
}

# --- Ports ---

variable "hr_backend_port" {
  type        = number
  default     = 8001
  description = "TCP port the HR example backend listens on inside the container. Used for Service Connect advertise."
  validation {
    condition     = var.hr_backend_port >= 1 && var.hr_backend_port <= 65535
    error_message = "hr_backend_port must be between 1 and 65535."
  }
}

# --- Deploy-server ---

variable "deploy_deploy_server" {
  type        = bool
  default     = false
  description = "Deploy the deploy-server example backend (okta-cross-app / ID-JAG auth). Requires deploy_server_okta_domain and deploy_server_okta_auth_server_id."
}

variable "deploy_server_image_tag" {
  type        = string
  default     = "latest"
  description = "Container image tag for deploy-server."
}

variable "deploy_server_log_retention_days" {
  type        = number
  default     = 7
  description = "CloudWatch log retention for deploy-server."
}

variable "deploy_server_port" {
  type        = number
  default     = 8005
  description = "TCP port the deploy-server listens on. Used for Service Connect advertise."
  validation {
    condition     = var.deploy_server_port >= 1 && var.deploy_server_port <= 65535
    error_message = "deploy_server_port must be between 1 and 65535."
  }
}

variable "deploy_server_okta_domain" {
  type        = string
  default     = ""
  description = "Okta domain (e.g. dev-123.okta.com) used by deploy-server to build the issuer for token validation. Required when deploy_deploy_server=true."
  validation {
    condition     = var.deploy_server_okta_domain == "" || can(regex("^[a-zA-Z0-9][a-zA-Z0-9.-]+$", var.deploy_server_okta_domain))
    error_message = "deploy_server_okta_domain must be a bare domain (no scheme, no trailing slash), e.g. dev-123.okta.com."
  }
}

variable "deploy_server_okta_auth_server_id" {
  type        = string
  default     = ""
  description = "Okta custom authorization server ID used by deploy-server (e.g. ausABC123... or 'default'). Required when deploy_deploy_server=true."
}

variable "deploy_server_okta_audience" {
  type        = string
  default     = "api://deploy-server"
  description = "Expected audience claim for deploy-server access tokens. Must match the audience configured on the Okta resource server."
}
