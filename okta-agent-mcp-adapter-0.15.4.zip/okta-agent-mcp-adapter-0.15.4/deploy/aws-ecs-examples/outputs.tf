output "hr_backend_ecr_url" {
  value       = local.ecr_hr_backend_url != "" ? local.ecr_hr_backend_url : null
  description = "Registry URL for HR backend image (private ECR or public.ecr.aws). Null if not deployed."
}

output "hr_backend_service_name" {
  value       = try(aws_ecs_service.hr_backend[0].name, null)
  description = "ECS service name for HR backend. Null if not deployed."
}

output "hr_backend_service_connect_dns" {
  value       = var.deploy_hr_backend ? "hr-backend.${var.project_name}.local" : null
  description = "Service Connect DNS for HR backend (internal cluster address)."
}

output "hr_backend_port" {
  value       = var.hr_backend_port
  description = "HR backend port."
}

output "deploy_server_ecr_url" {
  value       = local.ecr_deploy_server_url != "" ? local.ecr_deploy_server_url : null
  description = "Registry URL for deploy-server image (private ECR or public.ecr.aws). Null if not deployed."
}

output "deploy_server_service_name" {
  value       = try(aws_ecs_service.deploy_server[0].name, null)
  description = "ECS service name for deploy-server. Null if not deployed."
}

output "deploy_server_service_connect_dns" {
  value       = var.deploy_deploy_server ? "deploy-server.${var.project_name}.local" : null
  description = "Service Connect DNS for deploy-server (internal cluster address)."
}

output "deploy_server_port" {
  value       = var.deploy_server_port
  description = "Deploy-server port."
}

# --- Admin UI registration hints ---
# Paste these values into Admin UI → Resources → New to register each backend.

output "admin_ui_hr_backend_url" {
  value       = var.deploy_hr_backend ? "http://hr-backend.${var.project_name}.local:${var.hr_backend_port}" : null
  description = "URL to paste into the Admin UI when registering the HR backend resource."
}

output "admin_ui_deploy_server_url" {
  value       = var.deploy_deploy_server ? "http://deploy-server.${var.project_name}.local:${var.deploy_server_port}" : null
  description = "URL to paste into the Admin UI when registering the deploy-server resource."
}
