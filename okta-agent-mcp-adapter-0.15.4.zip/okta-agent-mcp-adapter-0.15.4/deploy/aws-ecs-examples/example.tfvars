# -----------------------------------------------------------------------------
# example.tfvars — Examples project (HR backend + deploy-server)
# -----------------------------------------------------------------------------
# Copy to terraform.tfvars (deploy.sh does this automatically if missing).
# The shared-contract inputs are loaded from ../aws-ecs/core-outputs.json by
# deploy.sh and exported as TF_VAR_* env vars — do NOT set them here unless
# you are running terraform directly (without deploy.sh).
# -----------------------------------------------------------------------------

# Deployment toggle (set false to provision infra but skip HR)
deploy_hr_backend = true

# Image tag (typically "latest")
hr_backend_image_tag = "latest"

# Log retention (days)
hr_backend_log_retention_days = 7

# Additional tags (merged with core_tags from core output)
additional_tags = {}

# --- Deploy-server (okta-cross-app / ID-JAG) ---
#
# Deploy-server validates Bearer tokens using okta-jwt-verifier. When enabled,
# deploy_server_okta_domain and deploy_server_okta_auth_server_id are REQUIRED
# and must match the Okta resource server you configured for this backend.

deploy_deploy_server = false

deploy_server_image_tag          = "latest"
deploy_server_log_retention_days = 7
deploy_server_port               = 8005

# Required when deploy_deploy_server = true (bare domain, no scheme):
# deploy_server_okta_domain          = "dev-123.okta.com"
# deploy_server_okta_auth_server_id  = "default"          # or ausXXXXXXXXXXXXXX

# Audience claim expected on AT-2 access tokens. Must match the audience
# configured on the Okta resource server. Default matches docker-compose.
deploy_server_okta_audience = "api://deploy-server"

# -----------------------------------------------------------------------------
# Shared inputs — come from core-outputs.json via deploy.sh.
# Uncomment and fill in ONLY if running terraform directly (not via deploy.sh).
# -----------------------------------------------------------------------------
# aws_region                       = "us-east-1"
# project_name                     = "oktaps-mcp"
# cluster_arn                      = "arn:aws:ecs:us-east-1:123456789012:cluster/oktaps-mcp-cluster"
# cluster_name                     = "oktaps-mcp-cluster"
# service_discovery_namespace_arn  = "arn:aws:servicediscovery:us-east-1:123456789012:namespace/ns-..."
# ecs_tasks_sg_id                  = "sg-abc123"
# alb_sg_id                        = "sg-def456"
# ecs_task_role_arn                = "arn:aws:iam::123456789012:role/oktaps-mcp-ecs-task"
# ecs_task_execution_role_arn      = "arn:aws:iam::123456789012:role/oktaps-mcp-ecs-task-execution"
# private_subnet_ids               = ["subnet-abc", "subnet-def"]
# vpc_id                           = "vpc-xyz"
# core_tags                        = { Project = "oktaps-mcp" }
