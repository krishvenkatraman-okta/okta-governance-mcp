# Horizontal Scaling Guide

The Okta MCP Adapter supports horizontal scaling (2+ replicas behind a load balancer) when backed by a shared Redis instance. This document covers the required configuration, sizing, health checks, and known limitations.

## Prerequisites

All four must be met before running multiple replicas:

| # | Requirement | Why |
|---|-------------|-----|
| 1 | `CACHE_PROVIDER=redis` | Switches all caches from in-memory to Redis-backed L2 |
| 2 | `REDIS_URL` set and reachable from every pod | All pods must share the same Redis instance |
| 3 | `ENCRYPTION_KEY` identical across every pod | Pods encrypt/decrypt each other's cached data (AES-256-GCM) |
| 4 | Starlette HTTP transport (the default) | All per-flow state lives in Redis; no in-process session affinity |

Single-pod deployments continue to work with `CACHE_PROVIDER=memory` (the default).

## Required Environment Variables

| Variable | Required | Default | Description |
|----------|----------|---------|-------------|
| `CACHE_PROVIDER` | Yes | `memory` | Set to `redis` for multi-pod |
| `REDIS_URL` | Yes | `redis://localhost:6379` | Redis connection URL (all pods must use the same URL) |
| `REDIS_PASSWORD` | Yes | `redis-secret` | Redis authentication password |
| `REDIS_TLS_ENABLED` | Recommended | `false` | Enable TLS for Redis connections (required for Azure Cache for Redis) |
| `REDIS_KEY_PREFIX` | No | `okta-mcp:` | Key prefix for all Redis keys (allows sharing a Redis instance) |
| `ENCRYPTION_KEY` | Yes | — | AES-256 key (base64-encoded). Generate with `python ops_scripts/generate_encryption_key.py`. Must be identical on every pod. |

## Recommended Redis Sizing

| Profile | Size | Replication | Use Case |
|---------|------|-------------|----------|
| Demo / Dev | 250 MB (Azure Basic C0 or equivalent) | None | Local Docker Compose, single-developer testing |
| Production | 1 GB+ (Azure Standard C1 or equivalent) | Yes (replica) | Multi-pod deployment with HA |

Key count estimate: ~50 keys per active user session (tokens, relay state, consent, JWKS, config). At 1000 concurrent users, expect ~50K keys using ~100-200 MB.

## Health Checks

### Redis Liveness Probe

The adapter's `/health` endpoint includes Redis connectivity status:

```bash
curl -s http://localhost:8000/health | jq '.cache_healthy'
# true  → Redis is connected and responding
# false → Redis is unreachable (adapter falls back to in-memory)
```

### Fail-Open Behavior

The adapter is **fail-open** with respect to Redis:
- If Redis goes down, each pod falls back to its own in-memory L1 cache.
- Requests continue to work, but cross-pod state is lost (users may need to re-authenticate).
- When Redis recovers, pods automatically reconnect and resume L2 writes.

This means a Redis outage does **not** cause request failures — it causes state isolation between pods until Redis is restored.

## Pod Scaling Guidance

- **Minimum replicas:** 2 (for availability)
- **HPA metric:** CPU or request rate (the adapter is CPU-bound during token exchange)
- **Session stickiness:** NOT required. All per-flow state lives in Redis.
- **Graceful shutdown:** The adapter cancels its pub/sub listener task on SIGTERM. Kubernetes default `terminationGracePeriodSeconds` (30s) is sufficient.

### What Lives in Redis

Every cache that previously required session stickiness is now backed by CacheService:

- OAuth relay sessions (CIMD authorize → callback flow)
- Gateway authorization codes (single-use, cross-pod atomicity enforced)
- STS consent transactions (multi-step consent interstitial)
- User token mappings (access_token → id_token for XAA pipeline)
- Resource tokens, JWKS, MCP sessions, config cache, tool catalogs

A request can be issued on pod A and the callback can land on pod B — both will see the same state.

## Known Limitations

### `aremove_by_user` uses broad prefix clear

`UserTokenStore.aremove_by_user()` calls `clear_prefix("user_token:")` in L2, which removes **all** user_token entries across all users — not just the target user's. This is acceptable because:
- L1 removal is user-scoped (only the target user's entries are removed from the local TTLCache)
- Other pods will re-populate their L1 from L2 on the next request. If L2 is cleared, they'll re-fetch from Okta.
- The operation is rare (only triggered by explicit user token removal)

For fine-grained per-user L2 invalidation, a future migration could add a per-user secondary index (e.g., `user_token_index:{user_sub}` → list of token hashes).

### No `/logout` endpoint yet

The `user_logout` pub/sub channel is wired (subscribers clear UserTokenStore + TokenCache for the user), but no `/logout` HTTP endpoint publishes to it. The gateway currently relies on token TTL expiration for session cleanup. A TODO is placed in `app.py` for future implementation.

### Gateway code atomicity is best-effort

`GatewayCodeManager.aexchange_code()` uses an L2 `exists` check to prevent cross-pod double-exchange, but this is not a true atomic operation (no Redis Lua script). The window for a race condition is extremely small (microseconds between `exists` and `delete`), and the L1 pop provides same-pod atomicity. A Redis `GETDEL` Lua script is deferred to a future optimization.
