# Split-Examples Pattern

The pattern for separating example MCP servers from core adapter infrastructure, as applied to AWS ECS. This document captures the decisions so the same split can be applied to Azure ACA and AKS later without re-debating.

## Principles

1. **Two sibling deployment projects, not submodules.** Core and examples are peer directories with independent state (Terraform state files, Bicep deployments, Helm releases — whatever the profile uses).

2. **One-way dependency.** Examples consumes core's outputs. Core knows nothing about examples.

3. **`core-outputs.json` contract.** Core's `deploy.sh --apply` writes `core-outputs.json` via `terraform output -json` (or the equivalent for the profile). Examples' `deploy.sh --apply` reads it and converts each key to a `TF_VAR_*` / `PARAM_*` flag.

4. **No `terraform_remote_state` data source.** Brittle across state backends; breaks in air-gapped deployments; couples the two projects at the Terraform level when the whole point is to decouple them.

5. **No Terraform workspaces.** Workspaces confuse operators and don't isolate blast radius — they just rename state keys.

6. **Examples gated by a bool variable per example.** `deploy_<name> = true` lets operators disable individual examples even within the examples project (e.g., "I want examples infra for the deploy-server but not HR").

7. **Build scripts reuse core's CodeBuild / CI project where possible.** The AWS ECS split reuses the core CodeBuild project with `--source-location-override` + `--buildspec-override`. This avoids provisioning a second CodeBuild project and its IAM role. Apply the same pattern for Azure Pipelines / GitHub Actions on other profiles.

## Shared contract (applies to any profile)

Core outputs, examples inputs:

| Output | Examples consumes as |
|---|---|
| `<region>` | `var.aws_region` / `var.azure_region` |
| `project_name` | `var.project_name` |
| `compute_platform_id` | cluster ARN / ACA environment ID / AKS cluster ID |
| `service_namespace` | Service Connect / Dapr component / K8s namespace |
| `workload_sg_or_nsg` | shared SG / NSG / NetworkPolicy selector |
| `workload_identity` | task role ARN / managed identity ID / workload identity client ID |
| `subnet_ids` | private subnet IDs |
| `network_id` | VPC ID / VNet ID |
| `common_tags` | tags / labels map |

Specific variable names change per cloud; structure is the same. Examples' `variables.tf` (or equivalent) explicitly marks which group each variable belongs to so operators reading the file understand what comes from where.

## Operator-facing scripts

Each profile's examples project has:

- `deploy.sh` with `--apply / --plan / --destroy / --build-only / --use-local-docker / --help`
- `smoke-test.sh` — polls the platform until the example service reports healthy (running count equals desired count, rollout/revision is complete)
- `build-codebuild.sh` / `build-ci.sh` / `build-pipelines.sh` — server-side image build (reuses core's CI project where possible)
- `build-images.sh` — local Docker build fallback
- `buildspec.yml` / `azure-pipelines.yml` / `.github/workflows/examples.yml` — CI-side build config
- `example.tfvars` / `example.bicepparam` / `values.example.yaml` — shared-input placeholders + examples-specific vars
- `shell-lib` symlink to the profile's shared shell-lib (reuses `info/ok/warn/die/prompt_yesno` helpers)

## Failure-isolation guarantees

The split is motivated by three operational requirements:

- **Core succeeds on its own.** A broken example image tag does not block adapter/admin UI from reaching healthy.
- **Examples can be torn down in isolation.** Destroy examples without touching core.
- **Examples are explicitly opt-in.** Operators demoing the adapter do not pay for HR backend compute unless they ask for it.

All three come from the state-file boundary. Terraform (and Bicep/Helm) can't have a partial-success apply across separate state files the way it can within one.

## Tear-down order

**Examples FIRST, then core.** Destroying core first orphans example resources:

- ECR repos / ACR repos — not referenced by core state, so `terraform destroy` on core skips them; they remain in AWS/Azure silently
- Log groups — same issue
- Security group rules attached to core's SG — AWS may block the SG destroy until the rule is gone, but the error is cryptic and operators often retry-through it via `--force-new-deployment` or manual cleanup

Core's `deploy.sh --destroy` warns if it detects leftover examples state (`.terraform/` + non-empty `terraform state list` in the examples directory). The warning is a prompt, not a hard block — an operator can still force-destroy core, but at that point they have been told.

## Why not combine them under one directory?

Considered (Option B: one directory, examples gated by a variable in core). Rejected because Terraform runs all resources in the same plan — an example's failure still poisons the core apply. The whole point of the split is blast-radius isolation, which requires separate state files and separate apply invocations.

Also considered (Option C: Terraform workspaces). Rejected because workspaces don't change the binary; they just key the state differently. A bad example resource still appears in the same plan output and fails the same apply.

## Azure ACA application

`deploy/azure-aca/` (core) → `deploy/azure-aca-examples/` (new sibling).

Core outputs (to be added to `deploy/azure-aca/bicep/main.bicep` outputs block):

- `resource_group_name` — examples creates sibling resources here
- `aca_environment_id` — examples deploys Container Apps here
- `acr_login_server` — examples pushes HR image here (or gets its own ACR repo in the same registry)
- `managed_identity_id` — examples Container Apps use this for ACR pull + Key Vault access
- `log_analytics_workspace_id` — examples streams logs here
- `vnet_subnet_id` (if private networking) — examples Container Apps attach here
- `private_dns_zone_id` (if private networking) — examples get reachable internal names
- `common_tags` — tags propagated from core

Examples provisions:

- HR backend Container App (ingress disabled — internal-only via Service Discovery)
- HR backend ACR repo + image build pipeline
- Dapr component bindings if needed
- Container App secrets referencing the same Key Vault (pulled via managed identity)

`deploy.sh` uses `az deployment group create` with `--parameters @core-outputs.json` after a small transform script (Bicep params are shaped slightly differently than Terraform vars — the deploy wrapper handles the conversion).

## Azure AKS application

`deploy/azure-aks/` (core) → `deploy/azure-aks-examples/` (new sibling).

Core outputs:

- `kube_config` (sensitive — marked `output "kube_config" { sensitive = true }`)
- `cluster_id`
- `acr_login_server`
- `namespace` — the shared K8s namespace created by core for MCP workloads
- `workload_identity_client_id` — for federated identity with Azure AD
- `keyvault_id` — for Container Storage Interface secrets driver
- `private_dns_zone_id` — for in-cluster DNS
- `common_tags` → K8s labels map

Examples provisions:

- HR backend `Deployment` + `Service` (via `kubernetes` or `helm` Terraform provider, or a standalone `helm install`)
- HR backend ACR repo + build pipeline
- `HTTPRoute` (if Gateway API) or `Ingress` rule for internal routing
- `ServiceAccount` bound to workload identity (if HR needs Key Vault or other Azure AD–gated resources)

**Kubeconfig handling:** The `kube_config` output from core is sensitive. Examples' `deploy.sh` should:

- Read it from `core-outputs.json` with `jq -r`
- Write it to a `0600`-permissioned temp file (or use `az aks get-credentials` with `--resource-group` + `--name` from core outputs to regenerate — preferred, no sensitive material on disk)
- Export `KUBECONFIG=<path>` for the duration of the apply
- Unset/remove on exit (trap)

## Open questions (deferred)

- **Should examples projects have their own `wizard.sh`?** Probably yes (simpler — 1-2 questions: "Deploy HR? [Y/n]" + image tag), but deferred until a second example is added.
- **Should there be a top-level `deploy/aws-ecs-full/` wrapper that applies core then examples in sequence for demo convenience?** Possibly, but risks re-introducing the coupling the split was meant to remove. Not recommended.
- **Should examples have their own CodeBuild/Pipelines project?** Currently reuses core's by overriding source/buildspec. Works for HR; if a future example needs meaningfully different IAM or runtime environment, revisit.

*— End of document —*
