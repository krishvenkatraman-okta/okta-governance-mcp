#!/usr/bin/env bash
# =============================================================================
# Okta MCP Adapter — Uninstall Script
# =============================================================================
# Stops all services, removes volumes, and optionally cleans up images and
# configuration files.
#
# Usage:
#   ./uninstall.sh                        # Stop services, remove volumes
#   ./uninstall.sh --remove-images        # Also remove Docker images
#   ./uninstall.sh --remove-config        # Also remove .env file
#   ./uninstall.sh --remove-images --remove-config   # Full cleanup
#   ./uninstall.sh -y                     # Skip confirmation prompt
# =============================================================================

set -euo pipefail

# ---------------------------------------------------------------------------
# Colors and formatting
# ---------------------------------------------------------------------------
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
CYAN='\033[0;36m'
BOLD='\033[1m'
DIM='\033[2m'
RESET='\033[0m'

info()    { echo -e "${BLUE}==>${RESET} ${BOLD}$*${RESET}"; }
success() { echo -e "${GREEN}==>${RESET} ${BOLD}$*${RESET}"; }
warn()    { echo -e "${YELLOW}==>${RESET} ${BOLD}$*${RESET}"; }
error()   { echo -e "${RED}==>${RESET} ${BOLD}$*${RESET}" >&2; }
step()    { echo -e "    ${CYAN}•${RESET} $*"; }

# ---------------------------------------------------------------------------
# Globals
# ---------------------------------------------------------------------------
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
COMPOSE_FILE="${SCRIPT_DIR}/docker-compose.bundle.yml"
ENV_FILE="${SCRIPT_DIR}/.env"

REMOVE_IMAGES=false
REMOVE_CONFIG=false
SKIP_CONFIRM=false

# ---------------------------------------------------------------------------
# Parse arguments
# ---------------------------------------------------------------------------
while [[ $# -gt 0 ]]; do
    case "$1" in
        --remove-images)  REMOVE_IMAGES=true; shift ;;
        --remove-config)  REMOVE_CONFIG=true; shift ;;
        -y|--yes)         SKIP_CONFIRM=true; shift ;;
        -h|--help)
            cat <<EOF
Usage: $0 [OPTIONS]

Stops the Okta MCP Adapter stack and removes data.

Options:
  --remove-images   Remove Docker images after stopping
  --remove-config   Remove .env configuration file
  -y, --yes         Skip confirmation prompt
  -h, --help        Show this help

By default, this script stops containers and removes Docker volumes
(database data, Redis cache, logs). Images and .env are preserved
unless explicitly requested.
EOF
            exit 0
            ;;
        *) error "Unknown option: $1"; exit 1 ;;
    esac
done

# ---------------------------------------------------------------------------
# Version
# ---------------------------------------------------------------------------
VERSION="unknown"
if [[ -f "${SCRIPT_DIR}/VERSION" ]]; then
    VERSION=$(cat "${SCRIPT_DIR}/VERSION" | tr -d '[:space:]')
fi

# =============================================================================
# BANNER
# =============================================================================

echo ""
echo -e "${BOLD}╔══════════════════════════════════════════════════════════╗${RESET}"
echo -e "${BOLD}║       Okta MCP Adapter — Uninstall                     ║${RESET}"
echo -e "${BOLD}╚══════════════════════════════════════════════════════════╝${RESET}"
echo ""

# =============================================================================
# SHOW WHAT WILL BE REMOVED
# =============================================================================

info "The following actions will be performed:"
echo ""
step "Stop all running containers"
step "Remove containers and networks"
step "${RED}Remove Docker volumes (database, Redis cache, logs)${RESET}"

if [[ "$REMOVE_IMAGES" == "true" ]]; then
    step "${RED}Remove Docker images${RESET}"
fi

if [[ "$REMOVE_CONFIG" == "true" ]]; then
    step "${RED}Remove .env configuration file${RESET}"
fi

echo ""
warn "This will permanently delete all data stored in Docker volumes."
echo -e "    ${DIM}Including: PostgreSQL database, Redis cache, adapter logs${RESET}"
echo ""

# =============================================================================
# CONFIRMATION
# =============================================================================

if [[ "$SKIP_CONFIRM" != "true" ]]; then
    read -rp "    Are you sure you want to continue? (y/N): " confirm
    case "$confirm" in
        [yY]|[yY][eE][sS])
            ;;
        *)
            echo ""
            info "Uninstall cancelled."
            exit 0
            ;;
    esac
    echo ""
fi

# =============================================================================
# PHASE 1: Stop containers and remove volumes
# =============================================================================

info "Stopping containers and removing volumes..."
echo ""

if [[ -f "${COMPOSE_FILE}" ]]; then
    # Stop with all profiles to catch observability containers too
    docker compose -f "${COMPOSE_FILE}" --profile observability down -v --remove-orphans 2>&1 | while read -r line; do
        step "${line}"
    done
    echo ""
    success "Containers stopped and volumes removed."
else
    warn "docker-compose.bundle.yml not found — attempting manual cleanup."
    echo ""

    # Try to stop known containers manually
    CONTAINER_NAMES=(
        "okta-agent-mcp-adapter"
        "okta-mcp-postgres"
        "okta-mcp-redis"
        "okta-mcp-admin-ui"
        "hr-mcp-server"
        "deploy-mcp-server"
        "okta-mcp-loki"
        "okta-mcp-promtail"
        "okta-mcp-grafana"
    )

    for name in "${CONTAINER_NAMES[@]}"; do
        if docker inspect "$name" &>/dev/null; then
            docker rm -f "$name" &>/dev/null && \
                step "${GREEN}✓${RESET} Removed ${name}" || \
                step "${YELLOW}⚠${RESET} Could not remove ${name}"
        fi
    done
    echo ""
fi

# Track what was removed for summary
REMOVED_ITEMS=("Containers" "Networks" "Volumes")

# =============================================================================
# PHASE 2: Remove Docker images (optional)
# =============================================================================

if [[ "$REMOVE_IMAGES" == "true" ]]; then
    echo ""
    info "Removing Docker images..."
    echo ""

    IMAGES_TO_REMOVE=(
        "okta-mcp-adapter:latest"
        "okta-mcp-admin-ui:latest"
        "okta-mcp-hr-server:latest"
        "okta-mcp-deploy-server:latest"
        "postgres:15-alpine"
        "redis:7-alpine"
    )

    for img in "${IMAGES_TO_REMOVE[@]}"; do
        if docker image inspect "$img" &>/dev/null; then
            docker rmi "$img" &>/dev/null && \
                step "${GREEN}✓${RESET} Removed ${img}" || \
                step "${YELLOW}⚠${RESET} Could not remove ${img} (may be in use)"
        else
            step "${DIM}Skipped ${img} (not found)${RESET}"
        fi
    done

    REMOVED_ITEMS+=("Docker images")
    echo ""
    success "Images removed."
fi

# =============================================================================
# PHASE 3: Remove configuration (optional)
# =============================================================================

if [[ "$REMOVE_CONFIG" == "true" ]]; then
    echo ""
    info "Removing configuration files..."
    echo ""

    if [[ -f "${ENV_FILE}" ]]; then
        rm -f "${ENV_FILE}"
        step "${GREEN}✓${RESET} Removed .env"
    else
        step "${DIM}Skipped .env (not found)${RESET}"
    fi

    # Also remove install log if present
    if [[ -f "${SCRIPT_DIR}/install.log" ]]; then
        rm -f "${SCRIPT_DIR}/install.log"
        step "${GREEN}✓${RESET} Removed install.log"
    fi

    REMOVED_ITEMS+=("Configuration files")
    echo ""
    success "Configuration removed."
fi

# =============================================================================
# SUMMARY
# =============================================================================

echo ""
echo -e "${BOLD}╔══════════════════════════════════════════════════════════╗${RESET}"
echo -e "${BOLD}║       Uninstall Complete                               ║${RESET}"
echo -e "${BOLD}╠══════════════════════════════════════════════════════════╣${RESET}"
echo -e "${BOLD}║${RESET}                                                          ${BOLD}║${RESET}"
echo -e "${BOLD}║${RESET}  ${BOLD}Removed:${RESET}                                               ${BOLD}║${RESET}"
for item in "${REMOVED_ITEMS[@]}"; do
echo -e "${BOLD}║${RESET}    ${GREEN}✓${RESET} ${item}"
done
echo -e "${BOLD}║${RESET}                                                          ${BOLD}║${RESET}"

if [[ "$REMOVE_CONFIG" != "true" && -f "${ENV_FILE}" ]]; then
echo -e "${BOLD}║${RESET}  ${BOLD}Preserved:${RESET}                                             ${BOLD}║${RESET}"
echo -e "${BOLD}║${RESET}    ${DIM}• .env (use --remove-config to delete)${RESET}"
echo -e "${BOLD}║${RESET}                                                          ${BOLD}║${RESET}"
fi

if [[ "$REMOVE_IMAGES" != "true" ]]; then
echo -e "${BOLD}║${RESET}  ${BOLD}Preserved:${RESET}                                             ${BOLD}║${RESET}"
echo -e "${BOLD}║${RESET}    ${DIM}• Docker images (use --remove-images to delete)${RESET}"
echo -e "${BOLD}║${RESET}                                                          ${BOLD}║${RESET}"
fi

echo -e "${BOLD}║${RESET}  To reinstall, run:  ${DIM}./install.sh${RESET}"
echo -e "${BOLD}║${RESET}                                                          ${BOLD}║${RESET}"
echo -e "${BOLD}╚══════════════════════════════════════════════════════════╝${RESET}"
echo ""
