#!/usr/bin/env bash
# =============================================================================
# Okta MCP Adapter — Status Dashboard
# =============================================================================
# Displays container status, health checks, smoke tests, and resource usage.
#
# Usage:
#   ./status.sh            # Interactive dashboard
#   ./status.sh --json     # Machine-readable JSON output
# =============================================================================

set -euo pipefail

# ---------------------------------------------------------------------------
# Colors and formatting
# ---------------------------------------------------------------------------
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
CYAN='\033[0;36m'
BOLD='\033[1m'
DIM='\033[2m'
RESET='\033[0m'

info()    { echo -e "${BLUE}==>${RESET} ${BOLD}$*${RESET}"; }
success() { echo -e "${GREEN}==>${RESET} ${BOLD}$*${RESET}"; }
warn()    { echo -e "${YELLOW}==>${RESET} ${BOLD}$*${RESET}"; }
error()   { echo -e "${RED}==>${RESET} ${BOLD}$*${RESET}" >&2; }
step()    { echo -e "    ${CYAN}•${RESET} $*"; }

# ---------------------------------------------------------------------------
# Globals
# ---------------------------------------------------------------------------
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
COMPOSE_FILE="${SCRIPT_DIR}/docker-compose.bundle.yml"
ENV_FILE="${SCRIPT_DIR}/.env"
JSON_MODE=false

# ---------------------------------------------------------------------------
# Parse arguments
# ---------------------------------------------------------------------------
while [[ $# -gt 0 ]]; do
    case "$1" in
        --json)  JSON_MODE=true; shift ;;
        -h|--help)
            echo "Usage: $0 [OPTIONS]"
            echo ""
            echo "Options:"
            echo "  --json    Output machine-readable JSON"
            echo "  -h        Show this help"
            exit 0
            ;;
        *) error "Unknown option: $1"; exit 1 ;;
    esac
done

# ---------------------------------------------------------------------------
# Load .env (admin API is Okta-OAuth-only in v0.15.x+; no local credentials)
# ---------------------------------------------------------------------------
OKTA_DOMAIN=""
GATEWAY_PORT="8000"
ADMIN_UI_PORT="3001"

if [[ -f "${ENV_FILE}" ]]; then
    OKTA_DOMAIN=$(grep '^OKTA_DOMAIN=' "${ENV_FILE}" 2>/dev/null | cut -d= -f2- || echo "")
    GATEWAY_PORT=$(grep '^GATEWAY_PORT=' "${ENV_FILE}" 2>/dev/null | cut -d= -f2- || echo "8000")
fi

GATEWAY_URL="http://localhost:${GATEWAY_PORT}"
ADMIN_UI_URL="http://localhost:${ADMIN_UI_PORT}"

# ---------------------------------------------------------------------------
# Container definitions
# ---------------------------------------------------------------------------
declare -a CONTAINER_NAMES=(
    "okta-agent-mcp-adapter"
    "okta-mcp-postgres"
    "okta-mcp-redis"
    "okta-mcp-admin-ui"
    "hr-mcp-server"
    "deploy-mcp-server"
)

declare -A CONTAINER_DISPLAY_NAMES=(
    [okta-agent-mcp-adapter]="Gateway"
    [okta-mcp-postgres]="PostgreSQL"
    [okta-mcp-redis]="Redis"
    [okta-mcp-admin-ui]="Admin UI"
    [hr-mcp-server]="HR MCP Server"
    [deploy-mcp-server]="Deploy MCP Server"
)

# ---------------------------------------------------------------------------
# Helper: get container field via docker inspect
# ---------------------------------------------------------------------------
container_field() {
    local container="$1"
    local format="$2"
    docker inspect --format="$format" "$container" 2>/dev/null || echo ""
}

# ---------------------------------------------------------------------------
# Helper: test HTTP endpoint
# ---------------------------------------------------------------------------
http_check() {
    local url="$1"
    local timeout="${2:-5}"
    local status
    status=$(curl -sf -o /dev/null -w '%{http_code}' --connect-timeout "$timeout" --max-time "$timeout" "$url" 2>/dev/null || echo "000")
    echo "$status"
}

# ---------------------------------------------------------------------------
# Helper: test HTTP POST
# ---------------------------------------------------------------------------
http_post() {
    local url="$1"
    local data="$2"
    local auth_header="${3:-}"
    local timeout="${4:-5}"
    local args=(-sf -o /dev/null -w '%{http_code}' --connect-timeout "$timeout" --max-time "$timeout")
    args+=(-H "Content-Type: application/json")
    if [[ -n "$auth_header" ]]; then
        args+=(-H "Authorization: Bearer ${auth_header}")
    fi
    args+=(-d "$data")
    curl "${args[@]}" "$url" 2>/dev/null || echo "000"
}

# ---------------------------------------------------------------------------
# Helper: get HTTP response body
# ---------------------------------------------------------------------------
http_get_body() {
    local url="$1"
    local auth_header="${2:-}"
    local timeout="${3:-5}"
    local args=(-sf --connect-timeout "$timeout" --max-time "$timeout")
    if [[ -n "$auth_header" ]]; then
        args+=(-H "Authorization: Bearer ${auth_header}")
    fi
    curl "${args[@]}" "$url" 2>/dev/null || echo ""
}

# =============================================================================
# JSON MODE
# =============================================================================

if [[ "$JSON_MODE" == "true" ]]; then

    # Build JSON output
    json_containers="["
    first=true
    for name in "${CONTAINER_NAMES[@]}"; do
        if docker inspect "$name" &>/dev/null; then
            status=$(container_field "$name" '{{.State.Status}}')
            health=$(container_field "$name" '{{if .State.Health}}{{.State.Health.Status}}{{else}}N/A{{end}}')
            image=$(container_field "$name" '{{.Config.Image}}')
            # Get published ports
            ports=$(docker port "$name" 2>/dev/null | awk -F'-> ' '{print $2}' | tr '\n' ',' | sed 's/,$//')

            [[ "$first" != "true" ]] && json_containers+=","
            first=false
            json_containers+="{\"name\":\"${name}\",\"image\":\"${image}\",\"status\":\"${status}\",\"health\":\"${health}\",\"ports\":\"${ports}\"}"
        fi
    done
    json_containers+="]"

    # Health checks
    gw_status=$(http_check "${GATEWAY_URL}/.well-known/oauth-protected-resource")
    ui_status=$(http_check "${ADMIN_UI_URL}/")
    db_ready="false"
    if docker exec okta-mcp-postgres pg_isready -U gateway_user -d gateway_db &>/dev/null; then
        db_ready="true"
    fi
    redis_ready="false"
    redis_pass=$(grep '^REDIS_PASSWORD=' "${ENV_FILE}" 2>/dev/null | cut -d= -f2- || echo "")
    if docker exec okta-mcp-redis redis-cli -a "${redis_pass}" ping &>/dev/null 2>&1; then
        redis_ready="true"
    fi

    # Admin API reachability: probe with OKTA_ADMIN_TOKEN if present, otherwise
    # confirm the endpoint rejects unauthenticated requests (401).
    admin_login_status="000"
    admin_token="${OKTA_ADMIN_TOKEN:-}"
    agents_count=0
    backends_count=0

    if [[ -n "$admin_token" ]]; then
        probe_code=$(curl -s -o /dev/null -w '%{http_code}' --connect-timeout 5 --max-time 5 \
            -H "Authorization: Bearer ${admin_token}" \
            "${GATEWAY_URL}/api/admin/agents" 2>/dev/null || echo "000")
        admin_login_status="$probe_code"
        if [[ "$probe_code" == "200" ]]; then
            agents_body=$(http_get_body "${GATEWAY_URL}/api/admin/agents" "$admin_token")
            if [[ -n "$agents_body" ]]; then
                agents_count=$(echo "$agents_body" | python3 -c "import sys,json; print(len(json.load(sys.stdin)))" 2>/dev/null || echo "0")
            fi
        fi
    else
        # Verify 401 without a token (auth middleware wired correctly)
        probe_code=$(curl -s -o /dev/null -w '%{http_code}' --connect-timeout 5 --max-time 5 \
            "${GATEWAY_URL}/api/admin/agents" 2>/dev/null || echo "000")
        admin_login_status="$probe_code"
    fi

    # Resource usage
    json_resources="["
    first=true
    while IFS= read -r line; do
        if [[ -z "$line" ]]; then continue; fi
        # Parse: CONTAINER  CPU%  MEM USAGE / LIMIT  MEM%
        c_name=$(echo "$line" | awk '{print $1}')
        c_cpu=$(echo "$line" | awk '{print $2}')
        c_mem=$(echo "$line" | awk '{print $3}')
        c_memlimit=$(echo "$line" | awk '{print $5}')
        c_mempct=$(echo "$line" | awk '{print $6}')

        [[ "$first" != "true" ]] && json_resources+=","
        first=false
        json_resources+="{\"name\":\"${c_name}\",\"cpu\":\"${c_cpu}\",\"memory\":\"${c_mem}\",\"memory_limit\":\"${c_memlimit}\",\"memory_percent\":\"${c_mempct}\"}"
    done < <(docker stats --no-stream --format "{{.Name}} {{.CPUPerc}} {{.MemUsage}} {{.MemPerc}}" 2>/dev/null | grep -E "$(IFS='|'; echo "${CONTAINER_NAMES[*]}")" || true)
    json_resources+="]"

    cat <<JSONEOF
{
  "timestamp": "$(date -u '+%Y-%m-%dT%H:%M:%SZ')",
  "containers": ${json_containers},
  "health": {
    "gateway": {"status_code": ${gw_status}, "healthy": $([ "$gw_status" == "200" ] && echo true || echo false)},
    "admin_ui": {"status_code": ${ui_status}, "healthy": $([ "$ui_status" == "200" ] && echo true || echo false)},
    "database": {"healthy": ${db_ready}},
    "redis": {"healthy": ${redis_ready}}
  },
  "smoke_tests": {
    "admin_login": $([ "$admin_login_status" == "200" ] && echo true || echo false),
    "agents_count": ${agents_count},
    "backends_count": ${backends_count}
  },
  "resources": ${json_resources}
}
JSONEOF

    exit 0
fi

# =============================================================================
# INTERACTIVE MODE
# =============================================================================

VERSION="unknown"
if [[ -f "${SCRIPT_DIR}/VERSION" ]]; then
    VERSION=$(cat "${SCRIPT_DIR}/VERSION" | tr -d '[:space:]')
fi

echo ""
echo -e "${BOLD}╔══════════════════════════════════════════════════════════╗${RESET}"
echo -e "${BOLD}║       Okta MCP Adapter — Status Dashboard              ║${RESET}"
echo -e "${BOLD}║       Version: ${CYAN}${VERSION}${RESET}${BOLD}                                       ║${RESET}"
echo -e "${BOLD}╚══════════════════════════════════════════════════════════╝${RESET}"
echo ""

# -------------------------------------------------------------------------
# Section 1: Container Status
# -------------------------------------------------------------------------

info "Container Status"
echo ""
printf "    ${BOLD}%-24s %-28s %-10s %-10s %-12s${RESET}\n" "NAME" "IMAGE" "STATUS" "HEALTH" "PORTS"
printf "    ${DIM}%-24s %-28s %-10s %-10s %-12s${RESET}\n" "------------------------" "----------------------------" "----------" "----------" "------------"

RUNNING_COUNT=0
TOTAL_COUNT=0

for name in "${CONTAINER_NAMES[@]}"; do
    TOTAL_COUNT=$((TOTAL_COUNT + 1))

    if ! docker inspect "$name" &>/dev/null; then
        printf "    %-24s %-28s ${DIM}%-10s %-10s %-12s${RESET}\n" \
            "$name" "-" "not found" "-" "-"
        continue
    fi

    status=$(container_field "$name" '{{.State.Status}}')
    health=$(container_field "$name" '{{if .State.Health}}{{.State.Health.Status}}{{else}}N/A{{end}}')
    image=$(container_field "$name" '{{.Config.Image}}')
    ports=$(docker port "$name" 2>/dev/null | awk -F'-> ' '{print $2}' | awk -F: '{print $NF}' | sort -u | tr '\n' ',' | sed 's/,$//')

    # Color-code status
    case "$status" in
        running)  status_color="${GREEN}" ;;
        exited)   status_color="${RED}" ;;
        *)        status_color="${YELLOW}" ;;
    esac

    # Color-code health
    case "$health" in
        healthy)    health_color="${GREEN}" ;;
        unhealthy)  health_color="${RED}" ;;
        starting)   health_color="${YELLOW}" ;;
        *)          health_color="${DIM}" ;;
    esac

    printf "    %-24s %-28s ${status_color}%-10s${RESET} ${health_color}%-10s${RESET} %-12s\n" \
        "$name" "$image" "$status" "$health" "$ports"

    if [[ "$status" == "running" ]]; then
        RUNNING_COUNT=$((RUNNING_COUNT + 1))
    fi
done

echo ""

if (( RUNNING_COUNT == 0 )); then
    warn "No containers running. Start with: ./install.sh --force"
    echo ""
    exit 0
fi

# -------------------------------------------------------------------------
# Section 2: Service Health Checks
# -------------------------------------------------------------------------

info "Service Health Checks"
echo ""

HEALTH_PASS=0
HEALTH_TOTAL=0

# Gateway
HEALTH_TOTAL=$((HEALTH_TOTAL + 1))
gw_status=$(http_check "${GATEWAY_URL}/.well-known/oauth-protected-resource")
if [[ "$gw_status" == "200" ]]; then
    step "${GREEN}✓${RESET} Gateway           ${DIM}GET /.well-known/oauth-protected-resource → ${gw_status}${RESET}"
    HEALTH_PASS=$((HEALTH_PASS + 1))
else
    step "${RED}✗${RESET} Gateway           ${DIM}GET /.well-known/oauth-protected-resource → ${gw_status}${RESET}"
fi

# Admin UI
HEALTH_TOTAL=$((HEALTH_TOTAL + 1))
ui_status=$(http_check "${ADMIN_UI_URL}/")
if [[ "$ui_status" == "200" ]]; then
    step "${GREEN}✓${RESET} Admin UI          ${DIM}GET ${ADMIN_UI_URL}/ → ${ui_status}${RESET}"
    HEALTH_PASS=$((HEALTH_PASS + 1))
else
    step "${RED}✗${RESET} Admin UI          ${DIM}GET ${ADMIN_UI_URL}/ → ${ui_status}${RESET}"
fi

# Database
HEALTH_TOTAL=$((HEALTH_TOTAL + 1))
if docker exec okta-mcp-postgres pg_isready -U gateway_user -d gateway_db &>/dev/null; then
    step "${GREEN}✓${RESET} PostgreSQL        ${DIM}pg_isready → accepting connections${RESET}"
    HEALTH_PASS=$((HEALTH_PASS + 1))
else
    step "${RED}✗${RESET} PostgreSQL        ${DIM}pg_isready → not accepting connections${RESET}"
fi

# Redis
HEALTH_TOTAL=$((HEALTH_TOTAL + 1))
redis_pass=$(grep '^REDIS_PASSWORD=' "${ENV_FILE}" 2>/dev/null | cut -d= -f2- || echo "")
if docker exec okta-mcp-redis redis-cli -a "${redis_pass}" ping 2>/dev/null | grep -q PONG; then
    step "${GREEN}✓${RESET} Redis             ${DIM}redis-cli ping → PONG${RESET}"
    HEALTH_PASS=$((HEALTH_PASS + 1))
else
    step "${RED}✗${RESET} Redis             ${DIM}redis-cli ping → no response${RESET}"
fi

echo ""

if (( HEALTH_PASS == HEALTH_TOTAL )); then
    success "All ${HEALTH_TOTAL} health checks passed."
else
    warn "${HEALTH_PASS}/${HEALTH_TOTAL} health checks passed."
fi
echo ""

# -------------------------------------------------------------------------
# Section 3: Admin API Smoke Tests
# -------------------------------------------------------------------------

info "Admin API Smoke Tests"
echo ""

SMOKE_PASS=0
SMOKE_TOTAL=0
ADMIN_TOKEN="${OKTA_ADMIN_TOKEN:-}"

# Always verify the admin API rejects unauthenticated requests.
SMOKE_TOTAL=$((SMOKE_TOTAL + 1))
probe_code=$(curl -s -o /dev/null -w '%{http_code}' --connect-timeout 5 --max-time 5 \
    "${GATEWAY_URL}/api/admin/agents" 2>/dev/null || echo "000")
if [[ "$probe_code" == "401" ]]; then
    step "${GREEN}✓${RESET} Admin auth wired  ${DIM}GET /api/admin/agents (no bearer) → 401${RESET}"
    SMOKE_PASS=$((SMOKE_PASS + 1))
else
    step "${RED}✗${RESET} Admin auth        ${DIM}expected 401, got ${probe_code}${RESET}"
fi

# If the operator provided an Okta access token, exercise agent/backend lists.
if [[ -n "$ADMIN_TOKEN" ]]; then
    SMOKE_TOTAL=$((SMOKE_TOTAL + 1))
    agents_body=$(http_get_body "${GATEWAY_URL}/api/admin/agents" "$ADMIN_TOKEN")
    if [[ -n "$agents_body" ]]; then
        agents_count=$(echo "$agents_body" | python3 -c "import sys,json; data=json.load(sys.stdin); print(len(data))" 2>/dev/null || echo "0")
        agent_ids=$(echo "$agents_body" | python3 -c "import sys,json; data=json.load(sys.stdin); print(', '.join(a.get('agent_id','?') for a in data[:5]))" 2>/dev/null || echo "")
        step "${GREEN}✓${RESET} List agents       ${DIM}GET /api/admin/agents → ${agents_count} agent(s): ${agent_ids}${RESET}"
        SMOKE_PASS=$((SMOKE_PASS + 1))
    else
        step "${RED}✗${RESET} List agents       ${DIM}GET /api/admin/agents → empty or rejected (check OKTA_ADMIN_TOKEN)${RESET}"
    fi

    SMOKE_TOTAL=$((SMOKE_TOTAL + 1))
    resources_body=$(http_get_body "${GATEWAY_URL}/api/admin/resources" "$ADMIN_TOKEN")
    if [[ -n "$resources_body" ]]; then
        step "${GREEN}✓${RESET} List resources    ${DIM}GET /api/admin/resources → ok${RESET}"
        SMOKE_PASS=$((SMOKE_PASS + 1))
    else
        step "${RED}✗${RESET} List resources    ${DIM}GET /api/admin/resources → empty or rejected${RESET}"
    fi
else
    step "${DIM}(set OKTA_ADMIN_TOKEN to exercise authenticated admin endpoints)${RESET}"
fi

echo ""

if (( SMOKE_TOTAL > 0 )); then
    if (( SMOKE_PASS == SMOKE_TOTAL )); then
        success "All ${SMOKE_TOTAL} smoke tests passed."
    else
        warn "${SMOKE_PASS}/${SMOKE_TOTAL} smoke tests passed."
    fi
    echo ""
fi

# -------------------------------------------------------------------------
# Section 4: Resource Usage
# -------------------------------------------------------------------------

info "Resource Usage"
echo ""
printf "    ${BOLD}%-26s %8s %22s %8s${RESET}\n" "CONTAINER" "CPU %" "MEM USAGE / LIMIT" "MEM %"
printf "    ${DIM}%-26s %8s %22s %8s${RESET}\n" "--------------------------" "--------" "----------------------" "--------"

docker stats --no-stream --format "{{.Name}}\t{{.CPUPerc}}\t{{.MemUsage}}\t{{.MemPerc}}" 2>/dev/null | \
    grep -E "$(IFS='|'; echo "${CONTAINER_NAMES[*]}")" | \
    sort | \
    while IFS=$'\t' read -r c_name c_cpu c_mem c_mempct; do
        printf "    %-26s %8s %22s %8s\n" "$c_name" "$c_cpu" "$c_mem" "$c_mempct"
    done || step "${DIM}No container stats available${RESET}"

echo ""

# -------------------------------------------------------------------------
# Section 5: Connection Info
# -------------------------------------------------------------------------

echo -e "${BOLD}╔══════════════════════════════════════════════════════════╗${RESET}"
echo -e "${BOLD}║              Connection Information                    ║${RESET}"
echo -e "${BOLD}╠══════════════════════════════════════════════════════════╣${RESET}"
echo -e "${BOLD}║${RESET}                                                          ${BOLD}║${RESET}"
echo -e "${BOLD}║${RESET}  ${BOLD}Services:${RESET}                                              ${BOLD}║${RESET}"
echo -e "${BOLD}║${RESET}    Gateway:     ${GREEN}${GATEWAY_URL}${RESET}"
echo -e "${BOLD}║${RESET}    Admin UI:    ${GREEN}${ADMIN_UI_URL}${RESET}"
echo -e "${BOLD}║${RESET}                                                          ${BOLD}║${RESET}"
echo -e "${BOLD}║${RESET}  ${BOLD}Admin Auth:${RESET}       Okta OAuth (sign in to Admin UI)       ${BOLD}║${RESET}"
echo -e "${BOLD}║${RESET}                                                          ${BOLD}║${RESET}"
if [[ -n "$OKTA_DOMAIN" ]]; then
echo -e "${BOLD}║${RESET}  ${BOLD}Okta Domain:${RESET}  ${OKTA_DOMAIN}"
echo -e "${BOLD}║${RESET}                                                          ${BOLD}║${RESET}"
fi
echo -e "${BOLD}║${RESET}  ${BOLD}Useful Commands:${RESET}                                       ${BOLD}║${RESET}"
echo -e "${BOLD}║${RESET}    Logs:        ${DIM}docker compose -f docker-compose.bundle.yml logs -f${RESET}"
echo -e "${BOLD}║${RESET}    Restart:     ${DIM}docker compose -f docker-compose.bundle.yml restart${RESET}"
echo -e "${BOLD}║${RESET}    Stop:        ${DIM}docker compose -f docker-compose.bundle.yml down${RESET}"
echo -e "${BOLD}║${RESET}    Uninstall:   ${DIM}./uninstall.sh${RESET}"
echo -e "${BOLD}║${RESET}                                                          ${BOLD}║${RESET}"
echo -e "${BOLD}╚══════════════════════════════════════════════════════════╝${RESET}"
echo ""
