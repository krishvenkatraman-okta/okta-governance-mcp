#!/usr/bin/env bash
# =============================================================================
# Okta MCP Adapter — Interactive Configuration Wizard
# =============================================================================
# Guides the customer through configuration with validation and connectivity
# checks. Generates secrets, writes .env, and optionally starts the stack.
#
# Usage:
#   ./configure.sh          # Interactive wizard
#   ./configure.sh --help   # Show help
#
# Re-runnable: preserves existing secrets unless explicitly reconfigured.
# =============================================================================

set -euo pipefail

# ---------------------------------------------------------------------------
# Colors and formatting
# ---------------------------------------------------------------------------
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
CYAN='\033[0;36m'
BOLD='\033[1m'
DIM='\033[2m'
RESET='\033[0m'

info()    { echo -e "${BLUE}==>${RESET} ${BOLD}$*${RESET}"; }
success() { echo -e "${GREEN}==>${RESET} ${BOLD}$*${RESET}"; }
warn()    { echo -e "${YELLOW}==>${RESET} ${BOLD}$*${RESET}"; }
error()   { echo -e "${RED}==>${RESET} ${BOLD}$*${RESET}" >&2; }
step()    { echo -e "    ${CYAN}•${RESET} $*"; }

# ---------------------------------------------------------------------------
# Globals
# ---------------------------------------------------------------------------
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ENV_FILE="${SCRIPT_DIR}/.env"
ENV_TEMPLATE="${SCRIPT_DIR}/.env.template"
VERSION_FILE="${SCRIPT_DIR}/VERSION"

VERSION="dev"
if [[ -f "${VERSION_FILE}" ]]; then
    VERSION=$(cat "${VERSION_FILE}" | tr -d '[:space:]')
fi

# Configuration values (populated during wizard)
CFG_OKTA_DOMAIN=""
CFG_OKTA_ISSUER=""
CFG_CIMD_ENABLED="true"
CFG_RELAY_CLIENT_ID=""
CFG_RELAY_CLIENT_SECRET=""

# Existing .env values (loaded if present)
declare -A EXISTING_VALUES

# ---------------------------------------------------------------------------
# Parse arguments
# ---------------------------------------------------------------------------
while [[ $# -gt 0 ]]; do
    case "$1" in
        -h|--help)
            cat <<EOF
Usage: $0 [OPTIONS]

Interactive configuration wizard for the Okta MCP Adapter bundle.

Options:
  -h, --help    Show this help

The wizard will guide you through:
  1. Okta domain and authorization server setup
  2. Admin password configuration
  3. CIMD / Confidential Relay setup (optional)

Configuration is saved to .env. Existing secrets are preserved
unless you choose to reconfigure from scratch.
EOF
            exit 0
            ;;
        *)
            error "Unknown option: $1"
            echo "Run '$0 --help' for usage."
            exit 1
            ;;
    esac
done

# ---------------------------------------------------------------------------
# Helper: read a value from existing .env
# ---------------------------------------------------------------------------
load_existing_env() {
    if [[ -f "${ENV_FILE}" ]]; then
        while IFS='=' read -r key value; do
            # Skip comments and empty lines
            [[ -z "$key" || "$key" =~ ^# ]] && continue
            # Trim whitespace
            key=$(echo "$key" | xargs)
            value=$(echo "$value" | sed 's/^["'\''"]//;s/["'\''"]$//')
            EXISTING_VALUES["$key"]="$value"
        done < "${ENV_FILE}"
    fi
}

# ---------------------------------------------------------------------------
# Helper: get existing value or default
# ---------------------------------------------------------------------------
get_existing() {
    local key="$1"
    local default="${2:-}"
    echo "${EXISTING_VALUES[$key]:-$default}"
}

# ---------------------------------------------------------------------------
# Helper: prompt with default value
# ---------------------------------------------------------------------------
prompt_value() {
    local prompt_text="$1"
    local default_value="${2:-}"
    local result=""

    if [[ -n "$default_value" ]]; then
        read -rp "    ${prompt_text} [${default_value}]: " result
        result="${result:-$default_value}"
    else
        read -rp "    ${prompt_text}: " result
    fi

    echo "$result"
}

# ---------------------------------------------------------------------------
# Helper: prompt yes/no
# ---------------------------------------------------------------------------
prompt_yn() {
    local prompt_text="$1"
    local default="${2:-n}"  # y or n
    local result=""

    if [[ "$default" == "y" ]]; then
        read -rp "    ${prompt_text} [Y/n]: " result
        result="${result:-y}"
    else
        read -rp "    ${prompt_text} [y/N]: " result
        result="${result:-n}"
    fi

    case "$result" in
        [yY]|[yY][eE][sS]) echo "y" ;;
        *) echo "n" ;;
    esac
}

# ---------------------------------------------------------------------------
# Helper: mask a secret for display
# ---------------------------------------------------------------------------
mask_secret() {
    local value="$1"
    if [[ -z "$value" ]]; then
        echo "(not set)"
    elif [[ ${#value} -le 4 ]]; then
        echo "****"
    else
        echo "${value:0:4}****"
    fi
}

# ---------------------------------------------------------------------------
# Helper: test URL reachability
# ---------------------------------------------------------------------------
test_url() {
    local url="$1"
    local timeout="${2:-5}"
    if curl -sf --connect-timeout "$timeout" --max-time "$timeout" "$url" >/dev/null 2>&1; then
        return 0
    else
        return 1
    fi
}

# =============================================================================
# WELCOME BANNER
# =============================================================================

echo ""
echo -e "${BOLD}╔══════════════════════════════════════════════════════════╗${RESET}"
echo -e "${BOLD}║     Okta MCP Adapter — Configuration Wizard            ║${RESET}"
echo -e "${BOLD}║     Version: ${CYAN}${VERSION}${RESET}${BOLD}                                        ║${RESET}"
echo -e "${BOLD}╚══════════════════════════════════════════════════════════╝${RESET}"
echo ""

# =============================================================================
# HANDLE EXISTING .env
# =============================================================================

CONFIG_MODE="fresh"   # fresh | keep | update

if [[ -f "${ENV_FILE}" ]]; then
    load_existing_env

    warn "Existing .env configuration found."
    echo ""
    echo -e "    What would you like to do?"
    echo ""
    echo -e "    ${BOLD}1)${RESET} Keep current config ${DIM}(no changes)${RESET}"
    echo -e "    ${BOLD}2)${RESET} Reconfigure from scratch ${DIM}(regenerates secrets)${RESET}"
    echo -e "    ${BOLD}3)${RESET} Update specific values ${DIM}(preserves existing secrets)${RESET}"
    echo ""

    while true; do
        read -rp "    Choose [1/2/3]: " choice
        case "$choice" in
            1)
                CONFIG_MODE="keep"
                break
                ;;
            2)
                CONFIG_MODE="fresh"
                break
                ;;
            3)
                CONFIG_MODE="update"
                break
                ;;
            *)
                echo -e "    ${RED}Invalid choice.${RESET} Enter 1, 2, or 3."
                ;;
        esac
    done

    echo ""

    if [[ "$CONFIG_MODE" == "keep" ]]; then
        success "Keeping existing configuration."
        echo ""

        # Ask if they want to start
        answer=$(prompt_yn "Start the adapter now?" "y")
        if [[ "$answer" == "y" ]]; then
            echo ""
            info "Starting Okta MCP Adapter..."
            exec "${SCRIPT_DIR}/install.sh" --force --skip-start=false 2>/dev/null || \
                docker compose -f "${SCRIPT_DIR}/docker-compose.bundle.yml" up -d
        fi
        exit 0
    fi

    # For "update" mode, pre-load existing values as defaults
    if [[ "$CONFIG_MODE" == "update" ]]; then
        CFG_OKTA_DOMAIN=$(get_existing "OKTA_DOMAIN")
        CFG_OKTA_ISSUER=$(get_existing "OKTA_ISSUER")
        CFG_CIMD_ENABLED=$(get_existing "CIMD_ENABLED" "true")
    fi
fi

# =============================================================================
# STEP 1: Okta Domain
# =============================================================================

echo -e "${BOLD}  Step 1 of 3: Okta Domain${RESET}"
echo -e "  ${DIM}Your Okta org domain is used for JWT validation and OAuth flows.${RESET}"
echo ""

while true; do
    CFG_OKTA_DOMAIN=$(prompt_value "Enter your Okta domain (e.g., dev-12345.okta.com)" "$CFG_OKTA_DOMAIN")

    # Validate domain pattern
    if [[ "$CFG_OKTA_DOMAIN" =~ ^[a-zA-Z0-9._-]+\.(okta\.com|oktapreview\.com|okta-emea\.com|trexcloud\.com)$ ]]; then
        step "${GREEN}✓${RESET} Domain format valid"
    else
        echo -e "    ${RED}✗${RESET} Must match *.okta.com or *.oktapreview.com"
        echo -e "      ${DIM}Example: dev-12345.okta.com${RESET}"
        CFG_OKTA_DOMAIN=""
        continue
    fi

    # Test connectivity
    echo -ne "    ${DIM}Testing connectivity...${RESET}"
    OIDC_URL="https://${CFG_OKTA_DOMAIN}/.well-known/openid-configuration"
    if test_url "$OIDC_URL"; then
        echo -e "\r    ${GREEN}✓${RESET} Okta domain reachable (${DIM}${OIDC_URL}${RESET})"
    else
        echo -e "\r    ${YELLOW}⚠${RESET} Could not reach ${DIM}${OIDC_URL}${RESET}"
        echo -e "      ${DIM}This may be expected if you're behind a firewall.${RESET}"
    fi

    break
done

echo ""

# Derive issuer URL from domain (Org authorization server)
CFG_OKTA_ISSUER="https://${CFG_OKTA_DOMAIN}"

# =============================================================================
# STEP 2: Admin API authentication (Okta OAuth only)
# =============================================================================

echo -e "${BOLD}  Step 2 of 3: Admin Authentication${RESET}"
echo -e "  ${DIM}Admin API uses Okta OAuth access tokens only (v0.15.x+).${RESET}"
echo -e "  ${DIM}Admin UI sign-in will be configured via ADMIN_UI_OKTA_* vars.${RESET}"
echo ""
step "${GREEN}✓${RESET} No local password required"
echo ""

# =============================================================================
# STEP 3: CIMD / Confidential Relay (optional)
# =============================================================================

echo -e "${BOLD}  Step 3 of 3: Confidential Client Registration (CIMD)${RESET}"
echo -e "  ${DIM}Enables MCP clients to register dynamically using Client Identity${RESET}"
echo -e "  ${DIM}Metadata Documents. Requires a relay Okta OIDC application.${RESET}"
echo ""

CONFIGURE_CIMD="n"
if [[ "$CONFIG_MODE" == "update" && -n "$CFG_RELAY_CLIENT_ID" ]]; then
    echo -e "    Current relay client: ${DIM}$(mask_secret "$CFG_RELAY_CLIENT_ID")${RESET}"
    answer=$(prompt_yn "Keep current CIMD configuration?" "y")
    if [[ "$answer" == "y" ]]; then
        step "${GREEN}✓${RESET} Keeping existing CIMD configuration"
        CONFIGURE_CIMD="skip"
    else
        CONFIGURE_CIMD=$(prompt_yn "Enable Confidential Client Registration?" "y")
    fi
else
    CONFIGURE_CIMD=$(prompt_yn "Enable Confidential Client Registration?" "n")
fi

if [[ "$CONFIGURE_CIMD" == "y" ]]; then
    echo ""
    echo "    CIMD relay credentials are now configured per-agent in the database."
    echo "    Use the Admin API to set client_id and client_secret on each agent."
    CFG_CIMD_ENABLED="true"
    step "${GREEN}✓${RESET} CIMD enabled (per-agent credentials via Admin API)"
elif [[ "$CONFIGURE_CIMD" == "n" ]]; then
    CFG_CIMD_ENABLED="false"
    step "${DIM}CIMD disabled${RESET}"
fi

echo ""

# =============================================================================
# GENERATE SECRETS
# =============================================================================

info "Generating secrets..."
echo ""

# For "update" mode, preserve existing secrets; for "fresh" mode, regenerate all
if [[ "$CONFIG_MODE" == "update" ]]; then
    ENCRYPTION_KEY=$(get_existing "ENCRYPTION_KEY")
    POSTGRES_PASSWORD=$(get_existing "POSTGRES_PASSWORD")
    REDIS_PASSWORD=$(get_existing "REDIS_PASSWORD")
    HR_PSK_SECRET=$(get_existing "HR_PSK_SECRET")
    ADMIN_UI_NEXTAUTH_SECRET=$(get_existing "ADMIN_UI_NEXTAUTH_SECRET")

    # Generate any missing secrets
    if [[ -z "$ENCRYPTION_KEY" ]]; then
        ENCRYPTION_KEY=$(openssl rand -base64 32)
        step "${GREEN}✓${RESET} ENCRYPTION_KEY generated (was missing)"
    else
        step "${DIM}✓${RESET} ENCRYPTION_KEY preserved"
    fi

    if [[ -z "$POSTGRES_PASSWORD" ]]; then
        POSTGRES_PASSWORD=$(openssl rand -base64 24 | tr -dc 'A-Za-z0-9' | head -c 20)
        step "${GREEN}✓${RESET} POSTGRES_PASSWORD generated (was missing)"
    else
        step "${DIM}✓${RESET} POSTGRES_PASSWORD preserved"
    fi

    if [[ -z "$REDIS_PASSWORD" ]]; then
        REDIS_PASSWORD=$(openssl rand -base64 16 | tr -dc 'A-Za-z0-9' | head -c 16)
        step "${GREEN}✓${RESET} REDIS_PASSWORD generated (was missing)"
    else
        step "${DIM}✓${RESET} REDIS_PASSWORD preserved"
    fi

    if [[ -z "$HR_PSK_SECRET" ]]; then
        HR_PSK_SECRET=$(openssl rand -base64 32)
        step "${GREEN}✓${RESET} HR_PSK_SECRET generated (was missing)"
    else
        step "${DIM}✓${RESET} HR_PSK_SECRET preserved"
    fi

    if [[ -z "$ADMIN_UI_NEXTAUTH_SECRET" ]]; then
        ADMIN_UI_NEXTAUTH_SECRET=$(openssl rand -base64 32)
        step "${GREEN}✓${RESET} ADMIN_UI_NEXTAUTH_SECRET generated (was missing)"
    else
        step "${DIM}✓${RESET} ADMIN_UI_NEXTAUTH_SECRET preserved"
    fi
else
    # Fresh mode: generate all secrets
    ENCRYPTION_KEY=$(openssl rand -base64 32)
    step "${GREEN}✓${RESET} ENCRYPTION_KEY generated"

    POSTGRES_PASSWORD=$(openssl rand -base64 24 | tr -dc 'A-Za-z0-9' | head -c 20)
    step "${GREEN}✓${RESET} POSTGRES_PASSWORD generated"

    REDIS_PASSWORD=$(openssl rand -base64 16 | tr -dc 'A-Za-z0-9' | head -c 16)
    step "${GREEN}✓${RESET} REDIS_PASSWORD generated"

    HR_PSK_SECRET=$(openssl rand -base64 32)
    step "${GREEN}✓${RESET} HR_PSK_SECRET generated"

    ADMIN_UI_NEXTAUTH_SECRET=$(openssl rand -base64 32)
    step "${GREEN}✓${RESET} ADMIN_UI_NEXTAUTH_SECRET generated"
fi

# Preserve other existing values in update mode
if [[ "$CONFIG_MODE" == "update" ]]; then
    GATEWAY_BASE_URL=$(get_existing "GATEWAY_BASE_URL" "http://localhost:8000")
    GATEWAY_PORT=$(get_existing "GATEWAY_PORT" "8000")
    LOG_LEVEL=$(get_existing "LOG_LEVEL" "INFO")
    POSTGRES_DB=$(get_existing "POSTGRES_DB" "gateway_db")
    POSTGRES_USER=$(get_existing "POSTGRES_USER" "gateway_user")
    ADMIN_UI_NEXTAUTH_URL=$(get_existing "ADMIN_UI_NEXTAUTH_URL" "http://localhost:3001")
    ADMIN_UI_OKTA_DOMAIN=$(get_existing "ADMIN_UI_OKTA_DOMAIN")
    ADMIN_UI_OKTA_CLIENT_ID=$(get_existing "ADMIN_UI_OKTA_CLIENT_ID")
    ADMIN_UI_OKTA_CLIENT_SECRET=$(get_existing "ADMIN_UI_OKTA_CLIENT_SECRET")
    GF_SECURITY_ADMIN_PASSWORD=$(get_existing "GF_SECURITY_ADMIN_PASSWORD" "admin")
else
    GATEWAY_BASE_URL="http://localhost:8000"
    GATEWAY_PORT="8000"
    LOG_LEVEL="INFO"
    POSTGRES_DB="gateway_db"
    POSTGRES_USER="gateway_user"
    ADMIN_UI_NEXTAUTH_URL="http://localhost:3001"
    ADMIN_UI_OKTA_DOMAIN=""
    ADMIN_UI_OKTA_CLIENT_ID=""
    ADMIN_UI_OKTA_CLIENT_SECRET=""
    GF_SECURITY_ADMIN_PASSWORD="admin"
fi

echo ""
success "Secrets ready."
echo ""

# =============================================================================
# WRITE .env FILE
# =============================================================================

info "Writing .env configuration..."

cat > "${ENV_FILE}" <<ENVEOF
# =============================================================================
# Okta MCP Adapter — Environment Configuration
# Generated by configure.sh at $(date -u '+%Y-%m-%dT%H:%M:%SZ')
# =============================================================================

# === Okta Configuration ===
OKTA_DOMAIN=${CFG_OKTA_DOMAIN}
OKTA_ISSUER=${CFG_OKTA_ISSUER}

# === Generated Secrets ===
ENCRYPTION_KEY=${ENCRYPTION_KEY}
POSTGRES_PASSWORD=${POSTGRES_PASSWORD}
REDIS_PASSWORD=${REDIS_PASSWORD}
HR_PSK_SECRET=${HR_PSK_SECRET}

# === Gateway Configuration ===
GATEWAY_BASE_URL=${GATEWAY_BASE_URL}
GATEWAY_PORT=${GATEWAY_PORT}
# Admin API authentication: Okta OAuth access tokens only (v0.15.x+).
LOG_LEVEL=${LOG_LEVEL}

# === Database ===
POSTGRES_DB=${POSTGRES_DB}
POSTGRES_USER=${POSTGRES_USER}

# === CIMD / Confidential Relay ===
CIMD_ENABLED=${CFG_CIMD_ENABLED}

# === Admin UI ===
ADMIN_UI_NEXTAUTH_URL=${ADMIN_UI_NEXTAUTH_URL}
ADMIN_UI_NEXTAUTH_SECRET=${ADMIN_UI_NEXTAUTH_SECRET}
ADMIN_UI_OKTA_DOMAIN=${ADMIN_UI_OKTA_DOMAIN}
ADMIN_UI_OKTA_CLIENT_ID=${ADMIN_UI_OKTA_CLIENT_ID}
ADMIN_UI_OKTA_CLIENT_SECRET=${ADMIN_UI_OKTA_CLIENT_SECRET}

# === Observability ===
GF_SECURITY_ADMIN_PASSWORD=${GF_SECURITY_ADMIN_PASSWORD}

ENVEOF

success ".env written."
echo ""

# =============================================================================
# CONFIGURATION SUMMARY
# =============================================================================

echo -e "${BOLD}╔══════════════════════════════════════════════════════════╗${RESET}"
echo -e "${BOLD}║              Configuration Summary                     ║${RESET}"
echo -e "${BOLD}╠══════════════════════════════════════════════════════════╣${RESET}"
echo -e "${BOLD}║${RESET}                                                          ${BOLD}║${RESET}"
echo -e "${BOLD}║${RESET}  Okta Domain:       ${CYAN}${CFG_OKTA_DOMAIN}${RESET}"
echo -e "${BOLD}║${RESET}  Issuer:            ${DIM}${CFG_OKTA_ISSUER}${RESET}"
echo -e "${BOLD}║${RESET}                                                          ${BOLD}║${RESET}"
echo -e "${BOLD}║${RESET}  Admin Auth:        ${CYAN}Okta OAuth (no local password)${RESET}"
echo -e "${BOLD}║${RESET}  CIMD Enabled:      ${CYAN}${CFG_CIMD_ENABLED}${RESET}"
echo -e "${BOLD}║${RESET}                                                          ${BOLD}║${RESET}"
echo -e "${BOLD}║${RESET}  ${DIM}Secrets:${RESET}"
echo -e "${BOLD}║${RESET}    ENCRYPTION_KEY:          ${DIM}$(mask_secret "$ENCRYPTION_KEY")${RESET}"
echo -e "${BOLD}║${RESET}    POSTGRES_PASSWORD:       ${DIM}$(mask_secret "$POSTGRES_PASSWORD")${RESET}"
echo -e "${BOLD}║${RESET}    REDIS_PASSWORD:           ${DIM}$(mask_secret "$REDIS_PASSWORD")${RESET}"
echo -e "${BOLD}║${RESET}    HR_PSK_SECRET:            ${DIM}$(mask_secret "$HR_PSK_SECRET")${RESET}"
echo -e "${BOLD}║${RESET}    NEXTAUTH_SECRET:          ${DIM}$(mask_secret "$ADMIN_UI_NEXTAUTH_SECRET")${RESET}"
echo -e "${BOLD}║${RESET}                                                          ${BOLD}║${RESET}"
echo -e "${BOLD}║${RESET}  ${DIM}Config saved to: ${ENV_FILE}${RESET}"
echo -e "${BOLD}║${RESET}                                                          ${BOLD}║${RESET}"
echo -e "${BOLD}╚══════════════════════════════════════════════════════════╝${RESET}"
echo ""

# =============================================================================
# OFFER TO START
# =============================================================================

answer=$(prompt_yn "Start the adapter now?" "y")

if [[ "$answer" == "y" ]]; then
    echo ""

    if [[ -f "${SCRIPT_DIR}/install.sh" ]]; then
        info "Starting installation..."
        echo ""
        exec "${SCRIPT_DIR}/install.sh" --force \
            --okta-domain "$CFG_OKTA_DOMAIN" \
            --okta-issuer "$CFG_OKTA_ISSUER"
    else
        info "Starting Docker Compose stack..."
        echo ""
        docker compose -f "${SCRIPT_DIR}/docker-compose.bundle.yml" up -d
        echo ""
        success "Stack started. Check status with: docker compose -f docker-compose.bundle.yml ps"
    fi
else
    echo ""
    success "Configuration complete."
    echo ""
    echo -e "  To start the adapter later, run:"
    echo -e "    ${DIM}./install.sh --force${RESET}"
    echo -e ""
    echo -e "  Or start directly with Docker Compose:"
    echo -e "    ${DIM}docker compose -f docker-compose.bundle.yml up -d${RESET}"
fi

echo ""
