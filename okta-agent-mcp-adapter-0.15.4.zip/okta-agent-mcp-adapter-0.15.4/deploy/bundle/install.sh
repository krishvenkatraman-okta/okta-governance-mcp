#!/usr/bin/env bash
# =============================================================================
# Okta MCP Adapter — First-Boot Installation Script
# =============================================================================
# Ships inside the portable bundle tarball. Loads Docker images, generates
# secrets, writes .env, and starts the stack.
#
# Usage:
#   ./install.sh \
#     --okta-domain dev-12345.okta.com
#
# See ./install.sh --help for all options.
# =============================================================================

set -euo pipefail

# ---------------------------------------------------------------------------
# Colors
# ---------------------------------------------------------------------------
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
CYAN='\033[0;36m'
BOLD='\033[1m'
DIM='\033[2m'
RESET='\033[0m'

info()    { echo -e "${BLUE}==>${RESET} ${BOLD}$*${RESET}"; }
success() { echo -e "${GREEN}==>${RESET} ${BOLD}$*${RESET}"; }
warn()    { echo -e "${YELLOW}==>${RESET} ${BOLD}$*${RESET}"; }
error()   { echo -e "${RED}==>${RESET} ${BOLD}$*${RESET}" >&2; }
step()    { echo -e "    ${CYAN}•${RESET} $*"; }

# ---------------------------------------------------------------------------
# Globals
# ---------------------------------------------------------------------------
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
LOG_FILE="${SCRIPT_DIR}/install.log"
COMPOSE_FILE="${SCRIPT_DIR}/docker-compose.bundle.yml"
ENV_FILE="${SCRIPT_DIR}/.env"
ENV_TEMPLATE="${SCRIPT_DIR}/.env.template"
IMAGES_DIR="${SCRIPT_DIR}/images"

# Flags
OKTA_DOMAIN=""
OKTA_ISSUER=""
SKIP_START=false
FORCE=false
PROFILE="standalone"
ENABLE_OBSERVABILITY=false

# Cleanup handler
CLEANUP_NEEDED=false

# ---------------------------------------------------------------------------
# Logging
# ---------------------------------------------------------------------------
exec > >(tee -a "${LOG_FILE}") 2>&1
echo "" >> "${LOG_FILE}"
echo "=== install.sh started at $(date -u '+%Y-%m-%dT%H:%M:%SZ') ===" >> "${LOG_FILE}"

# ---------------------------------------------------------------------------
# Ctrl+C handler
# ---------------------------------------------------------------------------
cleanup() {
    echo ""
    if [[ "$CLEANUP_NEEDED" == "true" ]]; then
        warn "Interrupted. Stopping containers..."
        docker compose -f "${COMPOSE_FILE}" down --timeout 10 2>/dev/null || true
    fi
    warn "Installation cancelled. See ${LOG_FILE} for details."
    exit 130
}
trap cleanup INT TERM

# ---------------------------------------------------------------------------
# Parse arguments
# ---------------------------------------------------------------------------
usage() {
    cat <<EOF
Usage: $0 [OPTIONS]

Required (on first run):
  --okta-domain DOMAIN         Okta org domain (e.g., dev-12345.okta.com)

Optional Okta:
  --okta-issuer URL            Override issuer URL (defaults to Org auth server)

Optional:
  --skip-start                 Load images and configure only; don't start stack
  --force                      Overwrite existing .env without prompting
  --profile PROFILE            Deployment profile (default: standalone)
                               Options: standalone, edge-proxy, split-auth, sidecar
  -h, --help                   Show this help
EOF
}

while [[ $# -gt 0 ]]; do
    case "$1" in
        --okta-domain)       OKTA_DOMAIN="$2"; shift 2 ;;
        --okta-issuer)       OKTA_ISSUER="$2"; shift 2 ;;
        --skip-start)        SKIP_START=true; shift ;;
        --force)             FORCE=true; shift ;;
        --profile)
            PROFILE="$2"
            if [[ "$PROFILE" == "observability" ]]; then
                ENABLE_OBSERVABILITY=true
                PROFILE="standalone"
            fi
            shift 2
            ;;
        -h|--help)           usage; exit 0 ;;
        *)                   error "Unknown option: $1"; usage; exit 1 ;;
    esac
done

# =============================================================================
# PREREQUISITES
# =============================================================================

echo ""
echo -e "${BOLD}╔══════════════════════════════════════════════════════════╗${RESET}"
echo -e "${BOLD}║       Okta MCP Adapter — Installation                  ║${RESET}"
echo -e "${BOLD}╚══════════════════════════════════════════════════════════╝${RESET}"
echo ""

info "Checking prerequisites..."
echo ""
PREREQ_FAIL=false

# --- Docker ---
if command -v docker &>/dev/null; then
    DOCKER_VERSION=$(docker version --format '{{.Server.Version}}' 2>/dev/null || echo "0.0.0")
    DOCKER_MAJOR=$(echo "${DOCKER_VERSION}" | cut -d. -f1)
    if (( DOCKER_MAJOR >= 24 )); then
        step "${GREEN}✓${RESET} Docker ${DOCKER_VERSION}"
    else
        step "${RED}✗${RESET} Docker ${DOCKER_VERSION} — version 24+ required"
        PREREQ_FAIL=true
    fi
else
    step "${RED}✗${RESET} Docker not found"
    echo -e "      Install: ${DIM}https://docs.docker.com/get-docker/${RESET}"
    PREREQ_FAIL=true
fi

# --- Docker Compose ---
if docker compose version &>/dev/null; then
    COMPOSE_VERSION=$(docker compose version --short 2>/dev/null || echo "0.0.0")
    COMPOSE_MAJOR=$(echo "${COMPOSE_VERSION}" | cut -d. -f1)
    if (( COMPOSE_MAJOR >= 2 )); then
        step "${GREEN}✓${RESET} Docker Compose ${COMPOSE_VERSION}"
    else
        step "${RED}✗${RESET} Docker Compose ${COMPOSE_VERSION} — v2+ required"
        PREREQ_FAIL=true
    fi
else
    step "${RED}✗${RESET} Docker Compose not found"
    echo -e "      Install: ${DIM}https://docs.docker.com/compose/install/${RESET}"
    PREREQ_FAIL=true
fi

# --- curl ---
if command -v curl &>/dev/null; then
    step "${GREEN}✓${RESET} curl $(curl --version | head -1 | awk '{print $2}')"
else
    step "${RED}✗${RESET} curl not found (needed for smoke tests)"
    PREREQ_FAIL=true
fi

# --- RAM check (4GB minimum) ---
if [[ "$(uname)" == "Darwin" ]]; then
    TOTAL_RAM_MB=$(( $(sysctl -n hw.memsize) / 1024 / 1024 ))
else
    TOTAL_RAM_MB=$(awk '/MemTotal/ {printf "%d", $2/1024}' /proc/meminfo 2>/dev/null || echo "0")
fi
if (( TOTAL_RAM_MB >= 4096 )); then
    step "${GREEN}✓${RESET} RAM: $(( TOTAL_RAM_MB / 1024 ))GB available"
else
    step "${RED}✗${RESET} RAM: $(( TOTAL_RAM_MB / 1024 ))GB — at least 4GB required"
    PREREQ_FAIL=true
fi

# --- Port checks ---
REQUIRED_PORTS=(8000 3001 5432 6379)
for port in "${REQUIRED_PORTS[@]}"; do
    if lsof -iTCP:"${port}" -sTCP:LISTEN -P -n &>/dev/null 2>&1; then
        step "${RED}✗${RESET} Port ${port} is in use"
        echo -e "      ${DIM}$(lsof -iTCP:${port} -sTCP:LISTEN -P -n 2>/dev/null | tail -1)${RESET}"
        PREREQ_FAIL=true
    else
        step "${GREEN}✓${RESET} Port ${port} available"
    fi
done

echo ""

if [[ "$PREREQ_FAIL" == "true" ]]; then
    error "Prerequisites not met. Please fix the issues above and try again."
    exit 1
fi

success "All prerequisites met."
echo ""

# --- Bundle files check ---
if [[ ! -d "${IMAGES_DIR}" ]]; then
    error "images/ directory not found. Are you running from inside the bundle?"
    exit 1
fi

if [[ ! -f "${COMPOSE_FILE}" ]]; then
    error "docker-compose.bundle.yml not found."
    exit 1
fi

if [[ ! -f "${ENV_TEMPLATE}" ]]; then
    error ".env.template not found."
    exit 1
fi

# =============================================================================
# PHASE 1: Handle existing .env
# =============================================================================

RECONFIGURE=true

if [[ -f "${ENV_FILE}" ]] && [[ "$FORCE" != "true" ]]; then
    echo ""
    warn "Existing .env found."
    echo -e "    ${DIM}Use --force to overwrite, or press Enter to use existing config.${RESET}"
    echo ""
    read -rp "    Use existing .env? [Y/n] " response
    case "${response}" in
        [nN]|[nN][oO])
            info "Reconfiguring..."
            RECONFIGURE=true
            ;;
        *)
            info "Using existing .env"
            RECONFIGURE=false
            # Source existing values
            set -a
            source "${ENV_FILE}"
            set +a
            ;;
    esac
fi

# =============================================================================
# PHASE 2: Validate Okta configuration
# =============================================================================

if [[ "$RECONFIGURE" == "true" ]]; then
    # Check required Okta params
    MISSING_PARAMS=()

    if [[ -z "$OKTA_DOMAIN" ]]; then
        MISSING_PARAMS+=("--okta-domain")
    fi
    if [[ ${#MISSING_PARAMS[@]} -gt 0 ]]; then
        error "Missing required parameters for first-time setup:"
        for param in "${MISSING_PARAMS[@]}"; do
            echo -e "    ${RED}•${RESET} ${param}"
        done
        echo ""
        echo -e "  Example:"
        echo -e "    ${DIM}./install.sh --okta-domain dev-12345.okta.com${RESET}"
        exit 1
    fi

    # Derive issuer from domain if not explicitly provided (Org auth server)
    if [[ -z "$OKTA_ISSUER" ]]; then
        OKTA_ISSUER="https://${OKTA_DOMAIN}"
    fi
fi

# =============================================================================
# PHASE 3: Load Docker images
# =============================================================================

info "Loading Docker images..."
echo ""

IMAGE_COUNT=0
TOTAL_IMAGES=$(ls "${IMAGES_DIR}"/*.tar.gz 2>/dev/null | wc -l | tr -d ' ')

for archive in "${IMAGES_DIR}"/*.tar.gz; do
    if [[ ! -f "$archive" ]]; then
        continue
    fi

    filename=$(basename "$archive")
    IMAGE_COUNT=$((IMAGE_COUNT + 1))

    step "[${IMAGE_COUNT}/${TOTAL_IMAGES}] Loading ${CYAN}${filename}${RESET} ..."
    loaded=$(docker load < "$archive" 2>/dev/null | grep -oE 'Loaded image: .+' || echo "loaded")
    step "  ${GREEN}✓${RESET} ${loaded}"
done

echo ""

# Verify images
info "Verifying loaded images..."
EXPECTED_IMAGES=(
    "okta-mcp-adapter:latest"
    "okta-mcp-admin-ui:latest"
    "okta-mcp-hr-server:latest"
    "okta-mcp-deploy-server:latest"
    "postgres:15-alpine"
    "redis:7-alpine"
)

VERIFY_FAIL=false
for img in "${EXPECTED_IMAGES[@]}"; do
    if docker image inspect "$img" &>/dev/null; then
        step "${GREEN}✓${RESET} ${img}"
    else
        step "${RED}✗${RESET} ${img} — not found"
        VERIFY_FAIL=true
    fi
done

if [[ "$VERIFY_FAIL" == "true" ]]; then
    error "Some images failed to load. Check install.log for details."
    exit 1
fi

echo ""
success "All images loaded."
echo ""

# =============================================================================
# PHASE 4: Generate secrets
# =============================================================================

if [[ "$RECONFIGURE" == "true" ]]; then
    info "Generating secrets..."
    echo ""

    # Encryption key: 32 random bytes, base64-encoded
    ENCRYPTION_KEY=$(openssl rand -base64 32)
    step "${GREEN}✓${RESET} ENCRYPTION_KEY generated"

    # Database password
    POSTGRES_PASSWORD=$(openssl rand -base64 24 | tr -dc 'A-Za-z0-9' | head -c 20)
    step "${GREEN}✓${RESET} POSTGRES_PASSWORD generated"

    # Redis password
    REDIS_PASSWORD=$(openssl rand -base64 16 | tr -dc 'A-Za-z0-9' | head -c 16)
    step "${GREEN}✓${RESET} REDIS_PASSWORD generated"

    # HR PSK secret
    HR_PSK_SECRET=$(openssl rand -base64 32)
    step "${GREEN}✓${RESET} HR_PSK_SECRET generated"

    # NextAuth secret (for admin UI)
    ADMIN_UI_NEXTAUTH_SECRET=$(openssl rand -base64 32)
    step "${GREEN}✓${RESET} ADMIN_UI_NEXTAUTH_SECRET generated"

    echo ""
    success "Secrets generated."
    echo ""

    # =========================================================================
    # PHASE 5: Write .env
    # =========================================================================

    info "Writing .env configuration..."

    cat > "${ENV_FILE}" <<ENVEOF
# =============================================================================
# Okta MCP Adapter — Environment Configuration
# Generated by install.sh at $(date -u '+%Y-%m-%dT%H:%M:%SZ')
# =============================================================================

# === Okta Configuration ===
OKTA_DOMAIN=${OKTA_DOMAIN}
OKTA_ISSUER=${OKTA_ISSUER}

# === Generated Secrets ===
ENCRYPTION_KEY=${ENCRYPTION_KEY}
POSTGRES_PASSWORD=${POSTGRES_PASSWORD}
REDIS_PASSWORD=${REDIS_PASSWORD}
HR_PSK_SECRET=${HR_PSK_SECRET}

# === Gateway Configuration ===
GATEWAY_BASE_URL=http://localhost:8000
GATEWAY_PORT=8000
# Admin API authentication: Okta OAuth access tokens only (v0.15.x+).
LOG_LEVEL=INFO

# === Database ===
POSTGRES_DB=gateway_db
POSTGRES_USER=gateway_user

# === CIMD / Confidential Relay ===
CIMD_ENABLED=true

# === Admin UI ===
ADMIN_UI_NEXTAUTH_URL=http://localhost:3001
ADMIN_UI_NEXTAUTH_SECRET=${ADMIN_UI_NEXTAUTH_SECRET}
ADMIN_UI_OKTA_DOMAIN=
ADMIN_UI_OKTA_CLIENT_ID=
ADMIN_UI_OKTA_CLIENT_SECRET=

# === Observability ===
GF_SECURITY_ADMIN_PASSWORD=admin

# === Deployment ===
DEPLOYMENT_MODE=${PROFILE}
ENVEOF

    success ".env written."
    echo ""
fi

# =============================================================================
# PHASE 6: Start the stack
# =============================================================================

if [[ "$SKIP_START" == "true" ]]; then
    warn "Skipping stack start (--skip-start)"
    echo ""
else
    CLEANUP_NEEDED=true

    COMPOSE_PROFILES=""
    if [[ "$ENABLE_OBSERVABILITY" == "true" ]]; then
        COMPOSE_PROFILES="--profile observability"
    fi

    info "Starting Okta MCP Adapter stack..."
    echo ""

    docker compose -f "${COMPOSE_FILE}" ${COMPOSE_PROFILES} up -d 2>&1 | while read -r line; do
        step "${line}"
    done

    echo ""
    info "Waiting for services to become healthy..."
    echo ""

    # Wait for health with timeout
    TIMEOUT=120
    ELAPSED=0
    INTERVAL=5

    SERVICES=("postgres" "redis" "okta-agent-mcp-adapter" "admin-ui")
    declare -A SERVICE_HEALTHY
    for svc in "${SERVICES[@]}"; do
        SERVICE_HEALTHY[$svc]=false
    done

    ALL_HEALTHY=false

    while (( ELAPSED < TIMEOUT )); do
        ALL_HEALTHY=true

        for svc in "${SERVICES[@]}"; do
            if [[ "${SERVICE_HEALTHY[$svc]}" == "true" ]]; then
                continue
            fi

            health=$(docker inspect --format='{{.State.Health.Status}}' "okta-mcp-${svc}" 2>/dev/null || \
                     docker inspect --format='{{.State.Health.Status}}' "${svc}" 2>/dev/null || \
                     echo "not_found")

            case "${health}" in
                healthy)
                    SERVICE_HEALTHY[$svc]=true
                    step "${GREEN}✓${RESET} ${svc} is healthy"
                    ;;
                unhealthy)
                    error "${svc} is unhealthy!"
                    docker logs "okta-mcp-${svc}" --tail 20 2>/dev/null || \
                        docker logs "${svc}" --tail 20 2>/dev/null || true
                    ;;
                *)
                    ALL_HEALTHY=false
                    ;;
            esac
        done

        if [[ "$ALL_HEALTHY" == "true" ]]; then
            break
        fi

        # Progress indicator
        printf "    ${DIM}Waiting... (%ds / %ds)${RESET}\r" "$ELAPSED" "$TIMEOUT"
        sleep "$INTERVAL"
        ELAPSED=$((ELAPSED + INTERVAL))
    done

    echo ""

    if [[ "$ALL_HEALTHY" != "true" ]]; then
        error "Timed out waiting for services after ${TIMEOUT}s."
        echo ""
        echo -e "  Troubleshooting steps:"
        echo -e "    ${DIM}1. Check container status:${RESET}  docker compose -f docker-compose.bundle.yml ps"
        echo -e "    ${DIM}2. Check adapter logs:${RESET}      docker logs okta-agent-mcp-adapter"
        echo -e "    ${DIM}3. Check postgres logs:${RESET}     docker logs okta-mcp-postgres"
        echo -e "    ${DIM}4. Verify .env settings:${RESET}    cat .env"
        echo -e "    ${DIM}5. Review install log:${RESET}      cat install.log"
        echo ""
        exit 1
    fi

    # Quick smoke test
    echo ""
    info "Running smoke tests..."
    SMOKE_FAIL=false

    # Gateway health
    if curl -sf http://localhost:8000/.well-known/oauth-protected-resource >/dev/null 2>&1; then
        step "${GREEN}✓${RESET} Gateway responding on :8000"
    else
        step "${YELLOW}⚠${RESET} Gateway not responding on :8000 (may still be starting)"
        SMOKE_FAIL=true
    fi

    # Admin UI
    if curl -sf http://localhost:3001/ >/dev/null 2>&1; then
        step "${GREEN}✓${RESET} Admin UI responding on :3001"
    else
        step "${YELLOW}⚠${RESET} Admin UI not responding on :3001 (may still be starting)"
        SMOKE_FAIL=true
    fi

    CLEANUP_NEEDED=false
    echo ""
fi

# =============================================================================
# SUMMARY
# =============================================================================

VERSION="unknown"
if [[ -f "${SCRIPT_DIR}/VERSION" ]]; then
    VERSION=$(cat "${SCRIPT_DIR}/VERSION" | tr -d '[:space:]')
fi

echo -e "${BOLD}╔══════════════════════════════════════════════════════════╗${RESET}"
echo -e "${BOLD}║       Okta MCP Adapter — Installation Complete          ║${RESET}"
echo -e "${BOLD}╠══════════════════════════════════════════════════════════╣${RESET}"
echo -e "${BOLD}║${RESET}                                                          ${BOLD}║${RESET}"
echo -e "${BOLD}║${RESET}  Version:    ${CYAN}${VERSION}${RESET}                                       ${BOLD}║${RESET}"
echo -e "${BOLD}║${RESET}                                                          ${BOLD}║${RESET}"

if [[ "$SKIP_START" != "true" ]]; then
echo -e "${BOLD}║${RESET}  ${BOLD}Services:${RESET}                                              ${BOLD}║${RESET}"
echo -e "${BOLD}║${RESET}    Gateway:     ${GREEN}http://localhost:8000${RESET}                    ${BOLD}║${RESET}"
echo -e "${BOLD}║${RESET}    Admin UI:    ${GREEN}http://localhost:3001${RESET}                    ${BOLD}║${RESET}"
if [[ "$ENABLE_OBSERVABILITY" == "true" ]]; then
echo -e "${BOLD}║${RESET}    Grafana:     ${GREEN}http://localhost:3000${RESET}                    ${BOLD}║${RESET}"
fi
echo -e "${BOLD}║${RESET}                                                          ${BOLD}║${RESET}"
fi

echo -e "${BOLD}║${RESET}  ${BOLD}Admin Sign-In:${RESET}                                         ${BOLD}║${RESET}"
echo -e "${BOLD}║${RESET}    Sign in to the Admin UI with your Okta account        ${BOLD}║${RESET}"
echo -e "${BOLD}║${RESET}    (configure the OIDC app via ADMIN_UI_OKTA_* in .env)  ${BOLD}║${RESET}"
echo -e "${BOLD}║${RESET}                                                          ${BOLD}║${RESET}"
echo -e "${BOLD}║${RESET}  ${BOLD}Okta Domain:${RESET}  ${OKTA_DOMAIN:-see .env}                           ${BOLD}║${RESET}"
echo -e "${BOLD}║${RESET}                                                          ${BOLD}║${RESET}"
echo -e "${BOLD}╠══════════════════════════════════════════════════════════╣${RESET}"
echo -e "${BOLD}║${RESET}                                                          ${BOLD}║${RESET}"
echo -e "${BOLD}║${RESET}  ${BOLD}Next Steps:${RESET}                                            ${BOLD}║${RESET}"
echo -e "${BOLD}║${RESET}                                                          ${BOLD}║${RESET}"
echo -e "${BOLD}║${RESET}  1. Open Admin UI and configure backends                 ${BOLD}║${RESET}"
echo -e "${BOLD}║${RESET}     ${DIM}http://localhost:3001${RESET}                                  ${BOLD}║${RESET}"
echo -e "${BOLD}║${RESET}                                                          ${BOLD}║${RESET}"
echo -e "${BOLD}║${RESET}  2. Configure Claude Code:                               ${BOLD}║${RESET}"
echo -e "${BOLD}║${RESET}     ${DIM}claude mcp add okta-gateway \\${RESET}                        ${BOLD}║${RESET}"
echo -e "${BOLD}║${RESET}     ${DIM}  --transport http \\${RESET}                                 ${BOLD}║${RESET}"
echo -e "${BOLD}║${RESET}     ${DIM}  --url http://localhost:8000${RESET}                         ${BOLD}║${RESET}"
echo -e "${BOLD}║${RESET}                                                          ${BOLD}║${RESET}"
echo -e "${BOLD}║${RESET}  3. Check status:  ${DIM}./status.sh${RESET}                            ${BOLD}║${RESET}"
echo -e "${BOLD}║${RESET}  4. View logs:     ${DIM}docker compose logs -f${RESET}                 ${BOLD}║${RESET}"
echo -e "${BOLD}║${RESET}  5. Uninstall:     ${DIM}./uninstall.sh${RESET}                         ${BOLD}║${RESET}"
echo -e "${BOLD}║${RESET}                                                          ${BOLD}║${RESET}"
echo -e "${BOLD}╚══════════════════════════════════════════════════════════╝${RESET}"
echo ""

success "Installation complete. See install.log for full details."
