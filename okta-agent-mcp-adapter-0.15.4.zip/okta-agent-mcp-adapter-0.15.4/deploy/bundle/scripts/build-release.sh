#!/usr/bin/env bash
# =============================================================================
# Okta MCP Adapter — Build Release Bundle
# =============================================================================
# Automates the full bundle build pipeline:
#   1. Build Docker images from source
#   2. Export images as compressed tarballs
#   3. Package everything into a distributable bundle
#
# Usage:
#   ./scripts/build-release.sh
#   ./scripts/build-release.sh --version 1.0.0
#   ./scripts/build-release.sh --skip-build
#   ./scripts/build-release.sh --platform linux/arm64
# =============================================================================

set -euo pipefail

# ---------------------------------------------------------------------------
# Colors and formatting
# ---------------------------------------------------------------------------
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
CYAN='\033[0;36m'
BOLD='\033[1m'
DIM='\033[2m'
RESET='\033[0m'

info()    { echo -e "${BLUE}==>${RESET} ${BOLD}$*${RESET}"; }
success() { echo -e "${GREEN}==>${RESET} ${BOLD}$*${RESET}"; }
warn()    { echo -e "${YELLOW}==>${RESET} ${BOLD}$*${RESET}"; }
error()   { echo -e "${RED}==>${RESET} ${BOLD}$*${RESET}" >&2; }
step()    { echo -e "    ${CYAN}•${RESET} $*"; }

# ---------------------------------------------------------------------------
# Resolve paths
# ---------------------------------------------------------------------------
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
BUNDLE_DIR="$(cd "${SCRIPT_DIR}/.." && pwd)"
REPO_ROOT="$(cd "${BUNDLE_DIR}/../.." && pwd)"

# ---------------------------------------------------------------------------
# Defaults
# ---------------------------------------------------------------------------
VERSION=""
SKIP_BUILD=false
PLATFORM=""  # Empty = native platform (no cross-compile)

# ---------------------------------------------------------------------------
# Parse arguments
# ---------------------------------------------------------------------------
while [[ $# -gt 0 ]]; do
    case "$1" in
        --version)
            VERSION="$2"
            shift 2
            ;;
        --skip-build)
            SKIP_BUILD=true
            shift
            ;;
        --platform)
            PLATFORM="$2"
            shift 2
            ;;
        -h|--help)
            echo "Usage: $0 [OPTIONS]"
            echo ""
            echo "Options:"
            echo "  --version VERSION    Set bundle version (default: from VERSION file or 'dev')"
            echo "  --skip-build         Skip Docker image builds (use existing images)"
            echo "  --platform PLATFORM  Target platform (default: linux/amd64)"
            echo "  -h, --help           Show this help"
            exit 0
            ;;
        *)
            error "Unknown option: $1"
            exit 1
            ;;
    esac
done

# Resolve version: flag > VERSION file > 'dev'
if [[ -z "$VERSION" ]]; then
    if [[ -f "${BUNDLE_DIR}/VERSION" ]]; then
        VERSION="$(cat "${BUNDLE_DIR}/VERSION" | tr -d '[:space:]')"
    else
        VERSION="dev"
    fi
fi

# ---------------------------------------------------------------------------
# Image definitions (bash 3.2 compatible — no associative arrays)
# ---------------------------------------------------------------------------
IMAGE_NAMES="okta-mcp-adapter okta-mcp-admin-ui okta-mcp-hr-server okta-mcp-deploy-server postgres-15-alpine redis-7-alpine grafana loki promtail"
BUILD_IMAGES="okta-mcp-adapter okta-mcp-admin-ui okta-mcp-hr-server okta-mcp-deploy-server"
VENDOR_IMAGES="postgres-15-alpine redis-7-alpine grafana loki promtail"

# Lookup functions (replace associative arrays for bash 3.2 compat)
# Tags MUST match docker-compose.bundle.yml image: fields exactly.
get_tag() {
    case "$1" in
        okta-mcp-adapter)        echo "okta-mcp-adapter:latest" ;;
        okta-mcp-admin-ui)       echo "okta-mcp-admin-ui:latest" ;;
        okta-mcp-hr-server)      echo "okta-mcp-hr-server:latest" ;;
        okta-mcp-deploy-server)  echo "okta-mcp-deploy-server:latest" ;;
        postgres-15-alpine)      echo "postgres:15-alpine" ;;
        redis-7-alpine)          echo "redis:7-alpine" ;;
        grafana)                 echo "grafana/grafana:11.0.0" ;;
        loki)                    echo "grafana/loki:3.0.0" ;;
        promtail)                echo "grafana/promtail:3.0.0" ;;
    esac
}

get_dockerfile() {
    case "$1" in
        okta-mcp-adapter)        echo "${REPO_ROOT}/Dockerfile" ;;
        okta-mcp-admin-ui)       echo "${REPO_ROOT}/okta_agent_proxy_admin_ui/Dockerfile" ;;
        okta-mcp-hr-server)      echo "${REPO_ROOT}/examples/01-hr-system/Dockerfile" ;;
        okta-mcp-deploy-server)  echo "${REPO_ROOT}/examples/05-deploy-server/Dockerfile" ;;
    esac
}

get_context() {
    case "$1" in
        okta-mcp-adapter)        echo "${REPO_ROOT}" ;;
        okta-mcp-admin-ui)       echo "${REPO_ROOT}/okta_agent_proxy_admin_ui" ;;
        okta-mcp-hr-server)      echo "${REPO_ROOT}/examples/01-hr-system" ;;
        okta-mcp-deploy-server)  echo "${REPO_ROOT}/examples/05-deploy-server" ;;
    esac
}

# Build-time and size tracking (stored as NAME=VALUE pairs in temp files)
BUILD_TIMES_FILE="$(mktemp)"
EXPORT_SIZES_FILE="$(mktemp)"
trap 'rm -f "$BUILD_TIMES_FILE" "$EXPORT_SIZES_FILE"' EXIT

set_build_time() { echo "$1=$2" >> "$BUILD_TIMES_FILE"; }
get_build_time() { grep "^$1=" "$BUILD_TIMES_FILE" 2>/dev/null | tail -1 | cut -d= -f2 || echo "N/A"; }
set_export_size() { echo "$1=$2" >> "$EXPORT_SIZES_FILE"; }
get_export_size() { grep "^$1=" "$EXPORT_SIZES_FILE" 2>/dev/null | tail -1 | cut -d= -f2 || echo "N/A"; }

# ---------------------------------------------------------------------------
# Directories
# ---------------------------------------------------------------------------
IMAGES_DIR="${BUNDLE_DIR}/images"
DIST_DIR="${BUNDLE_DIR}/dist"
STAGING_DIR="${BUNDLE_DIR}/dist/okta-mcp-adapter-bundle-${VERSION}"
TARBALL_NAME="okta-mcp-adapter-bundle-${VERSION}.tar.gz"
TARBALL_PATH="${DIST_DIR}/${TARBALL_NAME}"

# Files that must exist for the bundle
BUNDLE_FILES=(
    "docker-compose.bundle.yml"
    ".env.template"
    "install.sh"
    "configure.sh"
    "status.sh"
    "uninstall.sh"
    "README.md"
)

# ---------------------------------------------------------------------------
# Helper: elapsed time formatting
# ---------------------------------------------------------------------------
format_duration() {
    local seconds=$1
    if (( seconds < 60 )); then
        echo "${seconds}s"
    else
        local mins=$(( seconds / 60 ))
        local secs=$(( seconds % 60 ))
        echo "${mins}m ${secs}s"
    fi
}

# ---------------------------------------------------------------------------
# Helper: human-readable file size
# ---------------------------------------------------------------------------
file_size() {
    local file="$1"
    if [[ -f "$file" ]]; then
        du -h "$file" | cut -f1 | tr -d '[:space:]'
    else
        echo "N/A"
    fi
}

# =============================================================================
# MAIN
# =============================================================================

echo ""
echo -e "${BOLD}╔══════════════════════════════════════════════════════════╗${RESET}"
echo -e "${BOLD}║     Okta MCP Adapter — Release Bundle Builder          ║${RESET}"
echo -e "${BOLD}╚══════════════════════════════════════════════════════════╝${RESET}"
echo ""
echo -e "  Version:    ${CYAN}${VERSION}${RESET}"
echo -e "  Platform:   ${CYAN}${PLATFORM:-native}${RESET}"
echo -e "  Skip build: ${CYAN}${SKIP_BUILD}${RESET}"
echo -e "  Repo root:  ${DIM}${REPO_ROOT}${RESET}"
echo -e "  Bundle dir: ${DIM}${BUNDLE_DIR}${RESET}"
echo ""

TOTAL_START=$(date +%s)

# ---------------------------------------------------------------------------
# Phase 0: Clean previous artifacts (idempotent)
# ---------------------------------------------------------------------------
info "Cleaning previous artifacts..."
rm -rf "${IMAGES_DIR}" "${DIST_DIR}"
mkdir -p "${IMAGES_DIR}" "${DIST_DIR}"
success "Clean."
echo ""

# ---------------------------------------------------------------------------
# Phase 1: Build Docker images
# ---------------------------------------------------------------------------
if [[ "$SKIP_BUILD" == "true" ]]; then
    warn "Skipping build phase (--skip-build)"
    echo ""
    for name in $BUILD_IMAGES; do
        set_build_time "$name" "skipped"
    done
else
    info "Phase 1: Building Docker images (platform: ${PLATFORM:-native})"
    echo ""

    for name in $BUILD_IMAGES; do
        tag="$(get_tag "$name")"
        dockerfile="$(get_dockerfile "$name")"
        context="$(get_context "$name")"

        step "Building ${CYAN}${tag}${RESET} ..."
        build_start=$(date +%s)

        build_cmd="docker build -t ${tag} -f ${dockerfile}"
        if [[ -n "${PLATFORM}" ]]; then
            build_cmd="${build_cmd} --platform ${PLATFORM}"
        fi
        build_cmd="${build_cmd} ${context}"

        if ! eval "${build_cmd}" > /dev/null 2>&1; then
            error "Build failed for ${tag}. Re-running with output:"
            eval "${build_cmd}"
            exit 1
        fi

        build_end=$(date +%s)
        elapsed=$(( build_end - build_start ))
        set_build_time "$name" "$elapsed"
        step "${GREEN}✓${RESET} ${tag} built in $(format_duration ${elapsed})"
    done

    # Pull vendor images
    echo ""
    step "Pulling vendor images..."
    for name in $VENDOR_IMAGES; do
        tag="$(get_tag "$name")"
        pull_start=$(date +%s)

        pull_cmd="docker pull ${tag}"
        if [[ -n "${PLATFORM}" ]]; then
            pull_cmd="docker pull --platform ${PLATFORM} ${tag}"
        fi
        eval "${pull_cmd}" > /dev/null 2>&1

        pull_end=$(date +%s)
        elapsed=$(( pull_end - pull_start ))
        set_build_time "$name" "$elapsed"
        step "${GREEN}✓${RESET} ${tag} pulled in $(format_duration ${elapsed})"
    done

    echo ""
    success "All images built."
    echo ""
fi

# ---------------------------------------------------------------------------
# Phase 2: Export images
# ---------------------------------------------------------------------------
info "Phase 2: Exporting images to ${DIM}images/${RESET}"
echo ""

for name in $IMAGE_NAMES; do
    tag="$(get_tag "$name")"
    archive="${IMAGES_DIR}/${name}.tar.gz"

    step "Saving ${CYAN}${tag}${RESET} ..."
    docker save "${tag}" | gzip > "${archive}"

    size=$(file_size "${archive}")
    set_export_size "$name" "$size"
    step "${GREEN}✓${RESET} ${name}.tar.gz  ${DIM}(${size})${RESET}"
done

echo ""
success "All images exported."
echo ""

# ---------------------------------------------------------------------------
# Phase 3: Package release bundle
# ---------------------------------------------------------------------------
info "Phase 3: Packaging release bundle"
echo ""

# Create staging directory
mkdir -p "${STAGING_DIR}/images"

# Copy images
step "Copying images..."
cp "${IMAGES_DIR}"/*.tar.gz "${STAGING_DIR}/images/"

# Copy bundle files (skip missing with a warning)
step "Copying bundle files..."
missing_files=()
for f in "${BUNDLE_FILES[@]}"; do
    src="${BUNDLE_DIR}/${f}"
    if [[ -f "${src}" ]]; then
        cp "${src}" "${STAGING_DIR}/"
        step "  ${GREEN}✓${RESET} ${f}"
    else
        missing_files+=("${f}")
        step "  ${YELLOW}⚠${RESET} ${f} ${DIM}(not found — placeholder created)${RESET}"
        echo "# ${f} — placeholder (not yet created)" > "${STAGING_DIR}/${f}"
    fi
done

# Write VERSION file
echo "${VERSION}" > "${STAGING_DIR}/VERSION"
step "  ${GREEN}✓${RESET} VERSION (${VERSION})"

# Create tarball
echo ""
step "Creating tarball..."
tar -czf "${TARBALL_PATH}" \
    -C "${DIST_DIR}" \
    "okta-mcp-adapter-bundle-${VERSION}"

# Compute checksum
CHECKSUM=$(shasum -a 256 "${TARBALL_PATH}" | cut -d' ' -f1)
TARBALL_SIZE=$(file_size "${TARBALL_PATH}")

# Clean up staging directory
rm -rf "${STAGING_DIR}"

echo ""
success "Bundle packaged."
echo ""

# ---------------------------------------------------------------------------
# Summary
# ---------------------------------------------------------------------------
TOTAL_END=$(date +%s)
TOTAL_ELAPSED=$(( TOTAL_END - TOTAL_START ))

echo -e "${BOLD}╔══════════════════════════════════════════════════════════╗${RESET}"
echo -e "${BOLD}║                    Build Summary                        ║${RESET}"
echo -e "${BOLD}╠══════════════════════════════════════════════════════════╣${RESET}"
printf  "${BOLD}║${RESET} %-28s %10s %12s   ${BOLD}║${RESET}\n" "IMAGE" "SIZE" "BUILD TIME"
echo -e "${BOLD}╠══════════════════════════════════════════════════════════╣${RESET}"

for name in $IMAGE_NAMES; do
    size="$(get_export_size "$name")"
    bt="$(get_build_time "$name")"
    if [[ "$bt" == "skipped" ]]; then
        bt_display="skipped"
    elif [[ "$bt" != "N/A" ]]; then
        bt_display="$(format_duration "$bt")"
    else
        bt_display="N/A"
    fi
    printf "${BOLD}║${RESET} %-28s %10s %12s   ${BOLD}║${RESET}\n" "$name" "$size" "$bt_display"
done

echo -e "${BOLD}╠══════════════════════════════════════════════════════════╣${RESET}"
printf  "${BOLD}║${RESET} %-28s %10s %12s   ${BOLD}║${RESET}\n" "TOTAL" "$TARBALL_SIZE" "$(format_duration $TOTAL_ELAPSED)"
echo -e "${BOLD}╚══════════════════════════════════════════════════════════╝${RESET}"
echo ""
echo -e "  ${BOLD}Tarball:${RESET}  ${TARBALL_PATH}"
echo -e "  ${BOLD}Size:${RESET}     ${TARBALL_SIZE}"
echo -e "  ${BOLD}SHA-256:${RESET}  ${CHECKSUM}"
echo ""

if [[ ${#missing_files[@]} -gt 0 ]]; then
    warn "Missing bundle files (placeholders were used):"
    for f in "${missing_files[@]}"; do
        echo -e "    ${YELLOW}•${RESET} ${f}"
    done
    echo ""
fi

success "Done. Distribute ${TARBALL_NAME} to deploy the adapter."
