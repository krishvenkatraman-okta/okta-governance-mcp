# Okta MCP Adapter — Portable Bundle

Self-contained deployment package for the Okta MCP Adapter, an OAuth 2.1 gateway that enables AI coding assistants (Claude Code, Cursor, GitHub Copilot) to securely access backend MCP servers using Okta authentication.

---

## What's Included

| File | Description |
|------|-------------|
| `docker-compose.bundle.yml` | Docker Compose stack definition (all services) |
| `.env.template` | Environment variable template with documentation |
| `install.sh` | First-boot installer: loads images, generates secrets, starts stack |
| `configure.sh` | Interactive setup wizard with validation and connectivity checks |
| `status.sh` | Status dashboard: health checks, smoke tests, resource usage |
| `uninstall.sh` | Clean teardown: stops services, removes volumes and data |
| `VERSION` | Bundle version number |
| `README.md` | This file |
| `images/` | Pre-built Docker images (compressed tarballs) |
| `images/okta-mcp-adapter.tar.gz` | Gateway — OAuth 2.1 proxy with 7-layer pipeline |
| `images/okta-mcp-admin-ui.tar.gz` | Admin UI — Next.js web console for configuration |
| `images/okta-mcp-hr-server.tar.gz` | HR MCP Server — example backend for demos |
| `images/okta-mcp-deploy-server.tar.gz` | Deploy MCP Server — example backend with cross-app access |
| `images/postgres-15-alpine.tar.gz` | PostgreSQL 15 — configuration and credential storage |
| `images/redis-7-alpine.tar.gz` | Redis 7 — token cache and pub/sub event bus |

---

## Prerequisites

- **Docker 24+** with **Docker Compose v2+**
- **4 GB RAM** minimum (8 GB recommended for observability stack)
- **Network access** to your Okta org domain (`*.okta.com`) for JWT validation
- **An Okta org** (the adapter uses the Org authorization server by default)
- **Ports available:** 8000 (gateway), 3001 (admin UI), 5432 (postgres), 6379 (redis)

---

## 5-Minute Quickstart

```bash
# 1. Extract the bundle
tar xzf okta-mcp-adapter-bundle-*.tar.gz
cd okta-mcp-adapter-bundle-*

# 2. Run the installer
./install.sh --okta-domain dev-12345.okta.com

# 3. Open the Admin UI
open http://localhost:3001
# Login with the admin credentials shown in the install output

# 4. Connect Claude Code
claude mcp add okta-gateway \
  --transport http \
  --url http://localhost:8000
```

The installer will:
- Check prerequisites (Docker, Compose, RAM, ports)
- Load all Docker images from the bundle
- Generate encryption keys and passwords
- Write the `.env` configuration file
- Start all services and wait for health checks
- Print credentials and next steps

---

## Interactive Setup (Alternative)

For a guided experience with connectivity validation:

```bash
./configure.sh
```

The wizard walks through each configuration step:
1. Okta domain (validates reachability)
2. Authorization server ID (tests the issuer endpoint)
3. Admin password (auto-generates if left empty)
4. Deployment profile selection
5. CIMD / Confidential Relay setup (optional)

It generates secrets, writes `.env`, and offers to start the stack.

---

## Architecture

The adapter operates as a 7-layer proxy pipeline between AI clients and backend MCP servers:

```
                          ┌─────────────────────────────────────────────┐
                          │           Okta MCP Adapter                  │
                          │                                             │
  ┌──────────┐    HTTPS   │  ┌─────────┐  ┌──────┐  ┌──────────────┐  │    ┌─────────────┐
  │Claude    ├───────────►│  │ Layer 1  │  │L2-L3 │  │   L5-L7      │  ├───►│ HR MCP      │
  │Code      │  OAuth 2.1 │  │ FastMCP  ├─►│Auth/ ├─►│ Token Exch / │  │    │ Server      │
  │Cursor    │  Bearer JWT│  │ Server   │  │Authz │  │ Cache / Proxy│  │    │ :8001       │
  │Copilot   │            │  └─────────┘  └──────┘  └──────────────┘  │    ├─────────────┤
  └──────────┘            │                    │                       │    │ Deploy MCP  │
                          │              ┌─────┴─────┐                 ├───►│ Server      │
                          │              │  Layer 4   │                │    │ :8005       │
                          │              │  Routing   │                │    └─────────────┘
                          │              └───────────┘                 │
                          └───────┬─────────────┬─────────────────────┘
                                  │             │
                          ┌───────┴──┐   ┌──────┴───┐
                          │PostgreSQL│   │  Redis   │
                          │  :5432   │   │  :6379   │
                          └──────────┘   └──────────┘
```

**Layer pipeline:**

| Layer | Function | Description |
|-------|----------|-------------|
| 1 | FastMCP Server | HTTP transport, MCP protocol lifecycle |
| 2 | Authentication | Okta JWT validation, JWKS key caching |
| 3 | Authorization | Agent-to-backend access control |
| 4 | Routing | Path-based or namespace-based backend selection |
| 5 | Token Exchange | ID-JAG token issuance (RFC 8693) for cross-app access |
| 6 | Token Cache | TTL-based caching with automatic expiration |
| 7 | Proxy | Backend authentication injection, HTTP forwarding |

### Services and Ports

| Service | Container | Port | Description |
|---------|-----------|------|-------------|
| Gateway | `okta-agent-mcp-adapter` | 8000 | MCP proxy with OAuth 2.1 |
| Admin UI | `okta-mcp-admin-ui` | 3001 | Web console for configuration |
| PostgreSQL | `okta-mcp-postgres` | 5432 | Agent/backend config storage |
| Redis | `okta-mcp-redis` | 6379 | Token cache, pub/sub |
| HR MCP Server | `hr-mcp-server` | 8001 | Demo backend (PSK auth) |
| Deploy MCP Server | `deploy-mcp-server` | 8005 | Demo backend (cross-app auth) |
| Grafana | `okta-mcp-grafana` | 3000 | Dashboards (observability profile) |
| Loki | `okta-mcp-loki` | 3100 | Log aggregation (observability profile) |

---

## Configuration Reference

All configuration is via environment variables in `.env`. The installer generates this file automatically.

### Required — Okta Configuration

| Variable | Description | Example |
|----------|-------------|---------|
| `OKTA_DOMAIN` | Your Okta org domain | `dev-12345.okta.com` |
| `OKTA_ISSUER` | _(Optional)_ Override issuer URL. Defaults to Org auth server. | `https://dev-12345.okta.com/oauth2/ausXXXX` |

> **Note:** Okta currently requires the Org authorization server for AI Agent token exchange (XAA/ID-JAG). `OKTA_ISSUER` is provided for future use when Okta adds custom auth server support for AI Agent flows.

### Auto-Generated Secrets

These are generated by `install.sh` or `configure.sh`. Do not change after initial setup unless you understand the implications.

| Variable | Description |
|----------|-------------|
| `ENCRYPTION_KEY` | AES-256-GCM key for encrypting stored credentials (base64) |
| `POSTGRES_PASSWORD` | PostgreSQL database password |
| `REDIS_PASSWORD` | Redis authentication password |
| `HR_PSK_SECRET` | Pre-shared key for the demo HR backend |
| `ADMIN_UI_NEXTAUTH_SECRET` | NextAuth session signing secret |

> Admin API authentication is Okta-OAuth-only (v0.15.x+). No local
> `ADMIN_PASSWORD` is required.

> **Warning:** Changing `ENCRYPTION_KEY` after data has been stored will make existing encrypted credentials unreadable.

### Optional — Gateway Settings

| Variable | Default | Description |
|----------|---------|-------------|
| `GATEWAY_BASE_URL` | `http://localhost:8000` | Public URL where the gateway is reachable |
| `GATEWAY_PORT` | `8000` | Port inside the container |
| `LOG_LEVEL` | `INFO` | Log verbosity: `DEBUG`, `INFO`, `WARNING`, `ERROR` |
| `POSTGRES_DB` | `gateway_db` | PostgreSQL database name |
| `POSTGRES_USER` | `gateway_user` | PostgreSQL username |

### Optional — CIMD / Confidential Relay

Enable Client Identity Metadata Document support for dynamic client registration.

| Variable | Default | Description |
|----------|---------|-------------|
| `CIMD_ENABLED` | `true` | Enable CIMD client support |
| `RELAY_OKTA_CLIENT_ID` | _(empty)_ | Okta OIDC app client ID for the relay |
| `RELAY_OKTA_CLIENT_SECRET` | _(empty)_ | Okta OIDC app client secret for the relay |
| `RELAY_OKTA_AUTH_SERVER_ID` | `org` | Auth server for relay token exchange (must be `org` for ID-JAG) |
| `CIMD_REQUIRE_HTTPS` | `true` | Require HTTPS for CIMD document URLs |
| `CIMD_TRUSTED_DOMAINS` | _(empty)_ | Comma-separated allowlist of trusted CIMD domains |
| `CIMD_ALLOW_LOCALHOST` | `false` | Allow localhost CIMD URLs (development only) |

### Optional — DCR (Dynamic Client Registration)

| Variable | Default | Description |
|----------|---------|-------------|
| `DCR_ENABLED` | `true` | Enable RFC 7591 DCR endpoint |
| `DCR_PROVISION_OKTA_APP` | `false` | Create real Okta OIDC apps (requires API token) |
| `DCR_AUTO_ENABLE_AGENT` | `true` | Auto-enable agents created via DCR |

### Optional — Admin UI (Okta OIDC)

| Variable | Default | Description |
|----------|---------|-------------|
| `ADMIN_UI_NEXTAUTH_URL` | `http://localhost:3001` | NextAuth callback base URL |
| `ADMIN_UI_OKTA_DOMAIN` | _(empty)_ | Okta domain for Admin UI OIDC login |
| `ADMIN_UI_OKTA_CLIENT_ID` | _(empty)_ | Okta OIDC client ID for Admin UI |
| `ADMIN_UI_OKTA_CLIENT_SECRET` | _(empty)_ | Okta OIDC client secret for Admin UI |

### Optional — Observability

| Variable | Default | Description |
|----------|---------|-------------|
| `GF_SECURITY_ADMIN_PASSWORD` | `admin` | Grafana admin password |

### Optional — Deployment

| Variable | Default | Description |
|----------|---------|-------------|
| `DEPLOYMENT_MODE` | `standalone` | Deployment profile (see [Deployment Profiles](#deployment-profiles)) |

---

## Operational Commands

```bash
# Start the stack
docker compose -f docker-compose.bundle.yml up -d

# Start with observability (Grafana + Loki)
docker compose -f docker-compose.bundle.yml --profile observability up -d

# Stop the stack (preserves data)
docker compose -f docker-compose.bundle.yml down

# View status dashboard
./status.sh

# Status as JSON (for monitoring integration)
./status.sh --json

# View gateway logs
docker compose -f docker-compose.bundle.yml logs -f okta-agent-mcp-adapter

# View all logs
docker compose -f docker-compose.bundle.yml logs -f

# Restart a specific service
docker compose -f docker-compose.bundle.yml restart okta-agent-mcp-adapter

# View resource usage
docker stats

# Uninstall (removes data)
./uninstall.sh

# Full cleanup (data + images + config)
./uninstall.sh --remove-images --remove-config
```

---

## Connecting AI Coding Assistants

### Claude Code

```bash
claude mcp add okta-gateway \
  --transport http \
  --url http://localhost:8000
```

The gateway supports Dynamic Client Registration (DCR) — Claude Code will automatically register itself on first connection. If you need to provide credentials manually:

```bash
# Set client secret via env var to avoid shell escaping issues
export MCP_CLIENT_SECRET="your-client-secret"
claude mcp add okta-gateway \
  --transport http \
  --url http://localhost:8000 \
  --client-id "your-client-id" \
  --client-secret env:MCP_CLIENT_SECRET
```

Verify the connection:

```bash
claude mcp get okta-gateway
```

### Cursor

Add to `.cursor/mcp.json` in your project root:

```json
{
  "mcpServers": {
    "okta-gateway": {
      "url": "http://localhost:8000",
      "transport": "http"
    }
  }
}
```

### GitHub Copilot (VS Code)

Add to `.vscode/mcp.json` in your project root:

```json
{
  "servers": {
    "okta-gateway": {
      "type": "http",
      "url": "http://localhost:8000"
    }
  }
}
```

### Verifying Tools

After connecting, ask your AI assistant to list available tools. You should see namespaced tools from each backend the agent has access to (e.g., `hr-system__get_employee`, `hr-system__search_employees`).

If you see 0 tools:
1. Check the agent's `backend_access` list in the Admin UI
2. Verify backends are reachable: `./status.sh`
3. Enable debug logging: set `LOG_LEVEL=DEBUG` in `.env` and restart

---

## Deployment Profiles

### Standalone (Default)

All services run on a single host. Best for demos, POCs, and small teams.

```
┌─────────────────────────────────────┐
│            Single Host              │
│  ┌─────────┐  ┌────────┐  ┌─────┐  │
│  │ Gateway  │  │Admin UI│  │Redis│  │
│  │  :8000   │  │ :3001  │  │:6379│  │
│  └────┬─────┘  └────────┘  └─────┘  │
│       │  ┌──────────┐  ┌─────────┐  │
│       └─►│PostgreSQL│  │HR Server│  │
│          │  :5432   │  │  :8001  │  │
│          └──────────┘  └─────────┘  │
└─────────────────────────────────────┘
```

### Edge Proxy

Gateway sits behind a reverse proxy (nginx, Traefik, Caddy) that handles TLS termination and load balancing. Set `GATEWAY_BASE_URL` to the external URL.

```
              ┌───────────┐
  Internet ──►│  nginx /  │
              │ Traefik   │
              │  :443     │
              └─────┬─────┘
                    │
┌───────────────────┼─────────────────┐
│                   ▼                 │
│  ┌──────────┐  ┌────────┐          │
│  │ Gateway  │  │Admin UI│  + DB/   │
│  │  :8000   │  │ :3001  │  Cache   │
│  └──────────┘  └────────┘          │
└─────────────────────────────────────┘
```

### Split Auth

Authentication is handled by an external Okta integration (e.g., Okta Access Gateway). The adapter trusts pre-validated tokens and focuses on routing, authorization, and token exchange.

```
  ┌──────────┐     ┌──────────────┐     ┌──────────┐
  │  Client  ├────►│ Okta Access  ├────►│ Gateway  │
  │          │     │   Gateway    │     │  :8000   │
  └──────────┘     └──────────────┘     └────┬─────┘
                                             │
                                        ┌────┴─────┐
                                        │ Backends │
                                        └──────────┘
```

### Sidecar

Gateway runs as a sidecar container alongside your application. Useful for Kubernetes pods or when adding MCP support to an existing service.

```
┌──────────────────────────────┐
│         Pod / Host           │
│  ┌──────────┐  ┌──────────┐ │
│  │ Your App │  │ Gateway  │ │
│  │          ├─►│ (sidecar)│ │
│  │          │  │ :8000    │ │
│  └──────────┘  └────┬─────┘ │
└──────────────────────┼───────┘
                       │
                  ┌────┴─────┐
                  │ Backends │
                  └──────────┘
```

---

## Troubleshooting

### "Agent not found" error

- Verify the `X-MCP-Agent` header matches an agent ID in the Admin UI
- Check the agent is enabled: Admin UI → Agents → toggle switch
- If using DCR, the agent may not have been auto-provisioned — check `DCR_AUTO_ENABLE_AGENT=true`

### "Authorization denied" error

- Check the backend name is in the agent's `backend_access` list
- Open Admin UI → Agents → edit the agent → verify backend access

### JWT validation fails

- Verify `OKTA_DOMAIN` matches the token issuer
- Run `./status.sh` to verify the gateway is healthy
- Enable `LOG_LEVEL=DEBUG` in `.env` and restart to see JWKS cache behavior

### Token exchange fails

- Verify the agent's `private_key` is valid JWK format
- Check `target_authorization_server` in the backend config is correct
- Verify the agent's Okta OAuth app has the token exchange grant enabled

### Claude Code "Connection failed" or "No client info found"

- The gateway supports DCR — clients self-register at `/.well-known/oauth/registration`
- Alternatively, provide credentials: `claude mcp add --client-id <id> --client-secret env:MCP_CLIENT_SECRET`
- Verify with: `claude mcp get okta-gateway`

### Claude Code shows 0 tools after connecting

- Check the agent's `backend_access` list includes at least one backend
- Verify backends are reachable: `./status.sh`
- Ensure backend MCP servers are running: check container health in `./status.sh`
- Enable `LOG_LEVEL=DEBUG` and look for tool discovery logs

### Admin UI won't load

- Check container is running: `docker ps | grep admin-ui`
- Check logs: `docker logs okta-mcp-admin-ui`
- Verify port 3001 is not in use by another process

### Database connection errors

- Check PostgreSQL is healthy: `docker exec okta-mcp-postgres pg_isready`
- Verify `POSTGRES_PASSWORD` in `.env` matches what was used during initial setup
- Check logs: `docker logs okta-mcp-postgres`

### Services fail to start after upgrade

- Ensure the new bundle version is compatible with existing data
- Try: `docker compose -f docker-compose.bundle.yml down` then `./install.sh --force`
- If schema changed, the gateway runs Alembic migrations automatically on startup

### Port conflicts

- Check which process is using the port: `lsof -i :8000`
- Modify ports in `.env`: `GATEWAY_PORT`, `ADMIN_UI_PORT`, `POSTGRES_PORT`, `REDIS_PORT`
- Restart: `docker compose -f docker-compose.bundle.yml up -d`

---

## Upgrading

### Standard Upgrade

Data persists across upgrades — PostgreSQL and Redis volumes are preserved.

```bash
# 1. Stop the current stack
docker compose -f docker-compose.bundle.yml down

# 2. Extract the new bundle (in a new directory)
tar xzf okta-mcp-adapter-bundle-NEW_VERSION.tar.gz
cd okta-mcp-adapter-bundle-NEW_VERSION

# 3. Copy your existing .env
cp /path/to/old-bundle/.env .

# 4. Run the installer (--force skips the .env prompt)
./install.sh --force \
  --okta-domain YOUR.okta.com

# 5. Verify
./status.sh
```

### What's Preserved

- **PostgreSQL data** (agent configs, backend configs, DCR registrations, audit logs) — stored in a Docker named volume
- **Redis cache** — stored in a Docker named volume (cache rebuilds automatically if lost)
- **`.env` configuration** — copy from old bundle to new bundle

### What's Replaced

- Docker images (new versions loaded from bundle)
- Scripts (`install.sh`, `status.sh`, etc.)
- Docker Compose definition

### Database Migrations

The gateway automatically runs Alembic database migrations on startup. No manual migration steps are needed. If a migration fails, check the gateway logs:

```bash
docker logs okta-agent-mcp-adapter
```

---

## Security Notes

- The gateway container runs with security hardening: `read_only` filesystem, `no-new-privileges`, all capabilities dropped
- Credentials in PostgreSQL are encrypted with AES-256-GCM using the `ENCRYPTION_KEY`
- Never share the `.env` file — it contains all secrets
- Admin API authentication is delegated to Okta. Rotate the Admin UI OIDC
  client secret in Okta and update `ADMIN_UI_OKTA_CLIENT_SECRET` in `.env`
- For production, place the gateway behind a TLS-terminating reverse proxy (see Edge Proxy profile)

---

## Support

This is an unofficial prototype for evaluation purposes. For issues:
- Check the troubleshooting section above
- Run `./status.sh --json` and include the output when reporting problems
- Review gateway logs: `docker compose -f docker-compose.bundle.yml logs okta-agent-mcp-adapter`
