-- Migration: 002 — DCR agent selection
-- Author: joe-witt_atko <joe.witt@okta.com>
-- Source: alembic/versions/002_dcr_agent_selection.py
-- Applied to: schema_migrations table on success
--
-- Adds columns for the DCR agent selection feature:
--   agents.dcr_selectable              — mark agents available for DCR selection
--   dcr_registrations.linked_agent_name — FK to agents for credential inheritance

ALTER TABLE agents
    ADD COLUMN dcr_selectable BOOLEAN DEFAULT FALSE;

ALTER TABLE dcr_registrations
    ADD COLUMN linked_agent_name VARCHAR(255);

ALTER TABLE dcr_registrations
    ADD CONSTRAINT fk_dcr_registrations_linked_agent
        FOREIGN KEY (linked_agent_name) REFERENCES agents (agent_name)
        ON DELETE SET NULL;
