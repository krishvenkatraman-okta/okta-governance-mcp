# Database Bootstrap

The Okta MCP Adapter does not create database schema at runtime. A DBA (or
CI/CD pipeline) provisions the database, creates two least-privilege roles,
and applies migrations before the adapter starts. The adapter itself runs
with DML privileges only and fails fast if the schema is not at the
expected version.

This directory contains the SQL the operator needs:

| File                               | Purpose                              |
|------------------------------------|--------------------------------------|
| `bootstrap_roles.sql`              | Creates the two roles, one-time per DB |
| `000__bootstrap.up.sql`            | Creates the `schema_migrations` tracking table (applied automatically by the runner) |
| `NNN__<slug>.up.sql`               | Forward migration — applied by `okta-adapter-migrate upgrade` |
| `NNN__<slug>.down.sql`             | Reverse migration — for operator rollback, not invoked by the runner |

## One-time setup (run as DBA / superuser)

1. Create the database:

   ```bash
   createdb gateway_db
   ```

2. Create the two roles and grant privileges:

   ```bash
   DB_OWNER_ROLE=okta_adapter_owner \
   DB_APP_ROLE=okta_adapter_app \
   DB_NAME=gateway_db \
   psql -d gateway_db -f deploy/migrations/sql/bootstrap_roles.sql
   ```

   The script is idempotent — running it twice is a no-op.

3. Set passwords (skip if using AWS RDS IAM / Azure Entra / Vault — see
   `docs/OPERATIONS.md` for those paths):

   ```sql
   ALTER ROLE okta_adapter_owner PASSWORD '<rotate-me>';
   ALTER ROLE okta_adapter_app   PASSWORD '<rotate-me>';
   ```

## Per-deployment (run by CI/CD or DBA)

Apply pending migrations using the **owner** role:

```bash
DATABASE_URL=postgresql://okta_adapter_owner:<pwd>@host/gateway_db?sslmode=require \
  python -m okta_agent_proxy.storage.migrate upgrade
```

## Runtime

The adapter container runs as the **app** role only:

```bash
DATABASE_URL=postgresql://okta_adapter_app:<pwd>@host/gateway_db?sslmode=require
```

The adapter refuses to create or modify schema. If the app role is granted
DDL by accident, that is a misconfiguration — revoke it. The adapter also
logs a warning at startup when the configured DB user looks like the owner
role, so operators notice a drift quickly.

## Role model summary

| Role                  | Used by               | Privileges                         |
|-----------------------|-----------------------|------------------------------------|
| `okta_adapter_owner`  | Migration runner (CI) | Full DDL on `gateway_db`           |
| `okta_adapter_app`    | Adapter runtime       | `SELECT, INSERT, UPDATE, DELETE` only; no `CREATE` on `public` schema |

`ALTER DEFAULT PRIVILEGES` is used so every table created by the owner is
automatically readable and writable by the app role — migrations do not
need to grant table privileges manually.
