-- Migration: 001 — initial schema (DOWN)
-- Author: joe-witt_atko <joe.witt@okta.com>
-- Source: alembic/versions/001_initial_schema.py (downgrade)

-- Drop triggers
DROP TRIGGER IF EXISTS update_gateway_config_updated_at ON gateway_config;
DROP TRIGGER IF EXISTS update_resources_updated_at ON resources;
DROP TRIGGER IF EXISTS update_agents_updated_at ON agents;
DROP FUNCTION IF EXISTS update_updated_at_column();

-- Drop FK that cross-references agents → dcr_registrations so tables can be dropped.
ALTER TABLE IF EXISTS agents DROP CONSTRAINT IF EXISTS fk_agents_dcr_registration;

-- Drop tables in reverse dependency order.
DROP TABLE IF EXISTS encryption_keys;
DROP TABLE IF EXISTS gateway_config;
DROP TABLE IF EXISTS cimd_cache;
DROP TABLE IF EXISTS dcr_registrations;
DROP TABLE IF EXISTS okta_sync_state;
DROP TABLE IF EXISTS audit_log;
DROP TABLE IF EXISTS resources;
DROP TABLE IF EXISTS agents;
