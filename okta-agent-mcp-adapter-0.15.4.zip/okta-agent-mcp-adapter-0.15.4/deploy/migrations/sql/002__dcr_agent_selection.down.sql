-- Migration: 002 — DCR agent selection (DOWN)
-- Author: joe-witt_atko <joe.witt@okta.com>
-- Source: alembic/versions/002_dcr_agent_selection.py (downgrade)

ALTER TABLE dcr_registrations
    DROP CONSTRAINT IF EXISTS fk_dcr_registrations_linked_agent;

ALTER TABLE dcr_registrations
    DROP COLUMN IF EXISTS linked_agent_name;

ALTER TABLE agents
    DROP COLUMN IF EXISTS dcr_selectable;
