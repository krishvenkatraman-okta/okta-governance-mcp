-- ===========================================================================
-- Two-role bootstrap for the Okta MCP Adapter database.
--
-- Run this ONCE as a Postgres superuser (typically rds_superuser on AWS,
-- or the postgres role on a self-hosted cluster) BEFORE running migrations.
--
-- Customize the role names if your shop uses different naming conventions —
-- the adapter reads DB_OWNER_ROLE and DB_APP_ROLE env vars.
--
-- Invocation:
--     DB_OWNER_ROLE=okta_adapter_owner \
--     DB_APP_ROLE=okta_adapter_app \
--     DB_NAME=gateway_db \
--     psql -d gateway_db -f deploy/migrations/sql/bootstrap_roles.sql
--
-- The script is idempotent — running it twice is a no-op.
-- ===========================================================================

\set ON_ERROR_STOP on

-- Configurable identifiers. Override via environment before calling psql.
-- psql expands `...` as a shell command; the ${VAR:-default} fallback lets
-- the file run without any env vars set.
\set owner_role  `echo "${DB_OWNER_ROLE:-okta_adapter_owner}"`
\set app_role    `echo "${DB_APP_ROLE:-okta_adapter_app}"`
\set db_name     `echo "${DB_NAME:-gateway_db}"`

-- psql variable substitution does not cross dollar-quoted strings, so we stash
-- the role names in session-level GUCs and read them from the DO blocks via
-- current_setting(). The custom class name "okta_adapter" avoids the
-- reserved-class check Postgres applies to unqualified GUCs.
SET okta_adapter.owner_role = :'owner_role';
SET okta_adapter.app_role   = :'app_role';

-- Role 1: schema owner. Used ONLY by the migration runner.
-- Has DDL on the database; should not be used by the running application.
DO $$
DECLARE
    v_role text := current_setting('okta_adapter.owner_role');
BEGIN
    IF NOT EXISTS (SELECT FROM pg_roles WHERE rolname = v_role) THEN
        EXECUTE format('CREATE ROLE %I LOGIN', v_role);
    END IF;
END $$;

-- Role 2: application runtime. DML only, no DDL.
DO $$
DECLARE
    v_role text := current_setting('okta_adapter.app_role');
BEGIN
    IF NOT EXISTS (SELECT FROM pg_roles WHERE rolname = v_role) THEN
        EXECUTE format('CREATE ROLE %I LOGIN', v_role);
    END IF;
END $$;

-- Grant owner_role membership to the bootstrap session. ALTER DEFAULT
-- PRIVILEGES FOR ROLE X (below) requires the session user to be a member
-- of X. On AWS RDS the master is rds_superuser (not a true superuser) and
-- CREATE ROLE does not auto-enroll the creator, so we grant explicitly.
-- Idempotent: GRANT role TO user is a no-op when membership already exists.
DO $$
DECLARE
    v_role text := current_setting('okta_adapter.owner_role');
BEGIN
    EXECUTE format('GRANT %I TO CURRENT_USER', v_role);
END $$;

-- Owner gets full DDL on the database.
GRANT ALL PRIVILEGES ON DATABASE :"db_name" TO :"owner_role";

-- Postgres 15+ revokes CREATE on schema public from PUBLIC by default, so the
-- owner role needs it granted explicitly to run migrations.
GRANT USAGE, CREATE ON SCHEMA public TO :"owner_role";

-- App role: connect to the DB and use the public schema.
GRANT CONNECT ON DATABASE :"db_name" TO :"app_role";
GRANT USAGE ON SCHEMA public TO :"app_role";

-- Default privileges: any future tables created by the owner are auto-granted
-- to app.
ALTER DEFAULT PRIVILEGES FOR ROLE :"owner_role" IN SCHEMA public
    GRANT SELECT, INSERT, UPDATE, DELETE ON TABLES TO :"app_role";
ALTER DEFAULT PRIVILEGES FOR ROLE :"owner_role" IN SCHEMA public
    GRANT USAGE, SELECT ON SEQUENCES TO :"app_role";

-- Idempotent grant for any existing tables (in case migrations have already
-- run before this bootstrap script — order doesn't matter).
GRANT SELECT, INSERT, UPDATE, DELETE ON ALL TABLES    IN SCHEMA public TO :"app_role";
GRANT USAGE, SELECT                 ON ALL SEQUENCES IN SCHEMA public TO :"app_role";

-- App role explicitly does NOT get CREATE on the schema. This is the control
-- that forces DDL to go through the migration runner under the owner role.
REVOKE CREATE ON SCHEMA public FROM :"app_role";

-- AWS RDS IAM DB authentication: a role only accepts IAM auth tokens after
-- it has been granted the rds_iam role. Without this grant, RDS falls back
-- to password auth and the server returns "password authentication failed"
-- even when an IAM token is presented. The rds_iam role only exists on
-- RDS/Aurora, so we gate the grant on its presence — self-hosted Postgres
-- and Azure PG skip this block cleanly.
DO $$
DECLARE
    v_owner text := current_setting('okta_adapter.owner_role');
    v_app   text := current_setting('okta_adapter.app_role');
BEGIN
    IF EXISTS (SELECT FROM pg_roles WHERE rolname = 'rds_iam') THEN
        EXECUTE format('GRANT rds_iam TO %I', v_owner);
        EXECUTE format('GRANT rds_iam TO %I', v_app);
    END IF;
END $$;

\echo 'Bootstrap complete.'
\echo 'Owner role:' :owner_role
\echo 'App role:  ' :app_role
