-- Migration: 000 — bootstrap (schema_migrations tracking table)
-- Author: joe-witt_atko <joe.witt@okta.com>
-- Source: DB migration prompt P03
-- Applied automatically by the migration runner before any user migration.
--
-- The migration runner itself never drops this table. There is intentionally
-- no 000__bootstrap.down.sql.

CREATE TABLE IF NOT EXISTS schema_migrations (
    version          VARCHAR(16) PRIMARY KEY,
    applied_at       TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    applied_by       VARCHAR(255),
    checksum         VARCHAR(64) NOT NULL,
    execution_ms     INTEGER NOT NULL DEFAULT 0
);

CREATE INDEX IF NOT EXISTS idx_schema_migrations_applied_at
    ON schema_migrations(applied_at);
