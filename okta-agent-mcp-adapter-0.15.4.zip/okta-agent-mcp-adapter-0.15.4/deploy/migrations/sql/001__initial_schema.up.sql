-- Migration: 001 — initial schema
-- Author: joe-witt_atko <joe.witt@okta.com>
-- Source: alembic/versions/001_initial_schema.py
-- Applied to: schema_migrations table on success
--
-- Consolidated schema for Okta Agent MCP Adapter v0.11.0.
-- All deprecated tables and backward-compat columns removed.
--
-- Tables: agents, resources, audit_log, okta_sync_state, dcr_registrations,
--         cimd_cache, gateway_config, encryption_keys

-- ===========================================================================
-- AGENTS
-- ===========================================================================
CREATE TABLE agents (
    agent_name                VARCHAR(255) NOT NULL,
    agent_id                  VARCHAR(255) NOT NULL,
    client_id                 VARCHAR(255) NOT NULL,

    -- Encrypted credentials (AES-256-GCM)
    client_secret_encrypted   BYTEA,
    client_secret_iv          BYTEA,
    client_secret_tag         BYTEA,

    -- Encrypted private key for JWT signing (nullable — not all agents need it)
    private_key_encrypted     BYTEA,
    private_key_iv            BYTEA,
    private_key_tag           BYTEA,

    -- Configuration
    scopes                    TEXT NOT NULL DEFAULT '[]',
    enabled                   BOOLEAN NOT NULL DEFAULT TRUE,

    -- Registration provenance
    registration_source       VARCHAR(20) DEFAULT 'manual',
    dcr_registration_id       VARCHAR(36),
    cimd_client_id_url        TEXT,
    okta_ai_agent_id          VARCHAR(255),

    -- Okta AI Agent principal ID (issuer/subject in JWT bearer claims)
    principal_id              VARCHAR(255),

    -- Audit
    created_by                VARCHAR(255),
    created_at                TIMESTAMP NOT NULL DEFAULT NOW(),
    updated_by                VARCHAR(255),
    updated_at                TIMESTAMP NOT NULL DEFAULT NOW(),

    CONSTRAINT pk_agents PRIMARY KEY (agent_name),
    CONSTRAINT uq_agents_agent_id UNIQUE (agent_id),
    CONSTRAINT uq_agents_client_id UNIQUE (client_id)
);

CREATE INDEX idx_agents_agent_id ON agents (agent_id);
CREATE INDEX idx_agents_client_id ON agents (client_id);
CREATE INDEX idx_agents_enabled ON agents (enabled) WHERE enabled = TRUE;
CREATE UNIQUE INDEX idx_agents_cimd_client_id_url ON agents (cimd_client_id_url);
CREATE INDEX ix_agents_principal_id ON agents (principal_id);

-- ===========================================================================
-- RESOURCES
-- ===========================================================================
-- Collapsed resources table: one row per (agent, Okta Managed Connection).
-- Resources come into being via Okta sync (or admin import + sync); there is
-- no standalone-create path. Admins edit routing/lifecycle fields (url,
-- slug, enabled); sync owns connection_type/scopes/scope_condition.
CREATE TABLE resources (
    id                        SERIAL NOT NULL,

    -- Provenance (required; set by syncer, never edited by admin)
    agent_id                  VARCHAR(255) NOT NULL,
    connection_id             VARCHAR(255) NOT NULL,

    -- Admin-editable routing metadata
    name                      VARCHAR(255) NOT NULL,
    type                      VARCHAR(20) NOT NULL DEFAULT 'mcp',
    url                       VARCHAR(2048) NOT NULL DEFAULT '',
    description               TEXT NOT NULL DEFAULT '',

    -- Per-connection sync state (materialized from Okta; never edited by admin)
    connection_type           VARCHAR(50) NOT NULL,
    connection_resource_id    VARCHAR(255),
    scopes                    JSONB NOT NULL DEFAULT '[]'::jsonb,
    scope_condition           VARCHAR(50) NOT NULL DEFAULT 'ALLOW_ALL',
    auth_method               VARCHAR(50),
    metadata                  JSONB NOT NULL DEFAULT '{}'::jsonb,

    -- Admin-editable routing / auth config
    config                    JSONB NOT NULL DEFAULT '{}'::jsonb,
    tags                      JSONB NOT NULL DEFAULT '[]'::jsonb,
    paths                     TEXT NOT NULL DEFAULT '[]',
    auth_config               TEXT NOT NULL DEFAULT '{}',
    timeout_seconds           INTEGER DEFAULT 30,

    -- Lifecycle (sync creates disabled; admin sets url + flips to enabled)
    enabled                   BOOLEAN NOT NULL DEFAULT FALSE,
    created_by                VARCHAR(255),
    created_at                TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_by                VARCHAR(255),
    updated_at                TIMESTAMPTZ NOT NULL DEFAULT NOW(),

    CONSTRAINT pk_resources PRIMARY KEY (id),
    CONSTRAINT uq_resources_agent_connection UNIQUE (agent_id, connection_id),
    CONSTRAINT fk_resources_agent
        FOREIGN KEY (agent_id) REFERENCES agents (agent_id) ON DELETE CASCADE
);

CREATE UNIQUE INDEX ix_resources_name ON resources (name);
CREATE INDEX idx_resources_agent_id ON resources (agent_id);
CREATE INDEX idx_resources_connection_id ON resources (connection_id);
CREATE INDEX idx_resources_connection_resource_id ON resources (connection_resource_id);
CREATE INDEX idx_resources_auth_method ON resources (auth_method);

-- ===========================================================================
-- AUDIT LOG
-- ===========================================================================
CREATE TABLE audit_log (
    id            VARCHAR(36) NOT NULL,
    entity_type   VARCHAR(50) NOT NULL,
    entity_id     VARCHAR(255) NOT NULL,
    action        VARCHAR(50) NOT NULL,
    changes       TEXT,
    changed_by    VARCHAR(255) NOT NULL,
    changed_at    TIMESTAMP NOT NULL DEFAULT NOW(),
    ip_address    VARCHAR(45),
    user_agent    TEXT,

    CONSTRAINT pk_audit_log PRIMARY KEY (id)
);

CREATE INDEX idx_audit_log_entity_type ON audit_log (entity_type);
CREATE INDEX idx_audit_log_entity_id ON audit_log (entity_id);
CREATE INDEX idx_audit_log_entity ON audit_log (entity_type, entity_id);
CREATE INDEX idx_audit_log_changed_by ON audit_log (changed_by);
CREATE INDEX idx_audit_log_changed_at ON audit_log (changed_at);

-- ===========================================================================
-- OKTA SYNC STATE
-- ===========================================================================
CREATE TABLE okta_sync_state (
    id                 SERIAL NOT NULL,
    last_sync_at       TIMESTAMPTZ,
    status             VARCHAR(20) NOT NULL DEFAULT 'never',
    resources_count    INTEGER DEFAULT 0,
    unresolved_count   INTEGER DEFAULT 0,
    sync_duration_ms   INTEGER DEFAULT 0,
    created_at         TIMESTAMPTZ DEFAULT NOW(),

    CONSTRAINT pk_okta_sync_state PRIMARY KEY (id)
);

-- ===========================================================================
-- DCR REGISTRATIONS
-- ===========================================================================
CREATE TABLE dcr_registrations (
    id                  VARCHAR(36) NOT NULL,
    client_id           VARCHAR(255) NOT NULL,
    client_name         VARCHAR(255) NOT NULL,
    agent_name          VARCHAR(255),
    okta_app_id         VARCHAR(255),
    okta_ai_agent_id    VARCHAR(255),
    redirect_uris       TEXT NOT NULL,
    grant_types         TEXT NOT NULL,
    provision_mode      VARCHAR(20) NOT NULL,
    source_ip           VARCHAR(45),
    status              VARCHAR(20) NOT NULL DEFAULT 'active',
    created_at          TIMESTAMP DEFAULT NOW(),
    revoked_at          TIMESTAMP,

    CONSTRAINT pk_dcr_registrations PRIMARY KEY (id),
    CONSTRAINT uq_dcr_registrations_client_id UNIQUE (client_id),
    CONSTRAINT fk_dcr_registrations_agent_name
        FOREIGN KEY (agent_name) REFERENCES agents (agent_name) ON DELETE SET NULL
);

CREATE UNIQUE INDEX idx_dcr_client_id ON dcr_registrations (client_id);
CREATE INDEX idx_dcr_status ON dcr_registrations (status);
CREATE INDEX idx_dcr_source_ip ON dcr_registrations (source_ip);
CREATE INDEX idx_dcr_created_at ON dcr_registrations (created_at);

-- Cross-reference: agents.dcr_registration_id → dcr_registrations.id
ALTER TABLE agents
    ADD CONSTRAINT fk_agents_dcr_registration
    FOREIGN KEY (dcr_registration_id) REFERENCES dcr_registrations (id)
    ON DELETE SET NULL;

-- ===========================================================================
-- CIMD CACHE
-- ===========================================================================
CREATE TABLE cimd_cache (
    client_id_url   TEXT NOT NULL,
    metadata_json   TEXT NOT NULL,
    domain          VARCHAR(255),
    trust_level     VARCHAR(20),
    fetched_at      TIMESTAMP NOT NULL,
    expires_at      TIMESTAMP,

    CONSTRAINT pk_cimd_cache PRIMARY KEY (client_id_url)
);

CREATE INDEX idx_cimd_domain ON cimd_cache (domain);
CREATE INDEX idx_cimd_expires ON cimd_cache (expires_at);

-- ===========================================================================
-- GATEWAY CONFIG
-- ===========================================================================
CREATE TABLE gateway_config (
    id             VARCHAR(36) NOT NULL,
    config_key     VARCHAR(255) NOT NULL,
    config_value   TEXT NOT NULL,
    description    TEXT,
    updated_by     VARCHAR(255),
    updated_at     TIMESTAMP NOT NULL DEFAULT NOW(),

    CONSTRAINT pk_gateway_config PRIMARY KEY (id),
    CONSTRAINT uq_gateway_config_key UNIQUE (config_key)
);

CREATE UNIQUE INDEX idx_gateway_config_key ON gateway_config (config_key);

-- ===========================================================================
-- ENCRYPTION KEY METADATA
-- ===========================================================================
CREATE TABLE encryption_keys (
    id               VARCHAR(36) NOT NULL,
    key_id           VARCHAR(255) NOT NULL,
    algorithm        VARCHAR(50) NOT NULL,
    created_at       TIMESTAMP NOT NULL DEFAULT NOW(),
    rotated_at       TIMESTAMP,
    is_active        BOOLEAN NOT NULL DEFAULT TRUE,
    kdf_algorithm    VARCHAR(50),
    kdf_iterations   INTEGER,

    CONSTRAINT pk_encryption_keys PRIMARY KEY (id),
    CONSTRAINT uq_encryption_keys_key_id UNIQUE (key_id)
);

CREATE UNIQUE INDEX idx_encryption_keys_active
    ON encryption_keys (is_active) WHERE is_active = TRUE;

-- ===========================================================================
-- TRIGGERS FOR AUTO-UPDATE timestamps
-- ===========================================================================
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$ LANGUAGE 'plpgsql';

CREATE TRIGGER update_agents_updated_at
    BEFORE UPDATE ON agents
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_resources_updated_at
    BEFORE UPDATE ON resources
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_gateway_config_updated_at
    BEFORE UPDATE ON gateway_config
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
