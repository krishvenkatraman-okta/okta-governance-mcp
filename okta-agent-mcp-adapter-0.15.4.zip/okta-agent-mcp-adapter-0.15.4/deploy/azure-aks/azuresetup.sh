#!/usr/bin/env bash
set -euo pipefail

# =============================================================
# azuresetup.sh — Okta MCP Adapter AKS Production Wizard
# =============================================================
# Interactive wizard that deploys the adapter on AKS Automatic
# with managed Postgres, managed Redis, and Application Gateway
# for Containers ingress.
#
# Phase 1: Foundation (RG, providers, ACR, VNet, AKS Automatic,
#          workload identity)
# Phase 2: Stateful tier (Postgres, Redis, Key Vault, secrets)
# Phase 3: Application + ingress (build, deploy, AGC)
# Phase 4: Smoke tests + Key Vault lockdown
# =============================================================

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
cd "$SCRIPT_DIR"

# Source shared libraries
source "$SCRIPT_DIR/shell-lib/common.sh"
source "$SCRIPT_DIR/shell-lib/azure-helpers.sh"

# Disable az cli paging so it never blocks on `less`
export AZURE_CORE_OUTPUT_NOWARN=1
export AZURE_CORE_NO_COLOR=false

# ---- Ctrl+C handler ----
cleanup() {
  echo ""
  warn "Interrupted. State saved to .azuresetup.state — rerun to resume."
  exit 130
}
trap cleanup INT TERM

# ---- Read version from pyproject.toml (single source of truth) ----
VERSION="dev"
if [[ -f "$SCRIPT_DIR/../../pyproject.toml" ]]; then
  VERSION="$(grep -m1 '^version' "$SCRIPT_DIR/../../pyproject.toml" | sed 's/.*= *"\(.*\)"/\1/')"
fi

# ---- Defaults ----
PHASE="all"
NON_INTERACTIVE=false
SKIP_BUILD=false

# ---- Parse flags ----
show_help() {
  cat <<'USAGE'
Usage: azuresetup.sh [OPTIONS]

Options:
  --phase PHASE          Run a specific phase: 1, 2, 3, 4, all (default: all)
  --subscription ID      Azure subscription ID (overrides current)
  --location REGION      Azure region (default: eastus2)
  --non-interactive      Use values from .env and .azuresetup.state, never prompt
  --skip-build           Skip docker image builds (use existing tags in ACR)
  --destroy              Delete the resource group and all resources
  -h, --help             Show this help

Phases:
  1  Foundation: RG, providers, ACR, VNet, AKS Automatic, workload identity
  2  Stateful tier: Postgres, Redis, Key Vault, secrets
  3  Application + ingress: build images, deploy K8s, AGC
  4  Smoke tests + Key Vault lockdown

Environment variables (or .env file):
  AZURE_SUBSCRIPTION_ID     Required
  AZURE_LOCATION            Default: eastus2
  AZURE_RG                  Default: okta-ps-adapter-prod
  OKTA_DOMAIN               Required for Phase 2
  ADAPTER_HOSTNAME          Required for Phase 3
  ADMIN_HOSTNAME            Required for Phase 3
USAGE
}

while [[ $# -gt 0 ]]; do
  case "$1" in
    --phase)             PHASE="$2"; shift 2 ;;
    --subscription)      export AZURE_SUBSCRIPTION_ID="$2"; shift 2 ;;
    --location)          export AZURE_LOCATION="$2"; shift 2 ;;
    --non-interactive)   NON_INTERACTIVE=true; shift ;;
    --skip-build)        SKIP_BUILD=true; shift ;;
    --destroy)           PHASE="destroy"; shift ;;
    -h|--help)           show_help; exit 0 ;;
    *) die "Unknown flag: $1 (use --help)" ;;
  esac
done

[[ "$PHASE" =~ ^(1|2|3|4|all|destroy)$ ]] || \
  die "--phase must be 1, 2, 3, 4, all, or destroy"

# ---- Load .env if present ----
if [[ -f "$SCRIPT_DIR/.env" ]]; then
  set -a
  # shellcheck disable=SC1091
  source "$SCRIPT_DIR/.env"
  set +a
fi

# ---- Load existing state if present ----
load_state

# ---- Banner helpers (match awsetup.sh style) ----
print_banner() {
  local title="$1"
  echo ""
  printf "${CYAN}┌──────────────────────────────────────────────────┐${NC}\n"
  printf "${CYAN}│${NC}  ${BOLD}%-48s${NC}${CYAN}│${NC}\n" "$title"
  printf "${CYAN}└──────────────────────────────────────────────────┘${NC}\n"
  echo ""
}

print_summary_box() {
  local title="$1"; shift
  echo ""
  printf "${GREEN}┌──────────────────────────────────────────────────┐${NC}\n"
  printf "${GREEN}│${NC}  ${BOLD}%-48s${NC}${GREEN}│${NC}\n" "$title"
  printf "${GREEN}├──────────────────────────────────────────────────┤${NC}\n"
  for line in "$@"; do
    printf "${GREEN}│${NC}  %-48s${GREEN}│${NC}\n" "$line"
  done
  printf "${GREEN}└──────────────────────────────────────────────────┘${NC}\n"
  echo ""
}

# ================================================================
# Phase 1: Foundation
# ================================================================

run_phase_1() {
  print_banner "Phase 1: Foundation"

  # Step 1.1: Validate prerequisites
  info "Step 1.1: Validating prerequisites..."
  validate_command az "Install: https://learn.microsoft.com/cli/azure/install-azure-cli"
  validate_command jq
  validate_command python3
  validate_command openssl
  validate_command kubectl "Install: https://kubernetes.io/docs/tasks/tools/"
  validate_command helm "Install: https://helm.sh/docs/intro/install/"
  az_login_check
  ok "Prerequisites OK"

  # Step 1.2: Resolve subscription, region, RG, ACR name
  info "Step 1.2: Resolving Azure subscription and region..."

  if [[ -z "${AZURE_SUBSCRIPTION_ID:-}" ]]; then
    AZURE_SUBSCRIPTION_ID="$(get_state AZURE_SUBSCRIPTION_ID)"
  fi
  if [[ -z "$AZURE_SUBSCRIPTION_ID" ]]; then
    if $NON_INTERACTIVE; then
      die "AZURE_SUBSCRIPTION_ID not set in env, .env, or state file"
    fi
    local current_sub
    current_sub="$(az account show --query id -o tsv 2>/dev/null || true)"
    prompt_default AZURE_SUBSCRIPTION_ID "Azure subscription ID" "$current_sub"
  fi
  az account set --subscription "$AZURE_SUBSCRIPTION_ID"
  save_state AZURE_SUBSCRIPTION_ID "$AZURE_SUBSCRIPTION_ID"

  AZURE_LOCATION="${AZURE_LOCATION:-$(get_state AZURE_LOCATION)}"
  AZURE_LOCATION="${AZURE_LOCATION:-eastus2}"
  if ! $NON_INTERACTIVE && [[ -z "$(get_state AZURE_LOCATION)" ]]; then
    prompt_default AZURE_LOCATION "Azure region" "$AZURE_LOCATION"
  fi
  save_state AZURE_LOCATION "$AZURE_LOCATION"

  AZURE_RG="${AZURE_RG:-$(get_state AZURE_RG)}"
  AZURE_RG="${AZURE_RG:-okta-ps-adapter-prod}"
  save_state AZURE_RG "$AZURE_RG"

  AZURE_ACR_NAME="${AZURE_ACR_NAME:-$(get_state AZURE_ACR_NAME)}"
  if [[ -z "$AZURE_ACR_NAME" ]]; then
    AZURE_ACR_NAME="oktapsadapterprod$(random_suffix 4)"
  fi
  save_state AZURE_ACR_NAME "$AZURE_ACR_NAME"

  TENANT_ID="$(az account show --query tenantId -o tsv)"
  save_state TENANT_ID "$TENANT_ID"

  ok "Subscription: $AZURE_SUBSCRIPTION_ID"
  ok "Region:       $AZURE_LOCATION"
  ok "Resource group: $AZURE_RG"
  ok "ACR name:     $AZURE_ACR_NAME"

  # Step 1.3: Register providers
  info "Step 1.3: Registering required Azure providers..."
  for provider in \
    Microsoft.ContainerService \
    Microsoft.ContainerRegistry \
    Microsoft.DBforPostgreSQL \
    Microsoft.Cache \
    Microsoft.KeyVault \
    Microsoft.OperationalInsights \
    Microsoft.Network \
    Microsoft.ServiceNetworking \
    Microsoft.ManagedIdentity ; do
    az_provider_register "$provider"
  done
  ok "All providers registered"

  # Step 1.4: Create resource group
  info "Step 1.4: Creating resource group..."
  if az group show -n "$AZURE_RG" &>/dev/null; then
    ok "Resource group $AZURE_RG already exists"
  else
    az group create -n "$AZURE_RG" -l "$AZURE_LOCATION" --output none
    ok "Resource group created"
  fi

  # Step 1.5: Create Azure Container Registry
  info "Step 1.5: Creating Azure Container Registry..."
  if az acr show -n "$AZURE_ACR_NAME" &>/dev/null; then
    ok "ACR $AZURE_ACR_NAME already exists"
  else
    az acr create -g "$AZURE_RG" -n "$AZURE_ACR_NAME" \
      --sku Standard --admin-enabled false --output none
    ok "ACR created"
  fi
  ACR_LOGIN_SERVER="$(az acr show -n "$AZURE_ACR_NAME" --query loginServer -o tsv)"
  save_state ACR_LOGIN_SERVER "$ACR_LOGIN_SERVER"

  # Step 1.6: Create VNet and subnets
  info "Step 1.6: Creating VNet and subnets..."
  VNET_NAME="okta-ps-adapter-vnet"
  if az network vnet show -g "$AZURE_RG" -n "$VNET_NAME" &>/dev/null; then
    ok "VNet $VNET_NAME already exists"
  else
    az network vnet create -g "$AZURE_RG" -n "$VNET_NAME" \
      -l "$AZURE_LOCATION" --address-prefix 10.50.0.0/16 \
      --output none
    ok "VNet created"
  fi

  for subnet_def in \
    "aks-subnet:10.50.0.0/20:" \
    "pe-subnet:10.50.16.0/24:" \
    "agc-subnet:10.50.17.0/24:Microsoft.ServiceNetworking/trafficControllers" ; do
    local name="${subnet_def%%:*}"
    local rest="${subnet_def#*:}"
    local cidr="${rest%%:*}"
    local delegation="${rest##*:}"

    if az network vnet subnet show -g "$AZURE_RG" --vnet-name "$VNET_NAME" \
         -n "$name" &>/dev/null; then
      ok "Subnet $name already exists"
    else
      local args=( -g "$AZURE_RG" --vnet-name "$VNET_NAME" -n "$name" \
                   --address-prefix "$cidr" --output none )
      [[ -n "$delegation" ]] && args+=( --delegations "$delegation" )
      az network vnet subnet create "${args[@]}"
      ok "Subnet $name created ($cidr)"
    fi
  done

  AKS_SUBNET_ID="$(az network vnet subnet show -g "$AZURE_RG" \
    --vnet-name "$VNET_NAME" -n aks-subnet --query id -o tsv)"
  PE_SUBNET_ID="$(az network vnet subnet show -g "$AZURE_RG" \
    --vnet-name "$VNET_NAME" -n pe-subnet --query id -o tsv)"
  AGC_SUBNET_ID="$(az network vnet subnet show -g "$AZURE_RG" \
    --vnet-name "$VNET_NAME" -n agc-subnet --query id -o tsv)"
  save_state AKS_SUBNET_ID "$AKS_SUBNET_ID"
  save_state PE_SUBNET_ID "$PE_SUBNET_ID"
  save_state AGC_SUBNET_ID "$AGC_SUBNET_ID"

  # Disable PE network policies on pe-subnet so private endpoints work
  az network vnet subnet update -g "$AZURE_RG" --vnet-name "$VNET_NAME" \
    -n pe-subnet --disable-private-endpoint-network-policies true \
    --output none

  # Step 1.7: Create private DNS zones
  info "Step 1.7: Creating private DNS zones and VNet links..."
  for zone in \
    privatelink.postgres.database.azure.com \
    privatelink.redis.cache.windows.net \
    privatelink.vaultcore.azure.net ; do
    if az network private-dns zone show -g "$AZURE_RG" -n "$zone" &>/dev/null; then
      ok "DNS zone $zone already exists"
    else
      az network private-dns zone create -g "$AZURE_RG" -n "$zone" --output none
      ok "DNS zone $zone created"
    fi
    local link_name="${zone//./-}-link"
    if az network private-dns link vnet show -g "$AZURE_RG" \
         -n "$link_name" -z "$zone" &>/dev/null; then
      ok "VNet link for $zone already exists"
    else
      az network private-dns link vnet create -g "$AZURE_RG" \
        -n "$link_name" -z "$zone" -v "$VNET_NAME" \
        --registration-enabled false --output none
      ok "VNet link for $zone created"
    fi
  done

  # Step 1.8: Create AKS Automatic cluster
  info "Step 1.8: Creating AKS Automatic cluster (5-8 min)..."
  AKS_NAME="okta-ps-adapter-aks"
  if az aks show -g "$AZURE_RG" -n "$AKS_NAME" &>/dev/null; then
    ok "AKS cluster $AKS_NAME already exists"
  else
    az aks create -g "$AZURE_RG" -n "$AKS_NAME" -l "$AZURE_LOCATION" \
      --sku automatic \
      --vnet-subnet-id "$AKS_SUBNET_ID" \
      --enable-managed-identity \
      --enable-workload-identity \
      --enable-oidc-issuer \
      --enable-azure-keyvault-secrets-provider \
      --attach-acr "$AZURE_ACR_NAME" \
      --output none
    ok "AKS Automatic cluster created"
  fi
  save_state AKS_NAME "$AKS_NAME"

  # Fetch credentials
  az aks get-credentials -g "$AZURE_RG" -n "$AKS_NAME" \
    --overwrite-existing --output none
  ok "kubectl context configured"

  AKS_OIDC_ISSUER="$(az aks show -g "$AZURE_RG" -n "$AKS_NAME" \
    --query oidcIssuerProfile.issuerUrl -o tsv)"
  save_state AKS_OIDC_ISSUER "$AKS_OIDC_ISSUER"

  # Step 1.9: Create user-assigned managed identity and federate it
  info "Step 1.9: Creating workload identity and federating with AKS..."
  WORKLOAD_IDENTITY_NAME="okta-ps-adapter-workload-id"
  if az identity show -g "$AZURE_RG" -n "$WORKLOAD_IDENTITY_NAME" &>/dev/null; then
    ok "Managed identity $WORKLOAD_IDENTITY_NAME already exists"
  else
    az identity create -g "$AZURE_RG" -n "$WORKLOAD_IDENTITY_NAME" \
      -l "$AZURE_LOCATION" --output none
    ok "Managed identity created"
  fi
  WORKLOAD_IDENTITY_CLIENT_ID="$(az identity show -g "$AZURE_RG" \
    -n "$WORKLOAD_IDENTITY_NAME" --query clientId -o tsv)"
  WORKLOAD_IDENTITY_PRINCIPAL_ID="$(az identity show -g "$AZURE_RG" \
    -n "$WORKLOAD_IDENTITY_NAME" --query principalId -o tsv)"
  save_state WORKLOAD_IDENTITY_CLIENT_ID "$WORKLOAD_IDENTITY_CLIENT_ID"
  save_state WORKLOAD_IDENTITY_PRINCIPAL_ID "$WORKLOAD_IDENTITY_PRINCIPAL_ID"

  # Federated credential (idempotent — list and skip if exists)
  if az identity federated-credential list -g "$AZURE_RG" \
       --identity-name "$WORKLOAD_IDENTITY_NAME" \
       --query "[?name=='okta-ps-adapter-fc']" -o tsv | grep -q .; then
    ok "Federated credential okta-ps-adapter-fc already exists"
  else
    az identity federated-credential create \
      --name okta-ps-adapter-fc \
      --identity-name "$WORKLOAD_IDENTITY_NAME" \
      --resource-group "$AZURE_RG" \
      --issuer "$AKS_OIDC_ISSUER" \
      --subject "system:serviceaccount:okta-ps-adapter:okta-ps-adapter-sa" \
      --output none
    ok "Federated credential created"
  fi

  # Mark phase 1 complete
  save_state PHASE_1_COMPLETE "true"

  print_summary_box "Phase 1 Complete: Foundation Ready" \
    "Subscription: $AZURE_SUBSCRIPTION_ID" \
    "Region:       $AZURE_LOCATION" \
    "RG:           $AZURE_RG" \
    "ACR:          $ACR_LOGIN_SERVER" \
    "AKS cluster:  $AKS_NAME" \
    "VNet:         $VNET_NAME (10.50.0.0/16)" \
    "Workload ID:  $WORKLOAD_IDENTITY_CLIENT_ID" \
    "" \
    "Next: ./azuresetup.sh --phase 2"
}

# ================================================================
# Phase 2: Stateful Tier
# ================================================================

run_phase_2() {
  print_banner "Phase 2: Stateful Tier"

  # Step 2.0: Verify Phase 1 completed
  info "Step 2.0: Verifying Phase 1 completion..."
  if [[ "$(get_state PHASE_1_COMPLETE)" != "true" ]]; then
    die "Phase 1 has not completed. Run: ./azuresetup.sh --phase 1"
  fi

  # Reload state from Phase 1
  AZURE_SUBSCRIPTION_ID="$(get_state AZURE_SUBSCRIPTION_ID)"
  AZURE_LOCATION="$(get_state AZURE_LOCATION)"
  AZURE_RG="$(get_state AZURE_RG)"
  TENANT_ID="$(get_state TENANT_ID)"
  AKS_NAME="$(get_state AKS_NAME)"
  PE_SUBNET_ID="$(get_state PE_SUBNET_ID)"
  WORKLOAD_IDENTITY_PRINCIPAL_ID="$(get_state WORKLOAD_IDENTITY_PRINCIPAL_ID)"

  for var in AZURE_SUBSCRIPTION_ID AZURE_LOCATION AZURE_RG TENANT_ID \
             AKS_NAME PE_SUBNET_ID WORKLOAD_IDENTITY_PRINCIPAL_ID; do
    if [[ -z "${!var}" ]]; then
      die "$var missing from state. Rerun Phase 1."
    fi
  done

  az account set --subscription "$AZURE_SUBSCRIPTION_ID"
  ok "Phase 1 state loaded"

  # Step 2.1: Load and validate Okta values
  info "Step 2.1: Loading Okta configuration..."

  # Only OKTA_DOMAIN is required. The adapter's config.py derives
  # the issuer URL from OKTA_DOMAIN. CIMD relay credentials live
  # per-agent in the database and are configured via the Admin UI
  # after deployment.
  OKTA_DOMAIN="${OKTA_DOMAIN:-$(get_state OKTA_DOMAIN)}"

  if $NON_INTERACTIVE; then
    if [[ -z "$OKTA_DOMAIN" ]]; then
      die "OKTA_DOMAIN not set in env, .env, or state file (non-interactive mode)"
    fi
  else
    if [[ -z "$OKTA_DOMAIN" ]]; then
      prompt_required OKTA_DOMAIN "Okta domain (e.g. yourorg.okta.com)"
    fi
  fi

  # Validate the domain format
  if [[ ! "$OKTA_DOMAIN" =~ \.(okta\.com|oktapreview\.com)$ ]]; then
    warn "OKTA_DOMAIN does not end with .okta.com or .oktapreview.com"
    if ! $NON_INTERACTIVE; then
      prompt_yesno "Continue anyway?" n || die "Aborted by operator"
    fi
  fi

  save_state OKTA_DOMAIN "$OKTA_DOMAIN"
  ok "Okta configuration loaded (OKTA_DOMAIN=$OKTA_DOMAIN)"

  # Step 2.2: Resolve / generate names for Postgres and Redis
  info "Step 2.2: Resolving Postgres and Redis resource names..."

  PG_NAME="${PG_NAME:-$(get_state PG_NAME)}"
  if [[ -z "$PG_NAME" ]]; then
    PG_NAME="okta-ps-adapter-pg-$(random_suffix 4)"
  fi
  save_state PG_NAME "$PG_NAME"

  REDIS_NAME="${REDIS_NAME:-$(get_state REDIS_NAME)}"
  if [[ -z "$REDIS_NAME" ]]; then
    REDIS_NAME="okta-ps-adapter-redis-$(random_suffix 4)"
  fi
  save_state REDIS_NAME "$REDIS_NAME"

  ok "Postgres: $PG_NAME"
  ok "Redis:    $REDIS_NAME"

  # Step 2.3: Generate / load Postgres password
  info "Step 2.3: Resolving Postgres admin password..."
  PG_PASSWORD="$(get_state PG_PASSWORD)"
  if [[ -z "$PG_PASSWORD" ]]; then
    PG_PASSWORD="$(generate_password 24)"
    save_state PG_PASSWORD "$PG_PASSWORD"
    ok "Generated new Postgres admin password"
  else
    ok "Loaded existing Postgres password from state"
  fi

  # Step 2.4: Kick off Postgres + Redis in parallel (BOTH --no-wait)
  info "Step 2.4: Kicking off Postgres + Redis provisioning in parallel..."
  warn "         Sequential would be ~30 min wall-clock. Parallel = ~20 min."

  # Postgres — only kick off if it doesn't already exist
  if az postgres flexible-server show -g "$AZURE_RG" -n "$PG_NAME" &>/dev/null; then
    ok "Postgres $PG_NAME already exists — skipping create"
  else
    info "Starting Postgres GP D2ds_v5 + ZR HA provisioning (--no-wait)..."
    az postgres flexible-server create \
      --resource-group "$AZURE_RG" \
      --location "$AZURE_LOCATION" \
      --name "$PG_NAME" \
      --tier GeneralPurpose \
      --sku-name Standard_D2ds_v5 \
      --version 15 \
      --storage-size 64 \
      --high-availability ZoneRedundant \
      --zone 1 \
      --standby-zone 2 \
      --vnet okta-ps-adapter-vnet \
      --subnet pe-subnet \
      --private-dns-zone privatelink.postgres.database.azure.com \
      --admin-user pgadmin \
      --admin-password "$PG_PASSWORD" \
      --backup-retention 14 \
      --yes \
      --no-wait \
      --output none
    ok "Postgres provisioning kicked off"
  fi

  # Redis — only kick off if it doesn't already exist
  if az redis show -g "$AZURE_RG" -n "$REDIS_NAME" &>/dev/null; then
    ok "Redis $REDIS_NAME already exists — skipping create"
  else
    info "Starting Redis Standard C1 provisioning (--no-wait)..."
    az redis create \
      --resource-group "$AZURE_RG" \
      --location "$AZURE_LOCATION" \
      --name "$REDIS_NAME" \
      --sku Standard --vm-size c1 \
      --enable-non-ssl-port false \
      --minimum-tls-version 1.2 \
      --redis-version 6 \
      --no-wait \
      --output none
    ok "Redis provisioning kicked off"
  fi

  # Step 2.5: Wait for both to finish
  # Postgres wait first because it's typically faster (8-12 min) and
  # we want to fail fast if it errors. Redis polling continues after.
  info "Step 2.5: Waiting for Postgres to reach provisioningState=Succeeded..."
  az postgres flexible-server wait \
    --resource-group "$AZURE_RG" \
    --name "$PG_NAME" \
    --created \
    --interval 30 \
    --timeout 1500
  ok "Postgres $PG_NAME ready"

  info "Step 2.5b: Waiting for Redis to reach provisioningState=Succeeded..."
  poll_redis_provisioned "$AZURE_RG" "$REDIS_NAME" 1800

  # Step 2.6: Create the gateway database in Postgres
  info "Step 2.6: Creating gateway_db database..."
  if az postgres flexible-server db show -g "$AZURE_RG" -s "$PG_NAME" \
       -d gateway_db &>/dev/null; then
    ok "Database gateway_db already exists"
  else
    az postgres flexible-server db create -g "$AZURE_RG" \
      -s "$PG_NAME" -d gateway_db --output none
    ok "Database gateway_db created"
  fi

  PG_FQDN="${PG_NAME}.postgres.database.azure.com"
  save_state PG_FQDN "$PG_FQDN"

  # Step 2.7: Disable Redis public network access and create private endpoint
  info "Step 2.7: Disabling Redis public network access..."
  az redis update -g "$AZURE_RG" -n "$REDIS_NAME" \
    --set publicNetworkAccess=Disabled --output none
  ok "Redis public access disabled"

  info "Step 2.8: Creating Redis private endpoint..."
  REDIS_PE_NAME="${REDIS_NAME}-pe"
  if az network private-endpoint show -g "$AZURE_RG" -n "$REDIS_PE_NAME" &>/dev/null; then
    ok "Private endpoint $REDIS_PE_NAME already exists"
  else
    REDIS_RESOURCE_ID="$(az redis show -g "$AZURE_RG" -n "$REDIS_NAME" \
      --query id -o tsv)"
    az network private-endpoint create \
      -g "$AZURE_RG" -l "$AZURE_LOCATION" \
      --name "$REDIS_PE_NAME" \
      --vnet-name okta-ps-adapter-vnet --subnet pe-subnet \
      --private-connection-resource-id "$REDIS_RESOURCE_ID" \
      --group-id redisCache \
      --connection-name "${REDIS_NAME}-pe-conn" \
      --output none
    ok "Private endpoint created"
  fi

  info "Step 2.8b: Linking Redis private endpoint to private DNS zone..."
  if az network private-endpoint dns-zone-group show \
       -g "$AZURE_RG" --endpoint-name "$REDIS_PE_NAME" \
       -n redis-zg &>/dev/null; then
    ok "DNS zone group already exists"
  else
    az network private-endpoint dns-zone-group create \
      -g "$AZURE_RG" --endpoint-name "$REDIS_PE_NAME" \
      -n redis-zg \
      --private-dns-zone privatelink.redis.cache.windows.net \
      --zone-name redis \
      --output none
    ok "DNS zone group created"
  fi

  REDIS_FQDN="${REDIS_NAME}.redis.cache.windows.net"
  save_state REDIS_FQDN "$REDIS_FQDN"

  # Step 2.9: Build connection strings for later phases
  info "Step 2.9: Building connection strings..."
  PG_PASSWORD_ENC="$(urlencode_password "$PG_PASSWORD")"
  DATABASE_URL="postgresql://pgadmin:${PG_PASSWORD_ENC}@${PG_FQDN}:5432/gateway_db?sslmode=require"

  REDIS_KEY="$(az redis list-keys -g "$AZURE_RG" -n "$REDIS_NAME" \
    --query primaryKey -o tsv)"
  REDIS_URL="rediss://:${REDIS_KEY}@${REDIS_FQDN}:6380/0"

  # Save into state so AZ9 can pull them when writing to Key Vault
  save_state DATABASE_URL "$DATABASE_URL"
  save_state REDIS_URL "$REDIS_URL"
  ok "Connection strings staged for Key Vault"

  # Step 2.10: Resolve / generate Key Vault name
  info "Step 2.10: Resolving Key Vault name..."
  KV_NAME="${KV_NAME:-$(get_state KV_NAME)}"
  if [[ -z "$KV_NAME" ]]; then
    KV_NAME="okta-ps-adapter-kv-$(random_suffix 4)"
  fi
  save_state KV_NAME "$KV_NAME"
  ok "Key Vault: $KV_NAME"

  # Step 2.11: Create Key Vault with RBAC mode and purge protection
  # NOTE: Public network access is left ENABLED here so this script
  # can write the secrets from the operator's machine. Phase 4 will
  # disable it once the AKS workload identity has been verified to
  # have its Key Vault Secrets User role.
  info "Step 2.11: Creating Key Vault (RBAC mode, purge protection)..."
  if az keyvault show -n "$KV_NAME" &>/dev/null; then
    ok "Key Vault $KV_NAME already exists"
  else
    az keyvault create -g "$AZURE_RG" -n "$KV_NAME" \
      -l "$AZURE_LOCATION" \
      --enable-rbac-authorization true \
      --enable-purge-protection true \
      --retention-days 90 \
      --output none
    ok "Key Vault created"
  fi
  KV_URI="$(az keyvault show -n "$KV_NAME" --query properties.vaultUri -o tsv)"
  save_state KV_URI "$KV_URI"

  # Step 2.12: Grant the operator running this script the
  # "Key Vault Secrets Officer" role so we can write secrets
  info "Step 2.12: Granting current user Key Vault Secrets Officer RBAC..."
  CURRENT_USER_ID="$(az ad signed-in-user show --query id -o tsv 2>/dev/null || true)"
  if [[ -z "$CURRENT_USER_ID" ]]; then
    # Fall back to service principal context if signed-in-user fails
    CURRENT_USER_ID="$(az account show --query user.name -o tsv)"
    warn "Using service principal identity for RBAC: $CURRENT_USER_ID"
  fi
  KV_SCOPE="$(az keyvault show -n "$KV_NAME" --query id -o tsv)"

  # Idempotent role assignment — check if already granted
  if az role assignment list --assignee "$CURRENT_USER_ID" \
       --scope "$KV_SCOPE" \
       --query "[?roleDefinitionName=='Key Vault Secrets Officer']" \
       -o tsv | grep -q .; then
    ok "Operator already has Key Vault Secrets Officer"
  else
    az role assignment create \
      --role "Key Vault Secrets Officer" \
      --assignee "$CURRENT_USER_ID" \
      --scope "$KV_SCOPE" \
      --output none
    ok "Role assignment created — waiting 30s for propagation"
    sleep 30
  fi

  # Step 2.13: Create private endpoint for Key Vault
  info "Step 2.13: Creating Key Vault private endpoint..."
  KV_PE_NAME="${KV_NAME}-pe"
  if az network private-endpoint show -g "$AZURE_RG" -n "$KV_PE_NAME" &>/dev/null; then
    ok "Private endpoint $KV_PE_NAME already exists"
  else
    az network private-endpoint create \
      -g "$AZURE_RG" -l "$AZURE_LOCATION" \
      --name "$KV_PE_NAME" \
      --vnet-name okta-ps-adapter-vnet --subnet pe-subnet \
      --private-connection-resource-id "$KV_SCOPE" \
      --group-id vault \
      --connection-name "${KV_NAME}-pe-conn" \
      --output none
    ok "Private endpoint created"
  fi

  if az network private-endpoint dns-zone-group show \
       -g "$AZURE_RG" --endpoint-name "$KV_PE_NAME" \
       -n kv-zg &>/dev/null; then
    ok "DNS zone group already exists"
  else
    az network private-endpoint dns-zone-group create \
      -g "$AZURE_RG" --endpoint-name "$KV_PE_NAME" \
      -n kv-zg \
      --private-dns-zone privatelink.vaultcore.azure.net \
      --zone-name vault \
      --output none
    ok "DNS zone group created"
  fi

  # Step 2.14: Generate the AES-256 encryption key and admin password
  info "Step 2.14: Generating encryption key and admin password..."
  ENCRYPTION_KEY="${ENCRYPTION_KEY:-$(get_state ENCRYPTION_KEY)}"
  if [[ -z "$ENCRYPTION_KEY" ]]; then
    ENCRYPTION_KEY="$(generate_encryption_key)"
    save_state ENCRYPTION_KEY "$ENCRYPTION_KEY"
    ok "Generated new ENCRYPTION_KEY"
  else
    ok "Loaded existing ENCRYPTION_KEY from state"
  fi

  # ADMIN_PASSWORD removed in v0.15.x — admin API is Okta-OAuth-only.

  # Step 2.15: Write secrets to Key Vault
  # Note: CIMD relay credentials are NOT stored here. They live
  # per-agent in PostgreSQL and are managed via the Admin UI.
  info "Step 2.15: Writing secrets to Key Vault..."

  # Reload connection strings from state (saved by AZ8)
  DATABASE_URL="$(get_state DATABASE_URL)"
  REDIS_URL="$(get_state REDIS_URL)"
  [[ -z "$DATABASE_URL" ]] && die "DATABASE_URL missing from state"
  [[ -z "$REDIS_URL" ]] && die "REDIS_URL missing from state"

  set_kv_secret() {
    local name="$1" value="$2"
    az keyvault secret set --vault-name "$KV_NAME" --name "$name" \
      --value "$value" --output none
    ok "Secret written: $name"
  }

  set_kv_secret encryption-key "$ENCRYPTION_KEY"
  set_kv_secret database-url "$DATABASE_URL"
  set_kv_secret redis-url "$REDIS_URL"

  # Step 2.16: Grant the workload identity Key Vault Secrets User RBAC
  info "Step 2.16: Granting workload identity Key Vault Secrets User..."
  if az role assignment list \
       --assignee "$WORKLOAD_IDENTITY_PRINCIPAL_ID" \
       --scope "$KV_SCOPE" \
       --query "[?roleDefinitionName=='Key Vault Secrets User']" \
       -o tsv | grep -q .; then
    ok "Workload identity already has Key Vault Secrets User"
  else
    az role assignment create \
      --role "Key Vault Secrets User" \
      --assignee-object-id "$WORKLOAD_IDENTITY_PRINCIPAL_ID" \
      --assignee-principal-type ServicePrincipal \
      --scope "$KV_SCOPE" \
      --output none
    ok "Role assignment created"
  fi

  # Mark phase 2 complete
  save_state PHASE_2_COMPLETE "true"

  print_summary_box "Phase 2 Complete: Stateful Tier Ready" \
    "Postgres:    $PG_FQDN" \
    "             Standard_D2ds_v5 + ZR HA" \
    "Redis:       $REDIS_FQDN" \
    "             Standard C1 (private endpoint)" \
    "Key Vault:   $KV_NAME" \
    "             Public access ENABLED until Phase 4" \
    "Secrets:     4 written (encryption-key, admin-password," \
    "             database-url, redis-url)" \
    "             (CIMD relay credentials are per-agent in DB)" \
    "Workload ID: granted Key Vault Secrets User" \
    "" \
    "Next: ./azuresetup.sh --phase 3"
}

# ================================================================
# Phase 3: Application + Ingress (stub)
# ================================================================

run_phase_3() {
  print_banner "Phase 3: Application + Ingress"

  # Step 3.0: Verify Phase 2 completed
  info "Step 3.0: Verifying Phase 2 completion..."
  if [[ "$(get_state PHASE_2_COMPLETE)" != "true" ]]; then
    die "Phase 2 has not completed. Run: ./azuresetup.sh --phase 2"
  fi

  # Reload state from Phases 1 and 2
  AZURE_SUBSCRIPTION_ID="$(get_state AZURE_SUBSCRIPTION_ID)"
  AZURE_LOCATION="$(get_state AZURE_LOCATION)"
  AZURE_RG="$(get_state AZURE_RG)"
  TENANT_ID="$(get_state TENANT_ID)"
  AKS_NAME="$(get_state AKS_NAME)"
  AKS_OIDC_ISSUER="$(get_state AKS_OIDC_ISSUER)"
  AZURE_ACR_NAME="$(get_state AZURE_ACR_NAME)"
  ACR_LOGIN_SERVER="$(get_state ACR_LOGIN_SERVER)"
  AGC_SUBNET_ID="$(get_state AGC_SUBNET_ID)"
  WORKLOAD_IDENTITY_CLIENT_ID="$(get_state WORKLOAD_IDENTITY_CLIENT_ID)"
  KV_NAME="$(get_state KV_NAME)"
  OKTA_DOMAIN="$(get_state OKTA_DOMAIN)"

  for var in AZURE_SUBSCRIPTION_ID AZURE_LOCATION AZURE_RG TENANT_ID \
             AKS_NAME AKS_OIDC_ISSUER AZURE_ACR_NAME ACR_LOGIN_SERVER \
             AGC_SUBNET_ID WORKLOAD_IDENTITY_CLIENT_ID KV_NAME \
             OKTA_DOMAIN; do
    [[ -z "${!var}" ]] && die "$var missing from state. Rerun Phase 1 or 2."
  done

  az account set --subscription "$AZURE_SUBSCRIPTION_ID"
  ok "Phase 1 and 2 state loaded"

  # Ensure kubectl context is set (the operator may have been on
  # a different cluster since Phase 1)
  info "Ensuring kubectl context points at $AKS_NAME..."
  az aks get-credentials -g "$AZURE_RG" -n "$AKS_NAME" \
    --overwrite-existing --output none
  ok "kubectl context set"

  # Step 3.1: Load and validate hostnames
  info "Step 3.1: Loading public hostnames..."

  ADAPTER_HOSTNAME="${ADAPTER_HOSTNAME:-$(get_state ADAPTER_HOSTNAME)}"
  ADMIN_HOSTNAME="${ADMIN_HOSTNAME:-$(get_state ADMIN_HOSTNAME)}"

  if $NON_INTERACTIVE; then
    [[ -z "$ADAPTER_HOSTNAME" ]] && die "ADAPTER_HOSTNAME not set (non-interactive mode)"
    [[ -z "$ADMIN_HOSTNAME" ]] && die "ADMIN_HOSTNAME not set (non-interactive mode)"
  else
    [[ -z "$ADAPTER_HOSTNAME" ]] && \
      prompt_required ADAPTER_HOSTNAME "Adapter hostname (e.g. mcp.example.com)"
    [[ -z "$ADMIN_HOSTNAME" ]] && \
      prompt_required ADMIN_HOSTNAME "Admin UI hostname (e.g. admin-mcp.example.com)"
  fi

  # Sanity check: must not be IPs, must contain a dot, must not be
  # the same as each other
  for hn in "$ADAPTER_HOSTNAME" "$ADMIN_HOSTNAME"; do
    if [[ ! "$hn" =~ \. ]] || [[ "$hn" =~ ^[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+$ ]]; then
      die "Hostname '$hn' is not a valid DNS name"
    fi
  done
  if [[ "$ADAPTER_HOSTNAME" == "$ADMIN_HOSTNAME" ]]; then
    die "ADAPTER_HOSTNAME and ADMIN_HOSTNAME must be different"
  fi

  save_state ADAPTER_HOSTNAME "$ADAPTER_HOSTNAME"
  save_state ADMIN_HOSTNAME "$ADMIN_HOSTNAME"
  ok "Adapter hostname: $ADAPTER_HOSTNAME"
  ok "Admin hostname:   $ADMIN_HOSTNAME"

  # Step 3.2: Create the ALB controller's workload identity
  # This is SEPARATE from the adapter's workload identity created in
  # Phase 1. The ALB controller runs as a pod in azure-alb-system and
  # needs its own managed identity with its own federated credential
  # and its own RBAC assignments.
  info "Step 3.2: Creating ALB controller workload identity..."
  ALB_IDENTITY_NAME="azure-alb-identity"

  if az identity show -g "$AZURE_RG" -n "$ALB_IDENTITY_NAME" &>/dev/null; then
    ok "Managed identity $ALB_IDENTITY_NAME already exists"
  else
    az identity create -g "$AZURE_RG" -n "$ALB_IDENTITY_NAME" \
      -l "$AZURE_LOCATION" --output none
    ok "Managed identity $ALB_IDENTITY_NAME created"
  fi
  ALB_IDENTITY_CLIENT_ID="$(az identity show -g "$AZURE_RG" \
    -n "$ALB_IDENTITY_NAME" --query clientId -o tsv)"
  ALB_IDENTITY_PRINCIPAL_ID="$(az identity show -g "$AZURE_RG" \
    -n "$ALB_IDENTITY_NAME" --query principalId -o tsv)"
  save_state ALB_IDENTITY_CLIENT_ID "$ALB_IDENTITY_CLIENT_ID"
  save_state ALB_IDENTITY_PRINCIPAL_ID "$ALB_IDENTITY_PRINCIPAL_ID"

  # Step 3.3: Federate the identity with the AKS OIDC issuer
  # The ALB Helm chart deploys a ServiceAccount named alb-controller-sa
  # in the azure-alb-system namespace. The federated credential binds
  # the managed identity to that specific service account.
  info "Step 3.3: Federating ALB identity with AKS OIDC issuer..."
  if az identity federated-credential list -g "$AZURE_RG" \
       --identity-name "$ALB_IDENTITY_NAME" \
       --query "[?name=='azure-alb-identity-fc']" -o tsv | grep -q .; then
    ok "Federated credential azure-alb-identity-fc already exists"
  else
    az identity federated-credential create \
      --name azure-alb-identity-fc \
      --identity-name "$ALB_IDENTITY_NAME" \
      --resource-group "$AZURE_RG" \
      --issuer "$AKS_OIDC_ISSUER" \
      --subject "system:serviceaccount:azure-alb-system:alb-controller-sa" \
      --output none
    ok "Federated credential created"
  fi

  # Step 3.4: Grant the ALB identity Reader on the AKS node RG (MC_*)
  # The controller reads AKS node metadata to figure out the cluster
  # topology. Without this it cannot start.
  info "Step 3.4: Granting ALB identity Reader on node resource group..."
  MC_RG="$(az aks show -g "$AZURE_RG" -n "$AKS_NAME" \
    --query nodeResourceGroup -o tsv)"
  MC_RG_ID="$(az group show -n "$MC_RG" --query id -o tsv)"
  save_state MC_RG "$MC_RG"

  if az role assignment list \
       --assignee "$ALB_IDENTITY_PRINCIPAL_ID" \
       --scope "$MC_RG_ID" \
       --query "[?roleDefinitionName=='Reader']" -o tsv | grep -q .; then
    ok "ALB identity already has Reader on $MC_RG"
  else
    az role assignment create \
      --role "Reader" \
      --assignee-object-id "$ALB_IDENTITY_PRINCIPAL_ID" \
      --assignee-principal-type ServicePrincipal \
      --scope "$MC_RG_ID" \
      --output none
    ok "Reader role granted on $MC_RG"
  fi

  # Step 3.5: Grant the ALB identity AppGw for Containers Configuration
  # Manager on the AGC subnet. This lets the controller provision
  # AGC resources inside agc-subnet.
  info "Step 3.5: Granting ALB identity subnet join permission..."
  if az role assignment list \
       --assignee "$ALB_IDENTITY_PRINCIPAL_ID" \
       --scope "$AGC_SUBNET_ID" \
       --query "[?roleDefinitionName=='AppGw for Containers Configuration Manager']" \
       -o tsv | grep -q .; then
    ok "ALB identity already has AppGw Configuration Manager on agc-subnet"
  else
    az role assignment create \
      --role "AppGw for Containers Configuration Manager" \
      --assignee-object-id "$ALB_IDENTITY_PRINCIPAL_ID" \
      --assignee-principal-type ServicePrincipal \
      --scope "$AGC_SUBNET_ID" \
      --output none
    ok "AppGw Configuration Manager role granted on agc-subnet"
  fi

  info "Waiting 60s for role assignments to propagate..."
  sleep 60
  ok "Propagation wait complete"

  # Step 3.6: Build images via az acr build
  info "Step 3.6: Building images..."

  # Resolve the repo root — wizard lives at deploy/azure-aks/
  REPO_ROOT="$(cd "$SCRIPT_DIR/../.." && pwd)"

  # Resolve the image tag. For production we use the git sha so
  # rollouts are immutable and reproducible. Fall back to "manual"
  # if we're not inside a git repo.
  IMAGE_TAG="$(get_state IMAGE_TAG)"
  if [[ -z "$IMAGE_TAG" ]] || ! $SKIP_BUILD; then
    if git -C "$REPO_ROOT" rev-parse --short HEAD &>/dev/null; then
      IMAGE_TAG="$(git -C "$REPO_ROOT" rev-parse --short HEAD)"
    else
      IMAGE_TAG="manual-$(date +%Y%m%d-%H%M%S)"
      warn "Not inside a git repo — using tag $IMAGE_TAG"
    fi
    save_state IMAGE_TAG "$IMAGE_TAG"
  fi
  ok "Image tag: $IMAGE_TAG"

  if $SKIP_BUILD; then
    info "Step 3.6: Skipping image builds (--skip-build)"
    ok "Reusing existing tag $IMAGE_TAG in ACR"
  else
    info "Building adapter image..."
    az acr build --registry "$AZURE_ACR_NAME" \
      --image "adapter:$IMAGE_TAG" \
      --file "$REPO_ROOT/Dockerfile" \
      "$REPO_ROOT" \
      --output none
    ok "adapter:$IMAGE_TAG built"

    info "Building admin-ui image..."
    az acr build --registry "$AZURE_ACR_NAME" \
      --image "admin-ui:$IMAGE_TAG" \
      --file "$REPO_ROOT/okta_agent_proxy_admin_ui/Dockerfile" \
      "$REPO_ROOT/okta_agent_proxy_admin_ui" \
      --output none
    ok "admin-ui:$IMAGE_TAG built"

    info "Building hr-backend image..."
    az acr build --registry "$AZURE_ACR_NAME" \
      --image "hr-backend:$IMAGE_TAG" \
      --file "$REPO_ROOT/examples/01-hr-system/Dockerfile" \
      "$REPO_ROOT/examples/01-hr-system" \
      --output none
    ok "hr-backend:$IMAGE_TAG built"
  fi

  # Verify all three tags exist in ACR
  info "Verifying images in ACR..."
  for repo in adapter admin-ui hr-backend; do
    if ! az acr repository show-tags \
           --name "$AZURE_ACR_NAME" \
           --repository "$repo" \
           --query "contains(@, '$IMAGE_TAG')" -o tsv | grep -qi true; then
      die "Image $repo:$IMAGE_TAG not found in ACR. Build failed?"
    fi
    ok "$repo:$IMAGE_TAG confirmed in ACR"
  done

  # Step 3.7: Substitute manifest templates into a temp directory
  info "Step 3.7: Materializing manifest templates..."
  RENDERED_DIR="$(mktemp -d)"
  trap 'rm -rf "$RENDERED_DIR"' EXIT

  MANIFESTS_SRC="$SCRIPT_DIR/manifests"
  [[ -d "$MANIFESTS_SRC" ]] || die "Missing manifests directory: $MANIFESTS_SRC"

  # Namespace + ServiceAccount — needs workload identity client ID
  substitute_manifest \
    "$MANIFESTS_SRC/00-namespace-sa.yaml" \
    "$RENDERED_DIR/00-namespace-sa.yaml" \
    "WORKLOAD_IDENTITY_CLIENT_ID=$WORKLOAD_IDENTITY_CLIENT_ID"

  # SecretProviderClass — needs KV name, tenant, workload identity
  substitute_manifest \
    "$MANIFESTS_SRC/01-spc-keyvault.yaml" \
    "$RENDERED_DIR/01-spc-keyvault.yaml" \
    "KV_NAME=$KV_NAME" \
    "TENANT_ID=$TENANT_ID" \
    "WORKLOAD_IDENTITY_CLIENT_ID=$WORKLOAD_IDENTITY_CLIENT_ID"

  # ConfigMap — only OKTA_DOMAIN (per AZ13 correction)
  substitute_manifest \
    "$MANIFESTS_SRC/02-configmap.yaml" \
    "$RENDERED_DIR/02-configmap.yaml" \
    "OKTA_DOMAIN=$OKTA_DOMAIN"

  # Workload deployments — need ACR login server and image tag
  # NOTE: the templates from AZ3 hardcode ":latest" in the image
  # reference. We substitute the registry but then also do a
  # sed pass to replace :latest with :$IMAGE_TAG for reproducibility.
  for f in 20-adapter.yaml 21-admin-ui.yaml 22-hr-backend.yaml; do
    substitute_manifest \
      "$MANIFESTS_SRC/$f" \
      "$RENDERED_DIR/$f" \
      "ACR_LOGIN_SERVER=$ACR_LOGIN_SERVER"
    # Pin image tags to the git sha from AZ15
    sed -i.bak "s|:latest|:$IMAGE_TAG|g" "$RENDERED_DIR/$f"
    rm -f "$RENDERED_DIR/$f.bak"
  done

  # ALB (30), Gateway (31), HTTPRoutes (32) — hostnames and AGC subnet
  # Applied in AZ17 (AGC provisioning), but materialized here so all
  # rendering happens in one place.
  substitute_manifest \
    "$MANIFESTS_SRC/30-alb.yaml" \
    "$RENDERED_DIR/30-alb.yaml" \
    "AGC_SUBNET_ID=$AGC_SUBNET_ID"

  cp "$MANIFESTS_SRC/31-gateway.yaml" "$RENDERED_DIR/31-gateway.yaml"

  substitute_manifest \
    "$MANIFESTS_SRC/32-routes.yaml" \
    "$RENDERED_DIR/32-routes.yaml" \
    "ADAPTER_HOSTNAME=$ADAPTER_HOSTNAME" \
    "ADMIN_HOSTNAME=$ADMIN_HOSTNAME"

  # Network policies — no substitution (hardcoded CIDRs from AZ3)
  cp "$MANIFESTS_SRC/40-network-policies.yaml" \
     "$RENDERED_DIR/40-network-policies.yaml"

  save_state RENDERED_DIR "$RENDERED_DIR"
  ok "10 manifests materialized into $RENDERED_DIR"

  # Step 3.8: Apply namespace + ServiceAccount first
  info "Step 3.8: Applying namespace and ServiceAccount..."
  kubectl apply -f "$RENDERED_DIR/00-namespace-sa.yaml"

  # Step 3.9: Apply SecretProviderClass and ConfigMap
  info "Step 3.9: Applying SecretProviderClass and ConfigMap..."
  kubectl apply -f "$RENDERED_DIR/01-spc-keyvault.yaml"
  kubectl apply -f "$RENDERED_DIR/02-configmap.yaml"

  # Step 3.10: Apply workload Deployments and Services
  info "Step 3.10: Applying workload deployments..."
  kubectl apply -f "$RENDERED_DIR/20-adapter.yaml"
  kubectl apply -f "$RENDERED_DIR/21-admin-ui.yaml"
  kubectl apply -f "$RENDERED_DIR/22-hr-backend.yaml"

  # Step 3.11: Wait for rollouts
  info "Step 3.11: Waiting for workload rollouts..."
  kubectl -n okta-ps-adapterrollout status deployment/okta-ps-adapter --timeout=300s
  kubectl -n okta-ps-adapterrollout status deployment/admin-ui --timeout=180s
  kubectl -n okta-ps-adapterrollout status deployment/hr-mcp-server --timeout=180s
  ok "All three workloads rolled out"

  # Step 3.12: Verify the Key Vault CSI secret was materialized
  # This proves the Secrets Store CSI driver could authenticate to
  # Key Vault and pull the 4 secrets that Phase 2 wrote. If this
  # fails, the workload identity RBAC from Phase 2 is misconfigured.
  info "Step 3.12: Verifying Key Vault secret materialization..."
  local secret_keys
  secret_keys=$(kubectl -n okta-ps-adapterget secret okta-ps-adapter-secrets \
    -o jsonpath='{.data}' 2>/dev/null || echo "")
  if [[ -z "$secret_keys" ]]; then
    fail "Secret okta-ps-adapter-secrets was NOT materialized."
    fail "This usually means workload identity cannot read Key Vault."
    fail "Debug: kubectl -n okta-ps-adapterdescribe pod -l app=okta-ps-adapter"
    die "Aborting Phase 3"
  fi
  # Count keys without printing values
  local key_count
  key_count=$(kubectl -n okta-ps-adapterget secret okta-ps-adapter-secrets \
    -o jsonpath='{.data}' | jq 'length' 2>/dev/null || echo "0")
  if [[ "$key_count" -lt 4 ]]; then
    warn "Expected 4 keys in okta-ps-adapter-secrets, found $key_count"
  fi
  ok "Key Vault secret materialized with $key_count keys"

  # Step 3.13: Apply HPA, PDB, and network policies
  # Network policies must come AFTER the workload pods exist so the
  # default-deny doesn't orphan the first pod scheduling attempt.
  info "Step 3.13: Applying NetworkPolicies..."
  kubectl apply -f "$RENDERED_DIR/40-network-policies.yaml"
  ok "NetworkPolicies applied"

  # Step 3.14: Print workload status
  info "Step 3.14: Current workload state:"
  kubectl get pods,svc,hpa,pdb -n okta-ps

  # Step 3.15: Install ALB controller via Helm
  info "Step 3.15: Installing ALB controller via Helm..."
  info "         Pulling from oci://mcr.microsoft.com/application-lb/charts/alb-controller"
  info "         Version is NOT pinned — using current."

  # helm registry login is not needed for the public MCR OCI registry
  # but some helm versions emit a warning — suppress it

  if helm status alb-controller -n azure-alb-system &>/dev/null; then
    ok "ALB controller already installed — running helm upgrade"
    HELM_ACTION=upgrade
  else
    HELM_ACTION=install
  fi

  helm "$HELM_ACTION" alb-controller \
    oci://mcr.microsoft.com/application-lb/charts/alb-controller \
    --namespace azure-alb-system \
    --create-namespace \
    --set "albController.podIdentity.clientID=$ALB_IDENTITY_CLIENT_ID" \
    --wait --timeout 5m
  ok "ALB controller Helm $HELM_ACTION complete"

  # Capture the installed version for reproducibility
  ALB_CHART_VERSION="$(helm list -n azure-alb-system -o json | \
    jq -r '.[] | select(.name=="alb-controller") | .chart' | \
    sed 's/alb-controller-//')"
  save_state ALB_CHART_VERSION "$ALB_CHART_VERSION"
  ok "Installed ALB controller chart: alb-controller-$ALB_CHART_VERSION"

  # Step 3.16: Wait for the ALB controller deployment to be ready
  info "Step 3.16: Waiting for ALB controller pods..."
  kubectl -n azure-alb-system rollout status deployment/alb-controller \
    --timeout=300s
  ok "ALB controller is ready"

  # Step 3.17: Apply the ApplicationLoadBalancer custom resource
  # This tells the controller to provision an AGC instance bound to
  # agc-subnet. Takes ~2-5 minutes to provision.
  info "Step 3.17: Creating ApplicationLoadBalancer CR..."
  kubectl apply -f "$RENDERED_DIR/30-alb.yaml"

  # Poll until status shows Deployment=Ready (up to 10 min)
  info "Waiting for ApplicationLoadBalancer to be Ready..."
  local alb_elapsed=0 alb_max=600
  local alb_state=""
  while (( alb_elapsed < alb_max )); do
    alb_state=$(kubectl get applicationloadbalancer okta-ps-adapter-alb \
      -n okta-ps-adapter\
      -o jsonpath='{.status.conditions[?(@.type=="Deployment")].status}' \
      2>/dev/null || echo "")
    if [[ "$alb_state" == "True" ]]; then
      echo ""
      ok "ApplicationLoadBalancer Ready after ${alb_elapsed}s"
      break
    fi
    printf "."
    sleep 15
    alb_elapsed=$((alb_elapsed + 15))
  done
  echo ""
  if [[ "$alb_state" != "True" ]]; then
    fail "ApplicationLoadBalancer did not reach Ready after ${alb_max}s"
    fail "Inspect with: kubectl describe applicationloadbalancer okta-ps-adapter-alb -n okta-ps-adapter"
    fail "And: kubectl logs -n azure-alb-system deployment/alb-controller"
    die "Aborting Phase 3"
  fi

  # Step 3.18: Apply the Gateway and HTTPRoutes
  info "Step 3.18: Applying Gateway and HTTPRoutes..."
  kubectl apply -f "$RENDERED_DIR/31-gateway.yaml"
  kubectl apply -f "$RENDERED_DIR/32-routes.yaml"

  # Step 3.19: Wait for the Gateway to have a programmed address
  info "Step 3.19: Waiting for Gateway to get a programmed address..."
  local gw_elapsed=0 gw_max=300 gw_fqdn=""
  while (( gw_elapsed < gw_max )); do
    gw_fqdn=$(kubectl get gateway okta-ps-adapter-gw -n okta-ps-adapter\
      -o jsonpath='{.status.addresses[0].value}' 2>/dev/null || echo "")
    if [[ -n "$gw_fqdn" ]]; then
      echo ""
      ok "Gateway programmed after ${gw_elapsed}s"
      break
    fi
    printf "."
    sleep 10
    gw_elapsed=$((gw_elapsed + 10))
  done
  echo ""
  if [[ -z "$gw_fqdn" ]]; then
    fail "Gateway did not reach a programmed state after ${gw_max}s"
    fail "Inspect with: kubectl describe gateway okta-ps-adapter-gw -n okta-ps-adapter"
    die "Aborting Phase 3"
  fi
  save_state AGC_FQDN "$gw_fqdn"

  # Step 3.20: Mark Phase 3 complete and print CNAME instructions
  save_state PHASE_3_COMPLETE "true"

  print_summary_box "Phase 3 Complete: Application Deployed" \
    "AGC FQDN: $gw_fqdn" \
    "" \
    "NEXT STEP — Create DNS records:" \
    "" \
    "  $ADAPTER_HOSTNAME   CNAME   $gw_fqdn" \
    "  $ADMIN_HOSTNAME     CNAME   $gw_fqdn" \
    "" \
    "After DNS has propagated (5-30 min), run:" \
    "  ./azuresetup.sh --phase 4" \
    "" \
    "Phase 4 runs smoke tests, enables Container Insights," \
    "and disables Key Vault public network access."
}

# ================================================================
# Phase 4: Smoke Tests + Lockdown (stub)
# ================================================================

run_phase_4() {
  print_banner "Phase 4: Smoke Tests + Lockdown"

  # Step 4.0: Verify Phase 3 completed
  info "Step 4.0: Verifying Phase 3 completion..."
  if [[ "$(get_state PHASE_3_COMPLETE)" != "true" ]]; then
    die "Phase 3 has not completed. Run: ./azuresetup.sh --phase 3"
  fi

  # Reload state
  AZURE_RG="$(get_state AZURE_RG)"
  AKS_NAME="$(get_state AKS_NAME)"
  KV_NAME="$(get_state KV_NAME)"
  ADAPTER_HOSTNAME="$(get_state ADAPTER_HOSTNAME)"
  ADMIN_HOSTNAME="$(get_state ADMIN_HOSTNAME)"
  AGC_FQDN="$(get_state AGC_FQDN)"

  for var in AZURE_RG AKS_NAME KV_NAME ADAPTER_HOSTNAME ADMIN_HOSTNAME \
             AGC_FQDN; do
    [[ -z "${!var}" ]] && die "$var missing from state. Rerun Phase 3."
  done
  ok "Phase 3 state loaded"

  # Ensure kubectl context is fresh
  az aks get-credentials -g "$AZURE_RG" -n "$AKS_NAME" \
    --overwrite-existing --output none

  # Step 4.1: Verify DNS resolves for both hostnames
  # If the operator ran Phase 4 before creating CNAMEs, the smoke
  # tests will fail with TLS or connection errors that are confusing.
  # Check DNS first and give a clear message.
  info "Step 4.1: Verifying DNS resolution..."
  for hn in "$ADAPTER_HOSTNAME" "$ADMIN_HOSTNAME"; do
    local resolved
    resolved=$(getent hosts "$hn" 2>/dev/null | head -1 | awk '{print $1}' || true)
    if [[ -z "$resolved" ]]; then
      fail "$hn does not resolve in DNS."
      fail "Create these CNAME records before running Phase 4:"
      fail "  $ADAPTER_HOSTNAME   CNAME   $AGC_FQDN"
      fail "  $ADMIN_HOSTNAME     CNAME   $AGC_FQDN"
      die "Aborting Phase 4 — DNS not ready"
    fi
    ok "$hn -> $resolved"
  done

  # Step 4.2: Enable Container Insights
  info "Step 4.2: Enabling Container Insights..."
  if az aks show -g "$AZURE_RG" -n "$AKS_NAME" \
       --query "addonProfiles.omsagent.enabled" -o tsv 2>/dev/null | \
       grep -qi true; then
    ok "Container Insights already enabled"
  else
    az aks enable-addons -g "$AZURE_RG" -n "$AKS_NAME" \
      --addons monitoring --output none
    ok "Container Insights enabled"
    info "Waiting 60s for the agent DaemonSet to come up..."
    sleep 60
  fi

  # Step 4.3: Smoke tests
  info "Step 4.3: Running smoke tests against https://$ADAPTER_HOSTNAME ..."
  local pass=0 total=5

  # Smoke 1: oauth-protected-resource metadata
  if curl -sf "https://$ADAPTER_HOSTNAME/.well-known/oauth-protected-resource" \
       >/dev/null 2>&1; then
    ok "Smoke 1/5: oauth-protected-resource metadata"
    pass=$((pass + 1))
  else
    fail "Smoke 1/5: oauth-protected-resource metadata"
    warn "  If this is the first Phase 4 run after Phase 3, the AGC"
    warn "  managed certificate may still be provisioning (up to 30 min"
    warn "  after DNS propagation)."
  fi

  # Smoke 2: health endpoint
  if curl -sf "https://$ADAPTER_HOSTNAME/health" >/dev/null 2>&1; then
    ok "Smoke 2/5: health endpoint"
    pass=$((pass + 1))
  else
    fail "Smoke 2/5: health endpoint"
  fi

  # Smoke 3: admin API requires auth (password login removed in v0.15.x)
  local admin_status
  admin_status=$(curl -s -o /dev/null -w '%{http_code}' "https://$ADAPTER_HOSTNAME/api/admin/agents" 2>/dev/null || echo "000")
  if [[ "$admin_status" == "401" ]]; then
    ok "Smoke 3/5: admin API rejects unauthenticated requests (401)"
    pass=$((pass + 1))
  else
    fail "Smoke 3/5: admin API returned ${admin_status} (expected 401)"
  fi

  # Smoke 4: admin API with OKTA_ADMIN_TOKEN (optional — skip if unset)
  if [[ -n "${OKTA_ADMIN_TOKEN:-}" ]]; then
    if curl -sf "https://$ADAPTER_HOSTNAME/api/admin/agents" \
         -H "Authorization: Bearer $OKTA_ADMIN_TOKEN" >/dev/null 2>&1; then
      ok "Smoke 4/5: list agents (Okta OAuth token accepted)"
      pass=$((pass + 1))
    else
      fail "Smoke 4/5: list agents with OKTA_ADMIN_TOKEN"
    fi
  else
    warn "Smoke 4/5: skipped (no token from smoke 3)"
  fi

  # Smoke 5: cache_provider=redis confirmation
  # NON-FATAL — the /health/cache endpoint may not exist on the
  # adapter yet. Mirrors the ACA treatment.
  local cache_health
  cache_health=$(curl -sf "https://$ADAPTER_HOSTNAME/health/cache" 2>/dev/null || \
                 curl -sf "https://$ADAPTER_HOSTNAME/health" 2>/dev/null || true)
  if echo "$cache_health" | grep -q '"cache_provider":\s*"redis"' 2>/dev/null; then
    ok "Smoke 5/5: cache_provider=redis confirmed"
    pass=$((pass + 1))
  else
    warn "Smoke 5/5: could not confirm cache_provider=redis"
    warn "          (the adapter may not expose this endpoint yet — non-fatal)"
  fi

  info "Smoke results: ${pass}/${total} passed"
  save_state LAST_SMOKE_PASS "$pass"
  save_state LAST_SMOKE_TOTAL "$total"

  # If none of the security-critical smoke tests passed, bail out
  # before we lock down Key Vault. We don't want an unreachable
  # adapter AND a sealed vault.
  if (( pass < 2 )); then
    fail "Only $pass/$total smoke tests passed."
    fail "Refusing to proceed with Key Vault lockdown."
    fail "Investigate the deployment before running Phase 4 again."
    die "Aborting Phase 4"
  fi

  # Step 4.4: Lock down Key Vault public network access
  # This closes the "public-then-disable" window opened in Phase 2.
  # The adapter pods authenticate via workload identity, not via
  # public endpoint — so locking it down has no effect on runtime.
  info "Step 4.4: Disabling Key Vault public network access..."
  local kv_public
  kv_public=$(az keyvault show -n "$KV_NAME" \
    --query "properties.publicNetworkAccess" -o tsv 2>/dev/null || echo "")
  if [[ "$kv_public" == "Disabled" ]]; then
    ok "Key Vault public access already Disabled"
  else
    az keyvault update -n "$KV_NAME" \
      --public-network-access Disabled --output none
    ok "Key Vault public access disabled"
  fi

  # Step 4.5: Print the final summary box
  save_state PHASE_4_COMPLETE "true"

  local smoke_summary="${pass}/${total} smoke tests passed"

  print_summary_box "Phase 4 Complete: Wizard Done" \
    "Adapter URL:  https://$ADAPTER_HOSTNAME" \
    "Admin URL:    https://$ADMIN_HOSTNAME" \
    "" \
    "$smoke_summary" \
    "" \
    "Key Vault:    $KV_NAME (PRIVATE)" \
    "Postgres:     $(get_state PG_FQDN)" \
    "Redis:        $(get_state REDIS_FQDN) (PRIVATE)" \
    "" \
    "Est. cost:    ~\$700/mo on-demand" \
    "              ~\$550/mo with 1-yr RIs" \
    "" \
    "Teardown:     ./azuresetup.sh --destroy" \
    "              (deletes the entire resource group)"
}

# ================================================================
# Destroy
# ================================================================

run_destroy() {
  print_banner "Destroy: Delete Resource Group"
  AZURE_RG="${AZURE_RG:-$(get_state AZURE_RG)}"
  [[ -z "$AZURE_RG" ]] && die "AZURE_RG not set in env or state"
  if ! $NON_INTERACTIVE; then
    if ! prompt_yesno "Delete resource group '$AZURE_RG' AND ALL RESOURCES in it?" n; then
      info "Aborted."
      exit 0
    fi
  fi
  az group delete -n "$AZURE_RG" --yes --no-wait
  ok "Delete initiated (running asynchronously). Track with:"
  ok "  az group show -n $AZURE_RG"
  rm -f "$SCRIPT_DIR/.azuresetup.state"
  ok "State file removed."
}

# ================================================================
# Main dispatch
# ================================================================

case "$PHASE" in
  1)       run_phase_1 ;;
  2)       run_phase_2 ;;
  3)       run_phase_3 ;;
  4)       run_phase_4 ;;
  all)     run_phase_1 && run_phase_2 && run_phase_3 && run_phase_4 ;;
  destroy) run_destroy ;;
esac
