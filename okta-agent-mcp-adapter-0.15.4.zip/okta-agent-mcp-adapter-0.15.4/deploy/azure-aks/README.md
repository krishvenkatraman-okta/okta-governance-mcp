# Okta MCP Adapter — AKS Production Deployment

## Overview

Production-grade deployment of the Okta MCP Adapter on Azure Kubernetes Service (AKS) Automatic with Azure Database for PostgreSQL Flexible Server (General Purpose), Azure Cache for Redis (Standard C1), and Application Gateway for Containers (AGC) ingress with managed TLS certificates. On-demand cost is approximately **$700/month**; see [deploy/HORIZONTAL_SCALING.md](../HORIZONTAL_SCALING.md) for detailed sizing and scaling guidance.

## Prerequisites

- Azure subscription with **Owner** or **Contributor** role
- CLI tools on the operator's machine: `az`, `kubectl`, `helm`, `jq`, `python3`, `openssl`
- Okta org with a Custom Authorization Server and an OIDC Web App configured
- Two DNS hostnames you control (`ADAPTER_HOSTNAME`, `ADMIN_HOSTNAME`)
- The Redis caching migration must be complete in the adapter codebase (verify with: `pytest tests/integration/test_redis_multipod.py`)

## Quick Start

```bash
cp .env.example .env
vi .env  # fill in required values
./azuresetup.sh           # runs all four phases
```

## Phases

| Phase | Name | Creates | Duration |
|-------|------|---------|----------|
| 1 | Foundation | RG, providers, ACR, VNet, AKS Automatic, workload identity | ~10 min |
| 2 | Stateful tier | Postgres GP, Redis Standard, Key Vault, 4 secrets | ~25 min |
| 3 | Application + ingress | Image build, K8s deploy, ALB controller, AGC, Gateway API | ~15 min + DNS |
| 4 | Smoke + lockdown | DNS check, Container Insights, 5 smoke tests, KV lockdown | ~5 min |

**Total ~55 min wall-clock.** Each phase is independently re-runnable:

```bash
./azuresetup.sh --phase 1
./azuresetup.sh --phase 2
```

## The DNS gap between Phase 3 and Phase 4

Phase 3 ends by creating the Application Gateway for Containers
(AGC) and capturing its public FQDN (something like
`abc123-xyz.eastus2.alb.azure.com`). Before you run Phase 4, you
must create CNAME records in your DNS provider pointing
`ADAPTER_HOSTNAME` and `ADMIN_HOSTNAME` at that FQDN:

```
mcp.example.com         CNAME   abc123-xyz.eastus2.alb.azure.com
admin-mcp.example.com   CNAME   abc123-xyz.eastus2.alb.azure.com
```

DNS propagation usually takes 5-30 minutes. After the CNAMEs have
propagated, the AGC managed certificate will provision itself
automatically (this can take an additional 15-30 minutes — AGC
needs to validate domain ownership via the DNS record before
issuing the cert).

When you run `./azuresetup.sh --phase 4`, the wizard first checks
that both hostnames resolve in DNS. If they don't, it fails fast
with a clear message rather than running smoke tests that would
all mysteriously return connection errors.

If DNS resolves but the smoke tests fail with TLS errors, the
managed cert has not yet been issued. Wait 15 minutes and try
again:

```bash
./azuresetup.sh --phase 4
```

Phase 4 is fully re-runnable — every step checks for "already
done" before doing work. Running it twice is harmless.

## Resume After Interruption

State is persisted to `.azuresetup.state` after each step. To resume:

```bash
./azuresetup.sh --phase <last-completed+1>
```

Or just rerun the current phase — every step checks "already exists" before creating.

## Non-Interactive Mode

For CI/CD, set every required env var in advance and pass:

```bash
./azuresetup.sh --non-interactive
```

## Teardown

```bash
./azuresetup.sh --destroy
```

This deletes the entire resource group. There is no surgical teardown — for that, use `kubectl delete` or write your own Terraform.

## Troubleshooting

- **"AKS provisioning stuck at 'Creating'"** — usually a quota issue in the target region. Check vCPU quotas with:
  ```bash
  az vm list-usage -l $AZURE_LOCATION --query "[?contains(name.value, 'standardDSv5Family')]"
  ```

- **"Federated credential creation fails"** — workload identity OIDC issuer is not yet propagated. Wait 60s and rerun Phase 1.

- **"AGC managed cert pending"** — DNS CNAME to AGC FQDN not yet propagated. Wait up to 30 min after DNS update.

### Phase 3 Common Issues

**Pods stuck Pending with "SecretProviderClass not found" in events**

The CSI driver pod hasn't come up yet. Wait 30s and check:

```
kubectl -n kube-system get pods -l app=secrets-store-csi-driver
```

**Pods in CrashLoopBackOff with "failed to get secret from keyvault"**

Workload identity RBAC is misconfigured. Check:

```
az role assignment list \
  --assignee $(get_state WORKLOAD_IDENTITY_PRINCIPAL_ID) \
  --scope $(az keyvault show -n $(get_state KV_NAME) --query id -o tsv)
```

Should show `Key Vault Secrets User`. If not, Phase 2 did not
complete cleanly — rerun Phase 2.

**ApplicationLoadBalancer stuck in "Creating"**

The ALB controller pod is probably in CrashLoopBackOff. Check:

```
kubectl logs -n azure-alb-system deployment/alb-controller
```

If you see "unable to find user assigned identity", the client
ID was not passed correctly to the Helm install. Check state
has `ALB_IDENTITY_CLIENT_ID` and re-run Phase 3.

If you see "403 Forbidden" on the AGC subnet, the
`AppGw for Containers Configuration Manager` role assignment
from AZ14 Step 3.5 didn't propagate in time. Wait 2 minutes
and re-run Phase 3.

**Gateway never gets a programmed address**

The ALB controller is running but the AppGw provisioning is
still in progress. This is normal — it can take up to 10 min.
The wizard polls for 5 min then gives up. Re-run Phase 3 if
it bailed out; the poll will resume.

### Key Vault Public Access Window

Phase 2 creates the Key Vault with public network access ENABLED so
the operator's local `az` CLI can write the three runtime secrets
(ENCRYPTION_KEY, DATABASE_URL, REDIS_URL). ADMIN_PASSWORD is no longer
written — admin API auth is Okta-OAuth-only (v0.15.x+).

Phase 4 disables public network access once the AKS pods have
successfully read the secrets via the Secrets Store CSI driver and
workload identity. Between Phase 2 and Phase 4 there is roughly a
15-minute window where the vault is reachable from the public
internet.

This window is intentional — locking down the vault before workload
identity RBAC is verified would risk a deployment where pods cannot
read their secrets and the only way to recover is to re-enable
public access manually.

If your security policy forbids public Key Vault access at any
point, run AZ7-AZ9 from a jumpbox VM inside the VNet and skip the
initial public-access window by passing `--public-network-access
Disabled` directly to `az keyvault create`. This requires a
jumpbox with `az` CLI installed and is out of scope for the wizard.

### CIMD / Confidential Relay Configuration

The adapter supports CIMD (Confidential Client Registration) for
dynamic MCP client onboarding, but the relay credentials are NOT
passed as environment variables to the adapter. Instead, they
live per-agent in PostgreSQL and are configured via the Admin UI
after deployment.

To enable CIMD for a specific agent after the wizard finishes:

1. Visit the Admin UI (https://<ADMIN_HOSTNAME>)
2. Navigate to Agents → <agent name> → Edit
3. Under "Okta OIDC Credentials", enter the client_id and
   client_secret for the relay OIDC application in your Okta org
4. Save

See `okta_agent_proxy/auth/confidential_relay.py` for the
implementation details. Earlier versions of this wizard treated
these credentials as global env vars — that was wrong and has
been corrected.
