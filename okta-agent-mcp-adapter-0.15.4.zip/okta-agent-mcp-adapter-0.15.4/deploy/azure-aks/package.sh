#!/usr/bin/env bash
set -euo pipefail

# =============================================================
# package.sh — Build a self-contained AKS deployment tarball
# =============================================================
# Run from the deploy/azure-aks/ directory or any location.
# Produces: okta-ps-adapter-azure-aks-${VERSION}.tar.gz
# =============================================================

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
REPO_ROOT="$(cd "$SCRIPT_DIR/../.." && pwd)"

# ---- Colors ----
if [[ -n "${NO_COLOR:-}" ]] || [[ ! -t 1 ]]; then
  RED='' GREEN='' YELLOW='' CYAN='' BOLD='' NC=''
else
  RED='\033[0;31m'
  GREEN='\033[0;32m'
  YELLOW='\033[1;33m'
  CYAN='\033[0;36m'
  BOLD='\033[1m'
  NC='\033[0m'
fi

info()  { printf "${CYAN}[INFO]${NC}  %b\n" "$*"; }
ok()    { printf "${GREEN}[  OK]${NC}  %b\n" "$*"; }
warn()  { printf "${YELLOW}[WARN]${NC}  %b\n" "$*" >&2; }
die()   { printf "${RED}[FAIL]${NC}  %b\n" "$*" >&2; exit 1; }

# ---- Defaults ----
VERSION=""
OUTPUT_DIR=""
DRY_RUN=false

# ---- Parse flags ----
while [[ $# -gt 0 ]]; do
  case "$1" in
    --version)    VERSION="$2"; shift 2 ;;
    --output-dir) OUTPUT_DIR="$2"; shift 2 ;;
    --dry-run)    DRY_RUN=true; shift ;;
    -h|--help)
      echo "Usage: package.sh [--version VERSION] [--output-dir DIR] [--dry-run]"
      echo ""
      echo "Builds a self-contained tarball for AKS production deployment."
      echo ""
      echo "Options:"
      echo "  --version VERSION   Override version (default: from pyproject.toml)"
      echo "  --output-dir DIR    Output directory (default: ./dist)"
      echo "  --dry-run           List files without creating tarball"
      exit 0
      ;;
    *) die "Unknown flag: $1" ;;
  esac
done

# Resolve version from pyproject.toml
if [[ -z "$VERSION" ]]; then
  PYPROJECT="$REPO_ROOT/pyproject.toml"
  if [[ -f "$PYPROJECT" ]]; then
    VERSION="$(grep -m1 '^version' "$PYPROJECT" | sed 's/.*= *"\(.*\)"/\1/')"
  fi
  VERSION="${VERSION:-dev}"
fi

# Resolve output dir
OUTPUT_DIR="${OUTPUT_DIR:-$SCRIPT_DIR/dist}"

STAGING_DIR="/tmp/okta-ps-adapter-azure-aks-${VERSION}"
TARBALL_NAME="okta-ps-adapter-azure-aks-${VERSION}.tar.gz"

info "Version:    ${BOLD}${VERSION}${NC}"
info "Output dir: ${OUTPUT_DIR}"
info "Staging:    ${STAGING_DIR}"
echo ""

# ---- Verify source files exist ----
[[ -f "$SCRIPT_DIR/azuresetup.sh" ]] || die "Cannot find azuresetup.sh in $SCRIPT_DIR"
[[ -d "$SCRIPT_DIR/shell-lib" ]]     || die "Cannot find shell-lib/ in $SCRIPT_DIR"
[[ -d "$SCRIPT_DIR/manifests" ]]     || die "Cannot find manifests/ in $SCRIPT_DIR"

# ---- Clean staging ----
rm -rf "$STAGING_DIR"
mkdir -p "$STAGING_DIR"

# ---- Copy included files ----
# The wizard expects REPO_ROOT two levels above SCRIPT_DIR.
# We replicate that layout: staging/deploy/azure-aks/<wizard files>
# and staging/ as the repo root with Dockerfile, source, etc.
info "Copying wizard and supporting files..."

WIZARD_DIR="$STAGING_DIR/deploy/azure-aks"
mkdir -p "$WIZARD_DIR"

cp "$SCRIPT_DIR/azuresetup.sh" "$WIZARD_DIR/"
cp -r "$SCRIPT_DIR/shell-lib" "$WIZARD_DIR/"
cp -r "$SCRIPT_DIR/manifests" "$WIZARD_DIR/"
cp "$SCRIPT_DIR/README.md" "$WIZARD_DIR/"
cp "$SCRIPT_DIR/.env.example" "$WIZARD_DIR/"

# Copy adapter source code needed for az acr build
info "Copying adapter source code..."
cp "$REPO_ROOT/LICENSE" "$STAGING_DIR/"
cp "$REPO_ROOT/Dockerfile" "$STAGING_DIR/"
cp "$REPO_ROOT/.dockerignore" "$STAGING_DIR/"
cp "$REPO_ROOT/requirements.txt" "$STAGING_DIR/"
cp "$REPO_ROOT/pyproject.toml" "$STAGING_DIR/"
cp -r "$REPO_ROOT/okta_agent_proxy" "$STAGING_DIR/"
cp -r "$REPO_ROOT/scripts" "$STAGING_DIR/"
# Raw SQL migrations (replaced Alembic in v0.15.0). The Dockerfile
# COPYs deploy/migrations/ into the image.
if [[ -d "$REPO_ROOT/deploy/migrations" ]]; then
  mkdir -p "$STAGING_DIR/deploy/migrations"
  cp -r "$REPO_ROOT/deploy/migrations/." "$STAGING_DIR/deploy/migrations/"
else
  die "Cannot find deploy/migrations in $REPO_ROOT (required by Dockerfile)"
fi

# Copy Admin UI source (needed for admin-ui container image)
if [[ -d "$REPO_ROOT/okta_agent_proxy_admin_ui" ]]; then
  info "Copying Admin UI source..."
  cp -r "$REPO_ROOT/okta_agent_proxy_admin_ui" "$STAGING_DIR/"
fi

# Copy example demo servers (needed for container image builds)
info "Copying example demo servers..."
mkdir -p "$STAGING_DIR/examples"
if [[ -d "$REPO_ROOT/examples/01-hr-system" ]]; then
  cp -r "$REPO_ROOT/examples/01-hr-system" "$STAGING_DIR/examples/"
fi
if [[ -d "$REPO_ROOT/examples/05-deploy-server" ]]; then
  cp -r "$REPO_ROOT/examples/05-deploy-server" "$STAGING_DIR/examples/"
fi

# ---- Remove excluded patterns ----
info "Cleaning excluded files..."
find "$STAGING_DIR" -name ".azuresetup.state" -delete 2>/dev/null || true
find "$STAGING_DIR" -name ".env" -not -name ".env.example" -delete 2>/dev/null || true
find "$STAGING_DIR" -type d -name "dist" -exec rm -rf {} + 2>/dev/null || true
find "$STAGING_DIR" -type d -name ".git" -exec rm -rf {} + 2>/dev/null || true
find "$STAGING_DIR" -name "CLAUDE.md" -delete 2>/dev/null || true
find "$STAGING_DIR" -type d -name "tests" -exec rm -rf {} + 2>/dev/null || true
find "$STAGING_DIR" -type d -name "__pycache__" -exec rm -rf {} + 2>/dev/null || true
find "$STAGING_DIR" -type d -name "node_modules" -exec rm -rf {} + 2>/dev/null || true
find "$STAGING_DIR" -type d -name ".next" -exec rm -rf {} + 2>/dev/null || true
find "$STAGING_DIR" -name "*.pyc" -delete 2>/dev/null || true
find "$STAGING_DIR" -name ".coverage" -delete 2>/dev/null || true
find "$STAGING_DIR" -name "*.docx" -delete 2>/dev/null || true
find "$STAGING_DIR" -name "*.pptx" -delete 2>/dev/null || true
find "$STAGING_DIR" -name "*.xlsx" -delete 2>/dev/null || true

# ---- File listing ----
FILE_COUNT=$(find "$STAGING_DIR" -type f | wc -l | tr -d ' ')
TOTAL_SIZE=$(du -sh "$STAGING_DIR" | cut -f1)

echo ""
info "Package contents: ${BOLD}${FILE_COUNT}${NC} files, ${BOLD}${TOTAL_SIZE}${NC}"
echo ""

if $DRY_RUN; then
  info "${YELLOW}--dry-run${NC}: listing files (no tarball created)"
  echo ""
  (cd /tmp && find "okta-ps-adapter-azure-aks-${VERSION}" -type f | sort)
  echo ""
  info "Total: ${FILE_COUNT} files, ${TOTAL_SIZE}"
  rm -rf "$STAGING_DIR"
  exit 0
fi

# ---- Create tarball ----
info "Creating tarball..."
mkdir -p "$OUTPUT_DIR"
(cd /tmp && tar czf "${OUTPUT_DIR}/${TARBALL_NAME}" "okta-ps-adapter-azure-aks-${VERSION}")

TARBALL_PATH="${OUTPUT_DIR}/${TARBALL_NAME}"
TARBALL_SIZE=$(du -h "$TARBALL_PATH" | cut -f1)
CHECKSUM=$(shasum -a 256 "$TARBALL_PATH" | cut -d' ' -f1)

# ---- Cleanup ----
rm -rf "$STAGING_DIR"

# ---- Summary ----
echo ""
ok "Tarball created: ${BOLD}${TARBALL_PATH}${NC}"
echo ""
printf "  %-12s %s\n" "Files:" "$FILE_COUNT"
printf "  %-12s %s\n" "Unpacked:" "$TOTAL_SIZE"
printf "  %-12s %s\n" "Compressed:" "$TARBALL_SIZE"
printf "  %-12s %s\n" "SHA-256:" "$CHECKSUM"
echo ""
