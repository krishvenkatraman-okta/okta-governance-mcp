#!/usr/bin/env bash
set -euo pipefail
# =============================================================
# preflight-enterprise.sh — BYO resource validator
# =============================================================
# Standalone check: probes every BYO env var that is set and
# verifies the target resource exists and is in a usable state.
# Fails fast with a clear message citing the env var name.
#
# Run directly OR sourced by scripts/deploy.sh.
# =============================================================

SCRIPT_DIR="$(cd "$(dirname "$0")/.." && pwd)"
cd "$SCRIPT_DIR"

source "$SCRIPT_DIR/shell-lib/common.sh"

# Check every env var; skip if empty.
errors=0
warnings=0

probe_resource() {
  # probe_resource VAR_NAME DESCRIPTION [EXPECTED_TYPE]
  local var_name="$1" desc="$2" expected_type="${3:-}"
  local value="${!var_name:-}"
  [[ -z "$value" ]] && return 0

  info "Probing $desc ($var_name) ..."
  if ! az resource show --ids "$value" &>/dev/null; then
    fail "  ✗ $var_name points to a resource that does not exist or is inaccessible: $value"
    errors=$((errors + 1))
    return 1
  fi

  if [[ -n "$expected_type" ]]; then
    local actual_type
    actual_type=$(az resource show --ids "$value" --query type -o tsv 2>/dev/null || echo "unknown")
    if [[ "$actual_type" != "$expected_type" ]]; then
      fail "  ✗ $var_name expected type '$expected_type' but got '$actual_type': $value"
      errors=$((errors + 1))
      return 1
    fi
  fi

  ok "  ✓ $desc exists"
  return 0
}

probe_subnet() {
  # probe_subnet VAR_NAME DESCRIPTION [MIN_PREFIX_LEN]
  local var_name="$1" desc="$2" min_prefix="${3:-0}"
  local value="${!var_name:-}"
  [[ -z "$value" ]] && return 0

  info "Probing $desc subnet ($var_name) ..."
  local subnet_json
  subnet_json=$(az network vnet subnet show --ids "$value" -o json 2>/dev/null || echo "")
  if [[ -z "$subnet_json" ]]; then
    fail "  ✗ $var_name points to a subnet that does not exist: $value"
    errors=$((errors + 1))
    return 1
  fi

  local prefix
  prefix=$(echo "$subnet_json" | jq -r '.addressPrefix // empty')
  local prefix_len="${prefix##*/}"
  if [[ -n "$min_prefix" && "$min_prefix" -gt 0 ]]; then
    if [[ "$prefix_len" -gt "$min_prefix" ]]; then
      fail "  ✗ $desc subnet is /$prefix_len; needs to be /$min_prefix or larger (bigger range)"
      errors=$((errors + 1))
      return 1
    fi
  fi

  if [[ "$var_name" == *"PE"* ]]; then
    local pe_policies
    pe_policies=$(echo "$subnet_json" | jq -r '.privateEndpointNetworkPolicies // "Enabled"')
    if [[ "$pe_policies" != "Disabled" ]]; then
      warn "  ⚠ $desc subnet has privateEndpointNetworkPolicies=$pe_policies; recommended: Disabled"
      warnings=$((warnings + 1))
    fi
  fi

  ok "  ✓ $desc subnet OK ($prefix)"
  return 0
}

probe_postgres() {
  local value="${EXISTING_PG_SERVER_ID:-}"
  [[ -z "$value" ]] && return 0

  info "Probing EXISTING_PG_SERVER_ID ..."
  local state
  state=$(az postgres flexible-server show --ids "$value" --query state -o tsv 2>/dev/null || echo "")
  if [[ -z "$state" ]]; then
    fail "  ✗ EXISTING_PG_SERVER_ID resource does not exist or is not a flex server: $value"
    errors=$((errors + 1))
    return 1
  fi
  if [[ "$state" != "Ready" ]]; then
    warn "  ⚠ Postgres server state is '$state' (expected 'Ready')"
    warnings=$((warnings + 1))
  fi
  ok "  ✓ Postgres Flexible Server reachable (state=$state)"
}

probe_redis() {
  local value="${EXISTING_REDIS_ID:-}"
  [[ -z "$value" ]] && return 0

  info "Probing EXISTING_REDIS_ID ..."
  local state
  state=$(az redis show --ids "$value" --query provisioningState -o tsv 2>/dev/null || echo "")
  if [[ -z "$state" ]]; then
    fail "  ✗ EXISTING_REDIS_ID resource does not exist: $value"
    errors=$((errors + 1))
    return 1
  fi
  if [[ "$state" != "Succeeded" ]]; then
    warn "  ⚠ Redis provisioningState is '$state' (expected 'Succeeded')"
    warnings=$((warnings + 1))
  fi
  ok "  ✓ Redis cache reachable (state=$state)"
}

probe_dns_zone() {
  local value="${EXISTING_DNS_ZONE_ID:-}"
  [[ -z "$value" ]] && return 0
  [[ "${DNS_PROVIDER:-none}" == "none" || "${DNS_PROVIDER}" == "external" ]] && return 0

  info "Probing EXISTING_DNS_ZONE_ID ..."
  local result
  result=$(az network dns zone show --ids "$value" --query name -o tsv 2>/dev/null || echo "")
  if [[ -z "$result" ]]; then
    fail "  ✗ EXISTING_DNS_ZONE_ID zone does not exist: $value"
    errors=$((errors + 1))
    return 1
  fi
  ok "  ✓ DNS zone '$result' reachable"
}

probe_existing_rg() {
  local value="${EXISTING_RG_NAME:-}"
  [[ -z "$value" ]] && return 0

  info "Probing EXISTING_RG_NAME ..."
  if ! az group show --name "$value" &>/dev/null; then
    fail "  ✗ Resource group '$value' does not exist or is inaccessible"
    errors=$((errors + 1))
    return 1
  fi
  ok "  ✓ Resource group '$value' exists"
}

main() {
  info "Running enterprise BYO preflight …"
  echo ""

  # Login check
  if ! az account show &>/dev/null; then
    die "Not logged into Azure. Run 'az login' first."
  fi

  probe_existing_rg
  probe_resource EXISTING_VNET_ID          "VNet"                     "Microsoft.Network/virtualNetworks"
  probe_subnet   EXISTING_ACA_SUBNET_ID    "ACA infrastructure"       23
  probe_subnet   EXISTING_PE_SUBNET_ID     "Private endpoints"        0
  probe_resource EXISTING_PG_DNS_ZONE_ID    "Postgres private DNS zone" "Microsoft.Network/privateDnsZones"
  probe_resource EXISTING_REDIS_DNS_ZONE_ID "Redis private DNS zone"    "Microsoft.Network/privateDnsZones"
  probe_postgres
  probe_redis
  probe_resource EXISTING_ACR_ID           "Azure Container Registry" "Microsoft.ContainerRegistry/registries"
  probe_resource EXISTING_LAW_ID           "Log Analytics workspace"  "Microsoft.OperationalInsights/workspaces"
  probe_resource EXISTING_ACA_ENV_ID       "ACA Managed Environment"  "Microsoft.App/managedEnvironments"
  probe_resource EXISTING_KEY_VAULT_ID     "Key Vault"                "Microsoft.KeyVault/vaults"
  probe_resource EXISTING_UAMI_ID          "User-Assigned Managed Identity" "Microsoft.ManagedIdentity/userAssignedIdentities"
  probe_dns_zone
  probe_resource EXISTING_APP_GATEWAY_ID   "Application Gateway"      "Microsoft.Network/applicationGateways"
  probe_resource EXISTING_FRONT_DOOR_ID    "Front Door profile"       "Microsoft.Cdn/profiles"
  probe_resource EXISTING_CMK_KEY_ID_POSTGRES "Postgres CMK"          ""
  probe_resource EXISTING_CMK_KEY_ID_LAW     "Log Analytics CMK"      ""
  probe_resource EXISTING_CMK_KEY_ID_KV      "Key Vault CMK"          ""

  echo ""
  if [[ "$errors" -gt 0 ]]; then
    die "Preflight failed with $errors error(s) and $warnings warning(s). Fix the BYO inputs above and re-run."
  elif [[ "$warnings" -gt 0 ]]; then
    warn "Preflight passed with $warnings warning(s). Review above before proceeding."
  else
    ok "Preflight passed — all BYO resources validated."
  fi
}

# Only run main() if executed directly, not when sourced
if [[ "${BASH_SOURCE[0]}" == "${0}" ]]; then
  # Load .env if present
  if [[ -f "$SCRIPT_DIR/.env" ]]; then
    set -a; source "$SCRIPT_DIR/.env"; set +a
  fi
  STATE_FILE="${STATE_FILE:-$SCRIPT_DIR/.deploy.state}"
  main "$@"
fi
