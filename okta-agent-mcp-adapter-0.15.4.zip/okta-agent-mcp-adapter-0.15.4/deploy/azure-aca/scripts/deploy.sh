#!/usr/bin/env bash
set -euo pipefail
# =============================================================
# deploy.sh — Main deployment wrapper (full Bicep)
# =============================================================
# Default: pulls prebuilt images from
#   public.ecr.aws/${ECR_PUBLIC_ALIAS:-oktaps}/okta-mcp-{adapter,admin-ui,hr-server,deploy-server}
# at tag v<pyproject version>. No ACR, no build — single Bicep deploy.
#
# Usage:
#   ./scripts/deploy.sh [--yes] [--skip-preflight] [--what-if] [--destroy]
#   ./scripts/deploy.sh --build-from-source [--skip-build] [--tag=v…]
#
# Flow:
#   Phase 0:  load .env + state, collect BYO prompts, generate secrets
#   Phase 1:  preflight-enterprise.sh probes every BYO input
#   Phase 2:  az deployment sub what-if (preview, apps-included)
#
#   Default path (no --build-from-source):
#     Phase 3:  single bicep_deploy (deployApps=true, usePublicImages=true).
#               No ACR provisioned, no build.
#
#   Build path (--build-from-source):
#     Phase 3a: bicep_deploy deployApps=false — creates ACR + the rest of infra
#     Phase 3b: az acr build — push images into ACR (skippable with --skip-build)
#     Phase 3c: bicep_deploy deployApps=true — Container Apps resolve images
#
#   Phase 4:  DB bootstrap via ACA Job (+ optional operator handoff)
#   Phase 5:  smoke-test.sh
#   Phase 6:  summary
# =============================================================

SCRIPT_DIR="$(cd "$(dirname "$0")/.." && pwd)"
cd "$SCRIPT_DIR"

source "$SCRIPT_DIR/shell-lib/common.sh"
source "$SCRIPT_DIR/shell-lib/azure-helpers.sh"
source "$SCRIPT_DIR/shell-lib/bicep-helpers.sh"
# Cross-cloud DB bootstrap helper (P15). Lives in the top-level shell-lib
# so AWS scripts can share it. info()/ok()/warn()/die() are already defined
# by common.sh above.
# shellcheck disable=SC1091
source "$SCRIPT_DIR/../shell-lib/db_bootstrap.sh"

STATE_FILE="$SCRIPT_DIR/.deploy.state"
export STATE_FILE

# ---- Flags ----
YES=false
SKIP_PREFLIGHT=false
SKIP_BUILD=false
WHAT_IF_ONLY=false
DESTROY=false
NO_BOOTSTRAP=false
MIGRATE_ONLY=false
BUILD_FROM_SOURCE=false
PUBLIC_IMAGE_TAG=""

while [[ $# -gt 0 ]]; do
  case "$1" in
    --yes|-y)              YES=true; shift ;;
    --skip-preflight)      SKIP_PREFLIGHT=true; shift ;;
    --skip-build)          SKIP_BUILD=true; shift ;;
    --what-if)             WHAT_IF_ONLY=true; shift ;;
    --destroy)             DESTROY=true; shift ;;
    --no-bootstrap)        NO_BOOTSTRAP=true; shift ;;
    --migrate-only)        MIGRATE_ONLY=true; shift ;;
    --build-from-source)   BUILD_FROM_SOURCE=true; shift ;;
    --tag=*)               PUBLIC_IMAGE_TAG="${1#--tag=}"; shift ;;
    -h|--help)
      cat <<'USAGE'
Usage: ./scripts/deploy.sh [options]

Deploys the Okta MCP Adapter on Azure Container Apps.

Default path: pulls prebuilt images from public.ecr.aws/${ECR_PUBLIC_ALIAS:-oktaps}/
at tag v<pyproject version>. No ACR provisioned, no build.

Options:
  --yes, -y            Skip the what-if confirmation prompt (for CI).
  --skip-preflight     Skip the BYO resource probe (use with care).
  --what-if            Render the bicepparam, run what-if, then exit.
  --destroy            Invoke scripts/destroy.sh (BYO-safe teardown).
  --no-bootstrap       Skip the DB bootstrap job; print operator handoff.
                       Equivalent to RUN_DB_BOOTSTRAP=false.
  --migrate-only       Skip infra/apps; only run the DB bootstrap step.
                       (Reads existing state; requires a prior successful deploy.)
  --tag=vX.Y.Z         Override the public-image tag. Accepts 'latest' or any
                       published tag. Ignored with a warning when --build-from-source.

Build-from-source (opt-in) options:
  --build-from-source  Opt out of public images. Provisions ACR in this
                       subscription, runs `az acr build` for all four images,
                       deploys Container Apps pointing at ACR.
  --skip-build         Skip `az acr build` — use images already in ACR.
                       Only valid with --build-from-source.

  -h, --help           Show this help.

Environment variables (P15):
  RUN_DB_BOOTSTRAP=true|false
      true  (default): run the migrate Container Apps Job as part of deploy.
      false          : skip; print an operator handoff block. Same as --no-bootstrap.
  DB_BOOTSTRAP_FORCE_LOCAL=true|false
      Skip the ACA Job attempt and run bootstrap from the deploy host.
      Only meaningful when the host can reach Postgres (not typical in
      private-endpoint deployments).
  DB_BOOTSTRAP_TIMEOUT=<seconds>
      Max seconds to wait for the ACA Job (default 600).

BYO configuration:
  Every BYO knob is driven by env vars. See .env.byo.example for
  the full list. Unset = wizard creates the resource; set = reuse.

Quick BYO overview:
  Network:    USE_EXISTING_VNET, EXISTING_VNET_ID, EXISTING_ACA_SUBNET_ID,
              EXISTING_PE_SUBNET_ID, EXISTING_PG_DNS_ZONE_ID, EXISTING_REDIS_DNS_ZONE_ID
  Data:       USE_EXISTING_POSTGRES, EXISTING_PG_SERVER_ID,
              USE_EXISTING_REDIS, EXISTING_REDIS_ID
  Platform:   BYO_ACR, EXISTING_ACR_ID, EXISTING_ACR_LOGIN_SERVER,
              BYO_LOG_ANALYTICS, EXISTING_LAW_ID,
              BYO_ACA_ENV, EXISTING_ACA_ENV_ID
  Security:   USE_KEY_VAULT, EXISTING_KEY_VAULT_ID,
              BYO_UAMI, EXISTING_UAMI_ID,
              EXISTING_CMK_KEY_ID_POSTGRES, EXISTING_CMK_KEY_ID_LAW,
              EXISTING_CMK_KEY_ID_KV
  DNS:        DNS_PROVIDER (none|azure_dns|delegated|external),
              EXISTING_DNS_ZONE_ID, ADAPTER_HOSTNAME, ADMIN_HOSTNAME
  Upstream:   UPSTREAM_INGRESS (none|app_gateway|front_door)
USAGE
      exit 0
      ;;
    *) die "Unknown flag: $1 (use --help)" ;;
  esac
done

if $DESTROY; then
  exec "$SCRIPT_DIR/scripts/destroy.sh" "$@"
fi

# --build-from-source requires the source tree at ../../. If it's missing
# this is the deploy-only packaged tarball. Fail fast with a concrete fix
# before touching Azure or prompting the user.
if $BUILD_FROM_SOURCE; then
  for required in Dockerfile okta_agent_proxy; do
    if [[ ! -e "$SCRIPT_DIR/../../$required" ]]; then
      printf '\033[0;31m[FAIL]\033[0m  --build-from-source requires the source tree (missing: ../../%s).\n\n' "$required" >&2
      printf '  This looks like the deploy-only bundle. To build from source, either:\n' >&2
      printf '    - Extract the okta-ps-adapter-azure-aca-source-<version>.tar.gz bundle, or\n' >&2
      printf '    - Run from a git checkout of the repository.\n\n' >&2
      printf '  Otherwise drop --build-from-source to pull prebuilt images from ECR Public.\n' >&2
      exit 1
    fi
  done
fi

# ---- Load .env ----
if [[ -f "$SCRIPT_DIR/.env" ]]; then
  set -a; source "$SCRIPT_DIR/.env"; set +a
fi

# =============================================================
# Phase 0 — Reuse configuration + secret generation
# =============================================================

print_banner() {
  local title="$1"
  echo ""
  printf "${CYAN}┌──────────────────────────────────────────────────┐${NC}\n"
  printf "${CYAN}│${NC}  ${BOLD}%-48s${NC}${CYAN}│${NC}\n" "$title"
  printf "${CYAN}└──────────────────────────────────────────────────┘${NC}\n"
  echo ""
}

print_banner "Phase 0: Configuration"

# Validate tooling + login
bicep_preflight
az_login_check

# Resolve subscription + location
if [[ -z "${AZURE_SUBSCRIPTION_ID:-}" ]]; then
  AZURE_SUBSCRIPTION_ID="$(get_state AZURE_SUBSCRIPTION_ID)"
  [[ -z "$AZURE_SUBSCRIPTION_ID" ]] && prompt_required AZURE_SUBSCRIPTION_ID "Azure subscription ID"
fi
az account set --subscription "$AZURE_SUBSCRIPTION_ID"
save_state AZURE_SUBSCRIPTION_ID "$AZURE_SUBSCRIPTION_ID"

AZURE_LOCATION="${AZURE_LOCATION:-$(get_state AZURE_LOCATION)}"
[[ -z "$AZURE_LOCATION" ]] && prompt_default AZURE_LOCATION "Azure region" "eastus2"
save_state AZURE_LOCATION "$AZURE_LOCATION"
export AZURE_LOCATION

# RG — create or BYO
if [[ -z "${EXISTING_RG_NAME:-}" ]] && ! $YES; then
  if prompt_yesno "Deploy into an existing resource group?" "n"; then
    prompt_required EXISTING_RG_NAME "Existing resource group name"
  fi
fi

if [[ -n "${EXISTING_RG_NAME:-}" ]]; then
  save_state EXISTING_RG_NAME "$EXISTING_RG_NAME"
  export EXISTING_RG_NAME
  AZURE_RG="$EXISTING_RG_NAME"
else
  AZURE_RG="${AZURE_RG:-$(get_state AZURE_RG)}"
  [[ -z "$AZURE_RG" ]] && AZURE_RG="okta-ps-adapter-demo"
  save_state AZURE_RG "$AZURE_RG"
  export AZURE_RG
fi

# Okta configuration (required for Phase 3)
OKTA_DOMAIN="${OKTA_DOMAIN:-$(get_state OKTA_DOMAIN)}"
[[ -z "$OKTA_DOMAIN" ]] && prompt_required OKTA_DOMAIN "Okta org domain (e.g. dev-12345.okta.com)"
save_state OKTA_DOMAIN "$OKTA_DOMAIN"
export OKTA_DOMAIN

# Admin UI Okta OIDC app
ADMIN_UI_OKTA_CLIENT_ID="${ADMIN_UI_OKTA_CLIENT_ID:-$(get_state ADMIN_UI_OKTA_CLIENT_ID)}"
[[ -z "$ADMIN_UI_OKTA_CLIENT_ID" ]] && prompt_required ADMIN_UI_OKTA_CLIENT_ID "Admin UI Okta OIDC client ID"
save_state ADMIN_UI_OKTA_CLIENT_ID "$ADMIN_UI_OKTA_CLIENT_ID"
export ADMIN_UI_OKTA_CLIENT_ID

ADMIN_UI_OKTA_CLIENT_SECRET="${ADMIN_UI_OKTA_CLIENT_SECRET:-$(get_state ADMIN_UI_OKTA_CLIENT_SECRET)}"
[[ -z "$ADMIN_UI_OKTA_CLIENT_SECRET" ]] && prompt_required ADMIN_UI_OKTA_CLIENT_SECRET "Admin UI Okta OIDC client secret"
save_state ADMIN_UI_OKTA_CLIENT_SECRET "$ADMIN_UI_OKTA_CLIENT_SECRET"
export ADMIN_UI_OKTA_CLIENT_SECRET

# Deploy server (optional)
DEPLOY_OKTA_CLIENT_ID="${DEPLOY_OKTA_CLIENT_ID:-$(get_state DEPLOY_OKTA_CLIENT_ID)}"
save_state DEPLOY_OKTA_CLIENT_ID "$DEPLOY_OKTA_CLIENT_ID"
export DEPLOY_OKTA_CLIENT_ID
DEPLOY_OKTA_AUTH_SERVER_ID="${DEPLOY_OKTA_AUTH_SERVER_ID:-$(get_state DEPLOY_OKTA_AUTH_SERVER_ID)}"
save_state DEPLOY_OKTA_AUTH_SERVER_ID "$DEPLOY_OKTA_AUTH_SERVER_ID"
export DEPLOY_OKTA_AUTH_SERVER_ID
DEPLOY_OKTA_AUDIENCE="${DEPLOY_OKTA_AUDIENCE:-$(get_state DEPLOY_OKTA_AUDIENCE)}"
save_state DEPLOY_OKTA_AUDIENCE "$DEPLOY_OKTA_AUDIENCE"
export DEPLOY_OKTA_AUDIENCE

# Secrets — generate once, persist
ensure_secret() {
  local key="$1" size="${2:-32}"
  local v
  v="$(get_state "$key")"
  if [[ -z "$v" ]]; then
    v="$(openssl rand -base64 "$size" | tr -d '\n')"
    save_state "$key" "$v"
  fi
  export "$key"="$v"
}

ensure_secret ENCRYPTION_KEY 32
ensure_secret NEXTAUTH_SECRET 48
ensure_secret HR_PSK_SECRET 32
ensure_secret PG_ADMIN_PASSWORD 24

# ---- Image source wiring ----
# Default path: pull from public.ecr.aws/${ECR_PUBLIC_ALIAS:-oktaps}/ at the
# repo's current pyproject version. Bicep is steered via USE_PUBLIC_IMAGES +
# PUBLIC_IMAGE_REGISTRY env vars that main.bicepparam reads.
#
# --build-from-source path: keep today's behavior — timestamped tag, ACR
# provisioned, three-phase apply with az acr build in the middle.
if $BUILD_FROM_SOURCE; then
  if [[ -n "$PUBLIC_IMAGE_TAG" ]]; then
    warn "--tag=${PUBLIC_IMAGE_TAG} ignored when --build-from-source is set."
  fi

  IMAGE_TAG="${IMAGE_TAG:-v$(date +%Y%m%d-%H%M%S)}"
  export USE_PUBLIC_IMAGES=false
else
  if [[ -z "$PUBLIC_IMAGE_TAG" ]]; then
    PYPROJECT="$SCRIPT_DIR/../../pyproject.toml"
    if [[ -f "$PYPROJECT" ]]; then
      VERSION=$(grep -m1 '^version' "$PYPROJECT" | sed 's/.*= *"\(.*\)"/\1/')
      [[ -n "$VERSION" ]] && PUBLIC_IMAGE_TAG="v${VERSION}"
    fi
    [[ -n "$PUBLIC_IMAGE_TAG" ]] || die "Could not resolve version from pyproject.toml; pass --tag= explicitly."
  fi

  IMAGE_TAG="$PUBLIC_IMAGE_TAG"
  ECR_PUBLIC_ALIAS="${ECR_PUBLIC_ALIAS:-oktaps}"
  export USE_PUBLIC_IMAGES=true
  export PUBLIC_IMAGE_REGISTRY="public.ecr.aws/${ECR_PUBLIC_ALIAS}"

  # --skip-build without --build-from-source is a no-op — the public path
  # has nothing to build. Warn so the user knows nothing happened.
  if $SKIP_BUILD; then
    warn "--skip-build has no effect on the default (public-image) path. Dropping it."
    SKIP_BUILD=false
  fi
fi
save_state IMAGE_TAG "$IMAGE_TAG"
export IMAGE_TAG

ok "Configuration collected. State: $STATE_FILE"
if $BUILD_FROM_SOURCE; then
  ok "Image source: ACR (built in this subscription) @ ${IMAGE_TAG}"
else
  ok "Image source: ${PUBLIC_IMAGE_REGISTRY}/okta-mcp-{adapter,admin-ui,hr-server,deploy-server}:${IMAGE_TAG}"
fi

# =============================================================
# --migrate-only short-circuit (P15)
# =============================================================
# Skip infra/apps deploy; jump straight to Phase 4 using values saved
# by a prior successful deploy. Idempotent — running it twice changes
# nothing on the second run.
if $MIGRATE_ONLY; then
  print_banner "Migrate-only mode"
  RESOURCE_GROUP="$(get_state RESOURCE_GROUP)"
  MIGRATE_JOB_NAME="$(get_state MIGRATE_JOB_NAME)"
  DEPLOYMENT_NAME="$(get_state DEPLOYMENT_NAME)"
  [[ -n "$RESOURCE_GROUP" && -n "$MIGRATE_JOB_NAME" ]] || die \
    "--migrate-only requires a prior successful deploy (RESOURCE_GROUP / MIGRATE_JOB_NAME not in state)."
  info "Using state from prior deploy: $DEPLOYMENT_NAME"

  export PLATFORM=azure
  export AZURE_RG="$RESOURCE_GROUP"
  export MIGRATE_JOB_NAME
  export DB_HOST="$(bicep_output postgresServerFqdn "$DEPLOYMENT_NAME" 2>/dev/null || echo "")"
  export DB_PORT=5432
  export DB_NAME="${POSTGRES_DATABASE_NAME:-gateway_db}"
  export DB_OWNER_ROLE="${DB_OWNER_ROLE:-okta_adapter_owner}"
  export DB_APP_ROLE="${DB_APP_ROLE:-okta_adapter_app}"
  export ENTRA_OWNER_PRINCIPAL="${ENTRA_OWNER_PRINCIPAL:-${ADAPTER_OWNER_UAMI_NAME:-}}"
  export PG_MASTER_USER="${PG_MASTER_USER:-${POSTGRES_ADMIN_USER:-pgadmin}}"
  export PG_MASTER_PASSWORD="${PG_ADMIN_PASSWORD:-}"
  export MIGRATIONS_DIR="$SCRIPT_DIR/../migrations/sql"
  export DB_BOOTSTRAP_TIMEOUT=900
  if $NO_BOOTSTRAP; then
    export RUN_DB_BOOTSTRAP=false
  fi

  db_bootstrap_run
  ok "Migrate-only complete."
  exit 0
fi

# =============================================================
# Phase 1 — Preflight (BYO probe)
# =============================================================

if ! $SKIP_PREFLIGHT; then
  print_banner "Phase 1: Preflight (BYO validation)"
  bash "$SCRIPT_DIR/scripts/preflight-enterprise.sh"
fi

# =============================================================
# Phase 2 — Render bicepparam + what-if preview
# =============================================================

print_banner "Phase 2: Preview (what-if)"

bicep_export_env

DEPLOYMENT_NAME="okta-ps-adapter-$(date +%Y%m%d-%H%M%S)"

# Decide which bicepparam file to use. If main.bicepparam was
# hand-edited (version-controlled enterprise config), keep it.
# Otherwise, use the demo default.
BICEPPARAM_FILE="$SCRIPT_DIR/bicep/main.bicepparam"

info "Running what-if against $BICEPPARAM_FILE ..."
bicep_what_if "$AZURE_LOCATION" "$BICEPPARAM_FILE"

if $WHAT_IF_ONLY; then
  ok "what-if complete. --what-if set; exiting."
  exit 0
fi

bicep_confirm_apply

# =============================================================
# Phase 3 — Deploy (build-from-source runs three phases;
#           default public-image path is a single deploy).
# =============================================================

if $BUILD_FROM_SOURCE; then
  # Phase 3a: infra + ACR only.
  print_banner "Phase 3a: Deploy infrastructure"
  INFRA_DEP_NAME="${DEPLOYMENT_NAME}-infra"
  info "Deploying $INFRA_DEP_NAME (deployApps=false) ..."
  bicep_deploy "$AZURE_LOCATION" "$BICEPPARAM_FILE" "$INFRA_DEP_NAME" deployApps=false

  ACR_LOGIN_SERVER="$(bicep_output acrLoginServer "$INFRA_DEP_NAME")"
  RESOURCE_GROUP="$(bicep_output resourceGroupName "$INFRA_DEP_NAME")"
  save_state ACR_LOGIN_SERVER "$ACR_LOGIN_SERVER"
  save_state RESOURCE_GROUP "$RESOURCE_GROUP"
  ok "Infrastructure ready — ACR: $ACR_LOGIN_SERVER"

  # Phase 3b: build + push (skippable).
  if ! $SKIP_BUILD; then
    print_banner "Phase 3b: Build + push images"
    bash "$SCRIPT_DIR/scripts/build-images.sh" --build-only
  fi

  # Phase 3c: Container Apps.
  print_banner "Phase 3c: Deploy Container Apps"
  info "Deploying $DEPLOYMENT_NAME (deployApps=true) ..."
  bicep_deploy "$AZURE_LOCATION" "$BICEPPARAM_FILE" "$DEPLOYMENT_NAME" deployApps=true
else
  # Default path: single deploy. No ACR, no build — images pulled from
  # public.ecr.aws at runtime.
  print_banner "Phase 3: Deploy (public images, single pass)"
  info "Deploying $DEPLOYMENT_NAME (deployApps=true, usePublicImages=true) ..."
  bicep_deploy "$AZURE_LOCATION" "$BICEPPARAM_FILE" "$DEPLOYMENT_NAME" deployApps=true
  RESOURCE_GROUP="$(bicep_output resourceGroupName "$DEPLOYMENT_NAME")"
  ACR_LOGIN_SERVER=""
  save_state RESOURCE_GROUP "$RESOURCE_GROUP"
  save_state ACR_LOGIN_SERVER ""
fi

ADAPTER_FQDN="$(bicep_output adapterFqdn "$DEPLOYMENT_NAME")"
ADMIN_UI_FQDN="$(bicep_output adminUiFqdn "$DEPLOYMENT_NAME")"
MIGRATE_JOB_NAME="$(bicep_output migrateJobName "$DEPLOYMENT_NAME" 2>/dev/null || echo "")"

save_state ADAPTER_FQDN "$ADAPTER_FQDN"
save_state ADMIN_UI_FQDN "$ADMIN_UI_FQDN"
save_state DEPLOYMENT_NAME "$DEPLOYMENT_NAME"
save_state MIGRATE_JOB_NAME "$MIGRATE_JOB_NAME"

ok "Deployment complete."

# =============================================================
# Phase 4 — Bootstrap DB roles + apply migrations
# =============================================================
# Fires the ACA Job created by migrate-job.bicep. The job connects
# to Postgres as the owner UAMI (Entra admin), runs bootstrap_roles.sql,
# registers the app + owner Entra principals, and applies pending
# schema migrations. Skipped when entraAuthEnabled=false (legacy path).

# Phase 4 — DB bootstrap (role + migrate) via the shared helper. Delegates to
# the ACA Job deployed by migrate-job.bicep (which already runs
# bootstrap_roles.sql + Entra principal registration + the migrate runner as
# a single unit). When RUN_DB_BOOTSTRAP=false the helper prints an operator
# handoff block and returns without executing anything.
if [[ -n "$MIGRATE_JOB_NAME" ]]; then
  print_banner "Phase 4: Bootstrap DB roles + apply migrations"

  # Caller contract for db_bootstrap_run
  export PLATFORM=azure
  export AZURE_RG="$RESOURCE_GROUP"
  export MIGRATE_JOB_NAME
  export DB_HOST="$(bicep_output postgresServerFqdn "$DEPLOYMENT_NAME" 2>/dev/null || echo "")"
  export DB_PORT=5432
  export DB_NAME="${POSTGRES_DATABASE_NAME:-gateway_db}"
  export DB_OWNER_ROLE="${DB_OWNER_ROLE:-okta_adapter_owner}"
  export DB_APP_ROLE="${DB_APP_ROLE:-okta_adapter_app}"
  export ENTRA_OWNER_PRINCIPAL="${ENTRA_OWNER_PRINCIPAL:-${ADAPTER_OWNER_UAMI_NAME:-}}"
  export PG_MASTER_USER="${PG_MASTER_USER:-${POSTGRES_ADMIN_USER:-pgadmin}}"
  export PG_MASTER_PASSWORD="${PG_ADMIN_PASSWORD:-}"
  export MIGRATIONS_DIR="$SCRIPT_DIR/../migrations/sql"
  # ACA migrate job container has replicaTimeout=900; give the helper the
  # same budget.
  export DB_BOOTSTRAP_TIMEOUT=900
  if $NO_BOOTSTRAP; then
    export RUN_DB_BOOTSTRAP=false
  fi

  db_bootstrap_run
else
  warn "No migrate job deployed (entraAuthEnabled=false). Run migrations manually against DATABASE_URL."
fi

# =============================================================
# Phase 5 — Smoke test
# =============================================================

print_banner "Phase 5: Smoke test"
bash "$SCRIPT_DIR/scripts/smoke-test.sh" || warn "Smoke test reported issues — see above."

# =============================================================
# Phase 6 — Summary
# =============================================================

print_banner "Done"
if $BUILD_FROM_SOURCE; then
  IMAGE_SOURCE_LINE="ACR login:       ${ACR_LOGIN_SERVER} (tag ${IMAGE_TAG})"
else
  IMAGE_SOURCE_LINE="Images:          ${PUBLIC_IMAGE_REGISTRY}/okta-mcp-{adapter,admin-ui,hr-server,deploy-server}:${IMAGE_TAG}"
fi
cat <<EOF
Resource group:  ${RESOURCE_GROUP}
Adapter FQDN:    https://${ADAPTER_FQDN}
Admin UI FQDN:   https://${ADMIN_UI_FQDN}
${IMAGE_SOURCE_LINE}

Quick operations:
  Redeploy adapter only:  ./scripts/deploy-adapter.sh
  Redeploy admin UI only: ./scripts/deploy-ui.sh
  Preview changes:        ./scripts/deploy.sh --what-if
  Destroy (BYO-safe):     ./scripts/deploy.sh --destroy
EOF
