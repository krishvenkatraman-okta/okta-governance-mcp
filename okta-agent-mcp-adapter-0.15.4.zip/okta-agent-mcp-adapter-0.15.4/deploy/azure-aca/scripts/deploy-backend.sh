#!/usr/bin/env bash
set -euo pipefail
# =============================================================
# deploy-backend.sh — Quick redeploy of a backend MCP server
# =============================================================
# Rebuilds one of the example backend servers (hr-mcp-server or
# deploy-server) and rolls the Container App.
#
# Usage:
#   ./scripts/deploy-backend.sh hr          # hr-mcp-server
#   ./scripts/deploy-backend.sh deploy      # deploy-server
# =============================================================

SCRIPT_DIR="$(cd "$(dirname "$0")/.." && pwd)"
cd "$SCRIPT_DIR"
REPO_ROOT="$(cd "$SCRIPT_DIR/../.." && pwd)"

source "$SCRIPT_DIR/shell-lib/common.sh"
source "$SCRIPT_DIR/shell-lib/bicep-helpers.sh"

STATE_FILE="$SCRIPT_DIR/.deploy.state"
export STATE_FILE
[[ -f "$STATE_FILE" ]] || die "No .deploy.state found. Run scripts/deploy.sh first."

target="${1:-}"
case "$target" in
  hr)
    quick_redeploy \
      hr-mcp-server hr-mcp-server \
      "$REPO_ROOT/examples/01-hr-system" \
      "$REPO_ROOT/examples/01-hr-system/Dockerfile" \
      HR_BACKEND_FQDN
    ;;
  deploy)
    quick_redeploy \
      deploy-server deploy-server \
      "$REPO_ROOT/examples/05-deploy-server" \
      "$REPO_ROOT/examples/05-deploy-server/Dockerfile" \
      DEPLOY_SERVER_FQDN
    ;;
  ""|-h|--help)
    cat <<'USAGE'
Usage: ./scripts/deploy-backend.sh {hr|deploy}

Quick redeploy of one example backend MCP server.
  hr      — rebuild + roll hr-mcp-server
  deploy  — rebuild + roll deploy-server
USAGE
    [[ -z "$target" ]] && exit 1 || exit 0
    ;;
  *)
    die "Unknown target: $target (use 'hr' or 'deploy')"
    ;;
esac
