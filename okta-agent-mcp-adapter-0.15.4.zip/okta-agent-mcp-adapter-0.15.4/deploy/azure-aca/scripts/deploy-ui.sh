#!/usr/bin/env bash
set -euo pipefail
# =============================================================
# deploy-ui.sh — Quick redeploy of the admin UI Container App
# =============================================================
# Builds a new admin-ui image and rolls the Container App. ~3 min.
# Requires .deploy.state from a prior scripts/deploy.sh run.
# =============================================================

SCRIPT_DIR="$(cd "$(dirname "$0")/.." && pwd)"
cd "$SCRIPT_DIR"
REPO_ROOT="$(cd "$SCRIPT_DIR/../.." && pwd)"

source "$SCRIPT_DIR/shell-lib/common.sh"
source "$SCRIPT_DIR/shell-lib/bicep-helpers.sh"

STATE_FILE="$SCRIPT_DIR/.deploy.state"
export STATE_FILE
[[ -f "$STATE_FILE" ]] || die "No .deploy.state found. Run scripts/deploy.sh first."

quick_redeploy \
  admin-ui \
  admin-ui \
  "$REPO_ROOT/okta_agent_proxy_admin_ui" \
  "$REPO_ROOT/okta_agent_proxy_admin_ui/Dockerfile" \
  ADMIN_UI_FQDN
