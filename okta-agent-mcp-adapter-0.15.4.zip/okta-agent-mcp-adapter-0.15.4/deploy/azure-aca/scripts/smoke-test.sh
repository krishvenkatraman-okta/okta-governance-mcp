#!/usr/bin/env bash
set -euo pipefail
# =============================================================
# smoke-test.sh — Post-deploy health check
# =============================================================
# Probes the adapter /health and the admin UI homepage. Runs a
# short polling loop because ACA revisions take ~30-90s to go
# healthy after a rolling update.
#
# Exits 0 if both endpoints respond, non-zero otherwise. Safe
# to run independently after deploy.sh.
# =============================================================

SCRIPT_DIR="$(cd "$(dirname "$0")/.." && pwd)"
cd "$SCRIPT_DIR"

source "$SCRIPT_DIR/shell-lib/common.sh"

STATE_FILE="$SCRIPT_DIR/.deploy.state"
[[ -f "$STATE_FILE" ]] || die "No .deploy.state found. Run scripts/deploy.sh first."

ADAPTER_FQDN="$(get_state ADAPTER_FQDN)"
ADMIN_UI_FQDN="$(get_state ADMIN_UI_FQDN)"

[[ -n "$ADAPTER_FQDN" ]]  || die "ADAPTER_FQDN missing from state — was Phase 3 of deploy.sh run?"
[[ -n "$ADMIN_UI_FQDN" ]] || die "ADMIN_UI_FQDN missing from state — was Phase 3 of deploy.sh run?"

# probe_url URL LABEL [TIMEOUT_SEC] [EXPECT_CODE]
probe_url() {
  local url="$1" label="$2" timeout="${3:-180}" expect="${4:-200}"
  local elapsed=0 code
  info "Probing $label → $url"
  while (( elapsed < timeout )); do
    code=$(curl -sS -o /dev/null -w "%{http_code}" --max-time 5 "$url" 2>/dev/null || echo "000")
    if [[ "$code" == "$expect" ]]; then
      ok "  ✓ $label healthy (HTTP $code) after ${elapsed}s"
      return 0
    fi
    printf "."
    sleep 5
    elapsed=$((elapsed + 5))
  done
  echo ""
  warn "  ✗ $label did not return HTTP $expect within ${timeout}s (last: $code)"
  return 1
}

errors=0
probe_url "https://$ADAPTER_FQDN/health"  "Adapter /health" 180 200 || errors=$((errors + 1))
probe_url "https://$ADMIN_UI_FQDN/"       "Admin UI /"      180 200 || errors=$((errors + 1))

echo ""
if (( errors > 0 )); then
  warn "Smoke test finished with $errors failure(s)."
  warn "Tail logs with:"
  warn "  az containerapp logs show -g $(get_state RESOURCE_GROUP) -n okta-ps-adapter --follow"
  warn "  az containerapp logs show -g $(get_state RESOURCE_GROUP) -n admin-ui --follow"
  exit 1
fi

ok "Smoke test passed."
