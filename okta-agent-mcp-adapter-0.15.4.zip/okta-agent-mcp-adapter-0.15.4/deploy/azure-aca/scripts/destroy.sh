#!/usr/bin/env bash
set -euo pipefail
# =============================================================
# destroy.sh — BYO-safe teardown
# =============================================================
# Removes every resource the wizard created, and NOTHING it was
# asked to reuse. Rules:
#
#   - If EXISTING_RG_NAME is set, the RG is never deleted; we
#     delete wizard-owned resources inside it by tag match.
#   - If USE_EXISTING_VNET=true, the VNet/subnets/peers stay.
#     Private endpoints the wizard created are still removed.
#   - If USE_EXISTING_POSTGRES / USE_EXISTING_REDIS is set, the
#     server/cache itself stays; the wizard's `gateway_db` is
#     left in place (destroying a database on a shared server
#     is a customer-driven operation).
#   - If BYO_ACR / BYO_LOG_ANALYTICS / BYO_ACA_ENV is set, the
#     underlying resource stays.
#   - DNS records in a BYO zone are removed (wizard-owned).
#
# Safety: prints what will be destroyed and prompts for
# confirmation. Pass --yes to skip.
# =============================================================

SCRIPT_DIR="$(cd "$(dirname "$0")/.." && pwd)"
cd "$SCRIPT_DIR"

source "$SCRIPT_DIR/shell-lib/common.sh"
source "$SCRIPT_DIR/shell-lib/azure-helpers.sh"

STATE_FILE="$SCRIPT_DIR/.deploy.state"
export STATE_FILE

YES=false
while [[ $# -gt 0 ]]; do
  case "$1" in
    --yes|-y) YES=true; shift ;;
    -h|--help)
      cat <<'USAGE'
Usage: ./scripts/destroy.sh [--yes]

BYO-safe teardown. Deletes wizard-created resources only; any
BYO infra (existing RG, VNet, Postgres, Redis, ACR, LAW, ACA env,
Key Vault, UAMI, DNS zone) is left untouched.

Options:
  --yes, -y    Skip the confirmation prompt.
USAGE
      exit 0
      ;;
    *) die "Unknown flag: $1 (use --help)" ;;
  esac
done

[[ -f "$STATE_FILE" ]] || die "No .deploy.state found. Nothing to destroy."

# Load .env for any BYO flags the user set at deploy time
if [[ -f "$SCRIPT_DIR/.env" ]]; then
  set -a; source "$SCRIPT_DIR/.env"; set +a
fi

az_login_check

# ---- Read deploy state ----
SUB="$(get_state AZURE_SUBSCRIPTION_ID)"
RG="$(get_state RESOURCE_GROUP)"
[[ -z "$RG" ]] && RG="$(get_state AZURE_RG)"
EXISTING_RG_NAME="${EXISTING_RG_NAME:-$(get_state EXISTING_RG_NAME)}"
ADAPTER_HOSTNAME="${ADAPTER_HOSTNAME:-$(get_state ADAPTER_HOSTNAME)}"
ADMIN_HOSTNAME="${ADMIN_HOSTNAME:-$(get_state ADMIN_HOSTNAME)}"
EXISTING_DNS_ZONE_ID="${EXISTING_DNS_ZONE_ID:-$(get_state EXISTING_DNS_ZONE_ID)}"

[[ -n "$SUB" ]] || die "AZURE_SUBSCRIPTION_ID missing from state"
[[ -n "$RG" ]]  || die "RESOURCE_GROUP missing from state"

az account set --subscription "$SUB"

BYO_RG=false
[[ -n "$EXISTING_RG_NAME" ]] && BYO_RG=true

# ---- Plan ----
echo ""
printf "${BOLD}Destroy plan${NC}\n"
printf "  Subscription: %s\n" "$SUB"
printf "  Resource RG:  %s\n" "$RG"
if $BYO_RG; then
  printf "  RG mode:      ${YELLOW}BYO — will NOT be deleted${NC}; wizard resources inside will be removed\n"
else
  printf "  RG mode:      ${GREEN}wizard-owned — full RG delete${NC}\n"
fi
[[ "${USE_EXISTING_VNET:-false}" == "true" ]]     && printf "  Network:      ${YELLOW}BYO VNet — preserved${NC}\n"
[[ "${USE_EXISTING_POSTGRES:-false}" == "true" ]] && printf "  Postgres:     ${YELLOW}BYO server — preserved (gateway_db kept in place)${NC}\n"
[[ "${USE_EXISTING_REDIS:-false}" == "true" ]]    && printf "  Redis:        ${YELLOW}BYO cache — preserved${NC}\n"
[[ "${BYO_ACR:-false}" == "true" ]]               && printf "  ACR:          ${YELLOW}BYO registry — preserved (images kept)${NC}\n"
[[ "${BYO_LOG_ANALYTICS:-false}" == "true" ]]     && printf "  Log Analytics: ${YELLOW}BYO workspace — preserved${NC}\n"
[[ "${BYO_ACA_ENV:-false}" == "true" ]]           && printf "  ACA Env:      ${YELLOW}BYO environment — preserved${NC}\n"
[[ "${USE_KEY_VAULT:-false}" == "true" ]]         && printf "  Key Vault:    ${YELLOW}BYO vault — preserved (secrets kept)${NC}\n"
echo ""

if ! $YES; then
  if ! prompt_yesno "Proceed with teardown?" "n"; then
    die "Teardown cancelled."
  fi
fi

# ---- DNS records (always try to clean if we created them) ----
if [[ -n "$EXISTING_DNS_ZONE_ID" && -n "$ADAPTER_HOSTNAME" ]]; then
  ZONE_NAME="$(az network dns zone show --ids "$EXISTING_DNS_ZONE_ID" --query name -o tsv 2>/dev/null || echo '')"
  ZONE_RG="$(echo "$EXISTING_DNS_ZONE_ID" | awk -F/ '{print $5}')"
  if [[ -n "$ZONE_NAME" ]]; then
    for host in "$ADAPTER_HOSTNAME" "$ADMIN_HOSTNAME"; do
      [[ -z "$host" ]] && continue
      # Strip zone suffix to get the record name
      record_name="${host%."$ZONE_NAME"}"
      [[ "$record_name" == "$host" ]] && continue  # not in this zone
      info "Removing CNAME $host from zone $ZONE_NAME ..."
      az network dns record-set cname delete \
        --resource-group "$ZONE_RG" --zone-name "$ZONE_NAME" \
        --name "$record_name" --yes --output none 2>/dev/null || warn "  (record not found or already removed)"
    done
  fi
fi

# ---- RG-owned path ----
if ! $BYO_RG; then
  info "Deleting resource group $RG (wizard-owned) ..."
  az group delete --name "$RG" --yes --no-wait
  ok "RG delete triggered (--no-wait). Poll: az group show -n $RG"
  rm -f "$STATE_FILE"
  ok "State file removed."
  exit 0
fi

# ---- BYO-RG path: delete wizard-created resources only, by tag ----
info "Scanning $RG for wizard-tagged resources (tags.wizard=okta-ps-adapter) ..."
RESOURCES_JSON="$(az resource list \
  --resource-group "$RG" \
  --tag wizard=okta-ps-adapter \
  --query '[].{id:id, type:type, name:name}' \
  -o json 2>/dev/null || echo '[]')"

COUNT="$(echo "$RESOURCES_JSON" | jq 'length')"
if [[ "$COUNT" == "0" ]]; then
  warn "No wizard-tagged resources found in $RG."
  warn "If this deploy predates tagging, you'll need to delete manually."
  rm -f "$STATE_FILE"
  exit 0
fi

info "Found $COUNT wizard resources. Deleting in reverse dependency order ..."

# Delete order: apps → env → endpoints → data → identity/keyvault
# (az resource delete refuses non-empty resources, so we sort)
delete_by_type() {
  local type_prefix="$1"
  echo "$RESOURCES_JSON" | jq -r ".[] | select(.type | startswith(\"$type_prefix\")) | .id" | while read -r id; do
    [[ -z "$id" ]] && continue
    info "  deleting $(basename "$id") ($type_prefix)"
    az resource delete --ids "$id" --output none 2>/dev/null \
      || warn "    delete failed (may already be gone)"
  done
}

delete_by_type "Microsoft.App/containerApps"
delete_by_type "Microsoft.App/managedEnvironments"
delete_by_type "Microsoft.Network/privateEndpoints"
delete_by_type "Microsoft.DBforPostgreSQL/flexibleServers"
delete_by_type "Microsoft.Cache/Redis"
delete_by_type "Microsoft.ContainerRegistry/registries"
delete_by_type "Microsoft.OperationalInsights/workspaces"
delete_by_type "Microsoft.KeyVault/vaults"
delete_by_type "Microsoft.ManagedIdentity/userAssignedIdentities"
delete_by_type "Microsoft.Network/privateDnsZones"
delete_by_type "Microsoft.Network/virtualNetworks"

ok "Wizard-tagged resources deleted in $RG."
warn "Resource group '$RG' and any BYO resources were preserved."
rm -f "$STATE_FILE"
ok "State file removed."
