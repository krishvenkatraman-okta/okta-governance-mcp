#!/usr/bin/env bash
set -euo pipefail
# =============================================================
# build-images.sh — Build + push all four images via az acr build
# =============================================================
# Builds adapter, admin-ui, hr-mcp-server, deploy-server images in
# ACR (remote build, no local Docker required), then rolls each
# Container App to the new tag.
#
# Reads from .deploy.state:
#   ACR_LOGIN_SERVER, RESOURCE_GROUP, IMAGE_TAG, ADAPTER_FQDN,
#   ADMIN_UI_FQDN
#
# Requires: az CLI, az login. Run from deploy/azure-aca/.
# =============================================================

SCRIPT_DIR="$(cd "$(dirname "$0")/.." && pwd)"
cd "$SCRIPT_DIR"

source "$SCRIPT_DIR/shell-lib/common.sh"

STATE_FILE="$SCRIPT_DIR/.deploy.state"
[[ -f "$STATE_FILE" ]] || die "No .deploy.state found. Run scripts/deploy.sh first."

# --build-only skips the `az containerapp update` roll step. Used by
# scripts/deploy.sh Phase 3b, where the Container Apps don't exist
# yet — they get created in Phase 3c with the correct imageTag.
BUILD_ONLY=false
for arg in "$@"; do
  case "$arg" in
    --build-only) BUILD_ONLY=true ;;
  esac
done

REPO_ROOT="$(cd "$SCRIPT_DIR/../.." && pwd)"

ACR_LOGIN_SERVER="$(get_state ACR_LOGIN_SERVER)"
RESOURCE_GROUP="$(get_state RESOURCE_GROUP)"
IMAGE_TAG="$(get_state IMAGE_TAG)"

[[ -n "$ACR_LOGIN_SERVER" ]] || die "ACR_LOGIN_SERVER missing from state"
[[ -n "$RESOURCE_GROUP" ]]   || die "RESOURCE_GROUP missing from state"
[[ -n "$IMAGE_TAG" ]]        || die "IMAGE_TAG missing from state"

ACR_NAME="${ACR_LOGIN_SERVER%%.*}"

info "Registry:    $ACR_LOGIN_SERVER ($ACR_NAME)"
info "Resource GP: $RESOURCE_GROUP"
info "Image tag:   $IMAGE_TAG"
echo ""

# -------------------------------------------------------------
# Build images in parallel (ACR handles queue internally)
# -------------------------------------------------------------
# Each image gets both the unique tag AND :latest so operators
# can still `docker pull $ACR/adapter:latest` for debugging.
build_image() {
  local name="$1" context="$2" dockerfile="$3"
  info "Building $name:$IMAGE_TAG ..."
  az acr build \
    --registry "$ACR_NAME" \
    --image "$name:$IMAGE_TAG" \
    --image "$name:latest" \
    --file "$dockerfile" \
    "$context" \
    --output none
  ok "  ✓ $name built"
}

build_image adapter        "$REPO_ROOT"                                    "$REPO_ROOT/Dockerfile"
build_image admin-ui       "$REPO_ROOT/okta_agent_proxy_admin_ui"          "$REPO_ROOT/okta_agent_proxy_admin_ui/Dockerfile"
build_image hr-mcp-server  "$REPO_ROOT/examples/01-hr-system"              "$REPO_ROOT/examples/01-hr-system/Dockerfile"
build_image deploy-server  "$REPO_ROOT/examples/05-deploy-server"          "$REPO_ROOT/examples/05-deploy-server/Dockerfile"

echo ""

if $BUILD_ONLY; then
  ok "All images built. Skipping Container App roll (--build-only)."
  exit 0
fi

# -------------------------------------------------------------
# Roll each Container App to the new image
# -------------------------------------------------------------
roll_app() {
  local app="$1" image="$2"
  info "Rolling $app → ${ACR_LOGIN_SERVER}/${image}:${IMAGE_TAG}"
  az containerapp update \
    -g "$RESOURCE_GROUP" \
    -n "$app" \
    --image "${ACR_LOGIN_SERVER}/${image}:${IMAGE_TAG}" \
    --output none
  ok "  ✓ $app rolled"
}

roll_app okta-ps-adapter adapter
roll_app admin-ui        admin-ui
roll_app hr-mcp-server   hr-mcp-server
roll_app deploy-server   deploy-server

ok "All images built and Container Apps rolled to $IMAGE_TAG."
