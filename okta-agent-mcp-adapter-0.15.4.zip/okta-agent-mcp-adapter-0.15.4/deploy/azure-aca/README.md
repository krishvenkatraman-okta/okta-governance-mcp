# Okta MCP Adapter — Azure Container Apps Deployment

Deploys the Okta MCP Adapter, Admin UI, and two example backend MCP servers
onto **Azure Container Apps** using **full Bicep** plus thin bash wrappers.

Two paths:

- **Default (public images)** — `./scripts/deploy.sh` stands up a complete
  working stack (RG, VNet, Postgres, Redis, Log Analytics, ACA env, 4
  Container Apps) pulling prebuilt images from ECR Public
  (`public.ecr.aws/${ECR_PUBLIC_ALIAS:-oktaps}/okta-mcp-*`) at tag
  `v<pyproject version>`. No ACR provisioned. Single Bicep deployment,
  ~15 minutes. ~$60–100/month while active.
- **Enterprise (BYO)** — reuse your existing VNet, Postgres, Redis, Log
  Analytics workspace, ACA environment, Key Vault, User-Assigned Managed
  Identity, and/or Azure DNS zone. Every reusable subsystem has a BYO toggle
  implemented natively in Bicep. The default path works with every BYO
  toggle; ACR is only needed if you also pass `--build-from-source`.

The Bicep is **subscription-scoped** and modular (one module per subsystem).
The rendered `.bicepparam` is the handoff artifact: commit a sanitized copy
to your platform repo to capture enterprise configuration.

---

## Layout

```
deploy/azure-aca/
├── bicep/
│   ├── main.bicep                    # subscription-scoped orchestrator
│   ├── main.bicepparam               # demo defaults (reads env)
│   ├── main.byo.bicepparam.example   # worked enterprise example
│   └── modules/
│       ├── networking.bicep          # VNet + subnets + private DNS + peering
│       ├── database.bicep            # Postgres Flexible Server + gateway_db
│       ├── cache.bicep               # Redis + private endpoint
│       ├── registry.bicep            # ACR + AcrPull role
│       ├── observability.bicep       # Log Analytics + ACA env
│       ├── identity.bicep            # UAMI + role assignments
│       ├── keyvault.bicep            # Key Vault + 8 gateway secrets
│       ├── dns.bicep                 # CNAMEs in Azure DNS zone
│       └── apps.bicep                # 4 Container Apps
├── scripts/
│   ├── deploy.sh                     # main wrapper (preflight → what-if → deploy → build → smoke)
│   ├── preflight-enterprise.sh       # standalone BYO validator
│   ├── build-images.sh               # az acr build for all 4 images
│   ├── smoke-test.sh                 # post-deploy /health checks
│   ├── destroy.sh                    # BYO-safe teardown
│   ├── deploy-adapter.sh             # quick redeploy: adapter only (~3 min)
│   ├── deploy-ui.sh                  # quick redeploy: admin UI only (~3 min)
│   └── deploy-backend.sh             # quick redeploy: hr or deploy backend
├── shell-lib/
│   ├── common.sh                     # prompts, state I/O, logging
│   ├── azure-helpers.sh              # az login check, provider registration
│   └── bicep-helpers.sh              # what-if, deploy, output capture
├── .env.example                      # demo config template
├── .env.byo.example                  # enterprise BYO config template
└── package.sh                        # build self-contained tarball
```

---

## Prerequisites

- Azure subscription — **Owner** or **Contributor** role
- Tools on the operator's machine: `az` CLI, `jq`, `openssl`, `bash` 4+
- `az bicep install` (auto-run by `deploy.sh` if missing)
- An Okta org with a Custom Authorization Server and an OIDC Web App for the
  Admin UI

---

## Quick Start (default: pull from ECR Public)

```bash
cd deploy/azure-aca
cp .env.example .env
vi .env                        # fill in OKTA_* fields
./scripts/deploy.sh            # pulls public.ecr.aws/oktaps/okta-mcp-* at v<pyproject version>

# Pin to a specific published version
./scripts/deploy.sh --tag=v0.15.0

# Preview without deploying
./scripts/deploy.sh --what-if
```

Under the hood `deploy.sh` sets these Bicep parameters:

| Parameter | Value |
|---|---|
| `usePublicImages` | `true` (no ACR provisioned) |
| `publicImageRegistry` | `public.ecr.aws/${ECR_PUBLIC_ALIAS:-oktaps}` |
| `imageTag` | from `--tag=` or pyproject version (`v<semver>`) |

> **If the `oktaps` ECR Public alias is still pending AWS approval,** export
> `ECR_PUBLIC_ALIAS=<your-auto-assigned-alias>` before deploying. Look the
> alias up in the AWS console or via
> `aws ecr-public describe-registries --region us-east-1 --query 'registries[0].aliases[?status==\`ACTIVE\`].name'`.

Phases on the default path: (0) configuration & secret generation · (1)
preflight · (2) `az deployment sub what-if` · (3) single `az deployment sub
create` (deployApps=true) · (4) DB bootstrap ACA Job · (5) smoke test ·
(6) summary.

Useful flags:

| Flag | Purpose |
|---|---|
| `--yes` / `-y` | Skip confirmation prompts (CI-friendly) |
| `--what-if` | Render + preview the deployment, then exit |
| `--skip-preflight` | Skip BYO probe (use with care) |
| `--tag=vX.Y.Z` | Override the public-image tag |
| `--no-bootstrap` | Skip DB bootstrap; print operator handoff |
| `--migrate-only` | Run DB bootstrap only (needs prior successful deploy) |
| `--destroy` | Invoke BYO-safe teardown (`scripts/destroy.sh`) |

Single-component redeploys (~3 minutes each):

```bash
./scripts/deploy-adapter.sh         # adapter only
./scripts/deploy-ui.sh              # admin UI only
./scripts/deploy-backend.sh hr      # hr-mcp-server
./scripts/deploy-backend.sh deploy  # deploy-server
```

---

## Build from source (opt-in)

To build the four images in an ACR in your own subscription instead of
pulling from public.ecr.aws — for custom patches, air-gapped publishes, or
pre-release testing — pass `--build-from-source`:

```bash
./scripts/deploy.sh --build-from-source
```

`--build-from-source` flips `usePublicImages=false`, which provisions:

- Azure Container Registry (Basic SKU, admin enabled)
- ACR push IAM for the deployer
- UAMI with `AcrPull` on the registry for runtime pulls

Plus the existing three-phase apply:

1. **Phase 3a:** `bicep_deploy deployApps=false` creates infra + ACR.
2. **Phase 3b:** `az acr build` pushes `adapter`, `admin-ui`, `hr-mcp-server`,
   `deploy-server` into the new ACR (skippable with `--skip-build`).
3. **Phase 3c:** `bicep_deploy deployApps=true` creates Container Apps
   pointing at ACR.

Image tag on this path is timestamped (`v<yyyymmdd-HHMMSS>`) for build
uniqueness. Image names differ from the public path (ACR repo names are
`adapter` / `admin-ui` / `hr-mcp-server` / `deploy-server`; public ECR repos
are `okta-mcp-*`).

Additional flags on this path:

| Flag | Purpose |
|---|---|
| `--skip-build` | Skip `az acr build` — reuse already-pushed ACR images. Only valid with `--build-from-source`. |

### Air-gapped / egress-controlled: mirror public images to your ACR

If your Container Apps environment can't reach `public.ecr.aws`, mirror the
images into your ACR and deploy with `--build-from-source --skip-build`.
**This is a customer task** — we don't automate it.

```bash
# 1. Pull + push each image into your ACR. Repeat per release tag.
for name in okta-mcp-adapter okta-mcp-admin-ui okta-mcp-hr-server okta-mcp-deploy-server; do
  az acr import \
    --name "$YOUR_ACR_NAME" \
    --source "public.ecr.aws/oktaps/${name}:v0.15.0" \
    --image "${name#okta-mcp-}:v0.15.0"     # ACR repo matches this project's build names
done

# 2. Deploy with --build-from-source --skip-build so Bicep points at ACR but
#    doesn't try to build.
export BYO_ACR=true
export EXISTING_ACR_ID="/subscriptions/.../registries/$YOUR_ACR_NAME"
export EXISTING_ACR_LOGIN_SERVER="${YOUR_ACR_NAME}.azurecr.io"
export IMAGE_TAG="v0.15.0"
./scripts/deploy.sh --build-from-source --skip-build
```

---

## Enterprise deployment (BYO)

Run the standalone BYO validator first — it probes every populated
`EXISTING_*` ID with `az ... show` and fails fast with the env var name:

```bash
./scripts/preflight-enterprise.sh
```

### BYO slots — four bundles

Every toggle is driven by an env var. Empty = wizard creates the resource;
non-empty = wizard references it and never mutates it.

#### Bundle 1 — Network + data plane

| Resource | Env vars | Notes |
|---|---|---|
| Resource group | `EXISTING_RG_NAME` | Wizard tags resources with `wizard=okta-ps-adapter`; `destroy.sh` deletes only tagged resources when RG is BYO |
| VNet + subnets | `USE_EXISTING_VNET=true`, `EXISTING_VNET_ID`, `EXISTING_ACA_SUBNET_ID`, `EXISTING_PE_SUBNET_ID` | ACA infra subnet needs ≥ /23 and delegation to `Microsoft.App/environments`; PE subnet should have `privateEndpointNetworkPolicies=Disabled` |
| Private DNS zones | `EXISTING_PG_DNS_ZONE_ID`, `EXISTING_REDIS_DNS_ZONE_ID` | Skip zone + VNet-link creation |
| Postgres Flexible Server | `USE_EXISTING_POSTGRES=true`, `EXISTING_PG_SERVER_ID`, `EXISTING_PG_ADMIN_USER` | Wizard only creates the `gateway_db` database + app user; no firewall/networking changes |
| Redis Cache | `USE_EXISTING_REDIS=true`, `EXISTING_REDIS_ID` | Standard+ SKU required for private endpoints |

#### Bundle 2 — Platform shared services

| Resource | Env vars | Notes |
|---|---|---|
| ACR | `BYO_ACR=true`, `EXISTING_ACR_ID`, `EXISTING_ACR_LOGIN_SERVER` | UAMI gets `AcrPull` on the registry |
| Log Analytics | `BYO_LOG_ANALYTICS=true`, `EXISTING_LAW_ID` | ACA env `appLogsConfiguration` wired to it |
| ACA Managed Environment | `BYO_ACA_ENV=true`, `EXISTING_ACA_ENV_ID` | Shared-env pattern; env must already be linked to the same VNet + LAW |

#### Bundle 3 — Security + identity

| Resource | Env vars | Notes |
|---|---|---|
| Key Vault | `USE_KEY_VAULT=true`, `EXISTING_KEY_VAULT_ID`, `KV_SECRET_PREFIX` | Secrets rendered as ACA `keyVaultUrl` references resolved via UAMI |
| UAMI | `BYO_UAMI=true`, `EXISTING_UAMI_ID` | Needs AcrPull on ACR and Key Vault Secrets User on KV |
| CMK (wizard-created resources only) | `EXISTING_CMK_KEY_ID_POSTGRES`, `EXISTING_CMK_KEY_ID_LAW`, `EXISTING_CMK_KEY_ID_KV` | BYO resources already have their own encryption |

#### Bundle 4 — DNS + ingress

| Setting | Values | Notes |
|---|---|---|
| `DNS_PROVIDER` | `none` \| `azure_dns` \| `delegated` \| `external` | `none` = ACA-issued `*.azurecontainerapps.io`; `external` prints CNAME targets to configure manually |
| `EXISTING_DNS_ZONE_ID`, `ADAPTER_HOSTNAME`, `ADMIN_HOSTNAME` | IDs + FQDNs | Used by `dns.bicep` when provider is `azure_dns` or `delegated` |
| `UPSTREAM_INGRESS` | `none` \| `app_gateway` \| `front_door` | Wizard does **not** provision AGW / Front Door — it prints wiring instructions only |

### Gather-this-info checklist

Commands your Azure admin can run to pull the IDs your operator needs:

| Item | Command |
|---|---|
| VNets + subnets | `az network vnet list -o table`<br>`az network vnet subnet list -g <rg> --vnet-name <vnet> -o table` |
| Postgres Flex servers | `az postgres flexible-server list -o table` |
| Redis caches | `az redis list -o table` |
| Container registries | `az acr list -o table` |
| Log Analytics workspaces | `az monitor log-analytics workspace list -o table` |
| ACA managed environments | `az containerapp env list -o table` |
| Key Vaults | `az keyvault list -o table` |
| User-Assigned Managed Identities | `az identity list -o table` |
| Azure DNS zones | `az network dns zone list -o table` |
| Private DNS zones | `az network private-dns zone list -o table` |

### Worked example

```bash
cp .env.byo.example .env
vi .env
# Populate whichever BYO bundles apply. Everything else is auto-created.

./scripts/preflight-enterprise.sh   # validate IDs
./scripts/deploy.sh --what-if       # preview
./scripts/deploy.sh                 # apply
```

See [`bicep/main.byo.bicepparam.example`](bicep/main.byo.bicepparam.example)
for a fully-annotated `.bicepparam` showing every BYO slot populated.

---

## What-if preview

Every apply is gated behind `az deployment sub what-if`, which renders the
exact resource deltas ARM would apply. Review, then confirm with `y`. Use
`--yes` in CI to bypass the prompt.

---

## Teardown

```bash
./scripts/destroy.sh                # interactive
./scripts/destroy.sh --yes          # no prompt
```

**BYO safety rules:**

- `EXISTING_RG_NAME` set → the RG is preserved; only resources tagged
  `wizard=okta-ps-adapter` are deleted.
- `USE_EXISTING_VNET=true` → VNet, subnets, peering all preserved.
- `USE_EXISTING_POSTGRES=true` → server preserved; `gateway_db` left in place
  (destroying a database on a shared server is a customer-driven operation).
- `USE_EXISTING_REDIS=true` → cache preserved.
- `BYO_ACR` / `BYO_LOG_ANALYTICS` / `BYO_ACA_ENV` / `USE_KEY_VAULT` → the
  underlying resource stays. Secrets in a BYO Key Vault are not deleted.

When the RG is wizard-owned, `destroy.sh` calls `az group delete --no-wait`
and exits.

---

## Microsoft Entra ID authentication for Postgres

As of v0.15.0, the stack authenticates to Postgres using **Microsoft Entra ID**
by default — no static DATABASE_URL password. Two user-assigned managed
identities are provisioned:

| Identity | Purpose | DB role granted |
|---|---|---|
| `okta-ps-adapter-uami`       | Attached to adapter, admin UI, HR, deploy apps. Runtime / least-privilege. | `okta_adapter_app` (DML only) |
| `okta-ps-adapter-owner-uami` | Attached to the migrate ACA Job. Registered as Postgres Entra admin. | `okta_adapter_owner` (DDL) + `azure_pg_admin` |

The adapter container sets:

```
DB_CREDENTIAL_PROVIDER=azure_entra
DB_HOST=<postgres-fqdn>
DB_PORT=5432
DB_NAME=gateway_db
DB_USERNAME=okta-ps-adapter-uami
AZURE_CLIENT_ID=<app-uami-client-id>
```

`okta_agent_proxy.storage.credentials.AzureEntraCredentialProvider`
(introduced in P11) calls `DefaultAzureCredential.get_token(...)` with the
`https://ossrdbms-aad.database.windows.net/.default` scope and supplies the
resulting access token as the Postgres password; the managed identity inherits
the DML-only `okta_adapter_app` role via `GRANT`.

### Migration Job

A Container Apps Job (`okta-ps-adapter-migrate`, Manual trigger) runs once per
deploy. Steps (all idempotent):

1. Acquire an Entra token as the **owner UAMI**.
2. Apply `deploy/migrations/sql/bootstrap_roles.sql` — creates
   `okta_adapter_owner` and `okta_adapter_app` roles with default privileges.
3. Call `pgaadauth_create_principal_with_oid` for both UAMIs and GRANT the
   corresponding role to each.
4. Run `python -m okta_agent_proxy.storage.migrate upgrade` to apply pending
   schema migrations.

`scripts/deploy.sh` triggers the job after apps are created and polls its
execution status. You can rerun it any time:

```bash
az containerapp job start -g <rg> -n okta-ps-adapter-migrate
az containerapp job execution list -g <rg> -n okta-ps-adapter-migrate --query "[0].properties.status"
```

### Bootstrap control flags (P15)

The migrate-job invocation is wrapped by a shared helper
(`deploy/shell-lib/db_bootstrap.sh`) that exposes these flags on
`scripts/deploy.sh`:

```bash
# Default — run infra deploy + apps + migrate job
./scripts/deploy.sh

# Skip the migrate job. Prints an operator handoff block with the real
# resource group, job name, Entra owner principal, and DBA runbook.
./scripts/deploy.sh --no-bootstrap              # alias: RUN_DB_BOOTSTRAP=false

# Skip infra + apps; only re-run the migrate job. Reads saved state from
# .deploy.state. Idempotent — safe to run repeatedly. Useful when a new
# release ships migrations but no infra change.
./scripts/deploy.sh --migrate-only
```

| Variable                   | Default | Effect                                                                        |
|----------------------------|---------|-------------------------------------------------------------------------------|
| `RUN_DB_BOOTSTRAP`         | `true`  | `false` skips the ACA job; deploy prints an operator handoff block.           |
| `DB_BOOTSTRAP_FORCE_LOCAL` | `false` | `true` skips the ACA job attempt and runs bootstrap from the deploy host.    |
| `DB_BOOTSTRAP_TIMEOUT`     | `900`   | Max seconds to wait for the ACA job (overrides the default 600 on Azure).     |

When `RUN_DB_BOOTSTRAP=false`, the adapter container stays in
`CrashLoopBackoff` with the "schema not initialized" error until the DBA
completes the bootstrap. That's intentional. The handoff block includes the
exact `az containerapp job start` command plus a `psql` fallback for a DBA
jump host.

### Disabling Entra auth (legacy static password)

Set `ENTRA_AUTH_ENABLED=false` in `.env` (or `entraAuthEnabled = false` in a
BYO `.bicepparam`). The adapter then reads `DATABASE_URL` the old way and the
migrate job is not deployed — run migrations manually via the container:

```bash
az containerapp exec -g <rg> -n okta-ps-adapter -- \
  python -m okta_agent_proxy.storage.migrate upgrade
```

---

## Secrets + state

Generated on first run and persisted to `.deploy.state`:

| Key | Length | Purpose |
|---|---|---|
| `ENCRYPTION_KEY` | 32 bytes base64 | AES-256-GCM for encrypted config fields |
| `NEXTAUTH_SECRET` | 48 bytes base64 | NextAuth session signing |
| `HR_PSK_SECRET` | 32 bytes base64 | HR backend PSK |
| `PG_ADMIN_PASSWORD` | 24 bytes base64 | Postgres server admin password (wizard-created only) |

`.deploy.state` is `.gitignore`d. To rotate, delete the line and re-run
`scripts/deploy.sh`.

---

## The `.bicepparam` handoff artifact

`bicep/main.bicepparam` is rendered from `.env` + `.deploy.state` on every
deploy, and is the file `az deployment sub create` consumes. Platform teams
can version-control a sanitized copy to capture enterprise configuration —
it is declarative, diffable, and maps 1:1 to the Bicep modules.

Prefer the sanitized `.bicepparam` over `.env` for audit trails and code
review.

---

## Migration from `acasetup.sh`

The 1293-line `acasetup.sh` has been replaced by `scripts/deploy.sh` + Bicep
modules. A compatibility shim at `acasetup.sh` prints a deprecation banner
and execs `scripts/deploy.sh`. It translates the two legacy flags:

| Old flag | New behavior |
|---|---|
| `--custom-vnet` | No-op (custom VNet creation is now the default in `networking.bicep`) |
| `--peer-vnet <id>` | Sets `PEER_VNET_RESOURCE_ID` env var |

The shim will be removed in a future release. Update runbooks to call
`scripts/deploy.sh` directly.

---

## Troubleshooting

| Symptom | Hint |
|---|---|
| `Preflight failed` | `preflight-enterprise.sh` names the exact env var that's wrong — IDs are cross-subscription-sensitive (`az account set --subscription` first) |
| `what-if` shows unexpected deletes | Usually `.bicepparam` drifted from reality. Re-check `.env` BYO fields. Never edit `.bicepparam` by hand if you plan to re-run the wizard — changes are overwritten |
| Container App stuck in `Provisioning` | Tail logs: `az containerapp logs show -g <rg> -n <app> --follow` |
| `AcrPull` permission denied on image pull | UAMI needs `AcrPull` on the registry; `identity.bicep` grants it when wizard creates both, but BYO ACR + BYO UAMI requires you to grant it once |
| `keyVaultUrl` secret returns 403 | UAMI needs `Key Vault Secrets User` role on the vault (RBAC auth mode) |
| Smoke test times out | Revisions take 30–90 s to go healthy after a rolling update; rerun `./scripts/smoke-test.sh` |

---

## Packaging for distribution

```bash
./package.sh --version <x.y.z>
# → dist/okta-ps-adapter-azure-aca-<x.y.z>.tar.gz (with SHA-256)
```

The tarball is self-contained: `bicep/`, `scripts/`, `shell-lib/`, both
`.env*.example` files, the adapter source, admin UI source, example
backends, and `LICENSE`. Unpack anywhere, `cd deploy/azure-aca`, run
`./scripts/deploy.sh`.

---

## Redis Authentication: Entra Managed Identity

This deployment uses Microsoft Entra ID authentication for Azure
Cache for Redis (Standard SKU). The Container App's User-Assigned
Managed Identity (UAMI) is granted the "Data Owner" access policy
on the cache. At connection time, the adapter's `azure-entra`
credential provider acquires an access token for the
`redis.azure.com/.default` scope and presents it as the Redis
AUTH password (with the UAMI's Object ID as the username).

**No shared secret exists for Redis access** — the Bicep does not
call `listKeys()`, the access key is not embedded in `REDIS_URL`,
and the adapter stores no Redis credential. The connection URL is
emitted as a plain `rediss://<host>:6380` string.

### Resources involved

| Resource                                     | Purpose                                  |
| -------------------------------------------- | ---------------------------------------- |
| UAMI (`identity.bicep`)                      | Adapter's workload identity              |
| `redisConfiguration['aad-enabled'] = 'true'` | Enables Entra auth on the cache          |
| `accessPolicyAssignments/Data Owner`         | Grants the UAMI data access on the cache |

### Container App env vars

| Env var                  | Value                           |
| ------------------------ | ------------------------------- |
| `REDIS_AUTH_MODE`        | `azure-entra`                   |
| `REDIS_AZURE_USE_MSI`    | `true`                          |
| `REDIS_AZURE_CLIENT_ID`  | UAMI `clientId` (from `identity.outputs.clientId`) |
| `REDIS_URL`              | `rediss://<host>:6380` (no credential) |

### Auditability

Every credential mint emits a `redis.credential.minted` audit event
with the UAMI's Object ID in the `principal` field. Token refreshes
(every ~55 minutes) emit `redis.credential.refresh.success`.

### Tier requirements

Entra ID authentication for Azure Cache for Redis requires
**Standard or Premium SKU**. The Bicep `@allowed` constraint on
`redisSkuName` blocks Basic; the default is Standard. Azure Managed
Redis (a separate product) supports Entra by default and is the
recommended target once GA.
