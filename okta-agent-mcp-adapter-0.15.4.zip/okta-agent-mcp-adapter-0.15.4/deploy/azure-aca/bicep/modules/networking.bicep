// =============================================================
// networking.bicep — VNet, subnets, private DNS zones, peering
// =============================================================
// Either creates a new VNet with two subnets (ACA infra + private
// endpoints) or references an existing VNet via BYO IDs. Exports
// canonical IDs so downstream modules never branch on BYO/created.
// =============================================================

param location string
param tags object

param useExistingVnet bool
param existingVnetId string
param existingAcaSubnetId string
param existingPeSubnetId string

param vnetName string
param vnetAddressPrefix string
param acaSubnetPrefix string
param peSubnetPrefix string

param existingPgDnsZoneId string
param existingRedisDnsZoneId string

param peerVnetResourceId string
param peerName string

// -------------------------------------------------------------
// VNet + subnets (create path)
// -------------------------------------------------------------

resource vnet 'Microsoft.Network/virtualNetworks@2024-01-01' = if (!useExistingVnet) {
  name: vnetName
  location: location
  tags: tags
  properties: {
    addressSpace: {
      addressPrefixes: [ vnetAddressPrefix ]
    }
    subnets: [
      {
        name: 'aca-infra'
        properties: {
          addressPrefix: acaSubnetPrefix
          delegations: [
            {
              name: 'Microsoft.App.environments'
              properties: {
                serviceName: 'Microsoft.App/environments'
              }
            }
          ]
        }
      }
      {
        name: 'private-endpoints'
        properties: {
          addressPrefix: peSubnetPrefix
          privateEndpointNetworkPolicies: 'Disabled'
        }
      }
    ]
  }
}

// -------------------------------------------------------------
// Peering (only when we created the VNet AND peerVnetResourceId set)
// -------------------------------------------------------------

resource peering 'Microsoft.Network/virtualNetworks/virtualNetworkPeerings@2024-01-01' = if (!useExistingVnet && !empty(peerVnetResourceId)) {
  name: peerName
  parent: vnet
  properties: {
    allowVirtualNetworkAccess: true
    allowForwardedTraffic: true
    allowGatewayTransit: false
    useRemoteGateways: false
    remoteVirtualNetwork: {
      id: peerVnetResourceId
    }
  }
}

// -------------------------------------------------------------
// Private DNS zones (create when empty BYO id; always link to our VNet)
// -------------------------------------------------------------

var createPgDnsZone = empty(existingPgDnsZoneId)
var createRedisDnsZone = empty(existingRedisDnsZoneId)

resource pgDnsZone 'Microsoft.Network/privateDnsZones@2024-06-01' = if (createPgDnsZone) {
  name: 'privatelink.postgres.database.azure.com'
  location: 'global'
  tags: tags
}

resource redisDnsZone 'Microsoft.Network/privateDnsZones@2024-06-01' = if (createRedisDnsZone) {
  name: 'privatelink.redis.cache.windows.net'
  location: 'global'
  tags: tags
}

// Link the private DNS zones to the VNet we're using (created or BYO).
// Only link when we created the zone — BYO zones may already be linked.

resource pgDnsLink 'Microsoft.Network/privateDnsZones/virtualNetworkLinks@2024-06-01' = if (createPgDnsZone) {
  parent: pgDnsZone
  name: 'link-${vnetName}'
  location: 'global'
  properties: {
    registrationEnabled: false
    virtualNetwork: {
      id: useExistingVnet ? existingVnetId : vnet.id
    }
  }
}

resource redisDnsLink 'Microsoft.Network/privateDnsZones/virtualNetworkLinks@2024-06-01' = if (createRedisDnsZone) {
  parent: redisDnsZone
  name: 'link-${vnetName}'
  location: 'global'
  properties: {
    registrationEnabled: false
    virtualNetwork: {
      id: useExistingVnet ? existingVnetId : vnet.id
    }
  }
}

// -------------------------------------------------------------
// Outputs — canonical IDs
// -------------------------------------------------------------

output vnetId string = useExistingVnet ? existingVnetId : vnet.id
output acaSubnetId string = useExistingVnet ? existingAcaSubnetId : '${vnet.id}/subnets/aca-infra'
output peSubnetId string = useExistingVnet ? existingPeSubnetId : '${vnet.id}/subnets/private-endpoints'
output pgDnsZoneId string = createPgDnsZone ? pgDnsZone.id : existingPgDnsZoneId
output redisDnsZoneId string = createRedisDnsZone ? redisDnsZone.id : existingRedisDnsZoneId
