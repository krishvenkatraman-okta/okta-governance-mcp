// =============================================================
// registry.bicep — Azure Container Registry + AcrPull role
// =============================================================
// Either creates an ACR (Basic SKU, admin enabled for demo) or
// references an existing one. Grants AcrPull to the UAMI so apps
// can pull via managed identity. Falls back to admin credentials
// only when UAMI-based pull isn't viable.
// =============================================================

param location string
param tags object

param byoAcr bool
param existingAcrResourceId string
param existingAcrLoginServer string
param acrName string

param uamiPrincipalId string

resource acr 'Microsoft.ContainerRegistry/registries@2023-11-01-preview' = if (!byoAcr) {
  name: acrName
  location: location
  tags: tags
  sku: {
    name: 'Basic'
  }
  properties: {
    adminUserEnabled: true
    publicNetworkAccess: 'Enabled'
  }
}

resource acrRef 'Microsoft.ContainerRegistry/registries@2023-11-01-preview' existing = if (byoAcr) {
  name: last(split(existingAcrResourceId, '/'))
}

// AcrPull role (fixed built-in role definition ID)
var acrPullRoleId = '7f951dda-4ed3-4680-a7ca-43fe172d538d'

resource acrPullCreated 'Microsoft.Authorization/roleAssignments@2022-04-01' = if (!byoAcr) {
  scope: acr
  name: guid(acr.id, uamiPrincipalId, acrPullRoleId)
  properties: {
    roleDefinitionId: subscriptionResourceId('Microsoft.Authorization/roleDefinitions', acrPullRoleId)
    principalId: uamiPrincipalId
    principalType: 'ServicePrincipal'
  }
}

resource acrPullExisting 'Microsoft.Authorization/roleAssignments@2022-04-01' = if (byoAcr) {
  scope: acrRef
  name: guid(existingAcrResourceId, uamiPrincipalId, acrPullRoleId)
  properties: {
    roleDefinitionId: subscriptionResourceId('Microsoft.Authorization/roleDefinitions', acrPullRoleId)
    principalId: uamiPrincipalId
    principalType: 'ServicePrincipal'
  }
}

// Fetch admin creds only when we created the ACR (fallback auth path).
#disable-next-line BCP318
output loginServer string = byoAcr ? existingAcrLoginServer : acr.properties.loginServer
#disable-next-line BCP318
output resourceId string = byoAcr ? existingAcrResourceId : acr.id
#disable-next-line BCP318 BCP422 outputs-should-not-contain-secrets
output adminUsername string = byoAcr ? '' : acr.listCredentials().username
@secure()
#disable-next-line BCP318 BCP422 outputs-should-not-contain-secrets
output adminPassword string = byoAcr ? '' : acr.listCredentials().passwords[0].value
