// =============================================================
// database.bicep — Postgres Flexible Server + gateway database
// =============================================================
// Either creates a Postgres Flexible Server (Burstable B1ms for
// demo) with a private endpoint, or references an existing server.
// In both cases, creates the `gateway_db` database against the
// resolved server. Does NOT modify firewall/networking on a BYO
// server — customer owns that lifecycle.
//
// When entraAuthEnabled = true, the server is configured for
// Microsoft Entra ID authentication and the supplied principal
// (typically the owner UAMI) is registered as the Entra admin.
// Password auth remains enabled as a break-glass path.
// =============================================================

param location string
param tags object

param useExistingPostgres bool
param existingPostgresServerId string
param serverName string
param adminUser string
@secure()
param adminPassword string
param databaseName string
param skuName string
param skuTier string
param storageGB int

@description('Customer-managed key for data encryption. Empty = platform-managed.')
param cmkKeyId string = ''

@description('Enable Microsoft Entra ID authentication on the server (wizard-created servers only).')
param entraAuthEnabled bool = false

@description('Object ID of the Entra principal registered as the server admin. Typically the owner UAMI principalId.')
param entraAdminObjectId string = ''

@description('Display name of the Entra admin (shows in the portal and in server-level admin records).')
param entraAdminPrincipalName string = ''

@description('Principal type for the Entra admin. ServicePrincipal covers user-assigned managed identities.')
@allowed(['User', 'Group', 'ServicePrincipal'])
param entraAdminType string = 'ServicePrincipal'

@description('Tenant ID for Entra authentication. Defaults to the subscription tenant.')
param tenantId string = subscription().tenantId

// -------------------------------------------------------------
// Server: create or reference
// -------------------------------------------------------------

resource server 'Microsoft.DBforPostgreSQL/flexibleServers@2024-08-01' = if (!useExistingPostgres) {
  name: serverName
  location: location
  tags: tags
  sku: {
    name: skuName
    tier: skuTier
  }
  properties: {
    version: '16'
    administratorLogin: adminUser
    administratorLoginPassword: adminPassword
    authConfig: entraAuthEnabled ? {
      activeDirectoryAuth: 'Enabled'
      passwordAuth: 'Enabled'
      tenantId: tenantId
    } : {
      activeDirectoryAuth: 'Disabled'
      passwordAuth: 'Enabled'
    }
    storage: {
      storageSizeGB: storageGB
      autoGrow: 'Enabled'
    }
    backup: {
      backupRetentionDays: 7
      geoRedundantBackup: 'Disabled'
    }
    highAvailability: {
      mode: 'Disabled'
    }
    network: {
      publicNetworkAccess: 'Enabled'
    }
    dataEncryption: !empty(cmkKeyId) ? {
      type: 'AzureKeyVault'
      primaryKeyURI: cmkKeyId
    } : {
      type: 'SystemManaged'
    }
  }
}

resource serverRef 'Microsoft.DBforPostgreSQL/flexibleServers@2024-08-01' existing = if (useExistingPostgres) {
  name: last(split(existingPostgresServerId, '/'))
}

// -------------------------------------------------------------
// Firewall rule: allow all Azure services (demo path, created server only)
// -------------------------------------------------------------

resource allowAzure 'Microsoft.DBforPostgreSQL/flexibleServers/firewallRules@2024-08-01' = if (!useExistingPostgres) {
  parent: server
  name: 'AllowAllAzureIPs'
  properties: {
    startIpAddress: '0.0.0.0'
    endIpAddress: '0.0.0.0'
  }
}

// -------------------------------------------------------------
// Entra admin registration (wizard-created servers only)
// -------------------------------------------------------------

resource entraAdmin 'Microsoft.DBforPostgreSQL/flexibleServers/administrators@2024-08-01' = if (!useExistingPostgres && entraAuthEnabled && !empty(entraAdminObjectId)) {
  parent: server
  name: entraAdminObjectId
  properties: {
    principalType: entraAdminType
    principalName: entraAdminPrincipalName
    tenantId: tenantId
  }
}

// -------------------------------------------------------------
// Database — always created, even against BYO server
// -------------------------------------------------------------

resource dbCreated 'Microsoft.DBforPostgreSQL/flexibleServers/databases@2024-08-01' = if (!useExistingPostgres) {
  parent: server
  name: databaseName
  properties: {
    charset: 'UTF8'
    collation: 'en_US.utf8'
  }
}

resource dbExisting 'Microsoft.DBforPostgreSQL/flexibleServers/databases@2024-08-01' = if (useExistingPostgres) {
  parent: serverRef
  name: databaseName
  properties: {
    charset: 'UTF8'
    collation: 'en_US.utf8'
  }
}

// -------------------------------------------------------------
// Outputs — connection string + FQDN
// -------------------------------------------------------------

#disable-next-line BCP318
var serverFqdnResolved = useExistingPostgres ? serverRef.properties.fullyQualifiedDomainName : server.properties.fullyQualifiedDomainName

#disable-next-line BCP318
output serverId string = useExistingPostgres ? existingPostgresServerId : server.id
output serverFqdn string = serverFqdnResolved
output databaseName string = databaseName

@description('Postgres connection string (URL-encoded password). Consumed as DATABASE_URL when entraAuthEnabled=false.')
#disable-next-line outputs-should-not-contain-secrets
output connectionString string = 'postgresql://${adminUser}:${uriComponent(adminPassword)}@${serverFqdnResolved}:5432/${databaseName}?sslmode=require'
