// =============================================================
// apps.bicep — The four Container Apps
// =============================================================
// Deploys adapter (external), admin-ui (external), hr-mcp-server
// (internal), and deploy-server (internal) into the resolved ACA
// Managed Environment. Supports two secret modes:
//   - useKeyVault=false: inline @secure() values as ACA secrets
//   - useKeyVault=true:  keyVaultUrl references resolved via UAMI
// ACR auth: UAMI when available, else admin credentials.
// =============================================================

param location string
param tags object

param acaEnvId string

@description('Pull images from a public registry (unauthenticated) instead of an ACR login server. When true, Container Apps omit the `registries` auth block.')
param usePublicImages bool = false

@description('Registry hostname+prefix (e.g. public.ecr.aws/oktaps or <acr>.azurecr.io). Prepended to per-image names to form full image URIs.')
param imageRegistry string

@description('Adapter image repo name (okta-mcp-adapter on public path; adapter on build-from-source path).')
param adapterImageName string

@description('Admin UI image repo name.')
param adminUiImageName string

@description('HR example MCP server image repo name.')
param hrImageName string

@description('Deploy-server example MCP server image repo name.')
param deployServerImageName string

param acrUsername string = ''
@secure()
param acrPassword string = ''
param uamiResourceId string
@description('Client ID of the UAMI. Phase 2: passed to the adapter so ManagedIdentityCredential picks the right identity when authenticating to Redis via Entra ID.')
param uamiClientId string
param useUamiForAcr bool

param useKeyVault bool
param keyVaultUri string
#disable-next-line secure-secrets-in-params
param kvSecretPrefix string

param oktaDomain string
@secure()
param encryptionKey string
@secure()
param databaseUrl string
@secure()
param redisUrl string
@secure()
param adminUiOktaClientId string
@secure()
param adminUiOktaClientSecret string
@secure()
param nextauthSecret string
param deployOktaClientId string
param deployOktaAuthServerId string
param deployOktaAudience string
@secure()
param hrPskSecret string

param imageTag string
@minValue(1)
@maxValue(65535)
param gatewayPort int
@minValue(1)
@maxValue(65535)
param adminUiPort int
@minValue(1)
@maxValue(65535)
param hrBackendPort int
@minValue(1)
@maxValue(65535)
param deployServerPort int

@description('Use Microsoft Entra ID authentication for Postgres. When true, adapter env vars select DB_CREDENTIAL_PROVIDER=azure_entra and the DATABASE_URL secret is unused.')
param entraAuthEnabled bool = false

@description('Client ID of the app UAMI. Required when entraAuthEnabled=true.')
param appUamiClientId string = ''

@description('Name of the app UAMI (used as the Postgres principal name). Required when entraAuthEnabled=true.')
param appUamiName string = ''

@description('FQDN of the Postgres server. Required when entraAuthEnabled=true.')
param dbHost string = ''

@description('Database name. Required when entraAuthEnabled=true.')
param dbName string = ''

var uamiIdentityBlock = {
  type: 'UserAssigned'
  userAssignedIdentities: {
    '${uamiResourceId}': {}
  }
}

// Container Apps `registries` block. Empty on the public-ECR path (pulls
// are unauthenticated). On the build-from-source path, use UAMI auth when
// available, else inline admin-password.
var acrRegistryBlock = useUamiForAcr ? {
  server: imageRegistry
  identity: uamiResourceId
} : {
  server: imageRegistry
  username: acrUsername
  passwordSecretRef: 'acr-password'
}

var registriesArray = usePublicImages ? [] : [ acrRegistryBlock ]

// Secret blocks: when useKeyVault, each secret references a KV URL + identity.
// Otherwise, inline value.
func secretInline(name string, value string) object => {
  name: name
  value: value
}

func secretKv(name string, uri string, identity string) object => {
  name: name
  keyVaultUrl: uri
  identity: identity
}

// Build the adapter secrets array
var adapterSecretsBase = useKeyVault ? [
  secretKv('encryption-key', '${keyVaultUri}secrets/${kvSecretPrefix}encryption-key', uamiResourceId)
  secretKv('database-url',   '${keyVaultUri}secrets/${kvSecretPrefix}database-url',   uamiResourceId)
  secretKv('redis-url',      '${keyVaultUri}secrets/${kvSecretPrefix}redis-url',      uamiResourceId)
] : [
  secretInline('encryption-key', encryptionKey)
  secretInline('database-url',   databaseUrl)
  secretInline('redis-url',      redisUrl)
]

// acr-password secret only needed on the build-from-source path when UAMI
// auth isn't available. Public pulls are unauthenticated.
var needsAcrPassword = !usePublicImages && !useUamiForAcr
var adapterSecrets = needsAcrPassword ? concat(adapterSecretsBase, [ secretInline('acr-password', acrPassword) ]) : adapterSecretsBase

var adminUiSecretsBase = useKeyVault ? [
  secretKv('okta-client-id',     '${keyVaultUri}secrets/${kvSecretPrefix}admin-ui-client-id',     uamiResourceId)
  secretKv('okta-client-secret', '${keyVaultUri}secrets/${kvSecretPrefix}admin-ui-client-secret', uamiResourceId)
  secretKv('nextauth-secret',    '${keyVaultUri}secrets/${kvSecretPrefix}nextauth-secret',        uamiResourceId)
] : [
  secretInline('okta-client-id',     adminUiOktaClientId)
  secretInline('okta-client-secret', adminUiOktaClientSecret)
  secretInline('nextauth-secret',    nextauthSecret)
]

var adminUiSecrets = needsAcrPassword ? concat(adminUiSecretsBase, [ secretInline('acr-password', acrPassword) ]) : adminUiSecretsBase

var hrSecretsBase = useKeyVault ? [
  secretKv('psk-secret', '${keyVaultUri}secrets/${kvSecretPrefix}hr-psk-secret', uamiResourceId)
] : [
  secretInline('psk-secret', hrPskSecret)
]

var hrSecrets = needsAcrPassword ? concat(hrSecretsBase, [ secretInline('acr-password', acrPassword) ]) : hrSecretsBase

var deploySecrets = needsAcrPassword ? [ secretInline('acr-password', acrPassword) ] : []

// -------------------------------------------------------------
// Adapter (external, min=1)
// -------------------------------------------------------------
resource adapter 'Microsoft.App/containerApps@2024-03-01' = {
  name: 'okta-ps-adapter'
  location: location
  tags: tags
  identity: uamiIdentityBlock
  properties: {
    managedEnvironmentId: acaEnvId
    configuration: {
      ingress: {
        external: true
        targetPort: gatewayPort
        transport: 'auto'
        allowInsecure: false
      }
      registries: registriesArray
      secrets: adapterSecrets
    }
    template: {
      containers: [
        {
          name: 'adapter'
          image: '${imageRegistry}/${adapterImageName}:${imageTag}'
          resources: {
            cpu: json('1.0')
            memory: '2.0Gi'
          }
          env: concat([
            { name: 'OKTA_DOMAIN', value: oktaDomain }
            { name: 'CACHE_PROVIDER', value: 'redis' }
            { name: 'REDIS_TLS_ENABLED', value: 'true' }
            { name: 'REDIS_KEY_PREFIX', value: 'okta-ps-adapter:' }
            { name: 'LOG_LEVEL', value: 'INFO' }
            { name: 'GATEWAY_PORT', value: string(gatewayPort) }
            { name: 'DCR_ENABLED', value: 'true' }
            { name: 'ENCRYPTION_KEY', secretRef: 'encryption-key' }
            { name: 'REDIS_URL', secretRef: 'redis-url' }

            // --- Redis credential provider (Phase 2) ---
            // Entra ID authentication via the UAMI. No access key, no shared
            // secret. The Container App's identity (uamiClientId) acquires
            // an Entra token for the redis.azure.com scope at connect time
            // and presents it as the Redis AUTH password.
            { name: 'REDIS_AUTH_MODE', value: 'azure-entra' }
            { name: 'REDIS_AZURE_USE_MSI', value: 'true' }
            { name: 'REDIS_AZURE_CLIENT_ID', value: uamiClientId }
          ], entraAuthEnabled ? [
            { name: 'DB_CREDENTIAL_PROVIDER', value: 'azure_entra' }
            { name: 'DB_HOST',          value: dbHost }
            { name: 'DB_PORT',          value: '5432' }
            { name: 'DB_NAME',          value: dbName }
            { name: 'DB_USERNAME',      value: appUamiName }
            { name: 'AZURE_CLIENT_ID',  value: appUamiClientId }
          ] : [
            { name: 'DATABASE_URL', secretRef: 'database-url' }
          ])
          probes: [
            {
              type: 'Liveness'
              httpGet: { path: '/health', port: gatewayPort }
              initialDelaySeconds: 30
              periodSeconds: 15
              failureThreshold: 5
            }
            {
              type: 'Readiness'
              httpGet: { path: '/health', port: gatewayPort }
              initialDelaySeconds: 10
              periodSeconds: 5
            }
          ]
        }
      ]
      scale: {
        minReplicas: 1
        maxReplicas: 4
        rules: [
          {
            name: 'http-scale'
            http: { metadata: { concurrentRequests: '80' } }
          }
        ]
      }
    }
  }
}

// -------------------------------------------------------------
// Admin UI (external, min=0)
// -------------------------------------------------------------
resource adminUi 'Microsoft.App/containerApps@2024-03-01' = {
  name: 'admin-ui'
  location: location
  tags: tags
  identity: uamiIdentityBlock
  properties: {
    managedEnvironmentId: acaEnvId
    configuration: {
      ingress: {
        external: true
        targetPort: adminUiPort
        transport: 'auto'
        allowInsecure: false
      }
      registries: registriesArray
      secrets: adminUiSecrets
    }
    template: {
      containers: [
        {
          name: 'admin-ui'
          image: '${imageRegistry}/${adminUiImageName}:${imageTag}'
          resources: {
            cpu: json('0.5')
            memory: '1.0Gi'
          }
          env: [
            { name: 'API_URL', value: 'https://${adapter.properties.configuration.ingress.fqdn}' }
            { name: 'OKTA_DOMAIN', value: oktaDomain }
            { name: 'OKTA_CLIENT_ID', secretRef: 'okta-client-id' }
            { name: 'OKTA_CLIENT_SECRET', secretRef: 'okta-client-secret' }
            { name: 'NEXTAUTH_SECRET', secretRef: 'nextauth-secret' }
          ]
        }
      ]
      scale: {
        minReplicas: 0
        maxReplicas: 2
      }
    }
  }
}

// -------------------------------------------------------------
// HR MCP backend (internal, min=0)
// -------------------------------------------------------------
resource hrBackend 'Microsoft.App/containerApps@2024-03-01' = {
  name: 'hr-mcp-server'
  location: location
  tags: tags
  identity: uamiIdentityBlock
  properties: {
    managedEnvironmentId: acaEnvId
    configuration: {
      ingress: {
        external: false
        targetPort: hrBackendPort
        transport: 'auto'
        allowInsecure: true
      }
      registries: registriesArray
      secrets: hrSecrets
    }
    template: {
      containers: [
        {
          name: 'hr-mcp-server'
          image: '${imageRegistry}/${hrImageName}:${imageTag}'
          resources: {
            cpu: json('0.25')
            memory: '0.5Gi'
          }
          env: [
            { name: 'PSK_SECRET', secretRef: 'psk-secret' }
            { name: 'SERVER_HOST', value: '0.0.0.0' }
            { name: 'SERVER_PORT', value: string(hrBackendPort) }
            { name: 'LOG_LEVEL', value: 'INFO' }
          ]
        }
      ]
      scale: {
        minReplicas: 0
        maxReplicas: 1
      }
    }
  }
}

// -------------------------------------------------------------
// Deploy server (internal, min=0)
// -------------------------------------------------------------
resource deployServer 'Microsoft.App/containerApps@2024-03-01' = {
  name: 'deploy-server'
  location: location
  tags: tags
  identity: uamiIdentityBlock
  properties: {
    managedEnvironmentId: acaEnvId
    configuration: {
      ingress: {
        external: false
        targetPort: deployServerPort
        transport: 'auto'
        allowInsecure: true
      }
      registries: registriesArray
      secrets: deploySecrets
    }
    template: {
      containers: [
        {
          name: 'deploy-server'
          image: '${imageRegistry}/${deployServerImageName}:${imageTag}'
          resources: {
            cpu: json('0.25')
            memory: '0.5Gi'
          }
          env: [
            { name: 'DEPLOY_OKTA_DOMAIN', value: 'https://${oktaDomain}' }
            { name: 'DEPLOY_OKTA_CLIENT_ID', value: deployOktaClientId }
            { name: 'DEPLOY_OKTA_AUTH_SERVER_ID', value: deployOktaAuthServerId }
            { name: 'DEPLOY_OKTA_AUDIENCE', value: deployOktaAudience }
            { name: 'DEPLOY_AUTH_DISABLED', value: empty(deployOktaClientId) ? 'true' : 'false' }
            { name: 'SERVER_HOST', value: '0.0.0.0' }
            { name: 'SERVER_PORT', value: string(deployServerPort) }
            { name: 'LOG_LEVEL', value: 'INFO' }
          ]
        }
      ]
      scale: {
        minReplicas: 0
        maxReplicas: 1
      }
    }
  }
}

// -------------------------------------------------------------
// Outputs
// -------------------------------------------------------------

output adapterFqdn string = adapter.properties.configuration.ingress.fqdn
output adminUiFqdn string = adminUi.properties.configuration.ingress.fqdn
output hrBackendFqdn string = hrBackend.properties.configuration.ingress.fqdn
output deployServerFqdn string = deployServer.properties.configuration.ingress.fqdn
