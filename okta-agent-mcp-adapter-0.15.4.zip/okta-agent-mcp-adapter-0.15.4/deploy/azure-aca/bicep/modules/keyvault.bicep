// =============================================================
// keyvault.bicep — Key Vault + gateway secret references (optional)
// =============================================================
// Used only when useKeyVault=true. Either creates a Key Vault or
// references an existing one, then writes all gateway secrets into
// it and grants Key Vault Secrets User to the UAMI so Container
// Apps can pull them via keyVaultUrl references.
// =============================================================

param location string
param tags object

param existingKeyVaultId string
param vaultName string
#disable-next-line secure-secrets-in-params
param secretPrefix string
param uamiPrincipalId string

@secure()
param encryptionKey string
@secure()
param adminUiOktaClientId string
@secure()
param adminUiOktaClientSecret string
@secure()
param nextauthSecret string
@secure()
param hrPskSecret string
@secure()
param databaseUrl string
@secure()
param redisUrl string

var byoKv = !empty(existingKeyVaultId)

resource kv 'Microsoft.KeyVault/vaults@2024-04-01-preview' = if (!byoKv) {
  name: vaultName
  location: location
  tags: tags
  properties: {
    tenantId: subscription().tenantId
    sku: {
      family: 'A'
      name: 'standard'
    }
    enableRbacAuthorization: true
    enableSoftDelete: true
    softDeleteRetentionInDays: 7
    enablePurgeProtection: false
    publicNetworkAccess: 'Enabled'
  }
}

resource kvRef 'Microsoft.KeyVault/vaults@2024-04-01-preview' existing = if (byoKv) {
  name: last(split(existingKeyVaultId, '/'))
}

// Key Vault Secrets User (built-in role)
var kvSecretsUserRoleId = '4633458b-17de-408a-b874-0445c86b69e6'

resource kvRoleCreated 'Microsoft.Authorization/roleAssignments@2022-04-01' = if (!byoKv) {
  scope: kv
  name: guid(kv.id, uamiPrincipalId, kvSecretsUserRoleId)
  properties: {
    roleDefinitionId: subscriptionResourceId('Microsoft.Authorization/roleDefinitions', kvSecretsUserRoleId)
    principalId: uamiPrincipalId
    principalType: 'ServicePrincipal'
  }
}

resource kvRoleExisting 'Microsoft.Authorization/roleAssignments@2022-04-01' = if (byoKv) {
  scope: kvRef
  name: guid(existingKeyVaultId, uamiPrincipalId, kvSecretsUserRoleId)
  properties: {
    roleDefinitionId: subscriptionResourceId('Microsoft.Authorization/roleDefinitions', kvSecretsUserRoleId)
    principalId: uamiPrincipalId
    principalType: 'ServicePrincipal'
  }
}

// -------------------------------------------------------------
// Secrets (written into whichever vault we resolved)
// -------------------------------------------------------------

var secretDefs = [
  { suffix: 'encryption-key',       value: encryptionKey }
  { suffix: 'database-url',         value: databaseUrl }
  { suffix: 'redis-url',            value: redisUrl }
  { suffix: 'admin-ui-client-id',   value: adminUiOktaClientId }
  { suffix: 'admin-ui-client-secret', value: adminUiOktaClientSecret }
  { suffix: 'nextauth-secret',      value: nextauthSecret }
  { suffix: 'hr-psk-secret',        value: hrPskSecret }
]

// For BYO vault, write secrets using a nested deployment so we can
// target the vault regardless of its resource group.
resource secretsCreated 'Microsoft.KeyVault/vaults/secrets@2024-04-01-preview' = [for s in secretDefs: if (!byoKv) {
  parent: kv
  name: '${secretPrefix}${s.suffix}'
  properties: {
    value: s.value
    contentType: 'text/plain'
  }
}]

resource secretsExisting 'Microsoft.KeyVault/vaults/secrets@2024-04-01-preview' = [for s in secretDefs: if (byoKv) {
  parent: kvRef
  name: '${secretPrefix}${s.suffix}'
  properties: {
    value: s.value
    contentType: 'text/plain'
  }
}]

// -------------------------------------------------------------
// Outputs
// -------------------------------------------------------------

#disable-next-line BCP318
output vaultId string = byoKv ? existingKeyVaultId : kv.id
#disable-next-line BCP318
output vaultUri string = byoKv ? kvRef.properties.vaultUri : kv.properties.vaultUri
output secretPrefix string = secretPrefix
