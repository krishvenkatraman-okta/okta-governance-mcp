// =============================================================
// migrate-job.bicep — Container Apps Job for DB bootstrap + migrations
// =============================================================
// A manual-trigger ACA Job that:
//   1. Connects to Postgres AS the owner UAMI via Microsoft Entra ID
//      (the owner UAMI is registered as the server-level Entra admin
//      in database.bicep, which grants it azure_pg_admin).
//   2. Runs bootstrap_roles.sql to create the two least-privilege DB
//      roles (okta_adapter_owner, okta_adapter_app). Idempotent.
//   3. Creates Entra DB principals for the app + owner UAMIs using
//      pgaadauth_create_principal_with_oid and grants them the
//      corresponding roles. Idempotent.
//   4. Runs `python -m okta_agent_proxy.storage.migrate upgrade` as
//      the owner role to apply pending schema migrations.
//
// Invoked by scripts/deploy.sh after apps are deployed but before
// the smoke test. Can also be run ad-hoc via:
//     az containerapp job start -g <rg> -n <prefix>-migrate
// =============================================================

param location string
param tags object

param jobName string
param acaEnvId string

@description('Registry hostname+prefix (e.g. public.ecr.aws/oktaps or <acr>.azurecr.io).')
param imageRegistry string

@description('Adapter image repo name (okta-mcp-adapter on public path; adapter on build path).')
param adapterImage string

param imageTag string

@description('True when pulling from a public registry — no registries auth block is emitted.')
param usePublicImages bool = false

@description('Resource ID of the owner UAMI. Attached to the job so it authenticates to Postgres as the Entra admin.')
param ownerUamiResourceId string

@description('Client ID of the owner UAMI. Passed to the container so azure-identity picks the correct identity.')
param ownerUamiClientId string

@description('UAMI name used as the Entra admin principal name (matches the DB-level principal created on first login).')
param ownerUamiName string

@description('Resource ID of the app UAMI. Used only to derive its principal name/object ID in SQL.')
param appUamiName string

@description('Object ID (principalId) of the app UAMI. Passed into pgaadauth_create_principal_with_oid.')
param appUamiPrincipalId string

@description('Object ID (principalId) of the owner UAMI. Used for the idempotent owner principal-create call.')
param ownerUamiPrincipalId string

param dbHost string
param dbName string
param dbOwnerRole string
param dbAppRole string

@description('ACR registry block — either UAMI-based or admin-credential based.')
param registryBlock object

@description('Secrets array. Must include acr-password when UAMI-based pull is not available.')
param secretsBlock array = []

// URL-encoded scope for the Azure PG OSS RDBMS Entra resource. Passed into
// the container as AAD_SCOPE so the bootstrap script stays scope-agnostic.
#disable-next-line no-hardcoded-env-urls
var aadScope = 'https%3A%2F%2Fossrdbms-aad.database.windows.net'

// -------------------------------------------------------------
// Inline bootstrap script (runs inside the migrate container)
// -------------------------------------------------------------
// The script is heredoc-embedded so the whole workflow is a single
// ACA Job — no sidecar storage or config maps needed.
// Variables referenced:
//   $DB_HOST, $DB_NAME, $DB_USERNAME (= ownerUamiName)
//   $DB_OWNER_ROLE, $DB_APP_ROLE
//   $APP_UAMI_NAME, $APP_UAMI_OID
//   $OWNER_UAMI_NAME, $OWNER_UAMI_OID
// PGPASSWORD is set to the Entra access token at runtime.
var bootstrapScript = '''
set -euo pipefail

echo ">> Acquiring Entra access token for Postgres..."
ACCESS_TOKEN="$(curl -fsSL -H 'Metadata:true' \
  "http://169.254.169.254/metadata/identity/oauth2/token?api-version=2018-02-01&resource=${AAD_SCOPE}&client_id=${AZURE_CLIENT_ID}" \
  | python3 -c 'import sys,json;print(json.load(sys.stdin)["access_token"])')"
export PGPASSWORD="$ACCESS_TOKEN"

PSQL="psql --set=ON_ERROR_STOP=1 -h ${DB_HOST} -U ${DB_USERNAME} -d ${DB_NAME} -p 5432 -v sslmode=require"

echo ">> Bootstrapping two-role setup..."
DB_OWNER_ROLE="${DB_OWNER_ROLE}" DB_APP_ROLE="${DB_APP_ROLE}" DB_NAME="${DB_NAME}" \
  $PSQL -f /app/deploy/migrations/sql/bootstrap_roles.sql

echo ">> Registering Entra DB principals (idempotent)..."
# pgaadauth_create_principal_with_oid errors if the principal already exists;
# catch the duplicate error and continue.
$PSQL <<SQL || true
SELECT * FROM pgaadauth_create_principal_with_oid(
  '${APP_UAMI_NAME}', '${APP_UAMI_OID}', 'service', false, false);
SQL

$PSQL <<SQL || true
SELECT * FROM pgaadauth_create_principal_with_oid(
  '${OWNER_UAMI_NAME}', '${OWNER_UAMI_OID}', 'service', false, false);
SQL

echo ">> Granting roles to Entra principals..."
$PSQL <<SQL
GRANT ${DB_APP_ROLE}   TO "${APP_UAMI_NAME}";
GRANT ${DB_OWNER_ROLE} TO "${OWNER_UAMI_NAME}";
SQL

echo ">> Applying schema migrations..."
# Re-acquire token (belt-and-suspenders — the prior one may be close to expiry).
export DB_CREDENTIAL_PROVIDER=azure_entra
export DB_PORT=5432
python -m okta_agent_proxy.storage.migrate upgrade --migrations-dir /app/deploy/migrations/sql

echo ">> Done."
'''

// -------------------------------------------------------------
// Container Apps Job
// -------------------------------------------------------------

resource migrateJob 'Microsoft.App/jobs@2024-03-01' = {
  name: jobName
  location: location
  tags: tags
  identity: {
    type: 'UserAssigned'
    userAssignedIdentities: {
      '${ownerUamiResourceId}': {}
    }
  }
  properties: {
    environmentId: acaEnvId
    configuration: {
      triggerType: 'Manual'
      replicaTimeout: 900
      replicaRetryLimit: 0
      manualTriggerConfig: {
        parallelism: 1
        replicaCompletionCount: 1
      }
      registries: usePublicImages ? [] : [ registryBlock ]
      secrets: secretsBlock
    }
    template: {
      containers: [
        {
          name: 'migrate'
          image: '${imageRegistry}/${adapterImage}:${imageTag}'
          resources: {
            cpu: json('0.5')
            memory: '1.0Gi'
          }
          env: [
            { name: 'AZURE_CLIENT_ID',  value: ownerUamiClientId }
            { name: 'AAD_SCOPE',        value: aadScope }
            { name: 'DB_HOST',          value: dbHost }
            { name: 'DB_NAME',          value: dbName }
            { name: 'DB_USERNAME',      value: ownerUamiName }
            { name: 'DB_OWNER_ROLE',    value: dbOwnerRole }
            { name: 'DB_APP_ROLE',      value: dbAppRole }
            { name: 'APP_UAMI_NAME',    value: appUamiName }
            { name: 'APP_UAMI_OID',     value: appUamiPrincipalId }
            { name: 'OWNER_UAMI_NAME',  value: ownerUamiName }
            { name: 'OWNER_UAMI_OID',   value: ownerUamiPrincipalId }
          ]
          command: [ '/bin/sh', '-c' ]
          args: [ bootstrapScript ]
        }
      ]
    }
  }
}

output jobName string = migrateJob.name
output jobId string = migrateJob.id
