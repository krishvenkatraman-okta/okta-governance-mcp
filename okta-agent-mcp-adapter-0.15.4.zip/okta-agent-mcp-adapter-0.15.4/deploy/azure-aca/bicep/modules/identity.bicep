// =============================================================
// identity.bicep — User-Assigned Managed Identity
// =============================================================
// Either creates a UAMI or references an existing one. Downstream
// modules (registry, keyvault, apps) use principalId for role
// assignments and resourceId to attach to Container Apps.
// =============================================================

param location string
param tags object

param byoUami bool
param existingUamiId string
param uamiName string

resource uami 'Microsoft.ManagedIdentity/userAssignedIdentities@2023-01-31' = if (!byoUami) {
  name: uamiName
  location: location
  tags: tags
}

resource uamiRef 'Microsoft.ManagedIdentity/userAssignedIdentities@2023-01-31' existing = if (byoUami) {
  name: last(split(existingUamiId, '/'))
}

#disable-next-line BCP318
output resourceId string = byoUami ? existingUamiId : uami.id
#disable-next-line BCP318
output principalId string = byoUami ? uamiRef.properties.principalId : uami.properties.principalId
#disable-next-line BCP318
output clientId string = byoUami ? uamiRef.properties.clientId : uami.properties.clientId
#disable-next-line BCP318
output name string = byoUami ? last(split(existingUamiId, '/')) : uami.name
