// =============================================================
// cache.bicep — Azure Cache for Redis + optional private endpoint
// =============================================================
// Either creates a Redis cache or references an existing one.
// Enables Microsoft Entra ID authentication and grants the
// adapter's User-Assigned Managed Identity "Data Owner" access
// on the cache. Emits a credential-free rediss:// URL — the
// adapter's azure-entra credential provider supplies AUTH at
// connect time using the UAMI's Entra token.
//
// SKU constraint: Entra ID authentication requires Standard or
// Premium SKU. Basic-tier Azure Cache for Redis does not support
// Entra. main.bicep defaults to Standard for this reason.
// =============================================================

param location string
param tags object

param useExistingRedis bool
param existingRedisId string
param cacheName string
param skuName string
param skuFamily string
param skuCapacity int

param peSubnetId string
param privateDnsZoneId string
param usePrivateEndpoint bool

@description('Principal ID of the UAMI to grant Redis Data Owner access (Entra ID auth).')
param uamiPrincipalId string

resource redis 'Microsoft.Cache/redis@2024-11-01' = if (!useExistingRedis) {
  name: cacheName
  location: location
  tags: tags
  properties: {
    sku: {
      name: skuName
      family: skuFamily
      capacity: skuCapacity
    }
    enableNonSslPort: false
    minimumTlsVersion: '1.2'
    publicNetworkAccess: usePrivateEndpoint ? 'Disabled' : 'Enabled'
    redisConfiguration: {
      'maxmemory-policy': 'allkeys-lru'
      // Phase 2: enable Entra ID authentication. Standard+ SKU only.
      'aad-enabled': 'true'
    }
  }
}

resource redisRef 'Microsoft.Cache/redis@2024-11-01' existing = if (useExistingRedis) {
  name: last(split(existingRedisId, '/'))
}

// -------------------------------------------------------------
// Entra ID access policy — grants the UAMI "Data Owner" on the cache
// -------------------------------------------------------------
// "Data Owner" is a built-in Redis access policy that maps to
// the full read/write/admin RBAC permission set in Redis ACLs.

resource accessPolicyCreated 'Microsoft.Cache/redis/accessPolicyAssignments@2024-11-01' = if (!useExistingRedis) {
  parent: redis
  name: 'okta-mcp-adapter-data-owner'
  properties: {
    accessPolicyName: 'Data Owner'
    objectId: uamiPrincipalId
    objectIdAlias: 'okta-mcp-adapter-uami'
  }
}

resource accessPolicyExisting 'Microsoft.Cache/redis/accessPolicyAssignments@2024-11-01' = if (useExistingRedis) {
  parent: redisRef
  name: 'okta-mcp-adapter-data-owner'
  properties: {
    accessPolicyName: 'Data Owner'
    objectId: uamiPrincipalId
    objectIdAlias: 'okta-mcp-adapter-uami'
  }
}

// -------------------------------------------------------------
// Private endpoint (created Redis only; BYO is assumed to already have one)
// -------------------------------------------------------------

resource pe 'Microsoft.Network/privateEndpoints@2024-01-01' = if (!useExistingRedis && usePrivateEndpoint) {
  name: '${cacheName}-pe'
  location: location
  tags: tags
  properties: {
    subnet: {
      id: peSubnetId
    }
    privateLinkServiceConnections: [
      {
        name: 'redis'
        properties: {
          privateLinkServiceId: redis.id
          groupIds: [ 'redisCache' ]
        }
      }
    ]
  }
}

resource peDns 'Microsoft.Network/privateEndpoints/privateDnsZoneGroups@2024-01-01' = if (!useExistingRedis && usePrivateEndpoint) {
  parent: pe
  name: 'default'
  properties: {
    privateDnsZoneConfigs: [
      {
        name: 'redis'
        properties: {
          privateDnsZoneId: privateDnsZoneId
        }
      }
    ]
  }
}

// -------------------------------------------------------------
// Outputs
// -------------------------------------------------------------

#disable-next-line BCP318
var hostName = useExistingRedis ? redisRef.properties.hostName : redis.properties.hostName

output hostname string = hostName
#disable-next-line BCP318
output resourceId string = useExistingRedis ? existingRedisId : redis.id

@description('TLS Redis connection URL (Phase 2: no embedded credential — the adapter mints an Entra token at connect time).')
output connectionUrl string = 'rediss://${hostName}:6380'
