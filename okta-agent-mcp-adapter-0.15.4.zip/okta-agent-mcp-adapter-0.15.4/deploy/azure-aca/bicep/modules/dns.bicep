// =============================================================
// dns.bicep — Azure DNS records for custom hostnames
// =============================================================
// Deployed only when dnsProvider = azure_dns or delegated. Creates
// CNAME records in an existing Azure DNS zone pointing to the ACA
// app FQDNs. "external" mode emits instructions via main.bicep and
// does not invoke this module.
// =============================================================

param existingDnsZoneId string
param adapterHostname string
param adminHostname string
param adapterFqdn string
param adminUiFqdn string

var zoneName = last(split(existingDnsZoneId, '/'))

// Extract the record label (strip the zone suffix)
// Callers pass fully qualified names like mcp.example.com and the
// zone is example.com — we strip ".example.com" to get "mcp".
var adapterLabel = replace(adapterHostname, '.${zoneName}', '')
var adminLabel = replace(adminHostname, '.${zoneName}', '')

resource zone 'Microsoft.Network/dnsZones@2023-07-01-preview' existing = {
  name: zoneName
}

resource adapterRecord 'Microsoft.Network/dnsZones/CNAME@2023-07-01-preview' = {
  parent: zone
  name: adapterLabel
  properties: {
    TTL: 300
    CNAMERecord: {
      cname: adapterFqdn
    }
  }
}

resource adminRecord 'Microsoft.Network/dnsZones/CNAME@2023-07-01-preview' = {
  parent: zone
  name: adminLabel
  properties: {
    TTL: 300
    CNAMERecord: {
      cname: adminUiFqdn
    }
  }
}

output adapterRecordFqdn string = '${adapterLabel}.${zoneName}'
output adminRecordFqdn string = '${adminLabel}.${zoneName}'
