// =============================================================
// observability.bicep — Log Analytics + ACA Managed Environment
// =============================================================
// Creates or references a Log Analytics workspace, then creates or
// references an ACA Managed Environment wired to that workspace.
// When VNet-integrated, the env uses `internal` ingress mode and
// the provided infrastructure subnet.
// =============================================================

param location string
param tags object

param byoLogAnalytics bool
param existingLawResourceId string
param lawName string

param byoAcaEnv bool
param existingAcaEnvResourceId string
param acaEnvName string

@description('ACA infrastructure subnet ID. Used only when creating an ACA env in VNet mode.')
param acaInfrastructureSubnetId string

@description('When true, ACA env uses internal ingress (requires VNet). False = public.')
param internal bool

// -------------------------------------------------------------
// Log Analytics workspace
// -------------------------------------------------------------

resource law 'Microsoft.OperationalInsights/workspaces@2023-09-01' = if (!byoLogAnalytics) {
  name: lawName
  location: location
  tags: tags
  properties: {
    sku: {
      name: 'PerGB2018'
    }
    retentionInDays: 30
  }
}

resource lawRef 'Microsoft.OperationalInsights/workspaces@2023-09-01' existing = if (byoLogAnalytics) {
  name: last(split(existingLawResourceId, '/'))
  scope: resourceGroup(split(existingLawResourceId, '/')[2], split(existingLawResourceId, '/')[4])
}

#disable-next-line BCP318
var lawCustomerId = byoLogAnalytics ? lawRef.properties.customerId : law.properties.customerId
#disable-next-line BCP318 BCP422
var lawSharedKey = byoLogAnalytics ? lawRef.listKeys().primarySharedKey : law.listKeys().primarySharedKey

// -------------------------------------------------------------
// ACA Managed Environment
// -------------------------------------------------------------

resource acaEnv 'Microsoft.App/managedEnvironments@2024-03-01' = if (!byoAcaEnv) {
  name: acaEnvName
  location: location
  tags: tags
  properties: {
    appLogsConfiguration: {
      destination: 'log-analytics'
      logAnalyticsConfiguration: {
        customerId: lawCustomerId
        sharedKey: lawSharedKey
      }
    }
    vnetConfiguration: internal ? {
      infrastructureSubnetId: acaInfrastructureSubnetId
      internal: true
    } : null
    zoneRedundant: false
  }
}

resource acaEnvRef 'Microsoft.App/managedEnvironments@2024-03-01' existing = if (byoAcaEnv) {
  name: last(split(existingAcaEnvResourceId, '/'))
}

// -------------------------------------------------------------
// Outputs
// -------------------------------------------------------------

#disable-next-line BCP318
output lawId string = byoLogAnalytics ? existingLawResourceId : law.id
#disable-next-line BCP318
output acaEnvId string = byoAcaEnv ? existingAcaEnvResourceId : acaEnv.id
#disable-next-line BCP318
output acaEnvName string = byoAcaEnv ? last(split(existingAcaEnvResourceId, '/')) : acaEnv.name
#disable-next-line BCP318
output acaEnvDefaultDomain string = byoAcaEnv ? acaEnvRef.properties.defaultDomain : acaEnv.properties.defaultDomain
