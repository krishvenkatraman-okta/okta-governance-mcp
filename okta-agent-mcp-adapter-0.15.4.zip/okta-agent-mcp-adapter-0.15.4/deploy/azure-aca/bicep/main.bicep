// =============================================================
// main.bicep — Okta MCP Adapter on Azure Container Apps
// =============================================================
// Subscription-scoped template that creates (or references) a
// resource group, then deploys all subsystems via modules. Every
// reusable subsystem has a "bring-your-own" (BYO) toggle so this
// template can target either a clean demo subscription or an
// existing enterprise environment.
//
// Deploy with:
//   az deployment sub create \
//     --location <region> \
//     --template-file main.bicep \
//     --parameters main.bicepparam
//
// Preview changes with:
//   az deployment sub what-if \
//     --location <region> \
//     --template-file main.bicep \
//     --parameters main.bicepparam
// =============================================================

targetScope = 'subscription'

// -------------------------------------------------------------
// Core parameters
// -------------------------------------------------------------

@description('Azure region for all resources (e.g. eastus2).')
param location string

@description('Resource group name. Created if existingResourceGroupName is empty; otherwise ignored.')
param resourceGroupName string = 'okta-ps-adapter-demo'

@description('Name of an existing resource group to deploy into. Leave empty to create a new RG.')
param existingResourceGroupName string = ''

@description('Tags applied to all wizard-created resources. Ignored for BYO resources.')
param tags object = {
  wizard: 'okta-ps-adapter'
  'managed-by': 'bicep'
}

// -------------------------------------------------------------
// Bundle 1: Network + data plane
// -------------------------------------------------------------

@description('Reuse an existing VNet instead of creating one. Required when existingVnetId is set.')
param useExistingVnet bool = false

@description('Full resource ID of an existing VNet to deploy into. Required if useExistingVnet=true.')
param existingVnetId string = ''

@description('Full resource ID of an existing subnet for ACA infrastructure (needs >=/23). Required if useExistingVnet=true.')
param existingAcaSubnetId string = ''

@description('Full resource ID of an existing subnet for private endpoints. Required if useExistingVnet=true.')
param existingPeSubnetId string = ''

@description('VNet name when creating (ignored if BYO).')
param vnetName string = 'okta-adapter-vnet'

@description('VNet address prefix when creating (ignored if BYO).')
param vnetAddressPrefix string = '10.0.0.0/16'

@description('ACA infra subnet CIDR when creating (must be >=/23).')
param acaSubnetPrefix string = '10.0.0.0/23'

@description('Private endpoint subnet CIDR when creating.')
param peSubnetPrefix string = '10.0.2.0/24'

@description('Existing Private DNS zone for postgres (privatelink.postgres.database.azure.com). Empty = create new.')
param existingPgDnsZoneId string = ''

@description('Existing Private DNS zone for redis (privatelink.redis.cache.windows.net). Empty = create new.')
param existingRedisDnsZoneId string = ''

@description('Full resource ID of a remote VNet to peer with. Empty disables peering.')
param peerVnetResourceId string = ''

@description('Name for the local side of the VNet peering.')
param peerName string = 'adapter-to-remote'

@description('Reuse an existing Postgres Flexible Server instead of creating one.')
param useExistingPostgres bool = false

@description('Full resource ID of existing Postgres Flexible Server. Required if useExistingPostgres=true.')
param existingPostgresServerId string = ''

@description('Admin username for Postgres. Used for creating wizard-owned server; for BYO must match the existing server admin.')
param postgresAdminUser string = 'gwadmin'

@description('Admin password for Postgres. For BYO this must be the existing server admin password.')
@secure()
param postgresAdminPassword string

@description('Postgres database name created for the gateway (always created, even on BYO servers).')
param postgresDatabaseName string = 'gateway_db'

@description('Postgres SKU when creating (ignored on BYO).')
param postgresSkuName string = 'Standard_B1ms'

@description('Postgres tier when creating (ignored on BYO).')
param postgresSkuTier string = 'Burstable'

@description('Postgres storage in GB when creating (ignored on BYO).')
param postgresStorageGB int = 32

@description('Reuse an existing Redis cache instead of creating one.')
param useExistingRedis bool = false

@description('Full resource ID of existing Redis cache. Required if useExistingRedis=true.')
param existingRedisId string = ''

@description('Redis SKU name when creating. Standard or Premium required for Entra ID authentication (Phase 2). Basic tier does not support Entra.')
@allowed(['Standard', 'Premium'])
param redisSkuName string = 'Standard'

@description('Redis SKU family when creating. C=Standard, P=Premium.')
@allowed(['C', 'P'])
param redisSkuFamily string = 'C'

@description('Redis SKU capacity (size). 0 = C0 smallest.')
@minValue(0)
@maxValue(6)
param redisSkuCapacity int = 0

// -------------------------------------------------------------
// Bundle 2: Platform shared services
// -------------------------------------------------------------

@description('Pull prebuilt adapter images from a public container registry instead of building into ACR. Default true → no ACR is provisioned and the deploy skips the in-account build phase. Set false to opt into the previous `az acr build` flow (see `--build-from-source`).')
param usePublicImages bool = true

@description('Public container registry the images are pulled from when usePublicImages=true. Defaults to the canonical ECR Public alias. Override only if you have mirrored the images to a different public namespace.')
param publicImageRegistry string = 'public.ecr.aws/oktaps'

@description('Reuse an existing Azure Container Registry. Ignored when usePublicImages=true.')
param byoAcr bool = false

@description('Full resource ID of existing ACR. Required if byoAcr=true.')
param existingAcrResourceId string = ''

@description('Login server for existing ACR (e.g. myregistry.azurecr.io). Required if byoAcr=true.')
param existingAcrLoginServer string = ''

@description('ACR name when creating. Must be globally unique, 5-50 alphanumeric. Ignored when usePublicImages=true.')
param acrName string = ''

@description('Reuse an existing Log Analytics workspace.')
param byoLogAnalytics bool = false

@description('Full resource ID of existing Log Analytics workspace. Required if byoLogAnalytics=true.')
param existingLawResourceId string = ''

@description('Log Analytics workspace name when creating.')
param lawName string = 'okta-ps-adapter-law'

@description('Reuse an existing ACA Managed Environment.')
param byoAcaEnv bool = false

@description('Full resource ID of existing ACA Managed Environment. Required if byoAcaEnv=true.')
param existingAcaEnvResourceId string = ''

@description('ACA Managed Environment name when creating.')
param acaEnvName string = 'okta-ps-adapter-env'

// -------------------------------------------------------------
// Bundle 3: Security + identity
// -------------------------------------------------------------

@description('Store secrets in Azure Key Vault instead of inline ACA secrets. Requires UAMI with Key Vault Secrets User role.')
param useKeyVault bool = false

@description('Full resource ID of existing Key Vault. Required if useKeyVault=true.')
param existingKeyVaultId string = ''

@description('Name prefix for secrets stored in Key Vault.')
#disable-next-line secure-secrets-in-params
param kvSecretPrefix string = 'mcp-'

@description('Reuse an existing User-Assigned Managed Identity for ACR pull / Key Vault access (used by apps — runtime role).')
param byoUami bool = false

@description('Full resource ID of existing UAMI. Required if byoUami=true.')
param existingUamiId string = ''

@description('UAMI name when creating (runtime/app identity).')
param uamiName string = 'okta-ps-adapter-uami'

@description('Reuse an existing UAMI for the DB owner (migration runner). When omitted, one is created.')
param byoOwnerUami bool = false

@description('Full resource ID of existing owner UAMI. Required if byoOwnerUami=true.')
param existingOwnerUamiId string = ''

@description('Owner UAMI name when creating. Attached to the migrate ACA Job and registered as the Entra admin on Postgres.')
param ownerUamiName string = 'okta-ps-adapter-owner-uami'

@description('Enable Microsoft Entra ID authentication for Postgres. When true, the owner UAMI is set as the Entra admin and apps connect via azure_entra.')
param entraAuthEnabled bool = true

@description('Database role used for migrations (DDL). IAM-enabled.')
param dbOwnerRole string = 'okta_adapter_owner'

@description('Database role used by the adapter at runtime (DML only). IAM-enabled.')
param dbAppRole string = 'okta_adapter_app'

@description('Customer-managed key (CMK) for Postgres encryption. Empty = platform-managed.')
param existingCmkKeyIdPostgres string = ''

// -------------------------------------------------------------
// Bundle 4: DNS + ingress
// -------------------------------------------------------------

@description('DNS integration mode. none=use ACA FQDN; azure_dns=create records in BYO zone; delegated=subdomain owned by Azure DNS; external=manual CNAME instructions.')
@allowed(['none', 'azure_dns', 'delegated', 'external'])
param dnsProvider string = 'none'

@description('Full resource ID of the Azure DNS zone. Required if dnsProvider=azure_dns or delegated.')
param existingDnsZoneId string = ''

@description('Hostname for the adapter (e.g. mcp.example.com). Required when dnsProvider != none.')
param adapterHostname string = ''

@description('Hostname for the admin UI (e.g. mcp-admin.example.com). Required when dnsProvider != none.')
param adminHostname string = ''

@description('Upstream ingress mode. none=direct ACA ingress; app_gateway|front_door emit wiring instructions only.')
@allowed(['none', 'app_gateway', 'front_door'])
param upstreamIngress string = 'none'

@description('Full resource ID of existing Application Gateway (for wiring instructions only).')
param existingAppGatewayId string = ''

@description('Full resource ID of existing Front Door profile (for wiring instructions only).')
param existingFrontDoorProfileId string = ''

// -------------------------------------------------------------
// App configuration
// -------------------------------------------------------------

@description('Okta org domain (e.g. dev-12345.okta.com).')
param oktaDomain string

@description('Encryption key for AES-256-GCM field encryption (base64, 32 bytes).')
@secure()
param encryptionKey string

@description('Okta client ID for deploy-server (enables ID-JAG). Empty = auth disabled.')
param deployOktaClientId string = ''

@description('Okta custom auth server ID for deploy-server.')
param deployOktaAuthServerId string = ''

@description('Okta audience for deploy-server access tokens.')
param deployOktaAudience string = ''

@description('Okta OIDC client ID for admin-ui (NextAuth).')
@secure()
param adminUiOktaClientId string = ''

@description('Okta OIDC client secret for admin-ui (NextAuth).')
@secure()
param adminUiOktaClientSecret string = ''

@description('NextAuth session-signing secret.')
@secure()
param nextauthSecret string

@description('Pre-shared key for HR MCP backend demo.')
@secure()
param hrPskSecret string

@description('Image tag for all Container Apps (override for blue/green or promotion).')
param imageTag string = 'latest'

@description('Deploy the four Container Apps. Set false for the initial infra-only pass so images can be built into ACR before apps are created.')
param deployApps bool = true

@minValue(1)
@maxValue(65535)
param gatewayPort int = 8000
@minValue(1)
@maxValue(65535)
param adminUiPort int = 3001
@minValue(1)
@maxValue(65535)
param hrBackendPort int = 8001
@minValue(1)
@maxValue(65535)
param deployServerPort int = 8005

// -------------------------------------------------------------
// Resource group: create or reference
// -------------------------------------------------------------

var useExistingRg = !empty(existingResourceGroupName)
var resolvedRgName = useExistingRg ? existingResourceGroupName : resourceGroupName

resource rg 'Microsoft.Resources/resourceGroups@2023-07-01' = if (!useExistingRg) {
  name: resolvedRgName
  location: location
  tags: tags
}

// -------------------------------------------------------------
// Modules (deployed into resolvedRgName)
// -------------------------------------------------------------

module networking 'modules/networking.bicep' = {
  scope: resourceGroup(resolvedRgName)
  name: 'networking'
  dependsOn: [ rg ]
  params: {
    location: location
    tags: tags
    useExistingVnet: useExistingVnet
    existingVnetId: existingVnetId
    existingAcaSubnetId: existingAcaSubnetId
    existingPeSubnetId: existingPeSubnetId
    vnetName: vnetName
    vnetAddressPrefix: vnetAddressPrefix
    acaSubnetPrefix: acaSubnetPrefix
    peSubnetPrefix: peSubnetPrefix
    existingPgDnsZoneId: existingPgDnsZoneId
    existingRedisDnsZoneId: existingRedisDnsZoneId
    peerVnetResourceId: peerVnetResourceId
    peerName: peerName
  }
}

module identity 'modules/identity.bicep' = {
  scope: resourceGroup(resolvedRgName)
  name: 'identity'
  dependsOn: [ rg ]
  params: {
    location: location
    tags: tags
    byoUami: byoUami
    existingUamiId: existingUamiId
    uamiName: uamiName
  }
}

module ownerIdentity 'modules/identity.bicep' = {
  scope: resourceGroup(resolvedRgName)
  name: 'ownerIdentity'
  dependsOn: [ rg ]
  params: {
    location: location
    tags: tags
    byoUami: byoOwnerUami
    existingUamiId: existingOwnerUamiId
    uamiName: ownerUamiName
  }
}

// ACR is only provisioned on the build-from-source path. When
// usePublicImages=true, images are pulled from `publicImageRegistry` and no
// ACR is needed.
module registry 'modules/registry.bicep' = if (!usePublicImages) {
  scope: resourceGroup(resolvedRgName)
  name: 'registry'
  dependsOn: [ rg ]
  params: {
    location: location
    tags: tags
    byoAcr: byoAcr
    existingAcrResourceId: existingAcrResourceId
    existingAcrLoginServer: existingAcrLoginServer
    acrName: empty(acrName) ? 'oktapsadapter${uniqueString(subscription().subscriptionId, resolvedRgName)}' : acrName
    uamiPrincipalId: identity.outputs.principalId
  }
}

// -------------------------------------------------------------
// Image resolution
// -------------------------------------------------------------
// When pulling from public.ecr.aws the per-image names follow the public
// convention (okta-mcp-*). When building from source, the existing ACR
// repo names are preserved so existing deployments don't have orphaned
// ACR repos.
#disable-next-line BCP318
var imageRegistry = usePublicImages ? publicImageRegistry : registry.outputs.loginServer

var adapterImageName       = usePublicImages ? 'okta-mcp-adapter'       : 'adapter'
var adminUiImageName       = usePublicImages ? 'okta-mcp-admin-ui'      : 'admin-ui'
var hrImageName            = usePublicImages ? 'okta-mcp-hr-server'     : 'hr-mcp-server'
var deployServerImageName  = usePublicImages ? 'okta-mcp-deploy-server' : 'deploy-server'

module database 'modules/database.bicep' = {
  scope: resourceGroup(resolvedRgName)
  name: 'database'
  dependsOn: [ rg ]
  params: {
    location: location
    tags: tags
    useExistingPostgres: useExistingPostgres
    existingPostgresServerId: existingPostgresServerId
    serverName: 'okta-ps-pg-${uniqueString(subscription().subscriptionId, resolvedRgName)}'
    adminUser: postgresAdminUser
    adminPassword: postgresAdminPassword
    databaseName: postgresDatabaseName
    skuName: postgresSkuName
    skuTier: postgresSkuTier
    storageGB: postgresStorageGB
    cmkKeyId: existingCmkKeyIdPostgres
    entraAuthEnabled: entraAuthEnabled
    entraAdminObjectId: ownerIdentity.outputs.principalId
    entraAdminPrincipalName: ownerIdentity.outputs.name
    entraAdminType: 'ServicePrincipal'
  }
}

module cache 'modules/cache.bicep' = {
  scope: resourceGroup(resolvedRgName)
  name: 'cache'
  dependsOn: [ rg ]
  params: {
    location: location
    tags: tags
    useExistingRedis: useExistingRedis
    existingRedisId: existingRedisId
    cacheName: 'okta-ps-redis-${uniqueString(subscription().subscriptionId, resolvedRgName)}'
    skuName: redisSkuName
    skuFamily: redisSkuFamily
    skuCapacity: redisSkuCapacity
    peSubnetId: networking.outputs.peSubnetId
    privateDnsZoneId: networking.outputs.redisDnsZoneId
    // Standard+ SKU is always the case now (Basic blocked by @allowed
    // since Entra requires Standard+), and Standard+ supports private
    // endpoints — enable by default.
    usePrivateEndpoint: true
    // Phase 2: grant the UAMI Data Owner for Entra ID auth.
    uamiPrincipalId: identity.outputs.principalId
  }
}

module observability 'modules/observability.bicep' = {
  scope: resourceGroup(resolvedRgName)
  name: 'observability'
  dependsOn: [ rg ]
  params: {
    location: location
    tags: tags
    byoLogAnalytics: byoLogAnalytics
    existingLawResourceId: existingLawResourceId
    lawName: lawName
    byoAcaEnv: byoAcaEnv
    existingAcaEnvResourceId: existingAcaEnvResourceId
    acaEnvName: acaEnvName
    acaInfrastructureSubnetId: networking.outputs.acaSubnetId
    internal: useExistingVnet
  }
}

module keyvault 'modules/keyvault.bicep' = if (useKeyVault) {
  scope: resourceGroup(resolvedRgName)
  name: 'keyvault'
  dependsOn: [ rg ]
  params: {
    location: location
    tags: tags
    existingKeyVaultId: existingKeyVaultId
    vaultName: 'okta-ps-kv-${uniqueString(subscription().subscriptionId, resolvedRgName)}'
    secretPrefix: kvSecretPrefix
    uamiPrincipalId: identity.outputs.principalId
    encryptionKey: encryptionKey
    adminUiOktaClientId: adminUiOktaClientId
    adminUiOktaClientSecret: adminUiOktaClientSecret
    nextauthSecret: nextauthSecret
    hrPskSecret: hrPskSecret
    databaseUrl: database.outputs.connectionString
    redisUrl: cache.outputs.connectionUrl
  }
}

module apps 'modules/apps.bicep' = if (deployApps) {
  scope: resourceGroup(resolvedRgName)
  name: 'apps'
  dependsOn: [ rg ]
  params: {
    location: location
    tags: tags
    acaEnvId: observability.outputs.acaEnvId
    usePublicImages: usePublicImages
    imageRegistry: imageRegistry
    adapterImageName: adapterImageName
    adminUiImageName: adminUiImageName
    hrImageName: hrImageName
    deployServerImageName: deployServerImageName
    #disable-next-line BCP318
    acrUsername: usePublicImages ? '' : registry.outputs.adminUsername
    #disable-next-line BCP318
    acrPassword: usePublicImages ? '' : registry.outputs.adminPassword
    uamiResourceId: identity.outputs.resourceId
    uamiClientId: identity.outputs.clientId
    useUamiForAcr: !usePublicImages && (!byoAcr || !empty(existingUamiId) || !byoUami)
    useKeyVault: useKeyVault
    #disable-next-line BCP318
    keyVaultUri: useKeyVault ? keyvault.outputs.vaultUri : ''
    kvSecretPrefix: kvSecretPrefix
    oktaDomain: oktaDomain
    encryptionKey: encryptionKey
    databaseUrl: database.outputs.connectionString
    redisUrl: cache.outputs.connectionUrl
    adminUiOktaClientId: adminUiOktaClientId
    adminUiOktaClientSecret: adminUiOktaClientSecret
    nextauthSecret: nextauthSecret
    deployOktaClientId: deployOktaClientId
    deployOktaAuthServerId: deployOktaAuthServerId
    deployOktaAudience: deployOktaAudience
    hrPskSecret: hrPskSecret
    imageTag: imageTag
    gatewayPort: gatewayPort
    adminUiPort: adminUiPort
    hrBackendPort: hrBackendPort
    deployServerPort: deployServerPort
    entraAuthEnabled: entraAuthEnabled
    appUamiClientId: identity.outputs.clientId
    appUamiName: identity.outputs.name
    dbHost: database.outputs.serverFqdn
    dbName: database.outputs.databaseName
  }
}

module migrateJob 'modules/migrate-job.bicep' = if (deployApps && entraAuthEnabled) {
  scope: resourceGroup(resolvedRgName)
  name: 'migrateJob'
  dependsOn: [ rg ]
  params: {
    location: location
    tags: tags
    jobName: 'okta-ps-adapter-migrate'
    acaEnvId: observability.outputs.acaEnvId
    imageRegistry: imageRegistry
    adapterImage: adapterImageName
    imageTag: imageTag
    usePublicImages: usePublicImages
    ownerUamiResourceId: ownerIdentity.outputs.resourceId
    ownerUamiClientId: ownerIdentity.outputs.clientId
    ownerUamiName: ownerIdentity.outputs.name
    ownerUamiPrincipalId: ownerIdentity.outputs.principalId
    appUamiName: identity.outputs.name
    appUamiPrincipalId: identity.outputs.principalId
    dbHost: database.outputs.serverFqdn
    dbName: database.outputs.databaseName
    dbOwnerRole: dbOwnerRole
    dbAppRole: dbAppRole
    // On public-registry path, no registry auth is needed (public pulls are
    // unauthenticated). On build path, pick UAMI auth when available, else
    // inline admin-password secret.
    registryBlock: usePublicImages ? {} : ((!byoAcr || !empty(existingUamiId) || !byoUami) ? {
      #disable-next-line BCP318
      server: registry.outputs.loginServer
      identity: ownerIdentity.outputs.resourceId
    } : {
      #disable-next-line BCP318
      server: registry.outputs.loginServer
      #disable-next-line BCP318
      username: registry.outputs.adminUsername
      passwordSecretRef: 'acr-password'
    })
    secretsBlock: (usePublicImages || !byoAcr || !empty(existingUamiId) || !byoUami) ? [] : [ {
      name: 'acr-password'
      #disable-next-line BCP318
      value: registry.outputs.adminPassword
    } ]
  }
}

module dns 'modules/dns.bicep' = if (deployApps && (dnsProvider == 'azure_dns' || dnsProvider == 'delegated')) {
  scope: resourceGroup(split(existingDnsZoneId, '/')[4])
  name: 'dns'
  params: {
    existingDnsZoneId: existingDnsZoneId
    adapterHostname: adapterHostname
    adminHostname: adminHostname
    #disable-next-line BCP318
    adapterFqdn: apps.outputs.adapterFqdn
    #disable-next-line BCP318
    adminUiFqdn: apps.outputs.adminUiFqdn
  }
}

// -------------------------------------------------------------
// Outputs
// -------------------------------------------------------------

output resourceGroupName string = resolvedRgName
#disable-next-line BCP318
output acrLoginServer string = usePublicImages ? '' : registry.outputs.loginServer
output imageRegistry string = imageRegistry
output acaEnvId string = observability.outputs.acaEnvId
output uamiResourceId string = identity.outputs.resourceId
output uamiPrincipalId string = identity.outputs.principalId
#disable-next-line BCP318
output adapterFqdn string = deployApps ? apps.outputs.adapterFqdn : ''
#disable-next-line BCP318
output adminUiFqdn string = deployApps ? apps.outputs.adminUiFqdn : ''
#disable-next-line BCP318
output hrBackendFqdn string = deployApps ? apps.outputs.hrBackendFqdn : ''
#disable-next-line BCP318
output deployServerFqdn string = deployApps ? apps.outputs.deployServerFqdn : ''
output postgresServerFqdn string = database.outputs.serverFqdn
output redisHostname string = cache.outputs.hostname
#disable-next-line BCP318
output migrateJobName string = (deployApps && entraAuthEnabled) ? migrateJob.outputs.jobName : ''
output ownerUamiResourceId string = ownerIdentity.outputs.resourceId
output ownerUamiPrincipalId string = ownerIdentity.outputs.principalId
#disable-next-line BCP318
output keyVaultUri string = useKeyVault ? keyvault.outputs.vaultUri : ''

@description('DNS wiring instructions for "external" mode (shown only when dnsProvider=external).')
#disable-next-line BCP318
output dnsInstructions string = (deployApps && dnsProvider == 'external') ? 'Create the following DNS records in your external DNS provider:\n  ${adapterHostname} CNAME ${apps.outputs.adapterFqdn}\n  ${adminHostname} CNAME ${apps.outputs.adminUiFqdn}' : ''

@description('Upstream ingress wiring instructions (shown when upstreamIngress != none).')
#disable-next-line BCP318
output upstreamIngressInstructions string = (deployApps && upstreamIngress == 'app_gateway') ? 'Wire Application Gateway backend pool to ${apps.outputs.adapterFqdn} and ${apps.outputs.adminUiFqdn}. Existing AGW: ${existingAppGatewayId}' : (deployApps && upstreamIngress == 'front_door') ? 'Add Front Door origin pointing to ${apps.outputs.adapterFqdn}. Existing FD profile: ${existingFrontDoorProfileId}' : ''
