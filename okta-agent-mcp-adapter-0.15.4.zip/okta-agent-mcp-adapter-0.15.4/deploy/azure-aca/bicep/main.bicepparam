// =============================================================
// main.bicepparam — Demo defaults (no BYO)
// =============================================================
// Rendered by scripts/deploy.sh from .env + .deploy.state. Edit
// by hand only if you know what you're doing; running the wizard
// again will overwrite it.
// =============================================================

using 'main.bicep'

// Core
param location = readEnvironmentVariable('AZURE_LOCATION', 'eastus2')
param resourceGroupName = readEnvironmentVariable('AZURE_RG', 'okta-ps-adapter-demo')
param existingResourceGroupName = readEnvironmentVariable('EXISTING_RG_NAME', '')

// Secrets (wizard generates and injects via env)
param postgresAdminPassword = readEnvironmentVariable('PG_ADMIN_PASSWORD', '')
param encryptionKey = readEnvironmentVariable('ENCRYPTION_KEY', '')
param nextauthSecret = readEnvironmentVariable('NEXTAUTH_SECRET', '')
param hrPskSecret = readEnvironmentVariable('HR_PSK_SECRET', '')

// Okta
param oktaDomain = readEnvironmentVariable('OKTA_DOMAIN', '')
param adminUiOktaClientId = readEnvironmentVariable('ADMIN_UI_OKTA_CLIENT_ID', '')
param adminUiOktaClientSecret = readEnvironmentVariable('ADMIN_UI_OKTA_CLIENT_SECRET', '')
param deployOktaClientId = readEnvironmentVariable('DEPLOY_OKTA_CLIENT_ID', '')
param deployOktaAuthServerId = readEnvironmentVariable('DEPLOY_OKTA_AUTH_SERVER_ID', '')
param deployOktaAudience = readEnvironmentVariable('DEPLOY_OKTA_AUDIENCE', '')

// Image source — default pulls prebuilt images from ECR Public (no ACR
// needed). Set USE_PUBLIC_IMAGES=false to opt into the `az acr build` flow.
param usePublicImages = toLower(readEnvironmentVariable('USE_PUBLIC_IMAGES', 'true')) == 'true'
param publicImageRegistry = readEnvironmentVariable('PUBLIC_IMAGE_REGISTRY', 'public.ecr.aws/oktaps')

// Image tag — on the public path, deploy.sh sets this to v<pyproject version>.
// On the build-from-source path, deploy.sh sets a timestamped tag.
param imageTag = readEnvironmentVariable('IMAGE_TAG', 'latest')

// Microsoft Entra ID auth for Postgres. Default is on — the adapter and
// migrate job authenticate as user-assigned managed identities, no static
// password in DATABASE_URL. Set ENTRA_AUTH_ENABLED=false to fall back to
// the legacy DATABASE_URL path (static admin password).
param entraAuthEnabled = toLower(readEnvironmentVariable('ENTRA_AUTH_ENABLED', 'true')) == 'true'
