#!/usr/bin/env bash
set -euo pipefail
# DEPRECATED: this file moved to scripts/deploy-adapter.sh.
# Exec the new location so existing runbooks keep working.
exec "$(cd "$(dirname "$0")" && pwd)/scripts/deploy-adapter.sh" "$@"
