#!/usr/bin/env bash
set -euo pipefail
# =============================================================
# acasetup.sh — DEPRECATED compatibility shim
# =============================================================
# This wizard has been replaced by the thin bash + full Bicep
# layout under scripts/ and bicep/. See README.md for the new
# workflow.
#
# This shim exists so existing runbooks and docs continue to
# work for one release cycle. It maps the old --custom-vnet
# and --peer-vnet flags to the new BYO model and execs
# scripts/deploy.sh.
# =============================================================

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"

if [[ -n "${NO_COLOR:-}" ]] || [[ ! -t 1 ]]; then
  YELLOW='' CYAN='' NC=''
else
  YELLOW='\033[1;33m'; CYAN='\033[0;36m'; NC='\033[0m'
fi

cat >&2 <<BANNER
${YELLOW}-------------------------------------------------------------${NC}
${YELLOW}DEPRECATED${NC}: acasetup.sh has been replaced by scripts/deploy.sh.

The wizard is now built on full Bicep. Run:

  ${CYAN}./scripts/deploy.sh${NC}              # apply
  ${CYAN}./scripts/deploy.sh --what-if${NC}    # preview
  ${CYAN}./scripts/deploy.sh --destroy${NC}    # BYO-safe teardown

See README.md for the new workflow and .env.byo.example for the
BYO options (existing VNet, Postgres, Redis, ACR, Log Analytics,
Key Vault, UAMI, DNS zone, etc.).

This shim will be removed in a future release.
${YELLOW}-------------------------------------------------------------${NC}

BANNER

forwarded=()
while [[ $# -gt 0 ]]; do
  case "$1" in
    --custom-vnet)
      printf "${YELLOW}[WARN]${NC} --custom-vnet is now the default; flag ignored.\n" >&2
      shift
      ;;
    --peer-vnet)
      printf "${YELLOW}[WARN]${NC} --peer-vnet: set PEER_VNET_RESOURCE_ID in .env instead.\n" >&2
      shift
      [[ $# -gt 0 && "$1" != --* ]] && { export PEER_VNET_RESOURCE_ID="$1"; shift; }
      ;;
    *)
      forwarded+=("$1")
      shift
      ;;
  esac
done

exec "$SCRIPT_DIR/scripts/deploy.sh" ${forwarded+"${forwarded[@]}"}
