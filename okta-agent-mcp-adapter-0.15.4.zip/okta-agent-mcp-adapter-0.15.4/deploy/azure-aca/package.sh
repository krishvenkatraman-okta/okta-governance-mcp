#!/usr/bin/env bash
set -euo pipefail

# =============================================================
# package.sh — Build ACA deployment tarballs
# =============================================================
# Produces one or both of:
#
#   okta-ps-adapter-azure-aca-${VERSION}.tar.gz         (deploy-only)
#     deploy/azure-aca + deploy/shell-lib + deploy/migrations/sql.
#     For customers pulling from public.ecr.aws. --build-from-source
#     dies fast with a pointer to the source bundle.
#
#   okta-ps-adapter-azure-aca-source-${VERSION}.tar.gz  (source)
#     Adds Dockerfile, adapter source, admin UI, example MCP servers,
#     and scripts/docker-entrypoint.sh for `az acr build` workflows.
# =============================================================

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
REPO_ROOT="$(cd "$SCRIPT_DIR/../.." && pwd)"

# ---- Colors ----
if [[ -n "${NO_COLOR:-}" ]] || [[ ! -t 1 ]]; then
  RED='' GREEN='' YELLOW='' CYAN='' BOLD='' NC=''
else
  RED='\033[0;31m'
  GREEN='\033[0;32m'
  YELLOW='\033[1;33m'
  CYAN='\033[0;36m'
  BOLD='\033[1m'
  NC='\033[0m'
fi

info()  { printf "${CYAN}[INFO]${NC}  %b\n" "$*"; }
ok()    { printf "${GREEN}[  OK]${NC}  %b\n" "$*"; }
warn()  { printf "${YELLOW}[WARN]${NC}  %b\n" "$*" >&2; }
die()   { printf "${RED}[FAIL]${NC}  %b\n" "$*" >&2; exit 1; }

# ---- Defaults ----
VERSION=""
OUTPUT_DIR=""
DRY_RUN=false
BUNDLE="both"   # deploy | source | both

# ---- Parse flags ----
while [[ $# -gt 0 ]]; do
  case "$1" in
    --version)    VERSION="$2"; shift 2 ;;
    --output-dir) OUTPUT_DIR="$2"; shift 2 ;;
    --bundle)     BUNDLE="$2"; shift 2 ;;
    --bundle=*)   BUNDLE="${1#--bundle=}"; shift ;;
    --dry-run)    DRY_RUN=true; shift ;;
    -h|--help)
      cat <<EOF
Usage: package.sh [--bundle=deploy|source|both] [--version VERSION]
                  [--output-dir DIR] [--dry-run]

Builds one or both Azure Container Apps deployment tarballs.

Options:
  --bundle BUNDLE     deploy | source | both (default: both)
                        deploy  = slim tarball for customers pulling from
                                  public.ecr.aws (default public-image path).
                                  --build-from-source will NOT work from
                                  this bundle.
                        source  = full source tarball including Dockerfile,
                                  adapter source, admin UI, example servers,
                                  and scripts/docker-entrypoint.sh. Supports
                                  every deploy.sh flag including
                                  --build-from-source.
                        both    = produce both tarballs.
  --version VERSION   Override version (default: from pyproject.toml)
  --output-dir DIR    Output directory (default: ./dist)
  --dry-run           List files without creating tarball(s)
EOF
      exit 0
      ;;
    *) die "Unknown flag: $1" ;;
  esac
done

case "$BUNDLE" in
  deploy|source|both) ;;
  *) die "--bundle must be one of: deploy, source, both (got: $BUNDLE)" ;;
esac

# Resolve version from pyproject.toml
if [[ -z "$VERSION" ]]; then
  PYPROJECT="$REPO_ROOT/pyproject.toml"
  if [[ -f "$PYPROJECT" ]]; then
    VERSION="$(grep -m1 '^version' "$PYPROJECT" | sed 's/.*= *"\(.*\)"/\1/')"
  fi
  VERSION="${VERSION:-dev}"
fi

OUTPUT_DIR="${OUTPUT_DIR:-$SCRIPT_DIR/dist}"

info "Version:    ${BOLD}${VERSION}${NC}"
info "Bundle(s):  ${BOLD}${BUNDLE}${NC}"
info "Output dir: ${OUTPUT_DIR}"
echo ""

# ---- Verify source files exist ----
[[ -d "$SCRIPT_DIR/scripts" ]]   || die "Cannot find scripts/ in $SCRIPT_DIR"
[[ -d "$SCRIPT_DIR/shell-lib" ]] || die "Cannot find shell-lib/ in $SCRIPT_DIR"
[[ -d "$SCRIPT_DIR/bicep" ]]     || die "Cannot find bicep/ in $SCRIPT_DIR"
[[ -f "$SCRIPT_DIR/scripts/deploy.sh" ]] || die "Cannot find scripts/deploy.sh in $SCRIPT_DIR"

# =============================================================
# Stage functions
# =============================================================

# Files shared by both bundles: wizard scripts, shell-lib, Bicep, README,
# shared db_bootstrap helper, raw SQL migrations, LICENSE, pyproject.toml.
stage_common() {
  local staging="$1"

  info "Staging azure-aca scripts + Bicep..."
  local wizard_dir="$staging/deploy/azure-aca"
  mkdir -p "$wizard_dir"

  cp -r "$SCRIPT_DIR/scripts"   "$wizard_dir/"
  cp -r "$SCRIPT_DIR/shell-lib" "$wizard_dir/"
  cp -r "$SCRIPT_DIR/bicep"     "$wizard_dir/"
  cp "$SCRIPT_DIR/README.md"    "$wizard_dir/"
  [[ -f "$SCRIPT_DIR/.env.example" ]]     && cp "$SCRIPT_DIR/.env.example"     "$wizard_dir/"
  [[ -f "$SCRIPT_DIR/.env.byo.example" ]] && cp "$SCRIPT_DIR/.env.byo.example" "$wizard_dir/"
  # Legacy compat shim
  [[ -f "$SCRIPT_DIR/acasetup.sh" ]] && cp "$SCRIPT_DIR/acasetup.sh" "$wizard_dir/"

  # Shared cross-cloud deploy shell-lib (db_bootstrap sourced at runtime).
  [[ -d "$REPO_ROOT/deploy/shell-lib" ]] || die "Cannot find deploy/shell-lib in $REPO_ROOT"
  info "Staging deploy/shell-lib..."
  mkdir -p "$staging/deploy/shell-lib"
  cp -r "$REPO_ROOT/deploy/shell-lib/." "$staging/deploy/shell-lib/"

  # Raw SQL migrations. Needed by:
  #   - db_bootstrap.sh local-exec fallback (reads deploy/migrations/sql/*)
  #   - RUN_DB_BOOTSTRAP=false DBA handoff Option B
  # Cloud-native ACA Job path has these baked into the adapter image; shipping
  # here keeps secondary paths working (~40 KB).
  [[ -d "$REPO_ROOT/deploy/migrations" ]] || die "Cannot find deploy/migrations in $REPO_ROOT"
  info "Staging deploy/migrations..."
  mkdir -p "$staging/deploy/migrations"
  cp -r "$REPO_ROOT/deploy/migrations/." "$staging/deploy/migrations/"

  # LICENSE at tarball root
  cp "$REPO_ROOT/LICENSE" "$staging/"

  # pyproject.toml — deploy.sh greps `version = "X.Y.Z"` to resolve the
  # default public-image tag.
  cp "$REPO_ROOT/pyproject.toml" "$staging/"
}

# Additions for the source bundle: Dockerfile + adapter source + admin UI +
# example servers + entrypoint. Not required on the public-image default.
stage_source() {
  local staging="$1"

  info "Staging adapter source + Docker build context..."
  cp "$REPO_ROOT/Dockerfile"         "$staging/"
  cp "$REPO_ROOT/.dockerignore"      "$staging/"
  cp "$REPO_ROOT/requirements.txt"   "$staging/"
  cp -r "$REPO_ROOT/okta_agent_proxy" "$staging/"

  # docker-entrypoint.sh (only production script from scripts/)
  info "Staging scripts/docker-entrypoint.sh..."
  mkdir -p "$staging/scripts"
  cp "$REPO_ROOT/scripts/docker-entrypoint.sh" "$staging/scripts/"

  # Admin UI (for admin-ui image build)
  if [[ -d "$REPO_ROOT/okta_agent_proxy_admin_ui" ]]; then
    info "Staging Admin UI source..."
    cp -r "$REPO_ROOT/okta_agent_proxy_admin_ui" "$staging/"
  fi

  # Example backends (for hr-server and deploy-server image builds)
  info "Staging example demo servers..."
  mkdir -p "$staging/examples"
  [[ -d "$REPO_ROOT/examples/01-hr-system" ]] && \
    cp -r "$REPO_ROOT/examples/01-hr-system" "$staging/examples/"
  [[ -d "$REPO_ROOT/examples/05-deploy-server" ]] && \
    cp -r "$REPO_ROOT/examples/05-deploy-server" "$staging/examples/"
}

# Remove dev-only / stateful / sensitive files from the staged tree.
clean_staging() {
  local staging="$1"
  info "Cleaning excluded files..."

  find "$staging" -name ".acasetup.state" -delete 2>/dev/null || true
  find "$staging" -name ".deploy.state"   -delete 2>/dev/null || true
  find "$staging" -name ".env" -not -name ".env.example" -not -name ".env.byo.example" \
    -delete 2>/dev/null || true
  find "$staging" -type d -name "dist" -exec rm -rf {} + 2>/dev/null || true
  find "$staging" -type d -name ".git" -exec rm -rf {} + 2>/dev/null || true
  find "$staging" -type d -name ".github" -exec rm -rf {} + 2>/dev/null || true
  find "$staging" -name "CLAUDE.md" -delete 2>/dev/null || true
  find "$staging" -name "CLAUDE_CONVENTIONS.md" -delete 2>/dev/null || true
  find "$staging" -type d -name ".claude" -exec rm -rf {} + 2>/dev/null || true
  find "$staging" -type d -name "tests" -exec rm -rf {} + 2>/dev/null || true
  find "$staging" -name "pytest.ini" -delete 2>/dev/null || true
  find "$staging" -name "conftest.py" -delete 2>/dev/null || true
  find "$staging" -type d -name ".pytest_cache" -exec rm -rf {} + 2>/dev/null || true
  find "$staging" -type d -name "__pycache__" -exec rm -rf {} + 2>/dev/null || true
  find "$staging" -type d -name "node_modules" -exec rm -rf {} + 2>/dev/null || true
  find "$staging" -type d -name ".next" -exec rm -rf {} + 2>/dev/null || true
  find "$staging" -name "*.pyc" -delete 2>/dev/null || true
  find "$staging" -name ".coverage" -delete 2>/dev/null || true
  find "$staging" -name "*.docx" -delete 2>/dev/null || true
  find "$staging" -name "*.pptx" -delete 2>/dev/null || true
  find "$staging" -name "*.xlsx" -delete 2>/dev/null || true
  find "$staging" -name "*_PROMPTS*.md"  -delete 2>/dev/null || true
  find "$staging" -name "*_ANALYSIS*.md" -delete 2>/dev/null || true
  find "$staging" -name "*ADR_*.md"      -delete 2>/dev/null || true

  # Compiled Bicep artifacts — `az bicep build` emits sibling .json next
  # to .bicep source. Not part of the shipped artifact.
  find "$staging" -path "*/bicep/*.json" -delete 2>/dev/null || true
  find "$staging" -path "*/bicep/modules/*.json" -delete 2>/dev/null || true
}

# =============================================================
# Build one tarball
# =============================================================
# Args: $1 = kind (deploy|source)
build_bundle() {
  local kind="$1"
  local suffix=""
  [[ "$kind" == "source" ]] && suffix="-source"

  local tarball_base="okta-ps-adapter-azure-aca${suffix}-${VERSION}"
  local tarball_name="${tarball_base}.tar.gz"
  local staging="/tmp/${tarball_base}"

  echo ""
  info "================================================================"
  info "Building ${BOLD}${kind}${NC} bundle → ${BOLD}${tarball_name}${NC}"
  info "================================================================"

  rm -rf "$staging"
  mkdir -p "$staging"

  stage_common "$staging"
  if [[ "$kind" == "source" ]]; then
    stage_source "$staging"
  fi
  clean_staging "$staging"

  local file_count total_size
  file_count=$(find "$staging" -type f | wc -l | tr -d ' ')
  total_size=$(du -sh "$staging" | cut -f1)
  echo ""
  info "Package contents: ${BOLD}${file_count}${NC} files, ${BOLD}${total_size}${NC}"

  if $DRY_RUN; then
    echo ""
    info "${YELLOW}--dry-run${NC}: listing files (no tarball created)"
    echo ""
    (cd /tmp && find "$tarball_base" -type f | sort)
    echo ""
    info "Total: ${file_count} files, ${total_size}"
    rm -rf "$staging"
    return 0
  fi

  mkdir -p "$OUTPUT_DIR"
  (cd /tmp && tar czf "${OUTPUT_DIR}/${tarball_name}" "$tarball_base")

  local path size checksum
  path="${OUTPUT_DIR}/${tarball_name}"
  size=$(du -h "$path" | cut -f1)
  checksum=$(shasum -a 256 "$path" | cut -d' ' -f1)

  rm -rf "$staging"

  echo ""
  ok "Tarball created: ${BOLD}${path}${NC}"
  printf "  %-12s %s\n" "Files:"      "$file_count"
  printf "  %-12s %s\n" "Unpacked:"   "$total_size"
  printf "  %-12s %s\n" "Compressed:" "$size"
  printf "  %-12s %s\n" "SHA-256:"    "$checksum"

  echo ""
  echo "  To deploy from this bundle:"
  echo "    tar xzf ${tarball_name}"
  echo "    cd ${tarball_base}/deploy/azure-aca"
  echo "    export AZURE_SUBSCRIPTION_ID=..."
  if [[ "$kind" == "source" ]]; then
    echo "    ./scripts/deploy.sh                        # pull public images (default)"
    echo "    ./scripts/deploy.sh --build-from-source    # or build into ACR"
  else
    echo "    ./scripts/deploy.sh"
    echo ""
    echo "  Note: this bundle does not include source — --build-from-source"
    echo "        requires okta-ps-adapter-azure-aca-source-${VERSION}.tar.gz."
  fi
}

# =============================================================
# Dispatch
# =============================================================
case "$BUNDLE" in
  deploy) build_bundle deploy ;;
  source) build_bundle source ;;
  both)
    build_bundle deploy
    build_bundle source
    ;;
esac

echo ""
ok "Done."
