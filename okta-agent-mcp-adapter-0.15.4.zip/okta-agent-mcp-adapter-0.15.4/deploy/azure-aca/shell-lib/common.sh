#!/usr/bin/env bash
# =============================================================
# common.sh — Shared cloud-agnostic functions for Azure wizards
# =============================================================
# Source this file, do not execute it directly.
# Adapted from deploy/aws-ec2/shell-lib/common.sh.
# =============================================================

# ---- Color constants ----
# Respect NO_COLOR (https://no-color.org/) and detect non-TTY output
if [[ -n "${NO_COLOR:-}" ]] || [[ ! -t 1 ]]; then
  RED='' GREEN='' YELLOW='' CYAN='' BOLD='' NC=''
else
  RED='\033[0;31m'
  GREEN='\033[0;32m'
  YELLOW='\033[1;33m'
  CYAN='\033[0;36m'
  BOLD='\033[1m'
  NC='\033[0m'
fi

# ---- Logging ----

info()  { printf "${CYAN}[INFO]${NC}  %b\n" "$*"; }
ok()    { printf "${GREEN}[  OK]${NC}  %b\n" "$*"; }
warn()  { printf "${YELLOW}[WARN]${NC}  %b\n" "$*" >&2; }
fail()  { printf "${RED}[FAIL]${NC}  %b\n" "$*" >&2; }
die()   { fail "$@"; exit 1; }

# ---- Prompts ----

# prompt_required VAR_NAME PROMPT_TEXT
#   Asks until a non-empty value is provided, stores in the named variable.
prompt_required() {
  local var_name="$1" prompt_text="$2" value=""
  while [[ -z "$value" ]]; do
    printf "${BOLD}%s${NC}: " "$prompt_text"
    read -r value
    [[ -z "$value" ]] && warn "This field is required."
  done
  eval "$var_name=\"\$value\""
}

# prompt_default VAR_NAME PROMPT_TEXT DEFAULT_VALUE
#   Asks for input with a default shown in brackets.
prompt_default() {
  local var_name="$1" prompt_text="$2" default="$3" value=""
  printf "${BOLD}%s${NC} [${CYAN}%s${NC}]: " "$prompt_text" "$default"
  read -r value
  value="${value:-$default}"
  eval "$var_name=\"\$value\""
}

# prompt_yesno PROMPT_TEXT [DEFAULT: y|n]
#   Returns 0 for yes, 1 for no.
prompt_yesno() {
  local prompt_text="$1" default="${2:-y}" reply=""
  local hint="Y/n"
  [[ "$default" == "n" ]] && hint="y/N"
  printf "${BOLD}%s${NC} [${CYAN}%s${NC}]: " "$prompt_text" "$hint"
  read -r reply
  reply="${reply:-$default}"
  [[ "$reply" =~ ^[Yy] ]]
}

# ---- Validation ----

# validate_command CMD [INSTALL_HINT]
#   Exits if CMD is not on PATH.
validate_command() {
  local cmd="$1" hint="${2:-}"
  if ! command -v "$cmd" &>/dev/null; then
    [[ -n "$hint" ]] && die "'$cmd' is required but not found. $hint"
    die "'$cmd' is required but not found."
  fi
}

# check_port_available PORT
#   Returns 0 if port is free, 1 if in use.
check_port_available() {
  local port="$1"
  if ss -tlnp 2>/dev/null | grep -q ":${port} " || \
     lsof -iTCP:"${port}" -sTCP:LISTEN &>/dev/null; then
    return 1
  fi
  return 0
}

# ---- State management ----
# State is stored in .azuresetup.state (key=value, one per line).

STATE_FILE="${STATE_FILE:-.azuresetup.state}"

# save_state KEY VALUE
#   Append or update a key=value pair in the state file.
save_state() {
  local key="$1" value="$2"
  if [[ -f "$STATE_FILE" ]] && grep -q "^${key}=" "$STATE_FILE" 2>/dev/null; then
    # Update existing key — delete old line, append new
    local tmp
    tmp=$(mktemp)
    grep -v "^${key}=" "$STATE_FILE" > "$tmp" || true
    printf '%s=%s\n' "$key" "$value" >> "$tmp"
    mv "$tmp" "$STATE_FILE"
  else
    printf '%s=%s\n' "$key" "$value" >> "$STATE_FILE"
  fi
}

# load_state
#   No-op — retained for compatibility. Individual values are read
#   via get_state() which uses grep, avoiding bash interpretation
#   of special characters in URLs, passwords, and base64 keys.
load_state() {
  true
}

# get_state KEY
#   Print the value for KEY or empty string.
get_state() {
  local key="$1"
  if [[ -f "$STATE_FILE" ]]; then
    grep "^${key}=" "$STATE_FILE" 2>/dev/null | head -1 | cut -d= -f2- || true
  fi
}
