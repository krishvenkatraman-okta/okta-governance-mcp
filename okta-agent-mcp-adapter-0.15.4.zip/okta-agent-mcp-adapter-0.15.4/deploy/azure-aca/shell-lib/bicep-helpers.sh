#!/usr/bin/env bash
# =============================================================
# bicep-helpers.sh — Thin wrappers around `az deployment`
# =============================================================
# Source this file, do not execute it directly.
#
# Exposes:
#   bicep_preflight         — verify az + bicep tooling is installed
#   bicep_export_env        — load state + .env into the current shell env
#                             under the names main.bicepparam expects
#   bicep_what_if           — run `az deployment sub what-if` against main.bicep
#   bicep_deploy            — run `az deployment sub create` against main.bicep
#   bicep_get_outputs       — fetch outputs from the last deployment as JSON
# =============================================================

# ---- Tooling check ----
bicep_preflight() {
  validate_command az "Install: https://learn.microsoft.com/cli/azure/install-azure-cli"
  validate_command jq
  az bicep install &>/dev/null || true
  az bicep version &>/dev/null || die "bicep CLI not available (run: az bicep install)"
}

# ---- Environment prep ----
# Reads .env + .deploy.state and re-exports the full set of vars
# that main.bicepparam's readEnvironmentVariable() calls expect.
bicep_export_env() {
  # Secrets (never logged)
  export PG_ADMIN_PASSWORD="$(get_state PG_ADMIN_PASSWORD)"
  export ENCRYPTION_KEY="$(get_state ENCRYPTION_KEY)"
  export NEXTAUTH_SECRET="$(get_state NEXTAUTH_SECRET)"
  export HR_PSK_SECRET="$(get_state HR_PSK_SECRET)"

  # Okta config
  export OKTA_DOMAIN="${OKTA_DOMAIN:-$(get_state OKTA_DOMAIN)}"
  export ADMIN_UI_OKTA_CLIENT_ID="${ADMIN_UI_OKTA_CLIENT_ID:-$(get_state ADMIN_UI_OKTA_CLIENT_ID)}"
  export ADMIN_UI_OKTA_CLIENT_SECRET="${ADMIN_UI_OKTA_CLIENT_SECRET:-$(get_state ADMIN_UI_OKTA_CLIENT_SECRET)}"
  export DEPLOY_OKTA_CLIENT_ID="${DEPLOY_OKTA_CLIENT_ID:-$(get_state DEPLOY_OKTA_CLIENT_ID)}"
  export DEPLOY_OKTA_AUTH_SERVER_ID="${DEPLOY_OKTA_AUTH_SERVER_ID:-$(get_state DEPLOY_OKTA_AUTH_SERVER_ID)}"
  export DEPLOY_OKTA_AUDIENCE="${DEPLOY_OKTA_AUDIENCE:-$(get_state DEPLOY_OKTA_AUDIENCE)}"

  # Core
  export AZURE_LOCATION="${AZURE_LOCATION:-$(get_state AZURE_LOCATION)}"
  export AZURE_RG="${AZURE_RG:-$(get_state AZURE_RG)}"
  export EXISTING_RG_NAME="${EXISTING_RG_NAME:-$(get_state EXISTING_RG_NAME)}"
  export IMAGE_TAG="${IMAGE_TAG:-$(get_state IMAGE_TAG)}"

  # Required fields — fail fast if missing
  [[ -n "$OKTA_DOMAIN" ]]         || die "OKTA_DOMAIN is required (set in .env or wizard)"
  [[ -n "$ENCRYPTION_KEY" ]]      || die "ENCRYPTION_KEY missing from state — re-run Phase 0 of deploy.sh"
  [[ -n "$PG_ADMIN_PASSWORD" ]]   || die "PG_ADMIN_PASSWORD missing from state — re-run Phase 0 of deploy.sh"
}

# ---- Deployment operations ----

# bicep_what_if LOCATION BICEPPARAM_FILE [EXTRA_PARAMS...]
bicep_what_if() {
  local location="$1" bicepparam="$2"
  shift 2
  az deployment sub what-if \
    --location "$location" \
    --template-file "$SCRIPT_DIR/bicep/main.bicep" \
    --parameters "$bicepparam" \
    "$@"
}

# bicep_deploy LOCATION BICEPPARAM_FILE DEPLOYMENT_NAME [EXTRA_PARAMS...]
bicep_deploy() {
  local location="$1" bicepparam="$2" dep_name="$3"
  shift 3
  az deployment sub create \
    --location "$location" \
    --name "$dep_name" \
    --template-file "$SCRIPT_DIR/bicep/main.bicep" \
    --parameters "$bicepparam" \
    "$@"
}

# bicep_get_outputs DEPLOYMENT_NAME
#   Prints deployment outputs as JSON.
bicep_get_outputs() {
  local dep_name="$1"
  az deployment sub show --name "$dep_name" --query properties.outputs -o json
}

# bicep_output KEY DEPLOYMENT_NAME
#   Prints a single output value by key.
bicep_output() {
  local key="$1" dep_name="$2"
  az deployment sub show --name "$dep_name" --query "properties.outputs.${key}.value" -o tsv
}

# ---- Quick redeploy of a single Container App ----
# quick_redeploy IMAGE_NAME APP_NAME CONTEXT_DIR DOCKERFILE [FQDN_STATE_KEY]
#   Runs `az acr build` for a single image, rolls the named Container
#   App to the new tag, then optionally polls /health on the FQDN
#   resolved from state.
quick_redeploy() {
  local image="$1" app="$2" context="$3" dockerfile="$4" fqdn_key="${5:-}"

  local acr_login_server resource_group acr_name build_tag
  acr_login_server="$(get_state ACR_LOGIN_SERVER)"
  resource_group="$(get_state RESOURCE_GROUP)"
  [[ -n "$acr_login_server" ]] || die "ACR_LOGIN_SERVER missing — run scripts/deploy.sh first."
  [[ -n "$resource_group" ]]   || die "RESOURCE_GROUP missing — run scripts/deploy.sh first."
  acr_name="${acr_login_server%%.*}"
  build_tag="build-$(date +%Y%m%d-%H%M%S)"

  info "Building $image:$build_tag in $acr_name ..."
  az acr build --registry "$acr_name" \
    --image "$image:$build_tag" \
    --image "$image:latest" \
    --file "$dockerfile" \
    "$context" \
    --output none
  ok "Image built: $image:$build_tag"

  info "Rolling $app → ${acr_login_server}/${image}:${build_tag} ..."
  az containerapp update -g "$resource_group" -n "$app" \
    --image "${acr_login_server}/${image}:${build_tag}" \
    --output none
  ok "Container App '$app' rolled."

  if [[ -n "$fqdn_key" ]]; then
    local fqdn
    fqdn="$(get_state "$fqdn_key")"
    if [[ -n "$fqdn" ]]; then
      info "Waiting for $app to respond on https://$fqdn/ ..."
      local elapsed=0
      while (( elapsed < 120 )); do
        if curl -sf --max-time 5 "https://$fqdn/health" >/dev/null 2>&1 \
           || curl -sf --max-time 5 "https://$fqdn/" >/dev/null 2>&1; then
          ok "$app healthy after ${elapsed}s"
          return 0
        fi
        printf "."
        sleep 5
        elapsed=$((elapsed + 5))
      done
      echo ""
      warn "$app did not respond within 120s. Check logs: az containerapp logs show -g $resource_group -n $app --follow"
    fi
  fi
}

# bicep_confirm_apply — gate apply behind an interactive confirm unless YES=true
bicep_confirm_apply() {
  if [[ "${YES:-false}" == "true" ]]; then
    info "YES=true set — skipping confirmation."
    return 0
  fi
  echo ""
  if prompt_yesno "Proceed with this deployment?" "n"; then
    return 0
  fi
  die "Deployment cancelled by user."
}
