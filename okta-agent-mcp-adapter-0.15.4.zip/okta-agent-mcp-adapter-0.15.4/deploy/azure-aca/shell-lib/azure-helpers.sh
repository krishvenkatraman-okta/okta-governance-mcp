#!/usr/bin/env bash
# =============================================================
# azure-helpers.sh — Azure-specific helper functions
# =============================================================
# Source this file AFTER common.sh, do not execute it directly.
# Provides: az login checks, provider registration, resource
# existence checks, long-poll waiters, password and key generators.
# =============================================================

# ---- Authentication & Subscription ----

# az_login_check
#   Verify az CLI is logged in. If AZURE_SUBSCRIPTION_ID is set,
#   ensure the active subscription matches.
az_login_check() {
  if ! az account show &>/dev/null; then
    die "Not logged in to Azure CLI. Run 'az login' first."
  fi

  if [[ -n "${AZURE_SUBSCRIPTION_ID:-}" ]]; then
    local current_sub
    current_sub=$(az account show --query id -o tsv 2>/dev/null)
    if [[ "$current_sub" != "$AZURE_SUBSCRIPTION_ID" ]]; then
      warn "Active subscription ($current_sub) differs from AZURE_SUBSCRIPTION_ID ($AZURE_SUBSCRIPTION_ID). Switching..."
      az account set --subscription "$AZURE_SUBSCRIPTION_ID" || die "Failed to set subscription to $AZURE_SUBSCRIPTION_ID"
      ok "Subscription set to $AZURE_SUBSCRIPTION_ID"
    fi
  fi
}

# ---- Provider Registration ----

# az_provider_register PROVIDER
#   Registers a resource provider and waits up to 5 min for "Registered" state.
#   Idempotent — does nothing if already registered.
az_provider_register() {
  local provider="$1"
  local state
  state=$(az provider show -n "$provider" --query registrationState -o tsv 2>/dev/null || echo "NotRegistered")

  if [[ "$state" == "Registered" ]]; then
    ok "Provider $provider already registered"
    return 0
  fi

  info "Registering provider $provider..."
  az provider register -n "$provider" --wait false &>/dev/null || die "Failed to register provider $provider"

  local elapsed=0 timeout=300
  while [[ $elapsed -lt $timeout ]]; do
    state=$(az provider show -n "$provider" --query registrationState -o tsv 2>/dev/null || echo "Unknown")
    if [[ "$state" == "Registered" ]]; then
      printf "\n"
      ok "Provider $provider registered (${elapsed}s)"
      return 0
    fi
    printf "."
    sleep 10
    elapsed=$((elapsed + 10))
  done

  printf "\n"
  die "Timed out waiting for provider $provider to register (last state: $state)"
}

# ---- Resource Existence ----

# az_resource_exists RESOURCE_GROUP RESOURCE_TYPE NAME
#   Returns 0 if the resource exists, 1 if not.
az_resource_exists() {
  local rg="$1" resource_type="$2" name="$3"
  az resource show \
    --resource-group "$rg" \
    --resource-type "$resource_type" \
    --name "$name" \
    &>/dev/null 2>&1
}

# ---- Long-Poll Waiter ----

# wait_for_resource RESOURCE_ID PROPERTY EXPECTED_VALUE [TIMEOUT_SEC]
#   Polls az resource show until PROPERTY matches EXPECTED_VALUE.
#   Default timeout: 1800s (30 min).
wait_for_resource() {
  local resource_id="$1" property="$2" expected="$3" timeout="${4:-1800}"
  local elapsed=0
  local spinner_chars='|/-\'
  local spinner_idx=0
  local last_value=""

  while [[ $elapsed -lt $timeout ]]; do
    last_value=$(az resource show --ids "$resource_id" --query "$property" -o tsv 2>/dev/null || echo "")

    if [[ "$last_value" == "$expected" ]]; then
      # Clear the spinner line and print success
      printf "\r\033[K"
      ok "Resource ready (${elapsed}s)"
      return 0
    fi

    # Format elapsed as MM:SS
    local mins=$((elapsed / 60))
    local secs=$((elapsed % 60))
    local elapsed_fmt
    elapsed_fmt=$(printf "%02d:%02d" "$mins" "$secs")

    # Print spinner on the same line
    local spinner_char="${spinner_chars:$spinner_idx:1}"
    printf "\r${CYAN}[INFO]${NC}  Waiting for %s... %s %s" \
      "$(basename "$resource_id" 2>/dev/null || echo "$resource_id")" \
      "$spinner_char" \
      "$elapsed_fmt"

    spinner_idx=$(( (spinner_idx + 1) % 4 ))
    sleep 15
    elapsed=$((elapsed + 15))
  done

  # Timeout — clear line and die
  printf "\r\033[K"
  die "Timed out after ${timeout}s waiting for resource $resource_id — property '$property' last value: '$last_value' (expected: '$expected')"
}

# ---- Redis Provisioning Waiter ----

# poll_redis_provisioned RG REDIS_NAME [TIMEOUT_SEC]
#   Polls az redis show every 30 seconds until provisioningState
#   reaches "Succeeded". Default timeout 1800 seconds (30 min).
poll_redis_provisioned() {
  local rg="$1" name="$2" timeout="${3:-1800}"
  local elapsed=0 interval=30
  local spin_chars='|/-\'
  local spin_idx=0 state=""

  while (( elapsed < timeout )); do
    state="$(az redis show -g "$rg" -n "$name" \
              --query provisioningState -o tsv 2>/dev/null || echo "Unknown")"
    if [[ "$state" == "Succeeded" ]]; then
      printf "\r${GREEN}[  OK]${NC}  Redis %s provisioned (%d:%02d elapsed)        \n" \
        "$name" $((elapsed/60)) $((elapsed%60))
      return 0
    fi
    if [[ "$state" == "Failed" ]]; then
      printf "\r"
      die "Redis $name provisioning FAILED. Inspect with: az redis show -g $rg -n $name"
    fi
    local c="${spin_chars:$spin_idx:1}"
    printf "\r${CYAN}[INFO]${NC}  Waiting for redis %s... %s %02d:%02d (state: %s)" \
      "$name" "$c" $((elapsed/60)) $((elapsed%60)) "$state"
    spin_idx=$(( (spin_idx + 1) % 4 ))
    sleep "$interval"
    elapsed=$((elapsed + interval))
  done
  printf "\r"
  die "Timeout after ${timeout}s waiting for redis $name (last state: $state)"
}

# ---- Generators ----

# random_suffix [LENGTH]
#   Generates a random lowercase alphanumeric suffix.
#   Default length: 4. Works on macOS and Linux.
random_suffix() {
  local length="${1:-4}"
  openssl rand -hex $(( (length + 1) / 2 )) 2>/dev/null | head -c "$length"
}

# generate_password [LENGTH]
#   Generates a strong password. Default length: 24.
#   Uses uppercase, lowercase, digits, and safe symbols (!@#%^*).
generate_password() {
  local length="${1:-24}"
  local password=""

  # Generate until we get a password with all required character classes.
  # Uses openssl rand to avoid SIGPIPE issues with tr </dev/urandom | head
  # under set -euo pipefail on macOS.
  while true; do
    password="$(openssl rand -base64 "$length" | tr -d '/+\n' | head -c "$length")"
    # Append a symbol to guarantee the special-char class
    password="${password:0:$((length-1))}!"
    if [[ "$password" =~ [A-Z] ]] && \
       [[ "$password" =~ [a-z] ]] && \
       [[ "$password" =~ [0-9] ]]; then
      echo "$password"
      return 0
    fi
  done
}

# generate_encryption_key
#   Returns a base64-encoded 32-byte AES-256 key.
generate_encryption_key() {
  if command -v python3 &>/dev/null; then
    python3 -c "import os,base64; print(base64.b64encode(os.urandom(32)).decode())"
  elif command -v openssl &>/dev/null; then
    openssl rand -base64 32
  else
    die "Neither python3 nor openssl found — cannot generate encryption key."
  fi
}

# urlencode_password PASSWORD
#   URL-encodes a password for safe inclusion in a postgres:// connection string.
urlencode_password() {
  python3 -c 'import sys,urllib.parse; print(urllib.parse.quote(sys.argv[1], safe=""))' "$1"
}

# ---- Manifest Substitution ----

# substitute_manifest SRC DEST KEY1=VAL1 [KEY2=VAL2 ...]
#   Reads SRC, substitutes __KEY__ tokens with VAL values, writes
#   to DEST. Validates that every __NAME__ declared in the source
#   file's header comment was substituted (the header comment
#   lists placeholders on lines starting with "# Placeholders:").
#   Dies if any declared placeholder remains or if any token in
#   the body wasn't declared in the header.
substitute_manifest() {
  local src="$1" dest="$2"
  shift 2

  [[ -f "$src" ]] || die "substitute_manifest: source $src not found"

  # Build sed expressions from the KEY=VAL args
  # Track keys in a plain array (bash 3 compatible — no assoc arrays)
  local sed_args=()
  local sub_keys=()
  for kv in "$@"; do
    local k="${kv%%=*}"
    local v="${kv#*=}"
    sub_keys+=( "$k" )
    # Use | as sed delimiter to avoid issues with / in ARM IDs
    sed_args+=( -e "s|__${k}__|${v}|g" )
  done

  # Apply substitutions
  sed "${sed_args[@]}" "$src" > "$dest"

  # Validate: parse declared placeholders from the header comment
  local declared
  declared=$(awk '/^#/ {print} !/^#/ {exit}' "$src" | \
             grep -oE '__[A-Z_]+__' | sort -u || true)

  # Check every declared placeholder was substituted (i.e. is NOT
  # present in dest). If any remain in dest, die.
  for ph in $declared; do
    if grep -q "$ph" "$dest"; then
      die "substitute_manifest: placeholder $ph in $src was not substituted"
    fi
  done

  # Check every substitution key was actually needed (i.e. was
  # declared in the header). This catches typos like passing
  # KV_URI when the header only has KV_NAME.
  for k in "${sub_keys[@]}"; do
    if ! echo "$declared" | grep -q "__${k}__"; then
      warn "substitute_manifest: key $k was not declared in $src header (unused?)"
    fi
  done
}

# ---- Prerequisite Validation ----

# validate_azure_prereqs [--requires-k8s]
#   Validates required CLI tools are installed and az is logged in.
validate_azure_prereqs() {
  local requires_k8s=false
  while [[ $# -gt 0 ]]; do
    case "$1" in
      --requires-k8s) requires_k8s=true; shift ;;
      *) shift ;;
    esac
  done

  validate_command az "Install Azure CLI: https://aka.ms/installazurecli"
  validate_command jq "Install jq: https://jqlang.github.io/jq/download/"
  validate_command python3 "Install Python 3: https://www.python.org/downloads/"
  validate_command openssl "Install OpenSSL"

  if $requires_k8s; then
    validate_command kubectl "Install kubectl: https://kubernetes.io/docs/tasks/tools/"
    validate_command helm "Install Helm: https://helm.sh/docs/intro/install/"
  fi

  az_login_check
}
