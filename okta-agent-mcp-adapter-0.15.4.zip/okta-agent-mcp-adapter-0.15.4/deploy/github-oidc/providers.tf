provider "aws" {
  region = var.aws_region

  default_tags {
    tags = {
      Project   = "okta-agent-mcp-adapter"
      Component = "github-oidc"
      ManagedBy = "terraform"
    }
  }
}
