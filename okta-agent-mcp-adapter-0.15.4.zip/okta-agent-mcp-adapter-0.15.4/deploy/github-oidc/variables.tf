variable "aws_region" {
  type        = string
  default     = "us-east-1"
  description = "AWS region for the provider. IAM is global; this only affects API call routing. ECR Public itself lives in us-east-1."
}

variable "github_org" {
  type        = string
  default     = "atko-proservices"
  description = "GitHub organization owning the repository allowed to assume this role."
}

variable "github_repo" {
  type        = string
  default     = "okta-agent-mcp-adapter"
  description = "GitHub repository name (without org prefix) allowed to assume this role."
}

variable "allowed_tag_pattern" {
  type        = string
  default     = "v*.*.*"
  description = "Glob pattern applied to ref names via StringLike on token.actions.githubusercontent.com:sub. Default matches semver tags only; branches and PR refs are rejected."
}

variable "ecr_public_alias" {
  type        = string
  default     = "oktaps"
  description = "ECR Public registry alias. Image repos under this alias (okta-mcp-adapter, okta-mcp-admin-ui, okta-mcp-hr-server, okta-mcp-deploy-server) receive push permission."
}

variable "role_name" {
  type        = string
  default     = "oktaps-mcp-gh-publisher"
  description = "Name of the IAM role created for GitHub Actions to assume. Dedicated to ECR Public publishing for this repo; do not reuse for other workloads."
}
