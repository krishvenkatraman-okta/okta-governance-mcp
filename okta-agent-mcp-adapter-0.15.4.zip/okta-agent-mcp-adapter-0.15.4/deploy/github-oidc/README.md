# GitHub OIDC role for ECR Public publishing

One-time setup for the canonical release workflow
(`.github/workflows/publish-public-ecr.yml`). Creates a dedicated IAM role
scoped to **tag pushes** on `atko-proservices/okta-agent-mcp-adapter`.

## What this creates

| Resource | Purpose |
| --- | --- |
| `aws_iam_role.gh_publisher` (default name `oktaps-mcp-gh-publisher`) | Assumed by GitHub Actions via OIDC |
| `aws_iam_role_policy.ecr_public_push` | Inline policy granting `ecr-public:*` push on the four okta-mcp-* repos |

## What this does NOT create

- The `token.actions.githubusercontent.com` OIDC provider. Already exists in
  account 640706953729; referenced via data source and left untouched.
- ECR Public repositories. Create those once via console or CLI:

  ```bash
  for name in okta-mcp-adapter okta-mcp-admin-ui okta-mcp-hr-server okta-mcp-deploy-server; do
    aws ecr-public create-repository --region us-east-1 --repository-name "$name"
  done
  ```

## Trust policy

```
sub: repo:atko-proservices/okta-agent-mcp-adapter:ref:refs/tags/v*.*.*
aud: sts.amazonaws.com
```

Branch pushes, PR refs, and other repos cannot assume this role.

## Apply

```bash
cd deploy/github-oidc
terraform init
terraform apply

# Capture the role ARN for the workflow
terraform output -raw role_arn
```

Default inputs match the enterprise repo; override via `TF_VAR_*` if you need
a different org/repo or a non-semver tag pattern.

## Verify

```bash
# New role exists with the correct tag-scoped trust
aws iam get-role --role-name oktaps-mcp-gh-publisher \
  --query 'Role.AssumeRolePolicyDocument.Statement[0].Condition'

# Shared role untouched
aws iam list-attached-role-policies --role-name GitHubActionsOIDCRole
```

## Destroy

```bash
cd deploy/github-oidc
terraform destroy
```

Removes only the dedicated role + its inline policy. The shared OIDC
provider and `GitHubActionsOIDCRole` are not touched.
