output "role_arn" {
  value       = aws_iam_role.gh_publisher.arn
  description = "IAM role ARN that .github/workflows/publish-public-ecr.yml should assume. Paste into the workflow's aws-actions/configure-aws-credentials step as role-to-assume."
}

output "role_name" {
  value       = aws_iam_role.gh_publisher.name
  description = "IAM role name (for aws iam get-role verification)."
}

output "github_sub_pattern" {
  value       = local.github_sub_pattern
  description = "Exact value of the token.actions.githubusercontent.com:sub condition the role enforces. Useful for debugging AssumeRoleWithWebIdentity denials."
}

output "ecr_public_repo_arns" {
  value       = local.ecr_public_repo_arns
  description = "ARNs of the ECR Public repositories the role can push to."
}
