# -----------------------------------------------------------------------------
# github-oidc — IAM role for GitHub Actions to publish images to ECR Public.
# -----------------------------------------------------------------------------
# Standalone Terraform state; not coupled to the core aws-ecs deploy.
#
# Scope: creates one IAM role (oktaps-mcp-gh-publisher by default) that the
# .github/workflows/publish-public-ecr.yml workflow assumes via GitHub OIDC.
# Trust policy is restricted to tag pushes on a single repo — branches,
# PRs, and other repos are rejected.
#
# The OIDC provider itself is NOT managed here. The account already has one
# (serving other projects), so we reference it via data source and leave it
# untouched.
# -----------------------------------------------------------------------------

data "aws_caller_identity" "current" {}

data "aws_iam_openid_connect_provider" "github" {
  url = "https://token.actions.githubusercontent.com"
}

locals {
  # Sub claim condition — scope to tag refs matching the allowed pattern.
  # Example default: repo:atko-proservices/okta-agent-mcp-adapter:ref:refs/tags/v*.*.*
  github_sub_pattern = "repo:${var.github_org}/${var.github_repo}:ref:refs/tags/${var.allowed_tag_pattern}"

  # ECR Public repos we're granting push on. Limited to the four images the
  # workflow actually publishes, so this role cannot push to arbitrary repos
  # in the alias.
  ecr_public_repo_names = [
    "okta-mcp-adapter",
    "okta-mcp-admin-ui",
    "okta-mcp-hr-server",
    "okta-mcp-deploy-server",
  ]

  ecr_public_repo_arns = [
    for name in local.ecr_public_repo_names :
    "arn:aws:ecr-public::${data.aws_caller_identity.current.account_id}:repository/${name}"
  ]
}

resource "aws_iam_role" "gh_publisher" {
  name        = var.role_name
  description = "GitHub Actions role for publishing ${var.github_org}/${var.github_repo} images to public.ecr.aws/${var.ecr_public_alias}/. Tag-scoped trust only."

  # 1-hour max session is sufficient for a build+push workflow. Also matches
  # the default on the existing GitHubActionsOIDCRole in this account.
  max_session_duration = 3600

  assume_role_policy = jsonencode({
    Version = "2012-10-17"
    Statement = [
      {
        Effect = "Allow"
        Principal = {
          Federated = data.aws_iam_openid_connect_provider.github.arn
        }
        Action = "sts:AssumeRoleWithWebIdentity"
        Condition = {
          StringEquals = {
            "token.actions.githubusercontent.com:aud" = "sts.amazonaws.com"
          }
          StringLike = {
            "token.actions.githubusercontent.com:sub" = local.github_sub_pattern
          }
        }
      }
    ]
  })
}

resource "aws_iam_role_policy" "ecr_public_push" {
  name = "${var.role_name}-ecr-public-push"
  role = aws_iam_role.gh_publisher.id

  policy = jsonencode({
    Version = "2012-10-17"
    Statement = [
      {
        Sid    = "ECRPublicAuth"
        Effect = "Allow"
        Action = [
          "ecr-public:GetAuthorizationToken",
          "sts:GetServiceBearerToken"
        ]
        # Auth actions cannot be resource-scoped — they mint session tokens
        # that subsequent push actions use. The push actions below ARE scoped.
        Resource = "*"
      },
      {
        Sid    = "ECRPublicRead"
        Effect = "Allow"
        Action = [
          "ecr-public:BatchCheckLayerAvailability",
          "ecr-public:DescribeRepositories",
          "ecr-public:DescribeImages"
        ]
        Resource = local.ecr_public_repo_arns
      },
      {
        Sid    = "ECRPublicPush"
        Effect = "Allow"
        Action = [
          "ecr-public:InitiateLayerUpload",
          "ecr-public:UploadLayerPart",
          "ecr-public:CompleteLayerUpload",
          "ecr-public:PutImage"
        ]
        Resource = local.ecr_public_repo_arns
      }
    ]
  })
}
