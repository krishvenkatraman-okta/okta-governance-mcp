#!/usr/bin/env bash
# =============================================================
# db_bootstrap.sh — Cross-cloud DB bootstrap helper (P15)
# =============================================================
# Source this file from a deploy script after sourcing the
# caller's own ok()/info()/warn()/die() output helpers.
#
# Controls whether the deploy pipeline runs the role bootstrap
# (bootstrap_roles.sql) and schema migrations, and by which path:
#
#   1. Cloud-native job  — preferred; runs inside the deployed
#                          VPC/VNet with the right managed identity.
#   2. Local execution   — fallback; runs on the deploy host when
#                          the cloud CLI is missing or unauthenticated.
#   3. Off                — RUN_DB_BOOTSTRAP=false prints a copy-
#                          pasteable operator handoff block and
#                          exits cleanly (the adapter container
#                          will fail to start until a DBA runs
#                          migrations, which is the desired
#                          hand-off behavior).
#
# Required env vars set by the caller before invoking db_bootstrap_run:
#   PLATFORM           - "aws" or "azure"
#   DB_HOST            - DB endpoint hostname
#   DB_PORT            - DB port (5432)
#   DB_NAME            - database name
#   DB_OWNER_ROLE      - owner role name (default okta_adapter_owner)
#   DB_APP_ROLE        - app role name (default okta_adapter_app)
#   MIGRATIONS_DIR     - absolute path to deploy/migrations/sql
#
# Platform-specific (AWS):
#   AWS_REGION
#   ECS_CLUSTER
#   MIGRATE_TASK_DEF_ARN
#   ECS_SUBNETS          - comma-separated subnet IDs
#   ECS_SECURITY_GROUPS  - comma-separated SG IDs
#   DB_MASTER_SECRET_ARN - Secrets Manager ARN for master creds
#                          (SecretString JSON key: DATABASE_URL)
#   USE_RDS_IAM          - "true"/"false" from terraform output;
#                          when true the owner role has no standing
#                          password and local-exec for migrate is
#                          not supported.
#
# Platform-specific (Azure):
#   AZURE_RG
#   MIGRATE_JOB_NAME      - Container Apps Job name
#   PG_MASTER_USER        - master admin login (local-exec only)
#   PG_MASTER_PASSWORD    - master admin password (local-exec only;
#                          from state file, never Key Vault)
#   ENTRA_OWNER_PRINCIPAL - Entra principal name for owner role
#                          (used only in the handoff block)

: "${RUN_DB_BOOTSTRAP:=true}"
: "${DB_BOOTSTRAP_TIMEOUT:=600}"         # seconds to wait for cloud-native job
: "${DB_BOOTSTRAP_FORCE_LOCAL:=false}"   # set true to skip cloud-job attempt entirely

# -------------------------------------------------------------
# Public entrypoint
# -------------------------------------------------------------
db_bootstrap_run() {
    if [ "$RUN_DB_BOOTSTRAP" != "true" ]; then
        db_bootstrap_print_handoff
        return 0
    fi

    info "RUN_DB_BOOTSTRAP=true — executing role bootstrap and migrations"

    local path
    if [ "$DB_BOOTSTRAP_FORCE_LOCAL" = "true" ]; then
        info "DB_BOOTSTRAP_FORCE_LOCAL=true — skipping cloud-native job"
        path="local"
    elif _cloud_cli_available_and_authed; then
        path="cloud_job"
    else
        warn "Cloud CLI unavailable or not authenticated — falling back to local execution"
        path="local"
    fi

    case "$path" in
        cloud_job)
            _bootstrap_via_cloud_job
            # Cloud_job post-condition is the job's exit code (handled inside
            # _bootstrap_*_cloud_job via die on non-zero). The deploy host
            # cannot re-verify directly because the DB sits in private
            # subnets (AWS) or behind a private endpoint (Azure).
            ;;
        local)
            _bootstrap_via_local_exec
            _verify_post_condition
            ;;
    esac
    ok "Database bootstrap complete (path: $path)"
}

# -------------------------------------------------------------
# Cloud CLI probe
# -------------------------------------------------------------
_cloud_cli_available_and_authed() {
    case "$PLATFORM" in
        aws)
            command -v aws >/dev/null 2>&1 || return 1
            aws sts get-caller-identity --region "$AWS_REGION" >/dev/null 2>&1 || return 1
            return 0
            ;;
        azure)
            command -v az >/dev/null 2>&1 || return 1
            az account show >/dev/null 2>&1 || return 1
            return 0
            ;;
        *) die "Unknown PLATFORM: $PLATFORM" ;;
    esac
}

# -------------------------------------------------------------
# Path 1: cloud-native one-shot job
# -------------------------------------------------------------
_bootstrap_via_cloud_job() {
    info "Bootstrap path: cloud-native job"
    case "$PLATFORM" in
        aws)   _bootstrap_aws_ecs_runtask ;;
        azure) _bootstrap_azure_aca_job ;;
        *)     die "Unknown PLATFORM: $PLATFORM" ;;
    esac
}

_bootstrap_aws_ecs_runtask() {
    [ -n "${MIGRATE_TASK_DEF_ARN:-}" ] || die "MIGRATE_TASK_DEF_ARN not set"
    [ -n "${ECS_CLUSTER:-}" ]          || die "ECS_CLUSTER not set"
    [ -n "${ECS_SUBNETS:-}" ]          || die "ECS_SUBNETS not set"
    [ -n "${ECS_SECURITY_GROUPS:-}" ]  || die "ECS_SECURITY_GROUPS not set"

    info "Triggering ECS RunTask: $MIGRATE_TASK_DEF_ARN"
    local task_arn
    task_arn="$(
        aws ecs run-task \
            --region "$AWS_REGION" \
            --cluster "$ECS_CLUSTER" \
            --task-definition "$MIGRATE_TASK_DEF_ARN" \
            --launch-type FARGATE \
            --network-configuration "awsvpcConfiguration={subnets=[$ECS_SUBNETS],securityGroups=[$ECS_SECURITY_GROUPS],assignPublicIp=DISABLED}" \
            --query 'tasks[0].taskArn' --output text 2>/dev/null
    )" || die "ecs run-task failed"
    [ -n "$task_arn" ] && [ "$task_arn" != "None" ] || die "No task ARN returned"
    info "ECS task started: $task_arn"

    info "Waiting for migrate task to complete (timeout ${DB_BOOTSTRAP_TIMEOUT}s)..."
    aws ecs wait tasks-stopped \
        --region "$AWS_REGION" \
        --cluster "$ECS_CLUSTER" \
        --tasks "$task_arn" || die "Timed out waiting for migrate task"

    local exit_code
    exit_code="$(
        aws ecs describe-tasks \
            --region "$AWS_REGION" \
            --cluster "$ECS_CLUSTER" \
            --tasks "$task_arn" \
            --query 'tasks[0].containers[0].exitCode' --output text 2>/dev/null
    )"
    if [ "$exit_code" != "0" ]; then
        warn "Migrate task exited with code $exit_code — recent logs:"
        aws logs tail /ecs/oktaps-mcp/adapter --region "$AWS_REGION" --since 10m 2>/dev/null \
            | tail -50 || true
        die "Migration failed (exit $exit_code)"
    fi
    ok "ECS migrate task completed successfully"
}

_bootstrap_azure_aca_job() {
    [ -n "${MIGRATE_JOB_NAME:-}" ] || die "MIGRATE_JOB_NAME not set"
    [ -n "${AZURE_RG:-}" ]         || die "AZURE_RG not set"

    info "Triggering Container Apps Job: $MIGRATE_JOB_NAME"
    local execution_name
    execution_name="$(
        az containerapp job start \
            -g "$AZURE_RG" -n "$MIGRATE_JOB_NAME" \
            --query 'name' -o tsv 2>/dev/null
    )" || die "Failed to start Container Apps Job"
    [ -n "$execution_name" ] || die "Empty execution name from az containerapp job start"
    info "Job execution started: $execution_name"

    local elapsed=0 status
    info "Waiting for migrate job to complete (timeout ${DB_BOOTSTRAP_TIMEOUT}s)..."
    while [ "$elapsed" -lt "$DB_BOOTSTRAP_TIMEOUT" ]; do
        status="$(
            az containerapp job execution show \
                -g "$AZURE_RG" -n "$MIGRATE_JOB_NAME" \
                --job-execution-name "$execution_name" \
                --query 'properties.status' -o tsv 2>/dev/null || echo "Unknown"
        )"
        case "$status" in
            Succeeded)
                ok "ACA migrate job completed successfully"
                return 0
                ;;
            Failed|Degraded)
                warn "Migrate job status: $status — recent logs follow:"
                az containerapp logs show \
                    -g "$AZURE_RG" -n "$MIGRATE_JOB_NAME" \
                    --type system --tail 50 2>/dev/null || true
                die "Migration failed (status $status)"
                ;;
        esac
        sleep 10
        elapsed=$((elapsed + 10))
    done
    die "Timed out waiting for migrate job after ${DB_BOOTSTRAP_TIMEOUT}s"
}

# -------------------------------------------------------------
# Path 2: local execution fallback
# -------------------------------------------------------------
_bootstrap_via_local_exec() {
    info "Bootstrap path: local execution"
    _check_local_prereqs

    local master_url owner_url
    master_url="$(_resolve_master_db_url)"
    owner_url="$(_resolve_owner_db_url)"

    info "Step 1/2: applying bootstrap_roles.sql (idempotent)"
    DB_OWNER_ROLE="$DB_OWNER_ROLE" DB_APP_ROLE="$DB_APP_ROLE" DB_NAME="$DB_NAME" \
        psql "$master_url" -v ON_ERROR_STOP=1 \
             -f "$MIGRATIONS_DIR/bootstrap_roles.sql" \
        || die "bootstrap_roles.sql failed"
    ok "Roles bootstrapped"

    info "Step 2/2: applying migrations"
    python -m okta_agent_proxy.storage.migrate upgrade \
           --migrations-dir "$MIGRATIONS_DIR" \
           --conninfo "$owner_url" \
           --applied-by "deploy.sh@$(hostname)" \
        || die "Migrations failed"
    ok "Migrations applied"
}

_check_local_prereqs() {
    command -v psql >/dev/null 2>&1 || die \
      "psql not found. Install postgres-client or set RUN_DB_BOOTSTRAP=false and run migrations from a host that has it."
    command -v python >/dev/null 2>&1 || die \
      "python not found. Install Python 3.12+ or set RUN_DB_BOOTSTRAP=false."
    python -c 'import okta_agent_proxy.storage.migrate' 2>/dev/null || die \
      "okta_agent_proxy package not importable. Run from project root with venv active."
}

_resolve_master_db_url() {
    case "$PLATFORM" in
        aws)
            # Single secret: aws_secretsmanager_secret.db. SecretString is a
            # JSON object whose DATABASE_URL key holds master creds.
            [ -n "${DB_MASTER_SECRET_ARN:-}" ] || die "DB_MASTER_SECRET_ARN not set"
            aws secretsmanager get-secret-value \
                --region "$AWS_REGION" \
                --secret-id "$DB_MASTER_SECRET_ARN" \
                --query SecretString --output text 2>/dev/null \
              | python -c 'import sys,json; print(json.load(sys.stdin)["DATABASE_URL"])' \
              || die "Failed to fetch master DB URL"
            ;;
        azure)
            [ -n "${PG_MASTER_USER:-}" ]     || die "PG_MASTER_USER not set"
            [ -n "${PG_MASTER_PASSWORD:-}" ] || die "PG_MASTER_PASSWORD not set"
            local enc_pwd
            enc_pwd="$(_url_encode "$PG_MASTER_PASSWORD")"
            echo "postgresql://${PG_MASTER_USER}:${enc_pwd}@${DB_HOST}:${DB_PORT}/${DB_NAME}?sslmode=require"
            ;;
        *) die "Unknown PLATFORM: $PLATFORM" ;;
    esac
}

_resolve_owner_db_url() {
    case "$PLATFORM" in
        aws)
            if [ "${USE_RDS_IAM:-false}" = "true" ]; then
                die "Local-exec path is not supported when USE_RDS_IAM=true. The owner role has no standing password. Either unset DB_BOOTSTRAP_FORCE_LOCAL and allow the cloud-job path, or set use_rds_iam=false in terraform and redeploy."
            fi
            # Static-password mode: no standing owner secret — the migrate task
            # today uses the master URL for both bootstrap and migrations. Match
            # that here so behavior is consistent across paths.
            _resolve_master_db_url
            ;;
        azure)
            # Entra: owner is a managed identity; deploy host cannot impersonate
            # it. Local-exec is a best-effort fallback that uses master creds.
            warn "Local-exec on Azure uses master credentials for migrations (fallback only)"
            _resolve_master_db_url
            ;;
        *) die "Unknown PLATFORM: $PLATFORM" ;;
    esac
}

_url_encode() {
    python -c 'import sys, urllib.parse; print(urllib.parse.quote(sys.argv[1], safe=""))' "$1"
}

# -------------------------------------------------------------
# Post-condition verification (local-exec path only)
# -------------------------------------------------------------
_verify_post_condition() {
    info "Verifying schema_migrations.current_version >= MIN_SCHEMA_VERSION"
    local owner_url current min
    owner_url="$(_resolve_owner_db_url)"
    current="$(
        python -m okta_agent_proxy.storage.migrate version --conninfo "$owner_url" 2>/dev/null
    )"
    min="$(python -c 'from okta_agent_proxy.storage.constants import MIN_SCHEMA_VERSION; print(MIN_SCHEMA_VERSION)' 2>/dev/null)"
    if [ -z "$current" ] || [ "$current" = "(none)" ]; then
        die "Post-condition failed: schema_migrations is empty after bootstrap"
    fi
    if [ -z "$min" ]; then
        die "Could not import MIN_SCHEMA_VERSION from okta_agent_proxy.storage.constants"
    fi
    # String comparison is correct here because versions are zero-padded
    # 3-digit strings (001, 002, ...).
    if [ "$current" \< "$min" ]; then
        die "Post-condition failed: current_version=$current < MIN_SCHEMA_VERSION=$min"
    fi
    ok "Schema version verified: $current"
}

# -------------------------------------------------------------
# Off-mode operator handoff block
# -------------------------------------------------------------
db_bootstrap_print_handoff() {
    local owner_secret_ref=""
    case "$PLATFORM" in
        aws)
            owner_secret_ref="aws secretsmanager get-secret-value --region ${AWS_REGION:-<region>} --secret-id ${DB_MASTER_SECRET_ARN:-<master-secret-arn>} --query SecretString --output text"
            ;;
        azure)
            owner_secret_ref="(use the Entra-authenticated owner identity: ${ENTRA_OWNER_PRINCIPAL:-<owner-principal>})"
            ;;
    esac

    cat <<EOF

════════════════════════════════════════════════════════════════════════════════
DEPLOYMENT COMPLETE — DATABASE BOOTSTRAP NOT YET RUN (RUN_DB_BOOTSTRAP=false)
════════════════════════════════════════════════════════════════════════════════

The adapter will FAIL TO START until your DBA completes the steps below.
This is intentional: the application will not create schema at runtime.

Required role names:
  Owner role: ${DB_OWNER_ROLE:-okta_adapter_owner}
  App role:   ${DB_APP_ROLE:-okta_adapter_app}
  Database:   ${DB_NAME:-gateway_db} on ${DB_HOST:-<db-host>}:${DB_PORT:-5432}

Master credentials (one-time role bootstrap):
  ${owner_secret_ref}

────────────────────────────────────────────────────────────────────────────────
OPTION A: trigger the cloud-native one-shot job (recommended)
────────────────────────────────────────────────────────────────────────────────
EOF
    case "$PLATFORM" in
        aws) cat <<EOF
  aws ecs run-task \\
      --region ${AWS_REGION:-<region>} \\
      --cluster ${ECS_CLUSTER:-<cluster>} \\
      --task-definition ${MIGRATE_TASK_DEF_ARN:-<migrate-task-def-arn>} \\
      --launch-type FARGATE \\
      --network-configuration 'awsvpcConfiguration={subnets=[${ECS_SUBNETS:-<subnet-ids>}],securityGroups=[${ECS_SECURITY_GROUPS:-<sg-ids>}],assignPublicIp=DISABLED}'

EOF
            ;;
        azure) cat <<EOF
  az containerapp job start -g ${AZURE_RG:-<rg>} -n ${MIGRATE_JOB_NAME:-<job-name>}

EOF
            ;;
    esac
    cat <<EOF
────────────────────────────────────────────────────────────────────────────────
OPTION B: run from a DBA jump host with psql + the project venv
────────────────────────────────────────────────────────────────────────────────
  # 1. Create roles (idempotent):
  DB_OWNER_ROLE=${DB_OWNER_ROLE:-okta_adapter_owner} DB_APP_ROLE=${DB_APP_ROLE:-okta_adapter_app} DB_NAME=${DB_NAME:-gateway_db} \\
      psql "<master-url>" -f deploy/migrations/sql/bootstrap_roles.sql

  # 2. Apply migrations as the owner role:
  python -m okta_agent_proxy.storage.migrate upgrade \\
      --conninfo "<owner-url>"

  # 3. Verify (optional):
  python -m okta_agent_proxy.storage.migrate status --conninfo "<owner-url>"

────────────────────────────────────────────────────────────────────────────────
After bootstrap completes, restart the adapter Container App / ECS service.
The schema-version guard will pass and the adapter will start normally.
════════════════════════════════════════════════════════════════════════════════

EOF
}
