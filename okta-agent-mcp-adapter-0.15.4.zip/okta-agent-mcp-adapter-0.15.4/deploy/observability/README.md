# Observability Stack (Grafana + Loki + Promtail)

Optional Docker Compose overlay that adds log-based observability for the Okta MCP Adapter. Provides a pre-built Grafana dashboard for visualizing audit events, security metrics, and agent activity.

## Prerequisites

- Base Docker Compose stack running (`docker compose up -d`)
- Audit prompts 1-9 implemented (structured JSON audit events on stdout)
- Docker socket accessible at `/var/run/docker.sock`

## Quick Start

```bash
# Start the full stack (base + observability)
docker compose -f docker-compose.yml \
  -f deploy/observability/docker-compose.observability.yml up -d

# Verify all services are healthy
docker compose -f docker-compose.yml \
  -f deploy/observability/docker-compose.observability.yml ps
```

## Access

| Service | URL | Credentials |
|---------|-----|-------------|
| Grafana | http://localhost:3000 | admin / admin |
| Loki API | http://localhost:3100 | none |

The pre-provisioned dashboard is at **Dashboards > Okta MCP Adapter -- Audit & Observability**.

## Generating Test Events

Generate audit events by interacting with the adapter. Admin API requests
require an Okta OAuth access token (see
[docs/OPERATIONS.md § Admin API Authentication](../../docs/OPERATIONS.md#admin-api-authentication)):

```bash
export OKTA_ADMIN_TOKEN="<paste token from Admin UI>"

# List agents (generates admin API activity + auth.jwt.validated events)
curl -s http://localhost:8000/api/admin/agents \
  -H "Authorization: Bearer $OKTA_ADMIN_TOKEN"

# Update a resource URL (generates config.resource.updated event).
# Resources are auto-created by Okta sync; this sets the downstream URL.
curl -s -X PUT http://localhost:8000/api/admin/resources/test-backend \
  -H "Authorization: Bearer $OKTA_ADMIN_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"url": "http://localhost:9999", "enabled": true}'

# Delete the test backend (generates config.resource.deleted event)
curl -s -X DELETE http://localhost:8000/api/admin/resources/test-backend \
  -H "Authorization: Bearer $OKTA_ADMIN_TOKEN"
```

Wait 10-15 seconds, then check Grafana. Events flow through: adapter stdout -> Promtail -> Loki -> Grafana.

## Dashboard Panels

- **Overview row**: Total events, tool calls, auth failures, authz denied (stat panels)
- **Request Activity**: Events over time by type, latency distribution (p50/p95)
- **Security Events**: Auth/authz event breakdown, token exchange success/failure/cache
- **Agent Activity**: Events by agent ID, events by backend (bar charts)
- **Live Event Stream**: Full-width scrolling log panel with JSON expansion
- **Admin Activity**: Config changes and admin login logs

## Stopping

```bash
docker compose -f docker-compose.yml \
  -f deploy/observability/docker-compose.observability.yml down -v
```

## Customization

- **Retention**: Edit `loki-config.yml` — `retention_period` (default: 168h / 7 days)
- **Add panels**: Edit the dashboard JSON in `grafana/provisioning/dashboards/json/` or use Grafana's UI (changes persist in the `grafana_data` volume)
- **Labels**: Add/remove extracted labels in `promtail-config.yml` under `pipeline_stages`
- **Alerting**: Configure Grafana alerting rules against Loki queries for real-time notifications
