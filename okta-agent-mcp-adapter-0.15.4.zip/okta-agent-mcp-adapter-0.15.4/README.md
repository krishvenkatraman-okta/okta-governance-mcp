# Okta Agent Adapter

Authorization bridge for MCP tool calls.

## What It Does

The Okta Agent Adapter sits between MCP clients (Claude Code, Cursor, Copilot) and downstream resource servers. It validates Okta JWTs, enforces per-agent access control, translates credentials via ID-JAG token exchange, and forwards requests to the correct resource. All configuration is stored in PostgreSQL with AES-256-GCM encryption and full audit logging.

## Prerequisites

- **Docker and Docker Compose** (Docker Desktop includes both)
- **An Okta developer org** — [Sign up free](https://developer.okta.com/signup/)
- **Python 3.10+** (only needed for local development outside Docker)
- **Node.js 18+** (only needed for local Admin UI development outside Docker)
- **Claude Code CLI v2.1.30+** (for MCP client — [Install](https://docs.anthropic.com/en/docs/claude-code))

## Quick Start

## Okta Organization Setup

You need to create one OIDC application in Okta for the Admin UI. Additional applications per MCP client agent will be required for authorization and XAA flows. 

### Admin UI OIDC Application

This application allows administrators to sign in to the web console.

1. In the Okta Admin Console, go to **Applications > Applications > Create App Integration**
2. Select **OIDC - OpenID Connect**, then **Web Application**
3. Configure:

| Field | Value |
|-------|-------|
| App integration name | `Okta MCP Adapter Admin UI` |
| Grant types | Authorization Code, Refresh Token |
| Sign-in redirect URI | `http://localhost:3001/api/auth/callback/okta` |
| Sign-out redirect URI | `http://localhost:3001/login` |

4. Click **Save** and note the **Client ID** and **Client Secret**

5. Go to the **Okta API Scopes** tab on the application and **Grant** each of the following:

| Scope | Purpose |
|-------|---------|
| `okta.aiAgents.read` | List and read AI Agent details |
| `okta.aiAgents.manage` | Import, sync, and credential operations |
| `okta.apps.read` | Read linked OIDC app details |
| `okta.apps.manage` | Client secret operations (credential automation) |
| `okta.groups.read` | Read group information |
| `okta.authorizationServers.read` | Match connections to adapter resources |

> **Note:** Make sure you have Okta for AI Agents SKU and enabled the feature.

### MCP Client OIDC Application

This application will link to your Okta Agent AI.  Create MCP Client applications for each agent for example claude code, vscode, etc.  Note the redirect uri is the adapter.

1. In the Okta Admin Console, go to **Applications > Applications > Create App Integration**
2. Select **OIDC - OpenID Connect**, then **Web Application**
3. Configure:

| Field | Value |
|-------|-------|
| App integration name | `MCP Agent - Claude Code` (or your agent name) |
| Grant types | Authorization Code, Refresh Token, Token Exchange |
| Sign-in redirect URI | `http://localhost:8000/oauth/callback` |

## Port Configuration

All ports are configurable via environment variables. Defaults:

| Component | Env var | Default |
|---|---|---|
| Adapter | `GATEWAY_PORT` | 8000 |
| Admin UI | `ADMIN_UI_PORT` | 3001 |
| HR example | `HR_BACKEND_PORT` | 8001 |
| Deploy example | `DEPLOY_SERVER_PORT` | 8005 |

To avoid a port collision during `docker compose up`:

```bash
GATEWAY_PORT=9000 ADMIN_UI_PORT=4001 docker compose up -d
```

Full guide: [docs/OPERATIONS.md](docs/OPERATIONS.md#port-configuration)

## Local Setup

### 1. Create your environment file

The github repo source zip can be downloaded from the followig google drive folder.  [bundles](https://drive.google.com/drive/folders/1cUfNyqk0AZffbQaa96ncsa_qbGTVc2F9) 

```bash
git clone <repo-url> && cd okta-agent-mcp-adapter
```
or 
```bash
unzip okta-agent-mcp-adapter-[version].zip && cd okta-agent-mcp-adapter-[version]
```
```bash
cp .env.example .env
```

### 2. Set required values in `.env`

**Okta Configuration** (your Okta org domain):

```bash
OKTA_DOMAIN=dev-12345678.okta.com
```

**Admin UI OIDC** (from the Admin UI OIDC app you created above):

```bash
ADMIN_UI_NEXTAUTH_SECRET=<generate-with-command-below>
ADMIN_UI_OKTA_DOMAIN=dev-12345678.okta.com
ADMIN_UI_OKTA_CLIENT_ID=0oaXXXXXXXXXXXXXX
ADMIN_UI_OKTA_CLIENT_SECRET=XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
```

Generate the NextAuth secret:

```bash
openssl rand -base64 32
```

### Local Development Only env settings

| Variable | Description | Notes |
|----------|-------------|-------|
| `CIMD_TLS_VERIFY` | Disable TLS verification for CIMD fetches this may be required when leveraging DOCKER on work laptops | Set to `false` |
| `CIMD_ALLOW_LOCALHOST` | Allow localhost CIMD URLs | Set in docker-compose for local dev |
| `CIMD_ALLOW_PRIVATE_NETWORKS` | Allow private network CIMD URLs | Set in docker-compose for local dev |

### Prisma TLS Inspection (Okta Corporate Laptop Only — Manual Patch)

The default `Dockerfile` does **not** install Okta's Prisma TLS inspection root CA. All cloud deploys (AWS ECS/EC2/EKS, Azure ACA/AKS) build cleanly without it. If you are building the image on a **corporate laptop behind Prisma SASE**, image builds will fail when `pip`, `apt`, or `curl` hit the intercepted HTTPS. Apply this local-only patch:

**1. Download the CA bundle** (the file is gitignored, so it will not be committed):

```bash
curl -o prisma_certificates.pem https://okta-private-ca.s3.amazonaws.com/prisma_certificates.pem
```

**2. Patch your local `Dockerfile`** — add the following three lines to the production stage (after `FROM python:3.13-slim` and before the `RUN apt-get` block):

```dockerfile
COPY prisma_certificates.pem /usr/local/share/ca-certificates/prisma-certificates.crt
RUN update-ca-certificates
ENV SSL_CERT_FILE=/etc/ssl/certs/ca-certificates.crt
```

**3. Build as usual** — `docker compose build okta-agent-mcp-adapter`.

> :warning: **Do not commit the `Dockerfile` patch or `prisma_certificates.pem`.** Both are local-only. The cert file is already gitignored; use `git restore Dockerfile` before committing other changes in the same branch.

### 3. Run setup

```bash
./setup.sh
```

This script will:
- Validate your `.env` configuration
- Generate `ENCRYPTION_KEY` if not already set
- Build and start all Docker containers
- Wait for PostgreSQL, Redis, gateway, and Admin UI health checks
- Run smoke tests

## What Gets Deployed

| Service | Container | Port | Description |
|---------|-----------|------|-------------|
| PostgreSQL | `okta-mcp-postgres` | 5432 | Configuration and audit storage |
| Redis | `okta-mcp-redis` | 6379 | Cache and event bus |
| Gateway | `okta-agent-mcp-adapter` | 8000 | OAuth proxy with Admin API |
| Admin UI | `okta-mcp-admin-ui` | 3001 | Web-based admin console |
| HR MCP Server | `hr-mcp-server` | 8001 | Example resource (PSK auth) |
| Deploy MCP Server | `deploy-mcp-server` | 8005 | Example resource (Cross-App Access) |


### 4. Verify

```bash
curl -s http://localhost:8000/.well-known/oauth-protected-resource | python3 -m json.tool
```

## Admin UI

Open `http://localhost:3001` in your browser and click **Sign in with Okta**.

> The Admin UI uses Okta OIDC for authentication. You must complete the [Admin UI OIDC Application](#admin-ui-oidc-application) setup above.

Features:
- **Dashboard** with system overview and statistics
- **Agents** management (create, edit, delete, credential automation)
- **Resources** configuration with multi-auth support
- **Okta Import** for importing AI Agents from Okta Universal Directory

See [Admin UI OIDC Setup](okta_agent_proxy_admin_ui/OKTA_OIDC_SETUP.md) for detailed setup and troubleshooting.

## Agent Configuration and Okta Linking

### Import from Okta

1. Open the Admin UI at `http://localhost:3001`
2. Select **Import from Okta** 
3. Select AI Agents from your Okta org to import
4. The adapter creates agent records linked to existing Okta AI Agent principals

Requires the Okta API scopes to be granted on the Admin UI OIDC app (see [Okta Organization Setup](#admin-ui-oidc-application)).

## Connecting AI Coding Agents

### Claude Code

**CIMD mode (easiest):**

Connect Claude Code using unifed mode:

```bash
claude mcp add --transport http okta-gateway http://localhost:8000
```

Connect Claude Code using direct mode:

```bash
claude mcp add --transport http deploy-server http://localhost:8000/deploy-server
claude mcp add --transport http hr-server http://localhost:8000/hr-server
```

Inside Claude Code, run `/mcp` and select "Authenticate" for okta-gateway. A browser window opens for Okta login.

**Verify**: Run `/mcp` in Claude Code. You should see tools listed.

### VS Code (Copilot / Cursor)

Add to your VS Code settings (Cmd+Shift+P > "MCP: Add Server") or create `.vscode/mcp.json`:

```json
{
  "servers": {
    "okta-gateway": {
      "type": "http",
      "url": "http://localhost:8000"
    }
  }
}
```

See the [VS Code MCP documentation](https://code.visualstudio.com/docs/copilot/chat/mcp-servers) for more details.

## Redirect URI Reference

| Okta Application | Redirect URI | Purpose |
|---|---|---|
| Admin UI OIDC App | `http://localhost:3001/api/auth/callback/okta` | Admin SSO sign-in |
| Admin UI OIDC App (sign-out) | `http://localhost:3001/login` | Sign-out redirect |
| MCP Client OIDC App (per agent) | `http://localhost:3000/oauth/callback` | Claude Code OAuth callback |

## Testing the Gateway

Quick connectivity check (no auth required):

```bash
# Verify gateway is running
curl -s http://localhost:8000/.well-known/oauth-protected-resource | python3 -m json.tool

# Test MCP initialize (no auth required)
curl -s -X POST http://localhost:8000 \
  -H "Content-Type: application/json" \
  -d '{"jsonrpc":"2.0","id":"1","method":"initialize","params":{"protocolVersion":"2024-11-05","capabilities":{},"clientInfo":{"name":"test","version":"1.0"}}}' \
  | python3 -m json.tool
```

## Environment Variables Reference

### Required: Okta Configuration

| Variable | Description | Example |
|----------|-------------|---------|
| `OKTA_DOMAIN` | Your Okta org domain | `dev-12345678.okta.com` |
| `OKTA_ISSUER` | Token issuer URL (optional, defaults to Org auth server) | `https://dev-12345678.okta.com` |

### Required: Admin UI OIDC

| Variable | Description | Example |
|----------|-------------|---------|
| `ADMIN_UI_NEXTAUTH_URL` | Admin UI base URL | `http://localhost:3001` |
| `ADMIN_UI_NEXTAUTH_SECRET` | Session encryption secret | `openssl rand -base64 32` |
| `ADMIN_UI_OKTA_DOMAIN` | Okta domain for Admin UI OIDC | `dev-12345678.okta.com` |
| `ADMIN_UI_OKTA_CLIENT_ID` | Admin UI OIDC app client ID | `0oaXXXXXXXX` |
| `ADMIN_UI_OKTA_CLIENT_SECRET` | Admin UI OIDC app client secret | `XXXXXXXXXX` |

### Auto-Generated Secrets

| Variable | Description | Default |
|----------|-------------|---------|
| `ENCRYPTION_KEY` | AES-256-GCM key for credential encryption | Generated by `setup.sh` |

### Gateway

| Variable | Description | Default |
|----------|-------------|---------|
| `GATEWAY_BASE_URL` | Public URL of the gateway | `http://localhost:8000` |
| `GATEWAY_PORT` | Gateway listen port | `8000` |

> **Admin API authentication:** the adapter accepts **only Okta OAuth access
> tokens** (v0.15.x+). Configure the Admin UI's Okta OIDC app via
> `ADMIN_UI_OKTA_DOMAIN` / `ADMIN_UI_OKTA_CLIENT_ID` / `ADMIN_UI_OKTA_CLIENT_SECRET`
> (see the *Admin UI* section below). For API testing, obtain an access token
> from that app and send it as `Authorization: Bearer <token>`.

### Database

| Variable | Description | Default |
|----------|-------------|---------|
| `DATABASE_URL` | PostgreSQL connection string | `postgresql://gateway_user:gateway_pass@postgres:5432/gateway_db` |
| `POSTGRES_DB` | Database name | `gateway_db` |
| `POSTGRES_USER` | Database user | `gateway_user` |
| `POSTGRES_PASSWORD` | Database password | `gateway_pass` |

### Redis Cache (optional)

| Variable | Description | Default |
|----------|-------------|---------|
| `CACHE_PROVIDER` | `redis` or `memory` | `redis` |
| `REDIS_URL` | Redis connection URL | `redis://:redis-secret@redis:6379/0` |
| `REDIS_PASSWORD` | Redis authentication password | `redis-secret` |
| `REDIS_TLS_ENABLED` | Enable TLS for Redis | `false` |
| `REDIS_KEY_PREFIX` | Key prefix for shared Redis instances | `okta-mcp:` |

### CIMD Configuration

| Variable | Description | Default |
|----------|-------------|---------|
| `CIMD_TRUSTED_DOMAINS` | Comma-separated trusted domains | `localhost,host.docker.internal` |
| `CIMD_TRUSTED_BACKEND_ACCESS` | Resources for trusted CIMD clients | `hr-system,deploy-server` |
| `CIMD_UNKNOWN_BACKEND_ACCESS` | Resources for unknown CIMD clients | `hr-system,deploy-server` |
| `CIMD_AUTO_PROVISION_AGENT` | Auto-provision agent records | `true` |

### DCR Configuration

| Variable | Description | Default |
|----------|-------------|---------|
| `DCR_ENABLED` | Enable Dynamic Client Registration | `true` |
| `DCR_PROVISION_OKTA_APP` | Provision real Okta apps via DCR | `false` |
| `DCR_AUTO_ENABLE_AGENT` | Auto-enable DCR-created agents | `true` |
| `DCR_IP_ALLOWLIST` | Optional IP allowlist (CIDRs) | _(none)_ |
| `DCR_INITIAL_ACCESS_TOKEN` | Optional bearer token for DCR | _(none)_ |

### Okta AI Agent Integration

| Variable | Description | Default |
|----------|-------------|---------|
| `OKTA_AI_AGENT_ID` | Adapter's AI Agent principal ID | _(none)_ |
| `OKTA_AI_AGENT_CLIENT_ID` | OIDC app client ID for the AI Agent | _(none)_ |
| `OKTA_AI_AGENT_PRIVATE_KEY` | JWK private key for the AI Agent | _(none)_ |
| `OKTA_AI_AGENT_AUTO_REGISTER` | Auto-promote DCR/CIMD agents | `false` |
| `OKTA_AI_AGENT_DEFAULT_OWNER` | Default owner for auto-registered agents | _(none)_ |
| `OKTA_SERVICE_CLIENT_ID` | Service app for event-driven sync | _(none)_ |

### Audit

| Variable | Description | Default |
|----------|-------------|---------|
| `AUDIT_ENABLED` | Enable audit event emission | `true` |
| `AUDIT_SINKS` | Comma-separated sinks: `stdout`, `file`, `webhook` | `stdout` |
| `AUDIT_FILE_PATH` | File sink output path | `/app/logs/audit.jsonl` |
| `AUDIT_WEBHOOK_URL` | Webhook/SIEM endpoint | _(none)_ |
| `AUDIT_WEBHOOK_TOKEN` | Webhook authentication token | _(none)_ |

### Logging and Platform

| Variable | Description | Default |
|----------|-------------|---------|
| `LOG_LEVEL` | Log verbosity (`DEBUG`, `INFO`, `WARNING`, `ERROR`) | `INFO` |
| `LOG_FORMAT` | Log format (`json` or `text`) | `json` |
| `DOCKER_PLATFORM` | Docker image platform (`linux/amd64` or `linux/arm64`) | `linux/amd64` |

### Local Development Only

| Variable | Description | Notes |
|----------|-------------|-------|
| `CIMD_TLS_VERIFY` | Disable TLS verification for CIMD fetches | Set to `false` for local dev with self-signed certs |
| `CIMD_ALLOW_LOCALHOST` | Allow localhost CIMD URLs | Set in docker-compose for local dev |
| `CIMD_ALLOW_PRIVATE_NETWORKS` | Allow private network CIMD URLs | Set in docker-compose for local dev |

## Redis Credential Providers

The adapter authenticates to Redis through a pluggable credential
provider rather than reading a static password from environment.
This is required for deployments that fail security review on
long-lived shared secrets (regulated industries, SOC 2, PCI-DSS).

### Quick reference

| `REDIS_AUTH_MODE` | Use case                                     | Status  |
| ----------------- | -------------------------------------------- | ------- |
| `static`          | Local development with Docker Compose        | ✅      |
| `aws-iam`         | AWS ElastiCache for Redis 7+ or Valkey       | ✅      |
| `azure-entra`     | Azure Managed Redis or Cache for Redis Std+  | ✅      |
| `mtls`            | Self-hosted Redis/Valkey with X.509 client   | Phase 3 |
| `vault`           | HashiCorp Vault Redis secrets engine         | Phase 3 |

### Local development

For Docker Compose and local testing only:

    REDIS_AUTH_MODE=static
    ALLOW_STATIC_REDIS_PASSWORD=true
    REDIS_PASSWORD=redis-secret

The `ALLOW_STATIC_REDIS_PASSWORD=true` gate is mandatory — the
adapter refuses to start in static mode without it. This is
intentional: production deployments should not have this variable
set.

### Production

Set `REDIS_AUTH_MODE=aws-iam` (AWS) or `REDIS_AUTH_MODE=azure-entra`
(Azure) and the matching identity hints from `.env.example`. The
reference deployments under `deploy/aws-ecs/` and
`deploy/azure-aca/` provision the IAM roles and managed-identity
grants automatically — `terraform apply` and `acasetup.sh` are
sufficient.

Static-password mode is local-dev-only. Production deployments do
not set `ALLOW_STATIC_REDIS_PASSWORD`.

### Valkey support

Valkey is the BSD-licensed Linux Foundation fork of Redis. The
adapter supports Valkey transparently — point `REDIS_URL` at a
Valkey endpoint and everything works. Both AWS ElastiCache for
Valkey and self-hosted Valkey are tested. See `CLAUDE.md` for the
full deployment compatibility matrix.

## Architecture

Every request passes through a 7-layer pipeline:

```
Request + Bearer Token + X-MCP-Agent header
  |
  v
Layer 1  FastMCP Server         HTTP transport, MCP lifecycle
Layer 2  Authentication         Okta JWT validation, JWKS caching
Layer 3  Authorization          Agent -> resource access control
Layer 4  Routing                Path-based resource selection
Layer 5  Token Exchange         ID-JAG issuance (RFC 8693)
Layer 6  Token Cache            TTL-based caching with expiry
Layer 7  Proxy                  Add resource auth, forward request
  |
  v
Resource MCP Server
```

### Routing Modes

The adapter exposes resources in two ways simultaneously:

| Mode | Endpoint | Tool Names | Use Case |
|------|----------|------------|----------|
| Unified | `POST /` | Namespaced (`hr-system__get_employee`) | Claude Code, Cursor -- single URL |
| Direct | `POST /{resource_name}` | Original (`get_employee`) | Multi-agent, A2A, scripts |

Every resource is automatically reachable at `/{resource_name}`. Additional path aliases
can be configured via the `paths` field in resource configuration.

### Resource Auth Methods

| Method | Use Case | How It Works |
|--------|----------|--------------|
| `okta-cross-app` | Cross-org access | ID-JAG JWT exchange for resource token |
| `vault-secret` | Okta Privileged Access vaulted secrets | STS token exchange via SDK |
| `sts-service-account` | Okta PA service account credentials | STS token exchange via SDK |
| `okta-sts` | ISV tokens (GitHub, Jira, etc.) | STS brokered token exchange |
| `pre-shared-key` | Simple integrations | Static API key in custom header |
| `service-account` | Legacy systems | HTTP Basic Auth |
| `bearer-passthrough` | Direct token forwarding | Passes user's Okta Bearer token as-is |

### Token Exchange (ID-JAG)

For `okta-cross-app` resources, the gateway performs a two-step exchange:

1. Issue an ID-JAG JWT signed with the agent's private key
2. POST the assertion to the target authorization server's token endpoint
3. Cache the resulting resource token (keyed by `user_id:resource_name`)
4. On 401 from resource: invalidate cache, retry once

See [docs/ARCHITECTURE_DIAGRAM.md](docs/ARCHITECTURE_DIAGRAM.md) for detailed diagrams.

### Horizontal Scaling

The adapter is horizontally scalable behind a load balancer when backed by Redis. All per-flow state — OAuth relay sessions, gateway authorization codes, consent transactions, and user token mappings — is stored in a shared Redis instance, so session stickiness is not required. Set `CACHE_PROVIDER=redis`, `REDIS_URL`, and an identical `ENCRYPTION_KEY` on every replica. See [deploy/HORIZONTAL_SCALING.md](deploy/HORIZONTAL_SCALING.md) for sizing, health-check, and pod scaling guidance, and [docs/OPERATIONS.md](docs/OPERATIONS.md#horizontal-scaling-requirements) for the full prerequisites and troubleshooting.

## Project Structure

```
okta_agent_proxy/
  main.py               FastMCP entry point
  app.py                Starlette ASGI application (unified + path-based routes)
  database.py           PostgreSQL store factory
  mcp/                  Unified MCP handler (tool consolidation for Claude Code)
  auth/                 JWT validation, agent authz, token exchange, CIMD, DCR
  proxy/                Path-based request forwarding pipeline
  storage/              PostgreSQL repository + ORM models
  crypto/               AES-256-GCM encryption
  admin/                REST API for configuration management
  cache/                L1/L2 cache service, Redis pub/sub
  audit/                Async audit emitter, pluggable sinks
  resources/            Resource subsystem (syncer, models, event bus)
  okta_admin/           Credential automation (secret fetch, key generation)
okta_agent_proxy_admin_ui/
  app/                  Next.js 14 App Router pages
  lib/                  API client, auth config
  components/           Radix UI + Tailwind components
scripts/
  docker-entrypoint.sh  Container startup (migrations + uvicorn)
ops_scripts/
  generate_encryption_key.py  AES-256 key generation
  migrate_config_to_db.py     YAML → PostgreSQL migration
  run_gateway.sh              Local dev server launcher
examples/
  01-hr-system/         Example HR MCP server (PSK auth)
  05-deploy-server/     Example Deploy MCP server (Cross-App Access)
deploy/
  observability/        Grafana + Loki + Promtail stack
tests/                  397+ tests across 22 test files
```

## Admin API

All endpoints require an `Authorization: Bearer <okta_access_token>` header.
The token must be issued by the Admin UI's Okta OIDC app (see
[docs/OPERATIONS.md § Admin API Authentication](docs/OPERATIONS.md#admin-api-authentication)).
The legacy username/password login endpoint was removed in v0.15.x. Alternatively,
use the [Admin UI](#admin-ui) for a visual interface.

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/admin/agents` | List all agents |
| POST | `/api/admin/agents` | Create agent |
| GET | `/api/admin/agents/{id}` | Get agent |
| PUT | `/api/admin/agents/{id}` | Update agent |
| DELETE | `/api/admin/agents/{id}` | Delete agent |
| GET | `/api/admin/resources` | List all resources |
| POST | `/api/admin/resources` | Create resource |
| GET | `/api/admin/resources/{name}` | Get resource |
| PUT | `/api/admin/resources/{name}` | Update resource |
| DELETE | `/api/admin/resources/{name}` | Delete resource |
| POST | `/api/admin/agents/{id}/credentials/fetch-secret` | Fetch/generate client secret |
| POST | `/api/admin/agents/{id}/credentials/generate-keypair` | Generate RSA key pair |
| GET | `/api/admin/agents/{id}/credentials/status` | Check credential status |
| GET | `/api/admin/audit` | Query audit log |

## Development

### Running Tests

```bash
pip install -r requirements.txt
pytest tests/ -v
```

Tests use SQLite in-memory databases and mocked Okta validators -- no external services required. The admin API integration tests and PostgreSQL repository tests require `DATABASE_URL` to be set for full coverage.

### Adding a New Resource Example

1. Create `examples/02-your-system/` with a Dockerfile and MCP server
2. Add the service to `docker-compose.yml` on the `mcp-network`
3. Register the resource via the Admin UI or Admin API (see `docs/RESOURCE_SETUP_GUIDE.md`)

### Useful Commands

```bash
docker compose logs -f okta-agent-mcp-adapter    # Follow gateway logs
docker compose logs -f admin-ui                   # Follow admin UI logs
docker compose down                               # Stop everything
docker compose ps                                 # Check container status
LOG_LEVEL=DEBUG ./setup.sh                        # Rebuild with debug logging
```

### Observability Stack (optional)

```bash
docker compose -f docker-compose.yml \
  -f deploy/observability/docker-compose.observability.yml up -d
```

- **Grafana**: http://localhost:3000 (admin / admin)
- **Dashboard**: Dashboards > Okta MCP Adapter -- Audit & Observability
- **Pipeline**: adapter stdout -> Promtail -> Loki -> Grafana

See `deploy/observability/README.md` for setup details.

### Global Logout (Okta ITP)

- **Global Logout (Okta ITP)** — the adapter accepts Okta Universal Logout calls to revoke a user's tokens and sessions. See [docs/GLOBAL_LOGOUT_CONFIGURATION.md](docs/GLOBAL_LOGOUT_CONFIGURATION.md).

## Troubleshooting

### Admin UI won't load or shows login errors

- Verify `ADMIN_UI_OKTA_DOMAIN`, `ADMIN_UI_OKTA_CLIENT_ID`, and `ADMIN_UI_OKTA_CLIENT_SECRET` are set correctly in `.env`
- Confirm the sign-in redirect URI in Okta matches exactly: `http://localhost:3001/api/auth/callback/okta`
- Ensure `ADMIN_UI_NEXTAUTH_SECRET` is a valid random string (generate with `openssl rand -base64 32`)
- Check Admin UI logs: `docker compose logs admin-ui`

### "Agent not found" error

- Verify the `X-MCP-Agent` header matches an agent ID in the database
- Use the Admin UI to check agents, or call `GET /api/admin/agents`
- Confirm the agent is `enabled: true`

### "Authorization denied" error

- Check the resource name is in the agent's `resource_access` list
- Verify the resource exists via the Admin UI or `GET /api/admin/resources`

### JWT validation fails

- Verify `OKTA_DOMAIN` matches the token issuer
- Check the agent's `client_id` is in the allowed audiences list
- Enable `LOG_LEVEL=DEBUG` and check JWKS cache behavior

### Token exchange fails

- Verify the agent's `private_key` is valid JWK format
- Check `target_authorization_server` is correct on the resource
- Verify the agent's OAuth app has token exchange grant in Okta

### Claude Code "Connection failed" or "No client info found"

- The gateway supports DCR -- clients can self-register at `/.well-known/oauth/registration`
- Alternatively, use `claude mcp add --client-id <id> --client-secret` to provide credentials
- Pass secret via `MCP_CLIENT_SECRET` env var to avoid corruption
- Verify with: `claude mcp get okta-gateway` (should show client_id)

### Claude Code shows 0 tools after connecting

- Check the unified MCP handler: `POST /` with `tools/list`
- Verify the agent's `resource_access` list includes the resource name
- Check the resource is reachable from the gateway container
- Enable `LOG_LEVEL=DEBUG` and look for tool discovery logs

### "invalid_client_secret" in Okta syslog

- The BFF token proxy must pass the Authorization: Basic header unchanged
- Re-register with `MCP_CLIENT_SECRET` env var (interactive prompt can corrupt the value)

### CIMD resolution fails

- Check the client_id URL is reachable from the gateway
- Verify the CIMD document's `client_id` field matches the URL
- Check `CIMD_TRUSTED_DOMAINS` if using allowlist mode
- SSRF protection blocks private IP ranges by default

### "exec format error" on container startup

- Change `DOCKER_PLATFORM` in `.env` to match your host architecture
- Apple Silicon (M1/M2/M3): use `linux/arm64`
- Intel/AMD: use `linux/amd64`

### Import errors (local dev)

- Run `pip install -r requirements.txt --force-reinstall`
- Ensure Python 3.10+ is being used

## License

Apache 2.0

This is a productionized prototype for evaluation. Customer-specific versions of this prototype will be leveraged for production.
