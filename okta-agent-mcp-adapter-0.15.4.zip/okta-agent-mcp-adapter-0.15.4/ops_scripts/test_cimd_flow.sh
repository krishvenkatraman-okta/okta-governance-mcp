#!/usr/bin/env bash
set -euo pipefail

# ============================================================
# test_cimd_flow.sh — Test the CIMD OAuth flow end-to-end
# ============================================================
#
# Prerequisites:
#   1. Gateway running with CIMD support (docker compose up -d)
#   2. CIMD test server running (python ops_scripts/cimd_test_server.py)
#   3. RELAY_OKTA_CLIENT_ID and RELAY_OKTA_CLIENT_SECRET set in .env
#
# Flow:
#   1. Verify gateway metadata advertises CIMD support
#   2. Verify CIMD document is fetchable
#   3. Open browser to gateway's /oauth/authorize with CIMD client_id
#   4. Gateway fetches CIMD doc, starts relay, redirects to Okta
#   5. User authenticates at Okta
#   6. Okta redirects to gateway /oauth/callback
#   7. Gateway issues gateway code, redirects to CIMD client's callback
#   8. User exchanges gateway code for tokens via gateway token endpoint

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
CYAN='\033[0;36m'
BOLD='\033[1m'
NC='\033[0m'

GATEWAY_URL="${GATEWAY_BASE_URL:-http://localhost:8000}"
CIMD_PORT="${CIMD_PORT:-9876}"
# CIMD hostname: use host.docker.internal so Docker gateway can reach it
CIMD_HOSTNAME="${CIMD_HOSTNAME:-host.docker.internal}"
CIMD_CLIENT_ID="http://${CIMD_HOSTNAME}:${CIMD_PORT}/oauth.json"
# Redirect URI uses localhost (browser runs on host)
CIMD_REDIRECT_URI="http://localhost:${CIMD_PORT}/callback"

info()  { echo -e "${CYAN}→${NC} $*"; }
ok()    { echo -e "${GREEN}✓${NC} $*"; }
fail()  { echo -e "${RED}✗${NC} $*"; }

echo ""
echo -e "${BOLD}CIMD OAuth Flow — End-to-End Test${NC}"
echo "============================================"
echo ""

# ------------------------------------------------------------------
# Step 1: Check gateway metadata
# ------------------------------------------------------------------
info "Checking gateway OAuth metadata..."

METADATA=$(curl -sf "${GATEWAY_URL}/.well-known/oauth-authorization-server" 2>/dev/null || true)
if [ -z "$METADATA" ]; then
    fail "Gateway not responding at ${GATEWAY_URL}"
    echo "  Make sure the gateway is running: docker compose up -d"
    exit 1
fi

CIMD_SUPPORTED=$(echo "$METADATA" | python3 -c "import sys,json; d=json.load(sys.stdin); print(d.get('client_id_metadata_document_supported', False))" 2>/dev/null || echo "False")
NONE_AUTH=$(echo "$METADATA" | python3 -c "import sys,json; d=json.load(sys.stdin); print('none' in d.get('token_endpoint_auth_methods_supported', []))" 2>/dev/null || echo "False")
AUTH_ENDPOINT=$(echo "$METADATA" | python3 -c "import sys,json; print(json.load(sys.stdin)['authorization_endpoint'])" 2>/dev/null || echo "")

if [ "$CIMD_SUPPORTED" = "True" ]; then
    ok "Gateway advertises client_id_metadata_document_supported: true"
else
    fail "Gateway does NOT advertise CIMD support"
    echo "  Rebuild: docker compose build okta-agent-mcp-adapter && docker compose up -d"
    exit 1
fi

if [ "$NONE_AUTH" = "True" ]; then
    ok "Gateway supports token_endpoint_auth_method: none"
else
    fail "Gateway does NOT advertise 'none' auth method"
    exit 1
fi

if echo "$AUTH_ENDPOINT" | grep -q "/oauth/authorize"; then
    ok "Authorization endpoint: ${AUTH_ENDPOINT}"
else
    fail "Authorization endpoint should point to gateway /oauth/authorize, got: ${AUTH_ENDPOINT}"
    echo "  Rebuild: docker compose build okta-agent-mcp-adapter && docker compose up -d"
    exit 1
fi

# ------------------------------------------------------------------
# Step 2: Check CIMD document server
# ------------------------------------------------------------------
info "Checking CIMD document server..."

# Fetch from localhost (host perspective)
LOCAL_CIMD_URL="http://localhost:${CIMD_PORT}/oauth.json"
CIMD_DOC=$(curl -sf "${LOCAL_CIMD_URL}" 2>/dev/null || true)
if [ -z "$CIMD_DOC" ]; then
    fail "CIMD document not available at ${LOCAL_CIMD_URL}"
    echo ""
    echo "  Start the test server in another terminal:"
    echo "    python ops_scripts/cimd_test_server.py --port ${CIMD_PORT}"
    exit 1
fi

DOC_CLIENT_ID=$(echo "$CIMD_DOC" | python3 -c "import sys,json; print(json.load(sys.stdin)['client_id'])" 2>/dev/null || echo "")
if [ "$DOC_CLIENT_ID" = "$CIMD_CLIENT_ID" ]; then
    ok "CIMD document valid (client_id = ${DOC_CLIENT_ID})"
else
    fail "CIMD document client_id mismatch"
    echo "  Expected: ${CIMD_CLIENT_ID}"
    echo "  Got:      ${DOC_CLIENT_ID}"
    echo "  Make sure the CIMD server is using --hostname ${CIMD_HOSTNAME}"
    exit 1
fi

DOC_NAME=$(echo "$CIMD_DOC" | python3 -c "import sys,json; print(json.load(sys.stdin)['client_name'])" 2>/dev/null)
DOC_REDIRECT=$(echo "$CIMD_DOC" | python3 -c "import sys,json; print(json.load(sys.stdin)['redirect_uris'][0])" 2>/dev/null)
ok "Client: ${DOC_NAME}"
ok "Redirect URI: ${DOC_REDIRECT}"

# ------------------------------------------------------------------
# Step 3: Check relay app configuration
# ------------------------------------------------------------------
info "Checking relay app configuration..."

if [ -f .env ]; then
    set +u
    set -a
    eval "$(grep -v '^\s*#' .env | grep -v '^\s*$')"
    set +a
    set -u
fi

RELAY_ID="${RELAY_OKTA_CLIENT_ID:-}"
if [ -z "$RELAY_ID" ]; then
    fail "RELAY_OKTA_CLIENT_ID is not set in .env"
    echo ""
    echo "  Create a relay OIDC app in Okta:"
    echo "    1. Applications > Create App Integration > OIDC > Web Application"
    echo "    2. Name: 'MCP Gateway Relay'"
    echo "    3. Grant types: Authorization Code, Refresh Token"
    echo "    4. Redirect URI: ${GATEWAY_URL}/oauth/callback"
    echo "    5. Assign to your users"
    echo "    6. Set RELAY_OKTA_CLIENT_ID and RELAY_OKTA_CLIENT_SECRET in .env"
    echo "    7. Rebuild: docker compose build okta-agent-mcp-adapter && docker compose up -d"
    exit 1
fi
ok "Relay client_id: ${RELAY_ID}"

# ------------------------------------------------------------------
# Step 4: Build the authorization URL and open browser
# ------------------------------------------------------------------
echo ""
info "Building authorization URL..."

ENCODED_CLIENT_ID=$(python3 -c "from urllib.parse import quote; print(quote('${CIMD_CLIENT_ID}', safe=''))")
ENCODED_REDIRECT=$(python3 -c "from urllib.parse import quote; print(quote('${DOC_REDIRECT}', safe=''))")
STATE="cimd_test_$(date +%s)"

AUTHORIZE_URL="${AUTH_ENDPOINT}?client_id=${ENCODED_CLIENT_ID}&redirect_uri=${ENCODED_REDIRECT}&response_type=code&scope=openid+offline_access&state=${STATE}"

echo ""
echo -e "${BOLD}CIMD Flow:${NC}"
echo ""
echo "  1. Browser → gateway /oauth/authorize"
echo "     client_id = ${CIMD_CLIENT_ID}"
echo "  2. Gateway fetches CIMD doc, validates, starts relay"
echo "  3. Gateway → Okta /authorize (relay app: ${RELAY_ID})"
echo "  4. User authenticates at Okta"
echo "  5. Okta → gateway /oauth/callback"
echo "  6. Gateway issues code → redirects to ${DOC_REDIRECT}"
echo "  7. Exchange code at gateway /oauth2/v1/token"
echo ""
echo -e "${BOLD}After authenticating, exchange the code:${NC}"
echo ""
echo "  curl -s -X POST ${GATEWAY_URL}/oauth2/v1/token \\"
echo "    -H 'Content-Type: application/x-www-form-urlencoded' \\"
echo "    -d 'grant_type=authorization_code' \\"
echo "    -d 'code=<CODE_FROM_CALLBACK>' \\"
echo "    -d 'client_id=${CIMD_CLIENT_ID}' | python3 -m json.tool"
echo ""

# Try to open in browser
if command -v open &>/dev/null; then
    echo -e "${CYAN}Opening browser...${NC}"
    open "${AUTHORIZE_URL}"
elif command -v xdg-open &>/dev/null; then
    xdg-open "${AUTHORIZE_URL}"
else
    echo -e "${BOLD}Open this URL in your browser:${NC}"
    echo "  ${AUTHORIZE_URL}"
fi
