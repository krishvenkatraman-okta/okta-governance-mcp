#!/usr/bin/env python3
"""
Simulate Okta Event Hook calls for local testing.

Usage:
  # Simulate agent activation event
  python ops_scripts/simulate_okta_event_hook.py --event agent.activate --agent-id agtXXXXXX

  # Simulate agent deactivation
  python ops_scripts/simulate_okta_event_hook.py --event agent.deactivate --agent-id agtXXXXXX

  # Simulate managed connection update
  python ops_scripts/simulate_okta_event_hook.py --event connection.update --agent-id agtXXXXXX

  # Simulate verification handshake
  python ops_scripts/simulate_okta_event_hook.py --verify

  # Custom adapter URL (default: http://localhost:8000)
  python ops_scripts/simulate_okta_event_hook.py --event agent.activate --agent-id agtXXXXXX --url http://localhost:8000

  # Custom shared key (default: reads from OKTA_EVENT_HOOK_SECRET env var)
  python ops_scripts/simulate_okta_event_hook.py --event agent.activate --agent-id agtXXXXXX --secret "my-shared-key"
"""

import argparse
import json
import os
import sys
from datetime import datetime, timezone

import requests


EVENT_TYPE_MAP = {
    "agent.activate": "ai_agent.lifecycle.activate",
    "agent.deactivate": "ai_agent.lifecycle.deactivate",
    "agent.delete": "ai_agent.lifecycle.delete",
    "connection.update": "ai_agent.connection.update",
    "connection.create": "ai_agent.connection.create",
    "connection.delete": "ai_agent.connection.delete",
}


def build_event_payload(event_type: str, agent_id: str) -> dict:
    """Build a realistic Okta Event Hook payload."""
    okta_event_type = EVENT_TYPE_MAP.get(event_type, event_type)

    return {
        "data": {
            "events": [
                {
                    "uuid": f"sim-{datetime.now(timezone.utc).strftime('%Y%m%d%H%M%S')}",
                    "published": datetime.now(timezone.utc).isoformat(),
                    "eventType": okta_event_type,
                    "displayMessage": f"Simulated {event_type} event for {agent_id}",
                    "actor": {
                        "id": "00u_simulator",
                        "type": "User",
                        "displayName": "Event Hook Simulator",
                    },
                    "target": [
                        {
                            "id": agent_id,
                            "type": "AI_AGENT",
                            "alternateId": f"simulated-{agent_id}",
                            "displayName": f"Agent {agent_id}",
                        }
                    ],
                }
            ]
        }
    }


def simulate_verification(url: str) -> None:
    """Simulate the Okta verification handshake."""
    challenge = f"test-challenge-{int(datetime.now(timezone.utc).timestamp())}"
    print(f"Sending verification challenge: {challenge}")
    resp = requests.get(
        f"{url}/api/hooks/okta/events",
        headers={"x-okta-verification-challenge": challenge},
    )
    print(f"Status: {resp.status_code}")
    print(f"Response: {json.dumps(resp.json(), indent=2)}")
    if resp.status_code == 200 and resp.json().get("verification") == challenge:
        print("\nVerification handshake successful")
    else:
        print("\nVerification failed")
        sys.exit(1)


def simulate_event(url: str, secret: str, event_type: str, agent_id: str) -> None:
    """Send a simulated event hook POST."""
    payload = build_event_payload(event_type, agent_id)
    print(f"Sending {event_type} event for agent {agent_id}...")
    print(f"Payload: {json.dumps(payload, indent=2)}")

    resp = requests.post(
        f"{url}/api/hooks/okta/events",
        json=payload,
        headers={
            "Content-Type": "application/json",
            "Authorization": secret,
        },
    )
    print(f"\nStatus: {resp.status_code}")
    print(json.dumps(resp.json(), indent=2))

    if resp.status_code == 200:
        print(f"\nEvent delivered successfully")
    else:
        print(f"\nEvent delivery failed")
        sys.exit(1)


def main():
    parser = argparse.ArgumentParser(description="Simulate Okta Event Hook calls")
    parser.add_argument(
        "--verify", action="store_true", help="Simulate verification handshake"
    )
    parser.add_argument(
        "--event",
        choices=list(EVENT_TYPE_MAP.keys()),
        help="Event type to simulate",
    )
    parser.add_argument(
        "--agent-id", help="Okta AI Agent ID (e.g., agtXXXXXX)"
    )
    parser.add_argument(
        "--url",
        default="http://localhost:8000",
        help="Adapter base URL (default: http://localhost:8000)",
    )
    parser.add_argument(
        "--secret",
        default=os.getenv("OKTA_EVENT_HOOK_SECRET", ""),
        help="Shared key (default: OKTA_EVENT_HOOK_SECRET env var)",
    )

    args = parser.parse_args()

    if args.verify:
        simulate_verification(args.url)
    elif args.event:
        if not args.agent_id:
            print("ERROR: --agent-id required with --event")
            sys.exit(1)
        if not args.secret:
            print("ERROR: --secret or OKTA_EVENT_HOOK_SECRET env var required")
            sys.exit(1)
        simulate_event(args.url, args.secret, args.event, args.agent_id)
    else:
        parser.print_help()


if __name__ == "__main__":
    main()
