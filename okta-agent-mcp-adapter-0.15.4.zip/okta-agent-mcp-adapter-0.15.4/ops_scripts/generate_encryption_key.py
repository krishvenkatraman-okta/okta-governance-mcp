#!/usr/bin/env python3
"""
Generate a new encryption key for the gateway.

This script generates a cryptographically secure 32-byte (256-bit) key
suitable for AES-256 encryption.

Usage:
    python ops_scripts/generate_encryption_key.py

The generated key should be added to your .env file or environment variables:
    ENCRYPTION_KEY=<generated_key>

IMPORTANT: Keep this key secure!
- Store it in a secure secrets manager (AWS Secrets Manager, Azure Key Vault, etc.)
- Never commit it to version control
- Loss of this key means loss of all encrypted data
- Rotation requires re-encrypting all data with the new key
"""

import sys
import os

# Add parent directory to path
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from okta_agent_proxy.crypto.encryption import EncryptionService

if __name__ == "__main__":
    key = EncryptionService.generate_key()

    print("=" * 80)
    print("🔐 AES-256 Encryption Key Generated")
    print("=" * 80)
    print()
    print(f"ENCRYPTION_KEY={key}")
    print()
    print("=" * 80)
    print("📋 Next Steps:")
    print("=" * 80)
    print()
    print("1. Add this key to your .env file:")
    print(f"   echo 'ENCRYPTION_KEY={key}' >> .env")
    print()
    print("2. Or set it as an environment variable:")
    print(f"   export ENCRYPTION_KEY={key}")
    print()
    print("3. For production, store it in a secrets manager:")
    print("   - AWS Secrets Manager")
    print("   - Azure Key Vault")
    print("   - HashiCorp Vault")
    print("   - Google Cloud Secret Manager")
    print()
    print("=" * 80)
    print("⚠️  SECURITY WARNINGS:")
    print("=" * 80)
    print()
    print("• NEVER commit this key to version control")
    print("• Keep secure backups of this key")
    print("• Loss of this key = loss of ALL encrypted data")
    print("• Key rotation requires re-encrypting all data")
    print()
    print("=" * 80)
