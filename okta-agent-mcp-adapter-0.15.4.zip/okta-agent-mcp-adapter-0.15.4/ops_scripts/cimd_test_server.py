#!/usr/bin/env python3
"""
Simple HTTP server that hosts a CIMD (Client ID Metadata Document).

Used for testing the CIMD flow locally. Serves a JSON document at
http://<hostname>:<port>/oauth.json that acts as a URL-based client_id.

When running with Docker, use --hostname host.docker.internal so the
gateway container can fetch the document. The redirect_uri still uses
localhost since the browser runs on the host.

Usage:
    # For Docker-based gateway (default):
    python ops_scripts/cimd_test_server.py

    # For locally-run gateway:
    python ops_scripts/cimd_test_server.py --hostname localhost

The server also handles the OAuth callback and displays the authorization
code received from the gateway.
"""

import argparse
import json
import sys
import signal
from http.server import HTTPServer, BaseHTTPRequestHandler
from urllib.parse import urlparse, parse_qs


class CIMDHandler(BaseHTTPRequestHandler):
    """Serves CIMD document and handles OAuth callback."""

    port = 9876
    hostname = "host.docker.internal"

    def do_GET(self):
        parsed = urlparse(self.path)

        if parsed.path == "/oauth.json":
            self._serve_cimd()
        elif parsed.path == "/callback":
            self._handle_callback(parsed)
        else:
            self.send_response(404)
            self.end_headers()
            self.wfile.write(b"Not found\n")

    def _serve_cimd(self):
        """Serve the CIMD metadata document."""
        doc = {
            "client_id": f"http://{self.hostname}:{self.port}/oauth.json",
            "client_name": "CIMD Test Client",
            "redirect_uris": [
                f"http://localhost:{self.port}/callback",
                "http://127.0.0.1/callback",
                "https://vscode.dev/redirect",
            ],
            "grant_types": ["authorization_code"],
            "response_types": ["code"],
            "token_endpoint_auth_method": "none",
        }
        body = json.dumps(doc, indent=2).encode()
        self.send_response(200)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def _handle_callback(self, parsed):
        """Handle the OAuth callback with the gateway authorization code."""
        params = parse_qs(parsed.query)
        code = params.get("code", [None])[0]
        state = params.get("state", [None])[0]
        error = params.get("error", [None])[0]

        if error:
            desc = params.get("error_description", [""])[0]
            print(f"\n{'='*60}")
            print(f"ERROR from gateway: {error}")
            print(f"Description: {desc}")
            print(f"{'='*60}\n")
            self.send_response(200)
            self.send_header("Content-Type", "text/html")
            self.end_headers()
            self.wfile.write(f"<h1>Error: {error}</h1><p>{desc}</p>".encode())
            return

        client_id = f"http://{self.hostname}:{self.port}/oauth.json"

        if code:
            print(f"\n{'='*60}")
            print(f"AUTHORIZATION CODE RECEIVED!")
            print(f"  code:  {code}")
            print(f"  state: {state}")
            print(f"{'='*60}")
            print(f"\nTo exchange for tokens, run:")
            print(f"  curl -s -X POST http://localhost:8000/oauth2/v1/token \\")
            print(f"    -H 'Content-Type: application/x-www-form-urlencoded' \\")
            print(f"    -d 'grant_type=authorization_code' \\")
            print(f"    -d 'code={code}' \\")
            print(f"    -d 'client_id={client_id}' | python3 -m json.tool")
            print()

        body = f"""<html>
<head><title>CIMD Test - Authorization Code Received</title></head>
<body style="font-family: sans-serif; max-width: 600px; margin: 40px auto; padding: 20px;">
<h1>Authorization Code Received</h1>
<p><strong>code:</strong> <code style="background:#f0f0f0;padding:2px 6px;">{code}</code></p>
<p><strong>state:</strong> <code style="background:#f0f0f0;padding:2px 6px;">{state}</code></p>
<hr>
<h2>Exchange for tokens:</h2>
<pre style="background:#f0f0f0;padding:12px;overflow-x:auto;">curl -s -X POST http://localhost:8000/oauth2/v1/token \\
  -H 'Content-Type: application/x-www-form-urlencoded' \\
  -d 'grant_type=authorization_code' \\
  -d 'code={code}' \\
  -d 'client_id={client_id}' | python3 -m json.tool</pre>
</body>
</html>""".encode()

        self.send_response(200)
        self.send_header("Content-Type", "text/html")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def log_message(self, format, *args):
        """Override to prefix log messages."""
        sys.stderr.write(f"[CIMD Server] {args[0]}\n")


def main():
    parser = argparse.ArgumentParser(description="CIMD test server")
    parser.add_argument(
        "--port", type=int, default=9876,
        help="Port to listen on (default: 9876)",
    )
    parser.add_argument(
        "--hostname", type=str, default="host.docker.internal",
        help="Hostname for the client_id URL (default: host.docker.internal for Docker). "
             "Use 'localhost' if running the gateway locally without Docker.",
    )
    args = parser.parse_args()

    CIMDHandler.port = args.port
    CIMDHandler.hostname = args.hostname

    server = HTTPServer(("0.0.0.0", args.port), CIMDHandler)

    def shutdown(sig, frame):
        print("\nShutting down...")
        server.shutdown()
        sys.exit(0)

    signal.signal(signal.SIGINT, shutdown)
    signal.signal(signal.SIGTERM, shutdown)

    client_id = f"http://{args.hostname}:{args.port}/oauth.json"
    print(f"CIMD Test Server running on http://0.0.0.0:{args.port}")
    print(f"  CIMD document:  {client_id}")
    print(f"  OAuth callback: http://localhost:{args.port}/callback")
    print()
    print(f"  client_id = {client_id}")
    print()
    if args.hostname == "host.docker.internal":
        print("  Using host.docker.internal for Docker networking.")
        print("  The gateway container will fetch the CIMD doc via this hostname.")
        print("  The browser redirect uses localhost (runs on the host).")
    print()
    print("Press Ctrl+C to stop.\n")

    server.serve_forever()


if __name__ == "__main__":
    main()
