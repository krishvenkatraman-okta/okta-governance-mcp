#!/usr/bin/env python3
"""
Generate a persistent RSA-2048 signing key for the adapter.

Outputs the private key as a single-line JWK JSON string suitable for
ADAPTER_SIGNING_KEY in .env.

Usage:
    python ops_scripts/generate_signing_key.py
    python ops_scripts/generate_signing_key.py --quiet   # JWK only, no decoration
"""

import argparse
import base64
import json
import sys
import uuid

from cryptography.hazmat.primitives.asymmetric import rsa


def _int_to_base64url(n: int) -> str:
    byte_length = (n.bit_length() + 7) // 8
    raw = n.to_bytes(byte_length, byteorder="big")
    return base64.urlsafe_b64encode(raw).rstrip(b"=").decode("ascii")


def generate_signing_key() -> dict:
    """Generate an RSA-2048 key pair and return as a JWK dict."""
    private_key = rsa.generate_private_key(public_exponent=65537, key_size=2048)
    pn = private_key.private_numbers()
    pub = pn.public_numbers

    return {
        "kty": "RSA",
        "use": "sig",
        "alg": "RS256",
        "kid": f"adapter-{uuid.uuid4().hex[:8]}",
        "n": _int_to_base64url(pub.n),
        "e": _int_to_base64url(pub.e),
        "d": _int_to_base64url(pn.d),
        "p": _int_to_base64url(pn.p),
        "q": _int_to_base64url(pn.q),
        "dp": _int_to_base64url(pn.dmp1),
        "dq": _int_to_base64url(pn.dmq1),
        "qi": _int_to_base64url(pn.iqmp),
    }


def main():
    parser = argparse.ArgumentParser(description="Generate adapter signing key (JWK)")
    parser.add_argument("--quiet", "-q", action="store_true", help="Output JWK JSON only")
    args = parser.parse_args()

    jwk = generate_signing_key()
    jwk_json = json.dumps(jwk, separators=(",", ":"))

    if args.quiet:
        print(jwk_json)
    else:
        print("=" * 70)
        print("RSA-2048 Adapter Signing Key (JWK)")
        print("=" * 70)
        print()
        print(f"kid: {jwk['kid']}")
        print()
        print("Add to .env:")
        print(f"  ADAPTER_SIGNING_KEY={jwk_json}")
        print()
        print("This key is used for:")
        print("  - Adapter CIMD identity (private_key_jwt)")
        print("  - JWKS endpoint at /oauth/jwks.json")
        print()
        print("IMPORTANT: Keep this key secure and do not commit to git.")
        print("=" * 70)


if __name__ == "__main__":
    main()
