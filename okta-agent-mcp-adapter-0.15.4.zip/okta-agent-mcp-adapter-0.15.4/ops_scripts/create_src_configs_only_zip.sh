#!/usr/bin/env bash
# ──────────────────────────────────────────────────────────────
# create_src_configs_only_zip.sh — Package source & configs for Claude Desktop
#
# Creates a zip containing all source code, configuration, tests, and
# documentation needed for Claude Desktop to assist with architecture
# design and feature recommendations. Excludes secrets, generated
# artifacts, and large binaries.
#
# Usage:
#   ./ops_scripts/create_src_configs_only_zip.sh
#
# Output: dist/src-configs-only.zip
# ──────────────────────────────────────────────────────────────
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
PROJECT_ROOT="$(cd "$SCRIPT_DIR/.." && pwd)"

DIST_DIR="$PROJECT_ROOT/dist"
ZIP_NAME="src-configs-only.zip"
ZIP_PATH="$DIST_DIR/$ZIP_NAME"

mkdir -p "$DIST_DIR"
rm -f "$ZIP_PATH"

echo "╔══════════════════════════════════════════════════╗"
echo "║  Source & Configs Only — Claude Desktop Package  ║"
echo "╠══════════════════════════════════════════════════╣"
echo "║  Output : dist/$ZIP_NAME"
echo "╚══════════════════════════════════════════════════╝"
echo ""

cd "$PROJECT_ROOT"

STAGING_DIR="$(mktemp -d)"
trap 'rm -rf "$STAGING_DIR"' EXIT

echo "→ Staging files from git tracked content..."
git archive --format=tar HEAD | tar -x -C "$STAGING_DIR"

echo "→ Removing secrets, large binaries, and generated artifacts..."

cd "$STAGING_DIR"

# ── Secrets & credentials ──
rm -f  .env
rm -rf keys/
rm -rf certs/

# ── Large binaries & build artifacts ──
rm -rf deploy/aws-ec2/dist/
rm -rf deploy/aws-ecs/dist/
rm -rf deploy/azure-aca/dist/
rm -rf deploy/azure-aks/dist/
rm -rf dist/

# ── Generated JS artifacts ──
rm -rf okta_agent_proxy_admin_ui/node_modules/
rm -rf okta_agent_proxy_admin_ui/.next/
rm -f  okta_agent_proxy_admin_ui/package-lock.json

# ── Runtime & generated files ──
rm -rf logs/
rm -rf reports/
rm -rf notebooks/

# ── Python caches ──
find . -type d -name "__pycache__" -exec rm -rf {} + 2>/dev/null || true
find . -name "*.pyc" -delete 2>/dev/null || true
rm -rf .pytest_cache/
rm -f  .coverage

# ── OS artifacts ──
find . -name ".DS_Store" -delete 2>/dev/null || true

echo "→ Creating zip archive..."

cd "$STAGING_DIR"
zip -r "$ZIP_PATH" . -x '*.DS_Store' > /dev/null

# ── Summary ──
FILE_COUNT=$(zipinfo -1 "$ZIP_PATH" | wc -l | tr -d ' ')
FILE_SIZE=$(du -h "$ZIP_PATH" | cut -f1)

echo ""
echo "Done — $ZIP_PATH"
echo "  Size  : $FILE_SIZE"
echo "  Files : $FILE_COUNT"
echo ""
echo "Included:"
echo "  • okta_agent_proxy/          — Gateway source code"
echo "  • okta_agent_proxy_admin_ui/ — Admin UI source (no node_modules)"
echo "  • tests/                     — Full test suite"
echo "  • docs/                      — All documentation"
echo "  • alembic/                   — Database migrations"
echo "  • scripts/                   — Utility scripts"
echo "  • examples/                  — Usage examples"
echo "  • .claude/                   — Claude Code agents & commands"
echo "  • .github/                   — CI/CD workflows"
echo "  • CLAUDE.md                  — Project instructions"
echo ""
echo "Excluded:"
echo "  • .env, keys/, certs/        — Secrets"
echo "  • deploy/aws-ec2/dist/       — Large release tarballs"
echo "  • deploy/aws-ecs/dist/       — Large release tarballs"
echo "  • deploy/azure-aca/dist/     — Large release tarballs"
echo "  • deploy/azure-aks/dist/     — Large release tarballs"
echo "  • node_modules/, .next/      — Generated JS artifacts"
echo "  • __pycache__/, reports/     — Caches & generated reports"
