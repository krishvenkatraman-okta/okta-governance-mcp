# Ops Scripts Directory

Operator utility scripts for the Okta Agent MCP Adapter. These are not needed at runtime — the only runtime script is `scripts/docker-entrypoint.sh`.

## Available Scripts

### 1. generate_encryption_key.py

Generate a secure AES-256 encryption key for storing sensitive data.

**Usage:**
```bash
python scripts/generate_encryption_key.py
```

**Output:**
```
============================================================
🔐 AES-256 Encryption Key Generated
============================================================

ENCRYPTION_KEY=<base64-encoded-32-byte-key>

============================================================
📋 Next Steps:
============================================================
1. Add this key to your .env file
2. Keep secure backups
3. Never commit to version control
============================================================
```

**Features:**
- Generates cryptographically secure 32-byte (256-bit) key
- Base64-encoded output
- Ready for ENCRYPTION_KEY environment variable
- Includes security warnings and best practices

---

### 2. migrate_config_to_db.py

Migrate configuration from YAML to PostgreSQL with encryption.

**Usage:**
```bash
# Basic migration
python scripts/migrate_config_to_db.py

# Dry run (preview only)
python scripts/migrate_config_to_db.py --dry-run

# Custom config path
python scripts/migrate_config_to_db.py --config path/to/config.yaml

# Custom database URL
python scripts/migrate_config_to_db.py --database-url postgresql://user:pass@host/db

# Verbose output
python scripts/migrate_config_to_db.py --verbose
```

**Features:**
- ✅ Validates YAML structure before migration
- ✅ Encrypts sensitive fields (AES-256-GCM)
- ✅ Idempotent (safe to run multiple times)
- ✅ Supports dry-run mode
- ✅ Transaction-safe (rollback on errors)
- ✅ Detailed progress reporting
- ✅ Creates normalized agent-backend access mappings

**What Gets Migrated:**
- Agents (with encrypted client_secret and private_key)
- Backends (with encrypted auth secrets)
- Agent-backend access control mappings

**Encrypted Fields:**
- Agent: `client_secret`, `private_key`
- Backend: `target_client_secret`, `api_key`, `password` (depending on auth_method)

**Environment Variables:**
- `DATABASE_URL` - PostgreSQL connection string (required)
- `ENCRYPTION_KEY` - Base64 encryption key (required)
- `ENCRYPTION_PASSWORD` - Alternative to ENCRYPTION_KEY (derives key)
- `CONFIG_PATH` - Default config file path (optional)

**Exit Codes:**
- `0` - Success
- `1` - Validation error or migration failure

---

### 3. test_migration.sh

Comprehensive test suite for the migration script.

**Usage:**
```bash
./scripts/test_migration.sh
```

**What It Tests:**
1. ✅ Configuration file exists
2. ✅ Test database creation
3. ✅ Alembic migrations
4. ✅ Dry-run mode
5. ✅ Actual migration
6. ✅ Data verification
7. ✅ Encryption verification
8. ✅ Idempotency (run twice)
9. ✅ Sample data display

**Requirements:**
- PostgreSQL installed locally
- `psql` command available
- `alembic` installed
- Valid `config/config.yaml`

**Test Database:**
- Name: `gateway_test_migration`
- User: `test_user`
- Password: `test_pass`
- Automatically created and cleaned up

---

### 4. admin_token.sh

Mint an Okta access token for the admin API using an Okta API Services app
(`client_credentials` + `private_key_jwt`) and export it as a shell variable:

```bash
export ADMIN_SERVICE_CLIENT_ID=0oaYourServiceAppClientId
export ADMIN_SERVICE_PRIVATE_KEY_FILE=~/.okta/service-app.jwk.json
export OKTA_DOMAIN=dev-XXXXX.okta.com

eval "$(./ops_scripts/admin_token.sh)"
curl -H "Authorization: Bearer $ADMIN_TOKEN" http://localhost:8000/api/admin/agents
```

The script refuses to emit the token when stdout is a TTY (prevents leaking
into shell history when `eval` is forgotten). The service app's `cid` must
be listed in the adapter's `ADMIN_API_SERVICE_CLIENT_IDS` env var.

See `docs/ADMIN_API_SERVICE_AUTH.md` for the full Okta + adapter setup.

---

### 5. run_gateway.sh (if exists)

Start the gateway with proper environment setup.

**Usage:**
```bash
./scripts/run_gateway.sh
```

Creates virtual environment, installs dependencies, and starts the gateway.

---

## Quick Reference

### Initial Setup

```bash
# 1. Generate encryption key
python scripts/generate_encryption_key.py

# 2. Add to .env
echo "ENCRYPTION_KEY=<generated-key>" >> .env

# 3. Set database URL
echo "DATABASE_URL=postgresql://user:pass@localhost:5432/gateway_db" >> .env
```

### Migration Workflow

```bash
# 1. Dry run (preview)
python scripts/migrate_config_to_db.py --dry-run

# 2. Apply migrations
alembic upgrade head

# 3. Run migration
python scripts/migrate_config_to_db.py

# 4. Verify
psql $DATABASE_URL -c "SELECT COUNT(*) FROM agents;"
```

### Testing

```bash
# Run comprehensive tests
./scripts/test_migration.sh

# Or manually test
python scripts/migrate_config_to_db.py --config config/test-config.yaml --dry-run
```

## Common Issues

### "No module named 'psycopg2'"

**Solution:**
```bash
pip install psycopg2-binary
```

### "Encryption key not configured"

**Solution:**
```bash
python scripts/generate_encryption_key.py
export ENCRYPTION_KEY=<generated-key>
```

### "Database connection failed"

**Solution:**
```bash
# Check PostgreSQL is running
docker-compose ps postgres

# Or for local install
pg_isready -h localhost -p 5432
```

### "Configuration validation failed"

**Solution:**
- Check `config.yaml` syntax
- Verify all required fields present
- Run with `--verbose` for details

## Security Best Practices

### Encryption Keys

1. **Generate Secure Keys:**
   ```bash
   python scripts/generate_encryption_key.py
   ```

2. **Never Commit Keys:**
   ```bash
   echo ".env" >> .gitignore
   echo "*.key" >> .gitignore
   ```

3. **Use Secrets Manager (Production):**
   ```bash
   # Example: AWS
   ENCRYPTION_KEY=$(aws secretsmanager get-secret-value \
     --secret-id okta-mcp-encryption \
     --query SecretString --output text)

   # Example: Azure
   ENCRYPTION_KEY=$(az keyvault secret show \
     --name encryption-key \
     --vault-name okta-mcp \
     --query value -o tsv)
   ```

4. **Backup Keys Securely:**
   - Store in multiple secure locations
   - Use encrypted backup storage
   - Document recovery procedures

### Migration Safety

1. **Always Dry-Run First:**
   ```bash
   python scripts/migrate_config_to_db.py --dry-run
   ```

2. **Backup Before Migration:**
   ```bash
   cp config/config.yaml config/config.yaml.backup
   pg_dump $DATABASE_URL > backup.sql
   ```

3. **Test in Staging:**
   - Run migration in staging environment first
   - Verify gateway works with PostgreSQL backend
   - Test admin API operations

4. **Monitor After Migration:**
   ```bash
   # Check audit logs
   psql $DATABASE_URL -c "SELECT * FROM audit_log ORDER BY changed_at DESC LIMIT 10;"

   # Verify encryption
   psql $DATABASE_URL -c "SELECT agent_name, private_key_encrypted IS NOT NULL FROM agents;"
   ```

## Development

### Adding New Scripts

1. Create script in `scripts/` directory
2. Make executable: `chmod +x scripts/your_script.sh`
3. Add documentation to this README
4. Test thoroughly before committing

### Script Template

```python
#!/usr/bin/env python3
"""
Script Description

Usage:
    python scripts/your_script.py [options]
"""

import sys
import os
import argparse

# Add parent directory to path
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

def main():
    parser = argparse.ArgumentParser(description='Your script description')
    parser.add_argument('--option', help='Option description')
    args = parser.parse_args()

    # Your code here
    print("Hello from your script!")

if __name__ == '__main__':
    main()
```

## Additional Resources

- [Operations Guide](../docs/OPERATIONS.md)
- [Main README](../README.md)
