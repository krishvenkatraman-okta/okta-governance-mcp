#!/usr/bin/env python3
"""
Okta Adapter Round-Trip Integration Test

Performs a complete end-to-end test against a real Okta tenant:

  1. Discovery    — fetch adapter metadata, verify BFF endpoints
  2. Admin API    — login, list agents/backends
  3. PKCE Login   — full OAuth 2.1 authorization code flow with PKCE
                    (opens browser, spins up localhost callback server)
  4. MCP Proxy    — send JSON-RPC requests through adapter to HR backend
  5. Backend Direct — call HR backend with PSK, bypassing adapter
  6. Negative Tests — verify adapter rejects bad tokens, wrong agents, bad paths

Prerequisites:
  - Adapter running (docker-compose up)
  - HR backend running (port 8001)
  - At least one agent registered in Okta + seeded in adapter DB
  - Agent's Okta OIDC app has redirect_uri: http://localhost:9999/callback

Usage:
  python scripts/round_trip_test.py

  # Override defaults via env vars:
  ADAPTER_URL=http://localhost:8000 \\
  AGENT_NAME=claude-code \\
  ADMIN_PASSWORD=change-me-in-production \\
  python scripts/round_trip_test.py

  # Skip browser login (supply token directly):
  OKTA_ID_TOKEN=eyJ... python scripts/round_trip_test.py

  # Skip stages:
  python scripts/round_trip_test.py --skip-oauth   # skip browser login
  python scripts/round_trip_test.py --skip-proxy    # skip MCP proxy tests
"""

import argparse
import base64
import hashlib
import http.server
import json
import os
import secrets
import sys
import threading
import time
import urllib.parse
import webbrowser
from dataclasses import dataclass, field
from typing import Optional, Dict, Any, List

try:
    import requests
except ImportError:
    print("ERROR: 'requests' package required. Install with: pip install requests")
    sys.exit(1)


# ============================================================================
# Constants
# ============================================================================

# MCP Streamable HTTP requires clients to accept both JSON and SSE
MCP_ACCEPT = "application/json, text/event-stream"


# ============================================================================
# Configuration
# ============================================================================

@dataclass
class TestConfig:
    adapter_url: str = "http://localhost:8000"
    hr_backend_url: str = "http://localhost:8001"
    agent_name: str = "claude-code"
    hr_psk: str = "demo-psk-secret-do-not-use-in-prod"
    callback_port: int = 9999
    callback_host: str = "localhost"
    timeout: int = 10

    # Populated at runtime
    client_id: Optional[str] = None
    okta_issuer: Optional[str] = None
    authorize_endpoint: Optional[str] = None
    token_endpoint: Optional[str] = None

    @property
    def redirect_uri(self) -> str:
        return f"http://{self.callback_host}:{self.callback_port}/callback"

    @classmethod
    def from_env(cls) -> "TestConfig":
        return cls(
            adapter_url=os.getenv("ADAPTER_URL", "http://localhost:8000"),
            hr_backend_url=os.getenv("HR_BACKEND_URL", "http://localhost:8001"),
            agent_name=os.getenv("AGENT_NAME", "claude-code"),
            hr_psk=os.getenv("HR_PSK_SECRET", "demo-psk-secret-do-not-use-in-prod"),
            callback_port=int(os.getenv("CALLBACK_PORT", "9999")),
        )


# ============================================================================
# Test Result Tracking
# ============================================================================

@dataclass
class TestResult:
    name: str
    stage: str
    passed: bool
    message: str = ""
    detail: Optional[str] = None


@dataclass
class TestSuite:
    results: List[TestResult] = field(default_factory=list)

    def record(self, name: str, stage: str, passed: bool, message: str = "", detail: str = None):
        self.results.append(TestResult(name, stage, passed, message, detail))
        icon = "✅" if passed else "❌"
        print(f"  {icon} {name}: {message}")
        if detail and not passed:
            for line in detail.strip().split("\n"):
                print(f"       {line}")

    @property
    def passed(self) -> int:
        return sum(1 for r in self.results if r.passed)

    @property
    def failed(self) -> int:
        return sum(1 for r in self.results if not r.passed)

    def section(self, name: str):
        print(f"\n{'='*60}")
        print(f"  {name}")
        print(f"{'='*60}")

    def summary(self):
        total = len(self.results)
        print(f"\n{'='*60}")
        print(f"  RESULTS: {self.passed}/{total} passed, {self.failed} failed")
        if self.failed:
            print(f"\n  Failed tests:")
            for r in self.results:
                if not r.passed:
                    print(f"    - [{r.stage}] {r.name}: {r.message}")
        print(f"{'='*60}")
        return self.failed == 0


# ============================================================================
# PKCE Helpers
# ============================================================================

def generate_pkce_pair():
    """Generate PKCE code_verifier and code_challenge (S256)."""
    verifier = secrets.token_urlsafe(32)
    digest = hashlib.sha256(verifier.encode("ascii")).digest()
    challenge = base64.urlsafe_b64encode(digest).rstrip(b"=").decode("ascii")
    return verifier, challenge


# ============================================================================
# Callback Server — captures the OAuth authorization code
# ============================================================================

class CallbackHandler(http.server.BaseHTTPRequestHandler):
    """Tiny HTTP handler that captures the OAuth callback and extracts the auth code."""

    auth_code = None
    state = None
    error = None

    def do_GET(self):
        parsed = urllib.parse.urlparse(self.path)
        params = urllib.parse.parse_qs(parsed.query)

        if parsed.path == "/callback":
            CallbackHandler.auth_code = params.get("code", [None])[0]
            CallbackHandler.state = params.get("state", [None])[0]
            CallbackHandler.error = params.get("error", [None])[0]

            if CallbackHandler.auth_code:
                body = (
                    "<html><body style='font-family:sans-serif;text-align:center;padding:60px'>"
                    "<h1>&#9989; Authorization Successful</h1>"
                    "<p>You can close this tab. The test script has captured the auth code.</p>"
                    "</body></html>"
                )
                self.send_response(200)
            else:
                error_desc = params.get("error_description", ["Unknown error"])[0]
                body = (
                    f"<html><body style='font-family:sans-serif;text-align:center;padding:60px'>"
                    f"<h1>&#10060; Authorization Failed</h1>"
                    f"<p>{CallbackHandler.error}: {error_desc}</p>"
                    f"</body></html>"
                )
                self.send_response(400)

            self.send_header("Content-Type", "text/html")
            self.end_headers()
            self.wfile.write(body.encode())
        else:
            self.send_response(404)
            self.end_headers()

    def log_message(self, format, *args):
        """Suppress noisy HTTP logs."""
        pass


def run_callback_server(port: int, timeout: int = 120) -> Optional[str]:
    """
    Start a temporary HTTP server to capture the OAuth callback.

    Returns the authorization code, or None on timeout/error.
    """
    CallbackHandler.auth_code = None
    CallbackHandler.state = None
    CallbackHandler.error = None

    server = http.server.HTTPServer(("localhost", port), CallbackHandler)
    server.timeout = timeout

    # Handle one request (the callback)
    server.handle_request()
    server.server_close()

    if CallbackHandler.error:
        print(f"    OAuth error: {CallbackHandler.error}")
        return None

    return CallbackHandler.auth_code


# ============================================================================
# Stage 1: Discovery
# ============================================================================

def test_discovery(cfg: TestConfig, suite: TestSuite):
    print("\n--- Stage 1: Health & Discovery ---")

    # Health
    try:
        r = requests.get(f"{cfg.adapter_url}/health", timeout=cfg.timeout)
        data = r.json()
        healthy = data.get("status") == "healthy"
        agents = data.get("agents_loaded", 0)
        backends = data.get("backends_loaded", 0)
        suite.record(
            "Health check", "discovery", healthy and agents > 0 and backends > 0,
            f"status={data.get('status')}, agents={agents}, backends={backends}",
        )
    except Exception as e:
        suite.record("Health check", "discovery", False, f"Connection failed: {e}")
        return False  # Can't continue without adapter

    # Protected resource metadata
    try:
        r = requests.get(
            f"{cfg.adapter_url}/.well-known/oauth-protected-resource", timeout=cfg.timeout
        )
        data = r.json()
        has_auth_servers = bool(data.get("authorization_servers"))
        suite.record(
            "Protected resource metadata", "discovery", has_auth_servers,
            f"authorization_servers present: {has_auth_servers}",
        )
    except Exception as e:
        suite.record("Protected resource metadata", "discovery", False, str(e))

    # Authorization server metadata (BFF)
    try:
        r = requests.get(
            f"{cfg.adapter_url}/.well-known/oauth-authorization-server", timeout=cfg.timeout
        )
        data = r.json()
        token_ep = data.get("token_endpoint", "")
        auth_ep = data.get("authorization_endpoint", "")
        issuer = data.get("issuer", "")

        # BFF check: token_endpoint should point to adapter, not Okta
        bff_correct = cfg.adapter_url in token_ep
        suite.record(
            "BFF token endpoint", "discovery", bff_correct,
            f"token_endpoint={token_ep}",
            None if bff_correct else f"Expected adapter URL in token_endpoint, got: {token_ep}",
        )

        # Store for later use
        cfg.token_endpoint = token_ep
        cfg.authorize_endpoint = auth_ep
        cfg.okta_issuer = issuer
    except Exception as e:
        suite.record("Auth server metadata", "discovery", False, str(e))

    return True


# ============================================================================
# Stage 2: Admin API
# ============================================================================

def test_admin_api(cfg: TestConfig, suite: TestSuite) -> Optional[str]:
    print("\n--- Stage 2: Admin API ---")

    # Password login was removed in v0.15.x. Require an Okta access token
    # from the env (obtainable by signing in to the Admin UI and copying it
    # out of the browser devtools, or via the okta CLI).
    admin_token = os.getenv("OKTA_ADMIN_TOKEN", "").strip()
    if not admin_token:
        suite.record(
            "Admin auth", "admin", False,
            "OKTA_ADMIN_TOKEN env var is not set",
            "Obtain an access token from your Admin UI Okta OIDC app and export it:\n"
            "    export OKTA_ADMIN_TOKEN=\"<token>\"\n"
            "Then re-run this script.",
        )
        return None

    # Probe the admin API with the token; if it fails, stop here with a clear
    # error instead of hammering downstream endpoints.
    try:
        probe = requests.get(
            f"{cfg.adapter_url}/api/admin/agents",
            headers={"Authorization": f"Bearer {admin_token}"},
            timeout=cfg.timeout,
        )
    except Exception as e:
        suite.record("Admin auth", "admin", False, str(e))
        return None

    if probe.status_code != 200:
        suite.record(
            "Admin auth", "admin", False,
            f"status={probe.status_code}, token=rejected",
            "The Okta access token was rejected. Make sure it is a fresh "
            "token issued by the Admin UI's Okta OIDC app and has not expired.",
        )
        return None

    suite.record("Admin auth", "admin", True, "status=200 (Okta OAuth token accepted)")
    headers = {"Authorization": f"Bearer {admin_token}"}

    # List agents
    try:
        r = requests.get(f"{cfg.adapter_url}/api/admin/agents", headers=headers, timeout=cfg.timeout)
        data = r.json()
        agents = data.get("agents", [])
        agent_names = [a.get("agent_name") or a.get("agent_id") for a in agents]
        has_target_agent = cfg.agent_name in agent_names
        suite.record(
            "List agents", "admin", has_target_agent,
            f"agents={agent_names}",
            None if has_target_agent else f"Agent '{cfg.agent_name}' not found in {agent_names}",
        )

        # Extract client_id for the target agent
        for a in agents:
            if (a.get("agent_name") or a.get("agent_id")) == cfg.agent_name:
                cfg.client_id = a.get("client_id")
                print(f"    Agent '{cfg.agent_name}' client_id: {cfg.client_id}")
                break
    except Exception as e:
        suite.record("List agents", "admin", False, str(e))

    # List backends
    try:
        r = requests.get(f"{cfg.adapter_url}/api/admin/backends", headers=headers, timeout=cfg.timeout)
        data = r.json()
        backends = data.get("backends", [])
        backend_names = [b.get("name") for b in backends]
        has_hr = "hr-system" in backend_names
        suite.record(
            "List backends", "admin", has_hr,
            f"backends={backend_names}",
            None if has_hr else "'hr-system' not found in backends",
        )
    except Exception as e:
        suite.record("List backends", "admin", False, str(e))

    return admin_token


# ============================================================================
# Stage 3: OAuth PKCE Flow
# ============================================================================

def test_oauth_pkce(cfg: TestConfig, suite: TestSuite) -> Optional[str]:
    print("\n--- Stage 3: OAuth PKCE Flow (Browser Login) ---")

    if not cfg.client_id:
        suite.record("PKCE setup", "oauth", False, "No client_id — admin API must run first")
        return None

    if not cfg.authorize_endpoint:
        suite.record("PKCE setup", "oauth", False, "No authorize_endpoint — discovery must run first")
        return None

    # Generate PKCE pair
    code_verifier, code_challenge = generate_pkce_pair()
    state = secrets.token_urlsafe(16)

    # Build authorization URL
    auth_params = {
        "response_type": "code",
        "client_id": cfg.client_id,
        "redirect_uri": cfg.redirect_uri,
        "scope": "openid profile email offline_access",
        "state": state,
        "code_challenge": code_challenge,
        "code_challenge_method": "S256",
    }
    auth_url = cfg.authorize_endpoint.split("?")[0] + "?" + urllib.parse.urlencode(auth_params)

    print(f"    Opening browser for Okta login...")
    print(f"    Redirect URI: {cfg.redirect_uri}")
    print(f"    (Waiting up to 120s for login...)")

    # Start callback server in background thread
    auth_code_result = [None]

    def capture_callback():
        auth_code_result[0] = run_callback_server(cfg.callback_port, timeout=120)

    callback_thread = threading.Thread(target=capture_callback, daemon=True)
    callback_thread.start()

    # Give server a moment to bind
    time.sleep(0.5)

    # Open browser
    webbrowser.open(auth_url)

    # Wait for callback
    callback_thread.join(timeout=125)
    auth_code = auth_code_result[0]

    if not auth_code:
        suite.record(
            "Browser login", "oauth", False,
            "No authorization code received (timeout or error)",
        )
        return None

    suite.record("Browser login", "oauth", True, f"Authorization code received ({len(auth_code)} chars)")

    # Exchange auth code at adapter's BFF token endpoint
    try:
        r = requests.post(
            cfg.token_endpoint,
            data={
                "grant_type": "authorization_code",
                "code": auth_code,
                "redirect_uri": cfg.redirect_uri,
                "client_id": cfg.client_id,
                "code_verifier": code_verifier,
            },
            headers={"Content-Type": "application/x-www-form-urlencoded"},
            timeout=cfg.timeout,
        )

        if r.status_code != 200:
            suite.record(
                "Token exchange (BFF)", "oauth", False,
                f"status={r.status_code}",
                r.text[:500],
            )
            return None

        token_data = r.json()
        id_token = token_data.get("access_token")  # Adapter returns ID token as access_token
        refresh_token = token_data.get("refresh_token")

        suite.record(
            "Token exchange (BFF)", "oauth",
            id_token is not None,
            f"id_token={'obtained' if id_token else 'MISSING'}, "
            f"refresh_token={'present' if refresh_token else 'absent'}",
        )

        # Decode token claims (no verification — just inspect)
        if id_token:
            try:
                parts = id_token.split(".")
                payload = json.loads(
                    base64.urlsafe_b64decode(parts[1] + "==").decode()
                )
                sub = payload.get("sub", "?")
                aud = payload.get("aud", "?")
                iss = payload.get("iss", "?")
                exp = payload.get("exp", 0)
                remaining = exp - int(time.time())
                suite.record(
                    "Token claims", "oauth", True,
                    f"sub={sub}, aud={aud}, expires_in={remaining}s",
                )
            except Exception as e:
                suite.record("Token claims", "oauth", False, f"Could not decode: {e}")

        return id_token

    except Exception as e:
        suite.record("Token exchange (BFF)", "oauth", False, str(e))
        return None


# ============================================================================
# Stage 4: MCP Proxy Requests
# ============================================================================

def test_mcp_proxy(cfg: TestConfig, suite: TestSuite, id_token: str):
    print("\n--- Stage 4: MCP Proxy (Full Round-Trip) ---")

    headers = {
        "Authorization": f"Bearer {id_token}",
        "X-MCP-Agent": cfg.agent_name,
        "Content-Type": "application/json",
        "Accept": MCP_ACCEPT,
    }

    # tools/list
    try:
        r = requests.post(
            f"{cfg.adapter_url}/hr",
            headers=headers,
            json={
                "jsonrpc": "2.0",
                "id": "rt-1",
                "method": "tools/list",
                "params": {},
            },
            timeout=cfg.timeout,
        )
        ok = r.status_code == 200
        body = r.text[:300]
        suite.record(
            "MCP tools/list via /hr", "proxy",
            ok,
            f"status={r.status_code}",
            None if ok else body,
        )
    except Exception as e:
        suite.record("MCP tools/list via /hr", "proxy", False, str(e))

    # tools/call — health_check
    try:
        r = requests.post(
            f"{cfg.adapter_url}/hr",
            headers=headers,
            json={
                "jsonrpc": "2.0",
                "id": "rt-2",
                "method": "tools/call",
                "params": {"name": "health_check", "arguments": {}},
            },
            timeout=cfg.timeout,
        )
        ok = r.status_code == 200
        suite.record(
            "MCP tools/call health_check", "proxy", ok,
            f"status={r.status_code}",
        )
    except Exception as e:
        suite.record("MCP tools/call health_check", "proxy", False, str(e))

    # tools/call — get_employee (if available)
    try:
        r = requests.post(
            f"{cfg.adapter_url}/employees",
            headers=headers,
            json={
                "jsonrpc": "2.0",
                "id": "rt-3",
                "method": "tools/call",
                "params": {"name": "get_employee", "arguments": {"employee_id": "EMP001"}},
            },
            timeout=cfg.timeout,
        )
        ok = r.status_code == 200
        suite.record(
            "MCP tools/call get_employee via /employees", "proxy", ok,
            f"status={r.status_code}",
        )
    except Exception as e:
        suite.record("MCP get_employee via /employees", "proxy", False, str(e))

    # --- Negative tests ---
    print("\n--- Stage 4b: Negative Tests ---")

    # No auth header
    try:
        r = requests.post(
            f"{cfg.adapter_url}/hr",
            headers={
                "Content-Type": "application/json",
                "Accept": MCP_ACCEPT,
            },
            json={"jsonrpc": "2.0", "id": "n-1", "method": "tools/list", "params": {}},
            timeout=cfg.timeout,
        )
        suite.record(
            "Reject missing auth", "proxy-negative",
            r.status_code == 401,
            f"status={r.status_code} (expected 401)",
        )
    except Exception as e:
        suite.record("Reject missing auth", "proxy-negative", False, str(e))

    # Invalid token
    try:
        r = requests.post(
            f"{cfg.adapter_url}/hr",
            headers={
                "Authorization": "Bearer invalid.token.here",
                "X-MCP-Agent": cfg.agent_name,
                "Content-Type": "application/json",
                "Accept": MCP_ACCEPT,
            },
            json={"jsonrpc": "2.0", "id": "n-2", "method": "tools/list", "params": {}},
            timeout=cfg.timeout,
        )
        suite.record(
            "Reject invalid token", "proxy-negative",
            r.status_code in (401, 403),
            f"status={r.status_code} (expected 401/403)",
        )
    except Exception as e:
        suite.record("Reject invalid token", "proxy-negative", False, str(e))

    # Unknown path
    try:
        r = requests.post(
            f"{cfg.adapter_url}/nonexistent-backend",
            headers=headers,
            json={"jsonrpc": "2.0", "id": "n-3", "method": "tools/list", "params": {}},
            timeout=cfg.timeout,
        )
        suite.record(
            "Reject unknown path", "proxy-negative",
            r.status_code in (404, 500),
            f"status={r.status_code} (expected 404)",
        )
    except Exception as e:
        suite.record("Reject unknown path", "proxy-negative", False, str(e))

    # ================================================================
    # Dual-Mode Routing Tests
    # ================================================================
    suite.section("Dual-Mode Routing")

    # Test 1: Unified endpoint returns namespaced tools
    tools = []
    try:
        r = requests.post(
            f"{cfg.adapter_url}/",
            headers=headers,
            json={"jsonrpc": "2.0", "id": "dm-1", "method": "tools/list", "params": {}},
            timeout=cfg.timeout,
        )
        data = r.json()
        tools = data.get("result", {}).get("tools", [])
        has_namespaced = any("__" in t.get("name", "") for t in tools)
        suite.record(
            "Unified: tools are namespaced", "dual-mode",
            has_namespaced,
            f"Found {len(tools)} tools, namespaced={has_namespaced}",
        )
    except Exception as e:
        suite.record("Unified: tools are namespaced", "dual-mode", False, str(e))

    # Test 2: Direct path returns non-namespaced tools
    # Derive backend name from the unified response
    backend_name = None
    direct_tools = []
    try:
        if tools:
            first_tool = tools[0].get("name", "")
            if "__" in first_tool:
                backend_name = first_tool.split("__")[0]

        if backend_name:
            r = requests.post(
                f"{cfg.adapter_url}/{backend_name}",
                headers=headers,
                json={"jsonrpc": "2.0", "id": "dm-2", "method": "tools/list", "params": {}},
                timeout=cfg.timeout,
            )
            data = r.json()
            direct_tools = data.get("result", {}).get("tools", [])
            no_namespace = all("__" not in t.get("name", "") for t in direct_tools)
            suite.record(
                "Direct: tools NOT namespaced", "dual-mode",
                no_namespace and len(direct_tools) > 0,
                f"Found {len(direct_tools)} tools at /{backend_name}, no_namespace={no_namespace}",
            )
        else:
            suite.record("Direct: tools NOT namespaced", "dual-mode", False, "No backend found from unified")
    except Exception as e:
        suite.record("Direct: tools NOT namespaced", "dual-mode", False, str(e))

    # Test 3: Both modes return the same tools for the same backend
    try:
        if backend_name and tools and direct_tools:
            unified_for_backend = sorted([
                t["name"].split("__", 1)[1]
                for t in tools
                if t["name"].startswith(f"{backend_name}__")
            ])
            direct_names = sorted([t["name"] for t in direct_tools])
            match = unified_for_backend == direct_names
            suite.record(
                "Both modes: same tools", "dual-mode",
                match,
                f"unified={unified_for_backend}, direct={direct_names}",
            )
        else:
            suite.record("Both modes: same tools", "dual-mode", False, "Insufficient data")
    except Exception as e:
        suite.record("Both modes: same tools", "dual-mode", False, str(e))


# ============================================================================
# Stage 5: Backend Direct
# ============================================================================

def test_backend_direct(cfg: TestConfig, suite: TestSuite):
    print("\n--- Stage 5: Backend Direct (PSK) ---")

    psk_headers = {
        "X-API-Key": cfg.hr_psk,
        "Content-Type": "application/json",
        "Accept": MCP_ACCEPT,
    }

    # Step 1: Initialize MCP session (required by Streamable HTTP transport)
    session_id = None
    try:
        r = requests.post(
            f"{cfg.hr_backend_url}/mcp",
            headers=psk_headers,
            json={
                "jsonrpc": "2.0", "id": "init-1",
                "method": "initialize",
                "params": {
                    "protocolVersion": "2024-11-05",
                    "capabilities": {},
                    "clientInfo": {"name": "round-trip-test", "version": "1.0.0"},
                },
            },
            timeout=cfg.timeout,
        )
        session_id = r.headers.get("mcp-session-id")
        ok = r.status_code == 200 and session_id is not None
        suite.record(
            "HR MCP initialize", "backend", ok,
            f"status={r.status_code}, session_id={'obtained' if session_id else 'MISSING'}",
        )
    except requests.ConnectionError:
        suite.record(
            "HR MCP initialize", "backend", False,
            f"Connection refused at {cfg.hr_backend_url} — is the HR server running?",
        )
        return
    except Exception as e:
        suite.record("HR MCP initialize", "backend", False, str(e))
        return

    if not session_id:
        suite.record("HR session", "backend", False, "Cannot continue without session ID")
        return

    # Add session ID to headers for subsequent calls
    session_headers = {**psk_headers, "Mcp-Session-Id": session_id}

    # Step 2: tools/list
    try:
        r = requests.post(
            f"{cfg.hr_backend_url}/mcp",
            headers=session_headers,
            json={"jsonrpc": "2.0", "id": 1, "method": "tools/list", "params": {}},
            timeout=cfg.timeout,
        )
        ok = r.status_code == 200
        suite.record(
            "HR tools/list direct", "backend", ok,
            f"status={r.status_code}",
        )
    except Exception as e:
        suite.record("HR tools/list direct", "backend", False, str(e))

    # Step 3: tools/call health_check
    try:
        r = requests.post(
            f"{cfg.hr_backend_url}/mcp",
            headers=session_headers,
            json={
                "jsonrpc": "2.0", "id": 2,
                "method": "tools/call",
                "params": {"name": "health_check", "arguments": {}},
            },
            timeout=cfg.timeout,
        )
        ok = r.status_code == 200
        suite.record("HR health_check direct", "backend", ok, f"status={r.status_code}")
    except Exception as e:
        suite.record("HR health_check direct", "backend", False, str(e))

    # Step 4: Wrong PSK — should fail (use fresh request, no session)
    try:
        r = requests.post(
            f"{cfg.hr_backend_url}/mcp",
            headers={**psk_headers, "X-API-Key": "wrong-key"},
            json={
                "jsonrpc": "2.0", "id": 3,
                "method": "initialize",
                "params": {
                    "protocolVersion": "2024-11-05",
                    "capabilities": {},
                    "clientInfo": {"name": "bad-client", "version": "1.0.0"},
                },
            },
            timeout=cfg.timeout,
        )
        suite.record(
            "HR rejects wrong PSK", "backend",
            r.status_code in (401, 403, 500),
            f"status={r.status_code} (expected non-200)",
        )
    except Exception as e:
        suite.record("HR rejects wrong PSK", "backend", False, str(e))


# ============================================================================
# Main
# ============================================================================

def main():
    parser = argparse.ArgumentParser(
        description="Okta Adapter Round-Trip Integration Test",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Environment variables:
  ADAPTER_URL        Adapter base URL (default: http://localhost:8000)
  HR_BACKEND_URL     HR backend URL (default: http://localhost:8001)
  AGENT_NAME         Agent to test with (default: claude-code)
  ADMIN_USERNAME     Admin API username (default: admin)
  ADMIN_PASSWORD     Admin API password (default: change-me-in-production)
  HR_PSK_SECRET      HR backend PSK (default: demo-psk-secret-do-not-use-in-prod)
  CALLBACK_PORT      Local callback port for OAuth (default: 9999)
  OKTA_ID_TOKEN      Pre-existing token (skips OAuth browser flow)
        """,
    )
    parser.add_argument("--skip-oauth", action="store_true", help="Skip OAuth browser login")
    parser.add_argument("--skip-proxy", action="store_true", help="Skip MCP proxy tests")
    parser.add_argument("--skip-backend", action="store_true", help="Skip backend direct tests")
    args = parser.parse_args()

    cfg = TestConfig.from_env()
    suite = TestSuite()

    print("=" * 60)
    print("  Okta Adapter Round-Trip Integration Test")
    print("=" * 60)
    print(f"  Adapter:   {cfg.adapter_url}")
    print(f"  Backend:   {cfg.hr_backend_url}")
    print(f"  Agent:     {cfg.agent_name}")
    print(f"  Callback:  {cfg.redirect_uri}")
    print()

    # Stage 1: Discovery
    adapter_up = test_discovery(cfg, suite)
    if not adapter_up:
        print("\n  Adapter is not reachable. Aborting.")
        suite.summary()
        sys.exit(1)

    # Stage 2: Admin API
    admin_token = test_admin_api(cfg, suite)

    # Stage 5: Backend Direct (run early — doesn't need Okta token)
    if not args.skip_backend:
        test_backend_direct(cfg, suite)

    # Stage 3: OAuth PKCE
    id_token = os.getenv("OKTA_ID_TOKEN")
    if id_token:
        print("\n--- Stage 3: OAuth (Using pre-supplied OKTA_ID_TOKEN) ---")
        suite.record("Pre-supplied token", "oauth", True, f"Token length: {len(id_token)}")
    elif not args.skip_oauth:
        id_token = test_oauth_pkce(cfg, suite)
    else:
        print("\n--- Stage 3: OAuth (Skipped) ---")

    # Stage 4: MCP Proxy
    if id_token and not args.skip_proxy:
        test_mcp_proxy(cfg, suite, id_token)
    elif not id_token:
        print("\n--- Stage 4: MCP Proxy (Skipped — no token) ---")
        suite.record("MCP proxy", "proxy", False, "No Okta token available — skipped")

    # Summary
    all_passed = suite.summary()
    sys.exit(0 if all_passed else 1)


if __name__ == "__main__":
    main()