#!/usr/bin/env bash
# ===========================================================================
# XAA Token Mapping Smoke Test
#
# Manual validation script for the full XAA flow with a live Okta org.
# Requires a running gateway + deploy backend + valid Okta user token.
#
# Usage:
#   USER_TOKEN="eyJ..." ./ops_scripts/test_xaa_smoke.sh
#
# Optional:
#   GATEWAY_URL=http://localhost:8000  (default)
#   AGENT_HEADER=claude-code           (default)
#   VERBOSE=1                          (show full JSON responses)
# ===========================================================================
set -euo pipefail

GATEWAY_URL="${GATEWAY_URL:-http://localhost:8000}"
AGENT="${AGENT_HEADER:-claude-code}"
VERBOSE="${VERBOSE:-0}"

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m'

pass() { echo -e "${GREEN}✓ PASS${NC}: $1"; }
fail() { echo -e "${RED}✗ FAIL${NC}: $1"; FAILURES=$((FAILURES + 1)); }
info() { echo -e "${YELLOW}→${NC} $1"; }

FAILURES=0

# ---------------------------------------------------------------------------
# Pre-checks
# ---------------------------------------------------------------------------

if [ -z "${USER_TOKEN:-}" ]; then
    echo "ERROR: USER_TOKEN env var is required."
    echo "  Obtain a valid Okta access token and run:"
    echo "  USER_TOKEN=\"eyJ...\" $0"
    exit 1
fi

echo "========================================"
echo " XAA Token Mapping Smoke Test"
echo "========================================"
echo "Gateway:  $GATEWAY_URL"
echo "Agent:    $AGENT"
echo ""

# ---------------------------------------------------------------------------
# Helper: call MCP JSON-RPC on the unified endpoint
# ---------------------------------------------------------------------------
call_mcp() {
    local method="$1"
    local params="${2:-{}}"
    local id="${3:-1}"

    local body
    body=$(cat <<EOF
{"jsonrpc":"2.0","method":"${method}","params":${params},"id":${id}}
EOF
    )

    local resp
    resp=$(curl -s -w "\n%{http_code}" \
        -X POST "${GATEWAY_URL}/" \
        -H "Content-Type: application/json" \
        -H "Authorization: Bearer ${USER_TOKEN}" \
        -H "X-MCP-Agent: ${AGENT}" \
        -d "${body}")

    local http_code
    http_code=$(echo "$resp" | tail -1)
    local body_resp
    body_resp=$(echo "$resp" | sed '$d')

    if [ "$VERBOSE" = "1" ]; then
        info "Request: ${method} ${params}"
        info "Response (${http_code}): ${body_resp}"
    fi

    echo "${body_resp}"
    return 0
}

# ---------------------------------------------------------------------------
# Step 1: Initialize MCP session
# ---------------------------------------------------------------------------
info "Step 1: Initialize MCP session"
INIT_RESP=$(call_mcp "initialize" '{"protocolVersion":"2024-11-05","capabilities":{},"clientInfo":{"name":"smoke-test","version":"1.0"}}')

if echo "$INIT_RESP" | python3 -c "import sys,json; d=json.load(sys.stdin); assert 'result' in d" 2>/dev/null; then
    pass "MCP session initialized"
else
    fail "MCP initialize failed: $INIT_RESP"
fi

# ---------------------------------------------------------------------------
# Step 2: List tools (verifies auth + backend discovery)
# ---------------------------------------------------------------------------
info "Step 2: List tools"
TOOLS_RESP=$(call_mcp "tools/list" '{}' 2)

TOOL_COUNT=$(echo "$TOOLS_RESP" | python3 -c "
import sys, json
d = json.load(sys.stdin)
tools = d.get('result', {}).get('tools', [])
print(len(tools))
" 2>/dev/null || echo "0")

if [ "$TOOL_COUNT" -gt 0 ]; then
    pass "Discovered $TOOL_COUNT tools"
else
    fail "No tools discovered (check agent backend_access)"
fi

# ---------------------------------------------------------------------------
# Step 3: Call a deploy-server tool (requires XAA token exchange)
# ---------------------------------------------------------------------------
info "Step 3: Call deploy-server tool (get_deployments via XAA)"
DEPLOY_RESP=$(call_mcp "tools/call" '{"name":"deploy-server__get_deployments","arguments":{"service":"api-gateway","env":"prod"}}' 3)

if echo "$DEPLOY_RESP" | python3 -c "
import sys, json
d = json.load(sys.stdin)
content = d.get('result', {}).get('content', [])
assert len(content) > 0
text = content[0].get('text', '')
data = json.loads(text)
assert 'deployments' in data or isinstance(data, list)
" 2>/dev/null; then
    pass "deploy-server__get_deployments returned data (XAA exchange succeeded)"
else
    fail "deploy-server__get_deployments failed: $DEPLOY_RESP"
fi

# ---------------------------------------------------------------------------
# Step 4: Verify token store has a mapping (admin endpoint)
# ---------------------------------------------------------------------------
info "Step 4: Check token store stats (admin endpoint)"

# Use Okta access token from the environment. Password login was removed
# in v0.15.x. Obtain a token by signing in to the Admin UI and copying it
# out of browser devtools, or via the okta CLI, then:
#     export OKTA_ADMIN_TOKEN="<token>"
ADMIN_TOKEN="${OKTA_ADMIN_TOKEN:-}"

if [ -n "$ADMIN_TOKEN" ]; then
    STATS_RESP=$(curl -s "${GATEWAY_URL}/api/admin/token-store/stats" \
        -H "Authorization: Bearer ${ADMIN_TOKEN}")

    TOTAL=$(echo "$STATS_RESP" | python3 -c "
import sys, json
d = json.load(sys.stdin)
print(d.get('total_entries', 0))
" 2>/dev/null || echo "0")

    if [ "$TOTAL" -gt 0 ]; then
        pass "Token store has $TOTAL entries (BFF captured the mapping)"
    else
        fail "Token store is empty — BFF capture may not be working"
    fi
else
    info "Skipping admin check (OKTA_ADMIN_TOKEN not set)"
fi

# ---------------------------------------------------------------------------
# Step 5: Call an HR tool (PSK — should NOT use token store)
# ---------------------------------------------------------------------------
info "Step 5: Call HR tool (PSK backend — no XAA)"
HR_RESP=$(call_mcp "tools/call" '{"name":"hr-system__health_check","arguments":{}}' 5)

if echo "$HR_RESP" | python3 -c "
import sys, json
d = json.load(sys.stdin)
content = d.get('result', {}).get('content', [])
assert len(content) > 0
" 2>/dev/null; then
    pass "hr-system__health_check succeeded (PSK path working)"
else
    fail "hr-system__health_check failed: $HR_RESP"
fi

# ---------------------------------------------------------------------------
# Summary
# ---------------------------------------------------------------------------
echo ""
echo "========================================"
if [ "$FAILURES" -eq 0 ]; then
    echo -e "${GREEN}All checks passed!${NC}"
else
    echo -e "${RED}${FAILURES} check(s) failed${NC}"
fi
echo "========================================"

exit "$FAILURES"
