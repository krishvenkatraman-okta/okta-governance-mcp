#!/bin/bash
#
# Test migration script with sample data
#
# This script tests the config.yaml → PostgreSQL migration with a temporary database.
#

set -e  # Exit on error

echo "=========================================================================="
echo "Testing Configuration Migration Script"
echo "=========================================================================="
echo

# Colors for output
GREEN='\033[0;32m'
RED='\033[0;31m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Check if required commands are available
command -v python3 >/dev/null 2>&1 || { echo "Error: python3 is required but not installed."; exit 1; }
command -v psql >/dev/null 2>&1 || { echo "Error: psql is required but not installed."; exit 1; }

# Configuration
TEST_DB="gateway_test_migration"
TEST_USER="test_user"
TEST_PASS="test_pass"
TEST_CONFIG="config/config.yaml"
DATABASE_URL="postgresql://${TEST_USER}:${TEST_PASS}@localhost:5432/${TEST_DB}"

# Generate test encryption key
echo "Generating test encryption key..."
export ENCRYPTION_PASSWORD="test-migration-password-$(date +%s)"
export ENCRYPTION_SALT="test-salt"

echo "${YELLOW}Using password-derived encryption key for testing${NC}"
echo

# Step 1: Check if config file exists
echo "Step 1: Checking for config file..."
if [ ! -f "$TEST_CONFIG" ]; then
    echo "${RED}✗ Config file not found: $TEST_CONFIG${NC}"
    echo "Please create config/config.yaml before running this test"
    exit 1
fi
echo "${GREEN}✓ Config file found${NC}"
echo

# Step 2: Create test database
echo "Step 2: Creating test database..."
psql postgres -c "DROP DATABASE IF EXISTS ${TEST_DB};" 2>/dev/null || true
psql postgres -c "DROP USER IF EXISTS ${TEST_USER};" 2>/dev/null || true
psql postgres -c "CREATE USER ${TEST_USER} WITH PASSWORD '${TEST_PASS}';"
psql postgres -c "CREATE DATABASE ${TEST_DB} OWNER ${TEST_USER};"
psql postgres -c "GRANT ALL PRIVILEGES ON DATABASE ${TEST_DB} TO ${TEST_USER};"
echo "${GREEN}✓ Test database created${NC}"
echo

# Step 3: Run Alembic migrations
echo "Step 3: Running database migrations..."
export DATABASE_URL
alembic upgrade head
echo "${GREEN}✓ Migrations applied${NC}"
echo

# Step 4: Dry run migration
echo "Step 4: Testing dry-run mode..."
python3 ops_scripts/migrate_config_to_db.py \
    --config "$TEST_CONFIG" \
    --database-url "$DATABASE_URL" \
    --dry-run
echo "${GREEN}✓ Dry-run completed${NC}"
echo

# Step 5: Actual migration
echo "Step 5: Running actual migration..."
python3 ops_scripts/migrate_config_to_db.py \
    --config "$TEST_CONFIG" \
    --database-url "$DATABASE_URL"
echo "${GREEN}✓ Migration completed${NC}"
echo

# Step 6: Verify data
echo "Step 6: Verifying migrated data..."

# Count agents
AGENT_COUNT=$(psql "$DATABASE_URL" -t -c "SELECT COUNT(*) FROM agents;")
echo "  - Agents in database: ${AGENT_COUNT}"

# Count backends
BACKEND_COUNT=$(psql "$DATABASE_URL" -t -c "SELECT COUNT(*) FROM backends;")
echo "  - Backends in database: ${BACKEND_COUNT}"

# Count access mappings
ACCESS_COUNT=$(psql "$DATABASE_URL" -t -c "SELECT COUNT(*) FROM agent_backend_access;")
echo "  - Access mappings: ${ACCESS_COUNT}"

# Check encryption
HAS_ENCRYPTED=$(psql "$DATABASE_URL" -t -c "SELECT COUNT(*) FROM agents WHERE private_key_encrypted IS NOT NULL;")
echo "  - Agents with encrypted keys: ${HAS_ENCRYPTED}"

if [ "$HAS_ENCRYPTED" -gt 0 ]; then
    echo "${GREEN}✓ Data successfully migrated with encryption${NC}"
else
    echo "${RED}✗ No encrypted data found${NC}"
    exit 1
fi
echo

# Step 7: Test idempotency (run migration again)
echo "Step 7: Testing idempotency (running migration again)..."
python3 ops_scripts/migrate_config_to_db.py \
    --config "$TEST_CONFIG" \
    --database-url "$DATABASE_URL" \
    > /dev/null 2>&1

# Verify counts didn't change
AGENT_COUNT_2=$(psql "$DATABASE_URL" -t -c "SELECT COUNT(*) FROM agents;")
BACKEND_COUNT_2=$(psql "$DATABASE_URL" -t -c "SELECT COUNT(*) FROM backends;")

if [ "$AGENT_COUNT" = "$AGENT_COUNT_2" ] && [ "$BACKEND_COUNT" = "$BACKEND_COUNT_2" ]; then
    echo "${GREEN}✓ Migration is idempotent (counts unchanged)${NC}"
else
    echo "${RED}✗ Idempotency test failed (counts changed)${NC}"
    exit 1
fi
echo

# Step 8: Display sample data
echo "Step 8: Sample migrated data..."
echo
echo "Agents:"
psql "$DATABASE_URL" -c "SELECT agent_name, agent_id, client_id, enabled FROM agents;"
echo
echo "Backends:"
psql "$DATABASE_URL" -c "SELECT name, url, auth_method, enabled FROM backends LIMIT 5;"
echo
echo "Agent-Backend Access:"
psql "$DATABASE_URL" -c "SELECT agent_name, backend_name FROM agent_backend_access LIMIT 10;"
echo

# Step 9: Cleanup
echo "Step 9: Cleaning up..."
read -p "Delete test database? (y/n) " -n 1 -r
echo
if [[ $REPLY =~ ^[Yy]$ ]]; then
    psql postgres -c "DROP DATABASE IF EXISTS ${TEST_DB};"
    psql postgres -c "DROP USER IF EXISTS ${TEST_USER};"
    echo "${GREEN}✓ Test database deleted${NC}"
else
    echo "${YELLOW}Test database preserved for inspection: ${TEST_DB}${NC}"
    echo "To connect: psql ${DATABASE_URL}"
fi

echo
echo "=========================================================================="
echo "${GREEN}All tests passed!${NC}"
echo "=========================================================================="
