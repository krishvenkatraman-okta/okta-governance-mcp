#!/usr/bin/env bash
# Mint an Okta access token for the admin API using an Okta API Services app
# (client_credentials + private_key_jwt) and emit it as a shell `export` line
# so the caller can hide the token from the terminal with `eval`:
#
#     eval "$(./ops_scripts/admin_token.sh)"
#     curl -H "Authorization: Bearer $ADMIN_TOKEN" \
#          http://localhost:8000/api/admin/agents
#
# Inputs (env, all overridable via flags):
#     ADMIN_SERVICE_CLIENT_ID        0oa… id of the Okta API Services app
#     ADMIN_SERVICE_PRIVATE_KEY_FILE path to a JSON file containing the JWK
#                                    private key registered with that app
#     OKTA_DOMAIN                    e.g. dev-123.okta.com
#     ADMIN_SERVICE_SCOPE            space-separated scope list
#                                    (default matches the Admin UI's Okta
#                                    Management scopes, minus the OIDC
#                                    identity scopes which don't apply to
#                                    client_credentials tokens)
#     ADMIN_TOKEN_VAR                env var name for the export line
#                                    (default: ADMIN_TOKEN)
#
# The cid on the returned token MUST be listed in the adapter's
# ADMIN_API_SERVICE_CLIENT_IDS env var for the token to be accepted.
# See docs/ADMIN_API_SERVICE_AUTH.md.

set -euo pipefail

CLIENT_ID="${ADMIN_SERVICE_CLIENT_ID:-}"
KEY_FILE="${ADMIN_SERVICE_PRIVATE_KEY_FILE:-}"
DOMAIN="${OKTA_DOMAIN:-}"
# Default scopes mirror the Admin UI's NextAuth config
# (okta_agent_proxy_admin_ui/lib/auth.ts) minus openid/email/profile, which
# are OIDC identity scopes that don't apply to client_credentials tokens
# (no user context, no ID token issued). Every route the Admin UI can hit
# against Okta is covered by this set.
DEFAULT_SCOPE="okta.aiAgents.read okta.aiAgents.manage okta.apps.read okta.groups.read okta.authorizationServers.read"
SCOPE="${ADMIN_SERVICE_SCOPE:-$DEFAULT_SCOPE}"
VAR_NAME="${ADMIN_TOKEN_VAR:-ADMIN_TOKEN}"
QUIET=0

usage() {
  cat >&2 <<'USAGE'
Usage: admin_token.sh [options]

Options:
  --client-id <cid>     Okta API Services app client_id
  --key-file <path>     JWK private key file
  --domain <domain>     Okta domain (e.g. dev-123.okta.com)
  --scope <scope>       space-separated scope list (default mirrors Admin
                        UI's Okta Management scopes, minus OIDC identity
                        scopes which don't apply to client_credentials)
  --var <name>          env var name for the export line (default: ADMIN_TOKEN)
  --quiet               suppress stderr diagnostics
  -h, --help            show this help

Typical use:
  eval "$(./ops_scripts/admin_token.sh)"
USAGE
}

while [[ $# -gt 0 ]]; do
  case "$1" in
    --client-id) CLIENT_ID="$2"; shift 2 ;;
    --key-file)  KEY_FILE="$2"; shift 2 ;;
    --domain)    DOMAIN="$2"; shift 2 ;;
    --scope)     SCOPE="$2"; shift 2 ;;
    --var)       VAR_NAME="$2"; shift 2 ;;
    --quiet)     QUIET=1; shift ;;
    -h|--help)   usage; exit 0 ;;
    *) echo "Unknown argument: $1" >&2; usage; exit 2 ;;
  esac
done

die() { echo "admin_token.sh: $*" >&2; exit 1; }

[[ -n "$CLIENT_ID" ]] || die "ADMIN_SERVICE_CLIENT_ID (or --client-id) is required"
[[ -n "$KEY_FILE"  ]] || die "ADMIN_SERVICE_PRIVATE_KEY_FILE (or --key-file) is required"
[[ -n "$DOMAIN"    ]] || die "OKTA_DOMAIN (or --domain) is required"
[[ -r "$KEY_FILE"  ]] || die "Key file not readable: $KEY_FILE"

# Refuse to dump the token onto a TTY — the caller almost certainly forgot
# to wrap the invocation in `eval "$(...)"` and we'd leak the token into
# scrollback / shell history.
if [[ -t 1 ]]; then
  cat >&2 <<'TTY'
admin_token.sh: stdout is a TTY — refusing to emit the access token.
Wrap the call so the shell consumes the export line, e.g.:

    eval "$(./ops_scripts/admin_token.sh)"

Re-run with `| cat` if you really do want to see the raw export line.
TTY
  exit 1
fi

# Prefer the project venv when available so python-jose / httpx are present.
if [[ -x "./venv/bin/python" ]]; then
  PY="./venv/bin/python"
else
  PY="python3"
fi

export CLIENT_ID KEY_FILE DOMAIN SCOPE VAR_NAME QUIET

"$PY" - <<'PYEOF'
import json
import os
import sys
import time
import uuid

try:
    import httpx
    from jose import jwt
except ImportError as exc:  # pragma: no cover — deps listed in requirements.txt
    sys.stderr.write(
        f"admin_token.sh: missing dependency {exc.name!r}. "
        "Activate the project venv or `pip install python-jose httpx`.\n"
    )
    sys.exit(1)

client_id = os.environ["CLIENT_ID"]
key_file = os.environ["KEY_FILE"]
domain = os.environ["DOMAIN"].strip()
scope = os.environ["SCOPE"].strip()
var_name = os.environ["VAR_NAME"]
quiet = os.environ.get("QUIET") == "1"

if domain.startswith(("http://", "https://")):
    base = domain.rstrip("/")
else:
    base = f"https://{domain}"
token_endpoint = f"{base}/oauth2/v1/token"

try:
    with open(key_file, "r") as f:
        jwk = json.load(f)
except (OSError, json.JSONDecodeError) as exc:
    sys.stderr.write(f"admin_token.sh: failed to read JWK from {key_file}: {exc}\n")
    sys.exit(1)

if jwk.get("kty") != "RSA" or "d" not in jwk:
    sys.stderr.write(
        "admin_token.sh: key file must be an RSA private JWK (kty=RSA with 'd' claim)\n"
    )
    sys.exit(1)

now = int(time.time())
claims = {
    "iss": client_id,
    "sub": client_id,
    "aud": token_endpoint,
    "jti": str(uuid.uuid4()),
    "iat": now,
    "exp": now + 60,
}
headers = {"kid": jwk["kid"]} if jwk.get("kid") else {}
assertion = jwt.encode(claims, jwk, algorithm="RS256", headers=headers)

try:
    resp = httpx.post(
        token_endpoint,
        data={
            "grant_type": "client_credentials",
            "client_id": client_id,
            "client_assertion_type":
                "urn:ietf:params:oauth:client-assertion-type:jwt-bearer",
            "client_assertion": assertion,
            "scope": scope,
        },
        headers={"Content-Type": "application/x-www-form-urlencoded"},
        timeout=15.0,
    )
except httpx.HTTPError as exc:
    sys.stderr.write(f"admin_token.sh: token request failed: {exc}\n")
    sys.exit(1)

if resp.status_code != 200:
    sys.stderr.write(
        f"admin_token.sh: token endpoint returned {resp.status_code}: {resp.text}\n"
    )
    sys.exit(1)

body = resp.json()
access_token = body.get("access_token")
expires_in = body.get("expires_in")
if not access_token:
    sys.stderr.write(f"admin_token.sh: response missing access_token: {body}\n")
    sys.exit(1)

# Defensive check: confirm cid on the returned token matches the app we
# authenticated as. Catches misconfigured scopes / wrong endpoint early.
try:
    claims_out = jwt.get_unverified_claims(access_token)
except Exception as exc:
    sys.stderr.write(f"admin_token.sh: returned token is not a parseable JWT: {exc}\n")
    sys.exit(1)

cid = claims_out.get("cid")
if cid != client_id:
    sys.stderr.write(
        f"admin_token.sh: cid mismatch on returned token "
        f"(expected {client_id}, got {cid}). Check the service app configuration.\n"
    )
    sys.exit(1)

# access tokens are base64url + dots + underscores; no quotes to escape,
# but wrap in single quotes so the shell treats the value literally.
sys.stdout.write(f"export {var_name}='{access_token}'\n")

if not quiet:
    sys.stderr.write(
        f"admin_token.sh: acquired token cid={cid} scope='{scope}' "
        f"expires_in={expires_in}s (exported as ${var_name})\n"
    )
PYEOF
