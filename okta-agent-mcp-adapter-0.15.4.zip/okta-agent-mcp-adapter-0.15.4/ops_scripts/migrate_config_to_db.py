#!/usr/bin/env python3
"""
Migrate config.yaml to PostgreSQL database.

This script migrates configuration from YAML files to PostgreSQL with encryption
of sensitive fields. It is idempotent and can be run multiple times safely.

Features:
- Validates YAML structure before migration
- Encrypts sensitive fields (credentials, secrets, private keys)
- Uses upsert logic (INSERT ... ON CONFLICT DO UPDATE)
- Supports dry-run mode for preview
- Detailed progress reporting
- Transaction rollback on errors

Usage:
    # Basic migration
    python ops_scripts/migrate_config_to_db.py

    # Specify config path
    python ops_scripts/migrate_config_to_db.py --config config/config.yaml

    # Dry run (preview only)
    python ops_scripts/migrate_config_to_db.py --dry-run

    # Custom database URL
    python ops_scripts/migrate_config_to_db.py --database-url postgresql://user:pass@host/db

    # Verbose output
    python ops_scripts/migrate_config_to_db.py --verbose
"""

import sys
import os
import argparse
import yaml
import logging
from typing import Dict, Any, List, Tuple
from pathlib import Path

# Add parent directory to path
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from sqlalchemy import create_engine, text
from sqlalchemy.orm import sessionmaker
from sqlalchemy.dialects.postgresql import insert as pg_insert

from okta_agent_proxy.storage.models import (
    Base,
    AgentModel,
    BackendModel,
    AgentBackendAccess,
    AuditLog
)
from okta_agent_proxy.crypto.encryption import EncryptionService, EncryptionError

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)


class ConfigValidator:
    """Validates YAML configuration structure."""

    @staticmethod
    def validate_agent(agent_name: str, agent_data: Dict[str, Any]) -> List[str]:
        """Validate agent configuration."""
        errors = []

        # Required fields
        required = ['agent_id', 'client_id', 'private_key']
        for field in required:
            if field not in agent_data:
                errors.append(f"Agent '{agent_name}': Missing required field '{field}'")

        # Validate types
        if 'backend_access' in agent_data and not isinstance(agent_data['backend_access'], list):
            errors.append(f"Agent '{agent_name}': 'backend_access' must be a list")

        if 'scopes' in agent_data and not isinstance(agent_data['scopes'], list):
            errors.append(f"Agent '{agent_name}': 'scopes' must be a list")

        if 'enabled' in agent_data and not isinstance(agent_data['enabled'], bool):
            errors.append(f"Agent '{agent_name}': 'enabled' must be a boolean")

        # Validate private_key is JSON-like string or dict
        if 'private_key' in agent_data:
            pk = agent_data['private_key']
            if isinstance(pk, str):
                # Should be valid JSON
                if not (pk.strip().startswith('{') or pk.strip().startswith('"')):
                    errors.append(f"Agent '{agent_name}': 'private_key' should be JSON string")
            elif not isinstance(pk, dict):
                errors.append(f"Agent '{agent_name}': 'private_key' must be string or dict")

        return errors

    @staticmethod
    def validate_backend(backend_name: str, backend_data: Dict[str, Any]) -> List[str]:
        """Validate backend configuration."""
        errors = []

        # Required fields
        required = ['url', 'auth_method']
        for field in required:
            if field not in backend_data:
                errors.append(f"Backend '{backend_name}': Missing required field '{field}'")

        # Validate types
        if 'paths' in backend_data and not isinstance(backend_data['paths'], list):
            errors.append(f"Backend '{backend_name}': 'paths' must be a list")

        if 'auth_config' in backend_data and not isinstance(backend_data['auth_config'], dict):
            errors.append(f"Backend '{backend_name}': 'auth_config' must be a dict")

        if 'timeout_seconds' in backend_data:
            timeout = backend_data['timeout_seconds']
            if not isinstance(timeout, int) or timeout <= 0:
                errors.append(f"Backend '{backend_name}': 'timeout_seconds' must be positive integer")

        if 'enabled' in backend_data and not isinstance(backend_data['enabled'], bool):
            errors.append(f"Backend '{backend_name}': 'enabled' must be a boolean")

        # Validate auth_method
        valid_methods = ['okta-cross-app', 'static-key', 'service-account']
        if 'auth_method' in backend_data:
            if backend_data['auth_method'] not in valid_methods:
                errors.append(
                    f"Backend '{backend_name}': 'auth_method' must be one of {valid_methods}"
                )

        return errors

    @classmethod
    def validate_config(cls, config: Dict[str, Any]) -> Tuple[bool, List[str]]:
        """Validate entire configuration."""
        errors = []

        # Validate structure
        if 'agents' not in config and 'backends' not in config:
            errors.append("Configuration must contain 'agents' or 'backends' section")
            return False, errors

        # Validate agents
        agents = config.get('agents', {})
        if not isinstance(agents, dict):
            errors.append("'agents' section must be a dictionary")
        else:
            for agent_name, agent_data in agents.items():
                if not isinstance(agent_data, dict):
                    errors.append(f"Agent '{agent_name}' must be a dictionary")
                    continue
                errors.extend(cls.validate_agent(agent_name, agent_data))

        # Validate backends
        backends = config.get('backends', {})
        if not isinstance(backends, dict):
            errors.append("'backends' section must be a dictionary")
        else:
            for backend_name, backend_data in backends.items():
                if not isinstance(backend_data, dict):
                    errors.append(f"Backend '{backend_name}' must be a dictionary")
                    continue
                errors.extend(cls.validate_backend(backend_name, backend_data))

        return len(errors) == 0, errors


class ConfigMigrator:
    """Migrates configuration from YAML to PostgreSQL."""

    def __init__(
        self,
        database_url: str,
        encryption_service: EncryptionService,
        dry_run: bool = False
    ):
        """Initialize migrator."""
        self.database_url = database_url
        self.encryption = encryption_service
        self.dry_run = dry_run

        if not dry_run:
            self.engine = create_engine(database_url, echo=False)
            Base.metadata.create_all(self.engine)
            self.Session = sessionmaker(bind=self.engine)

        self.stats = {
            'agents_created': 0,
            'agents_updated': 0,
            'backends_created': 0,
            'backends_updated': 0,
            'access_mappings_created': 0,
            'errors': []
        }

    def migrate_backend(self, session, backend_name: str, backend_data: Dict[str, Any]) -> bool:
        """Migrate a single backend."""
        try:
            import json

            # Extract and encrypt sensitive fields
            auth_config = backend_data.get('auth_config', {})
            auth_method = backend_data.get('auth_method', 'okta-cross-app')

            auth_secret_encrypted = None
            auth_secret_iv = None
            auth_secret_tag = None

            sensitive_fields = self._extract_sensitive_fields(auth_method, auth_config)
            if sensitive_fields:
                secret_json = json.dumps(sensitive_fields)
                auth_secret_encrypted, auth_secret_iv, auth_secret_tag = \
                    self.encryption.encrypt(secret_json)

                # Remove sensitive fields from auth_config
                for key in sensitive_fields.keys():
                    auth_config.pop(key, None)

            # Prepare backend data
            backend_dict = {
                'name': backend_name,
                'url': backend_data['url'],
                'paths': json.dumps(backend_data.get('paths', [])),
                'auth_method': auth_method,
                'auth_config': json.dumps(auth_config),
                'auth_secret_encrypted': auth_secret_encrypted,
                'auth_secret_iv': auth_secret_iv,
                'auth_secret_tag': auth_secret_tag,
                'description': backend_data.get('description', ''),
                'timeout_seconds': backend_data.get('timeout_seconds', 30),
                'enabled': backend_data.get('enabled', True),
                'created_by': 'migration',
                'updated_by': 'migration'
            }

            if self.dry_run:
                logger.info(f"[DRY RUN] Would migrate backend: {backend_name}")
                self.stats['backends_created'] += 1
                return True

            # Upsert backend
            stmt = pg_insert(BackendModel).values(**backend_dict)
            stmt = stmt.on_conflict_do_update(
                index_elements=['name'],
                set_={
                    'url': stmt.excluded.url,
                    'paths': stmt.excluded.paths,
                    'auth_method': stmt.excluded.auth_method,
                    'auth_config': stmt.excluded.auth_config,
                    'auth_secret_encrypted': stmt.excluded.auth_secret_encrypted,
                    'auth_secret_iv': stmt.excluded.auth_secret_iv,
                    'auth_secret_tag': stmt.excluded.auth_secret_tag,
                    'description': stmt.excluded.description,
                    'timeout_seconds': stmt.excluded.timeout_seconds,
                    'enabled': stmt.excluded.enabled,
                    'updated_by': 'migration'
                }
            )

            result = session.execute(stmt)

            # Check if insert or update
            if result.rowcount > 0:
                # Check if it was an insert or update by querying
                existing = session.query(BackendModel).filter_by(name=backend_name).first()
                if existing and existing.created_by == 'migration':
                    self.stats['backends_created'] += 1
                    logger.info(f"✓ Created backend: {backend_name}")
                else:
                    self.stats['backends_updated'] += 1
                    logger.info(f"✓ Updated backend: {backend_name}")

            return True

        except Exception as e:
            error_msg = f"Failed to migrate backend '{backend_name}': {e}"
            logger.error(error_msg)
            self.stats['errors'].append(error_msg)
            return False

    def migrate_agent(self, session, agent_name: str, agent_data: Dict[str, Any]) -> bool:
        """Migrate a single agent."""
        try:
            import json

            # Encrypt sensitive fields
            client_secret = agent_data.get('client_secret')
            private_key = agent_data.get('private_key')

            # Handle private_key as dict or string
            if isinstance(private_key, dict):
                private_key = json.dumps(private_key)

            # Client secret encryption (optional)
            cs_enc, cs_iv, cs_tag = (None, None, None)
            if client_secret:
                cs_enc, cs_iv, cs_tag = self.encryption.encrypt(client_secret)

            # Private key encryption (required)
            pk_enc, pk_iv, pk_tag = self.encryption.encrypt(private_key)

            # Prepare agent data
            agent_dict = {
                'agent_name': agent_name,
                'agent_id': agent_data['agent_id'],
                'client_id': agent_data['client_id'],
                'client_secret_encrypted': cs_enc,
                'client_secret_iv': cs_iv,
                'client_secret_tag': cs_tag,
                'private_key_encrypted': pk_enc,
                'private_key_iv': pk_iv,
                'private_key_tag': pk_tag,
                'scopes': json.dumps(agent_data.get('scopes', ['mcp:read'])),
                'backend_access': json.dumps(agent_data.get('backend_access', [])),
                'enabled': agent_data.get('enabled', True),
                'created_by': 'migration',
                'updated_by': 'migration'
            }

            if self.dry_run:
                logger.info(f"[DRY RUN] Would migrate agent: {agent_name}")
                self.stats['agents_created'] += 1
                return True

            # Upsert agent
            stmt = pg_insert(AgentModel).values(**agent_dict)
            stmt = stmt.on_conflict_do_update(
                index_elements=['agent_name'],
                set_={
                    'agent_id': stmt.excluded.agent_id,
                    'client_id': stmt.excluded.client_id,
                    'client_secret_encrypted': stmt.excluded.client_secret_encrypted,
                    'client_secret_iv': stmt.excluded.client_secret_iv,
                    'client_secret_tag': stmt.excluded.client_secret_tag,
                    'private_key_encrypted': stmt.excluded.private_key_encrypted,
                    'private_key_iv': stmt.excluded.private_key_iv,
                    'private_key_tag': stmt.excluded.private_key_tag,
                    'scopes': stmt.excluded.scopes,
                    'backend_access': stmt.excluded.backend_access,
                    'enabled': stmt.excluded.enabled,
                    'updated_by': 'migration'
                }
            )

            result = session.execute(stmt)

            if result.rowcount > 0:
                existing = session.query(AgentModel).filter_by(agent_name=agent_name).first()
                if existing and existing.created_by == 'migration':
                    self.stats['agents_created'] += 1
                    logger.info(f"✓ Created agent: {agent_name}")
                else:
                    self.stats['agents_updated'] += 1
                    logger.info(f"✓ Updated agent: {agent_name}")

            return True

        except Exception as e:
            error_msg = f"Failed to migrate agent '{agent_name}': {e}"
            logger.error(error_msg)
            self.stats['errors'].append(error_msg)
            return False

    def migrate_agent_backend_access(
        self,
        session,
        agent_name: str,
        backend_list: List[str]
    ) -> bool:
        """Migrate agent-backend access mappings."""
        try:
            if self.dry_run:
                logger.info(f"[DRY RUN] Would create {len(backend_list)} access mappings for {agent_name}")
                self.stats['access_mappings_created'] += len(backend_list)
                return True

            # Delete existing mappings for this agent
            session.query(AgentBackendAccess).filter_by(agent_name=agent_name).delete()

            # Create new mappings
            for backend_name in backend_list:
                # Verify backend exists
                backend_exists = session.query(BackendModel).filter_by(name=backend_name).first()
                if not backend_exists:
                    logger.warning(
                        f"Backend '{backend_name}' not found, skipping access mapping for {agent_name}"
                    )
                    continue

                access = AgentBackendAccess(
                    agent_name=agent_name,
                    backend_name=backend_name,
                    granted_by='migration'
                )
                session.add(access)
                self.stats['access_mappings_created'] += 1

            logger.info(f"✓ Created {len(backend_list)} access mappings for {agent_name}")
            return True

        except Exception as e:
            error_msg = f"Failed to migrate access mappings for '{agent_name}': {e}"
            logger.error(error_msg)
            self.stats['errors'].append(error_msg)
            return False

    def _extract_sensitive_fields(self, auth_method: str, auth_config: Dict[str, Any]) -> Dict[str, Any]:
        """Extract sensitive fields from auth_config based on auth_method."""
        sensitive = {}

        if auth_method == 'okta-cross-app':
            if 'target_client_secret' in auth_config:
                sensitive['target_client_secret'] = auth_config['target_client_secret']
        elif auth_method == 'static-key':
            if 'api_key' in auth_config:
                sensitive['api_key'] = auth_config['api_key']
            if 'key' in auth_config:
                sensitive['key'] = auth_config['key']
        elif auth_method == 'service-account':
            if 'password' in auth_config:
                sensitive['password'] = auth_config['password']

        return sensitive

    def migrate(self, config: Dict[str, Any]) -> bool:
        """Migrate entire configuration."""
        if self.dry_run:
            logger.info("=" * 80)
            logger.info("DRY RUN MODE - No changes will be made to the database")
            logger.info("=" * 80)

        session = None
        try:
            if not self.dry_run:
                session = self.Session()

            # Migrate backends first (agents reference them via backend_access)
            backends = config.get('backends', {})
            logger.info(f"\nMigrating {len(backends)} backends...")
            for backend_name, backend_data in backends.items():
                self.migrate_backend(session, backend_name, backend_data)

            if not self.dry_run:
                session.flush()

            # Migrate agents
            agents = config.get('agents', {})
            logger.info(f"\nMigrating {len(agents)} agents...")
            for agent_name, agent_data in agents.items():
                self.migrate_agent(session, agent_name, agent_data)

            if not self.dry_run:
                session.flush()

            # Migrate agent-backend access mappings
            logger.info(f"\nMigrating agent-backend access mappings...")
            for agent_name, agent_data in agents.items():
                backend_list = agent_data.get('backend_access', [])
                if backend_list:
                    self.migrate_agent_backend_access(session, agent_name, backend_list)

            # Commit transaction
            if not self.dry_run:
                session.commit()
                logger.info("\n✓ All changes committed to database")
            else:
                logger.info("\n[DRY RUN] No changes were made")

            return len(self.stats['errors']) == 0

        except Exception as e:
            if session and not self.dry_run:
                session.rollback()
            error_msg = f"Migration failed: {e}"
            logger.error(error_msg)
            self.stats['errors'].append(error_msg)
            return False

        finally:
            if session and not self.dry_run:
                session.close()

    def print_summary(self):
        """Print migration summary."""
        logger.info("\n" + "=" * 80)
        logger.info("MIGRATION SUMMARY")
        logger.info("=" * 80)
        logger.info(f"Agents created:         {self.stats['agents_created']}")
        logger.info(f"Agents updated:         {self.stats['agents_updated']}")
        logger.info(f"Backends created:       {self.stats['backends_created']}")
        logger.info(f"Backends updated:       {self.stats['backends_updated']}")
        logger.info(f"Access mappings:        {self.stats['access_mappings_created']}")
        logger.info(f"Errors:                 {len(self.stats['errors'])}")

        if self.stats['errors']:
            logger.info("\nErrors encountered:")
            for error in self.stats['errors']:
                logger.error(f"  - {error}")

        logger.info("=" * 80)


def main():
    """Main entry point."""
    parser = argparse.ArgumentParser(
        description='Migrate config.yaml to PostgreSQL database',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  # Basic migration
  python ops_scripts/migrate_config_to_db.py

  # Dry run (preview only)
  python ops_scripts/migrate_config_to_db.py --dry-run

  # Custom config path
  python ops_scripts/migrate_config_to_db.py --config my-config.yaml

  # Custom database URL
  python ops_scripts/migrate_config_to_db.py --database-url postgresql://user:pass@host/db

Environment Variables:
  DATABASE_URL         Database connection string (default: from .env)
  ENCRYPTION_KEY       Base64-encoded encryption key (required)
  ENCRYPTION_PASSWORD  Alternative to ENCRYPTION_KEY (derive key)
        """
    )

    parser.add_argument(
        '--config',
        default=os.getenv('CONFIG_PATH', 'config/config.yaml'),
        help='Path to config.yaml file (default: config/config.yaml)'
    )

    parser.add_argument(
        '--database-url',
        default=os.getenv('DATABASE_URL'),
        help='PostgreSQL connection string (default: from DATABASE_URL env var)'
    )

    parser.add_argument(
        '--dry-run',
        action='store_true',
        help='Preview migration without making changes'
    )

    parser.add_argument(
        '--verbose',
        action='store_true',
        help='Enable verbose logging'
    )

    args = parser.parse_args()

    # Configure logging level
    if args.verbose:
        logging.getLogger().setLevel(logging.DEBUG)

    # Print header
    print("=" * 80)
    print("Okta Agent MCP Adapter - Configuration Migration")
    print("YAML → PostgreSQL with Encryption")
    print("=" * 80)
    print()

    # Validate arguments
    if not os.path.exists(args.config):
        logger.error(f"Configuration file not found: {args.config}")
        sys.exit(1)

    if not args.database_url:
        logger.error(
            "Database URL not provided. Set DATABASE_URL environment variable "
            "or use --database-url option."
        )
        sys.exit(1)

    # Load and validate YAML
    logger.info(f"Loading configuration from: {args.config}")
    try:
        with open(args.config, 'r') as f:
            config = yaml.safe_load(f)
    except Exception as e:
        logger.error(f"Failed to load YAML: {e}")
        sys.exit(1)

    # Validate configuration
    logger.info("Validating configuration...")
    valid, errors = ConfigValidator.validate_config(config)
    if not valid:
        logger.error("Configuration validation failed:")
        for error in errors:
            logger.error(f"  - {error}")
        sys.exit(1)

    logger.info(f"✓ Configuration valid")
    logger.info(f"  - Agents: {len(config.get('agents', {}))}")
    logger.info(f"  - Backends: {len(config.get('backends', {}))}")

    # Initialize encryption service
    logger.info("\nInitializing encryption service...")
    try:
        encryption = EncryptionService()
        logger.info("✓ Encryption service initialized")
    except EncryptionError as e:
        logger.error(f"Encryption initialization failed: {e}")
        logger.error("Set ENCRYPTION_KEY or ENCRYPTION_PASSWORD environment variable")
        sys.exit(1)

    # Connect to database (only if not dry-run)
    if not args.dry_run:
        logger.info(f"\nConnecting to database...")
        try:
            from sqlalchemy import create_engine
            engine = create_engine(args.database_url, echo=False)
            connection = engine.connect()
            connection.close()
            logger.info("✓ Database connection successful")
        except Exception as e:
            logger.error(f"Database connection failed: {e}")
            sys.exit(1)

    # Run migration
    logger.info("\nStarting migration...")
    migrator = ConfigMigrator(
        database_url=args.database_url,
        encryption_service=encryption,
        dry_run=args.dry_run
    )

    success = migrator.migrate(config)
    migrator.print_summary()

    # Exit with appropriate code
    if success and len(migrator.stats['errors']) == 0:
        logger.info("\n✓ Migration completed successfully!")
        sys.exit(0)
    else:
        logger.error("\n✗ Migration completed with errors")
        sys.exit(1)


if __name__ == '__main__':
    main()
