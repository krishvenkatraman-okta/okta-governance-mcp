#!/usr/bin/env bash
# ──────────────────────────────────────────────────────────────
# build_release_zip.sh — Package the Okta MCP Adapter for customer delivery
#
# Creates a clean zip file containing only the files required to
# deploy and operate the adapter. Excludes development artifacts,
# Claude Code files, test suites, reports, and other non-operational files.
#
# Usage:
#   ./ops_scripts/build_release_zip.sh              # default version from deploy/bundle/VERSION
#   ./ops_scripts/build_release_zip.sh 1.0.0        # explicit version
#
# Output: dist/okta-mcp-adapter-<version>.zip
# ──────────────────────────────────────────────────────────────
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
PROJECT_ROOT="$(cd "$SCRIPT_DIR/.." && pwd)"

# Version: argument > VERSION file > fallback
VERSION="${1:-}"
if [[ -z "$VERSION" ]]; then
    VERSION_FILE="$PROJECT_ROOT/deploy/bundle/VERSION"
    if [[ -f "$VERSION_FILE" ]]; then
        VERSION="$(tr -d '[:space:]' < "$VERSION_FILE")"
    else
        VERSION="0.0.0-dev"
    fi
fi

DIST_DIR="$PROJECT_ROOT/dist"
ZIP_NAME="okta-mcp-adapter-${VERSION}.zip"
ZIP_PATH="$DIST_DIR/$ZIP_NAME"

mkdir -p "$DIST_DIR"
rm -f "$ZIP_PATH"

echo "╔══════════════════════════════════════════════════╗"
echo "║  Okta MCP Adapter — Release Packager            ║"
echo "╠══════════════════════════════════════════════════╣"
echo "║  Version : $VERSION"
echo "║  Output  : dist/$ZIP_NAME"
echo "╚══════════════════════════════════════════════════╝"
echo ""

cd "$PROJECT_ROOT"

# ── Build the zip using git archive as the base (respects .gitignore)
# then layer on explicit exclusions for non-operational files.
# Using a temporary directory to stage the contents.

STAGING_DIR="$(mktemp -d)"
ARCHIVE_PREFIX="okta-mcp-adapter-${VERSION}"
trap 'rm -rf "$STAGING_DIR"' EXIT

echo "→ Staging files from git tracked content..."

# Export git-tracked files into the staging directory
git archive --format=tar HEAD | tar -x -C "$STAGING_DIR"

echo "→ Removing non-operational files..."

cd "$STAGING_DIR"

# ── Remove development / CI files ──
rm -f  CLAUDE.md
rm -f  examples/CLAUDE.md
rm -f  DOCKER_TEST_RESULTS.md
rm -f  test_gateway.py

# ── Remove test suite ──
rm -rf tests/

# ── Remove tests and test scripts inside examples ──
rm -rf examples/01-hr-system/tests/
rm -f  examples/01-hr-system/run_tests.sh
rm -f  examples/01-hr-system/manual_test.sh
rm -f  examples/01-hr-system/TEST-RESULTS.md
rm -rf examples/05-deploy-server/tests/
rm -f  examples/05-deploy-server/test_e2e_xaa.sh
rm -f  examples/05-deploy-server/test_e2e_xaa_path.sh

# ── Remove admin UI test/debug endpoints ──
rm -rf okta_agent_proxy_admin_ui/app/api/test-env/

# ── Remove reports directory ──
rm -rf reports/

# ── Remove Claude Code / AI assistant config ──
rm -rf .claude/

# ── Remove GitHub CI/CD (not needed for customer operation) ──
rm -rf .github/

# ── Remove pytest / dev tool caches ──
rm -rf .pytest_cache/
rm -f  .coverage

# ── Remove development-only scripts ──
rm -f  ops_scripts/test_migration.sh
rm -f  ops_scripts/test_cimd_flow.sh
rm -f  ops_scripts/test_round_trip.py
rm -f  ops_scripts/test_xaa_smoke.sh
rm -f  ops_scripts/cimd_test_server.py
rm -f  ops_scripts/simulate_okta_event_hook.py

# ── Remove bundle build tooling (the bundle itself is a separate artifact) ──
rm -rf deploy/bundle/dist/
rm -rf deploy/bundle/images/
rm -f  deploy/bundle/scripts/build-release.sh
rm -f  deploy/bundle/Makefile

# ── Remove dev-only docs ──
rm -f  docs/adr/ADR-001-scope-model.md
rm -rf docs/adr/

# ── Remove pyproject.toml dev sections are fine to keep (it's metadata) ──
# ── Keep README.md, docs/, deploy/ — customers need these ──

# ── Remove any stray __pycache__ or .pyc files ──
find . -type d -name "__pycache__" -exec rm -rf {} + 2>/dev/null || true
find . -name "*.pyc" -delete 2>/dev/null || true
find . -name ".DS_Store" -delete 2>/dev/null || true

echo "→ Creating zip archive..."

cd "$STAGING_DIR"
zip -r "$ZIP_PATH" . -x '*.DS_Store' > /dev/null

# ── Summary ──
FILE_COUNT=$(zipinfo -1 "$ZIP_PATH" | wc -l | tr -d ' ')
FILE_SIZE=$(du -h "$ZIP_PATH" | cut -f1)

echo ""
echo "✓ Release package created successfully"
echo "  Path  : $ZIP_PATH"
echo "  Size  : $FILE_SIZE"
echo "  Files : $FILE_COUNT"
echo ""
echo "Contents include:"
echo "  • okta_agent_proxy/         — Gateway source code"
echo "  • okta_agent_proxy_admin_ui/ — Admin UI (Next.js)"
echo "  • examples/                 — Example backend servers"
echo "  • scripts/                  — Operational scripts"
echo "  • deploy/                   — Docker & observability configs"
echo "  • docs/                     — Operations & setup guides"
echo "  • alembic/                  — Database migrations"
echo "  • docker-compose.yml        — Docker Compose stack"
echo "  • Dockerfile                — Gateway container image"
echo "  • setup.sh                  — Bootstrap script"
echo "  • .env.example              — Environment template"
echo "  • requirements.txt          — Python dependencies"
echo ""
echo "Excluded:"
echo "  • tests/, CLAUDE.md, .claude/, .github/"
echo "  • reports/, test scripts, build tooling"
echo "  • __pycache__/, .pyc, .DS_Store"
