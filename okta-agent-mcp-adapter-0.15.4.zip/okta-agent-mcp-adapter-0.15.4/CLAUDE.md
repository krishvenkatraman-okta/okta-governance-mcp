# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Project Overview

This is the **Okta MCP Adapter** - an OAuth 2.1 gateway/proxy for Model Context Protocol (MCP) clients. It enables multiple AI agents (Claude Code, Cursor, Copilot) to securely access downstream resource endpoints (MCP servers, A2A agents, API targets) using Okta authentication with the Identity-JAG (JWT Authorization Grant) token exchange pattern.

**⚠️ Status:** Unofficial prototype for evaluation only. All tests passing.

## Essential Commands

### Development Setup
```bash
# Install dependencies
pip install -r requirements.txt

# Setup configuration
cp .env.example .env
# Edit .env with your Okta and PostgreSQL credentials

# Initialize database
alembic upgrade head
```

### Running the Gateway
```bash
# Option 1: Direct execution
python -m okta_agent_proxy.main http

# Option 2: Using script (creates venv, installs deps)
./ops_scripts/run_gateway.sh

# With debug logging
LOG_LEVEL=DEBUG python -m okta_agent_proxy.main http
```

### Testing
```bash
# Run all tests
pytest tests/ -v

# Run specific test file
pytest tests/test_agent_authz.py -v
pytest tests/test_okta_auth.py -v
pytest tests/test_postgres_repository.py -v
pytest tests/test_admin_api_integration.py -v

# Run with coverage
pytest tests/ --cov=okta_agent_proxy

# Run single test
pytest tests/test_agent_authz.py::test_agent_can_access_allowed_resource -v

# Test PostgreSQL migration
./ops_scripts/test_migration.sh
```

### Code Quality
```bash
# Format code
black okta_agent_proxy/ --line-length 100

# Type checking
mypy okta_agent_proxy/

# Linting
flake8 okta_agent_proxy/
```

## Tooling Conventions

**Never `source venv/bin/activate`.** Claude Code treats `source` as shell-eval and prompts for approval on every call, which blocks unattended runs. Call the venv's binaries directly instead — their shebangs already point at the venv's interpreter, so activation is only useful for interactive human shells, not for one-off commands.

| Don't | Do |
|---|---|
| `source venv/bin/activate && pytest ...` | `./venv/bin/pytest ...` |
| `source venv/bin/activate && python -m ...` | `./venv/bin/python -m ...` |
| `source venv/bin/activate && pip install ...` | `./venv/bin/pip install ...` |
| `source venv/bin/activate && alembic upgrade head` | `./venv/bin/alembic upgrade head` |

The direct-invocation patterns (`./venv/bin/pytest:*`, `./venv/bin/python:*`, `venv/bin/pip install:*`, etc.) are already allowlisted in `.claude/settings.local.json`, so they run without prompts. Avoid `source` in any form for the same reason — if env vars are needed, inline them: `FOO=bar ./venv/bin/<tool>`.

## Architecture: 7-Layer Proxy Model

The gateway is architected as a 7-layer proxy pipeline. Understanding this flow is critical:

```
Layer 1: FastMCP Server      → HTTP transport, MCP protocol lifecycle
Layer 2: Authentication       → Okta JWT validation, JWKS caching
Layer 3: Authorization        → Agent-to-resource access control
Layer 4: Routing              → Path-based resource selection
Layer 5: Token Exchange       → ID-JAG token issuance (RFC 8693)
Layer 6: Token Cache          → TTL-based caching with expiration
Layer 7: Proxy                → Resource auth, HTTP forwarding
```

### Request Flow Pipeline

Every MCP request flows through these steps (see `okta_agent_proxy/proxy/handler.py:proxy_request`):

1. **Extract Bearer token** from Authorization header
2. **Extract agent ID** from X-MCP-Agent header (via `AgentExtractor`)
3. **Validate JWT** against Okta JWKS (via `OktaTokenValidator`)
4. **Route to resource** based on request path (via `ResourceRouter`)
5. **Check authorization** - is resource in agent's `resource_access` list? (via `check_agent_can_access_resource`)
6. **Exchange token** - Issue ID-JAG JWT, exchange for resource token (via `create_auth_handler`)
7. **Forward request** with resource credentials to target MCP server
8. **Handle errors** - 401s invalidate cache and retry

## Key Architectural Concepts

### Multi-Agent Support (Phase 2+)

Each MCP client agent has its own configuration entry in PostgreSQL (managed via Admin API):

```json
{
  "agent_id": "claude-code",
  "client_id": "0oa_xxx",           // Okta OAuth client
  "client_secret": "xxx",           // Encrypted in database
  "private_key": "{...JWK...}",     // JWK format for signing ID-JAG tokens, encrypted
  "resource_access": [              // Authorization list (resources this agent can access)
    "hr-system",
    "finance-system"
  ]
}
```

The `X-MCP-Agent` header determines which agent config to use. See `middleware/agent_extractor.py` for extraction logic.

### CIMD Agent Matching

Pre-registered agents can include a `cimd_client_id` field (CIMD URL).
When a CIMD client authenticates, the `ClientRegistry` matches by URL
before falling through to auto-provisioning. This gives CIMD clients
real Okta credentials for ID-JAG exchange instead of PLACEHOLDER keys.

Resolution order: Manual (`client_id`) → CIMD Match (`cimd_client_id`) →
Auto-Provision → DCR → None

Key files: `auth/client_registry.py` (`_resolve_by_cimd_url`), `storage/postgres.py` (`get_agent_by_cimd_client_id`)

### ID-JAG Token Exchange (Phase 3)

The adapter uses the official **okta-client-python** SDK's `CrossAppAccessFlow` for token exchange:

**Step 1+2: `flow.start(token=user_id_token)`** (`auth/cross_app_access.py`)
- SDK creates JWT assertion signed with agent's `private_key` (from DB)
- Exchanges user's ID token for an ID-JAG token at the org auth server
- JWTBearerClaims: issuer=principalId, subject=principalId

**Step 3: `flow.resume()`** (`auth/cross_app_access.py`)
- Exchanges ID-JAG for resource access token at the target auth server
- Receive resource access token with caching

This pattern enables **cross-org token exchange** between different Okta orgs.

### Resource Authentication Methods

Seven auth methods are supported (`auth/resource_auth.py`):

1. **okta-cross-app**: ID-JAG token exchange via `CrossAppAccessFlow` (most common)
2. **vault-secret**: SDK-based `TokenExchangeFlow` for Okta Privileged Access vaulted secrets (`OktaVaultSecretExchanger.exchange_vault_secret()`)
3. **sts-service-account**: SDK-based `TokenExchangeFlow` for Okta PA service account credentials (`OktaVaultSecretExchanger.exchange_service_account()`)
4. **okta-sts**: STS brokered ISV token exchange via `OktaSTSTokenExchanger` (GitHub, Jira, etc.)
5. **pre-shared-key**: Static API key in custom header
6. **service-account**: HTTP Basic Auth (static credentials)
7. **bearer-passthrough**: Forward user's token directly

The `auth_method` is auto-derived from the Okta connection type via `_CONNECTION_TYPE_TO_AUTH_METHOD`.

### Credential Automation

`okta_admin/` provisions client secrets and signing keys via the Okta Management API using the admin user's OIDC access token (no service app). Required scopes: `okta.apps.manage`, `okta.aiAgents.manage`. Prerequisite: agent's `okta_ai_agent_id` must be set (via "Import from Okta"). See `docs/CREDENTIAL_AUTOMATION.md`.

**JWKS registration gotcha:** If generate-keypair returns `Okta API error 400: Api validation failed: keys`, the agent's JWK list is at Okta's per-agent cap — delete stale keys in Okta and retry. The message looks like a payload-shape error but it is a quota issue; the JWK body is fine. Surfaces in `okta_admin/key_manager.py:register_public_key`.

### Token Caching Strategy

Resource tokens are cached with TTL (`cache/token_cache.py`):

- Key: `f"{user_id}:{resource_name}"`
- Default TTL: 3600 seconds (1 hour)
- Automatic expiration based on token `expires_in`
- 401 responses trigger cache invalidation and retry

This reduces auth server load significantly.

### Horizontal Scaling

The adapter supports horizontal scaling (2+ replicas behind a load balancer) when four prerequisites are met: `CACHE_PROVIDER=redis`, `REDIS_URL` reachable from every pod, `ENCRYPTION_KEY` identical across every pod, and the default Starlette HTTP transport. Session stickiness is not required — all per-flow state (UserTokenStore, GatewayCodeManager, ConfidentialRelay, ConsentTransactionStore) is stored in Redis when configured. Single-pod deployments continue to work with `CACHE_PROVIDER=memory` (the default). See `deploy/HORIZONTAL_SCALING.md` and `docs/OPERATIONS.md` "Redis Cache" section for details.

### PostgreSQL Configuration Storage

Configuration is stored in PostgreSQL with enterprise-grade security:

1. `PostgresResourceStore` connects to PostgreSQL database (`storage/postgres.py`)
2. Data stored in PostgreSQL with SQLAlchemy ORM (`storage/models.py`)
3. **Encryption:** Sensitive fields encrypted with AES-256-GCM (`crypto/encryption.py`)
   - Agent: `client_secret`, `private_key`
   - Resource: `target_client_secret`, `api_key`, `password`
4. **Audit logging:** All changes tracked with user attribution
5. Admin API (`admin/routes.py`) provides CRUD operations for runtime configuration management

**Benefits:** Multi-instance support, encrypted credentials, full audit trail, production-ready

## Redis Credential Providers

Pluggable providers in `okta_agent_proxy/cache/redis_credentials.py`. Factory dispatches by `REDIS_AUTH_MODE`.

| Mode          | Module                                        | Lifetime  | Refresh    |
| ------------- | --------------------------------------------- | --------- | ---------- |
| static        | redis_credential_providers/static.py          | none      | n/a        |
| aws-iam       | redis_credential_providers/aws_iam.py         | 15 min    | 2.5 min    |
| azure-entra   | redis_credential_providers/azure_entra.py     | ~1 hour   | 5 min      |

Expiring credentials refresh within `refresh_safety_window` of expiry. Refresh failures emit `redis.credential.refresh.failed` and let the existing client run until natural expiry (fail-open on refresh, fail-closed on auth). Startup preflight mints once and exposes state at `/health` under `redis_credentials`; failure degrades `/health` to 503.

**Static gate:** `static` mode requires `ALLOW_STATIC_REDIS_PASSWORD=true`. Production uses `aws-iam` or `azure-entra`. The gate exists as an explicit grep target for security reviewers.

**Valkey:** wire-compatible with `redis-py`. Swap the server image, no code changes. Don't swap the client library to `valkey-py` — untested.

## Configuration Patterns

### Environment Variables (.env)

```bash
# Okta Configuration
OKTA_DOMAIN=dev-xxx.okta.com          # Your Okta org domain

# Gateway Configuration
GATEWAY_BASE_URL=http://localhost:8000
GATEWAY_PORT=8000
LOG_LEVEL=INFO                        # DEBUG for troubleshooting

# PostgreSQL Database Configuration (Required)
DATABASE_URL=postgresql://user:pass@localhost:5432/gateway_db

# Encryption Configuration (Required)
ENCRYPTION_KEY=<base64-encoded-key>   # Generate with ops_scripts/generate_encryption_key.py
# Alternative: ENCRYPTION_PASSWORD=<password>  # Derive key from password via PBKDF2
```

**Port Configuration:** Five canonical env vars control all ports: `GATEWAY_PORT` (8000), `ADMIN_UI_PORT` (3001), `HR_BACKEND_PORT` (8001), `DEPLOY_SERVER_PORT` (8005), `DCR_CALLBACK_PORT` (3000). These flow through Dockerfiles, docker-compose, ECS Terraform, AKS/ACA manifests, and health checks. `SERVER_PORT` is deprecated — use component-specific vars. See [docs/OPERATIONS.md](docs/OPERATIONS.md#port-configuration).

**Important:**
- Credentials are managed via Admin API and stored encrypted in PostgreSQL
- Never commit `ENCRYPTION_KEY` to version control
- Use the same encryption key across all gateway instances in a cluster

### Resource Configuration

Each resource requires:
- `url`: Target MCP server endpoint
- `paths`: List of URL paths that route to this resource (e.g., `[/hr, /employees]`)
- `auth_method`: One of: okta-cross-app, pre-shared-key, service-account
- `auth_config`: Method-specific configuration (varies by auth_method)

### Agent Authorization Model

The `resource_access` list in agent config controls which resources the agent can access. This is enforced at Layer 3 (Authorization) before any token exchange happens.

**Authorization check location:** `auth/agent_authz.py:check_agent_can_access_resource`

### Terminology
- **Resource**: The adapter's view of one (agent, Okta Managed Connection) pair. One row per pair in the `resources` table, materialized by the Okta syncer. Admins edit routing metadata (URL, slug, description, enabled); sync owns the connection state (scopes, scope_condition, connection_type, auth_method, metadata). No standalone-create path — resources come into being via Okta sync. Previously called "backend" in earlier versions.
- **Connection**: An Okta Managed Connection linking an Okta AI Agent to a downstream target.
- **Agent**: An AI agent identity (Claude Code, Cursor, etc.) that connects to the gateway.

> **Note:** The term "backend" is fully deprecated as of v0.11.0. Use "resource" for configured downstream endpoints. "Backend" may still appear in generic HTTP proxy contexts (e.g., "backend server returned 502") and in legacy table/column names prefixed with `_deprecated_`.

## Testing

All async tests use `@pytest.mark.asyncio` (pytest-asyncio). Admin API tests use Starlette `TestClient`. Fixtures are defined in `tests/conftest.py`.

## MCP Protocol Integration

The gateway supports two routing modes, both active simultaneously:

**Mode 1 — Unified Consolidated Endpoint (POST /)**
Used by Claude Code, Cursor, and other MCP clients that connect to a single URL.
The `UnifiedMCPHandler` (`mcp/unified_handler.py`) consolidates tools from all resources
the agent has access to, namespacing tool names as `{resource_name}__{tool_name}`.
Tool calls are routed to the correct resource automatically.

Best for: AI coding assistants that expect a single MCP server URL.

**Mode 2 — Path-Based Direct Access (POST /{resource_name})**
Each resource is exposed as a standalone MCP server at its own path.
For example: `POST /hr-system`, `POST /deploy-server`, `POST /finance-system`.
Tool names are NOT namespaced — they pass through as-is from the resource.
The resource name IS the path (automatic canonical routing).
Custom path aliases can be added via the `paths[]` field in resource config.

Best for: Multi-agent architectures, A2A patterns, clients that connect
to specific resources, scripts, and curl-based testing.

Both modes share the same 7-layer pipeline (auth, authz, token exchange, etc.)
and require a valid Okta JWT in the Authorization header and an agent
identifier in the X-MCP-Agent header.

**MCP Methods (Unified Endpoint):**
- `initialize`: Returns gateway capabilities, generates session ID (no auth required)
- `notifications/initialized`: Returns HTTP 200 (no auth required)
- `tools/list`: Discovers and namespaces tools from all accessible resources
- `tools/call`: Routes to correct resource based on namespace prefix
- `resources/list`, `prompts/list`: Returns empty lists (extensible)
- `ping`: Returns empty result

**MCP Methods (Path-Based Direct Access):**
All methods are forwarded transparently to the resource, only adding authentication.

## Admin API & UI

- **Admin API** (`admin/routes.py`) — JWT-authenticated REST endpoints under `/api/admin/*` for agent/resource/DCR/audit CRUD. See `docs/OPERATIONS.md`.
- **Admin UI** (`okta_agent_proxy_admin_ui/`) — Next.js console at `http://localhost:3001`, NextAuth with Okta OIDC. The adapter's admin API accepts **only Okta OAuth access tokens** (v0.15.x+; password login was removed). See its `README.md`.

## Protected Resource Metadata (RFC 9728)

The gateway exposes OAuth discovery endpoints:

- `/.well-known/oauth-protected-resource`: Resource server metadata
- `/.well-known/oauth-authorization-server`: Modified Okta discovery (BFF pattern)
- `/.well-known/oauth/registration`: Dynamic Client Registration (RFC 7591)

These enable automatic OAuth client configuration.

## DCR Allowed Redirect Patterns

Controls which `redirect_uris` are accepted during Dynamic Client Registration. Stored in `gateway_config` table (key `dcr.allowed_redirect_patterns`). Precedence: DB > `DCR_ALLOWED_REDIRECT_PATTERNS` env seed > hardcoded defaults (localhost + 127.0.0.1).

**Cache:** L1 per-`DCRPolicy` with 300s safety-net TTL. Cross-worker invalidation via `CacheEventBus` pub/sub on `dcr_patterns_invalidate` (Redis only; single-pod is a no-op). On admin PUT: persist → invalidate L1 → publish → each worker's callback invalidates its L1. TTL guarantees consistency within 300s if pub/sub fails.

Validation logic is authoritative in `auth/redirect_pattern_validator.py`. Managed via Admin UI (Settings → DCR Policy) and `GET/PUT /api/admin/dcr/policy/redirect-patterns`.

## Audit & Observability

Structured JSON audit events flow through an async queue-backed `AuditEventEmitter` to pluggable sinks (stdout / file / webhook). Configure via `AUDIT_SINKS`. See `docs/AUDIT_AND_SIEM.md` and `deploy/observability/README.md`.

## Docker Deployment

Full stack in `docker-compose.yml` (adapter, postgres, redis, admin-ui, hr-mcp-server, deploy-mcp-server). Bootstrap with `./setup.sh` (generates keys, builds, seeds). Observability overlay: `deploy/observability/docker-compose.observability.yml`.

## Troubleshooting & Key Files

- Troubleshooting: see `docs/OPERATIONS.md`.
- Core proxy code: `okta_agent_proxy/{proxy,auth,routing,mcp,admin,storage,cache,audit,okta_admin}/`. Use Grep/Glob to find specifics.
