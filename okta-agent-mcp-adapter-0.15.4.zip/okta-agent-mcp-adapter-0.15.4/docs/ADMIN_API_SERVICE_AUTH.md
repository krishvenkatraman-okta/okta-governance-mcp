# Admin API Service-App Authentication

The adapter's admin API (`/api/admin/*`) accepts Okta OAuth access tokens from
two principal types:

1. **Human admins** — tokens from the Admin UI (authorization_code flow).
2. **Service apps** — tokens from an Okta API Services Integration
   (`client_credentials` + `private_key_jwt`). Intended for unattended
   automation: CI/CD pipelines, integration tests, scripted provisioning.

Both token types are issued by the Okta **org** authorization server and
validated against the same JWKS. This document covers the service-app path.

## When to use service-app tokens

Use service-app tokens when the caller is not a human and cannot complete a
browser-based login:

- CI/CD pipelines that seed agents/resources before running tests.
- Integration test suites that need to call the admin API with a real token.
- Scripts that bulk-provision configuration.

For interactive human access, keep using the Admin UI.

## Okta setup

1. In the Okta Admin Console: **Applications → Applications → Create App
   Integration → API Services**.
2. Give the app a recognisable name (e.g., `mcp-adapter-ci`).
3. On the created app's **General** tab, set **Client authentication** to
   **Public key / Private key**.
4. **Public Keys → Add key** — either paste the public JWK you generate locally
   or let Okta generate a key pair (download the private JWK; Okta retains
   only the public JWK).
5. Under **General Settings → Client Credentials**, confirm the
   **Grant type** `Client Credentials` is selected.
6. **Okta API Scopes** tab — grant the same management scopes the Admin UI
   requests at login, so the service app can hit every route a human admin
   can. The Admin UI's NextAuth config
   ([`okta_agent_proxy_admin_ui/lib/auth.ts`](../okta_agent_proxy_admin_ui/lib/auth.ts))
   requests:

   | Scope                              | Why it's needed                                     |
   | ---------------------------------- | --------------------------------------------------- |
   | `okta.aiAgents.read`               | List / read Okta AI Agents for import + sync        |
   | `okta.aiAgents.manage`             | Register signing keys, manage AI Agent records      |
   | `okta.apps.read`                   | Read linked OIDC apps (client_id, metadata)         |
   | `okta.groups.read`                 | Resolve group membership during import              |
   | `okta.authorizationServers.read`   | Introspect custom authorization servers             |

   The OIDC identity scopes (`openid`, `email`, `profile`) that the Admin UI
   also requests do **not** apply to service-app tokens — `client_credentials`
   issues no ID token and Okta's org AS rejects those scopes on this grant.

   Credential-automation endpoints that fetch an app's client_secret
   additionally require **`okta.apps.manage`**; the Admin UI prompts for
   this scope on-demand rather than at login (see
   `okta_agent_proxy_admin_ui/app/dashboard/agents/[agentId]/page.tsx`).
   Grant it to the service app if your automation rotates secrets.

7. Copy the **Client ID** — you'll need it for the adapter allowlist.

> **Why `private_key_jwt`?** It's Okta's recommended auth method for service
> apps: no client secret sits in your CI environment. If your CI secret store
> only supports strings, use `client_secret_jwt` or `client_secret_basic`
> instead — both will work the same way from the adapter's perspective as
> long as the token passes JWKS validation.

## Adapter setup

Add the service app's `client_id` to `ADMIN_API_SERVICE_CLIENT_IDS` in the
adapter's `.env`:

```
ADMIN_API_SERVICE_CLIENT_IDS=0oaYourServiceAppClientId
```

Multiple values are comma-separated:

```
ADMIN_API_SERVICE_CLIENT_IDS=0oaCiApp,0oaReleaseApp,0oaTestHarness
```

**Unset/empty disables service-app auth entirely.** Human Admin UI tokens
continue to work either way.

Restart the adapter after editing `.env`:

```
docker compose up -d --force-recreate okta-agent-mcp-adapter
```

## Minting a token with `admin_token.sh`

For interactive curl use and CI, the repo ships
[`ops_scripts/admin_token.sh`](../ops_scripts/admin_token.sh). It builds a
signed client assertion, exchanges it at Okta's org token endpoint, and
emits a shell `export` line on stdout — so you can hide the token from the
terminal with `eval`:

```bash
export ADMIN_SERVICE_CLIENT_ID=0oaYourServiceAppClientId
export ADMIN_SERVICE_PRIVATE_KEY_FILE=~/.okta/service-app.jwk.json
export OKTA_DOMAIN=dev-XXXXX.okta.com
# Default scope list mirrors the Admin UI's NextAuth config. Override only
# if you need a narrower set or have granted okta.apps.manage for rotation:
# export ADMIN_SERVICE_SCOPE="okta.aiAgents.read okta.aiAgents.manage okta.apps.read okta.apps.manage okta.groups.read okta.authorizationServers.read"

eval "$(./ops_scripts/admin_token.sh)"

curl -s -H "Authorization: Bearer $ADMIN_TOKEN" \
     http://localhost:8000/api/admin/agents | jq
```

What the script does for you:

- Signs the RFC 7523 assertion (`iss=sub=client_id`, `aud=<token endpoint>`,
  `exp=+60s`) with RS256 using the JWK you provide.
- POSTs `grant_type=client_credentials` +
  `client_assertion_type=urn:ietf:params:oauth:client-assertion-type:jwt-bearer`.
- Verifies the `cid` on the returned access token matches your client_id —
  catches most misconfigured-app mistakes before the token reaches the
  adapter.
- **Refuses to emit the token when stdout is a TTY**, so forgetting to wrap
  the call in `eval` will not leak the token into shell history / scrollback.
- Writes only the `export` line to stdout; diagnostics (cid, scope, expiry)
  go to stderr. `--quiet` silences stderr for fully quiet CI use.

Flags override the env vars:

```bash
./ops_scripts/admin_token.sh \
  --client-id 0oaOther \
  --key-file ./other.jwk.json \
  --domain dev-456.okta.com \
  --scope "okta.aiAgents.read okta.apps.read" \
  --var OTHER_TOKEN
```

Dependencies (`python-jose`, `httpx`) are already in `requirements.txt`; the
script uses `./venv/bin/python` when available, else `python3`.

### Rolling your own

If you need to mint tokens from a language without a Python runtime, the raw
exchange is:

```bash
curl -X POST "https://${OKTA_DOMAIN}/oauth2/v1/token" \
  -H "Content-Type: application/x-www-form-urlencoded" \
  -d "grant_type=client_credentials" \
  -d "client_id=${CLIENT_ID}" \
  -d "client_assertion_type=urn:ietf:params:oauth:client-assertion-type:jwt-bearer" \
  -d "client_assertion=${CLIENT_ASSERTION}" \
  -d "scope=okta.aiAgents.read okta.aiAgents.manage okta.apps.read okta.groups.read okta.authorizationServers.read"
# → { "access_token": "eyJ…", "expires_in": 3600, ... }
```

`${CLIENT_ASSERTION}` is an RS256-signed JWT with `iss=sub=client_id`,
`aud=https://${OKTA_DOMAIN}/oauth2/v1/token`, `exp=now+60s`, and a `kid`
header matching your uploaded public JWK.

> Scopes matter on the **Okta** side — the service app must have each
> requested scope granted on its **Okta API Scopes** tab, and the routes
> under `okta_import_routes.py` probe the token's scopes against the Okta
> Management API directly. The adapter itself does not yet enforce a
> baseline scope on admin-API routes beyond the `cid` allowlist; that's
> tracked as follow-up hardening.

## Audit attribution

When a service-app token acts on the admin API, audit events are attributed
to the service app, not a user:

```json
{
  "event_type": "config.agent.created",
  "actor": {
    "user_id": "service_app:0oaYourServiceAppClientId",
    "client_id": "0oaYourServiceAppClientId"
  },
  ...
}
```

The `user_id` prefix makes service-app events easy to filter in SIEM
tooling. `client_id` carries the raw `cid` for programmatic correlation with
the Okta app's audit log.

## Rotation

Rotate the service app's signing key on the cadence required by your
compliance posture:

1. Generate a new key pair.
2. Add the new public JWK in Okta (leave the old one attached during the
   overlap window).
3. Update your CI secret store with the new private JWK.
4. After CI is confirmed working with the new key, remove the old public JWK
   from Okta.

The adapter needs no changes — it validates against Okta's JWKS, which Okta
updates automatically when you add or remove keys.

## Troubleshooting

**401 on every request.** Check `ADMIN_API_SERVICE_CLIENT_IDS` actually
contains the `cid`. Inspect adapter logs for `Service-app token rejected`.
If the env var is unset, the log will say so explicitly.

**Token mints successfully but adapter rejects it.** Confirm the token
issuer matches the adapter's `OKTA_DOMAIN`. Both the Admin UI and the
service-app token must come from the **org** authorization server (issuer
`https://{OKTA_DOMAIN}`), not a custom authorization server (issuer
`https://{OKTA_DOMAIN}/oauth2/{authServerId}`).

**Route returns 403 `okta_auth_required`.** The route is one of the
Okta-sync endpoints (`okta_import_routes.py`) that additionally probes
Okta Management API scopes. Service-app tokens with `okta.aiAgents.*`
scopes granted in the Okta app will pass; otherwise use a human token for
those sync operations.

## See also

- `docs/OPERATIONS.md` — general admin API operations.
- `reports/security-audit-cache-auth-crypto.md` — hardening follow-ups
  (audience pinning, baseline scope enforcement).
