# Credential Automation

Automated provisioning of client secrets and signing keys for Okta AI Agent configurations in the adapter.

## Overview

The credential automation feature eliminates manual copy-paste of secrets and private keys when configuring agents. Instead of extracting credentials from the Okta Admin Console and entering them into the adapter, admins can click a button in the Admin UI to:

1. **Fetch client secrets** from the Okta app linked to an AI Agent
2. **Generate RSA key pairs** and register the public key with the Okta AI Agent

All operations use the admin user's own Okta OIDC access token — the adapter does not store service app credentials for this purpose.

## Architecture

```
┌─────────────┐     ┌──────────────────────┐     ┌─────────────┐
│  Admin UI    │────>│  Adapter Admin API    │────>│  Okta APIs  │
│  (browser)   │     │                      │     │             │
│              │     │  Admin's Okta token   │     │ /apps/      │
│  Has admin's │     │  passed through ──────│────>│ /ai-agents/ │
│  Okta token  │     │                      │     │             │
└─────────────┘     │  CredentialAutomation │     └─────────────┘
                    │  Service              │
                    │       │               │
                    │       v               │
                    │  ┌──────────────┐     │
                    │  │ PostgreSQL    │     │
                    │  │ (AES-256-GCM) │     │
                    │  └──────────────┘     │
                    └──────────────────────┘
```

**Components:**

| Component | File | Role |
|-----------|------|------|
| `OktaAPIClient` | `okta_admin/client.py` | Stateless HTTP proxy — forwards admin's Bearer token to Okta Management APIs |
| `ClientSecretFetcher` | `okta_admin/secret_fetcher.py` | Fetches/generates app secrets via `/api/v1/apps/{id}/credentials/secrets` |
| `AgentKeyManager` | `okta_admin/key_manager.py` | Local RSA key generation + public key registration via `/workload-principals/api/v1/ai-agents/{id}/credentials/jwks` |
| `CredentialAutomationService` | `okta_admin/service.py` | Orchestrator — combines fetcher, key manager, and config store |
| Admin routes | `admin/credential_routes.py` | HTTP endpoints with error mapping |

## Prerequisites

1. **Agent must have `okta_ai_agent_id` set.** Import the agent from Okta first (Dashboard > Agents > Import from Okta), or set it manually via the Configuration tab.

2. **Admin's OIDC app must have required Okta API scopes granted:**
   - `okta.apps.manage` — for fetching/generating client secrets
   - `okta.aiAgents.manage` — for registering public keys with AI Agents

   Grant these in Okta Admin Console > Applications > [Admin UI app] > Okta API Scopes.

3. **Admin user must have an Okta admin role** with permissions covering Apps and AI Agents management.

## Usage

### Via Admin UI

1. Navigate to **Dashboard > Agents > [agent name] > Configuration** tab
2. The **Credential Status** card shows what is configured:
   - Client Secret: Configured / Not Configured
   - Signing Key: Configured / Not Configured (with kid if available)
   - Registered Okta JWKs (if your token has scope to query them)
3. Click **"Fetch Secret from Okta"** to retrieve or generate a client secret
4. Click **"Generate & Register New Key"** to create an RSA key pair
5. Manual entry remains available under the collapsible **Manual Configuration** section

### Via API

#### Fetch Client Secret

```bash
curl -X POST \
  https://adapter.example.com/api/admin/agents/{agent_id}/credentials/fetch-secret \
  -H "Authorization: Bearer <admin_okta_token>"
```

Response:
```json
{
  "status": "success",
  "source": "fetched_existing",
  "app_id": "0oaABC123"
}
```

The `source` field is either `"fetched_existing"` (used an active secret from the app) or `"generated_new"` (generated a new secret because none were active).

#### Generate Key Pair

```bash
curl -X POST \
  https://adapter.example.com/api/admin/agents/{agent_id}/credentials/generate-keypair \
  -H "Authorization: Bearer <admin_okta_token>"
```

Response:
```json
{
  "status": "success",
  "kid": "550e8400-e29b-41d4-a716-446655440000",
  "agent_id": "claude-code"
}
```

The public key is registered with Okta. The private key is stored encrypted in the adapter's database. Neither is returned in the API response.

#### Get Credential Status

```bash
curl \
  https://adapter.example.com/api/admin/agents/{agent_id}/credentials/status \
  -H "Authorization: Bearer <admin_okta_token>"
```

Response:
```json
{
  "has_client_secret": true,
  "has_private_key": true,
  "registered_keys": [
    {"kid": "550e8400-...", "alg": "RS256"}
  ],
  "okta_agent_id": "agtABC123"
}
```

## Error Reference

| HTTP Code | Error | Meaning | Resolution |
|-----------|-------|---------|------------|
| 400 | `invalid_request` | Agent has no `okta_ai_agent_id` | Import agent from Okta or set the ID manually |
| 401 | `okta_auth_error` | Admin's Okta token expired or invalid | Re-authenticate in Admin UI |
| 403 | `okta_forbidden` | Insufficient Okta API scopes | Grant `okta.apps.manage` / `okta.aiAgents.manage` to the admin's OIDC app |
| 404 | `not_found` | Agent not found in adapter, or Okta AI Agent / app not found | Verify `okta_agent_id` is correct |
| 502 | `okta_api_error` | Okta Management API returned an error | Check Okta System Log for details |

## Security Considerations

- **Principle of least privilege**: Operations use the admin user's own Okta permissions. The adapter does not have standing service credentials for management APIs.
- **No stored admin tokens**: The admin's Okta access token is extracted from each HTTP request and passed through. It is never cached or persisted.
- **Private keys never leave the adapter**: Only public JWKs are sent to Okta. Private keys are encrypted with AES-256-GCM and stored in PostgreSQL.
- **Secrets encrypted at rest**: Client secrets are encrypted with AES-256-GCM before storage, same as all other sensitive fields.
- **No secret values in responses**: API responses contain status indicators (`has_client_secret: true`) but never actual secret values or private key material.
- **No secret values in logs**: All logging carefully avoids including token, secret, or key material.
- **Auditability**: All operations are performed under the admin user's Okta identity and appear in the Okta System Log tied to that user.
- **Admin authentication required**: All endpoints are protected by the `@admin_required` decorator, requiring a valid admin session.
