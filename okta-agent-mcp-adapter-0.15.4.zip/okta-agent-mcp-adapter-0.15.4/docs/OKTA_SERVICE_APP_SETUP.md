# Okta Service App for Event-Triggered Sync

The adapter can authenticate to Okta's Management APIs using its own service identity (no admin user session required). This is used for event-triggered operations like automatic agent sync.

## Step 1: Create API Services Application

1. Okta Admin Console → **Applications > Applications**
2. **Create App Integration** → **API Services**
3. Name: `MCP Adapter Service`
4. Save. Note the **Client ID** → this becomes `OKTA_SERVICE_CLIENT_ID`

## Step 2: Configure Client Authentication

1. Go to the app's **General** tab → **Client Credentials** section
2. Change authentication method to **Public key / Private key**
3. Click **Add Key** → paste the adapter's public JWK:

```bash
curl http://localhost:8000/oauth/jwks.json | jq '.keys[0]'
```

4. Save. The adapter uses this key to sign JWT assertions for token requests.

## Step 3: Grant Okta API Scopes

1. Go to the **Okta API Scopes** tab
2. Click **Grant** next to each required scope:

| Scope | Purpose |
|-------|---------|
| `okta.aiAgents.read` | List and read AI Agent details |
| `okta.aiAgents.manage` | Import and sync operations |
| `okta.apps.read` | Read linked OIDC app details |
| `okta.authorizationServers.read` | Match connections to adapter backends |

3. Verify each shows **Granted** (green checkmark)

## Step 4: Set Environment Variable

Add to your `.env` file:

```bash
OKTA_SERVICE_CLIENT_ID=0oaXXXXXXXX
```

The adapter uses the same signing key configured via `ADAPTER_SIGNING_KEY` (or auto-generates one at startup). No additional key configuration is needed.

## How It Works

The adapter uses the **private_key_jwt** client authentication method (RFC 7523):

1. Builds a JWT assertion: `iss=client_id, sub=client_id, aud={okta_domain}/oauth2/v1/token`
2. Signs with the adapter's private key (RS256)
3. POSTs to Okta's token endpoint with `grant_type=client_credentials`
4. Receives a short-lived access token with the granted scopes
5. Caches the token until 60 seconds before expiry

## Troubleshooting

| Symptom | Fix |
|---------|-----|
| `OKTA_SERVICE_CLIENT_ID not set` in logs | Set the env var from Step 4 |
| 401 `invalid_client` | Verify the public key in Okta matches the adapter's signing key |
| 403 `insufficient_scope` | Grant required scopes in Step 3 |
| Token request timeout | Check network connectivity to Okta domain |
| `No signing key available` | Set `ADAPTER_SIGNING_KEY` or let the adapter auto-generate one |
