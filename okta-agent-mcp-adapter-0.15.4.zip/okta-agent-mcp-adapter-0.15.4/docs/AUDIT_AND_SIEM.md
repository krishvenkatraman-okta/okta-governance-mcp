# Audit & SIEM Integration Guide

The Okta MCP Adapter emits structured JSON audit events for every security-relevant action. This guide covers configuration, event schema, sink options, and SIEM integration patterns.

## Quick Start

Audit is enabled by default with stdout output. To send events to a SIEM:

```bash
# .env
AUDIT_ENABLED=true
AUDIT_SINKS=stdout,webhook
AUDIT_WEBHOOK_URL=https://splunk-hec.example.com:8088/services/collector
AUDIT_WEBHOOK_TOKEN=your-hec-token
```

## Configuration Reference

| Variable | Default | Description |
|----------|---------|-------------|
| `AUDIT_ENABLED` | `true` | Master switch for audit emission |
| `AUDIT_SINKS` | `stdout` | Comma-separated sink list: `stdout`, `file`, `webhook` |
| `AUDIT_FILE_PATH` | `/app/logs/audit.jsonl` | Path for file sink (JSONL with rotation) |
| `AUDIT_WEBHOOK_URL` | *(none)* | HTTP endpoint (e.g., Splunk HEC URL) |
| `AUDIT_WEBHOOK_TOKEN` | *(none)* | Bearer/HEC token sent as `Authorization: Splunk <token>` |
| `AUDIT_WEBHOOK_BATCH_SIZE` | `100` | Max events per HTTP request |
| `AUDIT_WEBHOOK_FLUSH_INTERVAL_MS` | `1000` | Periodic flush interval (ms) |
| `AUDIT_WEBHOOK_TIMEOUT_MS` | `5000` | HTTP request timeout (ms) |
| `AUDIT_WEBHOOK_RETRY_MAX` | `3` | Max retries with exponential backoff |

## Event Schema (v1.0)

Every audit event is a JSON object with a stable schema:

```json
{
  "schema_version": "1.0",
  "event_type": "mcp.tool.call",
  "severity": "info",
  "severity_id": 1,
  "time": "2026-03-05T12:34:56.789012+00:00",
  "correlation_id": "req-abc123",
  "source": {
    "service": "okta-mcp-adapter",
    "version": "1.0.0",
    "instance_id": "gateway-1"
  },
  "actor": {
    "agent_id": "claude-code",
    "user_id": "user@example.com",
    "client_id": "0oa_xxx",
    "ip_address": "10.0.0.1",
    "user_agent": "claude-code/1.0"
  },
  "details": {
    "tool_name": "hr-system__get_employee",
    "backend": "hr-system"
  },
  "outcome": "success"
}
```

### Event Types

| Event Type | Severity | Description |
|------------|----------|-------------|
| `mcp.tool.call` | info | MCP tool invocation |
| `mcp.tool.list` | info | Tool catalog discovery |
| `mcp.session.created` | info | New MCP session initialized |
| `mcp.session.terminated` | info | MCP session ended |
| `auth.jwt.validated` | info | JWT successfully validated |
| `auth.jwt.rejected` | warning | JWT validation failed |
| `authz.access.granted` | info | Agent authorized for resource |
| `authz.access.denied` | warning | Agent denied access to resource |
| `token.exchange.success` | info | ID-JAG token exchange succeeded |
| `token.exchange.failure` | warning | Token exchange failed |
| `token.cache.hit` | info | Resource token served from cache |
| `token.cache.miss` | info | Cache miss, token exchange needed |
| `admin.login` | info | Admin API login success |
| `admin.login.failure` | warning | Admin API login failure |
| `admin.config.change` | info | Generic config change |
| `config.agent.created` | info | Agent configuration created |
| `config.agent.updated` | info | Agent configuration updated |
| `config.agent.deleted` | warning | Agent configuration deleted |
| `config.backend.created` | info | Resource configuration created |
| `config.backend.updated` | info | Resource configuration updated |
| `config.backend.deleted` | warning | Resource configuration deleted |

### Severity Levels

| Level | ID | Usage |
|-------|----|-------|
| `info` | 1 | Normal operations |
| `warning` | 2 | Access denials, failed auth, deletions |
| `critical` | 3 | System-level failures |

## Sinks

### stdout

Prints one JSON line per event to stdout. Useful for container log aggregation (Docker, Kubernetes) where a log shipper (Fluentd, Fluent Bit, Vector) forwards stdout to a SIEM.

```bash
AUDIT_SINKS=stdout
```

### file

Writes JSONL to a rotating file. Default: 100 MB per file, 5 backup files.

```bash
AUDIT_SINKS=file
AUDIT_FILE_PATH=/app/logs/audit.jsonl
```

### webhook

Sends batched NDJSON payloads to an HTTP endpoint. Designed for Splunk HEC but works with any endpoint that accepts NDJSON.

```bash
AUDIT_SINKS=webhook
AUDIT_WEBHOOK_URL=https://splunk-hec.example.com:8088/services/collector
AUDIT_WEBHOOK_TOKEN=your-hec-token
```

**Wire format (Splunk HEC NDJSON):**

Each line is a Splunk HEC envelope:

```json
{"event": {<audit event>}, "time": 1709641234.567, "sourcetype": "okta:mcp:audit"}
{"event": {<audit event>}, "time": 1709641234.789, "sourcetype": "okta:mcp:audit"}
```

**Retry behavior:**

- Transient errors (5xx, network failures) are retried up to `AUDIT_WEBHOOK_RETRY_MAX` times
- Exponential backoff: 0.5s, 1s, 2s, ...
- Client errors (4xx) are not retried
- Events are dropped after all retries are exhausted (logged as error)

**Multiple sinks:**

You can enable multiple sinks simultaneously:

```bash
AUDIT_SINKS=stdout,webhook
```

## SIEM Integration Patterns

### Splunk

1. Create an HTTP Event Collector (HEC) token in Splunk
2. Set the sourcetype to `okta:mcp:audit` (auto-set by the webhook sink)
3. Configure:

```bash
AUDIT_SINKS=webhook
AUDIT_WEBHOOK_URL=https://splunk:8088/services/collector
AUDIT_WEBHOOK_TOKEN=<hec-token>
```

**Splunk SPL examples:**

```spl
# All access denials in the last hour
index=main sourcetype="okta:mcp:audit" event_type="authz.access.denied"
| stats count by actor.agent_id, details.backend

# Tool usage by agent
index=main sourcetype="okta:mcp:audit" event_type="mcp.tool.call"
| timechart count by actor.agent_id

# Failed auth attempts
index=main sourcetype="okta:mcp:audit" event_type="auth.jwt.rejected"
| stats count by actor.ip_address
```

### Datadog

Use the webhook sink pointed at Datadog's HTTP log intake:

```bash
AUDIT_WEBHOOK_URL=https://http-intake.logs.datadoghq.com/api/v2/logs
AUDIT_WEBHOOK_TOKEN=<dd-api-key>
```

Note: You may need to adjust the `Authorization` header format. The webhook sink sends `Authorization: Splunk <token>`. For Datadog, you can use a log pipeline or a reverse proxy to transform the header.

### Elastic / OpenSearch

Point the webhook at an Elasticsearch bulk API endpoint or use Filebeat to ship the file sink output.

### Container Log Aggregation (Fluentd / Fluent Bit)

Use the `stdout` sink and configure your log shipper to parse JSON:

```yaml
# Fluent Bit example
[INPUT]
    Name   tail
    Path   /var/log/containers/okta-mcp-adapter*.log
    Parser json

[FILTER]
    Name   grep
    Match  *
    Regex  log schema_version
```

## Admin API Audit Endpoints

Query the PostgreSQL audit log via the Admin API:

```bash
# All audit entries (last 100)
GET /api/admin/audit

# Filter by entity type and ID
GET /api/admin/audit?entity_type=agent&entity_id=claude-code&limit=50

# Agent-specific audit trail
GET /api/admin/agents/{agent_id}/audit

# Resource-specific audit trail
GET /api/admin/backends/{name}/audit
```

These endpoints return the PostgreSQL-stored audit log (config change history), not the real-time event stream. Use SIEM queries for real-time event analysis.

## Architecture

```
┌─────────────────────────────────────────────┐
│              Application Code               │
│                                             │
│  emit_audit_event(type, details, ...)       │
│          │                                  │
│          v                                  │
│  ┌───────────────────┐                      │
│  │ AuditEventEmitter │  asyncio.Queue       │
│  │   (background)    │  (10k buffer)        │
│  └───────┬───────────┘                      │
│          │ drain loop (1s interval)         │
│          v                                  │
│  ┌─────────────┐ ┌──────────┐ ┌──────────┐ │
│  │ StdoutSink  │ │ FileSink │ │ Webhook  │ │
│  │   (sync)    │ │ (rotate) │ │  Sink    │ │
│  └─────────────┘ └──────────┘ └────┬─────┘ │
│                                     │       │
└─────────────────────────────────────┼───────┘
                                      │ HTTPS
                                      v
                              ┌──────────────┐
                              │  Splunk HEC  │
                              │  Datadog     │
                              │  Elastic     │
                              └──────────────┘
```

## Correlation

Every request gets a `correlation_id` (set via `contextvars`). All audit events within the same request share this ID, making it easy to trace a complete request lifecycle across events:

1. `auth.jwt.validated` (correlation_id=abc123)
2. `authz.access.granted` (correlation_id=abc123)
3. `token.cache.hit` (correlation_id=abc123)
4. `mcp.tool.call` (correlation_id=abc123)

Use the correlation ID in SIEM queries to reconstruct full request traces.
