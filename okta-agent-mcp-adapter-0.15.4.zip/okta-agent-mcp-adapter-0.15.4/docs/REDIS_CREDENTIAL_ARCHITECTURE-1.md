**Okta MCP Adapter**

**Redis Credential Provider Architecture**

*Eliminating long-lived Redis passwords for regulated deployments*

Document version: 1.0 (May 2026\)

Audience: enterprise architects, security review teams, platform engineering

# **1\. Executive Summary**

Several regulated customers have raised the same finding during security review of the Okta MCP Adapter: the Redis cache is authenticated with a static, long-lived username/password pair held in environment variables, secrets stores, and Infrastructure-as-Code outputs. This pattern fails internal controls that prohibit shared, rotation-free credentials for backing data stores — even when the data store is on a private subnet, even when the credential is held in a managed secrets vault.

The finding is correct. The fix is not a cache redesign; it is a credential layer redesign. AWS ElastiCache (Redis 7.0+) and Azure Managed Redis (default for new caches) both natively support short-lived, identity-based authentication that issues fresh credentials per connection. This document specifies a Redis credential provider abstraction that lets the adapter authenticate to Redis without holding any long-lived shared secret, while preserving the existing cache code paths and keeping a gated static-password mode for local development.

### **What changes**

* A new RedisCredentialProvider abstraction in okta\_agent\_proxy/cache/redis\_credentials.py with five concrete implementations: AWS IAM (ElastiCache), Microsoft Entra (Azure Managed Redis), mutual TLS, HashiCorp Vault dynamic secrets, and a gated static-password fallback.

* RedisCacheProvider and the pub/sub event bus reconnect on a schedule driven by the credential's expiration, picking up fresh material before the existing connection is rejected.

* Every credential mint emits an audit event with the principal identity, expiry, and provider type — reviewers see ephemeral auth in the audit trail, not just access logs.

* Static-password mode requires ALLOW\_STATIC\_REDIS\_PASSWORD=true to start; a HIGH-severity warning is emitted on every startup that uses it. Production Bicep and Terraform templates default to the identity-based providers.

### **What does not change**

* Cache key layout, TTL behaviour, encryption-at-rest model (AES-256-GCM via the EncryptionService), and pub/sub channel semantics are untouched.

* CacheService, TokenCache, ConfigCache, UserTokenStore, and all consumers continue to call the same async methods. The credential change is below them.

* Local development with Docker Compose continues to work with a one-line gate change.

# **2\. Problem Statement**

## **2.1 What customers are seeing today**

The current adapter accepts Redis credentials only as a static string. CacheService.create\_from\_env reads REDIS\_PASSWORD and concatenates it into the connection URL:

\# okta\_agent\_proxy/cache/cache\_service.py (lines \~100-115)  
url \= redis\_url or "redis://localhost:6379"  
key\_prefix \= os.getenv("REDIS\_KEY\_PREFIX", "okta-mcp:")  
ssl \= os.getenv("REDIS\_TLS\_ENABLED", "false").lower() \== "true"  
password \= os.getenv("REDIS\_PASSWORD")  
if password and "://" in url and "@" not in url:  
    scheme, rest \= url.split("://", 1\)  
    url \= f"{scheme}//:{password}@{rest}"  
l2 \= RedisCacheProvider(redis\_url=url, ...)

In our reference cloud deployments, this credential is provisioned once at deploy time and never rotated. Specifically:

| Deployment | How Redis is authenticated today | Reviewer-visible problem |
| :---- | :---- | :---- |
| AWS ECS Fargate (deploy/aws-ecs) | random\_password.redis\_password generated at terraform apply, stored in AWS Secrets Manager and used as ElastiCache auth\_token | Same 32-character string lives in Secrets Manager and ECS task env for the lifetime of the deployment. No rotation. |
| Azure Container Apps (deploy/azure-aca) | Azure Cache for Redis primary access key, passed into the container as REDIS\_PASSWORD | Access key is a long-lived shared secret. Reviewers treat it the same as a password in source code. |
| Docker Compose (dev) | Literal REDIS\_PASSWORD=redis-secret in .env.example | Default credentials in source-controlled samples are flagged by static analysis as a control failure. |

## **2.2 Why the cache architecture itself is fine**

Before re-architecting, it's worth confirming what reviewers are not objecting to. The two-tier cache (L1 in-process, L2 Redis), the AES-256-GCM serializer for L2 entries, the pub/sub invalidation channels, the SHA-256 hashing of token keys — none of this is the problem. Reviewers consistently approved the data-at-rest model. The objection is one layer down: how the adapter proves to Redis that it is allowed to read and write those encrypted blobs.

## **2.3 Control statements being failed**

The specific controls being cited are consistent across the customers who have raised this:

* PCI-DSS 4.0 §8.6.1: Application and system accounts that can be used for interactive logon must be managed; passwords used for application access cannot be hard-coded.

* PCI-DSS 4.0 §8.6.3: Passwords for application accounts must be changed periodically and the period must be defined and enforced.

* Internal: any credential that authenticates to a backing data store must either rotate automatically on a defined cadence (typically ≤90 days) or be issued per-session with a lifetime measured in minutes.

* Internal: no shared secret may be issued without an associated revocation path that does not require a deployment.

A Terraform-generated random\_password fails control 1 (it is hard-coded once and never changes), control 2 (no rotation), control 3 (lifetime is the lifetime of the deployment), and control 4 (revocation requires a redeploy).

# **3\. Solution Overview**

We introduce a credential provider seam at the Redis connection layer. The provider is responsible for producing fresh connection credentials on demand and for telling its caller when those credentials will expire. The cache code never sees a string password; it sees a credential object that knows how to mint itself.

## **3.1 The seam**

okta\_agent\_proxy/cache/  
├── base.py                     \# CacheProvider abstract (unchanged)  
├── cache\_service.py            \# accepts a RedisCredentialProvider  
├── redis\_provider.py           \# asks the provider for credentials  
├── redis\_credentials.py        \# NEW — provider abstraction \+ factory  
└── redis\_credential\_providers/ \# NEW  
    ├── static\_password.py      \# gated, dev-only  
    ├── aws\_iam.py              \# ElastiCache IAM (SigV4 → 15-min token)  
    ├── azure\_entra.py          \# Microsoft Entra (MSAL → \~1-hr token)  
    ├── mtls.py                 \# X.509 client cert, no AUTH password  
    └── vault\_dynamic.py        \# Vault Redis secrets engine

## **3.2 The contract**

class RedisCredentials(NamedTuple):  
    username: Optional\[str\]      \# None for AUTH-password-only mode  
    password: Optional\[str\]      \# None for mTLS  
    expires\_at: Optional\[datetime\]   \# None for non-expiring (static, mTLS)  
    ssl\_context: Optional\[ssl.SSLContext\]  \# populated for mTLS  
    principal: str               \# IAM role ARN, managed identity OID, etc.  
   
class RedisCredentialProvider(ABC):  
    name: str  
   
    @abstractmethod  
    async def get\_credentials(self) \-\> RedisCredentials: ...  
   
    @abstractmethod  
    def refresh\_safety\_window(self) \-\> timedelta:  
        """How far before expiry to refresh. Default 25% of TTL,  
        floored at 60 seconds."""  
   
    async def health\_check(self) \-\> bool:  
        """Returns True when the provider can mint credentials."""

## **3.3 How the connection lifecycle works**

On every Redis client construction (initial connect, reconnect after error, scheduled refresh), the credential provider is asked for fresh credentials. The Redis client wrapper schedules a reconnect for refresh\_at \= expires\_at − safety\_window. When that timer fires, a new client is built and atomically swapped in; the old client is allowed to drain in-flight commands and is then closed.

This pattern matches both AWS and Azure guidance:

* AWS ElastiCache IAM tokens are valid for 15 minutes; AWS recommends generating a new token *on every connection establishment* rather than storing the token. The Redis AUTH command is replayed when the connection re-establishes.

* Azure Managed Redis Entra tokens are typically valid for \~1 hour; Microsoft explicitly recommends sending a new token *at least three minutes before token expiry* to avoid connection disruption, using AUTH after re-establishing the connection.

Both align cleanly with our model: each provider declares its own safety window (15% for IAM, \~5 minutes minimum for Entra), and the wrapper reconnects on schedule.

## **3.4 Selecting a provider**

A new environment variable, REDIS\_AUTH\_MODE, selects the provider. It defaults to static (with the gate flag below) so existing deployments do not break on upgrade. Valid values:

| REDIS\_AUTH\_MODE | Use case | Required env / config |
| :---- | :---- | :---- |
| aws-iam | AWS ElastiCache Redis 7.0+ in serverless or RBAC mode | AWS\_REGION, REDIS\_AWS\_USER\_ID, REDIS\_AWS\_CACHE\_NAME, REDIS\_AWS\_IS\_SERVERLESS |
| azure-entra | Azure Managed Redis or Azure Cache for Redis with Entra enabled | AZURE\_REDIS\_HOST, REDIS\_AZURE\_PRINCIPAL\_OID (defaults to MSI lookup) |
| mtls | Self-hosted Redis 6+ with TLS client cert auth | REDIS\_MTLS\_CERT\_PATH, REDIS\_MTLS\_KEY\_PATH, REDIS\_MTLS\_CA\_PATH |
| vault | HashiCorp Vault Redis secrets engine | VAULT\_ADDR, VAULT\_REDIS\_ROLE, VAULT\_AUTH\_METHOD |
| static | Local dev / Docker Compose only | REDIS\_PASSWORD \+ ALLOW\_STATIC\_REDIS\_PASSWORD=true |

# **4\. Provider Specifications**

## **4.1 AwsIamElastiCacheProvider**

AWS IAM authentication for ElastiCache for Valkey or Redis OSS 7.0+ (serverless or self-designed clusters with RBAC). The provider mints a SigV4-signed pre-signed URL whose query string acts as the AUTH password. The token is valid for 15 minutes. Mint cost is local (no network round-trip), so we re-mint on every reconnect rather than caching.

### **How it works**

* Boto3's AWS credential chain resolves the calling identity: ECS task role, EC2 instance role, EKS service account (IRSA), or ambient developer credentials in dev.

* The provider builds a pre-signed GET URL for elasticache:Connect against the resource ARN of the cache and the IAM-enabled ElastiCache user, with X-Amz-Expires=900 (15 minutes).

* The URL's query string (without scheme/host) is used as the Redis AUTH password; the Redis username is the IAM-enabled ElastiCache user ID, not the IAM role name.

* expires\_at is set to now \+ 15 minutes; refresh\_safety\_window returns 2.5 minutes (about 17%).

### **Required IAM policy**

{  
  "Version": "2012-10-17",  
  "Statement": \[{  
    "Effect": "Allow",  
    "Action": "elasticache:Connect",  
    "Resource": \[  
      "arn:aws:elasticache:\<region\>:\<account\>:serverlesscache:\<cache-name\>",  
      "arn:aws:elasticache:\<region\>:\<account\>:user:\<user-id\>"  
    \]  
  }\]  
}

### **ElastiCache user setup (one-time, via Terraform)**

resource "aws\_elasticache\_user" "adapter" {  
  user\_id              \= "okta-mcp-adapter"  
  user\_name            \= "okta-mcp-adapter"  
  engine               \= "REDIS"  
  authentication\_mode { type \= "iam" }  
  access\_string        \= "on \~\* \+@all"  
}  
   
resource "aws\_elasticache\_user\_group" "adapter" {  
  engine        \= "REDIS"  
  user\_group\_id \= "okta-mcp-adapter"  
  user\_ids      \= \[aws\_elasticache\_user.adapter.user\_id\]  
}

### **Failure modes and mitigations**

| Failure | Mitigation |
| :---- | :---- |
| AWS credential chain returns no creds (e.g. task role mis-assigned) | Provider raises CredentialUnavailableError on startup; adapter refuses to start. |
| IAM user disabled, ARN typo, missing elasticache:Connect | Redis returns AUTH error 'invalid username-password pair or user is disabled'. We catch this, audit, and the connection is retried with a fresh mint after 30s exponential backoff (max 5 minutes). |
| Clock skew \> 5 minutes | SigV4 signatures are time-bound. We log clock skew detected and recommend chrony/ntp; we do not silently fast-forward. |

## **4.2 EntraManagedIdentityProvider**

Microsoft Entra ID authentication for Azure Managed Redis (default since GA) and Azure Cache for Redis (Standard/Premium with Entra enabled). The provider acquires an access token from Entra via the Azure Identity SDK; tokens have a typical lifetime of \~1 hour. Username is the Object ID of the managed identity or service principal; password is the access token.

### **How it works**

* DefaultAzureCredential (or a more constrained ManagedIdentityCredential when REDIS\_AZURE\_USE\_MSI=true) resolves the workload identity in container apps, AKS workload identity, App Service, VM MI, or developer login locally.

* Token is acquired for scope https://redis.azure.com/.default.

* expires\_at is set from the token's exp claim; refresh\_safety\_window returns 5 minutes (matches Microsoft's published guidance).

* On the first call, the provider also resolves and caches the principal Object ID — this is the Redis username and does not change for the lifetime of the identity.

### **Cache configuration (one-time, via Bicep)**

resource cache 'Microsoft.Cache/redisEnterprise@2024-09-01-preview' \= {  
  name: cacheName  
  location: location  
  identity: { type: 'SystemAssigned' }  
  properties: { ... }  
}  
   
resource adapterAccessPolicy 'Microsoft.Cache/redisEnterprise/databases/accessPolicyAssignments@...' \= {  
  name: 'adapter-data-owner'  
  parent: cacheDb  
  properties: {  
    accessPolicyName: 'default'  
    user: { objectId: adapterIdentity.properties.principalId }  
  }  
}

### **Failure modes and mitigations**

| Failure | Mitigation |
| :---- | :---- |
| IMDS endpoint unreachable (e.g. network policy block) | DefaultAzureCredential raises CredentialUnavailableError with a clear chain trace. We surface this on startup and refuse to start. |
| Token revoked mid-flight (rare but possible) | Redis returns AUTH error on next reconnect. The reconnect path discards the cached token and asks Entra for a new one. |
| Conditional Access policy applied to the workload identity | Token request fails with AADSTS error. We audit the AADSTS code and surface it; this is a configuration issue that needs to be resolved by the customer's Entra admin. |

## **4.3 MtlsCertProvider**

X.509 client-certificate authentication for self-hosted Redis 6+ behind a TLS terminator. There is no AUTH password; the certificate's CN/SAN identifies the client and the Redis server's tls-auth-clients yes setting requires a valid client cert.

### **How it works**

* Provider reads cert/key/CA paths from environment variables and constructs an ssl.SSLContext with verify\_mode \= CERT\_REQUIRED.

* RedisCredentials.password is None; the SSLContext is passed through to redis-py's connection\_class=SSLConnection.

* expires\_at is set from the certificate's notAfter; refresh\_safety\_window returns 24 hours by default. When a SPIFFE/SPIRE workload API agent rotates the cert on disk, the file timestamp triggers a reload and reconnect.

### **Why this matters for customers with strict workload identity programs**

Several large enterprises have standardised on SPIFFE/SPIRE for workload identity. SPIRE issues short-lived X.509-SVIDs (typically 1 hour) and rotates them on disk. Our mTLS provider integrates with this without any code change: the path-based watcher sees the new cert, the reconnect timer fires, and the new identity is in effect on the next Redis connection. This pattern is already on the adapter's roadmap (ADR-003) for upstream identity; using it for Redis auth is a natural extension.

## **4.4 VaultDynamicProvider**

HashiCorp Vault's Redis Database secrets engine generates per-lease Redis ACL users with a configurable TTL. The provider authenticates to Vault (Kubernetes auth, AppRole, or AWS IAM auth — selected by VAULT\_AUTH\_METHOD), reads a credential at /database/creds/{role}, and uses the username/password returned for the lease's lifetime.

### **How it works**

* Vault returns a leased credential with a documented TTL (default 1 hour, configurable per role).

* expires\_at is set from now \+ lease\_duration.

* On refresh, the provider calls /sys/leases/renew with the lease ID up to its max\_ttl. After max\_ttl, a new credential is requested and the old user is automatically revoked by Vault.

* On graceful shutdown, the provider revokes its outstanding lease — no orphaned Redis users.

### **When to use this provider**

Customers running self-hosted Redis (not managed) and already using Vault for other dynamic secrets (Postgres, RabbitMQ, etc.) get an immediate consistent control surface. Vault's audit log records every credential issue and revocation. For customers without Vault, this provider is unnecessary; AWS-IAM, Entra, or mTLS will be a better fit.

## **4.5 StaticPasswordProvider (gated, dev-only)**

Preserves the current behaviour for local development with Docker Compose. Refuses to start unless ALLOW\_STATIC\_REDIS\_PASSWORD=true is explicitly set. Emits a HIGH-severity startup audit event so static-password use shows up in the same audit stream as a real production event.

\# Startup behaviour  
if mode \== "static":  
    if os.getenv("ALLOW\_STATIC\_REDIS\_PASSWORD") \!= "true":  
        raise ConfigError(  
            "REDIS\_AUTH\_MODE=static requires ALLOW\_STATIC\_REDIS\_PASSWORD=true. "  
            "Static Redis passwords are not permitted in production. "  
            "See docs/redis-credentials.md for IAM/Entra/mTLS alternatives."  
        )  
    log.warning("=" \* 72\)  
    log.warning("REDIS AUTH: USING STATIC PASSWORD MODE — NOT FOR PRODUCTION")  
    log.warning("This deployment will fail customer security review.")  
    log.warning("=" \* 72\)  
    await audit\_emit(REDIS\_STATIC\_PASSWORD\_USED, severity=HIGH, ...)

This gate is what production reviewers will grep for. A clean grep \-r ALLOW\_STATIC\_REDIS\_PASSWORD across the production Helm/Bicep/Terraform output is the deliverable evidence that the static path is not enabled.

# **5\. Implementation Plan**

The change is structured as four sequential phases. Each phase is independently deployable and reversible.

## **5.1 Phase 1 — Provider seam (no behaviour change)**

* Introduce redis\_credentials.py with the abstract provider, the StaticPasswordProvider, and a factory get\_redis\_credential\_provider().

* Refactor RedisCacheProvider to take a credential provider in its constructor and to call get\_credentials() on every client construction.

* Wire the existing REDIS\_PASSWORD path through StaticPasswordProvider with the gate disabled by default. Existing deployments continue to work; new deployments without the gate fail loudly.

* Add unit tests covering the provider lifecycle: construction, get\_credentials, expiry handling, reconnect-on-expiry.

## **5.2 Phase 2 — Cloud providers**

* Add AwsIamElastiCacheProvider with botocore SigV4 signing. Test against ElastiCache Serverless via integration tests gated by AWS\_INTEGRATION\_TESTS=true.

* Add EntraManagedIdentityProvider using azure-identity. Test against Azure Managed Redis via integration tests gated by AZURE\_INTEGRATION\_TESTS=true.

* Update deploy/aws-ecs/main.tf to remove random\_password.redis\_password, add aws\_elasticache\_user with iam authentication mode, and inject the IAM role's permissions. Drop REDIS\_PASSWORD from the ECS task definition.

* Update deploy/azure-aca/bicep/main.bicep to enable system-assigned managed identity on the container app, grant the data-owner access policy on the cache, and drop REDIS\_PASSWORD from the env.

## **5.3 Phase 3 — Self-hosted providers**

* Add MtlsCertProvider with file-system watch on the cert path.

* Add VaultDynamicProvider with Kubernetes-auth, AppRole, and AWS-IAM-auth Vault methods.

* Document SPIFFE/SPIRE integration recipe in docs/redis-credentials.md.

## **5.4 Phase 4 — Audit, observability, hardening**

* Add five new AuditEventType enum values: REDIS\_CREDENTIAL\_MINTED, REDIS\_CREDENTIAL\_REFRESH\_SUCCESS, REDIS\_CREDENTIAL\_REFRESH\_FAILED, REDIS\_AUTH\_FAILURE, REDIS\_STATIC\_PASSWORD\_USED.

* Add Prometheus metrics: redis\_credential\_mints\_total{provider}, redis\_credential\_refresh\_failures\_total{provider}, redis\_credential\_expires\_seconds{provider} (gauge).

* Add Grafana panel covering credential lifetime distribution and refresh failure rate.

* Add startup health check that fails the readiness probe if the credential provider cannot mint at boot.

## **5.5 Test coverage**

New test files (all backing the existing pytest tests/ \-x \-q gate):

| File | Coverage |
| :---- | :---- |
| tests/cache/test\_redis\_credential\_provider.py | Abstract contract: get\_credentials, expiry math, refresh\_safety\_window defaults |
| tests/cache/test\_static\_password\_provider.py | Gate enforcement, audit emission, error message correctness |
| tests/cache/test\_aws\_iam\_provider.py | SigV4 mint correctness via moto, expiry math, principal extraction from STS GetCallerIdentity |
| tests/cache/test\_azure\_entra\_provider.py | Token acquisition via mocked azure-identity, scope correctness, principal OID resolution |
| tests/cache/test\_mtls\_provider.py | SSLContext construction, cert reload on file change, expiry from notAfter |
| tests/cache/test\_vault\_dynamic\_provider.py | Lease renew loop, max\_ttl exhaustion, graceful revoke on shutdown |
| tests/cache/test\_redis\_provider\_reconnect.py | End-to-end: mock provider expiring after 2s, verify reconnect with fresh creds, verify in-flight commands drain |

# **6\. Migration & Compatibility**

## **6.1 Compatibility matrix**

| Existing deployment | Migration step | Downtime |
| :---- | :---- | :---- |
| Local dev (Docker Compose) | Add ALLOW\_STATIC\_REDIS\_PASSWORD=true to .env. No code or compose changes. | None |
| AWS ECS with random\_password | Re-run terraform apply with new module. Terraform creates the IAM-enabled ElastiCache user, attaches the policy to the task role, and triggers an ECS deployment. The new task connects with IAM auth. | Rolling — new tasks come up before old tasks drain |
| Azure Container Apps with access key | Re-run az deployment group create with new Bicep. Bicep enables MI, grants the access policy, and triggers a container app revision. | Rolling — revision-level traffic shift |
| Self-hosted Redis with REDIS\_PASSWORD | Either keep static (with the gate) or migrate to mTLS / Vault. mTLS requires Redis 6+ with tls-auth-clients enabled; Vault requires the Redis secrets engine enabled. | Plan-dependent |

## **6.2 Rollback path**

Each provider mode is independently selectable. Rollback from aws-iam to static is a single env-var change plus the gate flag. The cache contents themselves remain readable across modes — Redis ACLs control who can connect, not what data is in the cache. As long as the new identity has equivalent ACL permissions, no cache flush is required.

## **6.3 Phased rollout for regulated production deployments**

* Week 0: Phase 1 (provider seam) ships behind the gate. Existing deployments unchanged.

* Week 1–2: Customer's security team reviews the doc you are reading, the audit event additions, and the Terraform/Bicep changes.

* Week 3: Phase 2 ships. Customer flips REDIS\_AUTH\_MODE to aws-iam or azure-entra in a non-prod environment, observes the audit stream, and verifies refresh behaviour.

* Week 4: Production cutover during the customer's standard deployment window.

# **7\. Security Review Crib Sheet**

Concrete answers to the questions security teams have asked us in pre-sales and review meetings.

## **7.1 "Where does the Redis credential live now?"**

After this change, nowhere persistent. In aws-iam mode, the credential is computed from the calling IAM identity at every reconnect — there is no string to leak. In azure-entra mode, the credential is an Entra access token held in the workload's process memory and refreshed every \~55 minutes. In mtls mode, only the private key file exists on disk, secured by the cert lifecycle of the platform that issued it (often SPIRE).

## **7.2 "How do I revoke access for a compromised pod?"**

In aws-iam mode, detach the elasticache:Connect policy from the task role. Existing connections are unaffected, but no new connection can authenticate, and existing connections reconnect every \~12.5 minutes. Hard-revoke is to delete the IAM-enabled ElastiCache user, which terminates all sessions associated with that user. In azure-entra mode, revoke the managed identity's data-owner access policy on the cache. The platform SDK retries token acquisition on the next refresh and fails the connection. In mtls mode, revoke the certificate via the issuing CA's CRL/OCSP.

## **7.3 "How do I prove the static-password path is off in production?"**

Three independent signals:

* The deployed pod's environment does not contain ALLOW\_STATIC\_REDIS\_PASSWORD (kubectl exec env or container-spec inspection).

* The deployed pod's environment does not contain REDIS\_PASSWORD.

* The startup audit log does not contain a REDIS\_STATIC\_PASSWORD\_USED event.

The audit event is canonical because it is emitted regardless of how the static gate was bypassed (env var, config file, or future config source).

## **7.4 "What happens when the cloud token provider has an outage?"**

Existing connections continue to work until their tokens expire. New connections fail with an audited REDIS\_CREDENTIAL\_REFRESH\_FAILED event, and the readiness probe degrades after the configured grace window (default 5 minutes). The adapter does not fail open — it cannot serve cache requests, and the L1 in-process cache continues to serve hot data while L2 is unreachable. This matches the existing graceful-degradation behaviour for Redis outages.

## **7.5 "Does this change introduce a new dependency surface?"**

| Provider | New runtime dependency | License | Notes |
| :---- | :---- | :---- | :---- |
| aws-iam | boto3 / botocore (already a transitive dep via okta-client-python) | Apache 2.0 | No new top-level dep |
| azure-entra | azure-identity, azure-core | MIT | New dep, \~7 MB total |
| mtls | Python stdlib ssl, watchdog (file watch) | PSF / Apache 2.0 | watchdog is small (\~250 KB) |
| vault | hvac | Apache 2.0 | New dep, \~200 KB |
| static | (none) | — | Unchanged |

# **8\. Appendices**

## **8.1 Reference: AWS IAM token mint (Python)**

\# okta\_agent\_proxy/cache/redis\_credential\_providers/aws\_iam.py  
import datetime  
from urllib.parse import urlparse  
from botocore.auth import SigV4QueryAuth  
from botocore.awsrequest import AWSRequest  
from botocore.session import Session  
   
class AwsIamElastiCacheProvider(RedisCredentialProvider):  
    name \= "aws-iam"  
   
    def \_\_init\_\_(self, user\_id: str, cache\_name: str, region: str,  
                 is\_serverless: bool \= True):  
        self.user\_id \= user\_id  
        self.cache\_name \= cache\_name  
        self.region \= region  
        self.is\_serverless \= is\_serverless  
        self.\_session \= Session()  
   
    async def get\_credentials(self) \-\> RedisCredentials:  
        creds \= self.\_session.get\_credentials().get\_frozen\_credentials()  
        host \= self.cache\_name \+ (".serverless." if self.is\_serverless else ".")  
        url \= f"http://{host}/?Action=connect\&User={self.user\_id}"  
        request \= AWSRequest(method="GET", url=url)  
        request.context\["timeout"\] \= 900  \# 15 min  
        SigV4QueryAuth(creds, "elasticache", self.region).add\_auth(request)  
        signed\_url \= request.url  
   
        \# The auth token is the URL minus the scheme://host/? prefix  
        token \= urlparse(signed\_url).query  
        \# The path is also part of the token; reconstruct correctly:  
        token \= signed\_url.split("://", 1)\[1\]  
        token \= token\[token.index("/") \+ 1:\]  
   
        return RedisCredentials(  
            username=self.user\_id,  
            password=token,  
            expires\_at=datetime.datetime.utcnow() \+ datetime.timedelta(minutes=15),  
            ssl\_context=None,  
            principal=creds.access\_key,  \# for audit  
        )  
   
    def refresh\_safety\_window(self) \-\> datetime.timedelta:  
        return datetime.timedelta(minutes=2, seconds=30)

## **8.2 Reference: Azure Entra token mint (Python)**

\# okta\_agent\_proxy/cache/redis\_credential\_providers/azure\_entra.py  
import datetime  
import jwt  \# PyJWT  
from azure.identity.aio import DefaultAzureCredential, ManagedIdentityCredential  
   
REDIS\_SCOPE \= "https://redis.azure.com/.default"  
   
class EntraManagedIdentityProvider(RedisCredentialProvider):  
    name \= "azure-entra"  
   
    def \_\_init\_\_(self, use\_msi: bool \= True, principal\_oid: str | None \= None):  
        self.\_cred \= (ManagedIdentityCredential() if use\_msi  
                      else DefaultAzureCredential())  
        self.\_principal\_oid \= principal\_oid  \# cached after first mint  
   
    async def get\_credentials(self) \-\> RedisCredentials:  
        token \= await self.\_cred.get\_token(REDIS\_SCOPE)  
        if self.\_principal\_oid is None:  
            claims \= jwt.decode(token.token, options={"verify\_signature": False})  
            self.\_principal\_oid \= claims.get("oid") or claims.get("appid")  
        return RedisCredentials(  
            username=self.\_principal\_oid,  
            password=token.token,  
            expires\_at=datetime.datetime.fromtimestamp(token.expires\_on),  
            ssl\_context=None,  
            principal=self.\_principal\_oid,  
        )  
   
    def refresh\_safety\_window(self) \-\> datetime.timedelta:  
        return datetime.timedelta(minutes=5)

## **8.3 New audit event types**

| Event type | Severity | Emitted when |
| :---- | :---- | :---- |
| REDIS\_CREDENTIAL\_MINTED | INFO | Provider produces a fresh credential. Fields: provider, principal, expires\_at. |
| REDIS\_CREDENTIAL\_REFRESH\_SUCCESS | INFO | Scheduled reconnect succeeded with fresh credential. |
| REDIS\_CREDENTIAL\_REFRESH\_FAILED | WARNING | Provider could not mint. Fields: provider, error\_class, error\_message (sanitised). |
| REDIS\_AUTH\_FAILURE | WARNING | Redis returned AUTH error after we presented a credential. Implies revocation, ACL change, or clock skew. |
| REDIS\_STATIC\_PASSWORD\_USED | HIGH | Adapter started with REDIS\_AUTH\_MODE=static and the gate enabled. Should never appear in production audit streams. |

## **8.4 Open questions**

* Should we expose a /admin/redis/credentials endpoint that reports the current provider, principal, and time-to-refresh? Useful for operators; sensitive enough to warrant admin-only access.

* Should refresh failures fail closed (drop all cache reads, force L1-only) after a configurable window? Current proposal is graceful degradation, but some customers may want fail-closed.

* For HashiCorp Vault, do we want to support response-wrapping for the initial credential read? Adds complexity but provides a tamper-evident handoff.