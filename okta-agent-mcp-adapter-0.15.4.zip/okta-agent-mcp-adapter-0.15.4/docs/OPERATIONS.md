# Operations Guide

Day-2 operations reference for the Okta Agent Adapter.

## Table of Contents

1. [Admin API Reference](#admin-api-reference)
2. [Database Bootstrap](#database-bootstrap)
3. [Database Operations](#database-operations)
3. [Configuration](#configuration)
4. [Port Configuration](#port-configuration)
5. [Redis Cache](#redis-cache)
5. [Agent Management](#agent-management)
6. [CIMD Agent Matching](#cimd-agent-matching)
7. [Resource Management](#resource-management)
8. [Monitoring](#monitoring)
9. [Production Hardening](#production-hardening)
10. [Troubleshooting](#troubleshooting)
11. [Okta Agent Import](#okta-agent-import)
12. [Claude Code Connection Guide](#claude-code-connection-guide)
13. [Troubleshooting Claude Code Integration](#troubleshooting-claude-code-integration)

---

## Admin API Reference

Base URL: `http://localhost:8000/api/admin`

All endpoints require `Authorization: Bearer <okta_access_token>`.

### Admin API Authentication

As of v0.15.x the adapter accepts **only Okta OAuth access tokens** issued by
the Admin UI's OIDC app — the old `POST /api/admin/login` username/password
flow was removed.

Obtain a token one of two ways:

1. **Admin UI** — sign in at `http://localhost:3001/login`, then copy the
   access token out of browser devtools:
   ```
   Application → Storage → IndexedDB → keyval-store → next-auth.session-token
   ```
   (or inspect the `Authorization` header on any admin API request from the UI).
2. **Okta CLI** — if you have the `okta` CLI configured, authenticate against
   the same OIDC app and capture its access token.

Then:

```bash
export OKTA_ADMIN_TOKEN="<paste token>"
curl -H "Authorization: Bearer $OKTA_ADMIN_TOKEN" \
     http://localhost:8000/api/admin/agents
```

> **Security note:** today any user in the Okta org with a valid token from
> the Admin UI OIDC app is admitted as an admin. Audience pinning and
> group/scope enforcement are tracked as follow-up hardening in
> [`reports/security-audit.md`](../reports/security-audit.md).

### Endpoint Reference

| Method | Endpoint | Status | Description |
|--------|----------|--------|-------------|
| GET | `/api/admin/agents` | 200 | List all agents |
| POST | `/api/admin/agents` | 201 | Create agent |
| GET | `/api/admin/agents/{id}` | 200 | Get agent by ID |
| PUT | `/api/admin/agents/{id}` | 200 | Update agent |
| DELETE | `/api/admin/agents/{id}` | 200 | Delete agent |
| GET | `/api/admin/backends` | 200 | List all resources |
| POST | `/api/admin/backends` | 201 | Create resource |
| GET | `/api/admin/backends/{name}` | 200 | Get resource by name |
| PUT | `/api/admin/backends/{name}` | 200 | Update resource |
| DELETE | `/api/admin/backends/{name}` | 200 | Delete resource |
| POST | `/api/admin/users/force-logout` | 200 | Admin-initiated force logout for a single user (email or Okta `sub`). Reuses the Global Logout (ITP Universal Logout) revocation cascade. See [Global Logout configuration](GLOBAL_LOGOUT_CONFIGURATION.md#admin-initiated-force-logout). Email resolution requires the Admin UI OIDC app to carry the `okta.users.read` scope; audit event `admin.user.force_logout`. |

### Error Responses

| Status | Error | Meaning |
|--------|-------|---------|
| 400 | `invalid_input` | Missing required field or bad payload |
| 401 | `unauthorized` | Missing, expired, or invalid admin token |
| 404 | `not_found` | Agent or resource does not exist |
| 409 | `conflict` | Duplicate agent_id or resource name |
| 500 | `server_error` | Internal failure (check logs) |

---

## Database Bootstrap

As of the v0.15 database migration, the adapter **does not create database
schema at runtime**. A DBA (or CI/CD pipeline) is expected to provision the
database and apply migrations before the service starts. If the adapter is
pointed at a database whose `schema_migrations` table is missing or behind
`MIN_SCHEMA_VERSION`, it **fails fast with an explicit error** and refuses
to start.

This is an intentional control requested by enterprise customers: DBAs
review and gate every DDL change, and the runtime service role is
granted only DML privileges. See Prompt P09 (`deploy/migrations/sql/bootstrap_roles.sql`)
for the two-role model (`okta_adapter_owner` for migrations,
`okta_adapter_app` for runtime).

### Operator workflow

1. **One-time** — DBA provisions the database and the two roles:

   ```bash
   createdb gateway_db
   DB_OWNER_ROLE=okta_adapter_owner \
   DB_APP_ROLE=okta_adapter_app \
   DB_NAME=gateway_db \
   psql -d gateway_db -f deploy/migrations/sql/bootstrap_roles.sql
   ```

2. **Per-deploy** — CI/CD (or DBA) runs pending migrations as the **owner**
   role before the adapter is upgraded:

   ```bash
   # psycopg conninfo / libpq URL accepted
   DATABASE_URL="postgresql://okta_adapter_owner:***@host/gateway_db?sslmode=require" \
     python -m okta_agent_proxy.storage.migrate upgrade

   # Or via the legacy wrapper (calls the same runner inside the container)
   ./run_migrations.sh
   ```

3. **Runtime** — The adapter container runs as the **app** role, which has
   no DDL grants:

   ```bash
   DATABASE_URL=postgresql://okta_adapter_app:***@host/gateway_db?sslmode=require
   ```

   On startup the adapter probes `schema_migrations` and logs:

   ```
   ✓ Database schema verified — current version: 004
   ```

### DBA-Controlled Migration Workflow (P15)

Both the AWS ECS and Azure ACA deploy scripts run the bootstrap + migration
step automatically by default. Set **`RUN_DB_BOOTSTRAP=false`** (or pass
`--no-bootstrap` / the existing `--skip-migrate`) to hand off to a DBA:

```bash
# AWS
cd deploy/aws-ecs && RUN_DB_BOOTSTRAP=false ./deploy.sh --apply

# Azure
cd deploy/azure-aca && RUN_DB_BOOTSTRAP=false ./scripts/deploy.sh
```

When off, the deploy completes successfully but prints a copy-pasteable
operator handoff block. The adapter will stay in `CrashLoopBackoff` with
the "schema not initialized" error (see next subsection) until the DBA
completes the bootstrap. That's the intended hand-off behavior.

The four-step DBA workflow:

1. **Operator** runs the deploy with `--no-bootstrap`. The deploy script
   prints a handoff block with the resolved secret ARN, cluster name,
   migrate task ARN, subnets, and security groups already substituted.
2. **Operator** forwards the handoff block to the DBA.
3. **DBA** runs either (a) the one-shot cloud-native job from the handoff
   block (`aws ecs run-task …` or `az containerapp job start …`), or
   (b) the `psql` + `python -m okta_agent_proxy.storage.migrate upgrade`
   commands from a jump host with DB reachability.
4. **Operator** runs `./deploy.sh --migrate-only` (AWS) or
   `./scripts/deploy.sh --migrate-only` (Azure) to verify — this does
   not modify infrastructure, it only re-runs bootstrap. Idempotent.

### Bootstrap execution path — cloud-job vs. local-exec

The shared helper at `deploy/shell-lib/db_bootstrap.sh` auto-selects:

- **Cloud-native job** (preferred). The deploy script triggers the ECS
  RunTask (`aws_ecs_task_definition.migrate`) or the ACA Container Apps
  Job (`migrate-job.bicep`). These run inside the deployed VPC/VNet
  with the right managed identity. Bootstrap + migrations run as a
  single unit inside the task/job.
- **Local-exec fallback**. When the cloud CLI is missing or not
  authenticated, the helper falls back to running `psql` +
  `python -m okta_agent_proxy.storage.migrate upgrade` directly from
  the deploy host. This requires the host to reach the DB — not typical
  in private-endpoint deployments.

Operators can force one path:

- `DB_BOOTSTRAP_FORCE_LOCAL=true` — skip the cloud-job attempt entirely.
- `DB_BOOTSTRAP_TIMEOUT=<seconds>` — max wait for the cloud-native job
  (default 600; Azure raises it to 900).

**AWS caveat:** when `use_rds_iam=true` (the default), the owner role
has no standing password. The local-exec fallback is refused with a
clear error in that mode — use the cloud-job path, or set
`use_rds_iam=false` in Terraform to opt out.

### What happens if migrations were not run

Point the adapter at an empty database and startup aborts with:

```
Database schema is not initialized — table 'schema_migrations' does not exist.
Run the migration runner against your database BEFORE starting the adapter:
    python -m okta_agent_proxy.storage.migrate upgrade --conninfo "$DATABASE_URL"
Or with Docker: ./run_migrations.sh
This adapter intentionally does not create database schema at runtime.
See docs/OPERATIONS.md § Database Bootstrap.
```

If the schema exists but is older than the minimum required by the build:

```
Database schema version is '003' but this build requires '004' or higher.
Run pending migrations:
    python -m okta_agent_proxy.storage.migrate upgrade --conninfo "$DATABASE_URL"
```

The process exits with status 1 in both cases. This is the expected,
correct behavior — do not work around it by granting DDL to the app role.

### Migration runner commands

```bash
# Show current applied version and any pending migrations
python -m okta_agent_proxy.storage.migrate status

# Apply all pending migrations
python -m okta_agent_proxy.storage.migrate upgrade

# Apply up to (and including) a specific version
python -m okta_agent_proxy.storage.migrate upgrade --target 003

# Just print the current version
python -m okta_agent_proxy.storage.migrate version
```

The runner records each applied migration in `schema_migrations` with a
SHA-256 checksum of the `.up.sql` file. Editing an already-applied
migration on disk causes the next `upgrade` to fail with
`Checksum mismatch…`; migrations are immutable once applied.

### Database Credential Providers

The adapter selects its database credential source via the
`DB_CREDENTIAL_PROVIDER` env var. The default (`static`) preserves the
v0.14 behaviour — parse `DATABASE_URL` once at startup and reuse the
baked-in password. Alternative providers issue short-lived credentials
so deployments never ship a long-lived DB password in a secret store.

| Provider        | Prompt | Rotation | Required env                                     |
|-----------------|--------|----------|--------------------------------------------------|
| `static`        | P02    | none     | `DATABASE_URL`                                   |
| `rds_iam`       | P10    | 15 min   | `DB_HOST`, `DB_PORT`, `DB_NAME`, `DB_USERNAME`, `AWS_REGION` |
| `azure_entra`   | P11    | ~60 min  | `DB_HOST`, `DB_PORT`, `DB_NAME`, `DB_USERNAME`   |
| `vault`         | P12    | lease    | (not yet implemented)                            |

`DatabasePool` sets `max_lifetime` to 80% of the credential TTL for
rotating providers, so in-flight connections are recycled before the
password expires.

#### AWS RDS IAM

Authenticate to RDS PostgreSQL with short-lived (15-minute) IAM tokens
instead of a static password. The adapter calls
`rds.generate_db_auth_token` on every new physical connection via the
credential provider → pool callback wiring added in P10.

**1 — Enable IAM authentication on the RDS instance.**
For provisioned RDS via the console: *Modify → Database authentication
→ Password and IAM database authentication*. For Terraform:

```hcl
resource "aws_db_instance" "this" {
  # ...
  iam_database_authentication_enabled = true
}
```

**2 — Grant `rds_iam` to the DB role on the Postgres side.** Connect
with master credentials once and:

```sql
GRANT rds_iam TO okta_adapter_app;
GRANT rds_iam TO okta_adapter_owner;  -- only if migrations run as IAM too
```

**3 — Attach an IAM policy to the task role** (ECS task role, EKS
IRSA, or EC2 instance profile) granting `rds-db:connect`:

```json
{
  "Version": "2012-10-17",
  "Statement": [{
    "Effect": "Allow",
    "Action": "rds-db:connect",
    "Resource": "arn:aws:rds-db:us-east-1:123456789012:dbuser:db-ABCDEFGHIJKL/okta_adapter_app"
  }]
}
```

The resource ARN uses the RDS **resource ID** (visible as
`aws_db_instance.<name>.resource_id` in Terraform or in the RDS console
as *Resource ID*), NOT the DB instance identifier.

**4 — Set the adapter's env vars** (no `DATABASE_URL` required):

```bash
DB_CREDENTIAL_PROVIDER=rds_iam
DB_HOST=my-db.abcdefg.us-east-1.rds.amazonaws.com
DB_PORT=5432
DB_NAME=gateway_db
DB_USERNAME=okta_adapter_app
AWS_REGION=us-east-1          # or AWS_DEFAULT_REGION
DB_SSLROOTCERT=/opt/rds-ca/global-bundle.pem   # default; leave unset
```

The container image ships the RDS global CA bundle at
`/opt/rds-ca/global-bundle.pem` by default. Set `INSTALL_RDS_CA=false`
at build time to skip this on non-AWS images.

**5 — Verify** by running the adapter and watching startup logs:

```
DatabasePool opened (provider=rds_iam, host=my-db..., max_lifetime=720s, rotates=True)
```

`max_lifetime=720` = 80% of the 15-minute token TTL. Connections are
recycled at that cadence; the pool never holds a token past its
expiry.

#### Azure Entra ID

Authenticate to Azure Database for PostgreSQL (Flexible Server) with
short-lived (~60-minute) Microsoft Entra access tokens instead of a
static password. The adapter calls `DefaultAzureCredential.get_token`
for the `https://ossrdbms-aad.database.windows.net/.default` scope on
every new physical connection; the resulting token is used as the
Postgres password.

**1 — Enable Microsoft Entra authentication on the Flexible Server.**
In the Azure portal: *Authentication → Assignments → Add Microsoft
Entra admin*. Pick an Entra group (preferred — easier to rotate) and
note its object ID. Terraform / Bicep equivalents set `authConfig` to
`{ activeDirectoryAuth: 'Enabled', passwordAuth: 'Enabled' }` on the
server and add a
`Microsoft.DBforPostgreSQL/flexibleServers/administrators` child.

**2 — Map the workload identity to a Postgres role.** Connect to the
server as the Entra admin and create a principal for the adapter's
managed identity (or service principal), then grant it the DML-only
app role created by `bootstrap_roles.sql`:

```sql
-- Create the Entra-backed DB principal. The name MUST match the
-- managed identity's display name or the user principal name.
SELECT * FROM pgaadauth_create_principal(
    'okta-adapter-app',   -- managed-identity display name
    false,                -- is_admin
    false                 -- is_mfa
);

GRANT okta_adapter_app TO "okta-adapter-app";
```

For a service principal, substitute the UPN
(`<app-name>@<tenant>.onmicrosoft.com`) or use
`pgaadauth_create_principal_with_oid` with the object ID.

**3 — Attach the workload identity to the runtime.** In Azure
Container Apps or AKS, attach the user-assigned managed identity to
the Pod / Container App. `DefaultAzureCredential` picks it up via
the `AZURE_CLIENT_ID` env var automatically set by the platform. For
a service principal, set
`AZURE_CLIENT_ID` / `AZURE_CLIENT_SECRET` / `AZURE_TENANT_ID`
directly.

**4 — Set the adapter's env vars** (no `DATABASE_URL` required):

```bash
DB_CREDENTIAL_PROVIDER=azure_entra
DB_HOST=my-server.postgres.database.azure.com
DB_PORT=5432
DB_NAME=gateway_db
DB_USERNAME=okta-adapter-app       # must match the Entra principal name
AZURE_CLIENT_ID=<managed-identity-client-id>  # optional; auto-set by ACA/AKS
```

Azure Postgres Flexible Server enforces SSL; the provider always
sets `sslmode=require`. The system trust store suffices for Azure's
public CAs — leave `DB_SSLROOTCERT` unset unless your runtime has a
custom trust store.

**5 — Verify** by running the adapter and watching startup logs:

```
DatabasePool opened (provider=azure_entra, host=my-server..., max_lifetime=2880s, rotates=True)
```

`max_lifetime` is 80% of the reported Entra token TTL (typically
~48 minutes when the token is fresh). Connections are recycled at
that cadence; the pool never holds a token past its expiry.

---

#### HashiCorp Vault

Use Vault's database secrets engine to issue short-lived, uniquely
named Postgres roles on demand. Every time the pool needs a new
physical connection, Vault mints a fresh username / password pair
backed by a lease; when the lease expires, Vault automatically revokes
the Postgres role. The adapter never sees a static password and no
operator needs to rotate anything.

**1 — Configure the database secrets engine in Vault.** Mount the
engine (default path `database`) and register the Postgres connection
plus a role that grants the DML privileges created by
`bootstrap_roles.sql`:

```bash
vault secrets enable database

vault write database/config/okta-adapter \
    plugin_name=postgresql-database-plugin \
    allowed_roles="okta-adapter-app" \
    connection_url='postgresql://{{username}}:{{password}}@db.example.com:5432/gateway_db?sslmode=require' \
    username="vault_admin" \
    password="<vault-admin-password>"

vault write database/roles/okta-adapter-app \
    db_name=okta-adapter \
    creation_statements="CREATE ROLE \"{{name}}\" WITH LOGIN PASSWORD '{{password}}' VALID UNTIL '{{expiration}}' IN ROLE okta_adapter_app;" \
    default_ttl="1h" \
    max_ttl="24h"
```

The `vault_admin` user is a long-lived Postgres role that Vault uses to
provision and drop dynamic roles. It is separate from the adapter's
`okta_adapter_owner` / `okta_adapter_app` roles; grant it `CREATEROLE`
and membership in `okta_adapter_app` so Vault-issued roles inherit the
DML privileges.

**2 — Grant the adapter access to the Vault role.** Attach a policy
that allows reads against the credential endpoint:

```hcl
path "database/creds/okta-adapter-app" {
  capabilities = ["read"]
}
```

**3 — Pick one authentication method for the adapter.**

*Kubernetes (preferred in K8s / EKS / AKS / GKE):*

```bash
VAULT_ADDR=https://vault.example.com:8200
VAULT_K8S_ROLE=okta-adapter
# Optional: override if your cluster uses a non-default Vault mount
# VAULT_K8S_AUTH_PATH=kubernetes
# Optional: projected SA token path — default matches kubelet's default
# K8S_SA_TOKEN_PATH=/var/run/secrets/kubernetes.io/serviceaccount/token
```

*AppRole (preferred for VMs / ECS / bare metal):*

```bash
VAULT_ADDR=https://vault.example.com:8200
VAULT_APPROLE_ROLE_ID=<role-id>
VAULT_APPROLE_SECRET_ID=<secret-id>   # deliver via your secret store
```

*Static token (development only — never production):*

```bash
VAULT_ADDR=https://vault.example.com:8200
VAULT_TOKEN=hvs.CAESI...
```

**4 — Set the adapter's env vars** (no `DATABASE_URL` required):

```bash
DB_CREDENTIAL_PROVIDER=vault
DB_HOST=db.example.com
DB_PORT=5432
DB_NAME=gateway_db
VAULT_DB_MOUNT=database                 # default shown
VAULT_DB_ROLE=okta-adapter-app
# DB_SSLMODE defaults to "require"; override per your Postgres setup.
# DB_SSLROOTCERT=/path/to/ca.pem
```

**5 — Verify** by running the adapter and watching startup logs:

```
Vault issued DB credential (role=okta-adapter-app mount=database username=v-approle-okta-adapter-... lease=3600s)
DatabasePool opened (provider=vault, host=db.example.com, max_lifetime=2880s, rotates=True)
```

The provider caches the credential in process memory until ~80% of the
lease has elapsed, so load against Vault stays flat. `max_lifetime`
tracks the same 80% threshold so the pool recycles each connection in
lock-step with the cache.

> **Do not** use `VAULT_TOKEN` outside of local development. It is a
> long-lived bearer credential that defeats the whole point of using
> Vault for dynamic secrets.

---

## Database Operations

### Connect to PostgreSQL

```bash
# Via docker compose
docker compose exec postgres psql -U gateway_user -d gateway_db

# Direct connection (if port 5432 is mapped)
psql postgresql://gateway_user:gateway_pass@localhost:5432/gateway_db
```

### Validate Database Setup

Quick checks to verify the database, user, and tables were created correctly:

```bash
# Verify the database user can connect
docker compose exec postgres pg_isready -U gateway_user -d gateway_db

# List all tables (should show agents, backends, agent_backend_access, audit_log, etc.)
docker compose exec postgres psql -U gateway_user -d gateway_db -c "\dt"

# Check current Alembic migration version
docker compose exec postgres psql -U gateway_user -d gateway_db -c "SELECT version_num FROM alembic_version;"

# Verify seeded agents
docker compose exec postgres psql -U gateway_user -d gateway_db -c "SELECT agent_id, client_id, enabled FROM agents;"

# Verify seeded backends
docker compose exec postgres psql -U gateway_user -d gateway_db -c "SELECT name, url, auth_method, enabled FROM backends;"
```

### Inspect Tables

```sql
-- List agents
SELECT agent_id, client_id, enabled, created_at FROM agents;

-- List backends
SELECT name, url, auth_method, enabled, created_at FROM backends;

-- List agent-to-resource access mappings
SELECT agent_id, backend_name FROM agent_backend_access;

-- View audit log (last 20 entries)
SELECT entity_type, entity_id, action, performed_by, created_at
  FROM audit_log ORDER BY created_at DESC LIMIT 20;
```

### Run Migrations

```bash
# Apply all pending migrations (idempotent)
docker compose exec okta-agent-mcp-adapter alembic upgrade head

# Check current migration version
docker compose exec okta-agent-mcp-adapter alembic current

# View migration history
docker compose exec okta-agent-mcp-adapter alembic history
```

### Backup and Restore

```bash
# Backup
docker compose exec postgres pg_dump -U gateway_user gateway_db > backup_$(date +%Y%m%d).sql

# Restore
cat backup_20260304.sql | docker compose exec -T postgres psql -U gateway_user gateway_db
```

### Reset Database

```bash
# Drop and recreate (destroys all data)
docker compose exec postgres psql -U gateway_user -d postgres \
  -c "DROP DATABASE gateway_db;" \
  -c "CREATE DATABASE gateway_db OWNER gateway_user;"

# Re-run migrations
docker compose exec okta-agent-mcp-adapter alembic upgrade head
```

### Migrate from YAML (Legacy)

If upgrading from v1.x with YAML configuration:

```bash
python ops_scripts/migrate_config_to_db.py \
  --config config/config.yaml \
  --database-url $DATABASE_URL

# Dry run first to preview
python ops_scripts/migrate_config_to_db.py --config config/config.yaml --dry-run
```

---

## Configuration

### Environment Variables

| Variable | Required | Default | Description |
|----------|----------|---------|-------------|
| `OKTA_DOMAIN` | Yes | — | Okta org domain (e.g., `dev-12345.okta.com`) |
| `OKTA_ISSUER` | No | `https://{OKTA_DOMAIN}` | Override issuer URL (defaults to Org auth server) |
| `DATABASE_URL` | Yes | — | PostgreSQL connection string |
| `ENCRYPTION_KEY` | Yes | — | Base64-encoded 32-byte AES key |
| `GATEWAY_BASE_URL` | No | `http://localhost:8000` | Public gateway URL |
| `GATEWAY_PORT` | No | `8000` | Gateway listen port (see [Port Configuration](#port-configuration)) |
| `ADMIN_UI_PORT` | No | `3001` | Admin UI listen port (see [Port Configuration](#port-configuration)) |
| `HR_BACKEND_PORT` | No | `8001` | HR example backend port (see [Port Configuration](#port-configuration)) |
| `DEPLOY_SERVER_PORT` | No | `8005` | Deploy example server port (see [Port Configuration](#port-configuration)) |
| `DCR_CALLBACK_PORT` | No | `3000` | OAuth callback port for setup.sh (see [Port Configuration](#port-configuration)) |
| `ADMIN_UI_OKTA_DOMAIN` | Yes (for admin API) | — | Okta domain that signs Admin UI tokens (see [Admin API Authentication](#admin-api-authentication)) |
| `ADMIN_UI_OKTA_CLIENT_ID` | Yes (for admin API) | — | Admin UI OIDC app client_id |
| `HR_PSK_SECRET` | No | `demo-psk-secret-do-not-use-in-prod` | HR resource PSK |
| `CACHE_PROVIDER` | No | `memory` | Cache provider: `memory` or `redis` |
| `REDIS_URL` | No | `redis://localhost:6379` | Redis connection URL |
| `REDIS_PASSWORD` | No | `redis-secret` | Redis authentication password |
| `REDIS_TLS_ENABLED` | No | `false` | Enable TLS for Redis connections |
| `REDIS_KEY_PREFIX` | No | `okta-mcp:` | Key prefix for all Redis keys |
| `LOG_LEVEL` | No | `INFO` | Logging level (`DEBUG`, `INFO`, `WARNING`, `ERROR`) |
| `POSTGRES_DB` | No | `gateway_db` | Database name (docker-compose) |
| `POSTGRES_USER` | No | `gateway_user` | Database user (docker-compose) |
| `POSTGRES_PASSWORD` | No | `gateway_pass` | Database password (docker-compose) |

### Encryption Key Management

```bash
# Generate a new key
python3 -c "import os,base64; print(base64.b64encode(os.urandom(32)).decode())"

# Or use the helper script
python ops_scripts/generate_encryption_key.py
```

The encryption key protects agent credentials (`client_secret`, `private_key`) and resource secrets (`api_key`, `password`, `target_client_secret`) using AES-256-GCM.

Rules:
- Never commit `ENCRYPTION_KEY` to version control
- Use the same key across all gateway instances in a cluster
- Changing the key after data is encrypted requires re-encryption (not yet automated)
- `setup.sh` auto-generates a key if `ENCRYPTION_KEY` is blank in `.env`

---

## Port Configuration

All adapter components listen on configurable TCP ports. The defaults (8000 / 3001 / 8001 / 8005) work for most demos; override them when:
- A port collides with an existing service in your target environment
- Corporate SCPs restrict which ports containers may bind
- You are running multiple adapter instances on one host

### Canonical port variables

| Component | Env var | Default | Where it's read |
|---|---|---|---|
| Adapter gateway | `GATEWAY_PORT` | 8000 | Container: uvicorn bind; ALB target group; ALB SG egress; Service Connect alias |
| Admin UI | `ADMIN_UI_PORT` | 3001 | Container: bridged to Next.js `PORT` by start.sh; ALB target group |
| HR example | `HR_BACKEND_PORT` | 8001 | Container: FastMCP bind; Service Connect advertise |
| Deploy example | `DEPLOY_SERVER_PORT` | 8005 | Container: FastMCP bind |
| DCR callback | `DCR_CALLBACK_PORT` | 3000 | setup.sh only; must match Okta app redirect URI |

### Host-side overrides (docker-compose only)

When running locally and needing to remap only the host side:

| Env var | Default |
|---|---|
| `GATEWAY_HOST_PORT` | `$GATEWAY_PORT` |
| `ADMIN_UI_HOST_PORT` | `$ADMIN_UI_PORT` |
| `HR_BACKEND_HOST_PORT` | `$HR_BACKEND_PORT` |
| `DEPLOY_SERVER_HOST_PORT` | `$DEPLOY_SERVER_PORT` |

Container-orchestrated profiles (ECS, AKS, ACA) do not use host ports — the container port is the only port that matters.

### Changing a port after deployment

**ECS:** set `TF_VAR_gateway_port=9000` and re-run `./deploy.sh --apply`. Terraform updates the ALB target group, security group rules, task definition, and Service Connect alias in one apply. Adapter and admin UI ports live in `deploy/aws-ecs/`. HR backend port lives in `deploy/aws-ecs-examples/`.

**AKS:** edit the port values in your manifests under `deploy/azure-aks/manifests/` (look for `# GATEWAY_PORT` comments) and re-apply.

**ACA:** set the port parameters in `.params.json` and re-run `az deployment group create --template-file main.bicep --parameters @.params.json`.

**docker-compose:** set the env var in `.env` and run `docker compose up -d --force-recreate`.

Never change a port by editing the container's code after start — the orchestrator's health check will fail and the task will be replaced with the old config.

### Privileged ports (<1024)

Ports 1–1023 require `CAP_NET_BIND_SERVICE` or root. Our containers run as non-root, so binding to 80 or 443 will fail. If you need the adapter to appear on port 443 externally, terminate TLS at the ALB / ingress controller and keep the container port at 8000.

### Deprecated: SERVER_PORT

The HR example backend and deploy server historically read `SERVER_PORT`. This is deprecated and will be removed in v2.0.0. Use `HR_BACKEND_PORT` and `DEPLOY_SERVER_PORT` respectively. Setting `SERVER_PORT` today still works but emits a `DeprecationWarning` at startup.

---

## Redis Cache

The gateway supports an optional Redis cache for multi-instance deployments. When Redis is available, cached tokens, JWKS keys, MCP sessions, metadata, and configuration data are shared across all gateway containers. A Redis pub/sub event bus also ensures cross-container cache invalidation when configuration changes via the Admin API.

Without Redis, the gateway falls back to in-memory caching (single-node only, no cross-container sync).

### Pub/Sub Invalidation Channels

The event bus publishes on the following Redis pub/sub channels to keep all gateway pods in sync:

| Channel | Trigger | Effect on Receiving Pod |
|---------|---------|------------------------|
| `route_invalidate` | Resource CRUD via Admin API | Reloads in-memory routing table |
| `agent_invalidate` | Agent CRUD, DCR registration, credential ops | Clears agent config L1 cache |
| `tool_catalog_invalidate` | Agent/resource CRUD | Clears unified handler tool cache |
| `dcr_patterns_invalidate` | DCR redirect pattern update | Clears DCR policy L1 pattern cache |
| `user_token_invalidate` | `UserTokenStore.aremove()` / `aremove_by_user()` | Drops matching entry from L1 TTLCache |
| `relay_session_invalidate` | Relay state or pre-consent state deleted | Drops matching entry from L1 session dicts |
| `consent_tx_invalidate` | `ConsentTransactionStore.aremove()` | Drops transaction from L1 by-id and by-session dicts |
| `user_logout` | *(No endpoint yet — TODO)* | Cascades: clears UserTokenStore + TokenCache entries for the user |

All user-scoped channels use a standard JSON envelope: `{"v": 1, "key": "<id>", "user_sub": "<optional>"}`. Config-scoped channels use free-form string messages.

> **⚠️ ENCRYPTION_KEY is REQUIRED when CACHE_PROVIDER=redis in production.**
> When Redis is the L2 cache, sensitive data (id_tokens, refresh_tokens, relay client secrets, consent transactions) is written to shared Redis storage. Without `ENCRYPTION_KEY`, this data is stored **unencrypted**. The gateway emits a loud startup warning (`REDIS ENABLED WITHOUT ENCRYPTION_KEY`) if this condition is detected. Always set `ENCRYPTION_KEY` before enabling Redis in production.

### Enable/Disable Redis

Set `CACHE_PROVIDER` in `.env`:

```bash
# Use Redis (recommended for production / multi-instance)
CACHE_PROVIDER=redis

# Use in-memory only (default, single-instance)
CACHE_PROVIDER=memory
```

When using Docker Compose, Redis is included by default and `CACHE_PROVIDER` is set to `redis`.

### Environment Variables

| Variable | Default | Description |
|----------|---------|-------------|
| `CACHE_PROVIDER` | `memory` | Cache provider: `memory` or `redis` |
| `REDIS_URL` | `redis://localhost:6379` | Redis connection URL |
| `REDIS_PASSWORD` | `redis-secret` | Redis authentication password |
| `REDIS_TLS_ENABLED` | `false` | Enable TLS for Redis connections |
| `REDIS_KEY_PREFIX` | `okta-mcp:` | Key prefix for all Redis keys |
| `ENCRYPTION_KEY` | — | **Required** when `CACHE_PROVIDER=redis`. AES-256 key for at-rest encryption of cached tokens. |

### Verify Redis is Connected

```bash
# Health check endpoint includes cache status
curl -s http://localhost:8000/health | python3 -m json.tool

# Expected response (with Redis):
# {
#   "status": "healthy",
#   "cache_provider": "RedisCacheProvider",
#   "cache_healthy": true,
#   ...
# }

# Expected response (without Redis):
# {
#   "status": "healthy",
#   "cache_provider": "MemoryCacheProvider",
#   "cache_healthy": true,
#   ...
# }
```

### Flush the Cache Manually

```bash
# Connect to Redis CLI inside the container
docker compose exec redis redis-cli -a "${REDIS_PASSWORD:-redis-secret}"

# List all gateway keys
KEYS okta-mcp:*

# Flush all gateway keys
EVAL "for _,k in ipairs(redis.call('keys','okta-mcp:*')) do redis.call('del',k) end" 0

# Flush entire Redis database (all keys, not just gateway)
FLUSHDB
```

### Horizontal Scaling Requirements

The adapter can run as 2+ replicas behind a load balancer when all four prerequisites are met:

1. **`CACHE_PROVIDER=redis`** — all pods must use Redis, not in-memory caching.
2. **`REDIS_URL` set and reachable from every pod** — all pods must connect to the same Redis instance.
3. **`ENCRYPTION_KEY` set and IDENTICAL across every pod** — all pods must decrypt each other's cached data. Generate with `python ops_scripts/generate_encryption_key.py`.
4. **Starlette ASGI transport** — the adapter uses a Starlette ASGI app (not FastMCP's HTTP transport), so all per-flow state lives in Redis when configured. This is the default `python -m okta_agent_proxy.main http` mode.

Session stickiness is **not required**. All per-flow state (OAuth relay sessions, gateway codes, consent transactions, user tokens) is stored in Redis and accessible from any pod.

See [deploy/HORIZONTAL_SCALING.md](../deploy/HORIZONTAL_SCALING.md) for detailed sizing, health-check, and pod scaling guidance.

### What Is Now Safe Across Pods

When `CACHE_PROVIDER=redis` and `ENCRYPTION_KEY` are set, the following caches are backed by CacheService (L1 local + L2 Redis):

| Component | Key Pattern | Semantics |
|-----------|-------------|-----------|
| TokenCache (resource tokens) | `token:{user_id}:{resource_name}` | Cached resource JWTs from ID-JAG/STS exchange |
| MCPSessionManager | `session:proxy:{user_id}:{resource_name}` | MCP initialize handshake session IDs |
| OktaTokenValidator JWKS | `jwks:{issuer_url}` | Okta public key sets for JWT validation |
| CachedResourceStore / ConfigCache | `agent:{id}`, `resource:{name}`, etc. | Agent and resource configuration read-through cache |
| UnifiedMCPHandler tool catalog | `tool_catalog:{agent_id}` | Consolidated tool lists per agent |
| CIMDFetcher metadata | `cimd:metadata:{sha256(url)}` | CIMD document metadata cache |
| UserTokenStore | `user_token:{sha256(access_token)}` | Encrypted access_token → id_token/refresh_token mapping for XAA |
| GatewayCodeManager (codes) | `gateway_code:{code}` | Single-use authorization codes (cross-pod atomicity enforced) |
| GatewayCodeManager (tokens) | `gateway_token:{access_token}` | Issued CIMD access token tracking |
| ConfidentialRelay state | `relay_state:{state}`, `relay_preconsent:{state}` | OAuth relay session state for CIMD/pre-consent flows |
| ConsentTransactionStore | `consent_tx:{id}`, `consent_session:{session_id}` | STS consent verification transactions |

### Troubleshooting Redis

```bash
# Check Redis container is running
docker compose ps redis

# Check Redis logs
docker compose logs redis

# Test connectivity from gateway container
docker compose exec okta-agent-mcp-adapter python -c "
import redis, os
r = redis.from_url(os.getenv('REDIS_URL', 'redis://localhost:6379'), socket_connect_timeout=3)
print('PING:', r.ping())
print('INFO:', r.info('server')['redis_version'])
"

# Check memory usage
docker compose exec redis redis-cli -a "${REDIS_PASSWORD:-redis-secret}" INFO memory | grep used_memory_human

# Common issues:
# - "Connection refused": Redis container not running or wrong REDIS_URL
# - "NOAUTH": REDIS_PASSWORD doesn't match redis-server --requirepass value
# - "OOM": Redis maxmemory reached — keys will be evicted via allkeys-lru policy
```

### Troubleshooting Multi-Pod Deployments

**Symptom: 401 immediately after login on multi-pod deployment**
The user authenticates on pod A but the next request lands on pod B, which can't find the token. Check:
- `ENCRYPTION_KEY` is identical on every pod (different keys = pods can't decrypt each other's cached data)
- `REDIS_URL` is reachable from every pod
- `CACHE_PROVIDER=redis` is set on every pod (not `memory`)

**Symptom: CIMD client gets `invalid_grant` on token exchange after a successful authorize**
The gateway code was issued on one pod but the exchange lands on another. This should not happen after the P3 migration — verify `GatewayCodeManager` is constructed with `cache_service` (check startup logs for `GatewayCode: L2 write`). If codes are being consumed twice, check that the cross-pod single-use guard is active (L2 `exists` check before accepting an L1 hit).

**Symptom: consent UI loops back to /authorize**
The consent transaction was lost between pods. Verify `ConsentTransactionStore` is constructed with `cache_service` (check startup logs for `[CONSENT-STORE] Initialized (cache_service=wired`). Ensure `ENCRYPTION_KEY` is set so consent data can be decrypted by any pod.

**Symptom: warning at startup about Redis without encryption**
```
REDIS ENABLED WITHOUT ENCRYPTION_KEY
```
Set `ENCRYPTION_KEY` in `.env` before enabling `CACHE_PROVIDER=redis`. Generate one with: `python ops_scripts/generate_encryption_key.py`

---

## Agent Management

Agents represent MCP clients (Claude Code, Cursor, Copilot, etc.). Each agent has its own Okta OAuth app and a list of resources it can access.

### Create an Agent

```bash
curl -X POST http://localhost:8000/api/admin/agents \
  -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "agent_id": "copilot",
    "agent_name": "copilot",
    "client_id": "0oaXXXXXXXXXXXXXX",
    "client_secret": "optional-client-secret",
    "private_key": "{\"kty\":\"RSA\",\"n\":\"...\",\"e\":\"AQAB\",\"d\":\"...\"}",
    "backend_access": ["hr-system"],
    "enabled": true
  }'
```

Required fields: `agent_id`, `client_id`, `private_key`

The `private_key` must be a JWK-formatted RSA key. It is encrypted at rest.

### Update an Agent

```bash
# Add resource access
curl -X PUT http://localhost:8000/api/admin/agents/copilot \
  -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"backend_access": ["hr-system", "finance-system"]}'

# Update Okta client_id (after creating a new Okta app)
curl -X PUT http://localhost:8000/api/admin/agents/claude-code \
  -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"client_id": "0oaREAL_CLIENT_ID"}'

# Disable an agent
curl -X PUT http://localhost:8000/api/admin/agents/copilot \
  -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"enabled": false}'
```

### Delete an Agent

```bash
curl -X DELETE http://localhost:8000/api/admin/agents/copilot \
  -H "Authorization: Bearer $TOKEN"
```

### List Agents and Check Access

```bash
# List all agents
curl -s http://localhost:8000/api/admin/agents \
  -H "Authorization: Bearer $TOKEN" | python3 -m json.tool

# Get a specific agent
curl -s http://localhost:8000/api/admin/agents/claude-code \
  -H "Authorization: Bearer $TOKEN" | python3 -m json.tool
```

---

## CIMD Agent Matching

### The Problem

When a CIMD-based MCP client (like Claude Code) connects using a URL-based `client_id` (e.g., `https://claude.ai/oauth/client-metadata.json`), the gateway auto-provisions an agent with PLACEHOLDER credentials. These PLACEHOLDER keys cannot perform ID-JAG token exchange with Okta, so the agent falls back to gateway-level credentials or fails entirely.

### The Solution

Pre-register an agent with a `cimd_client_id` field set to the expected CIMD URL. When a CIMD client authenticates, the `ClientRegistry` matches the URL to the pre-registered agent **before** falling through to auto-provisioning. This gives the CIMD client real Okta credentials for ID-JAG exchange.

**Resolution order:**
1. Manual match (by Okta `client_id`)
2. CIMD match (by `cimd_client_id` URL) — **new**
3. CIMD auto-provision (PLACEHOLDER credentials)
4. DCR
5. None

### Step-by-Step Setup

**Step 1: Create an Okta OIDC app for the agent**

Create a Web application in Okta with:
- Grant types: Authorization Code, Refresh Token
- Client authentication: `private_key_jwt`
- Generate or upload a JWK key pair (ES256 recommended)
- Note the `client_id` (e.g., `0oaXXXXXX`)

**Step 2: Create the agent via Admin API**

```bash
curl -X POST http://localhost:8000/api/admin/agents \
  -H "Authorization: Bearer $ADMIN_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "agent_id": "claude-code",
    "client_id": "0oaXXXXXX",
    "client_secret": "...",
    "private_key": "{\"kty\":\"EC\",\"crv\":\"P-256\",\"x\":\"...\",\"y\":\"...\",\"d\":\"...\"}",
    "backend_access": ["hr-system", "deploy-server"],
    "cimd_client_id": "https://claude.ai/oauth/client-metadata.json"
  }'
```

Or use the Admin UI: navigate to Agents, click "Add Agent", and fill in the "CIMD Client ID" field.

**Step 3: Test the connection**

Connect with the MCP client and check the gateway logs:

```bash
docker compose logs -f okta-agent-mcp-adapter | grep CIMD-MATCH
```

You should see:
```
[CIMD-MATCH] CIMD client https://claude.ai/oauth/client-metadata.json matched to agent 'claude-code' (client_id=0oaXXXXXX)
```

And for the ID-JAG exchange:
```
[XAA] Using pre-registered CIMD agent credentials: agent=claude-code client_id=0oaXXXXXX (matched from https://claude.ai/oauth/client-metadata.json)
[XAA] Agent has own private key — using agent-specific credentials (client_id=0oaXXXXXX, agent_id=claude-code)
```

### Adding CIMD Matching to an Existing Agent

```bash
curl -X PUT http://localhost:8000/api/admin/agents/claude-code \
  -H "Authorization: Bearer $ADMIN_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"cimd_client_id": "https://claude.ai/oauth/client-metadata.json"}'
```

### Troubleshooting

**CIMD client gets PLACEHOLDER fallback**
- Verify the agent has `cimd_client_id` set: `GET /api/admin/agents/claude-code`
- Ensure the URL matches exactly (including trailing path)
- Check the agent is `enabled: true`

**ID-JAG exchange fails after CIMD match**
- Verify the agent's `private_key` is a valid JWK (not `"PLACEHOLDER"`)
- Check the Okta app is configured for `private_key_jwt` authentication
- Ensure the Okta app has the JWT bearer grant type enabled
- Enable `LOG_LEVEL=DEBUG` and check for `[ID-JAG]` log entries

**Token validation fails**
- Ensure `RELAY_OKTA_CLIENT_ID` is in the gateway's `allowed_audiences` for the validator
- CIMD tokens bypass JWT validation (they're relay-issued), so audience mismatch between the relay app and the agent's Okta app is expected and handled

**"Agent not found" error:**
- Verify X-MCP-Agent header matches an agent ID in PostgreSQL
- Use Admin API to check agents: `GET /api/admin/agents`
- Check agent is `enabled: true` via Admin API

**"Authorization denied" error:**
- Check resource name is in agent's `resource_access` list
- Use Admin API to verify agent access: `GET /api/admin/agents/{agent_id}`
- Verify resource exists in PostgreSQL via Admin API

**JWT validation fails:**
- Verify OKTA_DOMAIN matches the token issuer
- Check agent's client_id is in allowed_audiences list
- Enable DEBUG logging to see JWKS cache behavior

**Token exchange fails:**
- Verify agent's private_key is valid JWK format
- Check target_authorization_server is correct
- Verify agent's OAuth app has token exchange grant in Okta

**Import errors:**
- Run `pip install -r requirements.txt --force-reinstall`
- Ensure Python 3.10+ is being used

**Claude Code "Connection failed" or "No client info found":**
- The gateway supports DCR — clients can self-register at `/.well-known/oauth/registration`
- Alternatively, use `claude mcp add --client-id <id> --client-secret` to provide credentials
- Pass secret via `MCP_CLIENT_SECRET` env var to avoid corruption
- Verify with: `claude mcp get okta-gateway` (should show client_id)

**CIMD resolution fails:**
- Check the client_id URL is reachable from the gateway
- Verify the CIMD document's `client_id` field matches the URL
- Check `CIMD_TRUSTED_DOMAINS` if using allowlist mode
- SSRF protection blocks private IP ranges by default

**DCR registration rejected:**
- Check `DCR_ENABLED=true` in environment
- Verify source IP is in `DCR_IP_ALLOWLIST` (if configured)
- Check required fields: `client_name`, `redirect_uris`, `grant_types`
- View policy: `GET /api/admin/dcr/policy`

**AI Agent promotion not working:**
- Set both `OKTA_AI_AGENT_ENABLED=true` and `OKTA_AI_AGENT_AUTO_REGISTER=true`
- Verify `OKTA_SERVICE_CLIENT_ID` is set (or fall back to SSWS if available)
- Check logs for `AI Agent promotion` messages

**Claude Code shows 0 tools after connecting:**
- Check that the unified MCP handler is working: `POST /` with `tools/list`
- Verify the agent's `resource_access` list includes the resource name
- Check resource is reachable from the gateway container
- Enable `LOG_LEVEL=DEBUG` and look for tool discovery logs

**"invalid_client_secret" in Okta syslog:**
- The BFF token proxy must pass the Authorization: Basic header unchanged
- Re-register with `MCP_CLIENT_SECRET` env var (interactive prompt can corrupt the value)
---

## Resource Management

Resources are the MCP servers that agents connect to through the gateway. Each resource has a URL, routing paths, and an authentication method.

### Auth Method Configurations

**Okta Cross-App (ID-JAG token exchange):**

```json
{
  "name": "finance-system",
  "url": "https://finance-mcp.example.com",
  "paths": ["/finance", "/budgets"],
  "auth_method": "okta-cross-app",
  "auth_config": {
    "target_authorization_server": "https://partner.okta.com/oauth2/ausXXXX",
    "target_token_endpoint": "https://partner.okta.com/oauth2/ausXXXX/v1/token",
    "target_client_id": "0oaTARGET_APP",
    "target_client_secret": "target-secret"
  }
}
```

**Pre-Shared Key:**

```json
{
  "name": "hr-system",
  "url": "http://hr-mcp-server:8001",
  "paths": ["/hr", "/employees"],
  "auth_method": "pre-shared-key",
  "auth_config": {
    "api_key": "your-secret-key",
    "header_name": "X-API-Key"
  }
}
```

**Service Account (HTTP Basic Auth):**

```json
{
  "name": "legacy-system",
  "url": "http://legacy:9000",
  "paths": ["/legacy"],
  "auth_method": "service-account",
  "auth_config": {
    "username": "svc-account",
    "password": "svc-password"
  }
}
```

### Create a Resource

```bash
curl -X POST http://localhost:8000/api/admin/backends \
  -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "name": "finance-system",
    "url": "https://finance-mcp.example.com",
    "paths": ["/finance", "/budgets"],
    "auth_method": "okta-cross-app",
    "auth_config": {
      "target_authorization_server": "https://partner.okta.com/oauth2/ausXXXX",
      "target_token_endpoint": "https://partner.okta.com/oauth2/ausXXXX/v1/token",
      "target_client_id": "0oaTARGET_APP",
      "target_client_secret": "target-secret"
    },
    "timeout_seconds": 30,
    "enabled": true
  }'
```

### Update a Resource

```bash
curl -X PUT http://localhost:8000/api/admin/backends/finance-system \
  -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"url": "https://new-finance-mcp.example.com", "timeout_seconds": 60}'
```

### Delete a Resource

```bash
curl -X DELETE http://localhost:8000/api/admin/backends/finance-system \
  -H "Authorization: Bearer $TOKEN"
```

### List Resources

```bash
curl -s http://localhost:8000/api/admin/backends \
  -H "Authorization: Bearer $TOKEN" | python3 -m json.tool
```

---

## Monitoring

### Health Endpoints

```bash
# OAuth Protected Resource Metadata (primary health check)
curl -s http://localhost:8000/.well-known/oauth-protected-resource | python3 -m json.tool

# OAuth Authorization Server discovery
curl -s http://localhost:8000/.well-known/oauth-authorization-server | python3 -m json.tool
```

### Logs

```bash
# Follow gateway logs
docker compose logs -f okta-agent-mcp-adapter

# Follow all service logs
docker compose logs -f

# Last 100 lines from gateway
docker compose logs --tail 100 okta-agent-mcp-adapter

# Debug logging (set in .env or override)
LOG_LEVEL=DEBUG docker compose up -d okta-agent-mcp-adapter
```

### Audit Log

Query the audit log for configuration change history:

```sql
-- All changes in the last 24 hours
SELECT entity_type, entity_id, action, performed_by, created_at
  FROM audit_log
  WHERE created_at > NOW() - INTERVAL '24 hours'
  ORDER BY created_at DESC;

-- Changes to a specific agent
SELECT action, performed_by, created_at
  FROM audit_log
  WHERE entity_type = 'agent' AND entity_id = 'claude-code'
  ORDER BY created_at DESC;

-- All deletions
SELECT entity_type, entity_id, performed_by, created_at
  FROM audit_log
  WHERE action = 'deleted'
  ORDER BY created_at DESC;
```

### Container Status

```bash
docker compose ps
docker compose top               # Process list per container
docker stats --no-stream         # Resource usage snapshot
```

---

## Production Hardening

### TLS Termination

Run a reverse proxy (nginx, Caddy, ALB) in front of the gateway. The gateway trusts `X-Forwarded-*` headers via `--proxy-headers` and `--forwarded-allow-ips`.

```nginx
# Example nginx upstream
upstream gateway {
    server 127.0.0.1:8000;
}

server {
    listen 443 ssl;
    ssl_certificate     /etc/ssl/certs/gateway.crt;
    ssl_certificate_key /etc/ssl/private/gateway.key;

    location / {
        proxy_pass http://gateway;
        proxy_set_header Host $host;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }
}
```

In production, restrict forwarded IPs:

```yaml
# docker-compose.override.yml
services:
  okta-agent-mcp-adapter:
    command: ["--forwarded-allow-ips", "10.0.0.0/8"]
```

### Secrets Management

- Store `ENCRYPTION_KEY` and `POSTGRES_PASSWORD` in a secrets manager (Vault, AWS Secrets Manager, etc.)
- Use Docker secrets or Kubernetes secrets instead of environment variables
- Admin API authentication is handled entirely by Okta (v0.15.x+); rotate the
  Admin UI OIDC client secret in Okta and redeploy with the new
  `ADMIN_UI_OKTA_CLIENT_SECRET`.

### Key Rotation

Encryption key rotation requires re-encrypting all stored credentials. This is not yet automated. The manual process:

1. Export all agents and backends via Admin API
2. Set the new `ENCRYPTION_KEY`
3. Re-create all agents and backends via Admin API (they'll be encrypted with the new key)

### Rate Limiting

The Admin API does not have built-in rate limiting. Add rate limiting at the reverse proxy layer:

```nginx
limit_req_zone $binary_remote_addr zone=admin:10m rate=10r/s;

location /api/admin/ {
    limit_req zone=admin burst=20 nodelay;
    proxy_pass http://gateway;
}
```

### Read-Only Filesystem

The Docker container runs with a read-only root filesystem by default. Only `/tmp` (tmpfs) and `/app/logs` (volume mount) are writable:

```bash
docker run --read-only --tmpfs /tmp:rw,noexec,nosuid,size=10m \
  --security-opt="no-new-privileges:true" \
  --cap-drop=ALL \
  -v ./logs:/app/logs:rw \
  okta-agent-mcp-adapter
```

---

## Troubleshooting

### "Port is already allocated" or "address already in use"

Something on your host is already listening on the default port. Check with `ss -tlnp | grep :8000` (Linux) or `lsof -iTCP:8000 -sTCP:LISTEN` (macOS).

Fix for docker-compose:

```bash
GATEWAY_HOST_PORT=18000 docker compose up -d
```

This remaps only the host-side port (container stays on 8000), so inter-service URLs inside the compose network still work.

For ECS deployments, set Terraform variables:

```bash
cd deploy/aws-ecs
TF_VAR_gateway_port=9000 ./deploy.sh --apply

cd ../aws-ecs-examples
TF_VAR_hr_backend_port=9001 ./deploy.sh --apply
```

Each project has its own port variables. Adapter and admin UI ports live in `deploy/aws-ecs/`. HR backend port lives in `deploy/aws-ecs-examples/`.

### Gateway Won't Start

```bash
# Check container logs
docker compose logs okta-agent-mcp-adapter

# Common causes:
# - DATABASE_URL not set or wrong → check .env
# - ENCRYPTION_KEY not set → run setup.sh or generate manually
# - PostgreSQL not ready → check: docker compose ps postgres
# - Alembic migration failed → run manually:
docker compose exec okta-agent-mcp-adapter alembic upgrade head
```

### JWT Validation Fails

```bash
# Verify Okta configuration
source .env
echo "OKTA_DOMAIN: $OKTA_DOMAIN"
echo "OKTA_ISSUER: $OKTA_ISSUER"

# Check JWKS endpoint is reachable from the container
docker compose exec okta-agent-mcp-adapter \
  python -c "import urllib.request; print(urllib.request.urlopen('https://${OKTA_DOMAIN}/.well-known/openid-configuration').read()[:200])"

# Enable debug logging
LOG_LEVEL=DEBUG docker compose up -d okta-agent-mcp-adapter
docker compose logs -f okta-agent-mcp-adapter | grep -i jwks
```

### Agent Not Found

```bash
# List all agents (including disabled)
docker compose exec postgres psql -U gateway_user gateway_db \
  -c "SELECT agent_id, agent_name, enabled FROM agents;"

# Agent ID in X-MCP-Agent header must match agent_id in the database
```

### Authorization Denied

```bash
# Check agent's backend_access list (resource access)
curl -s http://localhost:8000/api/admin/agents/claude-code \
  -H "Authorization: Bearer $TOKEN" | python3 -m json.tool

# Check resource exists
curl -s http://localhost:8000/api/admin/backends \
  -H "Authorization: Bearer $TOKEN" | python3 -m json.tool

# The resource name in backend_access must exactly match the resource name
```

### Token Exchange Fails

- Verify the agent's `private_key` is valid JWK format (not PEM)
- Check `target_authorization_server` URL is correct
- Verify the agent's Okta app has the token exchange grant type enabled
- Enable `LOG_LEVEL=DEBUG` and look for token exchange errors in logs

### PostgreSQL Connection Issues

```bash
# Check PostgreSQL is running
docker compose ps postgres

# Test connectivity
docker compose exec postgres pg_isready -U gateway_user -d gateway_db

# Check DATABASE_URL matches docker-compose service name
# Inside containers, use hostname "postgres" (not "localhost")
```

### Encryption/Decryption Errors

- Verify `ENCRYPTION_KEY` in `.env` matches what was used when data was written
- Do not change the encryption key without re-encrypting stored data
- Generate a fresh key: `python3 -c "import os,base64; print(base64.b64encode(os.urandom(32)).decode())"`

### Port Conflicts

```bash
# Check what's using the port
lsof -i :8000
lsof -i :5432

# Change ports in .env
GATEWAY_PORT=8080
POSTGRES_PORT=5433
```

---

## Okta Agent Import

Import AI Agent principals from Okta Universal Directory into the adapter. Imported agents get minimal records (agent_id, backend_access, enabled) — all identity data stays in Okta.

### Prerequisites

- `OKTA_AI_AGENT_ENABLED=true`
- Admin UI OIDC app with OAuth for Okta scopes — see `okta_agent_proxy_admin_ui/OKTA_OIDC_SETUP.md` Step 1b
- Service app for event-driven sync: `OKTA_SERVICE_CLIENT_ID` — see `docs/OKTA_SERVICE_APP_SETUP.md`
- Event Hook for real-time sync — see `docs/OKTA_EVENT_HOOK_SETUP.md`
- Admin user with Super Admin role (or equivalent custom role)

### Sync Mechanisms

| Trigger | Auth | When | Setup Required |
|---------|------|------|----------------|
| Admin clicks "Sync" per agent | Admin's Okta token | On demand | None (always available) |
| Admin clicks "Sync All Agents" | Admin's Okta token | On demand | None (always available) |
| Admin clicks "Sync Backends" | Admin's Okta token | On demand | None (always available) |
| Admin calls sync API | Admin's Okta token | On demand | None (always available) |
| Okta Event Hook fires | Service app (private_key_jwt) | Real-time | Event Hook + Service App |

Manual sync is the primary mechanism for demos and local development.
Event hooks add real-time automation for production deployments.

### Admin API Endpoints

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/admin/okta/agents` | List importable agents from Okta |
| GET | `/api/admin/okta/agents/{id}` | Get agent detail from Okta |
| POST | `/api/admin/okta/agents/{id}/import` | Import single agent |
| POST | `/api/admin/okta/agents/bulk-import` | Import multiple agents |
| POST | `/api/admin/okta/agents/{id}/sync` | Sync single agent |
| POST | `/api/admin/okta/sync/agents` | Sync all imported agents |
| POST | `/api/admin/okta/sync/backends` | Sync Managed Connection scopes |
| POST | `/api/admin/okta/sync/all` | Sync everything |

All import/sync endpoints require an Okta OAuth token (not legacy JWT).

### Local Testing with Event Hook Simulator

```bash
# Simulate agent deactivation
python ops_scripts/simulate_okta_event_hook.py --event agent.deactivate --agent-id agtXXXXXX

# Simulate verification handshake
python ops_scripts/simulate_okta_event_hook.py --verify

# See all options
python ops_scripts/simulate_okta_event_hook.py --help
```

---

## Claude Code Connection Guide

### Prerequisites

1. Gateway is running: `curl http://localhost:8000/.well-known/oauth-protected-resource`
2. Agent exists in database (seeded by `setup.sh` or created via Admin API)
3. Agent's `client_id` matches your Okta OIDC app
4. Claude Code v2.1.30 or newer (for `--client-id`/`--client-secret` support)

### Okta Application Requirements

Your Okta OIDC application must be configured as follows:

| Setting | Value |
|---------|-------|
| Application type | Web (confidential client) |
| Grant types | Authorization Code, Refresh Token |
| Redirect URIs | `http://localhost:3000/callback` |
| PKCE | Allowed (S256) |
| Client authentication | client_secret_basic |
| Scopes | openid, profile, email, offline_access |

> **Important**: Claude Code defaults to port 3000 for the OAuth callback. If you use `--callback-port` to change this, update the Okta redirect URI to match.

### Get Agent Credentials

```bash
# See "Admin API Authentication" above for how to obtain OKTA_ADMIN_TOKEN.
export OKTA_ADMIN_TOKEN="<paste token from Admin UI>"

curl -s http://localhost:8000/api/admin/agents/claude-code \
  -H "Authorization: Bearer $OKTA_ADMIN_TOKEN" | python3 -m json.tool
```

Save the `client_id` — you'll need it to register the MCP server.

### Register in Claude Code

Use the `claude mcp add` command with explicit OAuth credentials. The gateway does not support Dynamic Client Registration (DCR), so `--client-id` and `--client-secret` are required.

**Recommended** — pass the secret via environment variable (avoids typos and shell escaping issues):

```bash
MCP_CLIENT_SECRET='<your-okta-client-secret>' \
  claude mcp add --transport http \
  --client-id <your-okta-client-id> \
  --client-secret \
  --callback-port 3000 \
  --header "X-MCP-Agent: claude-code" \
  okta-gateway http://localhost:8000
```

> **Critical**: The `MCP_CLIENT_SECRET` env var must be on the same line as the command (or use proper line continuation). The gateway URL must be `http://localhost:8000` (root path) — do NOT append `/mcp`.

**Alternative** — interactive secret prompt:

```bash
claude mcp add --transport http \
  --client-id <your-okta-client-id> \
  --client-secret \
  --callback-port 3000 \
  --header "X-MCP-Agent: claude-code" \
  okta-gateway http://localhost:8000
```

Claude Code will prompt for the secret with masked input.

### Authenticate

Inside Claude Code:

```
/mcp
```

Select "Authenticate" for okta-gateway. Your browser will open to the Okta login page. After authenticating, Claude Code receives tokens via the gateway's BFF token proxy and stores them locally.

### Verify Connection

```
/mcp
```

You should see:

```
MCP Servers (1 active):
└─ okta-gateway
   ├─ Status: Connected
   ├─ Tools: 6
   │   ├─ hr-system__health_check
   │   ├─ hr-system__get_employee
   │   ├─ hr-system__search_employees
   │   ├─ hr-system__get_org_chart
   │   ├─ hr-system__get_leave_balance
   │   └─ hr-system__submit_leave_request
   └─ Transport: http
```

Tools are namespaced by resource (e.g., `hr-system__get_employee`). The gateway consolidates tools from all resources the agent has access to and presents them as a unified MCP server.

### Register Cursor

Same pattern with the `cursor` agent ID:

```bash
MCP_CLIENT_SECRET='<cursor-okta-client-secret>' \
  claude mcp add --transport http \
  --client-id <cursor-okta-client-id> \
  --client-secret \
  --callback-port 3000 \
  --header "X-MCP-Agent: cursor" \
  okta-gateway-cursor http://localhost:8000
```

### Useful Commands

```bash
# List registered MCP servers
claude mcp list

# Inspect a specific server's config
claude mcp get okta-gateway

# Remove and re-register (if auth breaks)
claude mcp remove okta-gateway

# Check MCP connection status inside Claude Code
/mcp

# View debug logs
claude --mcp-debug
```

---

## Troubleshooting Claude Code Integration

### BFF Token Proxy Fails (OAuth login completes but connection fails)

The gateway proxies token exchanges at `/oauth2/v1/token`. If Okta login succeeds but Claude Code still fails to connect:

```bash
# Check gateway logs during the OAuth flow
docker compose logs -f okta-agent-mcp-adapter | grep -i "token"

# You should see:
# "BFF token request: grant_type=authorization_code, client_id=..."
# "Proxying auth code exchange to Okta for client_id=..."
# "Successfully exchanged auth code with Okta"

# If you see "Okta token exchange failed: status=401":
# - Check Okta syslog for "invalid_client_secret"
# - The gateway must pass the Authorization: Basic header to Okta unchanged
# - Verify the client_secret was entered correctly (use MCP_CLIENT_SECRET env var)

# If you see "Okta token exchange failed: status=400":
# - Check Okta syslog for "invalid_grant" (auth code expired or replay)
# - Verify redirect_uri matches: http://localhost:3000/callback
```

### Claude Code OAuth Flow Not Starting

```bash
# Check that the gateway's discovery endpoints are working
curl -s http://localhost:8000/.well-known/oauth-protected-resource | python3 -m json.tool
curl -s http://localhost:8000/.well-known/oauth-authorization-server | python3 -m json.tool

# Verify token_endpoint points to the gateway (BFF pattern):
# "token_endpoint": "http://localhost:8000/oauth2/v1/token"

# Check Claude Code has the auth config stored
claude mcp get okta-gateway
# Should show client_id and callback_port — if missing, re-register
```

### Tools Not Showing After Authentication

If Claude Code authenticates but `/mcp` shows 0 tools:

```bash
# Test the unified endpoint manually
curl -s -X POST http://localhost:8000 \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer <token>" \
  -H "X-MCP-Agent: claude-code" \
  -d '{"jsonrpc":"2.0","id":"1","method":"tools/list","params":{}}' \
  | python3 -m json.tool

# Check agent has backend_access configured
curl -s http://localhost:8000/api/admin/agents/claude-code \
  -H "Authorization: Bearer $TOKEN" | python3 -m json.tool
# Verify "backend_access" includes "hr-system"

# Check resource is reachable from gateway container
docker compose exec okta-agent-mcp-adapter \
  curl -s http://hr-mcp-server:8001/mcp \
  -H "Content-Type: application/json" \
  -d '{"jsonrpc":"2.0","id":"1","method":"tools/list","params":{}}'
```

### "invalid_client_secret" in Okta Syslog

- The BFF token proxy must pass the `Authorization: Basic` header unchanged
- Re-register with `MCP_CLIENT_SECRET` env var (interactive prompt can corrupt the value)
- Verify the Okta app uses `client_secret_basic` authentication (not `client_secret_post`)
