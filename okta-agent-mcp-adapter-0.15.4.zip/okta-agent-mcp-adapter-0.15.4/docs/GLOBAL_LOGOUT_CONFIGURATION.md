# Global Logout (Okta ITP Universal Logout)

## Overview

Okta Identity Threat Protection (ITP) Universal Logout lets an Okta admin (or an automated risk-policy action) revoke a user's live sessions and refresh tokens across every integrated app when a risk signal fires — for example, when an admin clears sessions for a user, when ITP detects anomalous activity, or when a continuous-access policy decides the user should be forced to re-authenticate. Okta calls a per-app revocation endpoint that the adapter exposes at `/oauth/global-token-revocation` (per `draft-parecki-oauth-global-token-revocation`).

On receiving a valid revocation call, the adapter revokes all adapter-held state for the named user in three steps:

1. **`UserTokenStore`** — drops the server-side `id_token` + `refresh_token` mappings for that user (L1 + L2 + cross-pod pub/sub). The next MCP request from that user with a now-stale token fails JWT validation upstream.
2. **`TokenCache`** — drops cached backend tokens for that user, covering both the ID-JAG family (`{user_id}*`) and the STS family (`sts:{sha256(user_id)[:12]}:*`).
3. **`MCPSessionManager`** — issues DELETE calls in parallel to each downstream MCP server that has a locally-known session for the user.

## Prerequisites

- Okta Identity Engine tenant with Identity Threat Protection (ITP) enabled. ITP is a paid add-on.
- Admin role with permission to manage apps and clear user sessions.
- Adapter deployed at a TLS-reachable URL.

## Architecture context

The adapter currently uses the Okta org authorization server. This means `OKTA_ISSUER == https://{OKTA_DOMAIN}` in production, and all JWT `iss` values, body `subject.iss` values, and JWKS lookups resolve through this single issuer. Custom AS code paths exist for a future Okta capability (originating token from custom AS for the XAA/ID-JAG flow) but are not used today. If Okta ever supports that topology, this doc and the JWT validation logic must be re-verified against Okta's at-the-time guidance for which AS signs Universal Logout JWTs before enabling.

The adapter does not have a single Okta application that all users sign in through. Each Agent record is linked to its own Okta OIDC application (which may be shared across multiple agents or be unique per agent — operator's choice). Universal Logout is therefore configured per linked Okta app, and the adapter automatically maintains the trust set of accepted JWT `sub` values from its agents table.

## Adapter-side configuration

| Variable | Required | Default | Description |
|---|---|---|---|
| `GATEWAY_BASE_URL` | yes | — | Externally-visible adapter URL. Used to build the expected JWT `aud` claim (`GATEWAY_BASE_URL + /oauth/global-token-revocation`). |
| `GLOBAL_LOGOUT_AUDIENCE` | no | `GATEWAY_BASE_URL + path` | Override the expected `aud` claim if Okta is configured with a non-default value. |
| `GLOBAL_LOGOUT_RATE_LIMIT_PER_MIN` | no | `100` | Per-IP, per-replica rate cap on the revocation endpoint. |
| `GLOBAL_LOGOUT_RATE_LIMIT_MAX_IPS` | no | `4096` | Caps the in-memory IP table (`cachetools.TTLCache`); idle IPs age out after 2× the rate window. No unbounded growth. |
| `GLOBAL_LOGOUT_ALLOWLIST_TTL_SECONDS` | no | `3600` | The adapter caches the set of trusted Universal Logout `client_id`s from the agents table for this duration (default 1 hour). The cache is also invalidated immediately on any agent CRUD via the `CHANNEL_AGENT_INVALIDATE` pub/sub channel, so this TTL is a safety net for pub/sub partition scenarios rather than the primary refresh path. Lower values reduce the max-stale-trust window at the cost of more DB queries. |
| `OKTA_DOMAIN`, `OKTA_ISSUER` | yes | — | Already used elsewhere. The adapter validates the inbound JWT signature against `https://{OKTA_DOMAIN}/oauth2/v1/keys` via the existing `OktaTokenValidator`. |

## Okta Admin Console configuration

For the full admin-console walkthrough (screens, fields, options), follow Okta's official documentation:

- Universal Logout setup: https://help.okta.com/oie/en-us/content/topics/itp/config-universal-logout.htm
- ITP continuous access policies: https://help.okta.com/oie/en-us/content/topics/itp/enforce-continuous-access.htm
- ITP entity risk policies: https://help.okta.com/oie/en-us/content/topics/itp/entity-risk-policy.htm

### Per-agent-linked-app configuration

The adapter has no single "front door" Okta application. Each Agent record in the adapter is linked to an Okta OIDC application. Multiple agents may share one Okta app, or each may have its own.

For Universal Logout to revoke a user's tokens on the adapter, the Okta app the user signed in through MUST have Universal Logout configured. Therefore: **configure Universal Logout on every Okta OIDC app that any agent is linked to.**

Coverage by construction: a user can only obtain adapter-issued tokens by authenticating through one of these linked apps. So if Universal Logout is configured on every linked app, every user with adapter access is covered.

Per-app configuration steps mirror Okta's docs at https://help.okta.com/oie/en-us/content/topics/itp/config-universal-logout.htm

For each agent's linked Okta OIDC app:

- **Logout endpoint URL**: `https://<adapter>/oauth/global-token-revocation`
  (Same endpoint for every app — the adapter accepts logout JWTs from any registered agent's linked app.)
- **Endpoint authentication type**: `Signed JWT` (Okta default).
- **Subject format type**: `Issuer and Subject Identifier`.
  - Do NOT select `Email Identifier` — the adapter rejects email format with `HTTP 400 unsupported_subject_format`.

**Auto-trust:** The adapter validates the JWT `sub` claim (the calling Okta app's `client_id`) against the set of `client_id`s in its agents table. There is no env var to maintain — when an agent is registered, its linked app's `client_id` is automatically accepted as a Universal Logout source. When an agent is deleted, its `client_id` stops being accepted (after pub/sub propagation, or within `GLOBAL_LOGOUT_ALLOWLIST_TTL_SECONDS` in the worst case). Disabled agents remain in the allowlist — their existing users may still hold tokens that need revocation.

## Verifying the integration

- **Manual trigger**: follow Okta's instructions for clearing a user's sessions with Universal Logout enabled: https://help.okta.com/oie/en-us/content/topics/itp/config-universal-logout.htm
- **Expected adapter behavior**: within ~2 seconds, the user's `UserTokenStore` entries, `TokenCache` entries, and local MCP sessions are cleared. The next inbound MCP call from that user fails JWT validation at Layer 2 and returns `401`.
- **Audit events to expect**:
  - `GLOBAL_LOGOUT_REQUESTED` (synchronously, before auth)
  - `GLOBAL_LOGOUT_COMPLETED` (from background task)
  - zero or more `GLOBAL_LOGOUT_BACKEND_SESSION_TERMINATED` per backend with an active session

### Detecting linked apps with Universal Logout NOT configured

Run a periodic reconciliation report comparing two sets:

- **A.** The set of all `client_id`s in the adapter's agents table: admin API `GET /api/admin/agents` → collect each `agent.client_id`.
- **B.** The set of `client_id`s that have ever appeared as the JWT `sub` in a successful `GLOBAL_LOGOUT_REQUESTED` audit event over the observation window (e.g. last 30 days).

Any `client_id` in A but not in B is a linked Okta app that has never sent a Universal Logout call to the adapter. This may be benign (no logout-triggering events for users of that app in the window) or may indicate Universal Logout is not configured on that app. Investigate with the Okta admin to confirm.

Conversely, any `client_id` in B but not in A is a logout source that is no longer a registered agent — the JWT verification would now reject it, and the audit row is historical only.

## Inbound JWT format reference

Per Okta's Universal Logout spec, the inbound POST contains:

```
Authorization: Bearer <signed-JWT>
```

where the JWT looks like:

```json
// Header
{
  "typ": "global-token-revocation+jwt",
  "alg": "RS256",
  "kid": "<key-id-from-org-JWKS>"
}
// Payload
{
  "jti": "<unique-id>",
  "iss": "https://<okta_domain>",
  "sub": "<calling-Okta-app-client_id>",  // validated against agents table (see below)
  "aud": "https://<adapter>/oauth/global-token-revocation",
  "iat": <now>,
  "nbf": <now - 5m>,
  "exp": <now + 5m>
}
```

The body is JSON with a subject identifier per RFC 9493:

```json
{
  "subject": {
    "format": "iss_sub",
    "iss": "https://<okta_domain>",
    "sub": "<okta-user-id>"
  }
}
```

For the org-AS adapter, the JWT `iss` and the body `subject.iss` are the **same value** — both are `https://{OKTA_DOMAIN}`.

**`sub` claim:** the `client_id` of the calling Okta OIDC app. The adapter validates this against the set of `client_id`s in its agents table (via `store.get_all_agents`). Both enabled and disabled agents are trusted; only deleted agents are rejected.

## Admin-initiated force logout

In addition to the Okta-ITP-initiated flow described above, an operator can
trigger the same three-step revocation cascade from the Admin UI. This is
useful when the adapter's Okta org does not have ITP enabled, or when an
admin needs to revoke a single user's tokens without waiting for a risk
signal to fire.

- **UI path:** Admin UI → Security & Compliance → **User Sessions** →
  enter email or Okta `sub` → confirm.
- **Endpoint:** `POST /api/admin/users/force-logout`
  - Body: exactly one of `{"email": "<user@example.com>"}` or `{"sub": "<00u...>"}`.
  - Response: the same `GlobalLogoutHandler` summary (`tokens_revoked`,
    `cache_swept`, `sessions_terminated`, `sessions_failed`, `backends`)
    that the `/oauth/global-token-revocation` path produces.
- **Audit events:** one `ADMIN_FORCE_LOGOUT` (`admin.user.force_logout`)
  event is emitted for the admin action, carrying `actor`, `target_sub`,
  `target_email`, and `correlation_id`. The underlying revocation still
  emits `GLOBAL_LOGOUT_COMPLETED`, so ULO-native dashboards continue to
  reflect the event unchanged.

### Okta scope requirement

When the admin supplies an email address, the adapter resolves it to an
Okta `sub` by calling `GET /api/v1/users/{login}` on the Okta Management
API using the admin's own access token. The Admin UI OIDC application
therefore needs the **`okta.users.read`** scope granted to it; without
it the endpoint returns `403 forbidden` and the UI surfaces the
"missing `okta.users.read` scope" toast.

If the admin pastes an Okta `sub` directly the resolver is skipped and
the `okta.users.read` scope is not required.

## Troubleshooting

**`GLOBAL_LOGOUT_AUTH_FAILED` with reason `missing_bearer`**
Okta is calling without a signed JWT. Verify `Endpoint authentication type` is `Signed JWT` in the Okta app config.

**`GLOBAL_LOGOUT_AUTH_FAILED` with reason `unexpected_typ`**
The JWT `typ` header isn't `global-token-revocation+jwt`. Open a support case if you see this with a properly configured Okta app.

**`GLOBAL_LOGOUT_AUTH_FAILED` with reason mentioning `Signature` or `kid`**
JWKS mismatch. Verify `OKTA_DOMAIN` matches the tenant configured for the integration. The adapter caches JWKS for 1 hour; if keys were recently rotated, restart the adapter.

**`GLOBAL_LOGOUT_AUTH_FAILED` with reason mentioning `Issuer`**
The JWT `iss` doesn't match the adapter's configured issuer. Common cause: `OKTA_DOMAIN` is set to a custom-domain alias on the adapter side but the test tenant is using the default org domain (or vice versa). Reconcile.

**`GLOBAL_LOGOUT_AUTH_FAILED` with reason mentioning `audience` or `aud`**
The JWT `aud` claim doesn't match the expected URL. Either fix `GATEWAY_BASE_URL` or set `GLOBAL_LOGOUT_AUDIENCE` to the exact `aud` Okta is sending.

**`GLOBAL_LOGOUT_AUTH_FAILED` with reason `sub_not_in_allowlist`**
The JWT `sub` (the calling Okta app's `client_id`) does not match any registered agent's linked-app `client_id`. Possible causes:

- **(a)** The Okta app sending the JWT is for an agent that has been deleted from the adapter. Audit will show the agent in question; this is benign if expected.
- **(b)** The Okta app is for an agent that exists in the adapter but its `client_id` field has drifted from the actual Okta app (e.g. the app was rotated in Okta but not updated in the adapter). Reconcile via the admin API — get the agent and update its `client_id` to match Okta.
- **(c)** The Okta app sending the JWT is not actually a registered agent in the adapter (someone configured Universal Logout on an unrelated app pointing at our endpoint). Reject is correct; investigate why the app was misconfigured.
- **(d)** Recent agent CRUD has not yet propagated to this replica. Wait up to `GLOBAL_LOGOUT_ALLOWLIST_TTL_SECONDS` (default 3600s = 1h). If the replica is healthy and Redis is reachable, pub/sub propagation should be sub-second; the TTL is only a fallback.

**`GLOBAL_LOGOUT_SUBJECT_INVALID` with reason `iss_mismatch`**
`subject.iss` in the body doesn't match `settings.issuer`. For org-AS deployments these should be identical.

**`HTTP 400 unsupported_subject_format`**
Okta is sending `Email` format. Change `Subject format type` to `Issuer and Subject Identifier` in the Okta app config.

**`HTTP 204` returned for an unknown user**
Per Okta's developer guide, the adapter returns `204` (not `404`) for unrecognized users to prevent account enumeration. The audit event `GLOBAL_LOGOUT_SUBJECT_NOT_FOUND` records this case for ops visibility.

**`HTTP 204` returned but tokens still valid on next call**
Multi-replica deployment without Redis as the L2 cache provider. `UserTokenStore.aremove_by_user` publishes pub/sub invalidation that other replicas listen for; without Redis, peer replicas' in-memory caches stay populated. Configure `CACHE_PROVIDER=redis` for production multi-replica deployments.

**Backend MCP sessions still active on peer replicas**
Known limitation. `MCPSessionManager.terminate_all_for_user` only iterates the local replica's session cache. Sessions held by peer replicas die when their TTL (default 1 hour) expires. Cross-pod session enumeration is deferred.

**`GLOBAL_LOGOUT_BACKEND_SESSION_FAILED`**
A backend MCP server returned non-2xx on the DELETE call or timed out (default 3s per call). The adapter's local cache is still cleared, so the next user-scoped call fails JWT validation upstream regardless. Investigate backend health for repeated failures.

## Scope and limitations

- Rate limiter is per-replica. In multi-replica deployments the effective limit is `N × GLOBAL_LOGOUT_RATE_LIMIT_PER_MIN`. The in-memory IP table is bounded (`GLOBAL_LOGOUT_RATE_LIMIT_MAX_IPS`, default 4096) and idle-evicts; no unbounded growth.
- In-flight tool calls that already passed Layer 2 will complete. The **next** call after revocation is guaranteed to fail.
- Multi-replica MCP session termination is local-only.
- The adapter does **not** implement OIDC Back-Channel Logout (sid-based) in this release.
- `email` subject format is not supported (adapter design choice).
- Universal Logout `client_id` allowlist is sourced from the agents table. CRUD updates propagate via the `CHANNEL_AGENT_INVALIDATE` pub/sub channel within sub-second window when Redis is reachable; otherwise refreshes every `GLOBAL_LOGOUT_ALLOWLIST_TTL_SECONDS` (default 1 hour).
- `jti` replay protection is not yet implemented. Per Okta dev guide, `jti` is included in the JWT but not currently tracked.
- This implementation assumes the Okta **org** authorization server is the originating issuer. When Okta supports custom-AS as the originator for XAA flows, re-verify Okta's guidance on which AS signs Universal Logout JWTs before enabling.

## References

- IETF: `draft-parecki-oauth-global-token-revocation`
- Okta admin doc: https://help.okta.com/oie/en-us/content/topics/itp/config-universal-logout.htm
- Okta developer guide: https://developer.okta.com/docs/guides/oin-universal-logout-overview/
- Subject identifiers: RFC 9493
