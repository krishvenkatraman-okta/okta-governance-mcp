# ADR-001: Move Scopes from Agent Records to Agent-Backend Junction

**Status:** Accepted
**Date:** 2026-03-04
**Author:** Engineering

## Context

The original design stored a `scopes` field on the `agents` table as a JSON array
(e.g., `["mcp:read", "mcp:write"]`). This was used by `check_agent_has_scopes()`
and `validate_agent_scopes()` to verify that an agent had the required permissions
before proxying a request.

In practice, this model is incorrect for the gateway's authorization architecture:

1. **Authentication** is handled by Okta JWT validation. The OIDC token carries
   standard scopes (`openid`, `profile`, `email`) — these are validated by the
   Okta token validator, not by agent config.

2. **Authorization** is a binary ACL check: "does this agent have `backend_access`
   to the requested backend?" There are no scope-based gradations at this layer.

3. **Token exchange** is where backend-specific scopes matter. When the gateway
   issues an ID-JAG JWT and exchanges it for a backend access token, the `scope`
   parameter in the token request should be specific to that agent+backend pair —
   not a global agent-level setting.

Storing scopes on the agent record conflates these three concerns and makes it
impossible to configure different scopes for different backends.

## Decision

1. **Deprecate agent-level scopes.** The `agents.scopes` column is retained for
   backward compatibility but is ignored by the request pipeline. Default changed
   from `["mcp:read"]` to `[]`.

2. **Add scopes to the junction table.** A new `scopes` column on
   `agent_backend_access` (TEXT, nullable, JSON array) stores per-backend scopes.
   `NULL` means "use backend default scopes or omit the scope parameter."

3. **Deprecate scope-checking functions.** `check_agent_has_scopes()`,
   `AgentAuthorizationChecker.check_scopes()`, and `validate_agent_scopes()` are
   converted to no-ops that log a deprecation warning and return True.

4. **New query method.** `PostgresBackendStore.get_agent_backend_scopes(agent_id,
   backend_name)` returns the scopes from the junction for use during token exchange.

## Authorization Model (Post-ADR)

```
Request arrives
  1. Authentication  — Is the Okta JWT valid? (standard OIDC scopes: openid, profile)
  2. Authorization   — Does agent have backend_access entry? (binary ACL)
  3. Token Exchange  — Scopes from agent_backend_access junction (per-backend)
  4. Proxy           — Forward with backend credentials
```

## Migration

- **Migration 002** adds the `scopes` column to `agent_backend_access`.
- The `agents.scopes` column is NOT removed — that will be a future migration (003)
  once all references are confirmed removed.
- Existing junction records get `scopes = NULL` (use defaults).

## Consequences

- Agent creation no longer requires or uses a `scopes` field. Passing `scopes: []`
  is safe and recommended for clarity.
- Code that calls `check_agent_has_scopes()` will see a deprecation warning in logs
  but will not break (function returns True).
- Token exchange code can be updated in a follow-up to read scopes from
  `get_agent_backend_scopes()` and include them in the token request.
- The Admin API can be extended to accept scopes on the junction in a future PR.
