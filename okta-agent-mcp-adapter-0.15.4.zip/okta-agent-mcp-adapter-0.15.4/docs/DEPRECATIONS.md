# Deprecation Log

Tracks deprecated features, their replacements, and removal targets.

---

## SERVER_PORT (HR backend, deploy server)

**Deprecated:** PORT-P1 (port configurability pack)
**Replacement:** `HR_BACKEND_PORT` (HR backend) / `DEPLOY_SERVER_PORT` (deploy server)
**Removal target:** v2.0.0
**Migration:** Set `HR_BACKEND_PORT` or `DEPLOY_SERVER_PORT` in `.env` instead of `SERVER_PORT`. No code changes required on the caller side. Setting `SERVER_PORT` today still works but emits a `DeprecationWarning` at startup.
