# Docker Commands Reference — Okta MCP Adapter

Quick reference for operating the local development stack. All `docker compose`
commands should be run from the **repository root** directory where
`docker-compose.yml` lives.

---

## Container Status

```bash
# List running containers
docker compose ps

# List all containers (including stopped)
docker compose ps -a

# Container resource usage (CPU, memory)
docker stats --no-stream

# Detailed inspect of a single container
docker inspect okta-agent-mcp-adapter

# Health status of a specific container
docker inspect --format='{{.State.Health.Status}}' okta-agent-mcp-adapter
```

---

## Start / Stop / Restart

```bash
# Start all services
docker compose up -d

# Stop all services (containers removed, volumes preserved)
docker compose down

# Stop all services AND delete volumes (full reset)
docker compose down -v

# Restart all services
docker compose restart

# Restart a single service
docker compose restart okta-agent-mcp-adapter
docker compose restart postgres
docker compose restart redis
docker compose restart admin-ui

# Stop a single service
docker compose stop okta-agent-mcp-adapter

# Start a single service
docker compose start okta-agent-mcp-adapter
```

---

## Rebuild and Restart

```bash
# Rebuild all images and restart
docker compose up -d --build

# Rebuild a single service and restart it
docker compose up -d --build okta-agent-mcp-adapter

# Force recreate containers (without rebuild)
docker compose up -d --force-recreate

# Full clean rebuild (remove everything, rebuild, start)
docker compose down -v
docker compose up -d --build
```

---

## Viewing Logs

```bash
# Follow all logs (Ctrl+C to stop)
docker compose logs -f

# Follow logs for a specific service
docker logs -f okta-agent-mcp-adapter
docker logs -f okta-mcp-postgres
docker logs -f okta-mcp-redis
docker logs -f okta-mcp-admin-ui

# Last 100 lines of a service
docker logs --tail 100 okta-agent-mcp-adapter

# Logs with timestamps
docker logs -t okta-agent-mcp-adapter

# Logs since a specific time
docker logs --since 30m okta-agent-mcp-adapter
docker logs --since 2024-01-15T10:00:00 okta-agent-mcp-adapter
```

---

## Examples Overlay

The example resource MCP servers (HR System, Deploy Server) are defined in
`docker-compose.examples.yml` and overlay onto the base `docker-compose.yml`.
Run from the repository root:

```bash
# Start base stack + example resources
docker compose -f docker-compose.yml \
  -f docker-compose.examples.yml up -d

# Rebuild example resources only
docker compose -f docker-compose.yml \
  -f docker-compose.examples.yml up -d --build hr-mcp-server deploy-mcp-server

# Stop everything (base + examples)
docker compose -f docker-compose.yml \
  -f docker-compose.examples.yml down

# View example resource server logs
docker logs -f hr-mcp-server
docker logs -f deploy-mcp-server
```

---

## Observability Overlay

The observability stack (Grafana + Loki + Promtail) is defined in
`deploy/observability/docker-compose.observability.yml` and overlays onto
the base `docker-compose.yml`. Run from the repository root:

```bash
# Start base stack + observability overlay
docker compose -f docker-compose.yml \
  -f deploy/observability/docker-compose.observability.yml up -d

# Stop everything (base + observability)
docker compose -f docker-compose.yml \
  -f deploy/observability/docker-compose.observability.yml down

# Stop observability containers only
docker stop okta-mcp-grafana okta-mcp-promtail okta-mcp-loki

# View Grafana logs
docker logs -f okta-mcp-grafana

# Grafana UI: http://localhost:3000 (admin / admin)
```

---

## All Overlays Combined

```bash
# Start everything: base + examples + observability
docker compose -f docker-compose.yml \
  -f docker-compose.examples.yml \
  -f deploy/observability/docker-compose.observability.yml up -d

# Stop everything
docker compose -f docker-compose.yml \
  -f docker-compose.examples.yml \
  -f deploy/observability/docker-compose.observability.yml down
```

---

## PostgreSQL Commands

```bash
# Open interactive psql shell
docker exec -it okta-mcp-postgres psql -U gateway_user -d gateway_db

# Run a single SQL query
docker exec okta-mcp-postgres psql -U gateway_user -d gateway_db -c "SELECT 1;"

# Check database connectivity
docker exec okta-mcp-postgres pg_isready -U gateway_user -d gateway_db
```

### Useful SQL Queries

```bash
# List all agents
docker exec okta-mcp-postgres psql -U gateway_user -d gateway_db -c \
  "SELECT id, agent_id, enabled, created_at FROM agents;"

# List all backends
docker exec okta-mcp-postgres psql -U gateway_user -d gateway_db -c \
  "SELECT id, name, url, auth_method, enabled, created_at FROM backends;"

# Show agent-to-resource access mappings
docker exec okta-mcp-postgres psql -U gateway_user -d gateway_db -c \
  "SELECT a.agent_id, b.name AS backend
   FROM agent_backend_access aba
   JOIN agents a ON a.id = aba.agent_id
   JOIN backends b ON b.id = aba.backend_id;"

# View recent audit log entries
docker exec okta-mcp-postgres psql -U gateway_user -d gateway_db -c \
  "SELECT id, event_type, entity_type, entity_id, created_at
   FROM audit_log ORDER BY created_at DESC LIMIT 20;"

# Check table sizes
docker exec okta-mcp-postgres psql -U gateway_user -d gateway_db -c \
  "SELECT relname AS table, n_live_tup AS row_count
   FROM pg_stat_user_tables ORDER BY n_live_tup DESC;"

# List all tables
docker exec okta-mcp-postgres psql -U gateway_user -d gateway_db -c "\dt"

# Describe a table
docker exec okta-mcp-postgres psql -U gateway_user -d gateway_db -c "\d agents"

# Database size
docker exec okta-mcp-postgres psql -U gateway_user -d gateway_db -c \
  "SELECT pg_size_pretty(pg_database_size('gateway_db'));"

# Active connections
docker exec okta-mcp-postgres psql -U gateway_user -d gateway_db -c \
  "SELECT count(*) AS connections FROM pg_stat_activity WHERE datname = 'gateway_db';"

# Dump database (backup)
docker exec okta-mcp-postgres pg_dump -U gateway_user gateway_db > backup.sql

# Restore database
docker exec -i okta-mcp-postgres psql -U gateway_user gateway_db < backup.sql
```

---

## Redis Commands

```bash
# Open interactive redis-cli (password from .env)
docker exec -it okta-mcp-redis redis-cli -a <REDIS_PASSWORD>

# Ping
docker exec okta-mcp-redis redis-cli -a <REDIS_PASSWORD> ping

# List all keys
docker exec okta-mcp-redis redis-cli -a <REDIS_PASSWORD> KEYS "okta-mcp:*"

# Check memory usage
docker exec okta-mcp-redis redis-cli -a <REDIS_PASSWORD> INFO memory

# Flush all cached data
docker exec okta-mcp-redis redis-cli -a <REDIS_PASSWORD> FLUSHALL
```

---

## Health Checks and Smoke Tests

```bash
# Gateway health (OAuth protected resource metadata)
curl -s http://localhost:8000/.well-known/oauth-protected-resource | python3 -m json.tool

# Gateway authorization server metadata
curl -s http://localhost:8000/.well-known/oauth-authorization-server | python3 -m json.tool

# Admin API — requires an Okta OAuth access token (v0.15.x+).
# See docs/OPERATIONS.md § "Admin API Authentication" for how to get one.
export OKTA_ADMIN_TOKEN="<paste token from Admin UI>"

# List agents
curl -s http://localhost:8000/api/admin/agents \
  -H "Authorization: Bearer $OKTA_ADMIN_TOKEN" | python3 -m json.tool

# List resources
curl -s http://localhost:8000/api/admin/resources \
  -H "Authorization: Bearer $OKTA_ADMIN_TOKEN" | python3 -m json.tool
```

---

## Cleanup and Troubleshooting

```bash
# Remove all project containers, networks, and volumes
docker compose down -v --remove-orphans

# Remove project images
docker rmi okta-agent-mcp-adapter:latest okta-agent-proxy-admin-ui:latest

# Prune unused Docker resources (system-wide — use with caution)
docker system prune -a --volumes

# Shell into a running container for debugging
docker exec -it okta-agent-mcp-adapter /bin/sh
docker exec -it okta-mcp-postgres /bin/bash
docker exec -it okta-mcp-redis /bin/sh

# Check container environment variables
docker exec okta-agent-mcp-adapter env | sort

# Check container networking
docker network inspect okta-agent-mcp-adapter_mcp-network

# View container port mappings
docker port okta-agent-mcp-adapter
```

---

## Container Name Reference

### Base Stack (`docker-compose.yml`)

| Compose Service           | Container Name           | Port |
|---------------------------|--------------------------|------|
| `okta-agent-mcp-adapter` | `okta-agent-mcp-adapter` | 8000 |
| `postgres`                | `okta-mcp-postgres`      | 5432 |
| `redis`                   | `okta-mcp-redis`         | 6379 |
| `admin-ui`                | `okta-mcp-admin-ui`      | 3001 |

### Examples Overlay (`docker-compose.examples.yml`)

| Compose Service      | Container Name      | Port |
|----------------------|----------------------|------|
| `hr-mcp-server`     | `hr-mcp-server`      | 8001 |
| `deploy-mcp-server` | `deploy-mcp-server`  | 8005 |

### Observability Overlay (`deploy/observability/docker-compose.observability.yml`)

| Compose Service | Container Name      | Port |
|-----------------|---------------------|------|
| `grafana`       | `okta-mcp-grafana`  | 3000 |
| `loki`          | `okta-mcp-loki`     | 3100 |
| `promtail`      | `okta-mcp-promtail` | --   |
