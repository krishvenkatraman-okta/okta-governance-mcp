# Okta MCP Adapter — Azure Container Apps Deployment Guide

> **Audience:** Okta SEs, architects, and technical leads running the Okta MCP Adapter demo on Azure Container Apps (ACA) with a VS Code MCP client as the testing agent.
>
> **Assumption:** You're comfortable in the Okta Admin Console. This guide tells you *what to configure*, *what values the adapter expects*, and *in what order* — not how to click through Okta's UI.
>
> **Outcome:** A working adapter at `https://<adapter-fqdn>`, an Admin UI at `https://<admin-ui-fqdn>`, and a VS Code agent that can call the `deploy-mcp-server` backend via ID-JAG / Cross-App Access.

---

## Table of contents

1. [Architecture at a glance](#1-architecture-at-a-glance)
2. [Prerequisites](#2-prerequisites)
3. [The chicken-and-egg FQDN problem](#3-the-chicken-and-egg-fqdn-problem)
4. [Okta setup — overview](#4-okta-setup--overview)
5. [Okta Step 1 — Custom Authorization Server for the Deploy Server (`OK1Az2`)](#5-okta-step-1--custom-authorization-server-for-the-deploy-server-ok1az2)
6. [Okta Step 2 — Admin UI OIDC Web App](#6-okta-step-2--admin-ui-oidc-web-app)
7. [Okta Step 3 — Confidential Relay OIDC Web App (CIMD)](#7-okta-step-3--confidential-relay-oidc-web-app-cimd)
8. [Okta Step 4 — Create the AI Agent principal and link the Relay app](#8-okta-step-4--create-the-ai-agent-principal-and-link-the-relay-app)
9. [Populate `.env` and run Phase 1 + Phase 2](#9-populate-env-and-run-phase-1--phase-2)
10. [Post-deploy — update Okta redirect URIs with real FQDNs](#10-post-deploy--update-okta-redirect-uris-with-real-fqdns)
11. [Admin UI configuration — Resource, Agent, Connection](#11-admin-ui-configuration--resource-agent-connection)
12. [VS Code testing agent — connect and smoke test](#12-vs-code-testing-agent--connect-and-smoke-test)
13. [Troubleshooting quick reference](#13-troubleshooting-quick-reference)

---

## 1. Architecture at a glance

The `acasetup.sh` wizard provisions four Container Apps inside one ACA Environment behind `*.<region>.azurecontainerapps.io`:

| Container App | Ingress | Role |
|---|---|---|
| **adapter** | External, port 8000 | OAuth 2.1 gateway + MCP proxy |
| **admin-ui** | External, port 3001 | Next.js Admin UI, NextAuth → Okta OIDC |
| **hr-backend** | Internal only, 8001 | PSK-auth example backend |
| **deploy-server** | Internal only, 8005 | XAA (ID-JAG) example backend — this guide's target |

The request pattern you're demoing:

```
VS Code (MCP client)
   │  1. OAuth to adapter via CIMD (client_id = URL to metadata JSON)
   ▼
Adapter (Org AS user session, captured id_token in token store)
   │  2. Tool call: POST / with Bearer AT-1
   │  3. id_token  ──►  ID-JAG JWT  ──►  OK1Az2 /token  ──►  AT-2
   ▼
deploy-mcp-server
   │  4. Validates AT-2 via okta-jwt-verifier (issuer + audience check)
   ▼
Tool result
```

Two Okta authorization servers are in play:

- **Org Authorization Server** — Okta's built-in org AS. Handles *both* Admin UI sign-in (issuing tokens with `okta.*` management scopes) *and* the linked applications referenced in Agent configurations. The user's **id_token** captured through the Confidential Relay app is issued by this AS and becomes the subject of the ID-JAG exchange.
- **Custom Authorization Server (`OK1Az2`)** — a **new dedicated Custom AS** you will create *only* for the deploy-server. Issues `mcp:read` / `mcp:write` access tokens (AT-2) that the deploy-server validates.

---

## 2. Prerequisites

**On your workstation:**

The wizard needs a POSIX shell (it uses `set -euo pipefail`, `[[ ]]`, and arrays) plus four CLI tools:

| Tool | Why |
|---|---|
| `az` (Azure CLI) | All Azure provisioning + `az acr build` for container images |
| `jq` | JSON parsing of `az` output |
| `python3` | Small helpers the shell scripts shell out to |
| `openssl` | Generating random secrets and the encryption key |

> **Docker Desktop is NOT required.** The wizard builds container images server-side via `az acr build` — your workstation never needs a local Docker daemon. This is a big deal for Windows users without WSL2 or corporate laptops with Docker Desktop restrictions.

### Running on macOS / Linux

Native shell works. Install the four tools via Homebrew / apt / dnf and you're done.

### Running on Windows

The scripts will **not** run in `cmd.exe` or native PowerShell. You have two good options:

**Option A — WSL2 (recommended, closest to the macOS/Linux path)**

1. Install WSL2 with Ubuntu: `wsl --install -d Ubuntu` from an elevated PowerShell, then reboot.
2. Open the Ubuntu shell and install the four tools:
   ```bash
   sudo apt update
   sudo apt install -y jq python3 openssl
   curl -sL https://aka.ms/InstallAzureCLIDeb | sudo bash
   ```
3. Copy the deployment tarball into the WSL filesystem (e.g., `~/okta-adapter-aca/`), not under `/mnt/c/...`. Line endings and file permissions behave correctly only on the WSL-native filesystem, and scripts run measurably faster there. Extract with `tar xzf okta-ps-adapter-azure-aca-<version>.tar.gz`.
4. `az login` — the Azure CLI will pop a browser on the Windows host; sign in normally.
5. `cd okta-ps-adapter-azure-aca-<version>/deploy/azure-aca && ./acasetup.sh` — behaves identically to macOS/Linux.

**Option B — Git Bash (MINGW64, ships with Git for Windows)**

Works for a demo in a pinch but has caveats:

1. Install [Git for Windows](https://git-scm.com/download/win) — it includes Git Bash with `bash`, `openssl`, `curl`, `sed`, `awk`, `grep`, and `tr`.
2. Install Azure CLI for Windows: `winget install -e --id Microsoft.AzureCLI` (or the MSI from Microsoft Learn).
3. Install `jq` for Windows: `winget install -e --id jqlang.jq` — make sure it lands on `PATH`.
4. Install Python 3: `winget install -e --id Python.Python.3.12`. Git Bash calls it as `python3`; verify with `python3 --version`. If only `python` resolves, add an alias in `~/.bashrc`: `alias python3=python`.
5. In Git Bash, extract the tarball: `tar xzf okta-ps-adapter-azure-aca-<version>.tar.gz`
6. `az login`, then `cd okta-ps-adapter-azure-aca-<version>/deploy/azure-aca && ./acasetup.sh`

**Git Bash caveats to watch for:**

- **Path translation.** Git Bash silently rewrites `/foo/bar`-looking arguments to `C:\foo\bar`. If you hit a weird error, prefix single-slash args with an extra `/` (e.g., `//subscriptions/...`) or set `MSYS_NO_PATHCONV=1` for one command.
- **Line endings.** If the tarball was extracted on a system that mangled line endings (rare, but possible through some archive tools), the shell scripts may have CRLF line endings and fail with `bad interpreter: No such file or directory`. Fix with:
  ```bash
  cd deploy/azure-aca
  dos2unix acasetup.sh shell-lib/*.sh   # or: sed -i 's/\r$//' acasetup.sh shell-lib/*.sh
  ```
  Extracting directly with `tar xzf` inside Git Bash or WSL avoids this entirely.
- **Interactive prompts.** The wizard's `read -p` prompts work in Git Bash but occasionally don't show the prompt until after you type. Non-interactive mode (`--non-interactive`, with all required env vars set in `.env`) sidesteps this.

**Option C — Not recommended: Azure Cloud Shell**

Cloud Shell has `bash`, `az`, `jq`, `python3`, and `openssl` preinstalled, and you're already authenticated. But it has two dealbreakers for this wizard: the 20-minute idle timeout kills Phase 1 mid-Redis-provisioning, and you'd still need to upload the tarball into the Cloud Shell filesystem. Use a local WSL2 or Git Bash shell instead.

### In Okta

- Admin access to create: Custom Authorization Servers, OIDC Web Apps, and Okta API Scope grants
- Your user must hold a role permitting AI Agent and App management — **Super Administrator** is the simplest; a custom admin role works if it covers Apps, Groups, Authorization Servers, and AI Agents

### Deployment tarball layout

You'll be working from a self-contained deployment tarball named `okta-ps-adapter-azure-aca-<version>.tar.gz`. It's produced from the full source repo by a maintainer and contains only what's needed to run the ACA wizard and build container images server-side. Tests, docs, sibling deployment targets, and dev-only scaffolding are stripped out.

Extract it wherever you plan to run the wizard from:

```bash
tar xzf okta-ps-adapter-azure-aca-<version>.tar.gz
cd okta-ps-adapter-azure-aca-<version>
```

You'll see:

```
okta-ps-adapter-azure-aca-<version>/
├── Dockerfile                        # adapter image (built server-side by az acr build)
├── .dockerignore
├── requirements.txt
├── pyproject.toml
├── alembic.ini
├── alembic/                          # Postgres migrations run on adapter startup
├── scripts/
├── okta_agent_proxy/                 # adapter source (FastAPI gateway, auth, routing)
├── okta_agent_proxy_admin_ui/        # Next.js Admin UI source
├── examples/
│   ├── 01-hr-system/                 # PSK-auth example backend
│   └── 05-deploy-server/             # XAA (ID-JAG) example backend — this guide's target
└── deploy/
    └── azure-aca/                    # ← you run everything from here
        ├── acasetup.sh               # two-phase wizard
        ├── .env.example
        ├── README.md
        ├── shell-lib/
        │   ├── common.sh
        │   └── azure-helpers.sh
        └── bicep/
            └── main.bicep            # 4 Container Apps + outputs
```

Total unpacked size: ~15–20 MB. Every file in the tree is something either `acasetup.sh` reads or `az acr build` needs as image build context. You'll `cd deploy/azure-aca` and run `./acasetup.sh` from there for the entire deployment.

---

## 3. The chicken-and-egg FQDN problem

ACA assigns each Container App a default FQDN of the form:

```
<app-name>.<random-suffix>.<region>.azurecontainerapps.io
```

The suffix isn't knowable until Phase 1 creates the ACA Environment. Every Okta redirect URI needs the real FQDN.

**Recommended pattern (used throughout this guide):**

1. In Okta, register each app **with a placeholder redirect URI** (e.g., `https://placeholder.local/api/auth/callback/okta`). You cannot save an OIDC Web App in Okta with zero redirect URIs.
2. Run `acasetup.sh` Phase 1 + Phase 2.
3. Phase 2 prints the real FQDNs. **Update each Okta app** with the real redirect URIs (Section 10).
4. Sign in to the Admin UI.

If your org allows it, you can instead add redirect URIs in a second pass — same endpoint. Wildcard redirect URIs are **not** supported by Okta for web apps; don't try to use them.

---

## 4. Okta setup — overview

You will create **four things in Okta before running the wizard**, in this order:

| # | What | Used by | Redirect URI (placeholder first, real after Phase 2) |
|---|---|---|---|
| 1 | **Custom Authorization Server `OK1Az2`** with scopes `mcp:read`, `mcp:write` | Deploy server token validation | N/A |
| 2 | **Admin UI OIDC Web App** + Okta API scopes on its "Okta API Scopes" tab | Admin sign-in to Admin UI | `https://<admin-ui-fqdn>/api/auth/callback/okta` |
| 3 | **Confidential Relay OIDC Web App** | CIMD VS Code flow | `https://<adapter-fqdn>/oauth/relay/callback` |
| 4 | **Okta AI Agent principal** (Directory → AI Agents) with the Relay app linked | Admin UI Agent Sync auto-populates Client ID, secret, and `okta_ai_agent_id` from the linked app | N/A |

---

## 5. Okta Step 1 — Custom Authorization Server for the Deploy Server (`OK1Az2`)

This is the dedicated AS whose tokens the deploy-server container validates.

**Create the AS:**

- Admin Console → **Security → API → Authorization Servers → Add Authorization Server**
- **Name:** `okta-mcp-deploy-server`
- **Audience:** `api://deploy-server` *(this value MUST match `DEPLOY_OKTA_AUDIENCE` in your `.env`; the adapter defaults to this same string)*
- **Description:** "XAA target AS for the Okta MCP Adapter deploy-server backend"
- Save. Note the **Authorization Server ID** — it looks like `ausXXXXXXXXXXXXXXX`. You'll put this in `.env` as `DEPLOY_OKTA_AUTH_SERVER_ID`.

**Add scopes** (Scopes tab → Add Scope):

| Name | Display name | Description | Default | Metadata publish |
|---|---|---|---|---|
| `mcp:read` | Read MCP resources | Read access to MCP tool results | unchecked | Public |
| `mcp:write` | Write MCP resources | Mutating MCP tool calls (rollbacks, deploys) | unchecked | Public |

**Add an access policy** (Access Policies tab → Add Policy):

- **Name:** `default-xaa-policy`
- **Assign to:** **All clients**. The OK1Az2 policy is intentionally permissive at the Okta layer — governance for which agents can reach this resource is enforced two layers up: (a) by the **AI Agent principal's status** (STAGED/ACTIVE/DEACTIVATED) in Okta Directory, which gates whether the adapter treats the agent as enabled, and (b) by the agent's **Managed Connections** and the adapter's `backend_access` ACL, which controls which Resources each agent can route to. You do not attach individual apps here.
- Add a rule:
  - **Name:** `id-jag-exchange`
  - **Grant type:** Expand **advanced** check **Token Exchange** and **JWT Bearer**.
  - **User:** any user assigned via the linked app
  - **Scopes:** `mcp:read`, `mcp:write`

> **Verify later:** When Phase 2 finishes, you can hit `https://<your-okta-domain>/oauth2/<OK1Az2-id>/.well-known/openid-configuration` and confirm `mcp:read mcp:write` appear in `scopes_supported`.

---

## 6. Okta Step 2 — Admin UI OIDC Web App

The Admin UI uses NextAuth → Okta OIDC for sign-in **and** forwards the admin's token to Okta Management APIs for agent import, secret fetching, and managed connection sync. Because of that second role, it needs **two sets of scopes**:

- Standard OIDC scopes on the OIDC app (requested by NextAuth at login)
- Okta Management API scopes granted on the **Okta API Scopes** tab

**Create the app:**

- Applications → **Create App Integration → OIDC → Web Application**
- **App name:** `Okta MCP Adapter — Admin UI`
- **Grant types:** ✅ Authorization Code, ✅ Refresh Token
- **Sign-in redirect URIs:** `https://placeholder.local/api/auth/callback/okta` *(update after Phase 2)*
- **Sign-out redirect URIs:** `https://placeholder.local/login`
- **Controlled access:** Assign to the users/groups who should administer the adapter
- Save. Copy the **Client ID** → `.env` as `ADMIN_UI_OKTA_CLIENT_ID`. Copy the **Client secret** → `.env` as `ADMIN_UI_OKTA_CLIENT_SECRET`.

**OIDC scopes requested at login (configured in the adapter code, nothing to do in Okta here — listed for reference):**

```
openid email profile
okta.aiAgents.read okta.aiAgents.manage
okta.apps.read
okta.groups.read
okta.authorizationServers.read
```

**Grant the Okta Management API scopes** on the **Okta API Scopes** tab:

| Scope | Purpose |
|---|---|
| `okta.aiAgents.read` | List and read AI Agent details |
| `okta.aiAgents.manage` | Import and sync operations; register agent JWKs |
| `okta.apps.read` | Read linked OIDC app metadata |
| `okta.apps.manage` | Fetch/generate client secrets for agents from the Admin UI |
| `okta.groups.read` | Read group info |
| `okta.authorizationServers.read` | Match Managed Connections to adapter resources by auth server ID |

Each row must show **Granted** (green check) before you move on. **`okta.apps.manage`** is the one most easily missed — without it the Admin UI's "Fetch Secret from Okta" button will 403.

---

## 7. Okta Step 3 — Confidential Relay OIDC Web App (CIMD)

VS Code identifies itself via a **URL-based client_id** (CIMD). The adapter fetches the metadata JSON, validates it against the trust policy, and then starts a **real OAuth flow against Okta using a pre-registered "relay" OIDC app** that the adapter owns. That relay app is this step.

**Create the app:**

- Applications → **Create App Integration → OIDC → Web Application**
- **App name:** `Okta MCP Adapter - VS Code App Relay`
- **Grant types:** ✅ Authorization Code, ✅ Refresh Token
- **Sign-in redirect URIs:** `https://placeholder.local/oauth/relay/callback` *(update after Phase 2 to `https://<adapter-fqdn>/oauth/relay/callback`)*
- **Sign-out redirect URIs:** leave blank
- **Controlled access:** assign to the set of users who are allowed to use VS Code against the resources exposed by this agent. This is typically a dedicated group (e.g., `mcp-vscode-users`) and should **not** be the same group as the Admin UI app from Step 2 — Admin UI access is for operators who configure the adapter, while this group is for end users whose identities will flow through the ID-JAG exchange to reach `deploy-mcp-server`. Membership here is effectively "who can exercise the Managed Connections scoped to this AI Agent."
- Save. The **Client ID** does not need to be copied anywhere manually. The Admin UI will discover it automatically when you sync the AI Agent from Okta in Section 11, via the Linked Application relationship you'll set up in Step 4. The **Client secret** is also never manually copied — the Admin UI fetches it from Okta as part of the same sync.

**No `.env` entry is needed for the Relay app's Client ID.** As of the okta-jwt-verifier SDK migration, the deploy-server validates inbound AT-2 tokens using only the issuer URL and the expected audience — no client_id is required on the resource-server side. The Relay app's Client ID is still discovered automatically by the Admin UI's Import-from-Okta flow (Section 11) via the AI Agent's Linked Application relationship from Step 4. If you have an older `.env` with `DEPLOY_OKTA_CLIENT_ID` set, the deploy-server will log a one-time deprecation warning at startup and ignore it.

---

## 8. Okta Step 4 — Create the AI Agent principal and link the Relay app

This step creates a first-class **AI Agent principal** in Okta's Universal Directory and binds the Relay app from Step 3 to it as a Linked Application. Doing this now means that after the wizard finishes, the Admin UI can **import the agent** from Okta in a single click — pulling the `client_id`, fetching the `client_secret`, and populating `okta_ai_agent_id`, `enabled` status, and Managed Connection resource access automatically. No manual copy-paste from the Okta console.

**Create the AI Agent:**

- Okta Admin Console → **Directory → AI Agents → Add AI Agent**
- **Name:** `VS Code MCP Testing Agent`
- **Description:** `Local VS Code MCP client used for the Okta MCP Adapter XAA demo`
- Save. The agent is created in **STAGED** state. Note the **AI Agent ID** (looks like `agt0oa1abc2def3ghi`) — you don't need to paste it anywhere; the Admin UI will discover it automatically during sync.

**Link the Relay app:**

- Open the newly created AI Agent → **Linked Applications → Add**
- Select the **`Okta MCP Adapter - VS Code App Relay`** OIDC app from Step 3
- Save. This is the binding that lets the Admin UI's `get_agent_connections()` + `get_linked_app()` calls resolve the Relay app's Client ID automatically — it reads from `linked_app_data.credentials.oauthClient.client_id` and stores it against the adapter's agent record.

**Activate the agent:**

- On the AI Agent detail page, change the status from **Staged → Active**. The adapter's Agent Sync will not import STAGED agents by design (governance gate).

> **Why activation is a manual step:** automatic activation would let any newly registered agent immediately consume production resources. Requiring an admin to flip the switch gives you an approval gate you can wire into Okta Access Requests or a change-control workflow. The adapter does not override this.

**Add a Managed Connection to OK1Az2:**

Managed Connections are how the AI Agent principal declares which resources it's allowed to reach and with what scopes. Okta recommends authorization servers as the resource type for AI agents because they use Cross App Access — this is the mechanism that makes the ID-JAG exchange governed rather than permissive. See Okta's own guidance: [Connect an AI agent to an authorization server](https://help.okta.com/oie/en-us/content/topics/ai-agents/ai-agent-auth-server.htm).

- On the AI Agent detail page → **Managed connections** tab → **Add connection**
- **Resource type:** Authorization server
- **Authorization server:** select **`okta-mcp-deploy-server`** (the OK1Az2 you created in Step 1)
- **Select AI agent scopes:** choose **Only allow** and enter `mcp:read`, `mcp:write` *(or choose `Allow all` if you want every scope the AS exposes — `Only allow` is the stricter, auditable choice)*
- **Add**

Once saved, the authorization server appears as a connected resource on the agent's Managed connections tab. The adapter's Admin UI will read this connection during Import and automatically set the agent's `backend_access` to include `deploy-mcp-server` — matched by the connection's authorization server ID.

> **Scope enforcement:** Managed Connection scopes gate what the adapter is *allowed to request* during the ID-JAG exchange, on top of whatever OK1Az2's policy rule permits. If you `Only allow` `mcp:read` here but the adapter tries to request `mcp:write`, the exchange fails — exactly the kind of fine-grained control Cross App Access is designed to enforce.

---

## 9. Populate `.env` and run Phase 1 + Phase 2

**From the extracted tarball directory:**

```bash
cd okta-ps-adapter-azure-aca-<version>/deploy/azure-aca
cp .env.example .env
```

**Fill in `.env`:**

```bash
# --- Azure ---
AZURE_SUBSCRIPTION_ID=00000000-0000-0000-0000-000000000000
AZURE_LOCATION=eastus2
AZURE_RG=okta-ps-adapter-demo

# --- Okta (Phase 2) ---
OKTA_DOMAIN=yourorg.okta.com        # or .oktapreview.com

# --- Admin UI OIDC (Step 2) ---
ADMIN_UI_OKTA_CLIENT_ID=0oaXXXXXXXXXXXXXXX
ADMIN_UI_OKTA_CLIENT_SECRET=<secret from Admin UI app>

# --- Deploy server XAA verification (Steps 5 + 7) ---
DEPLOY_OKTA_AUTH_SERVER_ID=ausZZZZZZZZZZZZZZZ     # OK1Az2 id from Step 1
DEPLOY_OKTA_AUDIENCE=api://deploy-server          # must match OK1Az2 audience from Step 1
```

> The Confidential Relay Client ID is no longer needed in `.env`. It is discovered automatically by the Admin UI's Import-from-Okta flow (Section 11) via the AI Agent's Linked Application relationship from Step 4, and stored per-agent in Postgres. The Client secret is also fetched automatically by the Admin UI during Import.

**Run the wizard:**

```bash
./acasetup.sh           # runs Phase 1 (~25 min) then Phase 2 (~5 min)
```

Or run phases independently if you need to resume:

```bash
./acasetup.sh --phase 1
./acasetup.sh --phase 2
```

**What Phase 1 creates:** Resource Group, ACR, VNet, Postgres Flexible Server (B1ms), Redis Basic C0, Log Analytics workspace, ACA Environment. Redis provisioning is the long pole (~15 min).

**What Phase 2 creates:** container images pushed to ACR, the 4 Container Apps from Bicep, a smoke test, and two helper scripts: `demo-stop.sh` and `demo-start.sh`.

**Phase 2 output you need to capture:**

```
✓ adapter FQDN:       adapter.<suffix>.<region>.azurecontainerapps.io
✓ admin-ui FQDN:      admin-ui.<suffix>.<region>.azurecontainerapps.io
✓ hr-backend FQDN:    hr-backend.<suffix>.<region>.azurecontainerapps.io   (internal)
✓ deploy-server FQDN: deploy-server.<suffix>.<region>.azurecontainerapps.io (internal)
```

---

## 10. Post-deploy — update Okta redirect URIs with real FQDNs

Now that you have the real FQDNs, go back to each Okta app and replace the placeholders:

**Admin UI app (Step 2):**

- Sign-in redirect URI → `https://<admin-ui-fqdn>/api/auth/callback/okta`
- Sign-out redirect URI → `https://<admin-ui-fqdn>/login`

**Confidential Relay app (Step 3):**

- Sign-in redirect URI → `https://<adapter-fqdn>/oauth/relay/callback`

Verify the Admin UI login works before moving on:

```bash
open "https://<admin-ui-fqdn>"
# Click "Sign in with Okta" → authenticate → land on the dashboard
```

If you get a `redirect_uri_mismatch`, the URI in Okta doesn't match byte-for-byte. No trailing slash, correct `/api/auth/callback/okta` path.

If you get `403 insufficient_scopes` on any dashboard page, re-check Section 6's Okta API Scopes tab. After granting, **sign out and back in** — the scope set is baked into the token at login.

---

## 11. Admin UI configuration — Resource, Agent, Connection

You'll do three things in the Admin UI, in order:

### A. Register the `deploy-mcp-server` Resource

Dashboard → **Resources → Add Resource**. The dialog has six fields:

| Field | Value |
|---|---|
| **Name** * | `deploy-mcp-server` *(lowercase slug: a–z, 0–9, hyphens)* |
| **Type** | `MCP` *(currently the only supported type; A2A is planned for a future release and not yet implemented)* |
| **URL** * | `https://deploy-server.<suffix>.<region>.azurecontainerapps.io/mcp` *(internal FQDN — the adapter reaches it over the ACA vnet)* |
| **Connection Resource ID** | *(leave blank)* |
| **Description** | `DevOps deploy server — XAA demo target` |
| **Tags** | `deploy, xaa, demo` *(comma-separated, optional)* |

Click **Create**.

> **About the Connection Resource ID field:** Leave it empty. This field exists as a manual override path for linking to an Okta authorization server, but in the AI-Agents-driven flow the connection is populated automatically when the Managed Connection you created in Step 4 is imported in Section 11B. The field will be removed in a future release now that Managed Connections is the canonical linkage mechanism.

Once created, the Resource appears in the dashboard with an "unconnected" status until the Managed Connection imported in Section 11B matches it by authorization server ID. At that point the adapter will know: "when a request is routed to `deploy-mcp-server`, do an ID-JAG exchange against OK1Az2, request the scopes granted by the Managed Connection, and forward the AT-2 as Bearer to the URL above."

### B. Import the VS Code Agent from Okta

Navigate to **Okta Import** in the sidebar (or click **Import from Okta** on the Agents page).

The **Import Agents from Okta** dialog appears, showing all AI Agent principals in your Okta tenant as a table with columns: **Status** (ACTIVE/STAGED), **Name**, **Okta Agent ID**, **Linked App**, **Conns** (Managed Connection count), and **Action** (Import or Imported ✓).

1. Find your **VS Code** agent in the list — it should show `ACTIVE` status, the Okta Agent ID you created in Step 4, the Linked App client_id from Step 3, and the connection count matching the Managed Connections you added
2. Click **Import**
3. The Admin UI automatically:
   - Pulls the Linked Application's `client_id` from Okta
   - Fetches the linked app's `client_secret` via Okta's credentials API (using `okta.apps.manage`)
   - Populates `okta_ai_agent_id`, `Principal ID`, `enabled` status, and `registration_source=okta-import`
   - Imports all Managed Connections and matches them against registered Resources by authorization server ID
   - Encrypts the secret at rest with the adapter's `ENCRYPTION_KEY` before storing in Postgres

The agent now appears on the **Agents** page as a card showing: agent name, Principal ID, Client ID, CIMD Client ID, and **● Enabled** status.

**At this point you have typed zero credentials.** The operator never sees the `client_secret` at any point in this workflow.

> **If Import from Okta returns "Insufficient Okta Scopes"** — your Admin UI OIDC app is missing one or more of the required scopes (`okta.aiAgents.read`, `okta.apps.read`, `okta.apps.manage`, `okta.groups.read`, `okta.authorizationServers.read`). Go back to Section 6, grant them on the Okta API Scopes tab, sign out of the Admin UI, and sign back in to pick up the new scopes in your session token.

> **If the imported agent shows `enabled=false`** — the AI Agent principal in Okta is still in STAGED status. Go back to Step 4, flip it to Active, then click **Sync from Okta** on the agent detail page.

### C. Configure the imported Agent

Click the imported agent to open the detail page. It has four tabs: **Connections & Resources**, **Configuration**, **Tools**, and **Audit Log**.

**Connections & Resources tab** — link the Resource to the Managed Connection:

The summary cards at the top show **Total Connections**, **Linked** (green), **Needs Resource** (orange), and **Total Resources**. Immediately after import, all connections will show as "Needs Resource" because no adapter Resources have been linked yet.

Find the OK1Az2 Managed Connection card — it's labeled **OKTA MANAGED CONNECTION** with an orange **"— NEEDS RESOURCE"** indicator. The card shows the authorization server ID, badges `XAA` and `INCLUDE_ONLY`, and the granted scopes `mcp:read` `mcp:write`. Below it you'll see **"NO RESOURCES LINKED"** with a dashed-border prompt and two buttons:

- **+ Add resource** — creates a new Resource inline (use this if you haven't done Section 11A yet)
- **Link existing resource** — links a Resource you already registered

Click **Link existing resource**. A dialog appears titled "Link existing resource to 'Demo Ops Server MCP Adapter'" showing all unlinked Resources. Select **`deploy-server`** (it shows the `MCP` badge and the internal ACA URL) and click **Link Resource**.

After linking, the summary cards update: **Linked** goes from 0 to **1** (green), **Needs Resource** decreases by one, and **Total Resources** shows **1**. The connection card now shows **LINKED RESOURCE (1)** with `deploy-server`, its URL, the `MCP` badge, and **Edit** / **Unlink** buttons.

At this point the adapter knows: "when a tool call is routed to `deploy-server`, use this Managed Connection's XAA credentials and scopes (`mcp:read`, `mcp:write`) to perform the ID-JAG exchange against OK1Az2, and forward the AT-2 as Bearer to the Resource URL."

> **The remaining "Needs Resource" connections** (e.g., Secret-type connections for other backends like HR) are expected and harmless for this demo. Only the XAA connection to OK1Az2 needs a linked Resource for the deploy-server demo to work.

**Configuration tab** — verify identity and credentials:

The **Okta Identity (read-only)** card displays:

| Field | Expected value |
|---|---|
| Agent Name | `vscode` (or whatever name was set in Okta) |
| Client ID | The Relay app's Client ID from Step 3 (populated by Import) |
| Okta Agent ID | `wlpw...` (populated by Import) |
| Principal ID | Same as Okta Agent ID |

The **Credential Status** card shows two indicators:

| Credential | Expected status |
|---|---|
| Client Secret | ✅ Configured |
| Signing Key | ✅ Configured |

If either shows as not configured:
- **Client Secret** — click **"Fetch Secret from Okta"** to retrieve it using your session's `okta.apps.manage` scope
- **Signing Key** — click **"Generate & Register New Key"** to create an RSA key pair locally and register the public key with the Okta AI Agent principal (uses the `okta.aiAgents.manage` scope). The private key is stored AES-256-GCM encrypted in Postgres; the public key is uploaded to Okta for ID-JAG JWT signature verification.

> **Both credentials are required** for the XAA flow to work end-to-end. The adapter signs the ID-JAG JWT with the private key; Okta's token endpoint verifies it against the registered public key; the client_secret authenticates the token exchange request.

The **Settings** card shows **Client Mode** — select **CIMD Client** (URL-based client identity) and enter the CIMD Client ID:

| Field | Value |
|---|---|
| Client Mode | ◉ **CIMD Client** — URL-based client identity |
| CIMD Client ID | `https://vscode.dev/oauth/client-metadata.json` |

Save. This is VS Code's built-in CIMD metadata endpoint — VS Code publishes its own client metadata at this URL, so you don't need to host a separate document.

---

## 12. VS Code testing agent — connect and smoke test

### VS Code's built-in CIMD endpoint

VS Code publishes its own Client ID Metadata Document at a well-known URL:

```
https://vscode.dev/oauth/client-metadata.json
```

You already configured this as the CIMD Client ID on the agent in Section 11C. There's nothing to host or create — VS Code's MCP integration uses this URL automatically when it initiates an OAuth flow against an MCP server.

### Configure VS Code

In VS Code `settings.json`, add the adapter as an MCP server:

```json
{
  "mcp.servers": {
    "okta-adapter": {
      "url": "https://<adapter-fqdn>"
    }
  }
}
```

VS Code discovers the CIMD URL from the adapter's OAuth metadata and uses `https://vscode.dev/oauth/client-metadata.json` as its `client_id` automatically — you don't specify it in the settings.

---

## 13. Troubleshooting quick reference

| Symptom | Likely cause | Where to fix |
|---|---|---|
| Admin UI login redirects to `/login?error=OAuthCallback` | Redirect URI mismatch | Section 10 — update Admin UI app sign-in redirect URI |
| Dashboard shows "Insufficient Okta Scopes" banner | Missing `okta.*` scopes or stale token | Section 6 — grant scopes on Okta API Scopes tab, **sign out and back in** |
| "Fetch Secret from Okta" button returns 403 | Missing `okta.apps.manage` | Section 6 |
| `acasetup.sh` Phase 1 times out on Postgres | Burstable-tier provisioning is slow | Rerun Phase 1 — it resumes from state file |
| VS Code gets `invalid_client` at `/oauth/authorize` | CIMD Client ID on the agent doesn't match `https://vscode.dev/oauth/client-metadata.json`, or `vscode.dev` not in trust allowlist | Section 11C — verify CIMD Client ID is set correctly. Section 12 — switch `CIMD_TRUST_MODE` to `open` temporarily if the domain is blocked. |
| VS Code authorizes but tool calls return 401 | Adapter can't find stored `id_token` or missing credentials on the agent | Section 11C → Configuration tab → Credential Status: both Client Secret and Signing Key must show ✅ Configured. If not, use the Fetch Secret and Generate & Register New Key buttons. Also verify CIMD Client ID matches `https://vscode.dev/oauth/client-metadata.json`. |
| Tool call returns 502 or "ID-JAG exchange failed" | OK1Az2 policy rule wrong, AI Agent not ACTIVE, or Managed Connection scopes missing | Section 5 — verify `default-xaa-policy` has a rule with Token Exchange + JWT Bearer grants and `mcp:read`/`mcp:write` scopes. Section 8 — verify the AI Agent principal is ACTIVE (not STAGED). Section 11C — verify the agent's `backend_access` includes `deploy-mcp-server`. |
| Write-side tool call succeeds for `mcp:read` but fails for `mcp:write` | Managed Connection scoped to `Only allow mcp:read` | Section 8 — on the AI Agent's Managed connections tab, edit the OK1Az2 connection and add `mcp:write` to the allowed scopes |
| Deploy server returns `invalid_token` on AT-2 | OK1Az2 audience mismatch | Section 5 — `api://deploy-server` must match `DEPLOY_OKTA_AUDIENCE` |
| Postgres password gets stuck / wizard fails mid-Phase-1 | See README.md — rotate password and update `.acasetup.state` | `deploy/azure-aca/README.md` § Troubleshooting |
| Need to drop cost between demos | `./demo-stop.sh` (keeps Postgres data, ~$25/mo) or `./acasetup.sh --destroy` (~$0) | — |

---

---

*End of guide.*
