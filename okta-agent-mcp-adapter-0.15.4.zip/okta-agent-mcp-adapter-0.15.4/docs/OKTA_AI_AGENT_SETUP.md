# Okta AI Agent Setup Guide

This guide covers integrating the Okta MCP Adapter with **Okta for AI Agents** (Early Access), which formalizes AI agents as workload principals in Universal Directory.

> **Note:** The Okta AI Agent Registration API (`/api/v1/ai-agents`) is Early Access. The API surface may evolve. The adapter's integration is behind feature flags and resilient to API changes.

## Prerequisites

- Okta for AI Agents EA access (contact your Okta account team)
- Super Admin role in your Okta org
- The Okta MCP Adapter deployed and functional

## Step 1: Register the Adapter as an AI Agent

1. Navigate to **Directory > AI Agents** in the Okta Admin Console
2. Click **Add AI Agent**
3. Fill in:
   - **Name:** `Okta MCP Adapter` (or your preferred name)
   - **Description:** `OAuth 2.1 gateway/proxy for MCP clients`
4. Note the **AI Agent ID** (e.g., `agt0oa1abc2def3ghi`)
5. The agent is created in **STAGED** state

## Step 2: Upload the Gateway Signing Key

The adapter auto-generates an RSA-2048 signing key at startup. To register it with Okta:

1. Fetch the adapter's public JWKS:
   ```bash
   curl http://localhost:8000/oauth/jwks.json | jq '.keys[0]'
   ```

2. In the AI Agent configuration, go to **Credentials**
3. Click **Add Credential** and paste the JWK public key
4. Alternatively, set `ADAPTER_SIGNING_KEY` to a persistent JWK and upload the corresponding public key

## Step 3: Link the Relay OIDC App

1. In the AI Agent configuration, go to **Linked Applications**
2. Add your relay OIDC app (`RELAY_OKTA_CLIENT_ID`)
3. This associates OAuth grants made through the relay with the AI Agent principal

## Step 4: Activate the AI Agent

1. In the AI Agent list, click the agent
2. Change status from **Staged** to **Active**
3. The adapter verifies this on startup — check logs for:
   ```
   Adapter AI Agent agt0oa1abc2def3ghi verified — status=ACTIVE
   ```

> **Governance Note:** Activation is manual by design. Automatic activation would bypass governance controls.

## Step 5: Configure Managed Connections

Managed Connections define which downstream resources the AI Agent can access and with what scopes.

1. In the AI Agent configuration, go to **Connections**
2. For each resource (MCP server), add a connection:

   **Authorization Server connection:**
   - **Type:** Authorization Server
   - **Authorization Server:** Select the target auth server
   - **Scopes:** `read:employee`, `read:org` (per your policy)

   **Secret connection (for PSK resources):**
   - **Type:** Secret
   - **Resource Indicator:** `https://backend.example.com/api`

3. The adapter syncs these connections periodically and updates resource configurations

## Step 6: Set Environment Variables

```bash
# === AI Agent Identity ===
# Master toggle for AI Agent integration
OKTA_AI_AGENT_ENABLED=true

# The adapter's AI Agent ID (from Step 1)
OKTA_AI_AGENT_ID=agt0oa1abc2def3ghi

# Auto-promote DCR/CIMD agents to AI Agent principals
OKTA_AI_AGENT_AUTO_REGISTER=true

# Default owner for auto-registered AI Agents (Okta user ID)
OKTA_AI_AGENT_DEFAULT_OWNER=00u1abc2def3ghi4jkl

# Service app client ID for private_key_jwt auth (uses ADAPTER_SIGNING_KEY)
# Preferred over SSWS for production — see docs/OKTA_SERVICE_APP_SETUP.md
OKTA_SERVICE_CLIENT_ID=0oaXXXXXXXX
```

## Step 7: Enable Managed Connections Sync

```bash
# Enable sync of Managed Connections from Okta AI Agent API
# Triggered by Okta Event Hooks or manual Admin API calls (no polling)
OKTA_MANAGED_CONNECTIONS_ENABLED=true
```

The adapter will:
- Sync connections when triggered by Okta Event Hooks or manual Admin API calls
- Match authorization server connections to resources by auth server ID
- Update `managed_connection_scopes` on matching resources
- Enforce scope intersection during XAA token exchange

## Importing Agents

The adapter can import AI Agent principals from Okta Universal Directory. This creates minimal adapter records — all identity data stays in Okta.

### Prerequisites

- Step 1b OAuth scopes on the Admin UI OIDC app (see `okta_agent_proxy_admin_ui/OKTA_OIDC_SETUP.md`)
- Service app for event-driven sync (`OKTA_SERVICE_CLIENT_ID` — see `docs/OKTA_SERVICE_APP_SETUP.md`)
- Event Hook for real-time sync (see `docs/OKTA_EVENT_HOOK_SETUP.md`)

### What the Adapter Stores (Minimal)

| Field | Source | Description |
|-------|--------|-------------|
| `agent_id` | Derived from agent name | Adapter's internal ID |
| `okta_ai_agent_id` | Okta | The `agtXXXXXX` principal ID |
| `client_id` | Okta linked app | The OIDC app's client_id |
| `backend_access` | Managed Connections | Resource access, auto-matched by `authorizationServerId` |
| `enabled` | Okta agent status | `true` if ACTIVE, `false` if STAGED/DEACTIVATED |
| `registration_source` | Set to `okta-import` | Distinguishes imported vs manual agents |

All other data (name, description, connections, linked apps) is fetched from Okta on demand.

### How Token Forwarding Works

When an admin uses the Admin UI to import or sync agents:

1. Admin authenticates via Okta OIDC (the Admin UI app)
2. The admin's access token includes `okta.aiAgents.read` and related scopes
3. The adapter forwards this token directly to Okta's AI Agent Management APIs
4. No SSWS admin token is needed — the admin's own identity and permissions are used

For event-triggered sync (Okta Event Hooks), the adapter uses the service app's `private_key_jwt` credentials to authenticate to Okta independently.

## Governance

### Access Certifications

With AI Agents registered in Universal Directory, you can include them in Okta Access Certification campaigns:

- Review which AI Agents have access to which Managed Connections
- Revoke access for agents that no longer need it
- Track certification completion and exceptions

### Access Requests

Configure Okta Access Requests to require approval for:

- Activating new AI Agents
- Adding Managed Connections
- Expanding scope grants

### System Log Integration

The adapter emits structured audit events for SIEM integration:

| Event | Description |
|-------|-------------|
| `dcr_registration` | New client registered via DCR |
| `cimd_resolution` | CIMD client resolved and evaluated |
| `xaa_token_exchange` | Cross-app token exchange completed |
| `ai.agent.promoted` | Client promoted to Okta AI Agent |
| `managed.connections.synced` | Managed Connections sync completed |

### ISPM (Identity Security Posture Management)

The adapter supports ISPM Shadow AI detection:
- `X-Okta-Agent-Id` header included in all Okta API calls for attribution
- Session correlation via `sid` claim propagation
- All OAuth grants traceable to the adapter's AI Agent principal
- Structured audit logs with fields aligned to Okta System Log schema

## Troubleshooting

| Issue | Check |
|-------|-------|
| "Adapter AI Agent not found" at startup | Verify `OKTA_AI_AGENT_ID` matches the agent in Okta |
| "governance gap" warning | The AI Agent is DEACTIVATED or deleted — reactivate in Admin Console |
| Managed Connections not syncing | Verify `OKTA_MANAGED_CONNECTIONS_ENABLED=true` and `OKTA_SERVICE_CLIENT_ID` is set |
| Auto-promotion not working | Set both `OKTA_AI_AGENT_ENABLED=true` and `OKTA_AI_AGENT_AUTO_REGISTER=true` |
| Scope constraint errors | Check Managed Connection scopes match resource expectations |
