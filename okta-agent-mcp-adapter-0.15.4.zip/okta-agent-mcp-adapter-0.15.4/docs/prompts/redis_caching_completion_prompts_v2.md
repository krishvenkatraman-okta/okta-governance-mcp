# Okta MCP Adapter — Redis Caching Migration: Completion Prompts

**8 Prompts • Sequential Execution • Validated against current source**

---

## Overview

This document is a sequential prompt pack for completing the Redis caching migration in the Okta MCP Adapter. It has been validated against the actual contents of `okta_agent_proxy/` — every cache name, method signature, and channel constant referenced in the prompts matches the real source, not the design doc.

Unlike a green-field plan, this pack starts from the current state of the codebase, in which the `CacheProvider` abstraction, two-tier `CacheService`, pub/sub event bus, and most cache wiring already exist. The prompts here close the remaining gaps that block horizontal scaling — specifically `UserTokenStore`, `GatewayCodeManager`, `ConfidentialRelay` state dicts, and `ConsentTransactionStore` — and lock in cross-pod invalidation, encryption safety checks, and integration test coverage.

The end goal is a deployment story where the adapter can run as 2+ replicas behind a load balancer, sharing one Redis, with no requests failing due to cross-pod state divergence. This is the precondition for the Azure AKS production deployment that follows this work.

---

## Current State of the Caching Migration

Run Prompt 1 to verify the current state matches what's documented below. The state-of-play table is based on a code review of `okta_agent_proxy/` as uploaded to the project.

| Component | Status | Notes |
|---|---|---|
| CacheProvider abstraction | Done | `cache/base.py`, `memory_provider.py`, `redis_provider.py` |
| Two-tier CacheService (L1+L2) | Done | `cache/cache_service.py` with `create_from_env` |
| TokenCache via CacheService | Done | `cache/token_cache.py` — accepts `cache_service` + `encryption_service` |
| MCPSessionManager via CacheService | Done | `proxy/session_manager.py` — fully wired |
| JWKS cache via CacheService | Done | `auth/okta_validator.py` |
| CachedConfigStore | Done | `storage/cached_store.py`, `storage/config_cache.py` |
| Tool catalog cache (per-agent) | Done | `mcp/unified_handler.py` — flushed on startup via `tool_catalog:` prefix |
| CIMD metadata cache (CIMDFetcher) | Done | `auth/cimd_fetcher.py` — wired through `cache_service` |
| Pub/sub event bus | Done | `cache/pubsub.py` — channels: `route_invalidate`, `agent_invalidate`, `tool_catalog_invalidate`, `dcr_patterns_invalidate` |
| Encryption service module wiring | Done | `_encryption_svc` loaded in `app.py` and passed to TokenCache, ResourceRouter, DCRHandler |
| **UserTokenStore** | **GAP — CRITICAL** | Module-level singleton; TTLCache only. No `cache_service` param. Methods: `store/lookup/update/remove/remove_by_user`. Encryption already wired via singleton. |
| **GatewayCodeManager** (`_sessions_by_code`, `_sessions_by_token`) | **GAP — CRITICAL** | `auth/gateway_code_manager.py` — pure dict + TTLCache. Owns single-use gateway code lifecycle. Used by ConfidentialRelay AND consent flow. |
| **ConfidentialRelay state dicts** | **GAP — CRITICAL** | `_sessions_by_state` and `_preconsent_sessions_by_state` in `auth/confidential_relay.py` — in-process only. Holds in-flight OAuth round-trip state between authorize and callback. |
| **ConsentTransactionStore** | **GAP — CRITICAL** | `auth/consent_transaction.py` — pure dicts (`_by_id`, `_by_session`). The STS consent interstitial flow spans multiple HTTP requests and breaks immediately on multi-pod. |
| Pub/sub channels for token / relay / consent / logout | GAP | Only 4 channels exist today. Logout/refresh on pod A doesn't notify pod B. |
| Multi-pod integration tests | GAP | No test exercises two adapter instances against shared Redis end-to-end. |
| Ops runbook for horizontal scaling | Partial | `docs/OPERATIONS.md` mentions `CACHE_PROVIDER` but lacks the explicit horizontal-scaling preconditions. |

---

## Prompt Map

| # | Prompt | Creates / Modifies | Est. Time |
|---|---|---|---|
| P1 | Cache audit & gap report | `reports/redis-caching-gap.md` (read-only analysis) | 10 min |
| P2 | Migrate UserTokenStore via singleton accessor | `auth/user_token_store.py` + tests | 25 min |
| P3 | Migrate GatewayCodeManager + ConfidentialRelay state | `auth/gateway_code_manager.py`, `auth/confidential_relay.py` + tests | 40 min |
| P3.5 | Migrate ConsentTransactionStore | `auth/consent_transaction.py`, `app.py` + tests | 30 min |
| P4 | Centralize EncryptionService + startup warning | `cache/cache_service.py`, `app.py` wiring, tests | 15 min |
| P5 | Pub/sub channels for token / relay / consent / logout | `cache/pubsub.py`, `app.py` + tests | 25 min |
| P6 | Multi-pod integration test harness | `tests/integration/test_redis_multipod.py` | 30 min |
| P7 | Docs + ops runbook update | `docs/OPERATIONS.md`, `CLAUDE.md`, `README.md`, `deploy/HORIZONTAL_SCALING.md` | 15 min |

---

## Prerequisites

- Claude Code CLI authenticated and pointed at the `okta-agent-mcp-adapter` repository root
- Local PostgreSQL and Redis available (the existing docker-compose dev stack is sufficient)
- Python 3.12 venv with all dev dependencies installed (`pip install -e ".[dev]"`)
- Existing test suite passes before you start (`pytest -x`) — fix any failures first
- `ENCRYPTION_KEY` set in your local `.env` (Prompt 4 makes this a loud requirement for Redis mode)
- Clean working tree on a feature branch named `feat/redis-caching-completion`
- `fakeredis` installed for the integration test harness in P6 (`pip install fakeredis`)

---

## How to Execute

Copy each prompt body into the Claude Code CLI in order. Each prompt is self-contained and idempotent — if it fails partway through you can re-run it. Wait for each to complete before starting the next, and commit after each successful prompt so you can bisect any regression.

```bash
# From the project root:
cd okta-agent-mcp-adapter
git checkout -b feat/redis-caching-completion

# Confirm starting state is clean:
pytest -x

# Then paste each prompt body into Claude Code, one at a time.
# Commit after each green test run:
git add -A && git commit -m "P<N>: <prompt title>"
```

---

## Validation Notes

This pack was rebuilt after validating the prior version against `okta_agent_proxy/` source. Key corrections from the prior draft:

- `UserTokenStore` API uses `store/lookup/update/remove/remove_by_user`, not `set/get/invalidate/clear_user`
- `GatewayCodeManager` (not `ConfidentialRelay`) owns `_sessions_by_code` and `_sessions_by_token`; the relay exposes them as backward-compat properties
- `ConfidentialRelay` has no `try_reuse_tokens` method — the prior "by_client secondary index" design was based on a stale doc
- `ConsentTransactionStore` was missing from the prior pack entirely; it is its own CRITICAL gap and now has a dedicated prompt P3.5
- Pub/sub channel names use underscores (`route_invalidate`), not colons; existing channels are `route`, `agent`, `tool_catalog`, `dcr_patterns`
- `CacheEventBus` has only generic `publish`/`subscribe`; no `publish_route_invalidate`-style helpers exist today
- `CIMDFetcher` is already CacheService-wired; the prior P6 (CIMD metadata cache) has been removed
- Encryption is already wired correctly via `_encryption_svc` in `app.py`; P4 only adds a startup safety check, not a re-wire

---

## Prompt 1: Cache Audit & Gap Report

### Context

Read-only audit. Before changing any code, produce a current-state inventory of every cache in the codebase, what storage it uses, and whether it is safe under horizontal scaling. This exists so the implementation prompts that follow have a shared ground truth and so we don't break anything that's already correctly wired through CacheService.

### Prompt

*Copy the text below into Claude Code:*

```
Analyze the Okta MCP Adapter codebase and produce a Redis caching gap
report. Do NOT modify any source files. Write the result to
reports/redis-caching-gap.md.

Steps:
1. Find every cache-like data structure in okta_agent_proxy/. Look for:
   - cachetools.TTLCache instances
   - dict / defaultdict used as in-process caches
   - module-level _cache, _store, _sessions variables
   - any class attribute named *cache*, *store*, *sessions*

2. For each one, capture:
   - File and class name
   - Cache key shape (what identifies an entry)
   - Value type (token, session, JWKS, config, metadata, transaction)
   - Whether it accepts a CacheService in __init__
   - Whether it actually USES the CacheService in get/set paths
   - TTL strategy
   - What happens if a different pod sets / invalidates the entry

3. Cross-reference against the known-good list (these should all be
   on CacheService already — flag any that are NOT):
   - TokenCache (cache/token_cache.py)
   - MCPSessionManager (proxy/session_manager.py)
   - OktaTokenValidator JWKS cache (auth/okta_validator.py)
   - CachedConfigStore (storage/cached_store.py) and config_cache.py
   - UnifiedMCPHandler tool catalog (mcp/unified_handler.py)
   - CIMDFetcher metadata cache (auth/cimd_fetcher.py)

4. Identify caches that are NOT yet on CacheService. Specifically check:
   - auth/user_token_store.py — UserTokenStore (module-level singleton)
   - auth/gateway_code_manager.py — GatewayCodeManager
     (_sessions_by_code dict, _sessions_by_token TTLCache)
   - auth/confidential_relay.py — ConfidentialRelay
     (_sessions_by_state, _preconsent_sessions_by_state)
   - auth/consent_transaction.py — ConsentTransactionStore
     (_by_id, _by_session)
   - any other module under okta_agent_proxy/auth/ with cachetools or
     dict caches

5. For each gap, classify severity:
   - CRITICAL: breaks correctness across pods (e.g. user logs in on
     pod A, next request hits pod B and is rejected)
   - HIGH: breaks performance across pods (every pod re-fetches hot
     data)
   - MEDIUM: nice-to-have consistency improvement

6. Check pub/sub channel coverage. Open cache/pubsub.py and list the
   constants: CHANNEL_ROUTE_INVALIDATE, CHANNEL_AGENT_INVALIDATE,
   CHANNEL_TOOL_CATALOG_INVALIDATE, CHANNEL_DCR_PATTERNS_INVALIDATE.
   Identify any cache that has no invalidation channel at all.

7. Write the report with these sections:
   - Executive Summary (3-5 bullets)
   - Caches Already on CacheService (table)
   - Gaps by Severity (table per severity level)
   - Pub/Sub Coverage Matrix
   - Recommended Prompt Sequence

Do NOT propose code changes in this report. Do NOT touch any .py file.
Only create reports/redis-caching-gap.md.
```

### Expected Output

A single new file at `reports/redis-caching-gap.md`. The report should explicitly identify UserTokenStore, GatewayCodeManager, ConfidentialRelay state dicts, and ConsentTransactionStore as CRITICAL gaps, and the missing pub/sub channels for token/logout invalidation as a HIGH gap. No source files modified.

---

## Prompt 2: Migrate UserTokenStore via Singleton Accessor

### Context

`UserTokenStore` is a module-level singleton constructed by `get_user_token_store()` in `auth/user_token_store.py`. It caches the BFF discovery results (id_token, refresh_token, user_sub, agent_id) keyed by SHA-256 hash of the inbound access_token. Today it is a TTLCache only — when the adapter scales to 2+ pods, a request can hit a pod that has never seen the access_token and the user gets a 401. Encryption already works at L1 (the singleton wires `get_encryption_service()` in `__init__`). Migrate it to also use CacheService as the L2 backing store, keeping the existing TTLCache as L1 fast-path. The store's public API uses `store / lookup / update / remove / remove_by_user` — preserve those exact names and signatures.

### Prompt

*Copy the text below into Claude Code:*

```
Migrate okta_agent_proxy/auth/user_token_store.py to use CacheService
as an L2 backing store while keeping the existing TTLCache as L1.

Background to load before editing:
- Read auth/user_token_store.py end to end. Note the existing API:
  store(), lookup(), update(), remove(), remove_by_user(), get_stats().
  All are SYNCHRONOUS today.
- Read cache/token_cache.py to see the dual sync/async pattern this
  prompt is mirroring.
- Read cache/serializers.py — serialize_encrypted /
  deserialize_encrypted are already used by user_token_store.

Requirements:

1. Update UserTokenStore.__init__ to accept an optional cache_service
   parameter (default None). Keep all existing parameters
   (encryption_service, default_ttl, max_size). Update the [TOKEN-STORE]
   init log to also report whether cache_service is wired.

2. Define a key prefix constant at module level:
     _USER_TOKEN_PREFIX = "user_token:"
   And a helper:
     def _service_key(self, token_hash: str) -> str:
         return f"{_USER_TOKEN_PREFIX}{token_hash}"

3. Preserve the existing sync API. The existing store(), lookup(),
   update(), remove(), remove_by_user() methods MUST keep working
   exactly as they do today against the local TTLCache. Do not change
   their signatures.

4. Add async equivalents next to the sync methods:
     async def astore(...)  — same args as store()
     async def alookup(...) -> Optional[dict]
     async def aupdate(...)
     async def aremove(...)
     async def aremove_by_user(user_sub: str) -> int
   Each async method:
   - Performs the same L1 mutation as its sync counterpart (so single-
     pod behavior is unchanged)
   - If cache_service is set, also performs the same operation against
     CacheService using the prefixed key
   - Reuses _serialize / _deserialize so encryption remains correct
   - Wraps cache_service calls in try/except and logs warnings on
     failure WITHOUT raising — falling back to L1-only

5. The async aremove_by_user implementation uses
   cache_service.clear_prefix(f"{_USER_TOKEN_PREFIX}") to clear the
   L2 entries for that user. Note: this clears ALL user_token entries
   in L2, not just one user's. Document this trade-off in a docstring;
   the alternative (storing a per-user secondary index) is deferred.
   The L1 path still iterates and matches by user_sub like today.

6. Update get_user_token_store() so callers can pass an existing
   cache_service in. Change the signature to:
     def get_user_token_store(cache_service=None) -> UserTokenStore
   When cache_service is provided AND the singleton hasn't been built
   yet, pass it into the constructor. When the singleton already
   exists with a different (or None) cache_service, log a warning and
   return the existing one. Document this behavior.

7. Update okta_agent_proxy/app.py: after cache_service is created
   (line ~77) and _encryption_svc is loaded (line ~83), call
   get_user_token_store(cache_service=cache_service) at module load
   time so the singleton is built with both wired.

8. Find every call site of get_user_token_store() in the codebase
   (grep okta_agent_proxy/ tests/). Each call site is currently
   synchronous. DO NOT convert any call site to await yet — single-pod
   behavior must stay unchanged. The async API is opt-in for callers
   in new code and for the BFF token capture path. If a call site
   already runs in async context AND would benefit from cross-pod
   visibility (specifically: the BFF token capture in
   capture_token_mapping() and any /logout handler), update it to use
   the async variant.

9. Update capture_token_mapping() at the bottom of
   user_token_store.py: it currently calls store.store(). If running
   inside an async context, switch to astore(). Use a small helper
   that detects asyncio.get_running_loop() and dispatches:
     try:
         loop = asyncio.get_running_loop()
         loop.create_task(store.astore(...))
     except RuntimeError:
         store.store(...)
   This keeps the function non-blocking from sync callers and makes
   cross-pod write happen automatically when called from the BFF
   handler (which IS in async context).

10. Add audit events at write and remove points. AuditEventType
    already has TOKEN_CACHE_HIT and TOKEN_CACHE_MISS — those are the
    closest existing values. If you want store/remove granularity, add
    new types USER_TOKEN_STORE_WRITE and USER_TOKEN_STORE_REMOVE to
    audit/events.py and emit them from the L1 mutation path so both
    sync and async users get coverage. Use emit_audit_event() the same
    way other modules in auth/ do.

11. Add unit tests in tests/test_user_token_store_cache.py covering:
    - Standalone mode (no CacheService) — existing sync behavior
      unchanged
    - Two UserTokenStore instances sharing one MemoryCacheProvider
      (simulating two pods): astore on instance A, alookup on instance
      B returns the same payload
    - Encryption: when an EncryptionService is wired, the bytes stored
      in the underlying provider do NOT contain the raw id_token
    - aremove_by_user clears L1 entries by user_sub AND issues the L2
      clear_prefix
    - L2 failure (provider raises) falls back to L1-only without
      raising to the caller
    - capture_token_mapping() called from inside an async context
      schedules an L2 write

12. Run the full test suite. Fix any failures.

Print a summary at the end listing: files modified, new tests added,
test pass count, audit event types added (if any).
```

### Expected Output

`user_token_store.py` has dual sync/async API. Sync path unchanged. Async path additionally writes to CacheService when wired. Singleton accessor takes optional `cache_service`. App wiring updated. BFF capture uses async path automatically. New test file passes (six cases). Full suite passes.

---

## Prompt 3: Migrate GatewayCodeManager + ConfidentialRelay State

### Context

This is the most security-sensitive prompt. Two pieces of state are migrated together because they're tightly coupled in the OAuth round-trip.

1. **GatewayCodeManager** owns `_sessions_by_code` (dict) and `_sessions_by_token` (TTLCache). It issues single-use gateway codes and tracks issued access tokens.
2. **ConfidentialRelay** owns `_sessions_by_state` and `_preconsent_sessions_by_state` — in-flight OAuth state between the `/authorize` and `/oauth/callback` hops.

Both must move to CacheService or CIMD breaks across pods immediately. The single-use guarantee on gateway codes (today: `del self._sessions_by_code[code]` on exchange) must be preserved against the L2 store.

### Prompt

*Copy the text below into Claude Code:*

```
Migrate the in-process state in auth/gateway_code_manager.py and
auth/confidential_relay.py to CacheService.

Background to load before editing:
- Read auth/gateway_code_manager.py end to end. The current public API
  is: issue_code, exchange_code, lookup_token, track_token. The
  PendingCodeSession dataclass is the value type for the by_code
  store. _sessions_by_token is a TTLCache of arbitrary dicts.
- Read auth/confidential_relay.py end to end. Note that
  ConfidentialRelay exposes _sessions_by_code and _sessions_by_token
  as backward-compat properties that DELEGATE to GatewayCodeManager —
  so the relay does not need direct CacheService wiring for those two.
  The relay DOES own _sessions_by_state and _preconsent_sessions_by_state
  directly, and those need their own migration.
- Read auth/consent_transaction.py — the consent flow ALSO uses
  GatewayCodeManager (issue_code is called from the consent finish
  handler), so any change to issue_code/exchange_code semantics affects
  both the relay flow and the consent interstitial flow. Do not break
  either.
- Read tests/test_gateway_code_manager.py and
  tests/test_confidential_relay.py end to end.

Requirements:

PART A — GatewayCodeManager

1. Define module-level constants in gateway_code_manager.py:
     _CODE_PREFIX = "gateway_code:"
     _TOKEN_PREFIX = "gateway_token:"
   Default by_code TTL stays 300s. Default by_token TTL stays
   token_ttl (3600s).

2. Update GatewayCodeManager.__init__ to accept optional
   cache_service and encryption_service parameters. Keep token_ttl
   and max_tokens. Keep the existing local _sessions_by_code dict
   and _sessions_by_token TTLCache as L1 fast-path.

3. Add to_dict / from_dict methods to PendingCodeSession that handle
   the datetime field (created_at) via isoformat. Use the same
   pattern serializers.py expects (or just use dataclasses.asdict +
   manual datetime conversion).

4. Convert the four public methods to async. issue_code becomes
   aissue_code, exchange_code becomes aexchange_code, etc. Then add
   thin sync shims that ONLY work when cache_service is None — they
   raise RuntimeError("sync API requires cache_service=None") if
   called with cache_service set, so we catch any caller that hasn't
   been migrated. This forces every caller to either run sync (single-
   pod) or async (multi-pod) explicitly.

   Inspect every call site of issue_code / exchange_code /
   lookup_token / track_token in the codebase before doing this — if
   there are sync callers in async-context code paths, convert them
   to the async variant in the same prompt. The known call sites are:
   - auth/confidential_relay.py (callback handler — already in async
     context via app.py routes)
   - app.py consent finish handler (async)
   - any DCR token endpoint code (async)
   All of these can become async.

5. aissue_code:
   - Build the PendingCodeSession as today
   - Write to L1 (_sessions_by_code[code] = session)
   - If cache_service set: serialize via to_dict + serialize_encrypted
     (when encryption_service available, otherwise serialize_json),
     then await cache_service.set(_CODE_PREFIX + code, payload,
     ttl_seconds=ttl_seconds)
   - Return code

6. aexchange_code — CRITICAL single-use semantics:
   - Check L1 first. If present:
     a) Pop from L1 unconditionally BEFORE any further await
     b) If cache_service set, await cache_service.delete(_CODE_PREFIX
        + code) (best-effort; log on failure)
     c) Validate expired/client_id/etc. AFTER popping (so a stale
        session can't be re-consumed)
   - Else if cache_service set:
     a) Load from L2 via cache_service.get
     b) Immediately delete from L2 (best-effort) BEFORE any other
        operation
     c) Deserialize and validate
   - Else: raise GatewayCodeNotFound
   - Track the issued access_token via the same path issue_code uses
     today (write to both L1 and L2 via track_token)
   Note: this is "best-effort single use" not strict atomic GETDEL.
   For strict atomicity, P3 follow-up could land a Lua script in
   redis_provider.py — that is documented as deferred, not done here.

7. atrack_token / alookup_token follow the standard L1 -> L2
   fallthrough used in TokenCache.

8. PendingCodeSession's extra dict may contain relay_client_secret
   and other sensitive fields. When encryption_service is set,
   to_dict serialization MUST be encrypted. When encryption_service
   is NOT set AND cache_service IS set AND the L2 provider is Redis,
   log a one-time WARNING at issue_code time:
     "GatewayCodeManager: writing pending code to Redis WITHOUT
     encryption — set ENCRYPTION_KEY to fix"

PART B — ConfidentialRelay state

9. Define module-level constants in confidential_relay.py:
     _RELAY_STATE_PREFIX = "relay_state:"
     _PRECONSENT_STATE_PREFIX = "relay_preconsent:"
   TTL for both: 600 seconds (matches RelaySession.ttl_seconds default
   of 300 + slack for slow user clicks; configurable via
   RELAY_STATE_TTL env var).

10. Update ConfidentialRelay.__init__ to accept optional cache_service
    and encryption_service parameters. Keep the existing local dicts
    as L1 fast-path. Pass cache_service and encryption_service through
    to GatewayCodeManager() at line 150.

11. Add to_dict / from_dict to RelaySession and PreConsentSession
    dataclasses. Handle the datetime created_at via isoformat. The
    relay_client_secret field is sensitive — encryption is
    REQUIRED if cache_service is wired and L2 is Redis (same
    one-time warning pattern as PART A).

12. Add async helpers next to every direct dict mutation in the file:
      async def _store_relay_state(state, session): write to L1 dict
        AND cache_service.set(_RELAY_STATE_PREFIX + state, payload,
        ttl_seconds=...)
      async def _load_relay_state(state) -> Optional[RelaySession]:
        L1 -> L2 fallthrough
      async def _delete_relay_state(state): pop L1, await L2 delete
      async def _store_preconsent_state(...): same pattern with
        _PRECONSENT_STATE_PREFIX
      async def _load_preconsent_state(...): same pattern
      async def _delete_preconsent_state(...): same pattern

13. Update every call site inside confidential_relay.py that touches
    self._sessions_by_state[...] or self._preconsent_sessions_by_state
    to go through the new async helpers. Each handler in the relay
    is already async (they're called from Starlette async routes), so
    converting to await is straightforward. Re-check is_preconsent_state
    — it's a sync method called from /oauth/callback dispatch logic.
    Add an aiis_preconsent_state async variant that checks L2 too,
    and update the dispatch caller (in app.py /oauth/callback) to await
    it.

14. Update okta_agent_proxy/app.py line ~218:
      confidential_relay = ConfidentialRelay(
          cache_service=cache_service,
          encryption_service=_encryption_svc,
      )

PART C — Tests

15. Update tests/test_gateway_code_manager.py: add a new test class
    TestGatewayCodeManagerCacheService that constructs two
    GatewayCodeManager instances sharing one MemoryCacheProvider via
    one CacheService. Test cases:
    - aissue_code on instance A, aexchange_code on instance B
      succeeds; second exchange on A returns GatewayCodeNotFound
    - atrack_token on A, alookup_token on B returns the value
    - Encrypted mode: stored bytes in the provider do NOT contain
      access_token plaintext

16. Update tests/test_confidential_relay.py: add
    TestConfidentialRelayCacheService with cases:
    - Two ConfidentialRelay instances sharing one CacheService:
      _store_relay_state on A, _load_relay_state on B returns the
      same RelaySession
    - Pre-consent state visible across instances
    - relay_client_secret encrypted at rest in the provider when
      encryption_service is wired
    - Existing in-flight OAuth state on instance A is consumable on
      instance B after a simulated callback

17. Run the full test suite. Fix any failures, especially in CIMD
    end-to-end tests (tests/test_e2e_cimd.py) and the existing
    confidential_relay tests.

Print a summary listing: files modified, async helpers added, new
test classes, full test pass count, any audit events touched.
```

### Expected Output

GatewayCodeManager and ConfidentialRelay state dicts both have L1+L2 paths. Single-use gateway code semantics preserved via L1-pop-before-L2-delete sequencing. `relay_client_secret` encrypted in L2 when `ENCRYPTION_KEY` set. App wiring updated. Existing CIMD tests still pass. New cross-instance tests pass.

---

## Prompt 3.5: Migrate ConsentTransactionStore

### Context

`ConsentTransactionStore` (`auth/consent_transaction.py`) is pure in-process state — `_by_id` and `_by_session` dicts. It tracks the STS consent verification state during the OAuth authorization flow. The flow spans multiple HTTP requests (Okta callback creates the transaction, the consent UI polls it, the finish handler marks it complete and calls `GatewayCodeManager.issue_code`), so any 2-pod deployment will lose state mid-flow today. This is its own prompt because the value type (`ConsentTransaction` with nested `ConsentConnectionStatus` list) is more complex than the other migrations and the dual-index pattern (`by_id` + `by_session`) needs careful handling.

### Prompt

*Copy the text below into Claude Code:*

```
Migrate okta_agent_proxy/auth/consent_transaction.py to back its state
on CacheService while keeping the local dicts as L1 fast-path.

Background to load before editing:
- Read auth/consent_transaction.py end to end. Note the dual index:
  _by_id maps transaction_id -> ConsentTransaction, and _by_session
  maps session_id -> transaction_id. Lookups happen via either.
- Read auth/consent_verification.py to see the consumer side.
- Read app.py around line 228 to see how ConsentTransactionStore is
  constructed today.
- Find every call site of ConsentTransactionStore.create / get_by_id
  / get_by_session / validate_session / remove. Most are in app.py
  consent interstitial route handlers.

Requirements:

1. Define module-level constants:
     _CONSENT_TX_PREFIX = "consent_tx:"
     _CONSENT_SESSION_INDEX_PREFIX = "consent_session:"
   The first stores the full ConsentTransaction; the second is a
   pointer (just the transaction_id string) keyed by session_id, so
   get_by_session can look up across pods without scanning.

2. Add to_dict / from_dict methods to ConsentTransaction AND
   ConsentConnectionStatus (it's nested in the connections list).
   Handle the float created_at and the Optional[float] checked_at
   directly — both are time.monotonic() values, so they're
   process-local. WARNING: time.monotonic() is NOT comparable across
   processes. Replace it with time.time() (epoch seconds) so the
   is_expired property works after deserialization on a different
   pod. This is a small breaking change to the dataclass — search
   for any other use of ConsentTransaction.created_at to confirm
   nothing depends on monotonic semantics. Update the is_expired
   property to use time.time() too.

3. Update ConsentTransactionStore.__init__ to accept optional
   cache_service and encryption_service parameters. Keep the existing
   _by_id and _by_session dicts as L1.

4. Encryption is REQUIRED when cache_service is wired and L2 is
   Redis: ConsentTransaction holds id_token, access_token,
   refresh_token, AND relay_client_secret. Log a one-time WARNING at
   create() time if encryption is missing under those conditions.

5. Convert the public methods. The current API is sync. Add async
   variants alongside (acreate, aget_by_id, aget_by_session,
   avalidate_session, aremove). Keep the sync versions working
   against L1 only — they remain valid for unit tests and single-pod
   deployments.

6. acreate:
   - Build the ConsentTransaction as today
   - Write to L1: self._by_id[tx_id] = tx; self._by_session[sess_id]
     = tx_id
   - If cache_service: serialize tx via to_dict + serialize_encrypted,
     await cache_service.set(_CONSENT_TX_PREFIX + tx_id, payload,
     ttl_seconds=tx.ttl_seconds). Then write the session index
     pointer: cache_service.set(_CONSENT_SESSION_INDEX_PREFIX +
     session_id, tx_id, ttl_seconds=tx.ttl_seconds)
   - Return tx

7. aget_by_id:
   - L1 hit: return (and remove if expired, like today)
   - L1 miss + cache_service: cache_service.get(_CONSENT_TX_PREFIX +
     tx_id), deserialize, populate L1, check expiry
   - Else None

8. aget_by_session:
   - L1 hit: delegate to get_by_id (existing behavior)
   - L1 miss + cache_service: load the pointer from
     _CONSENT_SESSION_INDEX_PREFIX + session_id, then aget_by_id with
     the resolved tx_id

9. avalidate_session: identical to today but uses aget_by_session
   internally and adds the same IP/UA mismatch checks.

10. aremove:
    - Pop both L1 indices like today
    - If cache_service: delete _CONSENT_TX_PREFIX + tx_id AND
      _CONSENT_SESSION_INDEX_PREFIX + session_id

11. There is also an UPDATE path the consent flow uses — when a
    connection's status changes from "consent_required" to
    "verified", the in-process ConsentTransaction object is mutated
    in place. With L2 in the picture, those mutations are silently
    lost across pods. Audit consent_verification.py and any consent
    routes in app.py for in-place mutations of a fetched
    ConsentTransaction. After each mutation site, add an
    "await store.apersist(tx)" call where apersist re-serializes and
    writes the current tx state back to L2 (and refreshes L1).
    Implement apersist as a new method on ConsentTransactionStore.

12. Update app.py line ~228:
      consent_store = ConsentTransactionStore(
          cache_service=cache_service,
          encryption_service=_encryption_svc,
      )

13. Update get_by_id callers in app.py consent route handlers to
    use aget_by_id (they're all async route handlers). Same for
    get_by_session, validate_session, remove. Add the apersist call
    after every mutation.

14. Tests in tests/test_consent_transaction_cache.py:
    - Two ConsentTransactionStore instances sharing a CacheService
    - acreate on A, aget_by_id on B returns identical tx (including
      nested connections list)
    - aget_by_session via the index pointer works cross-instance
    - apersist after a connection status change is visible on the
      other instance
    - Encryption: id_token / access_token / relay_client_secret bytes
      in the provider don't contain plaintext
    - aremove cleans up both prefixes
    - Expired tx is removed on read (same behavior as today)
    - is_expired uses time.time() after the migration

15. Run the full suite, focusing on tests/test_consent_*.py and the
    consent interstitial e2e tests.

Print a summary.
```

### Expected Output

`ConsentTransactionStore` is L1+L2. Dual-index works cross-pod via the session pointer. In-place mutation hazard fixed via `apersist`. Time field migrated from `monotonic` to `time.time`. Tests cover all cases. Existing consent flow tests still pass.

---

## Prompt 4: Centralize EncryptionService Access + Startup Warning

### Context

Encryption is already wired correctly today: `app.py` loads `_encryption_svc` via `get_encryption_service()` at module init and threads it into TokenCache, ResourceRouter, DCRHandler, and (after P2/P3/P3.5) UserTokenStore, GatewayCodeManager, ConfidentialRelay, ConsentTransactionStore. This prompt does NOT change that wiring — it only adds a loud startup warning when Redis is enabled without an encryption key, and adds a small helper to `cache_service.py` so future code has a single place to ask for the env-derived encryption service. This prompt is small but worth running on its own because it produces the user-visible safety check we want before declaring horizontal scaling supported.

### Prompt

*Copy the text below into Claude Code:*

```
Add centralized encryption-aware factory helpers and a startup warning
when Redis is configured without ENCRYPTION_KEY.

Steps:
1. In cache/cache_service.py, add a module-level helper:
     def get_encryption_service_or_none():
         try:
             from okta_agent_proxy.crypto.encryption import get_encryption_service
             return get_encryption_service()
         except Exception:
             return None
   Document that this is a convenience for callers that want to opt
   into encryption when available without crashing if the key isn't
   set. It must NOT cache — get_encryption_service() already does.

2. Add a CacheService.is_redis_backed() helper:
     @property
     def is_redis_backed(self) -> bool:
         from okta_agent_proxy.cache.redis_provider import (
             RedisCacheProvider,
         )
         return isinstance(self._l2, RedisCacheProvider)

3. In okta_agent_proxy/app.py, immediately after _encryption_svc is
   set (line ~86), add a startup safety check:
     if cache_service.is_redis_backed and _encryption_svc is None:
         logger.warning(
             "=" * 78
             + "\nREDIS ENABLED WITHOUT ENCRYPTION_KEY"
             + "\nSensitive tokens (id_token, refresh_token, "
             + "relay_client_secret, consent transactions) will be "
             + "stored UNENCRYPTED in Redis."
             + "\nSet ENCRYPTION_KEY to fix.\n"
             + "=" * 78
         )
   The warning must be visible in default log output, not buried at
   DEBUG level.

4. Verify (do not change) that every cache-bearing component listed
   below is constructed with encryption_service=_encryption_svc in
   app.py:
   - TokenCache (existing)
   - ResourceRouter resource_token_cache (existing)
   - DCRHandler (existing)
   - UserTokenStore (added by P2 — verify get_user_token_store call
     passes _encryption_svc indirectly via the singleton)
   - ConfidentialRelay (added by P3)
   - ConsentTransactionStore (added by P3.5)
   If any of these are missing the encryption_service param, fix it
   here. The check is mechanical: grep app.py for each constructor
   and confirm encryption_service= is present whenever cache_service=
   is.

5. Add a test in tests/test_cache_encryption_wiring.py that:
   - Constructs a CacheService with a Redis-flavored provider stub
     (or fakeredis if available)
   - Constructs an EncryptionService from a fixed test key
   - Wraps a TokenCache, a UserTokenStore, and (if available) a
     ConsentTransactionStore with both
   - Calls the write methods with known sensitive values
   - Reaches into the underlying provider directly via cache_service.l2
     and asserts the stored bytes do NOT contain any of the plaintext
     values
   - Calls the read methods and asserts the original values come back

6. Add a second test that constructs a CacheService backed by a
   MemoryCacheProvider (so is_redis_backed is False), confirms
   is_redis_backed is False, and confirms no warning is emitted.

7. Add a third test that uses a Redis-flavored provider stub with NO
   encryption_service and asserts the warning IS emitted (via
   capsys / caplog).

8. Update docs/OPERATIONS.md "Redis Cache" section to state that
   ENCRYPTION_KEY is REQUIRED (not optional) when CACHE_PROVIDER=redis
   in production, and document the new startup warning behavior.

9. Run the full test suite.

Print a summary listing files modified, the new test cases, and the
final test pass count.
```

### Expected Output

Loud startup warning when Redis is enabled without encryption. `is_redis_backed` helper available. Three new tests exercise the warning conditions. `OPERATIONS.md` updated. Full test suite green.

---

## Prompt 5: Pub/Sub Channels for Token / Relay / Consent / Logout

### Context

The pub/sub event bus has 4 channels today (`route_invalidate`, `agent_invalidate`, `tool_catalog_invalidate`, `dcr_patterns_invalidate`). It needs channels for the user-scoped state we just migrated. This prompt adds those channels, wires the publishers at the right code points, and registers the subscribers at app startup. Channel naming follows the existing underscore convention. `CacheEventBus` has only generic `publish/subscribe` today (no `publish_route_invalidate`-style helpers), so this prompt does not add convenience helpers either — call sites use `bus.publish(CHANNEL_NAME, payload)` directly.

### Prompt

*Copy the text below into Claude Code:*

```
Extend cache/pubsub.py with channels for cross-pod user / session
invalidation, then wire publishers and subscribers.

Steps:
1. In okta_agent_proxy/cache/pubsub.py, add new channel constants
   alongside the existing four:
     CHANNEL_USER_TOKEN_INVALIDATE = "user_token_invalidate"
     CHANNEL_RELAY_SESSION_INVALIDATE = "relay_session_invalidate"
     CHANNEL_CONSENT_TX_INVALIDATE = "consent_tx_invalidate"
     CHANNEL_USER_LOGOUT = "user_logout"

2. Add all four to ALL_CHANNELS list. Verify no other module
   hardcodes a channel list — only ALL_CHANNELS should change.

3. Message payload format: each publish takes a JSON-serialized dict
   so message handlers can route on the type. Standard envelope:
     {"v": 1, "key": "<identifier>", "user_sub": "<optional>"}
   For user_logout the key is the user_sub. For user_token_invalidate
   the key is the SHA-256 token hash. For relay_session_invalidate
   the key is the relay_state. For consent_tx_invalidate the key is
   the transaction_id. user_sub is optional metadata.
   Document this envelope in a docstring at the top of pubsub.py.

4. In okta_agent_proxy/app.py inside _on_startup (find the existing
   handler for CHANNEL_TOOL_CATALOG_INVALIDATE), add four new
   subscribers:

   async def _on_user_token_invalidate(message: str):
       try:
           import json
           payload = json.loads(message)
           token_hash = payload.get("key")
           if not token_hash:
               return
           # We don't have the raw access_token, just the hash.
           # Drop the L1 entry for that hash directly.
           store = get_user_token_store()
           store._cache.pop(token_hash, None)
           logger.info(f"Pub/sub: user_token invalidated locally "
                       f"({token_hash[:8]}...)")
       except Exception as e:
           logger.warning(f"user_token_invalidate handler failed: {e}")

   async def _on_relay_session_invalidate(message: str):
       try:
           import json
           payload = json.loads(message)
           state = payload.get("key")
           if not state:
               return
           confidential_relay._sessions_by_state.pop(state, None)
           confidential_relay._preconsent_sessions_by_state.pop(state, None)
           logger.info(f"Pub/sub: relay state invalidated locally "
                       f"({state[:8]}...)")
       except Exception as e:
           logger.warning(f"relay_session_invalidate handler failed: {e}")

   async def _on_consent_tx_invalidate(message: str):
       try:
           import json
           payload = json.loads(message)
           tx_id = payload.get("key")
           if not tx_id:
               return
           # Drop from both L1 indices
           tx = consent_store._by_id.pop(tx_id, None)
           if tx is not None:
               consent_store._by_session.pop(tx.session_id, None)
           logger.info(f"Pub/sub: consent tx invalidated locally "
                       f"({tx_id[:8]}...)")
       except Exception as e:
           logger.warning(f"consent_tx_invalidate handler failed: {e}")

   async def _on_user_logout(message: str):
       try:
           import json
           payload = json.loads(message)
           user_sub = payload.get("key")
           if not user_sub:
               return
           # Cascade: drop UserTokenStore entries for this user,
           # drop TokenCache entries for this user prefix, drop any
           # ConsentTransactionStore entries belonging to this user.
           get_user_token_store().remove_by_user(user_sub)
           # router.resource_token_cache uses user_sub as part of the
           # key prefix — call invalidate by user
           if hasattr(router, "resource_token_cache"):
               router.resource_token_cache.invalidate(user_id=user_sub)
           logger.info(f"Pub/sub: user_logout cascade for {user_sub}")
       except Exception as e:
           logger.warning(f"user_logout handler failed: {e}")

   await event_bus.subscribe(
       CHANNEL_USER_TOKEN_INVALIDATE, _on_user_token_invalidate
   )
   await event_bus.subscribe(
       CHANNEL_RELAY_SESSION_INVALIDATE, _on_relay_session_invalidate
   )
   await event_bus.subscribe(
       CHANNEL_CONSENT_TX_INVALIDATE, _on_consent_tx_invalidate
   )
   await event_bus.subscribe(
       CHANNEL_USER_LOGOUT, _on_user_logout
   )

5. Wire publishers:
   - In auth/user_token_store.py aremove() and aremove_by_user(),
     after the L2 delete, publish CHANNEL_USER_TOKEN_INVALIDATE. The
     store does not have a reference to event_bus today — pass it in
     via __init__ as an optional event_bus parameter, set it from the
     singleton accessor, and update app.py to pass it. Same pattern
     used by DCRHandler and DCRPolicy in the existing code.
   - In auth/confidential_relay.py _delete_relay_state and
     _delete_preconsent_state, publish CHANNEL_RELAY_SESSION_INVALIDATE
     after the L2 delete. Pass event_bus into __init__ the same way.
   - In auth/consent_transaction.py aremove(), publish
     CHANNEL_CONSENT_TX_INVALIDATE.
   - Find the BFF logout endpoint in app.py (search for "/logout" or
     "session.terminate"). After clearing local state, publish
     CHANNEL_USER_LOGOUT with the user_sub. If no logout endpoint
     exists yet, document that in the prompt summary and skip the
     publish — leave a TODO comment in app.py at the place where it
     should go.

6. Tests in tests/test_event_bus_user_invalidation.py:
   - Use the existing fakeredis fixture if there is one in
     tests/conftest.py; otherwise add a minimal one
   - Two adapter test instances sharing a CacheEventBus backed by
     the same fakeredis
   - Set a UserTokenStore entry on instance A
   - Publish user_token_invalidate from instance A
   - Wait briefly for the listener loop to process
   - Assert the entry is gone from instance B's L1 _cache
   - Repeat for relay_session_invalidate (set state on A, publish,
     assert gone from B's _sessions_by_state)
   - Repeat for consent_tx_invalidate
   - Repeat for user_logout: populate UserTokenStore and TokenCache
     for "alice" on A, publish user_logout, assert both are clear
     on B

7. Update docs/OPERATIONS.md pub/sub channel table to include the
   four new channels with their triggers and effects.

8. Run the full test suite.

Print a summary listing channels added, publish call sites added,
test cases, and pass count.
```

### Expected Output

Four new pub/sub channels exist, are published at the right code points, and are subscribed at startup. Tests with two instances sharing one event bus prove cross-pod invalidation. `OPERATIONS.md` updated.

---

## Prompt 6: Multi-Pod Integration Test Harness

### Context

Unit tests cover individual caches, but nothing in the suite exercises the full adapter pipeline with two adapter instances sharing one Redis. This prompt builds an integration test that proves the horizontal-scaling story end to end. It is the gate before we declare the Redis caching work complete and move on to the Azure deployment. The test must be runnable in CI without an actual Redis server (`fakeredis` is the standard choice).

### Prompt

*Copy the text below into Claude Code:*

```
Build an integration test that runs two adapter instances against a
shared Redis (fakeredis) and exercises the full hot path including all
the new caches added in P2-P3.5.

Steps:
1. Look for an existing Redis test fixture in tests/ (search for
   "fakeredis", "RedisCacheProvider" in tests/conftest.py and
   tests/integration/). Reuse if present; otherwise add a pytest
   fixture that yields a fakeredis-backed CacheService and a
   CacheEventBus wired to it.

2. Create tests/integration/test_redis_multipod.py with a class
   TestMultiPodRedisCaching. Each test creates two instances of
   the relevant cache class (call them inst_a and inst_b) sharing
   one CacheService. Use the existing test app factory if present
   in tests/conftest.py; otherwise wire up the minimum components
   directly.

   Test cases:

   a) test_user_token_visible_across_pods
      - astore on inst_a's UserTokenStore
      - alookup on inst_b — same payload returned

   b) test_resource_token_visible_across_pods
      - Set a resource token in inst_a's TokenCache
      - Read it from inst_b's TokenCache

   c) test_mcp_session_visible_across_pods
      - Pre-populate via inst_a.MCPSessionManager
      - Look up via inst_b — same session_id

   d) test_gateway_code_single_use_across_pods
      - aissue_code on inst_a's GatewayCodeManager
      - aexchange_code on inst_b — succeeds and returns tokens
      - Second aexchange_code on inst_a with same code — raises
        GatewayCodeNotFound
      - Third aexchange_code on inst_b — also raises

   e) test_relay_state_visible_across_pods
      - _store_relay_state on inst_a's ConfidentialRelay
      - _load_relay_state on inst_b — returns the same RelaySession

   f) test_consent_tx_visible_across_pods
      - acreate on inst_a's ConsentTransactionStore
      - aget_by_id on inst_b — returns the same ConsentTransaction
        with nested connections list intact
      - aget_by_session on inst_b via the session pointer — works

   g) test_consent_tx_apersist_visible_across_pods
      - acreate on inst_a
      - Mutate a connection's status on the in-memory tx returned
        from inst_a
      - Call inst_a.apersist(tx)
      - aget_by_id on inst_b — sees the new status

   h) test_user_logout_clears_all_pods
      - Populate UserTokenStore, TokenCache (router.resource_token_cache),
        and a ConsentTransaction for "alice" on inst_a
      - Publish CHANNEL_USER_LOGOUT with user_sub="alice"
      - Wait briefly (asyncio.sleep(0.1)) for pub/sub propagation
      - Assert all three caches are empty for alice on inst_b

   i) test_jwks_cache_visible_across_pods
      - Mock the JWKS HTTP fetch to track call count
      - validate_token via inst_a's OktaTokenValidator (forces fetch)
      - validate_token via inst_b
      - Assert JWKS fetch was called exactly once

   j) test_tool_catalog_invalidate_clears_both_pods
      - Populate the tool catalog on both adapters
      - Publish tool_catalog_invalidate from inst_a
      - Wait briefly
      - Assert both inst_a and inst_b's caches are empty

3. Each test must clean up its pub/sub listener task at teardown
   (cancel and await) so pytest doesn't leak event loops. Use a
   fixture with try/finally semantics.

4. Mark the file with @pytest.mark.integration so it can be selected
   or excluded by CI.

5. Run the new tests in isolation:
     pytest tests/integration/test_redis_multipod.py -v
   Then run the full suite to confirm nothing else regressed.

6. If any test reveals a real bug introduced by P2-P5, fix it in the
   underlying module rather than weakening the test.

Print a summary: number of tests added, pass/fail count, any bugs
found and fixed.
```

### Expected Output

`tests/integration/test_redis_multipod.py` exists with ten passing tests covering all migrated caches plus the existing JWKS and tool catalog flows. Full test suite still green.

---

## Prompt 7: Documentation & Operations Runbook Update

### Context

Final prompt. With the gaps closed and tests in place, update the documentation so the upcoming Azure deployment work can rely on the horizontal-scaling story, and so SE customers have a clear answer to "what does this look like running with multiple instances?"

### Prompt

*Copy the text below into Claude Code:*

```
Update documentation to reflect the completed Redis caching migration.

Steps:
1. Update docs/OPERATIONS.md "Redis Cache" section:
   - Add a new subsection "Horizontal Scaling Requirements" listing
     all four prerequisites:
       (a) CACHE_PROVIDER=redis
       (b) REDIS_URL set and reachable from every pod
       (c) ENCRYPTION_KEY set and IDENTICAL across every pod
       (d) FastMCP stateless_http=True (already the default —
           confirm in mcp/unified_handler.py before documenting)
   - Update the pub/sub channels table to include the four channels
     added in P5 (user_token_invalidate, relay_session_invalidate,
     consent_tx_invalidate, user_logout).
   - Add a "What is now safe across pods" subsection listing every
     cache that is CacheService-backed after P2-P3.5, with one-line
     semantics for each.
   - Add a troubleshooting subsection. Required entries:
     * "Symptom: 401 immediately after login on multi-pod deployment"
       -> check ENCRYPTION_KEY parity across pods, check REDIS_URL
       reachability, check CACHE_PROVIDER=redis is set on every pod.
     * "Symptom: CIMD client gets 'invalid_grant' on token exchange
       after a successful authorize" -> stale gateway code on the
       wrong pod; this should not happen post-P3 — verify
       GatewayCodeManager is constructed with cache_service.
     * "Symptom: consent UI loops back to /authorize" -> consent
       transaction lost across pods; verify ConsentTransactionStore
       is constructed with cache_service.
     * "Symptom: warning at startup about Redis without encryption"
       -> set ENCRYPTION_KEY before enabling Redis.

2. Update CLAUDE.md (project root convention file) with a short
   note: horizontal scaling is now supported when running with the
   four prerequisites above; single-pod deployments continue to work
   with CACHE_PROVIDER=memory (the default).

3. Update README.md "Architecture" or "Deployment" section with a
   one-paragraph callout that the adapter is now horizontally
   scalable behind a load balancer when backed by Redis, and link
   to the new OPERATIONS.md sections.

4. Update okta_mcp_adapter_architecture_v4.docx Section 11
   (Caching Architecture) — read it first, then write a markdown
   patch describing the changes to reports/architecture-v4-patch.md
   (do NOT edit the .docx directly; it will be hand-merged). The
   patch should:
   - Add UserTokenStore, GatewayCodeManager (sessions_by_code +
     sessions_by_token), ConfidentialRelay state dicts, and
     ConsentTransactionStore to the cache architecture diagram
   - Add the four new pub/sub channels
   - Update the "Stateless HTTP for FastMCP" security row to note
     that all per-flow state now lives in Redis when configured

5. Create a new file deploy/HORIZONTAL_SCALING.md summarizing:
   - Required env vars (CACHE_PROVIDER, REDIS_URL, REDIS_TLS_ENABLED,
     REDIS_KEY_PREFIX, ENCRYPTION_KEY, REDIS_PASSWORD)
   - Recommended Redis sizing: demo (Basic 250 MB equivalent),
     production (1 GB+ with replication)
   - Health-check recommendations: Redis liveness probe; the
     adapter is fail-open (Redis down means in-memory only on that
     pod, not request failure)
   - Pod scaling guidance: minimum 2 replicas with HPA; stickiness
     is NOT required because all per-flow state lives in Redis
   - Known limitations: aremove_by_user uses clear_prefix on a
     shared user_token: prefix; for fine-grained per-user
     invalidation a future migration could add a per-user secondary
     index. Document this so the Azure deployment doesn't get a
     surprise.

6. Run the full test suite one more time as a sanity check.

7. Print a summary listing every file created or modified and the
   final test pass count.
```

### Expected Output

`OPERATIONS.md`, `CLAUDE.md`, `README.md`, `deploy/HORIZONTAL_SCALING.md` updated/created. Architecture v4 patch written to `reports/architecture-v4-patch.md` for hand-merge. Test suite still green.

---

## After Completion

When all eight prompts have run and the full test suite is green, the adapter is ready to be deployed in a multi-replica configuration. The next step is the Azure deployment work, which can now safely use either:

- **AKS Automatic with HPA** (production profile) — multiple adapter replicas behind Application Gateway for Containers, sharing one Azure Cache for Redis Standard
- **Azure Container Apps** (demo profile) — can now scale beyond `minReplicas=1` because all per-flow state lives in Redis

Both deployment options require the four horizontal-scaling prerequisites: `CACHE_PROVIDER=redis`, `REDIS_URL`, `ENCRYPTION_KEY`, and FastMCP `stateless_http=True`. `deploy/HORIZONTAL_SCALING.md` (created in Prompt 7) is the authoritative reference.

## Deferred Items

- Strict atomic GETDEL for gateway codes via Redis Lua script — current implementation is best-effort load-then-delete, which is acceptable because the L1 pop happens before any await
- Per-user secondary index for `UserTokenStore.aremove_by_user` — current implementation uses `clear_prefix` on the shared `user_token:` prefix, which clears all users in L2
- Migration of `ConsentTransaction.created_at` from `time.monotonic()` to `time.time()` is a small breaking change; verify no consumer relies on monotonic semantics
- BFF `/logout` endpoint may not exist yet; P5 publish point is left as a TODO if so
