# Custom VNet + Private Endpoints + VNet Peering — Implementation Prompts

These are sequential, copy-paste-ready prompts for Claude Code CLI. Each prompt is self-contained. Run them in order against the `deploy/azure-aca/` directory.

---

## Prompt 01 — Add `--custom-vnet` flag and VNet/subnet creation to Phase 1

```
You are modifying `deploy/azure-aca/acasetup.sh` to add optional custom VNet support via a `--custom-vnet` flag.

### Current state
- The wizard creates the ACA Environment with platform-managed networking (no `--infrastructure-subnet-resource-id`)
- Flag parsing is in the `while [[ $# -gt 0 ]]` case block around line 86
- Phase 1 runs steps 1.1 through 1.9 in the `run_phase_1()` function
- The ACA Environment is created in Step 1.9

### What to change

1. **Add a new flag `--custom-vnet`** to the case block and help text:
   - Sets `CUSTOM_VNET=true` (default `false`)
   - Add to help text under Options: `--custom-vnet          Use a custom VNet with Private Endpoints and peering support`
   - Save to state: `save_state CUSTOM_VNET "$CUSTOM_VNET"`
   - On Phase 2, reload from state: `CUSTOM_VNET="$(get_state CUSTOM_VNET || echo false)"`

2. **Add optional env vars** to the help text and `.env.example`:
   ```
   # Optional — Custom VNet (only used with --custom-vnet)
   # VNET_NAME=okta-adapter-vnet
   # VNET_ADDRESS_PREFIX=10.0.0.0/16
   # ACA_SUBNET_PREFIX=10.0.0.0/23
   # PE_SUBNET_PREFIX=10.0.2.0/24
   ```

3. **Add a new Step 1.5b** (after ACR, before Postgres) that only runs when `CUSTOM_VNET=true`:
   ```bash
   if $CUSTOM_VNET; then
     info "Step 1.5b: Creating custom VNet and subnets..."
     VNET_NAME="${VNET_NAME:-okta-adapter-vnet}"
     VNET_ADDRESS_PREFIX="${VNET_ADDRESS_PREFIX:-10.0.0.0/16}"
     ACA_SUBNET_PREFIX="${ACA_SUBNET_PREFIX:-10.0.0.0/23}"
     PE_SUBNET_PREFIX="${PE_SUBNET_PREFIX:-10.0.2.0/24}"

     if az network vnet show -g "$AZURE_RG" -n "$VNET_NAME" &>/dev/null; then
       ok "VNet $VNET_NAME already exists"
     else
       az network vnet create -g "$AZURE_RG" -n "$VNET_NAME" \
         -l "$AZURE_LOCATION" \
         --address-prefix "$VNET_ADDRESS_PREFIX" \
         --output none
       ok "VNet created"
     fi

     # ACA infrastructure subnet — requires /23 minimum, delegated to Microsoft.App/environments
     if az network vnet subnet show -g "$AZURE_RG" --vnet-name "$VNET_NAME" -n aca-infra &>/dev/null; then
       ok "Subnet aca-infra already exists"
     else
       az network vnet subnet create -g "$AZURE_RG" --vnet-name "$VNET_NAME" \
         -n aca-infra \
         --address-prefix "$ACA_SUBNET_PREFIX" \
         --delegations Microsoft.App/environments \
         --output none
       ok "Subnet aca-infra created (delegated to Microsoft.App/environments)"
     fi

     # Private Endpoints subnet — no delegation needed
     if az network vnet subnet show -g "$AZURE_RG" --vnet-name "$VNET_NAME" -n private-endpoints &>/dev/null; then
       ok "Subnet private-endpoints already exists"
     else
       az network vnet subnet create -g "$AZURE_RG" --vnet-name "$VNET_NAME" \
         -n private-endpoints \
         --address-prefix "$PE_SUBNET_PREFIX" \
         --output none
       ok "Subnet private-endpoints created"
     fi

     ACA_SUBNET_ID="$(az network vnet subnet show -g "$AZURE_RG" --vnet-name "$VNET_NAME" -n aca-infra --query id -o tsv)"
     PE_SUBNET_ID="$(az network vnet subnet show -g "$AZURE_RG" --vnet-name "$VNET_NAME" -n private-endpoints --query id -o tsv)"
     save_state VNET_NAME "$VNET_NAME"
     save_state ACA_SUBNET_ID "$ACA_SUBNET_ID"
     save_state PE_SUBNET_ID "$PE_SUBNET_ID"
   fi
   ```

4. **Modify Step 1.9** (ACA Environment creation) to conditionally pass the subnet:
   ```bash
   ACA_ENV_ARGS=()
   if $CUSTOM_VNET; then
     ACA_SUBNET_ID="$(get_state ACA_SUBNET_ID)"
     ACA_ENV_ARGS+=(--infrastructure-subnet-resource-id "$ACA_SUBNET_ID")
     ACA_ENV_ARGS+=(--internal-only false)
   fi

   az containerapp env create -g "$AZURE_RG" -n "$ACA_ENV" \
     -l "$AZURE_LOCATION" \
     --logs-workspace-id "$LA_ID" \
     --logs-workspace-key "$LA_KEY" \
     "${ACA_ENV_ARGS[@]}" \
     --output none
   ```

### Constraints
- Do NOT change any behavior when `--custom-vnet` is not passed. The platform-managed path must remain identical.
- Every step must be idempotent (check "already exists" before creating).
- Save all resource IDs to state so they survive resume.
- Do not modify Phase 2 in this prompt.
```

---

## Prompt 02 — Add Private Endpoint for Postgres

```
You are modifying `deploy/azure-aca/acasetup.sh` to add a Private Endpoint for the Postgres Flexible Server when `--custom-vnet` is used.

### Current state
- Step 1.6 creates Postgres with `--public-access 0.0.0.0`
- After Prompt 01, `CUSTOM_VNET`, `PE_SUBNET_ID`, and `VNET_NAME` are in state when `--custom-vnet` is passed
- The `DATABASE_URL` is built using the public FQDN: `${PG_NAME}.postgres.database.azure.com`

### What to change

1. **In Step 1.6 (Postgres creation)**, change `--public-access` based on VNet mode:
   ```bash
   if $CUSTOM_VNET; then
     PG_PUBLIC_ACCESS="none"
   else
     PG_PUBLIC_ACCESS="0.0.0.0"
   fi
   ```
   Then use `--public-access "$PG_PUBLIC_ACCESS"` in the `az postgres flexible-server create` command.

2. **Add a new Step 1.6b** immediately after the database creation, only when `CUSTOM_VNET=true`:
   ```bash
   if $CUSTOM_VNET; then
     info "Step 1.6b: Creating Private Endpoint for Postgres..."
     PG_PE_NAME="${PG_NAME}-pe"
     PE_SUBNET_ID="$(get_state PE_SUBNET_ID)"

     if az network private-endpoint show -g "$AZURE_RG" -n "$PG_PE_NAME" &>/dev/null; then
       ok "Private Endpoint $PG_PE_NAME already exists"
     else
       PG_RESOURCE_ID="$(az postgres flexible-server show -g "$AZURE_RG" -n "$PG_NAME" --query id -o tsv)"

       az network private-endpoint create \
         -g "$AZURE_RG" -n "$PG_PE_NAME" \
         -l "$AZURE_LOCATION" \
         --vnet-name "$VNET_NAME" \
         --subnet private-endpoints \
         --private-connection-resource-id "$PG_RESOURCE_ID" \
         --group-id postgresqlServer \
         --connection-name "${PG_NAME}-connection" \
         --output none
       ok "Private Endpoint created for Postgres"
     fi

     # Create Private DNS Zone and link it to the VNet
     PG_DNS_ZONE="privatelink.postgres.database.azure.com"
     if az network private-dns zone show -g "$AZURE_RG" -n "$PG_DNS_ZONE" &>/dev/null; then
       ok "Private DNS zone $PG_DNS_ZONE already exists"
     else
       az network private-dns zone create -g "$AZURE_RG" -n "$PG_DNS_ZONE" --output none
       ok "Private DNS zone created"
     fi

     # Link DNS zone to VNet
     DNS_LINK_NAME="${VNET_NAME}-pg-dns-link"
     if az network private-dns link vnet show -g "$AZURE_RG" -z "$PG_DNS_ZONE" -n "$DNS_LINK_NAME" &>/dev/null; then
       ok "DNS VNet link already exists"
     else
       az network private-dns link vnet create \
         -g "$AZURE_RG" -z "$PG_DNS_ZONE" \
         -n "$DNS_LINK_NAME" \
         --virtual-network "$VNET_NAME" \
         --registration-enabled false \
         --output none
       ok "DNS VNet link created"
     fi

     # Create DNS zone group on the Private Endpoint (auto-registers A record)
     if az network private-endpoint dns-zone-group show -g "$AZURE_RG" \
          --endpoint-name "$PG_PE_NAME" -n default &>/dev/null 2>&1; then
       ok "DNS zone group already configured"
     else
       az network private-endpoint dns-zone-group create \
         -g "$AZURE_RG" --endpoint-name "$PG_PE_NAME" \
         -n default \
         --private-dns-zone "$PG_DNS_ZONE" \
         --zone-name postgres \
         --output none
       ok "DNS zone group configured (A record auto-registered)"
     fi

     save_state PG_PE_NAME "$PG_PE_NAME"
   fi
   ```

3. **The `DATABASE_URL` does NOT change.** The Private Endpoint + Private DNS zone means the same FQDN (`${PG_NAME}.postgres.database.azure.com`) now resolves to the private IP inside the VNet. The connection string stays identical — DNS does the routing.

### Constraints
- Idempotent — every resource checks "already exists" before creating.
- The platform-managed path (no `--custom-vnet`) must not be affected at all.
- Do NOT modify the DATABASE_URL construction — the FQDN is unchanged, only the DNS resolution changes.
```

---

## Prompt 03 — Add Private Endpoint for Redis (upgrade to Standard)

```
You are modifying `deploy/azure-aca/acasetup.sh` to add a Private Endpoint for Redis when `--custom-vnet` is used. Redis Basic C0 does NOT support Private Link, so the VNet path must upgrade to Standard C0.

### Current state
- Step 1.7 creates Redis with `--sku Basic --vm-size c0`
- The `REDIS_URL` uses the public FQDN: `${REDIS_NAME}.redis.cache.windows.net`

### What to change

1. **In Step 1.7 (Redis creation)**, change the SKU based on VNet mode:
   ```bash
   if $CUSTOM_VNET; then
     REDIS_SKU="Standard"
     info "Step 1.7: Creating Azure Cache for Redis Standard C0 (~15 min)..."
     info "         (Standard required for Private Link — Basic does not support it)"
   else
     REDIS_SKU="Basic"
     info "Step 1.7: Creating Azure Cache for Redis Basic C0 (~15 min)..."
   fi
   ```
   Then use `--sku "$REDIS_SKU" --vm-size c0` in the `az redis create` command.
   Also add `--public-network-access Disabled` when `$CUSTOM_VNET` is true.

2. **Add a new Step 1.7b** immediately after Redis creation, only when `CUSTOM_VNET=true`:
   ```bash
   if $CUSTOM_VNET; then
     info "Step 1.7b: Creating Private Endpoint for Redis..."
     REDIS_PE_NAME="${REDIS_NAME}-pe"

     if az network private-endpoint show -g "$AZURE_RG" -n "$REDIS_PE_NAME" &>/dev/null; then
       ok "Private Endpoint $REDIS_PE_NAME already exists"
     else
       REDIS_RESOURCE_ID="$(az redis show -g "$AZURE_RG" -n "$REDIS_NAME" --query id -o tsv)"

       az network private-endpoint create \
         -g "$AZURE_RG" -n "$REDIS_PE_NAME" \
         -l "$AZURE_LOCATION" \
         --vnet-name "$VNET_NAME" \
         --subnet private-endpoints \
         --private-connection-resource-id "$REDIS_RESOURCE_ID" \
         --group-id redisCache \
         --connection-name "${REDIS_NAME}-connection" \
         --output none
       ok "Private Endpoint created for Redis"
     fi

     # Private DNS zone for Redis
     REDIS_DNS_ZONE="privatelink.redis.cache.windows.net"
     if az network private-dns zone show -g "$AZURE_RG" -n "$REDIS_DNS_ZONE" &>/dev/null; then
       ok "Private DNS zone $REDIS_DNS_ZONE already exists"
     else
       az network private-dns zone create -g "$AZURE_RG" -n "$REDIS_DNS_ZONE" --output none
       ok "Private DNS zone created"
     fi

     DNS_LINK_NAME="${VNET_NAME}-redis-dns-link"
     if az network private-dns link vnet show -g "$AZURE_RG" -z "$REDIS_DNS_ZONE" -n "$DNS_LINK_NAME" &>/dev/null; then
       ok "DNS VNet link already exists"
     else
       az network private-dns link vnet create \
         -g "$AZURE_RG" -z "$REDIS_DNS_ZONE" \
         -n "$DNS_LINK_NAME" \
         --virtual-network "$VNET_NAME" \
         --registration-enabled false \
         --output none
       ok "DNS VNet link created"
     fi

     if az network private-endpoint dns-zone-group show -g "$AZURE_RG" \
          --endpoint-name "$REDIS_PE_NAME" -n default &>/dev/null 2>&1; then
       ok "DNS zone group already configured"
     else
       az network private-endpoint dns-zone-group create \
         -g "$AZURE_RG" --endpoint-name "$REDIS_PE_NAME" \
         -n default \
         --private-dns-zone "$REDIS_DNS_ZONE" \
         --zone-name redis \
         --output none
       ok "DNS zone group configured"
     fi

     save_state REDIS_PE_NAME "$REDIS_PE_NAME"
   fi
   ```

3. **The `REDIS_URL` does NOT change.** Same rationale as Postgres — Private DNS resolves the same FQDN to a private IP.

4. **Update the Phase 1 completion summary** to indicate VNet mode:
   ```bash
   if $CUSTOM_VNET; then
     print_summary_box "Phase 1 Complete: Demo Foundation Ready (Custom VNet)" \
       ...existing fields... \
       "VNet:         $VNET_NAME" \
       "Redis SKU:    Standard C0 (Private Link enabled)" \
       "Private EP:   Postgres + Redis"
   else
     ...existing summary...
   fi
   ```

### Constraints
- Basic path unchanged — `--custom-vnet` not passed means Basic C0 and public endpoints exactly as before.
- Idempotent throughout.
- Note in the help text that `--custom-vnet` upgrades Redis from Basic to Standard (~$50/mo vs ~$16/mo increase).

### Cost note to add to help text
Add a line under the `--custom-vnet` help entry:
```
  --custom-vnet          Use a custom VNet with Private Endpoints and peering support
                         Note: upgrades Redis from Basic C0 (~$16/mo) to Standard C0 (~$50/mo)
                         for Private Link support. Total cost ~$100-120/mo vs ~$70-80/mo.
```
```

---

## Prompt 04 — Add VNet peering to an existing VNet in another resource group

```
You are modifying `deploy/azure-aca/acasetup.sh` to support VNet peering with an existing VNet in another resource group. This only applies when `--custom-vnet` is used.

### Current state
- After Prompts 01-03, when `--custom-vnet` is passed, a custom VNet `okta-adapter-vnet` exists with subnets `aca-infra` and `private-endpoints`, and Private Endpoints for Postgres and Redis.
- The wizard has no concept of peering today.

### What to change

1. **Add three new optional env vars** (also add to `.env.example`):
   ```
   # Optional — VNet Peering (only used with --custom-vnet)
   # Peer with an existing VNet in another resource group to reach backends there.
   # PEER_VNET_RESOURCE_ID=/subscriptions/SUB/resourceGroups/OTHER_RG/providers/Microsoft.Network/virtualNetworks/OTHER_VNET
   # PEER_NAME=hackathon-peer
   ```

2. **Add new CLI flags** `--peer-vnet` and `--peer-name`:
   ```
   --peer-vnet ID         Full resource ID of the VNet to peer with (requires --custom-vnet)
   --peer-name NAME       Peering name (default: adapter-to-remote)
   ```

   In the case block:
   ```bash
   --peer-vnet)     PEER_VNET_RESOURCE_ID="$2"; shift 2 ;;
   --peer-name)     PEER_NAME="$2"; shift 2 ;;
   ```

3. **Add Step 1.9b** after the ACA Environment creation, only when `CUSTOM_VNET=true` AND `PEER_VNET_RESOURCE_ID` is set:
   ```bash
   PEER_VNET_RESOURCE_ID="${PEER_VNET_RESOURCE_ID:-$(get_state PEER_VNET_RESOURCE_ID)}"
   if $CUSTOM_VNET && [[ -n "${PEER_VNET_RESOURCE_ID:-}" ]]; then
     info "Step 1.9b: Setting up VNet peering..."
     PEER_NAME="${PEER_NAME:-adapter-to-remote}"
     VNET_NAME="$(get_state VNET_NAME)"

     # Local → Remote peering
     LOCAL_PEER_NAME="${PEER_NAME}"
     if az network vnet peering show -g "$AZURE_RG" --vnet-name "$VNET_NAME" -n "$LOCAL_PEER_NAME" &>/dev/null; then
       ok "Local peering $LOCAL_PEER_NAME already exists"
     else
       az network vnet peering create \
         -g "$AZURE_RG" --vnet-name "$VNET_NAME" \
         -n "$LOCAL_PEER_NAME" \
         --remote-vnet "$PEER_VNET_RESOURCE_ID" \
         --allow-vnet-access true \
         --allow-forwarded-traffic true \
         --output none
       ok "Local → Remote peering created"
     fi

     # Remote → Local peering (requires permission on the remote VNet)
     # Extract remote RG and VNet name from the resource ID
     REMOTE_RG="$(echo "$PEER_VNET_RESOURCE_ID" | sed -n 's|.*/resourceGroups/\([^/]*\)/.*|\1|p')"
     REMOTE_VNET="$(echo "$PEER_VNET_RESOURCE_ID" | sed -n 's|.*/virtualNetworks/\(.*\)|\1|p')"
     REMOTE_PEER_NAME="remote-to-${VNET_NAME}"

     LOCAL_VNET_ID="$(az network vnet show -g "$AZURE_RG" -n "$VNET_NAME" --query id -o tsv)"

     if az network vnet peering show -g "$REMOTE_RG" --vnet-name "$REMOTE_VNET" -n "$REMOTE_PEER_NAME" &>/dev/null; then
       ok "Remote peering $REMOTE_PEER_NAME already exists"
     else
       az network vnet peering create \
         -g "$REMOTE_RG" --vnet-name "$REMOTE_VNET" \
         -n "$REMOTE_PEER_NAME" \
         --remote-vnet "$LOCAL_VNET_ID" \
         --allow-vnet-access true \
         --allow-forwarded-traffic true \
         --output none
       ok "Remote → Local peering created"
     fi

     save_state PEER_VNET_RESOURCE_ID "$PEER_VNET_RESOURCE_ID"
     save_state PEER_NAME "$PEER_NAME"

     # Verify peering state
     LOCAL_STATE="$(az network vnet peering show -g "$AZURE_RG" --vnet-name "$VNET_NAME" \
       -n "$LOCAL_PEER_NAME" --query peeringState -o tsv)"
     if [[ "$LOCAL_STATE" == "Connected" ]]; then
       ok "VNet peering is Connected"
     else
       warn "VNet peering state is $LOCAL_STATE (may take a moment to converge)"
     fi
   fi
   ```

4. **Add peering info to the Phase 1 completion summary** when peering was configured:
   ```bash
   if [[ -n "${PEER_VNET_RESOURCE_ID:-}" ]]; then
     # Add to the summary box:
     "Peered with:  $REMOTE_VNET (in RG $REMOTE_RG)"
   fi
   ```

5. **Link the remote VNet's Private DNS zones** so the remote VNet can also resolve the Private Endpoint FQDNs (optional but useful for bidirectional access):
   After peering is created, link both Private DNS zones to the remote VNet:
   ```bash
   for DNS_ZONE in "privatelink.postgres.database.azure.com" "privatelink.redis.cache.windows.net"; do
     REMOTE_LINK="remote-${REMOTE_VNET}-$(echo $DNS_ZONE | tr '.' '-')"
     if az network private-dns link vnet show -g "$AZURE_RG" -z "$DNS_ZONE" -n "$REMOTE_LINK" &>/dev/null; then
       ok "DNS link $REMOTE_LINK already exists"
     else
       az network private-dns link vnet create \
         -g "$AZURE_RG" -z "$DNS_ZONE" \
         -n "$REMOTE_LINK" \
         --virtual-network "$PEER_VNET_RESOURCE_ID" \
         --registration-enabled false \
         --output none
       ok "Linked $DNS_ZONE to remote VNet"
     fi
   done
   ```

### Important caveats to add as comments in the script
- The remote peering creation requires the current `az` identity to have `Network Contributor` (or equivalent) on the remote VNet's resource group. If it fails with 403, the remote RG owner needs to create the reverse peering manually.
- VNet address spaces must not overlap. The wizard defaults to `10.0.0.0/16` — if the remote VNet uses the same prefix, set `VNET_ADDRESS_PREFIX` to a non-overlapping range in `.env`.

### Constraints
- Do NOT run any peering steps when `--custom-vnet` is not passed.
- Do NOT run peering when `PEER_VNET_RESOURCE_ID` is empty (it's optional even in custom-vnet mode).
- Idempotent — every resource checks before creating.
- If the remote peering fails (403), warn but don't die — print instructions for manual creation.
```

---

## Prompt 05 — Update `--destroy` to clean up VNet resources

```
You are modifying the `--destroy` path in `deploy/azure-aca/acasetup.sh` to handle the new VNet resources.

### Current state
- `--destroy` deletes the entire resource group: `az group delete -g "$AZURE_RG" --yes --no-wait`
- This already handles VNet, subnets, Private Endpoints, and Private DNS zones inside the RG.
- But it does NOT clean up the **remote peering** created on the remote VNet.

### What to change

1. **Before deleting the resource group**, check if peering state exists and remove the remote-side peering:
   ```bash
   PEER_VNET_RESOURCE_ID="$(get_state PEER_VNET_RESOURCE_ID || true)"
   VNET_NAME="$(get_state VNET_NAME || true)"
   if [[ -n "$PEER_VNET_RESOURCE_ID" && -n "$VNET_NAME" ]]; then
     REMOTE_RG="$(echo "$PEER_VNET_RESOURCE_ID" | sed -n 's|.*/resourceGroups/\([^/]*\)/.*|\1|p')"
     REMOTE_VNET="$(echo "$PEER_VNET_RESOURCE_ID" | sed -n 's|.*/virtualNetworks/\(.*\)|\1|p')"
     REMOTE_PEER_NAME="remote-to-${VNET_NAME}"

     info "Removing remote VNet peering $REMOTE_PEER_NAME from $REMOTE_VNET..."
     if az network vnet peering delete -g "$REMOTE_RG" --vnet-name "$REMOTE_VNET" \
          -n "$REMOTE_PEER_NAME" --output none 2>/dev/null; then
       ok "Remote peering removed"
     else
       warn "Could not remove remote peering (may need manual cleanup in RG $REMOTE_RG)"
     fi

     # Remove DNS zone links to remote VNet
     for DNS_ZONE in "privatelink.postgres.database.azure.com" "privatelink.redis.cache.windows.net"; do
       REMOTE_LINK="remote-${REMOTE_VNET}-$(echo $DNS_ZONE | tr '.' '-')"
       az network private-dns link vnet delete -g "$AZURE_RG" -z "$DNS_ZONE" \
         -n "$REMOTE_LINK" --yes --output none 2>/dev/null || true
     done
     ok "DNS zone links to remote VNet cleaned up"
   fi
   ```

2. Then proceed with the existing `az group delete` which cleans up everything else.

### Constraints
- If peering state doesn't exist (platform-managed mode), skip silently.
- If remote peering deletion fails (403), warn but don't block the destroy.
- Keep the `--no-wait` on the group delete — it's a destructive operation the user already confirmed.
```

---

## Usage example for the hackathon

Once all 5 prompts are applied, the hackathon deployment command would look like:

```bash
./acasetup.sh --custom-vnet \
  --peer-vnet "/subscriptions/<THEIR_SUB>/resourceGroups/<THEIR_RG>/providers/Microsoft.Network/virtualNetworks/<THEIR_VNET>" \
  --peer-name hackathon-peer
```

This creates:
- Custom VNet `okta-adapter-vnet` (10.0.0.0/16) with `aca-infra` (/23) and `private-endpoints` (/24) subnets
- ACA Environment on the custom subnet
- Postgres with Private Endpoint (public access disabled)
- Redis Standard C0 with Private Endpoint (public access disabled)
- Bidirectional VNet peering to the hackathon team's VNet
- Private DNS zones linked to both VNets

Estimated cost: ~$100-120/mo (vs ~$70-80/mo for platform-managed) — the increase is Redis Standard C0.
