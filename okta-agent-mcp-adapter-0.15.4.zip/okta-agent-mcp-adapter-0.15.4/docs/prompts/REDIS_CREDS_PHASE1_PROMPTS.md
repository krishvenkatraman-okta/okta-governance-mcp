> **Historical (pre-v0.15.x):** Password-based admin login references in this document are obsolete. The adapter accepts only Okta OAuth access tokens — see [docs/OPERATIONS.md § Admin API Authentication](../OPERATIONS.md#admin-api-authentication).

# Redis Credential Provider — Phase 1 Implementation Prompts

**Feature:** Redis credential provider abstraction (eliminates static `REDIS_PASSWORD` for production deployments)
**Phase:** 1 of 4 — Provider seam, gated static fallback, no behavior change for existing deployments
**Prompt count:** 4 sequential prompts
**Test constraint:** All existing tests must continue passing after each prompt
**Audit constraint:** New auth-path code emits `REDIS_CREDENTIAL_*` audit events at every mint and refresh

---

## Phase Map

| #   | Prompt                                       | Creates / Modifies                                                                  | Est. Time |
| --- | -------------------------------------------- | ----------------------------------------------------------------------------------- | --------- |
| P01 | Provider abstraction + audit events          | `cache/redis_credentials.py`, `audit/events.py`                                     | 20 min    |
| P02 | Static provider with gated activation        | `cache/redis_credential_providers/static.py`, factory                               | 25 min    |
| P03 | Wire provider into RedisCacheProvider + bus  | `cache/redis_provider.py`, `resources/event_bus.py`, `cache/cache_service.py`, `app.py` | 35 min    |
| P04 | Backward compatibility tests + docs (CLAUDE.md, README.md, Valkey notes) | `tests/cache/test_redis_credential_*`, `.env.example`, `CLAUDE.md`, `README.md` | 30 min    |
| P05 | Cloud deployment templates (AWS ECS + Azure ACA) | `deploy/aws-ecs/main.tf`, `deploy/aws-ecs/README.md`, `deploy/azure-aca/bicep/modules/apps.bicep`, `deploy/azure-aca/README.md` | 20 min    |

**Total estimated time:** ~2h 10m of Claude Code execution.

---

## Prerequisites

- All existing 397+ tests passing on a clean working tree.
- `pyproject.toml` already lists `cachetools`, `redis`, `pydantic` v2.
- A working Docker Compose stack (Redis at `redis://:redis-secret@redis:6379` is the dev default).

---

## How to Execute

```bash
cd okta-agent-mcp-adapter

# For each prompt:
# 1. Paste the prompt verbatim into Claude Code
# 2. Wait for it to complete and show the test count
# 3. Verify the working tree is clean and the new files exist
# 4. git commit -m "redis-creds P0X: <one-line summary>"
# 5. /clear  (clear context for next prompt)
```

Do not skip the commit-between-prompts step. Each prompt assumes the previous one is committed.

---

# Phase 1: Provider Seam

---

## Prompt P01: Provider Abstraction and Audit Events

**Context:** Creates the `RedisCredentialProvider` abstract base class, the `RedisCredentials` named tuple, and the new audit event types. No provider implementations yet — this prompt is purely the contract.

**Prompt:**

````
Add the Redis credential provider abstraction to the Okta MCP Adapter.

Read the existing codebase, especially:
- okta_agent_proxy/cache/base.py (existing CacheProvider abstract pattern — match its style)
- okta_agent_proxy/cache/redis_provider.py (current Redis client construction; you are NOT modifying this in P01)
- okta_agent_proxy/audit/events.py (AuditEventType enum — append new values at the very end of the enum, after the existing event groups; also note the AuditSeverity enum defines INFO, WARNING, CRITICAL)
- okta_agent_proxy/audit/__init__.py (emit_audit_event signature: event_type, severity, resource_name, details, outcome)

Execute the following:

1. Create okta_agent_proxy/cache/redis_credential_providers/__init__.py with module docstring:
   "Redis credential provider implementations.

   Each provider produces fresh connection credentials on demand and declares
   when those credentials will expire. The cache code never sees a string
   password directly — it asks the provider via get_credentials().

   See docs/redis-credentials.md for the full design rationale and
   customer-review crib sheet."

2. Create okta_agent_proxy/cache/redis_credentials.py with the abstract contract.

   Module docstring:
   "Abstract Redis credential provider contract.

   The provider seam decouples the Redis connection layer from any specific
   credential source. Implementations live in cache/redis_credential_providers/
   and are selected at startup by the REDIS_AUTH_MODE environment variable.

   Phase 1 of the implementation only includes the abstract base, the
   RedisCredentials named tuple, the factory entry point, and the
   StaticPasswordProvider (gated). Cloud and dynamic providers ship in
   subsequent phases."

   Imports:
   - import datetime
   - import ssl
   - from abc import ABC, abstractmethod
   - from typing import NamedTuple, Optional

   Class RedisCredentials (typing.NamedTuple):
       username: Optional[str]              # None for AUTH-password-only mode
       password: Optional[str]              # None for mTLS
       expires_at: Optional[datetime.datetime]   # None for non-expiring (static, mTLS without rotation)
       ssl_context: Optional[ssl.SSLContext]     # populated for mTLS
       principal: str                       # IAM role ARN, managed identity OID, "static", etc. — for audit only

       def is_expiring(self) -> bool:
           """True when the credential has a known expiration."""
           return self.expires_at is not None

   Exception class CredentialUnavailableError(RuntimeError):
       """Raised when the provider cannot mint a credential (e.g. AWS creds chain empty,
       Entra IMDS unreachable, static gate not enabled). Adapter startup must fail."""

   Class RedisCredentialProvider(ABC):
       """Abstract base. Implementations live in redis_credential_providers/."""

       # Subclasses set this — used in audit events and logs.
       name: str = "abstract"

       @abstractmethod
       async def get_credentials(self) -> RedisCredentials:
           """Mint or fetch fresh credentials. Called on every Redis client
           construction — initial connect, reconnect after error, and the
           scheduled refresh ahead of expiry.

           Raises:
               CredentialUnavailableError: if the provider cannot produce a credential.
           """
           ...

       def refresh_safety_window(self) -> datetime.timedelta:
           """How far before expiry to refresh. Default is 25% of the credential's
           remaining lifetime, floored at 60 seconds. Subclasses with provider-specific
           guidance (AWS IAM = 2.5 min, Entra = 5 min) override this."""
           return datetime.timedelta(seconds=60)

       async def health_check(self) -> bool:
           """Returns True when the provider can mint credentials. Default
           implementation calls get_credentials() and treats success as healthy."""
           try:
               await self.get_credentials()
               return True
           except Exception:
               return False

   Function get_redis_credential_provider() -> RedisCredentialProvider:
       """Factory. Reads REDIS_AUTH_MODE from os.environ, instantiates the matching
       provider, and returns it.

       In Phase 1, only 'static' is supported. Future phases add aws-iam, azure-entra,
       mtls, and vault. Unknown modes raise ValueError listing the supported modes.

       Defaults to 'static' for backward compatibility, but the static provider itself
       refuses to start unless ALLOW_STATIC_REDIS_PASSWORD=true (see P02)."""
       import os
       mode = os.environ.get("REDIS_AUTH_MODE", "static").lower().strip()
       if mode == "static":
           from okta_agent_proxy.cache.redis_credential_providers.static import StaticPasswordProvider
           return StaticPasswordProvider.from_env()
       raise ValueError(
           f"Unsupported REDIS_AUTH_MODE: {mode!r}. "
           f"Phase 1 supports: static. Future phases will add aws-iam, azure-entra, mtls, vault."
       )

3. Add five new audit event types to okta_agent_proxy/audit/events.py.

   Append to the end of the AuditEventType class:

       # --- Redis credential lifecycle (Phase 1+) ---
       REDIS_CREDENTIAL_MINTED = "redis.credential.minted"
       REDIS_CREDENTIAL_REFRESH_SUCCESS = "redis.credential.refresh.success"
       REDIS_CREDENTIAL_REFRESH_FAILED = "redis.credential.refresh.failed"
       REDIS_AUTH_FAILURE = "redis.auth.failure"
       REDIS_STATIC_PASSWORD_USED = "redis.static_password.used"

   Do NOT modify any existing event values.

4. Create tests/cache/__init__.py (empty file, just for the test subdir).

5. Create tests/cache/test_redis_credential_provider_contract.py with the following tests
   (using pytest.mark.asyncio for async tests):

   - test_redis_credentials_is_expiring_true_when_expires_at_set
   - test_redis_credentials_is_expiring_false_when_none
   - test_credential_unavailable_error_is_runtime_error
   - test_provider_default_refresh_safety_window_is_60_seconds
   - test_provider_health_check_returns_true_when_get_credentials_succeeds
   - test_provider_health_check_returns_false_when_get_credentials_raises
   - test_factory_unknown_mode_raises_valueerror_listing_supported_modes
   - test_factory_default_mode_is_static (set REDIS_AUTH_MODE unset, monkeypatch the static loader to a stub)
   - test_factory_explicit_aws_iam_raises_valueerror_in_phase_1
   - test_audit_event_types_include_five_new_redis_events (assert all 5 strings present)

   For the health-check tests, define a tiny FakeProvider subclass inside the test module
   that overrides get_credentials.

   For the factory tests, monkeypatch
   okta_agent_proxy.cache.redis_credential_providers.static.StaticPasswordProvider.from_env
   to return a sentinel object — we are not testing static logic in this prompt.

6. Run: pytest tests/cache/test_redis_credential_provider_contract.py -v
   All 10 tests must pass.

7. Run the full existing suite: pytest tests/ -x -q
   Report the total test count and confirm no regressions.

8. Print the final test count and a one-line summary:
   "P01 complete: provider abstraction + 5 audit events + 10 contract tests. Total: <N> tests."
````

**Expected Output:**
- New files: `okta_agent_proxy/cache/redis_credentials.py`, `okta_agent_proxy/cache/redis_credential_providers/__init__.py`, `tests/cache/__init__.py`, `tests/cache/test_redis_credential_provider_contract.py`
- Modified files: `okta_agent_proxy/audit/events.py` (+5 event types appended)
- 10 new tests passing, full suite still green.

**Commit:** `redis-creds P01: provider abstraction + audit events`

---

## Prompt P02: StaticPasswordProvider with Gate Enforcement

**Context:** Implements the only Phase 1 provider — `StaticPasswordProvider`. It preserves the current behaviour (read `REDIS_PASSWORD` from env) but refuses to start unless `ALLOW_STATIC_REDIS_PASSWORD=true` is explicitly set. The gate is what customer reviewers grep for in production deployments.

**Prompt:**

````
Implement the StaticPasswordProvider for the Redis credential abstraction.

Read:
- okta_agent_proxy/cache/redis_credentials.py (created in P01 — RedisCredentials, RedisCredentialProvider, CredentialUnavailableError)
- okta_agent_proxy/cache/cache_service.py (existing REDIS_PASSWORD reading logic in create_from_env, lines 100-115 — you are NOT modifying this in P02; you replicate the parsing in the new provider)
- okta_agent_proxy/audit/__init__.py and audit/events.py (REDIS_STATIC_PASSWORD_USED added in P01)
- .env.example (current REDIS_* variable documentation)

Execute the following:

1. Create okta_agent_proxy/cache/redis_credential_providers/static.py.

   Module docstring:
   "Static-password Redis credential provider — DEV ONLY.

   Preserves the current REDIS_PASSWORD behaviour for local development with
   Docker Compose. Refuses to start unless ALLOW_STATIC_REDIS_PASSWORD=true is
   explicitly set.

   This module is gated because static, long-lived Redis passwords fail
   customer security review. The gate itself is the deliverable evidence:
   production deployments will not have
   ALLOW_STATIC_REDIS_PASSWORD set, and any startup that reaches this code
   path will emit a CRITICAL-severity REDIS_STATIC_PASSWORD_USED audit event."

   Imports:
   - import asyncio
   - import logging
   - import os
   - from typing import Optional
   - from okta_agent_proxy.cache.redis_credentials import (
         RedisCredentialProvider, RedisCredentials, CredentialUnavailableError
     )

   Module-level logger.

   Constants:
       GATE_ENV = "ALLOW_STATIC_REDIS_PASSWORD"
       PASSWORD_ENV = "REDIS_PASSWORD"
       USERNAME_ENV = "REDIS_USERNAME"  # optional — Redis 6+ ACL user

   Class StaticPasswordProvider(RedisCredentialProvider):
       name = "static"

       def __init__(self, username: Optional[str], password: Optional[str]):
           self._username = username
           self._password = password
           self._audit_emitted = False  # one-shot per process

       @classmethod
       def from_env(cls) -> "StaticPasswordProvider":
           """Construct from environment, enforcing the gate.

           Raises:
               CredentialUnavailableError: if ALLOW_STATIC_REDIS_PASSWORD is not
                   exactly the string 'true' (case-insensitive). The error message
                   names the supported alternative providers."""
           gate = os.environ.get(cls._gate_env_name(), "").strip().lower()
           if gate != "true":
               raise CredentialUnavailableError(
                   f"REDIS_AUTH_MODE=static requires {cls._gate_env_name()}=true. "
                   f"Static Redis passwords are not permitted in production. "
                   f"Set REDIS_AUTH_MODE=aws-iam, azure-entra, mtls, or vault for "
                   f"production deployments."
               )
           username = os.environ.get(USERNAME_ENV) or None
           password = os.environ.get(PASSWORD_ENV) or None
           # password may legitimately be None for an unauthenticated dev Redis,
           # but log a warning so it's visible in startup logs.
           if not password:
               logger.warning(
                   "[redis-creds:static] %s is empty — connecting without AUTH. "
                   "This is acceptable only for local dev Redis with no requirepass.",
                   PASSWORD_ENV,
               )
           return cls(username=username, password=password)

       @staticmethod
       def _gate_env_name() -> str:
           # Indirection for tests that monkeypatch the gate name.
           return GATE_ENV

       async def get_credentials(self) -> RedisCredentials:
           # First call emits the audit event, subsequent calls are silent.
           if not self._audit_emitted:
               self._audit_emitted = True
               self._log_loud_warning()
               await self._emit_static_used_audit()
           return RedisCredentials(
               username=self._username,
               password=self._password,
               expires_at=None,
               ssl_context=None,
               principal="static",
           )

       def _log_loud_warning(self):
           bar = "=" * 72
           logger.warning(bar)
           logger.warning("REDIS AUTH: USING STATIC PASSWORD MODE — NOT FOR PRODUCTION")
           logger.warning("Set REDIS_AUTH_MODE=aws-iam | azure-entra | mtls | vault")
           logger.warning("for production.")
           logger.warning(bar)

       async def _emit_static_used_audit(self):
           # Lazy import to avoid circular dependency at module load time.
           try:
               from okta_agent_proxy.audit import emit_audit_event
               from okta_agent_proxy.audit.events import AuditEventType, AuditSeverity
               await emit_audit_event(
                   AuditEventType.REDIS_STATIC_PASSWORD_USED,
                   AuditSeverity.CRITICAL,
                   resource_name="redis",
                   details={
                       "provider": self.name,
                       "username_set": self._username is not None,
                       "password_set": self._password is not None,
                   },
                   outcome="warning",
               )
           except Exception as e:
               # Audit failure must not prevent startup — log and continue.
               logger.warning(
                   "[redis-creds:static] could not emit REDIS_STATIC_PASSWORD_USED audit event: %s",
                   e,
               )

2. Update okta_agent_proxy/cache/redis_credentials.py — replace the lazy import block
   in get_redis_credential_provider() to use the now-real StaticPasswordProvider.from_env.
   The factory body should remain functionally identical; only the import is now
   guaranteed to resolve.

3. Create tests/cache/test_static_password_provider.py with tests:

   - test_from_env_raises_when_gate_unset
     (monkeypatch.delenv ALLOW_STATIC_REDIS_PASSWORD, expect CredentialUnavailableError,
      assert error message names aws-iam, azure-entra, mtls, vault)
   - test_from_env_raises_when_gate_is_false (set to "false" — must reject)
   - test_from_env_raises_when_gate_is_anything_other_than_true (e.g. "1", "yes")
   - test_from_env_succeeds_with_gate_true_lowercase
   - test_from_env_succeeds_with_gate_true_uppercase ("TRUE")
   - test_from_env_succeeds_with_gate_true_padded ("  true  ")
   - test_from_env_warns_when_password_empty (capture caplog)
   - test_from_env_picks_up_username_when_set
   - test_get_credentials_returns_static_principal
   - test_get_credentials_returns_expires_at_none
   - test_get_credentials_emits_audit_only_on_first_call
     (mock the audit emit_audit_event, call get_credentials twice,
      assert emit_audit_event called exactly once)
   - test_get_credentials_emits_critical_severity_event
   - test_get_credentials_does_not_raise_when_audit_emit_fails
     (monkeypatch emit_audit_event to raise, assert get_credentials still returns)
   - test_loud_warning_logged_on_first_call (assert caplog contains "NOT FOR PRODUCTION")

   Use pytest's monkeypatch fixture for env vars and caplog for log capture.
   Use unittest.mock.AsyncMock for the audit emit patch.

4. Run: pytest tests/cache/test_static_password_provider.py -v
   All 14 tests must pass.

5. Run the full existing suite: pytest tests/ -x -q
   No regressions allowed. Existing tests don't touch ALLOW_STATIC_REDIS_PASSWORD,
   so they should not be affected (the static provider is constructed lazily by
   the factory which isn't called in any existing test path yet — that's P03).

6. Print the final test count and a one-line summary:
   "P02 complete: StaticPasswordProvider with gate enforcement + 14 tests. Total: <N> tests."
````

**Expected Output:**
- New file: `okta_agent_proxy/cache/redis_credential_providers/static.py`
- New file: `tests/cache/test_static_password_provider.py`
- Modified: `okta_agent_proxy/cache/redis_credentials.py` (factory import resolved)
- 14 new tests passing, full suite still green.

**Commit:** `redis-creds P02: StaticPasswordProvider with ALLOW_STATIC_REDIS_PASSWORD gate`

---

## Prompt P03: Wire Provider into Connection Layer

**Context:** This is the largest prompt — it threads the provider through `RedisCacheProvider`, `CacheEventBus`, `CacheService.create_from_env`, and `app.py`. The behaviour-preserving requirement is that an existing deployment with `REDIS_PASSWORD=secret` and `CACHE_PROVIDER=redis` continues to work after this change *if and only if* the operator also sets `ALLOW_STATIC_REDIS_PASSWORD=true`. Without the gate, the adapter refuses to start — by design.

**Prompt:**

````
Wire the Redis credential provider into the connection layer.

Read:
- okta_agent_proxy/cache/redis_provider.py (current RedisCacheProvider — takes redis_url with embedded password)
- okta_agent_proxy/cache/cache_service.py (CacheService.create_from_env — currently does the URL+password concatenation at lines 100-115)
- okta_agent_proxy/resources/event_bus.py (CacheEventBus.start at lines 69-95 — independently creates a Redis client from a URL string)
- okta_agent_proxy/app.py (lines 80-90 wire CacheService and event bus at startup)
- okta_agent_proxy/cache/redis_credentials.py (P01 contract)
- okta_agent_proxy/cache/redis_credential_providers/static.py (P02 implementation)

The goal: every place that constructs a Redis client now goes through the credential
provider seam. After this prompt, no code reads REDIS_PASSWORD directly — only the
StaticPasswordProvider does, and only inside its from_env() classmethod.

Execute the following:

1. Modify okta_agent_proxy/cache/redis_provider.py.

   Change RedisCacheProvider.__init__ signature to accept either a URL with
   embedded credentials (legacy) or a host+credential_provider pair (new):

       def __init__(
           self,
           redis_url: str,
           key_prefix: str = "okta-mcp:",
           default_ttl: int = 3600,
           ssl: bool = False,
           credential_provider: Optional["RedisCredentialProvider"] = None,
       ):
           self._key_prefix = key_prefix
           self._default_ttl = default_ttl
           self._redis_url = redis_url  # may or may not have credentials embedded
           self._ssl = ssl
           self._credential_provider = credential_provider
           self._clients: dict[int, object] = {}
           self._init_failed = False
           # ...existing logger.info...

   In _get_redis(), insert the block below AFTER `loop_id = id(loop)` (so
   `loop_id` is in scope for the per-loop mint tracker) and the existing
   kwargs block, but BEFORE the `aioredis.from_url(url, **kwargs)` call:

       if self._credential_provider is not None:
           # Provider mode — strip any embedded credentials from the URL and
           # supply username/password as connection kwargs. This ensures the
           # provider is the single source of truth.
           creds = await self._credential_provider.get_credentials()
           if creds.username:
               kwargs["username"] = creds.username
           if creds.password:
               kwargs["password"] = creds.password
           if creds.ssl_context is not None:
               kwargs["ssl"] = True
               # redis-py honors ssl_certfile/ssl_keyfile/ssl_ca_certs;
               # full mTLS wiring lands in Phase 3. For now, we only need
               # to support static (no SSLContext) — record this is a no-op.
           # Strip any "user:pass@" from the URL so they don't conflict with kwargs.
           url = self._strip_url_credentials(url)
           # Emit audit on first mint per loop.
           if loop_id not in self._minted_loops:
               self._minted_loops.add(loop_id)
               await self._emit_mint_audit(creds)

   Add as a new method on RedisCacheProvider:

       @staticmethod
       def _strip_url_credentials(url: str) -> str:
           """Remove any embedded user:pass@ from a redis(s):// URL."""
           from urllib.parse import urlparse, urlunparse
           parsed = urlparse(url)
           if parsed.username or parsed.password:
               netloc = parsed.hostname or ""
               if parsed.port:
                   netloc = f"{netloc}:{parsed.port}"
               parsed = parsed._replace(netloc=netloc)
               return urlunparse(parsed)
           return url

       async def _emit_mint_audit(self, creds):
           try:
               from okta_agent_proxy.audit import emit_audit_event
               from okta_agent_proxy.audit.events import AuditEventType, AuditSeverity
               await emit_audit_event(
                   AuditEventType.REDIS_CREDENTIAL_MINTED,
                   AuditSeverity.INFO,
                   resource_name="redis",
                   details={
                       "provider": self._credential_provider.name,
                       "principal": creds.principal,
                       "expires_at": creds.expires_at.isoformat() if creds.expires_at else None,
                       "username_set": creds.username is not None,
                   },
                   outcome="success",
               )
           except Exception as e:
               logger.warning(f"[redis-creds] mint audit emission failed: {e}")

   Add `self._minted_loops: set[int] = set()` to __init__ alongside _clients.

2. Modify okta_agent_proxy/cache/cache_service.py.

   Replace CacheService.create_from_env() so it builds the credential provider
   first, then passes it into RedisCacheProvider. Remove the inline
   REDIS_PASSWORD reading and URL-rewriting block entirely.

   New body of create_from_env:

       @classmethod
       def create_from_env(cls) -> "CacheService":
           provider = os.getenv("CACHE_PROVIDER", "memory").lower()
           redis_url = os.getenv("REDIS_URL")

           if provider == "redis" or redis_url:
               from .redis_provider import RedisCacheProvider
               from .redis_credentials import get_redis_credential_provider

               url = redis_url or "redis://localhost:6379"
               key_prefix = os.getenv("REDIS_KEY_PREFIX", "okta-mcp:")
               ssl = os.getenv("REDIS_TLS_ENABLED", "false").lower() == "true"

               credential_provider = get_redis_credential_provider()
               # Note: from_env() may raise CredentialUnavailableError if the
               # gate is not set for static mode. We deliberately let that
               # propagate to fail-fast at startup rather than silently
               # falling back to memory.

               l2 = RedisCacheProvider(
                   redis_url=url,
                   key_prefix=key_prefix,
                   default_ttl=3600,
                   ssl=ssl,
                   credential_provider=credential_provider,
               )
           else:
               l2 = MemoryCacheProvider(max_size=10000, default_ttl=3600)

           return cls(l2_provider=l2)

   Also update the `create()` classmethod to take an optional credential_provider
   and pass it through. Default to None (legacy URL-only path) for any callers
   that haven't migrated yet.

3. Modify okta_agent_proxy/resources/event_bus.py.

   IMPORTANT — there are two classes named `CacheEventBus` in the codebase:

   (a) `okta_agent_proxy.cache.pubsub.CacheEventBus` — constructed in
       app.py as `event_bus = CacheEventBus(cache_service)` (signature:
       `__init__(self, cache_service)`). It reuses
       `RedisCacheProvider._get_redis()` for its pub/sub client, so it
       INHERITS the credential provider from the cache layer automatically.
       DO NOT add a credential_provider parameter here — it would change
       the public signature unnecessarily, and `_get_redis()` already
       flows provider credentials through.

   (b) `okta_agent_proxy.resources.event_bus.CacheEventBus` (imported as
       `ResourceMapEventBus` in app.py) — constructs its own Redis client
       from `_redis_url` at start() time. This one does NOT share the
       cache provider's client, so it NEEDS the credential_provider.
       This step modifies only (b).

   Add a credential_provider parameter to `resources.event_bus.CacheEventBus.__init__`
   (default None). In start(), if credential_provider is set, follow the
   same pattern as RedisCacheProvider: strip URL credentials, fetch from
   provider, pass username/password as kwargs to aioredis.from_url.

   Refactor the redis client construction in start() into a helper:

       async def _build_redis_client(self):
           import redis.asyncio as aioredis
           kwargs = {"decode_responses": True}
           url = self._redis_url
           if url and url.startswith("rediss://"):
               kwargs["ssl_cert_reqs"] = "none"
           if self._credential_provider is not None:
               creds = await self._credential_provider.get_credentials()
               if creds.username:
                   kwargs["username"] = creds.username
               if creds.password:
                   kwargs["password"] = creds.password
               url = self._strip_url_credentials(url)
           return aioredis.from_url(url, **kwargs)

       @staticmethod
       def _strip_url_credentials(url: str) -> str:
           from urllib.parse import urlparse, urlunparse
           parsed = urlparse(url)
           if parsed.username or parsed.password:
               netloc = parsed.hostname or ""
               if parsed.port:
                   netloc = f"{netloc}:{parsed.port}"
               parsed = parsed._replace(netloc=netloc)
               return urlunparse(parsed)
           return url

   Use _build_redis_client in start(); replace the existing inline aioredis.from_url call.

4. Modify okta_agent_proxy/app.py.

   The CacheService and the ResourceMapEventBus must share a single
   credential_provider instance so audit events show one mint per process
   rather than one per Redis connection point. The pubsub `CacheEventBus`
   does NOT need the provider threaded through it — it reuses the cache
   provider's client (see step 3 (a) above).

   At app.py before `cache_service = CacheService.create_from_env()` (currently
   line 85; find the line symbolically rather than trusting the number), insert:

       # --- Redis credential provider (Phase 1) ---
       # Built once and shared between CacheService and ResourceMapEventBus
       # so we mint credentials once per process rather than once per Redis
       # connection point. The pubsub CacheEventBus inherits provider
       # credentials via RedisCacheProvider._get_redis() — no extra wiring
       # needed there.
       _redis_credential_provider = None
       _cache_provider_env = os.getenv("CACHE_PROVIDER", "memory").lower()
       if _cache_provider_env == "redis" or os.getenv("REDIS_URL"):
           from okta_agent_proxy.cache.redis_credentials import get_redis_credential_provider
           _redis_credential_provider = get_redis_credential_provider()
           logger.info(
               f"Redis credential provider: {_redis_credential_provider.name}"
           )

   Refactor `CacheService.create_from_env` to accept an optional provider,
   defaulting to the factory when not supplied:

       @classmethod
       def create_from_env(cls, credential_provider=None) -> "CacheService":
           ...
           credential_provider = credential_provider or get_redis_credential_provider()
           ...

   Pass `credential_provider=_redis_credential_provider` from app.py.

   Then find the `ResourceMapEventBus(...)` construction in app.py (currently
   around line 184 — it takes `redis_url=...` today). Pass
   `credential_provider=_redis_credential_provider` into that constructor call.

   DO NOT modify the `event_bus = CacheEventBus(cache_service)` call
   (currently line 268). That is the pubsub bus; its signature is
   `__init__(self, cache_service)` and it already inherits provider
   credentials through `RedisCacheProvider._get_redis()`. Adding a
   `credential_provider` kwarg there would TypeError.

5. Update tests that currently set REDIS_PASSWORD directly. Run:

       grep -rn "REDIS_PASSWORD\|redis_password" tests/

   On current main this grep returns zero hits — proceed with no changes.
   The step is retained for future-proofing: if any test starts setting
   REDIS_PASSWORD as a precondition, also set ALLOW_STATIC_REDIS_PASSWORD=true
   via monkeypatch. Do NOT widen the gate's default. Most existing tests
   use the in-memory cache provider so they are unaffected.

6. Add tests/cache/test_redis_provider_with_credential_provider.py:

   - test_redis_provider_strips_url_credentials_when_provider_set
     (construct RedisCacheProvider with redis://user:pass@host:6379 and a fake provider,
      assert _strip_url_credentials returns redis://host:6379)
   - test_redis_provider_passes_username_password_from_provider_to_aioredis
     (use unittest.mock to capture aioredis.from_url kwargs)
   - test_redis_provider_emits_mint_audit_on_first_get_redis
     (mock emit_audit_event, call get and verify REDIS_CREDENTIAL_MINTED was emitted exactly once)
   - test_redis_provider_does_not_re_emit_mint_audit_on_subsequent_calls
   - test_redis_provider_legacy_url_only_still_works (no provider param — backward compat)
   - test_event_bus_strips_url_credentials_when_provider_set
   - test_event_bus_passes_username_password_from_provider

   Use a FakeProvider subclass of RedisCredentialProvider that returns a known
   RedisCredentials tuple. Mock the actual aioredis import.

7. Run: pytest tests/cache/test_redis_provider_with_credential_provider.py -v
   All 7 tests must pass.

8. Run the full suite: pytest tests/ -x -q

   If any existing test fails, the most likely cause is a Redis-touching test that
   didn't get its monkeypatch updated in step 5. Diagnose and fix.

9. Update docker-compose.yml adapter service env.

   The adapter service in docker-compose.yml currently reads the Redis
   password from the embedded URL only (`REDIS_URL:
   redis://:${REDIS_PASSWORD:-redis-secret}@redis:6379/0`). After this
   prompt's `_strip_url_credentials` lands, the URL password is stripped
   before the client is built, and `StaticPasswordProvider.from_env()`
   reads `REDIS_PASSWORD` from the adapter's own process env — which is
   not currently set on the adapter service. Without this step the
   adapter will attempt to connect with no password and fail NOAUTH.

   Add two entries to the adapter service `environment` block in
   docker-compose.yml (mark clearly as dev-only):

       environment:
         # ... existing entries ...
         # Phase 1 Redis credential provider (dev-only)
         ALLOW_STATIC_REDIS_PASSWORD: "true"
         REDIS_PASSWORD: ${REDIS_PASSWORD:-redis-secret}

10. Smoke test the actual Docker Compose stack:

    docker-compose down -v
    docker-compose up -d
    sleep 5
    curl -sf http://localhost:8000/health || echo "HEALTH FAIL"
    docker-compose logs okta-mcp-adapter | grep -E "REDIS|credential|mint" | head -20

    The logs MUST contain:
    - "Redis credential provider: static"
    - The four-line "USING STATIC PASSWORD MODE" warning banner
    - One line containing "REDIS_CREDENTIAL_MINTED" or the audit event JSON

    Now temporarily remove `ALLOW_STATIC_REDIS_PASSWORD` from the adapter
    env in docker-compose.yml (comment out the line) and re-run:

      docker-compose down -v
      docker-compose up -d
      sleep 5

    This time the adapter MUST refuse to start. Check logs for the
    CredentialUnavailableError message that names the gate. Restore the
    line after confirming. Document smoke test results in the prompt
    completion summary.

11. Print the final test count and a one-line summary:
    "P03 complete: provider seam wired through cache + event bus. Total: <N> tests."
````

**Expected Output:**
- Modified: `cache/redis_provider.py`, `cache/cache_service.py`, `resources/event_bus.py`, `app.py`, `docker-compose.yml`
- New file: `tests/cache/test_redis_provider_with_credential_provider.py` (7 tests)
- Updated test files that previously set `REDIS_PASSWORD` (expected: none on current main)
- Smoke test confirms gate enforcement works end-to-end.

**Commit:** `redis-creds P03: wire credential provider through cache + event bus`

---

## Prompt P04: Backward Compat, Documentation, and .env Template

**Context:** Phase 1 closes with four things: a backward-compatibility test matrix that proves we haven't broken any existing deployment shape, an updated `.env.example` that documents the gate, a `CLAUDE.md` section describing the new seam (with Valkey compatibility matrix), and a `README.md` quick reference so customer security teams can find the answer without reading source.

**Prompt:**

````
Finalize Phase 1 of the Redis credential provider with backward-compat tests and documentation.

Read:
- .env.example (current REDIS_* documentation)
- CLAUDE.md (project guide — add a new "Redis Credential Providers" section near the existing Cache section)
- README.md (project README — add a Redis credential provider quick reference after the existing caching section)
- All files modified/created in P01-P03

Execute the following:

1. Update .env.example.

   Replace the existing Redis section (currently "REDIS_PASSWORD=redis-secret" etc.)
   with a more explicit one. Keep alphabetical/logical ordering with the rest of the file.

       # ============================================================
       # REDIS
       # ============================================================
       # Cache provider: 'redis' (default, matches docker-compose) or 'memory'.
       # Change to 'memory' to skip the Redis dependency entirely.
       CACHE_PROVIDER=redis

       # Redis connection URL (used by both cache and pub/sub).
       # Do NOT embed username:password in the URL when using REDIS_AUTH_MODE
       # other than 'static' — credentials are supplied by the provider.
       # For local dev with the bundled docker-compose Redis, leave the
       # embedded password as shown below; the static provider will also
       # read REDIS_PASSWORD from env to populate AUTH kwargs after the
       # URL is stripped.
       REDIS_URL=redis://:${REDIS_PASSWORD:-redis-secret}@redis:6379/0

       # Key prefix for all Redis keys (useful for shared Redis instances).
       REDIS_KEY_PREFIX=okta-mcp:

       # Enable TLS for Redis connections (set to "true" for managed Redis services).
       REDIS_TLS_ENABLED=false

       # ------------------------------------------------------------
       # REDIS CREDENTIAL PROVIDER (Phase 1: 'static' only)
       # ------------------------------------------------------------
       # Selects how the adapter authenticates to Redis. Future phases will add:
       #   aws-iam      — AWS ElastiCache IAM (SigV4, 15-min token)
       #   azure-entra  — Azure Managed Redis with Entra ID (~1-hr token)
       #   mtls         — X.509 client cert (self-hosted Redis 6+)
       #   vault        — HashiCorp Vault Redis secrets engine
       #
       # In Phase 1 only 'static' is implemented. Static mode requires the
       # ALLOW_STATIC_REDIS_PASSWORD gate below — without it, the adapter
       # refuses to start. This is intentional: production deployments must
       # not use static passwords.
       REDIS_AUTH_MODE=static

       # GATE: required for REDIS_AUTH_MODE=static.
       # Production deployments MUST NOT set this to 'true'. The gate exists
       # so security reviewers can grep their deployment manifests as proof
       # that static-password mode is not in use.
       # ALLOW_STATIC_REDIS_PASSWORD=true

       # Static Redis credentials (only consumed when REDIS_AUTH_MODE=static
       # and ALLOW_STATIC_REDIS_PASSWORD=true).
       # REDIS_USERNAME=
       REDIS_PASSWORD=redis-secret

   Verify the docker-compose.yml (and docker-compose.examples.yml) still works
   with these defaults. P03 step 9 should have already added
       ALLOW_STATIC_REDIS_PASSWORD: "true"
       REDIS_PASSWORD: ${REDIS_PASSWORD:-redis-secret}
   to the adapter service env. If not, add them here (with a comment that
   this is dev-only). Do NOT change CACHE_PROVIDER's default — it stays
   'redis' to match compose and avoid breaking existing onboarding.

2. Add a "Redis Credential Providers" section to CLAUDE.md.

   Insert it after the existing "Caching Architecture" section. The section
   should cover:

       ## Redis Credential Providers (Phase 1)

       The adapter authenticates to Redis through a pluggable credential
       provider abstraction (`okta_agent_proxy/cache/redis_credentials.py`).
       This decouples the connection layer from any specific credential
       source — customers rejected the static-password pattern, and this seam
       lets us add IAM/Entra/mTLS/Vault providers without touching the
       cache code.

       ### Phase 1 contents

       | File                                                       | Purpose                                |
       | ---------------------------------------------------------- | -------------------------------------- |
       | cache/redis_credentials.py                                 | Abstract base, factory, named tuple   |
       | cache/redis_credential_providers/static.py                 | Gated static-password provider        |
       | cache/redis_provider.py                                    | Calls provider on every connect       |
       | resources/event_bus.py                                     | Calls provider on pub/sub connect     |

       ### Selecting a provider

       Set `REDIS_AUTH_MODE` in env. Phase 1 supports `static` only; Phase 2
       adds `aws-iam` and `azure-entra`; Phase 3 adds `mtls` and `vault`.

       ### The static gate

       `static` mode requires `ALLOW_STATIC_REDIS_PASSWORD=true`. Without it,
       the adapter raises `CredentialUnavailableError` at startup. This
       gate is the customer-review deliverable: production manifests should not
       contain it. When it IS set, every startup emits a CRITICAL-severity
       `REDIS_STATIC_PASSWORD_USED` audit event.

       ### Audit events (5 new)

       - `redis.credential.minted` — provider produced a credential
       - `redis.credential.refresh.success` — scheduled refresh succeeded
       - `redis.credential.refresh.failed` — provider could not mint
       - `redis.auth.failure` — Redis rejected our credential (post-mint)
       - `redis.static_password.used` — static gate was enabled at startup

       ### Adding a new provider (for future phases)

       1. Subclass `RedisCredentialProvider` in
          `cache/redis_credential_providers/<name>.py`.
       2. Implement `get_credentials()` — return `RedisCredentials` with a
          principal string for audit.
       3. Override `refresh_safety_window()` if your token TTL has
          provider-specific guidance.
       4. Add a `from_env()` classmethod for factory construction.
       5. Wire into the factory in `redis_credentials.py`.
       6. Add unit tests under `tests/cache/`.
       7. Add cloud deployment template updates under `deploy/`.

       ### Valkey compatibility

       The adapter uses standard `redis://` / `rediss://` wire protocol
       (RESP2/RESP3) via the `redis-py` client. This means **Valkey is
       supported transparently with no code changes** — Valkey is the
       Linux Foundation fork of Redis 7.2.4 (BSD-licensed) and is
       wire-compatible with all standard Redis commands the adapter uses
       (GET, SET, DEL, EXPIRE, SCAN, pub/sub).

       Tested deployment combinations:

       | Server                            | Status      | Notes                                 |
       | --------------------------------- | ----------- | ------------------------------------- |
       | Redis OSS 7.0+                    | Supported   | Original target                       |
       | Redis Community Edition 7.4+      | Supported   | SSPL/RSALv2 license — customers may ban |
       | Valkey 7.2+ (self-hosted)         | Supported   | BSD-licensed, drop-in replacement     |
       | Valkey 8.0+ (self-hosted)         | Supported   | Multi-threaded I/O, ~30% faster       |
       | AWS ElastiCache for Redis 7.0+    | Supported   | IAM auth in Phase 2                   |
       | AWS ElastiCache for Valkey 7.2+   | Supported   | IAM auth identical to Redis ElastiCache; default for new ElastiCache deployments |
       | Azure Managed Redis               | Supported   | Entra ID auth in Phase 2              |
       | Azure Cache for Redis (Standard+) | Supported   | Entra ID auth in Phase 2              |
       | GCP Memorystore for Valkey        | Supported   | GCP IAM provider on Phase 4 backlog   |

       **Why this matters for customer conversations:** Some customers have
       policies that prohibit SSPL/RSALv2-licensed components in
       production. For those customers, Valkey is the required server
       choice. The Phase 1 credential provider seam works with a Valkey
       **server** out of the box because the adapter uses the standard
       `redis-py` client (`import redis.asyncio as aioredis`) and only
       the RESP wire protocol and Redis commands the adapter relies on
       (GET, SET, DEL, EXPIRE, SCAN, pub/sub) — all of which Valkey
       implements identically. Swapping the **client library** from
       `redis-py` to `valkey-py` is not currently supported or tested;
       stick with `redis-py` against either server.

       **Local dev with Valkey:** swap the image in `docker-compose.yml`:

           # Before
           image: redis:7-alpine
           # After (drop-in)
           image: valkey/valkey:8-alpine

       All Phase 1 tests pass against either server.

3. Add a Redis credential provider section to README.md.

   Read the current README.md and locate the existing Redis or caching
   section (search for "REDIS_URL", "Redis cache", or "Caching"). Add the
   following block immediately after that section, before the next
   top-level heading.

       ## Redis Credential Providers

       The adapter authenticates to Redis through a pluggable credential
       provider rather than reading a static password from environment.
       This is required for deployments that fail security review on
       long-lived shared secrets (regulated industries, SOC 2, PCI-DSS).

       ### Quick reference

       | `REDIS_AUTH_MODE` | Use case                                    | Phase |
       | ----------------- | ------------------------------------------- | ----- |
       | `static`          | Local development with Docker Compose       | 1 ✅   |
       | `aws-iam`         | AWS ElastiCache (Redis 7+ or Valkey)       | 2     |
       | `azure-entra`     | Azure Managed Redis with Entra ID          | 2     |
       | `mtls`            | Self-hosted Redis/Valkey with X.509 client | 3     |
       | `vault`           | HashiCorp Vault Redis secrets engine        | 3     |

       ### Local development

       For Docker Compose and local testing only:

           REDIS_AUTH_MODE=static
           ALLOW_STATIC_REDIS_PASSWORD=true
           REDIS_PASSWORD=redis-secret

       The `ALLOW_STATIC_REDIS_PASSWORD=true` gate is mandatory — the
       adapter refuses to start in static mode without it. This is
       intentional: production deployments should not have this variable
       set.

       ### Production

       Phase 2 (planned) ships AWS IAM and Azure Entra ID providers.
       Until then, production deployments either use the static path
       (with the gate, accepting the security finding) or wait for
       Phase 2.

       ### Valkey support

       Valkey is the BSD-licensed Linux Foundation fork of Redis. The
       adapter supports Valkey transparently — point `REDIS_URL` at a
       Valkey endpoint and everything works. Both AWS ElastiCache for
       Valkey and self-hosted Valkey are tested. See `CLAUDE.md` for the
       full deployment compatibility matrix.

   Verify the placement: the new section should not interrupt an
   existing flow (e.g. a quick-start that currently mentions
   `REDIS_PASSWORD` should be updated to mention the gate as well).
   Check for and update any other README references to Redis credentials
   that are now obsolete.

4. Create tests/cache/test_redis_credential_provider_compat.py.

   This is the backward-compatibility matrix. Each test sets a specific
   environment shape and asserts the right outcome.

   - test_default_env_uses_memory_cache_no_provider_constructed
     (CACHE_PROVIDER unset, REDIS_URL unset → MemoryCacheProvider, no provider)

   - test_legacy_compose_with_gate_works
     (CACHE_PROVIDER=redis, REDIS_URL=redis://redis:6379, REDIS_PASSWORD=foo,
      ALLOW_STATIC_REDIS_PASSWORD=true → succeeds, provider name="static")

   - test_legacy_compose_without_gate_raises
     (same as above but without ALLOW_STATIC_REDIS_PASSWORD →
      CredentialUnavailableError)

   - test_redis_url_with_embedded_password_is_stripped_when_provider_set
     (redis://x:y@host:6379 + ALLOW_STATIC_REDIS_PASSWORD=true → URL passed
      to aioredis is redis://host:6379, password kwarg is "y" or whatever
      the provider returns from REDIS_PASSWORD env)

   - test_unsupported_auth_mode_lists_supported_modes
     (REDIS_AUTH_MODE=aws-iam → ValueError mentioning "aws-iam, azure-entra,
      mtls, vault" — all listed as future support)

   - test_provider_constructed_once_when_app_starts
     (this is more of an integration assertion — ensure that
     CacheService.create_from_env and CacheEventBus together call
     get_redis_credential_provider zero or one time, not twice. Use
     unittest.mock.patch to count calls.)

   Use the same FakeProvider pattern from P03 where you need a stub.

5. Run: pytest tests/cache/test_redis_credential_provider_compat.py -v
   All 6 tests must pass.

6. Run the full suite: pytest tests/ -x -q
   Capture the total test count.

7. Verify the smoke tests one more time. Note: P03 step 9 added
   `ALLOW_STATIC_REDIS_PASSWORD` and `REDIS_PASSWORD` to the adapter
   service env in docker-compose.yml. Path 1 uses that as-is. Path 2
   temporarily comments out the gate line.

   # Path 1: adapter env has gate set (default after P03) — works
   docker-compose down -v
   docker-compose up -d adapter redis
   sleep 5
   docker-compose logs adapter | grep -c REDIS_CREDENTIAL_MINTED
   # Expect: 1

   # Path 2: comment out ALLOW_STATIC_REDIS_PASSWORD in docker-compose.yml
   # adapter service env, then:
   docker-compose down -v
   docker-compose up -d adapter redis
   sleep 5
   docker-compose logs adapter | grep -E "ALLOW_STATIC_REDIS_PASSWORD|CredentialUnavailableError"
   # Expect: a clear error message naming the gate
   # Restore the line after confirming.

   # Path 3: in-memory cache (no Redis at all) — still works
   docker-compose down -v
   CACHE_PROVIDER=memory docker-compose up -d adapter
   sleep 5
   curl -sf http://localhost:8000/health
   # Expect: 200

8. Print the Phase 1 completion summary:

   "Phase 1 complete:
    - 4 new modules
    - 5 new audit events
    - <N> new tests (37 expected: 10 + 14 + 7 + 6)
    - Total test suite: <M>
    - .env.example updated with REDIS_AUTH_MODE and ALLOW_STATIC_REDIS_PASSWORD
    - CLAUDE.md updated with provider section + Valkey compatibility matrix
    - README.md updated with quick reference table + Valkey support note
    - Smoke tests: legacy-with-gate ✓, legacy-without-gate ✓ (refuses), memory-only ✓

    Next: Phase 2 prompts (AWS IAM and Azure Entra providers)."
````

**Expected Output:**
- Modified: `.env.example`, `CLAUDE.md`, `README.md`, possibly `docker-compose.yml`
- New file: `tests/cache/test_redis_credential_provider_compat.py` (6 tests)
- Smoke tests pass for all three deployment shapes.
- Phase 1 deliverable summary printed.

**Commit:** `redis-creds P04: backward-compat tests + documentation`

---

## Prompt P05: Cloud Deployment Template Updates (AWS ECS + Azure ACA)

**Context:** P01–P04 ship the code. P05 ships the deployment-template changes that make existing cloud deployments continue to work after the upgrade. This is critical — without P05, anyone who pulls Phase 1 and re-runs `terraform apply` or the Azure setup script will get an adapter that refuses to start, because `ALLOW_STATIC_REDIS_PASSWORD` is missing from the task definition / container app env.

The Phase 1 promise is: existing deployments keep working, just with the gate flag added. The actual move to IAM/Entra is Phase 2 work. P05 reflects that — we add the gate, we do not remove the static password, and we leave clearly-marked TODOs that point at Phase 2.

**Prompt:**

````
Update AWS ECS Terraform and Azure Container Apps Bicep to set the
ALLOW_STATIC_REDIS_PASSWORD gate so existing cloud deployments continue
to work after Phase 1 of the Redis credential provider lands.

This prompt is purely deployment-template work — no Python code is
modified. The changes are minimal because Phase 1 keeps the static
password path; we just need to flip the gate flag on so the adapter
will start.

Read:
- deploy/aws-ecs/main.tf (specifically the adapter task-def environment
  block around line 980-1010, and the Secrets Manager redis block around
  line 696-703)
- deploy/azure-aca/bicep/modules/apps.bicep (specifically the adapter
  container env array at lines 158-170 — the adapter env lives in this
  module, NOT in the orchestrator bicep/main.bicep)
- deploy/azure-aca/acasetup.sh (specifically the Bicep parameters block
  around line 956-985 — we are NOT modifying this file in P05, but you
  must read it to confirm no parameter wiring is needed)
- deploy/aws-ecs/README.md and deploy/azure-aca/README.md (you are
  appending a Phase-1 note to each)

Execute the following:

1. Modify deploy/aws-ecs/main.tf.

   In the adapter ECS task definition's `environment` block (currently
   ending around line 998 with PYTHONDONTWRITEBYTECODE), append two new
   entries before the closing bracket:

       environment = [
         # ... existing entries ...
         { name = "PYTHONUNBUFFERED", value = "1" },
         { name = "PYTHONDONTWRITEBYTECODE", value = "1" },

         # --- Redis credential provider (Phase 1) ---
         # REDIS_AUTH_MODE=static keeps the existing password-based auth
         # working. Phase 2 will replace this with REDIS_AUTH_MODE=aws-iam
         # using ElastiCache IAM authentication, at which point the
         # REDIS_PASSWORD secret below becomes unused and can be deleted.
         { name = "REDIS_AUTH_MODE", value = "static" },

         # GATE: required by the adapter when REDIS_AUTH_MODE=static.
         # This is set here because Phase 1 retains static-password auth.
         # Customer security review will flag this as a finding — that finding
         # closes when Phase 2 (aws-iam) ships and these two lines are
         # removed together with the REDIS_PASSWORD secret.
         { name = "ALLOW_STATIC_REDIS_PASSWORD", value = "true" },
       ]

   Do NOT modify the secrets array (REDIS_URL and REDIS_PASSWORD stay).
   Do NOT modify the random_password.redis_password resource.
   Do NOT modify the Secrets Manager secret blocks.

   Add a comment immediately above the `random_password "redis_password"`
   resource (currently around line 396):

       # NOTE (Phase 1): This static password is consumed by the adapter
       # via the REDIS_PASSWORD secret. Phase 2 will switch the adapter
       # to ElastiCache IAM authentication, at which point this resource
       # and the aws_secretsmanager_secret_version.redis block can be
       # removed. Until then, the adapter requires the
       # ALLOW_STATIC_REDIS_PASSWORD=true gate (see task definition).

2. Modify deploy/azure-aca/bicep/modules/apps.bicep.

   The adapter container env array is in this module, NOT in
   bicep/main.bicep (main.bicep is the orchestrator). Locate the `env:`
   array in the adapter Container App resource at lines 158-170; the
   `REDIS_URL` secretRef is the last entry at line 169. Append two new
   entries before the closing `]`:

       env: [
         { name: 'OKTA_DOMAIN', value: oktaDomain }
         { name: 'CACHE_PROVIDER', value: 'redis' }
         { name: 'REDIS_TLS_ENABLED', value: 'true' }
         { name: 'REDIS_KEY_PREFIX', value: 'okta-ps-adapter:' }
         { name: 'LOG_LEVEL', value: 'INFO' }
         { name: 'GATEWAY_PORT', value: string(gatewayPort) }
         { name: 'DCR_ENABLED', value: 'true' }
         { name: 'ENCRYPTION_KEY', secretRef: 'encryption-key' }
         { name: 'ADMIN_PASSWORD', secretRef: 'admin-password' }
         { name: 'DATABASE_URL', secretRef: 'database-url' }
         { name: 'REDIS_URL', secretRef: 'redis-url' }

         // --- Redis credential provider (Phase 1) ---
         // Phase 2 will switch this to azure-entra using Managed Identity
         // auth against Azure Managed Redis, at which point both lines
         // below disappear together with the redis-url secret.
         { name: 'REDIS_AUTH_MODE', value: 'static' }

         // GATE: required by the adapter when REDIS_AUTH_MODE=static.
         // Customer security review will flag this as a finding — closes
         // when Phase 2 (azure-entra) ships.
         { name: 'ALLOW_STATIC_REDIS_PASSWORD', value: 'true' }
       ]

   Do NOT modify the `secrets` array.
   Do NOT modify acasetup.sh — no Bicep parameters change because the
   gate value is hardcoded in the template (it's not a per-deploy
   variable; production-vs-dev is selected by NOT setting it, which
   is impossible from a Bicep file we control, hence the explicit
   "true" with a tracking comment).

3. Append a Phase-1 note to deploy/aws-ecs/README.md.

   Locate the existing "Architecture" or "Components" section. Append
   a new subsection at the end of the README before any closing
   "License" or "Support" section:

       ## Phase 1 Note: Redis Credential Provider

       This deployment currently uses static password authentication for
       ElastiCache, with the password held in AWS Secrets Manager and
       injected into the adapter task definition. The Terraform sets
       `ALLOW_STATIC_REDIS_PASSWORD=true` to permit this — without that
       flag, the Phase 1 adapter refuses to start.

       **Customer security review will cite this as a finding.** The finding
       closes in Phase 2, which switches the adapter to ElastiCache IAM
       authentication. When Phase 2 ships, the following resources can be
       deleted from `main.tf`:

       - `random_password.redis_password`
       - `aws_secretsmanager_secret.redis` and its `_version`
       - `REDIS_PASSWORD` from the task secrets array
       - `REDIS_AUTH_MODE`, `ALLOW_STATIC_REDIS_PASSWORD` from the env
         array (replaced by `REDIS_AUTH_MODE=aws-iam`)

       And these must be added:

       - `aws_elasticache_user.adapter` with `authentication_mode = "iam"`
       - `aws_elasticache_user_group.adapter`
       - An `elasticache:Connect` policy attached to the ECS task role
       - `REDIS_AWS_USER_ID` and `REDIS_AWS_CACHE_NAME` env vars

       See `REDIS_CREDS_PHASE2_PROMPTS.md` for the Terraform diff once
       Phase 2 work begins.

4. Append a Phase-1 note to deploy/azure-aca/README.md.

   Same pattern as step 3, sized for Azure:

       ## Phase 1 Note: Redis Credential Provider

       This deployment currently uses Azure Cache for Redis primary
       access key authentication, with the access key embedded in the
       `REDIS_URL` connection string passed to the adapter as a Container
       App secret. The Bicep sets `ALLOW_STATIC_REDIS_PASSWORD=true` to
       permit this — without that flag, the Phase 1 adapter refuses to
       start.

       **Customer security review will cite this as a finding.** The finding
       closes in Phase 2, which switches the adapter to Microsoft Entra
       ID authentication using the Container App's system-assigned
       managed identity. When Phase 2 ships, the following changes apply:

       - `acasetup.sh` stops calling `az redis list-keys`
       - `redisUrl` no longer carries an embedded access key
       - The Container App gains a `SystemAssigned` managed identity
       - A Redis access policy assignment grants the MI data-access
       - `REDIS_AUTH_MODE=azure-entra` replaces the static gate

       Note that Phase 2 specifically targets **Azure Managed Redis**
       (which has Entra GA) or **Azure Cache for Redis Standard/Premium**
       with Entra explicitly enabled. Basic-tier Azure Cache for Redis
       does not support Entra and will continue to require static-password
       auth (or migrate to Managed Redis).

       See `REDIS_CREDS_PHASE2_PROMPTS.md` for the Bicep diff once
       Phase 2 work begins.

5. Validate the Terraform.

   cd deploy/aws-ecs
   terraform fmt -check
   terraform validate

   Both must succeed. If either fails, fix and re-run. Do NOT run
   `terraform plan` against any real AWS account from this prompt —
   validation is sufficient.

6. Validate the Bicep.

   cd deploy/azure-aca
   az bicep build --file bicep/main.bicep --stdout > /dev/null

   Building the orchestrator (main.bicep) transitively compiles the
   apps.bicep module where we made our edits, so a successful build
   covers both. Must succeed with no warnings. (Warnings about unused
   parameters are okay; warnings about syntax are not.) If `az` is not
   installed in the dev environment, run instead:

   bicep build --file bicep/main.bicep --stdout > /dev/null

   If neither tool is installed, skip this step and document that the
   Bicep validation must be run by the deployer before merge.

7. Run the existing test suite to confirm nothing else broke:

   pytest tests/ -x -q

   Capture the count — it should be unchanged from P04. Deployment-only
   changes have no test impact.

8. Print the P05 completion summary:

   "P05 complete: cloud deployment templates updated for Phase 1.
    - deploy/aws-ecs/main.tf: +REDIS_AUTH_MODE, +ALLOW_STATIC_REDIS_PASSWORD
      in adapter task env, tracking comments on Secrets Manager block
    - deploy/azure-aca/bicep/modules/apps.bicep: +REDIS_AUTH_MODE,
      +ALLOW_STATIC_REDIS_PASSWORD in adapter env array
    - deploy/aws-ecs/README.md: Phase-1 note + Phase-2 migration plan
    - deploy/azure-aca/README.md: Phase-1 note + Phase-2 migration plan
    - Terraform validates: ✓
    - Bicep validates: ✓ (or 'skipped — no az/bicep CLI in env')
    - Total test suite: <N> (unchanged from P04)

    Phase 1 fully complete. Existing AWS ECS and Azure ACA deployments
    will start cleanly after upgrade with no operator action beyond
    pulling the new template and applying it."
````

**Expected Output:**
- Modified: `deploy/aws-ecs/main.tf` (2 env entries + 1 tracking comment)
- Modified: `deploy/azure-aca/bicep/modules/apps.bicep` (2 env entries)
- Modified: `deploy/aws-ecs/README.md` (Phase-1 note appended)
- Modified: `deploy/azure-aca/README.md` (Phase-1 note appended)
- Terraform/Bicep validation passes.
- No test count change.

**Commit:** `redis-creds P05: deployment templates set ALLOW_STATIC_REDIS_PASSWORD gate`

---

# What ships at the end of Phase 1

- The seam exists. `RedisCredentialProvider`, `RedisCredentials`, `CredentialUnavailableError`, factory, audit events.
- Static mode is gated. Production deployments without `ALLOW_STATIC_REDIS_PASSWORD=true` refuse to start.
- The customer evidence is real. Audit stream contains `REDIS_STATIC_PASSWORD_USED` (CRITICAL) on every static-mode startup; absent it, the gate is off.
- Valkey works transparently. The provider seam is wire-protocol-agnostic, so AWS ElastiCache for Valkey and self-hosted Valkey are supported with zero code branches.
- Existing cloud deployments keep working. The AWS ECS Terraform and Azure ACA Bicep set the gate flag, with tracking comments pointing at Phase 2 for IAM/Entra migration.
- 37 new tests, no regressions.
- Documentation in `.env.example`, `CLAUDE.md`, `README.md`, and the two deploy READMEs lets a customer's security team review the seam without reading code.

# What does NOT ship in Phase 1

- AWS IAM provider — Phase 2 (`elasticache:Connect`, `aws_elasticache_user`).
- Azure Entra provider — Phase 2 (Managed Identity + Redis access policy).
- mTLS provider — Phase 3.
- Vault provider — Phase 3.
- Scheduled credential refresh ahead of expiry — Phase 4 (Phase 1 mints on every reconnect, which is fine for static where there's no expiry).
- Removal of `random_password.redis_password` and the `aws_secretsmanager_secret.redis` block — Phase 2 (when the IAM path replaces them).
- Removal of `az redis list-keys` from `acasetup.sh` — Phase 2 (when Entra MI replaces the access key).
- Prometheus metrics for credential lifetime — Phase 4.

# Pre-flight checklist before P01

- [ ] Working tree clean, all existing tests passing
- [ ] On a feature branch (e.g. `feature/redis-credential-provider-phase-1`)
- [ ] You can run `pytest tests/ -x -q` and see green
- [ ] Docker Compose stack starts cleanly with current code

# After P05 — what to send the customer

1. The architecture doc (already produced)
2. The five commits, kept as-is for reviewability (squashing hides the deploy-only changes from the rest)
3. A 1-page diff summary highlighting:
   - The static gate (`ALLOW_STATIC_REDIS_PASSWORD`) and where it appears (code: `static.py`; deployments: `deploy/aws-ecs/main.tf`, `deploy/azure-aca/bicep/modules/apps.bicep`, `docker-compose.yml`)
   - The 5 new audit events
   - The compat matrix (`tests/cache/test_redis_credential_provider_compat.py`)
   - The Phase-2 migration plan in both deploy READMEs
4. A statement that Phase 2 (AWS IAM / Entra) is contracted for delivery in week N+2.

This is what unlocks the customer conversation. Phase 2 is the actual production fix; Phase 1 is what makes Phase 2 a low-risk drop-in.
