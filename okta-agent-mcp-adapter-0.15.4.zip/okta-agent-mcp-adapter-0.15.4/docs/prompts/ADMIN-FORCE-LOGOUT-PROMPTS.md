# Admin-UI Force Logout — Implementation Prompts

## Context for all prompts

You are adding an **admin-initiated force-logout** capability to the Okta MCP Adapter. An operator on the Admin UI should be able to enter a user's email (or Okta sub) and click "Force Logout", which invalidates all cached tokens and backend sessions for that user across every pod. The goal is to avoid building a generic cache-refresh admin feature by reusing the revocation flow that already exists for Okta ITP Universal Logout (ULO).

### Key design decisions (already agreed)

- **Reuse `GlobalLogoutHandler.revoke_user(user_sub, correlation_id)`** in `okta_agent_proxy/auth/global_logout.py`. It is HTTP-agnostic, idempotent, and already performs the three-step cascade: `UserTokenStore.aremove_by_user` → `TokenCache.ainvalidate_all_for_user` → `MCPSessionManager.terminate_all_for_user`.
- **Accept email OR sub on the new admin endpoint.** Email is preferred UX; admins may paste an Okta sub directly as an escape hatch. When email is supplied, resolve it to `sub` via the Okta Management API (`GET /api/v1/users/{login}`) using the admin's own access token forwarded through the existing `OktaAPIClient` pattern (`okta_agent_proxy/okta_admin/client.py`).
- **New audit event type `ADMIN_FORCE_LOGOUT`** distinguishes admin-initiated revocation from Okta-ITP-initiated ULO in SIEM dashboards. Both paths terminate in the same underlying `GLOBAL_LOGOUT_COMPLETED` event emitted by `GlobalLogoutHandler`, so ULO-native dashboards continue to work unchanged.
- **No new rate limiting on the admin endpoint.** Admins are trusted; rate limiting exists on the unauthenticated `/oauth/global-token-revocation` endpoint for abuse prevention, which is not a concern here.
- **UI placement:** new sidebar entry under "Security & Compliance" at `/dashboard/sessions`. Single-purpose page, free-form email/sub input, confirm dialog, toast on completion — matches the `handleSyncAll` UX in `okta-import/page.tsx`.
- **Branching:** `feature/global-logout` is merged into `feature/db-migration-0.15.0` so both ship together as the 0.15.0 release (see Prompt 1). All subsequent prompts assume the merged state.

### Rules that apply to every prompt

- All existing tests must pass after each prompt. Run `./venv/bin/pytest tests/ -v` before claiming done.
- Each prompt is idempotent — running it twice leaves the code in the same state as running it once.
- Every new auth/admin code path emits audit events via `emit_audit_event()`. Every admin endpoint uses the `@admin_required` decorator from `okta_agent_proxy/admin/middleware.py`.
- Do not modify unrelated code. Note drive-by issues as comments; do not fix them in these prompts.
- Commits must be signed (`-S` explicitly — the local repo's `.git/config` disables signing by default; see memory `feedback_local_gpgsign_override.md`).
- Tooling: never `source venv/bin/activate`. Call `./venv/bin/pytest`, `./venv/bin/python`, etc., directly. See CLAUDE.md "Tooling Conventions".

### Verified facts about the codebase (from source review)

- `GlobalLogoutHandler.revoke_user(user_sub: str, correlation_id: str) -> dict` exists at `okta_agent_proxy/auth/global_logout.py` and returns `{"user_sub", "correlation_id", "tokens_revoked", "cache_swept", "sessions_terminated", "sessions_failed", "backends"}`. Singletons resolve lazily on first use.
- `OktaAPIClient` at `okta_agent_proxy/okta_admin/client.py` is the canonical pattern for Okta Management API calls. `_request(method, path, token, json=None)` maps 401→`OktaAdminAuthError`, 403→`OktaAdminForbiddenError`, 404→`OktaAdminNotFoundError`, 429→`OktaAdminRateLimitError`. Use it; do not roll a new `httpx` client.
- Admin routes are plain async Starlette handlers decorated with `@admin_required`. Routes are registered imperatively in `okta_agent_proxy/app.py` via `Route("/api/admin/...", handler, methods=[...])`. There is no FastAPI `APIRouter`.
- Admin audit context: inside an `@admin_required` handler, `request.state.admin_user` carries the operator identifier; `user_id_var` and `client_id_var` from `audit/context.py` are set automatically.
- Admin UI API client is `okta_agent_proxy_admin_ui/lib/api-client.ts`. All requests pull the Okta access token from `getSession()` and proxy through `app/api/admin/[...path]/route.ts` to the gateway.
- Admin UI nav is configured in `okta_agent_proxy_admin_ui/app/dashboard/layout.tsx` (around line 66, `navSections`).
- The closest existing UX template for a confirm-dialog-gated POST action is `handleSyncAll` in `okta_agent_proxy_admin_ui/app/dashboard/okta-import/page.tsx` (~line 226).
- Okta Users API: `GET /api/v1/users/{login}` accepts either an email address or an Okta user id as `{login}`. The response JSON has the immutable user id at `.id`. Requires scope `okta.users.read` on the caller's access token.

---

## Prompt 1 — Merge `feature/global-logout` into `feature/db-migration-0.15.0`

### Goal

Merge the `feature/global-logout` branch into `feature/db-migration-0.15.0` so both ship together in the 0.15.0 release. Resolve conflicts, keep the full test matrix green, and end with a single signed merge commit on `feature/db-migration-0.15.0`.

### Pre-flight

The working tree on `feature/db-migration-0.15.0` currently has uncommitted edits. Before merging:

1. `git status` — enumerate the dirty files.
2. Commit, stash, or discard each one deliberately with the user's direction. Do **not** discard without asking. Several of the dirty files (`admin/routes.py`, `app.py`, `api-client.ts`) overlap with the ULO branch, so committing them first lets git present one conflict per file rather than layered chaos.

### Expected conflict hotspots

Running `git diff --name-only main..feature/db-migration-0.15.0` and `git diff --name-only main..feature/global-logout` identifies the overlap. Plan for conflicts in:

- `okta_agent_proxy/admin/routes.py` — 0.15.0 did the (agent, connection)→resources collapse; ULO added admin-side wiring references. Prefer the 0.15.0 shape; re-apply ULO's additions on top.
- `okta_agent_proxy/app.py` — both branches add `Route(...)` entries and subscribers. Merge additively; keep both.
- `okta_agent_proxy/audit/events.py` — both branches add `AuditEventType` enum values. Trivial; keep both sets, preserve alphabetical/logical grouping.
- `okta_agent_proxy_admin_ui/lib/api-client.ts` — both add new methods. Keep both.
- `okta_agent_proxy_admin_ui/package.json` + `package-lock.json` — resolve to the 0.15.0 version string; run `npm install` inside `okta_agent_proxy_admin_ui/` after resolution to regenerate the lock.
- `okta_agent_proxy_admin_ui/app/dashboard/resources/page.tsx` — 0.15.0 refactor dominates; ULO changes should be light. Prefer 0.15.0.
- `README.md`, `tests/test_oauth_discovery.py` — doc and the ULO discovery-advertisement tests; low risk.

### Execution

1. `git checkout feature/db-migration-0.15.0` (already current).
2. `git merge feature/global-logout` — resolve conflicts file by file.
3. After all conflicts resolved: `git add <resolved files>`, then `git commit -S -m "merge(global-logout): bring ULO into 0.15.0 release"` — GPG sign explicitly; the local `.git/config` disables signing by default.
4. `./venv/bin/pytest tests/ -v` — all previously-green tests must remain green, including the ~21 ULO integration tests. Triage any new failure.
5. `./setup.sh` to bring the Docker stack up. Smoke-check:
   - `POST /.well-known/oauth-authorization-server` advertises `global_token_revocation_endpoint`.
   - `POST /oauth/global-token-revocation` with a deliberately invalid JWT returns the ULO branch's JWT-validation error (confirms the endpoint is wired, not 404).
6. `git push -S` to the remote tracking branch.

### Done criteria

- `feature/db-migration-0.15.0` contains every commit from `feature/global-logout`.
- Full test suite passes.
- `/oauth/global-token-revocation` is reachable from the running stack.
- Merge commit is signed.

---

## Prompt 2 — Backend: audit event + Okta user resolver

### Goal

Lay the plumbing for the new admin endpoint by adding (a) the `ADMIN_FORCE_LOGOUT` audit event type, and (b) a small helper on `OktaAPIClient` that resolves an email to an Okta user id.

### Files to modify

- `okta_agent_proxy/audit/events.py`
- `okta_agent_proxy/okta_admin/client.py`
- `tests/test_okta_admin_client.py` (extend — or create if absent)

### Changes

**1. Add audit event** in `okta_agent_proxy/audit/events.py`:

```python
# Inside class AuditEventType(str, Enum):
ADMIN_FORCE_LOGOUT = "admin.user.force_logout"
```

Place it near the existing admin audit events (alphabetical within its group). No severity change vs. the ULO event path — severity is assigned at emit time.

**2. Add resolver method** on `OktaAPIClient` in `okta_agent_proxy/okta_admin/client.py`:

```python
async def get_user_by_login(self, login: str, token: str) -> dict:
    """Look up an Okta user by login (email) or by Okta user id.

    Returns the raw Okta user object. Caller extracts `.id` as the
    immutable sub used by GlobalLogoutHandler.

    Requires the caller's access token to carry the `okta.users.read`
    scope. Raises OktaAdminForbiddenError (403) if missing, or
    OktaAdminNotFoundError (404) if the user does not exist.
    """
    response = await self._request(
        method="GET",
        path=f"/api/v1/users/{login}",
        token=token,
    )
    response.raise_for_status()
    return response.json()
```

Do not URL-encode `login` — Okta accepts `+` and `@` in path segments for this endpoint. If the caller passes something that must be encoded (e.g., `%20`), let it surface as a 404 from Okta rather than silently massaging it.

**3. Unit tests** in `tests/test_okta_admin_client.py`:

- Happy path: mock `httpx.AsyncClient.request` to return a 200 with `{"id": "00u123", "profile": {"email": "u@example.com"}}` → assert the returned dict has `.id == "00u123"`.
- 404 path: mock 404 → assert `OktaAdminNotFoundError` is raised.
- 403 path: mock 403 → assert `OktaAdminForbiddenError` is raised with the existing "Insufficient Okta permissions" message.

### Verification

`./venv/bin/pytest tests/test_okta_admin_client.py -v` — new tests green.

---

## Prompt 3 — Backend: admin force-logout endpoint

### Goal

Expose `POST /api/admin/users/force-logout` as an admin-authenticated endpoint that accepts an email or sub, resolves email via the Okta resolver from Prompt 2 when needed, and calls `GlobalLogoutHandler.revoke_user` to perform the revocation.

### Files to modify

- `okta_agent_proxy/admin/routes.py`
- `okta_agent_proxy/app.py`

### Changes

**1. New handler** in `okta_agent_proxy/admin/routes.py` — add after `token_store_delete_user`:

```python
@admin_required
async def force_logout_user(request: Request):
    """POST /api/admin/users/force-logout — admin-initiated revocation.

    Body: one of
      {"email": "user@example.com"}
      {"sub":   "00u..."}

    Returns the GlobalLogoutHandler summary.
    """
    try:
        body = await request.json()
    except Exception:
        return JSONResponse(
            {"error": "invalid_input", "message": "Request body must be JSON."},
            status_code=400,
        )

    email = (body.get("email") or "").strip()
    sub = (body.get("sub") or "").strip()

    if bool(email) == bool(sub):
        return JSONResponse(
            {
                "error": "invalid_input",
                "message": "Provide exactly one of 'email' or 'sub'.",
            },
            status_code=400,
        )

    admin_user = getattr(request.state, "admin_user", "admin")
    admin_token = extract_admin_token(request)  # reuse existing helper
    correlation_id = uuid.uuid4().hex

    resolved_sub = sub
    resolved_email: Optional[str] = email or None

    if email:
        try:
            okta_client = OktaAPIClient()
            user = await okta_client.get_user_by_login(email, token=admin_token)
            resolved_sub = user["id"]
            resolved_email = user.get("profile", {}).get("email", email)
        except OktaAdminNotFoundError:
            return JSONResponse(
                {"error": "user_not_found", "message": f"No Okta user for '{email}'."},
                status_code=404,
            )
        except OktaAdminForbiddenError as exc:
            return JSONResponse(
                {"error": "forbidden", "message": str(exc)},
                status_code=403,
            )
        except OktaAdminAuthError as exc:
            return JSONResponse(
                {"error": "unauthorized", "message": str(exc)},
                status_code=401,
            )

    try:
        summary = await GlobalLogoutHandler().revoke_user(resolved_sub, correlation_id)
    except Exception as exc:
        logger.exception("Admin force-logout failed for sub=%s", resolved_sub)
        return JSONResponse(
            {"error": "server_error", "message": f"{type(exc).__name__}: {exc}"},
            status_code=500,
        )

    await emit_audit_event(
        AuditEventType.ADMIN_FORCE_LOGOUT,
        severity=AuditSeverity.INFO,
        details={
            "actor": admin_user,
            "target_sub": resolved_sub,
            "target_email": resolved_email,
            "correlation_id": correlation_id,
            "tokens_revoked": summary["tokens_revoked"],
            "cache_swept": summary["cache_swept"],
            "sessions_terminated": summary["sessions_terminated"],
            "sessions_failed": summary["sessions_failed"],
        },
    )

    return JSONResponse(summary, status_code=200)
```

Imports to add at the top of the file (if not already present): `uuid`, `OktaAPIClient`, the three `OktaAdmin*Error` classes, `GlobalLogoutHandler`, `extract_admin_token`, `AuditSeverity`. Match the import style already in the module.

**2. Register the route** in `okta_agent_proxy/app.py` — add alongside the existing admin routes (near `token_store_delete_user`):

```python
Route(
    "/api/admin/users/force-logout",
    admin_routes.force_logout_user,
    methods=["POST"],
),
```

### Verification

- Start the stack: `./setup.sh`.
- With an admin session (via the Admin UI's DevTools → copy Bearer token):
  ```bash
  curl -X POST http://localhost:8000/api/admin/users/force-logout \
    -H "Authorization: Bearer $ADMIN_TOKEN" \
    -H "Content-Type: application/json" \
    -d '{"sub":"00u_EXISTING_USER"}'
  ```
  → Expect 200 with the GlobalLogoutHandler summary.
- `-d '{"email":"user@example.com"}'` → Expect 200 (or 404 if the user doesn't exist).
- `-d '{}'` → Expect 400.
- `-d '{"email":"x","sub":"y"}'` → Expect 400.

---

## Prompt 4 — Backend: integration tests for the force-logout endpoint

### Goal

Cover the admin endpoint with integration tests that exercise every branch: email path, sub path, both-or-neither rejection, Okta 404 pass-through, Okta 403 pass-through, and audit-event emission.

### Files to create

- `tests/test_admin_force_logout.py`

### Test plan

Follow the fixture patterns in `tests/test_admin_api_integration.py` (Starlette `TestClient`, admin JWT fixture, mocked audit sink). Mock `GlobalLogoutHandler.revoke_user` to return a canned summary. Mock `OktaAPIClient.get_user_by_login` rather than hitting the real Okta.

Required cases:

1. `test_force_logout_by_sub_happy_path` — body `{"sub": "00u1"}`, `revoke_user` called with `"00u1"`, 200 response, summary in body.
2. `test_force_logout_by_email_resolves_sub` — body `{"email": "u@example.com"}`, resolver returns `{"id": "00u1", ...}`, `revoke_user` called with `"00u1"`, 200 response.
3. `test_force_logout_rejects_both_email_and_sub` — body has both → 400 `invalid_input`.
4. `test_force_logout_rejects_neither_email_nor_sub` — body has neither → 400 `invalid_input`.
5. `test_force_logout_email_not_found_in_okta` — resolver raises `OktaAdminNotFoundError` → 404 `user_not_found`.
6. `test_force_logout_admin_lacks_okta_users_read` — resolver raises `OktaAdminForbiddenError` → 403 `forbidden`.
7. `test_force_logout_emits_admin_audit_event` — capture audit sink, assert exactly one `ADMIN_FORCE_LOGOUT` event with the expected `actor`, `target_sub`, `target_email`, `correlation_id`, and revocation counts.
8. `test_force_logout_unauthenticated_is_401` — no admin token → 401 before any handler logic runs (covers `@admin_required` wiring).

### Verification

`./venv/bin/pytest tests/test_admin_force_logout.py -v` — all cases green.
`./venv/bin/pytest tests/ -v` — full suite still green.

---

## Prompt 5 — Admin UI: api-client method, sessions page, nav entry

### Goal

Add the "User Sessions" page to the Admin UI under Security & Compliance. A single card collects either an email or an Okta sub, a confirm dialog gates the action, and a toast reports the revocation summary on completion.

### Files to modify

- `okta_agent_proxy_admin_ui/lib/api-client.ts`
- `okta_agent_proxy_admin_ui/app/dashboard/layout.tsx`

### Files to create

- `okta_agent_proxy_admin_ui/app/dashboard/sessions/page.tsx`

### Changes

**1. API client method** (`lib/api-client.ts`) — add to the `ApiClient` class:

```ts
export interface ForceLogoutSummary {
  user_sub: string;
  correlation_id: string;
  tokens_revoked: number;
  cache_swept: boolean;
  sessions_terminated: number;
  sessions_failed: number;
  backends: Record<string, boolean>;
}

export interface ForceLogoutInput {
  email?: string;
  sub?: string;
}

// inside class ApiClient:
async forceLogoutUser(input: ForceLogoutInput): Promise<ForceLogoutSummary> {
  return this.request<ForceLogoutSummary>('/api/admin/users/force-logout', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(input),
  });
}
```

**2. Nav entry** (`app/dashboard/layout.tsx`) — under the "Security & Compliance" section of `navSections`:

```ts
{ label: 'User Sessions', href: '/dashboard/sessions', icon: <SomeIcon /> },
```

Pick an icon already imported in the file (e.g., `LogOut` from lucide-react if available — check existing imports and reuse).

**3. New page** (`app/dashboard/sessions/page.tsx`):

Mirror the UX pattern from `okta-import/page.tsx` `handleSyncAll` (confirm dialog + toast). The page should include:

- A card titled "Force Logout User" with short explanatory copy referencing this is destructive.
- A radio toggle "By email" / "By Okta user ID (sub)".
- A single text input, with validation tied to the selection (email format check, or `00u...` shape check for sub). Keep validation lenient — the backend is authoritative.
- A destructive-styled "Force Logout" button. Disabled while a request is in flight.
- Confirm dialog via the existing `components/ui/dialog` with the summary of what will happen ("This will revoke all cached tokens and terminate all backend MCP sessions for this user across every adapter pod.").
- Toast via `useToast`:
  - Success: `"Force-logout complete: revoked {tokens_revoked} tokens, terminated {sessions_terminated} backend sessions."`
  - 404: `"No Okta user found for that email."`
  - 403: `"Your admin login is missing the 'okta.users.read' scope. Ask the Okta admin to add it to this app."`
  - 500 / unknown: raw error message.

Do not add a user-listing UI or a picker — there is no users table backing it, and the admin is expected to know either the email or the sub.

### Verification

- `cd okta_agent_proxy_admin_ui && npm run build` — no TypeScript errors.
- Start the stack, log into the Admin UI, navigate to Security & Compliance → User Sessions.
- Enter a known email → confirm → toast reports success → audit log page shows an `admin.user.force_logout` entry.
- Re-run a tool call from an MCP client that was cached under that user — the client should be forced through a fresh Okta round-trip (cache miss).

---

## Prompt 6 — Docs, operator notes, CHANGELOG, version bump

### Goal

Close out the feature with docs, operator notes about the new Okta scope requirement, and the 0.15.0 version bump across all five files (lockstep with the Admin UI).

### Files to modify

- `docs/GLOBAL_LOGOUT_CONFIGURATION.md` — add a section "Admin-initiated force logout" noting the `okta.users.read` scope requirement on the Admin UI's Okta app, the endpoint URL, and the audit event name.
- `docs/OPERATIONS.md` — add a cross-reference under the admin-API section.
- `CHANGELOG.md` — v0.15.0 entry gets a new bullet under "Added" referencing both the ULO merge and the new admin-UI force-logout action.
- `pyproject.toml` — version → `0.15.0` (confirm, do not downgrade).
- `okta_agent_proxy/__init__.py` — `__version__ = "0.15.0"`.
- `okta_agent_proxy_admin_ui/package.json` — `"version": "0.15.0"`.
- `okta_agent_proxy_admin_ui/package-lock.json` — regenerate via `npm install`.

Per memory `project_release_process.md`, all five version locations bump in lockstep. Do not skip the lockfile.

### Done criteria

- All tests still green.
- Docker stack still boots cleanly via `./setup.sh`.
- Git working tree clean after a signed commit titled `release: v0.15.0`.

---

## Appendix — How to run these prompts

Each prompt is intended to be executed in a fresh Claude context. At the start of a new session:

1. Paste the "Context for all prompts" section.
2. Paste the specific prompt (e.g., "Prompt 3").
3. Let Claude execute end-to-end against the current working tree, including running tests.
4. Commit the result with a signed commit (`-S`) before clearing and moving to the next prompt.

Prompts 2–6 assume Prompt 1 has been completed and the merge commit is on `feature/db-migration-0.15.0`.
