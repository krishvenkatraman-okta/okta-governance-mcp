# RFC 8414 §3.3 Issuer Mismatch — Implementation Prompts

**Feature:** Bring the OAuth Authorization Server discovery metadata into compliance with RFC 8414 §3.3 so the `issuer` field byte-matches the issuer identifier value advertised in the RFC 9728 protected resource metadata. Required for spec-compliant client interoperability, to remove an open security-review finding, and to give clients a working mix-up-attack defense layer (per RFC 8414 §2's reference to MIX-UP).

**Affected Modules:** `okta_agent_proxy/config.py`, `okta_agent_proxy/app.py`, `okta_agent_proxy/auth/okta_validator.py`, `okta_agent_proxy/audit/events.py`, `okta_agent_proxy/metadata.py`, `okta_agent_proxy/main.py`

**Prompt Count:** 6 sequential prompts

**Test Constraint:** All existing tests must continue passing after each prompt. The full suite is run after every prompt with `pytest tests/ -x -q`.

**Audit Constraint:** Discovery endpoint changes do not directly emit per-request audit events, but the new traditional-client audit emissions MUST emit `OAUTH_AUTHORIZE_RELAYED` and `OAUTH_AUTHORIZE_RELAY_FAILED` events. Add these to `audit/events.py` in R1 and wire `emit_audit_event()` calls into the traditional-client branch of `oauth_authorize` in R5.

---

## Background — What's Broken and Why

### The finding

A security test flagged that the adapter's OAuth Authorization Server metadata at:

```
https://st-okta-mcp-adapter-demo.up.railway.app/.well-known/oauth-authorization-server
```

…declares Okta's domain as the `issuer`:

```json
{
  "issuer": "https://servicetitan.oktapreview.com",
  "authorization_endpoint": "https://st-okta-mcp-adapter-demo.up.railway.app/oauth/authorize",
  "token_endpoint":         "https://st-okta-mcp-adapter-demo.up.railway.app/oauth2/v1/token",
  "jwks_uri":               "https://servicetitan.oktapreview.com/oauth2/v1/keys"
}
```

This violates **RFC 8414 §3.3** (Authorization Server Metadata Validation):

> The "issuer" value returned MUST be identical to the authorization server's issuer identifier value into which the well-known URI string was inserted to create the URL used to retrieve the metadata. If these values are not identical, the data contained in the response MUST NOT be used.

The constraint is *not* "issuer must equal the request host." It's: whatever issuer identifier the client was working from when it constructed the metadata URL must byte-match the `issuer` field in the response. In a properly wired BFF flow:

1. Client fetches PRM (`/.well-known/oauth-protected-resource`) from the adapter
2. PRM advertises `authorization_servers: [<some issuer URL>]`
3. Client takes that issuer URL, inserts `/.well-known/oauth-authorization-server` per RFC 8414 §3, and fetches the metadata
4. RFC 8414 §3.3 says the `issuer` in the response MUST byte-match the URL the client started from in step 2

If the adapter wants to be the BFF (own the discovery surface, intercept the token endpoint, do `access_token = id_token` rewriting, gate CIMD/DCR), the issuer advertised in PRM must be the adapter's URL, and therefore the AS metadata's `issuer` must also be the adapter's URL.

### What the code already has (and what's really broken)

This review — not the original draft of this doc — surfaced the following actual current state, which significantly reduces the scope of work:

- **PRM is already compliant.** `oauth_protected_resource` (`app.py:392-407`) already advertises `authorization_servers: [gateway_base_url]`. No shape change needed.
- **`/oauth/authorize` already exists** (`app.py:1033-1297`) and correctly routes CIMD, DCR-linked, DCR-unlinked, and traditional clients. The traditional-client branch (`app.py:1279-1297`) already 302-redirects to Okta with full parameter preservation. No new handler needed; only audit emission is missing on that branch.
- **The real §3.3 violation is narrow.** Two discovery handlers (`oauth_authorization_server` and `oauth_authorization_server_by_name`) hardcode `issuer: okta_issuer` while every other advertised endpoint already points at the gateway. Flipping `issuer` (and `jwks_uri`) closes the compliance gap.
- **`/oauth2/v1/keys` does not exist.** Once `jwks_uri` flips to the gateway, this endpoint must actually exist. The handler re-serves Okta's JWKS via the existing `OktaTokenValidator.fetch_jwks()` cache (`auth/okta_validator.py:139`).
- **`GATEWAY_BASE_URL` already means "the adapter's public URL"** and is used throughout `app.py`. It just lacks validation (no https-or-loopback check, no trailing-slash rejection, no path/query rejection). Tightening the existing setting is cheaper than adding a parallel `ADAPTER_ISSUER`.
- **`okta_agent_proxy/metadata.py::get_protected_resource_metadata()` is dead code that still advertises Okta as the AS** (contradicts the live handler). Imported only by `main.py:74` and `tests/test_okta_auth.py:21,343`. Delete it.

### Why this matters even though current clients tolerate it

Claude Code, Cursor, and the other clients exercised against this deployment today appear to tolerate the violation. That does not make the finding low-priority:

- **Spec-strict clients will fail-closed.** Future clients (Foundry's AI Gateway, AgentCore, third-party MCP clients with stricter OAuth libraries) will reject the metadata per §3.3's MUST NOT clause.
- **Security review findings.** Enterprise customers running their own SAST/DAST during POC engagements will surface this. "Why does your OAuth metadata violate RFC 8414?" is not a question to field mid-engagement.
- **Mix-up attack defense weakened.** §3.3 is the explicit defense (per §2's MIX-UP reference). The current state means clients can't use it as a defense layer.
- **Discovery foundation is shaky.** CIMD, DCR, and the AS metadata advertisement of those features all sit on top of this metadata. Building more on a non-compliant base makes future debugging harder.

### The architectural decision

The adapter is a Backend-for-Frontend (BFF) OAuth proxy. It is the authorization server presented to inbound MCP clients, even though Okta is the upstream signer. We pick **Path A — Adapter-as-issuer**:

- AS metadata declares `GATEWAY_BASE_URL` as `issuer` (existing setting, tightened validation).
- `authorization_endpoint`, `token_endpoint`, `jwks_uri`, `registration_endpoint` all point to the adapter.
- The adapter 302-redirects `/oauth/authorize` to Okta's real `/authorize` (already implemented, preserves all query params).
- The adapter proxies JWKS from Okta's keys endpoint via a new `/oauth2/v1/keys` handler.
- Okta remains the only token signer (consistent with "Okta is the only token issuer"). The `okta_validator` continues to validate inbound JWT `iss` against Okta's URL — this is the legitimate BFF divergence. Outbound token planes (ID-JAG / Cross App Access) are independent and unaffected.

### What we are NOT doing

- We are **not** re-signing tokens at the adapter. Token issuance stays at Okta.
- We are **not** removing `/.well-known/oauth-authorization-server`. The BFF pattern requires it.
- We are **not** changing the inbound JWT `iss` validation. Tokens are signed by Okta and carry Okta's `iss`. The `okta_validator` keeps validating that.
- We are **not** touching the outbound plane. Backend MCP servers validate tokens minted by Okta's custom auth server against Okta's JWKS directly.
- We are **not** introducing a new `ADAPTER_ISSUER` config. `GATEWAY_BASE_URL` already serves this role; we tighten its validation instead.
- We are **not** rewriting `oauth_authorize`. The handler already works correctly for CIMD, DCR, and traditional clients; we only add audit emission to the traditional-client branch.
- We are **not** modifying DCR or CIMD branches of `oauth_authorize`. They already emit appropriate audit events (`DCR_AUTHORIZE_RELAYED` / `DCR_AUTHORIZE_RELAY_FAILED`).

---

## Prompt Execution Order

```
R1: Tighten GATEWAY_BASE_URL validation + add new AuditEventType values
R2: Fix §3.3 violation in BOTH discovery handlers (main + by-name)
R3: Delete metadata.py::get_protected_resource_metadata() dead code
R4: Add /oauth2/v1/keys JWKS proxy endpoint
R5: Add audit emission to traditional-client branch of oauth_authorize
R6: Add RFC 8414 §3.3 end-to-end round-trip test
```

---

### Prompt R1: Tighten `GATEWAY_BASE_URL` Validation + Add Audit Event Types

**Context:** `GATEWAY_BASE_URL` already exists (`config.py:163`) and is used throughout `app.py` as the adapter's public URL. It lacks validation — any string is accepted. This prompt adds strict validation and the new audit event types that downstream prompts will emit.

**Prompt:**

```
Tighten validation on the existing GATEWAY_BASE_URL setting and add the new
audit event types that R2, R4, and R5 will emit.

Read the existing codebase, especially:
- okta_agent_proxy/config.py — GatewaySettings class at line 145, gateway_base_url
  field at line 163, existing @field_validator pattern at lines 166-180
- okta_agent_proxy/audit/events.py — AuditEventType enum, groupings for AUTH_*,
  OAUTH-adjacent events, DCR_*, CIMD_*
- .env.example — existing env var documentation pattern

Execute the following:

1. In okta_agent_proxy/config.py, add a @field_validator("gateway_base_url")
   to the GatewaySettings class with these rules (raise ValueError on violation):

   - MUST start with "https://" UNLESS the host is a loopback address. Loopback
     hosts that may use http:// are: "localhost", "127.0.0.1", "::1", and any
     hostname ending in ".localhost" (per RFC 6761 §6.3). This carve-out matches
     what the broader OAuth ecosystem does (cf. RFC 8252 §7.3 "Loopback
     Interface Redirection" and the MCP Python SDK's validate_issuer_url) and
     allows local development without TLS while still rejecting HTTP for any
     real internet host.
   - MUST NOT have a trailing slash (RFC 8414 §3 — issuer is used as-is for
     URL construction; trailing slashes break byte-identity comparisons in §3.3
     validation).
   - MUST NOT contain a path component, query string, or fragment (issuer is
     host-only per RFC 8414 §2).
   - MUST be a valid absolute URL with scheme and host.

   Implementation note: do NOT gate the http://-on-loopback exception on an
   ENVIRONMENT variable. The URL itself encodes whether http is safe — if the
   host is loopback, http is fine; if it isn't, http is rejected regardless of
   environment. This catches misconfigurations like "http://prod.example.com"
   even if someone sets ENVIRONMENT=production by mistake.

   Reference helper (place as a module-level private function in config.py):

   _LOOPBACK_HOSTS = {"localhost", "127.0.0.1", "::1"}

   def _is_loopback(host: str) -> bool:
       if not host:
           return False
       host_lower = host.lower()
       if host_lower in _LOOPBACK_HOSTS:
           return True
       # RFC 6761 §6.3 — *.localhost is reserved for loopback
       if host_lower.endswith(".localhost"):
           return True
       return False

   The validator should parse with urllib.parse.urlparse, extract hostname,
   and apply the rules. Error messages must be specific: "GATEWAY_BASE_URL
   must use https:// or a loopback host; got <value>", etc.

2. In okta_agent_proxy/audit/events.py, add to the AuditEventType enum:

   OAUTH_DISCOVERY_SERVED = "oauth.discovery.served"
   OAUTH_JWKS_PROXY_HIT = "oauth.jwks.proxy.hit"
   OAUTH_JWKS_PROXY_MISS = "oauth.jwks.proxy.miss"
   OAUTH_AUTHORIZE_RELAYED = "oauth.authorize.relayed"
   OAUTH_AUTHORIZE_RELAY_FAILED = "oauth.authorize.relay.failed"

   Place these near the existing DCR_AUTHORIZE_RELAYED / DCR_AUTHORIZE_RELAY_FAILED
   values (audit/events.py:54-55) so the OAuth-family events cluster together.

3. Update .env.example:
   - Add or update the GATEWAY_BASE_URL entry with a comment block explaining
     it acts as the OAuth issuer identifier (RFC 8414 §3.3 compliance). Document
     the validation rules: https-or-loopback, no trailing slash, no path/query.
     Reference that this value must byte-match what PRM advertises in
     authorization_servers (established by R2).

4. Create tests/test_gateway_base_url_validation.py with 14+ tests:
   - Valid HTTPS URL is accepted ("https://example.com")
   - Valid HTTPS URL with port is accepted ("https://example.com:8443")
   - http://localhost:8000 is accepted (loopback exemption)
   - http://127.0.0.1:8000 is accepted (loopback exemption)
   - http://[::1]:8000 is accepted (IPv6 loopback)
   - http://app.localhost:8000 is accepted (RFC 6761 §6.3 subdomain)
   - http://localhost.evil.com is REJECTED (host is "localhost.evil.com",
     not a loopback — this is a known phishing/typo class)
   - http://example.com is rejected (not loopback)
   - http://192.168.1.50:8000 is rejected (LAN IP is not a loopback per RFC 6761)
   - Trailing slash is rejected with a clear error message
   - Path component (e.g., https://host/foo) is rejected
   - Query string is rejected
   - Fragment is rejected
   - ftp:// or other non-http(s) schemes are rejected
   - Empty string / missing scheme is rejected

   NOTE: The default in config.py is "http://localhost:8000" which must
   continue to pass validation (it's a loopback URL). Confirm this in a test.

5. Run: pytest tests/test_gateway_base_url_validation.py -v
   Then: pytest tests/ -x -q
   ALL tests must pass.

Do NOT change any handler code in this prompt. R2 consumes the audit event types.
Do NOT emit any audit events from this prompt.
Do NOT introduce a new ADAPTER_ISSUER setting — this was explicitly rejected
during plan review. Reuse GATEWAY_BASE_URL.
```

**Expected Output:** Tightened `@field_validator` on `gateway_base_url` with loopback carve-out, 5 new `AuditEventType` values, updated `.env.example`, 14+ new tests passing, full suite green.

---

### Prompt R2: Fix §3.3 Violation in Both Discovery Handlers

**Context:** This is the core fix. Both `oauth_authorization_server` (root) and `oauth_authorization_server_by_name` (per-resource) currently return `issuer: okta_issuer` while every other advertised endpoint already points at the gateway. Flipping `issuer` and `jwks_uri` closes the §3.3 gap on both surfaces.

**Prompt:**

```
Fix the RFC 8414 §3.3 violation in both authorization-server discovery
handlers. The current handlers return Okta's domain as the issuer; they must
return GATEWAY_BASE_URL (byte-identical to PRM's authorization_servers[0],
which is already gateway_base_url).

Read the existing codebase, especially:
- okta_agent_proxy/app.py:453-488 — oauth_authorization_server() handler
- okta_agent_proxy/app.py:491-536 — oauth_authorization_server_by_name() handler
- okta_agent_proxy/app.py:392-407 — oauth_protected_resource() (already returns
  gateway_base_url in authorization_servers; confirm this)
- okta_agent_proxy/config.py — gateway_base_url setting
- okta_agent_proxy/audit/__init__.py:70 — emit_audit_event() signature
- okta_agent_proxy/auth/okta_validator.py — the inbound JWT iss validation site
  (do NOT modify; only add a clarifying comment)

Execute the following:

1. In oauth_authorization_server() (app.py:453-488):
   - Change "issuer" from okta_issuer to gateway_base (the existing local var).
   - Change "jwks_uri" from the Okta JWKS URL to f"{gateway_base}/oauth2/v1/keys".
   - Preserve all other fields as-is (authorization_endpoint, token_endpoint,
     registration_endpoint, response_types_supported, grant_types_supported,
     token_endpoint_auth_methods_supported, code_challenge_methods_supported,
     scopes_supported, client_id_metadata_document_supported).
   - Add a docstring explaining RFC 8414 §3.3 compliance and the BFF
     divergence (inbound validator validates iss against OKTA_ISSUER; discovery
     advertises GATEWAY_BASE_URL because the adapter is the BFF-fronted AS).
   - Emit OAUTH_DISCOVERY_SERVED audit event with details:
     {"endpoint": "oauth-authorization-server", "issuer": gateway_base,
      "client_ip": <extracted>, "user_agent": <from headers>}
     Use severity=info (default). Do NOT block the response on emission.
     For client_ip: use request.client.host (match the pattern in
     oauth_registration at app.py:555).

2. In oauth_authorization_server_by_name() (app.py:491-536):
   - Change "issuer" from okta_issuer to config.gateway.gateway_base_url.
   - Change "jwks_uri" from the Okta JWKS URL to
     f"{config.gateway.gateway_base_url}/oauth2/v1/keys".
   - IMPORTANT: the current handler's authorization_endpoint builds a URL
     pointing at Okta (line 506: f"{okta_issuer}/v1/authorize?{scope_param}").
     Change this to point at the gateway:
     f"{config.gateway.gateway_base_url}/oauth/authorize?{scope_param}"
     so that all four core endpoints (authorization_endpoint, token_endpoint,
     jwks_uri, registration_endpoint) are under GATEWAY_BASE_URL. The existing
     /oauth/authorize handler preserves query parameters and handles the
     Okta redirect internally.
   - Preserve resource_name / resource_url augmentation logic as-is.
   - Emit OAUTH_DISCOVERY_SERVED with details:
     {"endpoint": "oauth-authorization-server-by-name",
      "issuer": config.gateway.gateway_base_url,
      "resource_path": request_path,
      "client_ip": <extracted>, "user_agent": <from headers>}

3. Add a code comment to okta_agent_proxy/auth/okta_validator.py at the iss
   validation site (search for the token validation method; the iss check
   compares the token's iss claim against the configured issuer). The
   comment should explain:
   - The inbound validator validates iss against OKTA_ISSUER, NOT GATEWAY_BASE_URL.
   - This is intentional BFF divergence (per RFC 8414 §3.3 discussion in
     docs/prompts/RFC8414_ISSUER_FIX_PROMPTS.md).
   - Okta is the actual token signer; the adapter fronts discovery only.
   Do NOT change any validation logic.

4. Grep app.py for any remaining occurrences of `"issuer": okta_issuer` or
   equivalent patterns in the .well-known handlers and confirm zero matches
   after the change.

5. Update or create tests/test_oauth_discovery.py with 14+ tests:
   - oauth-authorization-server: issuer equals gateway_base_url (not Okta)
   - oauth-authorization-server: authorization_endpoint, token_endpoint,
     jwks_uri, registration_endpoint all start with gateway_base_url
   - oauth-authorization-server: NO Okta domain anywhere in response
     (assert that okta_domain does not appear as a substring of any value)
   - oauth-authorization-server-by-name/{resource}: issuer equals
     gateway_base_url
   - oauth-authorization-server-by-name/{resource}: authorization_endpoint
     points at the gateway (not Okta)
   - oauth-authorization-server-by-name/{resource}: jwks_uri points at
     the gateway
   - oauth-authorization-server-by-name/{resource}: NO Okta domain in response
   - Both: code_challenge_methods_supported includes "S256"
   - Both: client_id_metadata_document_supported is true on root handler
   - Both: response Content-Type is application/json
   - Both: response is HTTP 200
   - §3.3 byte-identity: oauth-authorization-server issuer == oauth-protected-resource
     authorization_servers[0] (byte-for-byte string equality)
   - OAUTH_DISCOVERY_SERVED audit event emitted on root handler with expected fields
   - OAUTH_DISCOVERY_SERVED audit event emitted on by-name handler with resource_path

   Update any existing test that asserted Okta's domain in discovery metadata
   (search tests/ for "iss" / "issuer" / Okta domain expectations in discovery
   responses). Document the updates in the commit message.

6. Run: pytest tests/test_oauth_discovery.py -v
   Then: pytest tests/ -x -q
   ALL tests must pass.

Do NOT add the /oauth2/v1/keys route in this prompt — that is R4. Tests for
discovery must NOT depend on the JWKS endpoint existing; they only assert the
advertised URL shape.

Do NOT modify oauth_authorize — the traditional-client branch already does
the right thing for §3.3 purposes. R5 adds audit emission there.
```

**Expected Output:** Both discovery handlers return `issuer = gateway_base_url` with byte-identical PRM↔AS-metadata contract, `OAUTH_DISCOVERY_SERVED` audit emissions, BFF-divergence comment in `okta_validator.py`, 14+ new tests passing, full suite green.

---

### Prompt R3: Delete `metadata.py::get_protected_resource_metadata()` Dead Code

**Context:** `okta_agent_proxy/metadata.py` contains a PRM generator that still advertises Okta as the authorization server — contradicts the live handler in `app.py`. It is imported only by `main.py:74` and `tests/test_okta_auth.py`. Delete it to prevent future drift.

**Prompt:**

```
Delete okta_agent_proxy/metadata.py::get_protected_resource_metadata() and
its importers. The function contradicts the live PRM handler in app.py and
serves no runtime purpose.

Read the existing codebase, especially:
- okta_agent_proxy/metadata.py — the function to remove
- okta_agent_proxy/main.py:74 — importer #1
- tests/test_okta_auth.py:21 and :343 — importer #2
- okta_agent_proxy/app.py:392-407 — the live PRM handler that stays

Execute the following:

1. Determine whether main.py:74 actually CALLS get_protected_resource_metadata()
   (vs just imports it). Show the import block and any call sites in the
   edit description.
   - If main.py calls it: evaluate what the call site expects. If it's
     populating some metadata surface, redirect that surface to read the
     same JSON shape that oauth_protected_resource() returns, OR remove the
     call site entirely if it's unused/dead. Prefer removal.
   - If main.py only imports it without calling: remove the import line.

2. In tests/test_okta_auth.py:
   - Line 21: remove the import.
   - Line 343: examine the test and either (a) rewrite it to hit the live
     /.well-known/oauth-protected-resource endpoint via the test client, or
     (b) delete the test if it's duplicated by tests in test_oauth_discovery.py
     (from R2) or elsewhere. Prefer (a) — we want an assertion that PRM
     advertises gateway_base_url, not Okta.

3. Delete okta_agent_proxy/metadata.py entirely. Confirm no other importers
   exist via grep:
   grep -rn "from okta_agent_proxy.metadata" --include="*.py"
   grep -rn "from .metadata import" --include="*.py"
   grep -rn "import metadata" okta_agent_proxy/

4. If any other file imports from metadata.py beyond the two identified,
   stop and report them rather than deleting blindly.

5. Run: pytest tests/ -x -q
   ALL tests must pass.

This prompt is a pure cleanup. The §3.3 compliance fix lands in R2; R3 just
removes a divergent surface that could drift.
```

**Expected Output:** `metadata.py` deleted, `main.py:74` import removed (and call site if any), `tests/test_okta_auth.py` rewritten or cleaned, full suite green.

---

### Prompt R4: JWKS Proxy at `/oauth2/v1/keys`

**Context:** After R2, discovery advertises `jwks_uri = f"{GATEWAY_BASE_URL}/oauth2/v1/keys"`, so that endpoint must serve a valid JWKS. The simplest approach is to re-serve Okta's JWKS — the keys themselves remain Okta's because Okta remains the only token signer. Note: this endpoint is for inbound clients validating tokens issued via the BFF flow; the outbound plane (backend MCP servers validating ID-JAG-issued tokens) is unaffected and continues to fetch JWKS directly from Okta's custom auth server.

**Prompt:**

```
Add a JWKS proxy endpoint at /oauth2/v1/keys that re-serves Okta's JWKS under
the adapter's origin.

Read the existing codebase, especially:
- okta_agent_proxy/auth/okta_validator.py:139 — fetch_jwks() async method
  on OktaTokenValidator (uses cachetools.TTLCache at self.jwks_cache,
  TTL default 3600s at line 50)
- okta_agent_proxy/auth/okta_validator.py:99-101 — jwks_cache attribute
- okta_agent_proxy/app.py — identify how the existing handlers get a reference
  to the OktaTokenValidator singleton (module-level, app state, or per-request).
  Search for "OktaTokenValidator(" and "okta_validator" to find the pattern.
- okta_agent_proxy/app.py:2558-2576 — route table where /oauth2/v1/token is
  mounted (place the new route next to it)
- okta_agent_proxy/audit/events.py — confirm OAUTH_JWKS_PROXY_HIT and
  OAUTH_JWKS_PROXY_MISS exist (added in R1)

Execute the following:

1. Add a new handler in app.py:

   async def oauth_jwks(request: Request) -> JSONResponse:
       """
       JWKS proxy endpoint.

       The AS metadata (R2) advertises jwks_uri = {GATEWAY_BASE_URL}/oauth2/v1/keys.
       Per RFC 8414 §3.3 and the BFF pattern, jwks_uri must be under the
       adapter's issuer. The keys themselves are Okta's — the adapter does
       not sign tokens; it only re-serves Okta's JWKS so clients fetch it
       from a URL consistent with the AS issuer.

       This serves the inbound plane only. The outbound plane (backend MCP
       servers) fetches JWKS from Okta's custom auth server directly and
       does not use this endpoint.

       Returns 503 if Okta's JWKS is unavailable; we do not synthesize an
       empty JWKS because that would let signature verification "succeed"
       against zero keys on misconfigured clients.
       """

2. Implementation:
   - Obtain the OktaTokenValidator instance using the same pattern as the
     rest of app.py (match the discovery of the singleton — likely a
     module-level variable or accessible via app state).
   - Check whether the validator's jwks_cache currently holds "jwks"
     (per fetch_jwks() logic at okta_validator.py:150-152). If it does,
     this is a cache hit — emit OAUTH_JWKS_PROXY_HIT (severity=info).
     If it does not, it's a cache miss — emit OAUTH_JWKS_PROXY_MISS
     (severity=info) after the successful fetch.
   - Call `await validator.fetch_jwks()` — do NOT add a second cache layer.
   - On upstream failure (fetch_jwks raises): emit OAUTH_JWKS_PROXY_MISS
     with severity=warning and return JSONResponse with status 503 and body
     {"error": "jwks_unavailable"}. Do NOT return an empty {"keys": []}.
   - Set Cache-Control: "public, max-age=<ttl>" on the response, where ttl
     is read from the validator's _jwks_cache_ttl attribute (defaults to 3600).
   - Set Content-Type: application/json (JSONResponse does this by default).

3. Mount the route in app.py next to /oauth2/v1/token:

   Route("/oauth2/v1/keys", oauth_jwks, methods=["GET"]),

   Match the CORS/method handling used for nearby OAuth endpoints.

4. Create tests/test_oauth_jwks_proxy.py with 10+ tests:
   - GET returns 200 with a "keys" array containing at least one entry
     (mock fetch_jwks to return a realistic JWKS dict)
   - Returned JWKS structure matches what fetch_jwks returns (no transformation)
   - Cache-Control header is set with max-age matching the validator TTL
   - Content-Type is application/json
   - Upstream failure (fetch_jwks raises) returns 503 with
     {"error": "jwks_unavailable"}
   - Upstream failure does NOT return empty {"keys": []}
   - OAUTH_JWKS_PROXY_HIT is emitted when the validator's cache already
     contains "jwks" before the request
   - OAUTH_JWKS_PROXY_MISS is emitted when the cache is empty and fetch
     succeeds
   - OAUTH_JWKS_PROXY_MISS (warning severity) is emitted on upstream failure
   - Multiple concurrent GET requests hit the cache — verify fetch_jwks is
     called at most once across 10 concurrent requests (this is a property
     of the validator's existing cache, not a new feature; the test confirms
     we didn't break it by wrapping)
   - Non-GET methods return 405

5. Run: pytest tests/test_oauth_jwks_proxy.py -v
   Then: pytest tests/ -x -q
   ALL tests must pass.

After this prompt: the jwks_uri advertised by R2's discovery handlers
actually resolves and returns valid Okta signing keys.
```

**Expected Output:** Working `/oauth2/v1/keys` proxy that re-serves Okta's JWKS via the existing validator cache, audit events on hit/miss, 10+ new tests passing, full suite green.

---

### Prompt R5: Audit Emission on Traditional-Client Branch of `oauth_authorize`

**Context:** `oauth_authorize` (`app.py:1033-1297`) already handles CIMD, DCR-linked, DCR-unlinked, and traditional clients correctly. The CIMD and DCR branches emit appropriate audit events. The **traditional-client branch** (`app.py:1279-1297`) — which 302-redirects non-CIMD, non-DCR clients to Okta — has no audit emission. Add `OAUTH_AUTHORIZE_RELAYED` on success and `OAUTH_AUTHORIZE_RELAY_FAILED` on the early `invalid_request` 400 at line 1062-1066. Do NOT modify CIMD or DCR branches.

**Prompt:**

```
Add OAUTH_AUTHORIZE_RELAYED and OAUTH_AUTHORIZE_RELAY_FAILED audit emissions
to the traditional-client branch of oauth_authorize. Do NOT modify CIMD or
DCR branches — they already emit DCR_AUTHORIZE_* / CIMD_* events.

Read the existing codebase, especially:
- okta_agent_proxy/app.py:1033-1297 — full oauth_authorize handler
- okta_agent_proxy/app.py:1062-1066 — early 400 on missing client_id (applies
  to ALL branches, including traditional; this is where RELAY_FAILED fires)
- okta_agent_proxy/app.py:1186-1205 — existing DCR_AUTHORIZE_RELAYED /
  DCR_AUTHORIZE_RELAY_FAILED emission pattern (follow this shape)
- okta_agent_proxy/app.py:1279-1297 — traditional-client branch to instrument
- okta_agent_proxy/audit/__init__.py:70 — emit_audit_event() signature
- okta_agent_proxy/audit/events.py — confirm OAUTH_AUTHORIZE_RELAYED and
  OAUTH_AUTHORIZE_RELAY_FAILED exist (added in R1)

Execute the following:

1. At the early 400 (app.py:1062-1066, missing client_id), emit
   OAUTH_AUTHORIZE_RELAY_FAILED BEFORE the return:

   await emit_audit_event(
       AuditEventType.OAUTH_AUTHORIZE_RELAY_FAILED,
       severity=AuditSeverity.WARNING,
       details={
           "error": "invalid_request",
           "error_description": "client_id is required",
       },
       outcome="failure",
   )

   Do NOT include client_id (it's missing by definition).
   Do NOT include redirect_uri, state, or code_challenge — those may be
   present but leaking them on a 400 adds noise without value.

2. At the traditional-client branch (app.py:1279-1297), AFTER the okta_url is
   built and BEFORE the RedirectResponse return, emit OAUTH_AUTHORIZE_RELAYED:

   # Extract host-only redirect_uri for privacy (no path/query)
   from urllib.parse import urlparse
   redirect_host = urlparse(redirect_uri).netloc if redirect_uri else ""
   upstream_host_path = f"{urlparse(okta_url).scheme}://{urlparse(okta_url).netloc}{urlparse(okta_url).path}"

   await emit_audit_event(
       AuditEventType.OAUTH_AUTHORIZE_RELAYED,
       details={
           "client_id": client_id,
           "redirect_uri_host": redirect_host,   # host only
           "scope": scope or "",
           "resource": target_resource or "",    # RFC 8707
           "upstream_authorize_url": upstream_host_path,  # no query
       },
   )

   CRITICAL privacy rules — the audit payload must NOT contain:
   - code_challenge values (PKCE secrets)
   - state values (client session correlator)
   - full redirect_uri with query string
   - full upstream URL with query string

   These can leak info about the client session or be reused across requests.

3. Do NOT touch the CIMD branch (app.py:1068-1138).
   Do NOT touch either DCR branch (app.py:1140-1277).

4. Create tests/test_oauth_authorize_audit.py with 8+ tests:
   - Missing client_id triggers OAUTH_AUTHORIZE_RELAY_FAILED with
     severity=WARNING and outcome=failure
   - OAUTH_AUTHORIZE_RELAY_FAILED payload contains error and error_description
   - OAUTH_AUTHORIZE_RELAY_FAILED payload does NOT contain client_id
   - Traditional-client success (opaque client_id, no dcr_ prefix, not a URL)
     triggers OAUTH_AUTHORIZE_RELAYED
   - OAUTH_AUTHORIZE_RELAYED payload contains client_id, redirect_uri_host
     (host only), scope, resource, upstream_authorize_url (no query)
   - OAUTH_AUTHORIZE_RELAYED payload does NOT contain code_challenge
   - OAUTH_AUTHORIZE_RELAYED payload does NOT contain state
   - OAUTH_AUTHORIZE_RELAYED payload redirect_uri_host does NOT contain
     path or query (e.g., if redirect_uri = "https://host/cb?x=1",
     redirect_uri_host is "host" or "https://host" only)
   - CIMD client requests do NOT emit OAUTH_AUTHORIZE_RELAYED (they emit
     CIMD events instead); verify by checking that the OAUTH_* event is
     absent from the audit sink after a CIMD request
   - DCR-linked client requests do NOT emit OAUTH_AUTHORIZE_RELAYED (they
     emit DCR_AUTHORIZE_RELAYED instead)

5. Run: pytest tests/test_oauth_authorize_audit.py -v
   Then: pytest tests/ -x -q
   ALL tests must pass.

Do NOT add response_type or code_challenge_method validation to the
traditional-client branch in this prompt — the user explicitly chose
"audit emission only" for this scope during plan review.
```

**Expected Output:** `OAUTH_AUTHORIZE_RELAYED` / `OAUTH_AUTHORIZE_RELAY_FAILED` emitted on the traditional-client branch with privacy-safe payloads. CIMD and DCR branches untouched. 8+ new tests passing, full suite green.

---

### Prompt R6: RFC 8414 §3.3 End-to-End Round-Trip Test

**Context:** The programmatic equivalent of the curl-based verification in the doc's "Verification" section. This is the test a security reviewer would re-run to confirm the finding is closed. Includes it in CI so the contract is enforced on every PR.

**Prompt:**

```
Add an end-to-end RFC 8414 §3.3 compliance test that replicates the
security-tester round-trip programmatically.

Read the existing codebase, especially:
- tests/conftest.py — test client fixtures, app/config fixtures
- okta_agent_proxy/app.py — route table, handlers wired in R2/R4

Execute the following:

1. Create tests/test_rfc8414_compliance_e2e.py with 6+ tests.

   Each test uses the Starlette TestClient against the full application.
   Mock external calls (Okta JWKS fetch) as needed so the test runs
   without network access.

   Tests to include:

   Test 1: PRM advertises exactly one authorization_servers entry equal
   to gateway_base_url.
   - GET /.well-known/oauth-protected-resource
   - Assert response is 200
   - Assert authorization_servers is a list with exactly one element
   - Assert authorization_servers[0] == config.gateway.gateway_base_url

   Test 2: AS metadata issuer is byte-identical to PRM's
   authorization_servers[0] (the §3.3 contract).
   - GET /.well-known/oauth-protected-resource → extract PRM_ISSUER
   - Construct the AS metadata URL: PRM_ISSUER +
     "/.well-known/oauth-authorization-server"
   - Since tests run against the same app, hit
     /.well-known/oauth-authorization-server directly on the test client
   - Extract AS_ISSUER from the response
   - Assert PRM_ISSUER == AS_ISSUER (byte-equal string comparison,
     no normalization)

   Test 3: AS metadata is fully self-consistent under gateway_base_url.
   - GET /.well-known/oauth-authorization-server
   - Assert issuer, authorization_endpoint, token_endpoint, jwks_uri,
     registration_endpoint all start with gateway_base_url
   - Assert no occurrence of okta_domain in any value (as a substring)

   Test 4: All endpoints advertised by AS metadata actually respond.
   - GET /.well-known/oauth-authorization-server → extract endpoint URLs
   - For authorization_endpoint: GET with client_id+redirect_uri+response_type=code
     +code_challenge+code_challenge_method=S256 returns 302
   - For authorization_endpoint: GET without client_id returns 400
   - For jwks_uri: GET returns 200 with a keys array
   - For registration_endpoint: GET returns 200 or 501
     (depending on DCR config)

   Test 5: Per-resource AS metadata is also §3.3 compliant.
   - Seed a resource (use existing sample_resource fixture or create one)
   - GET /.well-known/oauth-authorization-server/{resource_name}
   - Assert issuer == gateway_base_url
   - Assert jwks_uri points at gateway
   - Assert authorization_endpoint points at gateway

   Test 6: Per-resource PRM also points at gateway.
   - GET /.well-known/oauth-protected-resource/{resource_name}
   - Assert authorization_servers[0] == gateway_base_url
   - Assert resource is under gateway_base_url

2. Add a module docstring at the top of the test file explaining:
   - This test file is the programmatic equivalent of the security-review
     round-trip.
   - The §3.3 contract is: PRM.authorization_servers[0] byte-equals
     AS_metadata.issuer, and both equal GATEWAY_BASE_URL.
   - If any test in this file fails, §3.3 compliance has regressed and
     the security finding will reopen.

3. Run: pytest tests/test_rfc8414_compliance_e2e.py -v
   Then: pytest tests/ -x -q
   ALL tests must pass.

After this prompt: the §3.3 compliance fix is complete, CI enforces the
contract on every PR, and the security finding can be re-tested and closed.
```

**Expected Output:** `tests/test_rfc8414_compliance_e2e.py` with 6+ tests covering the §3.3 round-trip, all green.

---

## Verification (After All 6 Prompts)

These are the manual checks to run after the full sequence completes. They mirror what a security tester would run.

### 1. PRM advertises the adapter as the AS issuer

```bash
curl -s https://st-okta-mcp-adapter-demo.up.railway.app/.well-known/oauth-protected-resource | jq .authorization_servers
```

Expected: `["https://st-okta-mcp-adapter-demo.up.railway.app"]` — exactly one entry, exactly the adapter URL.

### 2. AS metadata `issuer` byte-matches the value from PRM

```bash
PRM_ISSUER=$(curl -s https://st-okta-mcp-adapter-demo.up.railway.app/.well-known/oauth-protected-resource | jq -r '.authorization_servers[0]')

AS_ISSUER=$(curl -s "${PRM_ISSUER}/.well-known/oauth-authorization-server" | jq -r .issuer)

[ "$PRM_ISSUER" = "$AS_ISSUER" ] && echo "PASS: §3.3 byte-identity holds" || echo "FAIL"
```

Expected: `PASS: §3.3 byte-identity holds`.

### 3. AS metadata is fully self-consistent

```bash
curl -s https://st-okta-mcp-adapter-demo.up.railway.app/.well-known/oauth-authorization-server | jq .
```

Expected:
- `issuer == "https://st-okta-mcp-adapter-demo.up.railway.app"`
- `authorization_endpoint`, `token_endpoint`, `jwks_uri`, `registration_endpoint` all start with the same URL
- No occurrences of any Okta domain anywhere in the response

### 4. JWKS proxy returns Okta's keys under the adapter origin

```bash
curl -s https://st-okta-mcp-adapter-demo.up.railway.app/oauth2/v1/keys | jq '.keys | length'
```

Expected: number > 0.

### 5. Authorize endpoint 302s to Okta

```bash
curl -s -o /dev/null -w "%{http_code} %{redirect_url}\n" \
  "https://st-okta-mcp-adapter-demo.up.railway.app/oauth/authorize?client_id=test&redirect_uri=https://example.com/cb&response_type=code&code_challenge=abc&code_challenge_method=S256&state=xyz"
```

Expected: `302 https://servicetitan.oktapreview.com/oauth2/<asId>/v1/authorize?client_id=test&...` with all params preserved.

### 6. Per-resource AS metadata is also compliant

```bash
curl -s https://st-okta-mcp-adapter-demo.up.railway.app/.well-known/oauth-authorization-server/hr | jq .issuer
```

Expected: same gateway URL — not Okta's domain.

### 7. Client matrix smoke test (staging only — see Rollback Plan)

After deploying to staging, run the OAuth flow against the new metadata with each known-working client:
- Claude Code
- Cursor
- VS Code MCP integration
- Any AgentCore / Foundry test rigs in scope

Expected: every client that works against the current (broken) metadata also works against the fixed metadata.

---

## Rollback Plan

The current state is functional for known clients despite the §3.3 violation. A breaking change in the new state is unlikely but possible if any client has its own bugs that depend on the current broken shape. Therefore:

1. **Deploy to staging first.** Confirm `GATEWAY_BASE_URL` is set to the staging URL (already set in current environments). Run the full client matrix from Verification step 7. Do not promote to production until every currently-working client passes against the new metadata.
2. **Production rollback path.** If a regression surfaces in production:
   - Revert R2 (both discovery handlers) to restore the previous `issuer: okta_issuer` behavior. The adapter goes back to the broken-but-known state — known-working clients keep working, the security finding reopens.
   - R1 (config validation + audit events), R3 (metadata.py deletion), R4 (JWKS proxy), R5 (audit emission), R6 (E2E test) are safe to leave in place. They don't change existing client-visible behavior once R2 is reverted, except R4 which adds a new endpoint that is harmless if clients stop fetching it (they will, once R2 is reverted and `jwks_uri` points back to Okta).
   - If R1's tightened `GATEWAY_BASE_URL` validation rejects a previously-accepted value at startup, revert R1 separately or fix the env value. This is a deliberate failure mode catching misconfigurations.
3. **No urgency.** This is a P1 security-finding remediation, not a P0 production-down fix. The current state works. Take the time to gate properly.

---

## Local Testing Considerations

The §3.3 constraint and the loopback-host carve-out interact in one specific way worth understanding:

**The constraint is `PRM_ISSUER == AS_METADATA_ISSUER`, not "request Host header == issuer."**

So local-dev with `GATEWAY_BASE_URL=http://localhost:8000` works as long as:
- The MCP client is on the same machine and can reach `http://localhost:8000`
- PRM returns `authorization_servers: ["http://localhost:8000"]`
- AS metadata returns `issuer: "http://localhost:8000"`
- These two strings are byte-identical (no trailing slash, no scheme/case drift)

The §3.3 check then passes because the client constructed `http://localhost:8000/.well-known/oauth-authorization-server` from PRM, fetched it, and got back `issuer: http://localhost:8000` — byte-match.

**What does NOT work in local dev:** running the client on a different machine and hitting the adapter via LAN IP while `GATEWAY_BASE_URL=http://localhost:8000`. The PRM returned to the client will still say the issuer is `http://localhost:8000`, which the client then tries to fetch from *its own* machine — connection refused. Fix: set `GATEWAY_BASE_URL` to whatever URL the client can actually reach (LAN IP, DNS name, ngrok tunnel, etc.).

**The loopback carve-out in R1** allows `http://` for `localhost`, `127.0.0.1`, `::1`, and `*.localhost` (RFC 6761 §6.3) — so multi-instance local dev with hostnames like `adapter1.localhost`, `adapter2.localhost` works without TLS. RFC 8414 §2 itself does not mention localhost; the carve-out is grounded in the broader OAuth ecosystem (RFC 8252 §7.3, MCP Python SDK practice) which treats loopback addresses as having implicit security guarantees that don't require TLS.

---

## Success Criteria

After all 6 prompts complete and all tests pass:

1. `curl -s https://<adapter>/.well-known/oauth-authorization-server | jq .issuer` returns the adapter URL — not Okta's domain.
2. `curl -s https://<adapter>/.well-known/oauth-protected-resource | jq .authorization_servers[0]` returns the same adapter URL, byte-identical.
3. The §3.3 round-trip (Verification step 2) passes programmatically via `tests/test_rfc8414_compliance_e2e.py`.
4. `/oauth2/v1/keys` exists and returns Okta's JWKS under the adapter origin.
5. `oauth_authorization_server_by_name` is also §3.3 compliant (not just the root handler).
6. The traditional-client branch of `/oauth/authorize` emits `OAUTH_AUTHORIZE_RELAYED` / `OAUTH_AUTHORIZE_RELAY_FAILED` without leaking PKCE secrets, state, or full redirect URIs.
7. Every client in the staging matrix that worked against the old metadata works against the new metadata (no regressions).
8. The full existing test suite continues passing (no regressions).
9. New audit events (`OAUTH_DISCOVERY_SERVED`, `OAUTH_JWKS_PROXY_HIT`, `OAUTH_JWKS_PROXY_MISS`, `OAUTH_AUTHORIZE_RELAYED`, `OAUTH_AUTHORIZE_RELAY_FAILED`) emit correctly and are observable in Grafana/Loki.
10. The inbound JWT `iss` validation in `okta_validator.py` is unchanged and still validates against `OKTA_ISSUER` — this divergence is documented in code with a reference to RFC 8414 §3.3 and the BFF pattern.
11. `okta_agent_proxy/metadata.py::get_protected_resource_metadata()` is deleted; no divergent PRM shape remains in the codebase.
12. The original security finding can be re-tested and is closed.

---

## Notes for Claude Code

- Run prompts strictly in order R1 → R2 → R3 → R4 → R5 → R6.
- After each prompt, run the full test suite: `pytest tests/ -x -q`.
- If any existing test asserts Okta's domain in discovery metadata, update it as part of R2 (not before, not after) and document the change in the commit message.
- Do not skip the audit event additions — discovery traffic visibility is a P0 requirement per the standing project rule that every prompt touching auth paths must add audit events.
- `GATEWAY_BASE_URL` MUST be set correctly in production environments — R1's startup-time validation enforces the shape. Railway / staging / prod already set this; verify values are trailing-slash-free and use https.
- For local development, `GATEWAY_BASE_URL=http://localhost:8000` is the default and passes R1 validation per the ecosystem-standard loopback carve-out.
- The four plan-review decisions are **non-negotiable** and encoded in this doc:
  1. Do NOT add `ADAPTER_ISSUER` — reuse `GATEWAY_BASE_URL`.
  2. Delete `metadata.py::get_protected_resource_metadata()` in R3.
  3. Fix both `oauth_authorization_server` AND `oauth_authorization_server_by_name` in R2.
  4. R5 scope is audit emission only — do not rewrite `oauth_authorize`, do not modify CIMD/DCR branches, do not add validation rules to the traditional-client branch.
