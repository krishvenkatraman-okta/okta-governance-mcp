> **Historical (pre-v0.15.x):** Password-based admin login references in this document are obsolete. The adapter accepts only Okta OAuth access tokens — see [docs/OPERATIONS.md § Admin API Authentication](../OPERATIONS.md#admin-api-authentication).

# Okta MCP Adapter — Phase 2 Correction Prompt

## AZ13: Remove Non-Required Okta Environment Variables

**1 prompt • Corrective • Applies after AZ7–AZ12 have been executed**

---

## Why this prompt exists

While authoring AZ7–AZ12, I incorrectly flagged four environment variables as required for the adapter to run. After verifying against the actual source code in `okta_agent_proxy/config.py`, only `OKTA_DOMAIN` is required. The four variables I wrongly included were:

| Variable | Reality |
|---|---|
| `OKTA_ISSUER` | Optional. `config.py` derives it as `https://<OKTA_DOMAIN>` if unset. The `deploy/bundle/README.md` explicitly documents this: "Okta currently requires the Org authorization server for AI Agent token exchange. `OKTA_ISSUER` is provided for future use when Okta adds custom auth server support." |
| `OKTA_AUTHORIZATION_SERVER_ID` | **Not in `GatewaySettings` at all.** It appears as a pass-through env var in some docker-compose files but the actual adapter config model has no such field. It's a ghost from an earlier iteration. |
| `OKTA_RELAY_CLIENT_ID` | Wrong name (actual name in the codebase is `RELAY_OKTA_CLIENT_ID`) AND wrong scope. The `confidential_relay.py` module docstring explicitly states: "Each CIMD-matched agent must have client_id and client_secret configured in its database record... **there are no global relay credentials.**" CIMD credentials now live per-agent in PostgreSQL, configured via the Admin UI after deployment. |
| `OKTA_RELAY_CLIENT_SECRET` | Same as above. |

The correct picture: `OKTA_DOMAIN` is the only required Okta env var for Phase 2. CIMD (Confidential Client Registration) is an opt-in feature configured per-agent via the Admin UI after the adapter is running.

This prompt walks Claude Code through removing the unnecessary variables from every place they were introduced in AZ7–AZ12, without disturbing anything else that's working.

## What this prompt changes

**AKS wizard** (`deploy/azure-aks/`)
- `azuresetup.sh` Phase 2 prereq block (AZ7) — remove 4 env var loads, validations, and state saves
- `azuresetup.sh` Phase 2 Key Vault secrets (AZ9) — drop `okta-relay-client-id` and `okta-relay-client-secret` from the 6-secret list, leaving 4
- `.env.example` — remove the 4 variables
- `README.md` — remove the 4 from the required list, add a note about CIMD being configured via the Admin UI

**ACA wizard** (`deploy/azure-aca/`)
- `acasetup.sh` Phase 2 prereq block (AZ10) — remove 4 env var loads, validations, and state saves
- `bicep/main.bicep` — remove `oktaRelayClientId`, `oktaRelayClientSecret`, `oktaIssuer`, `oktaAuthorizationServerId` parameters; remove them from the adapter container's `secrets` and `env` arrays
- `acasetup.sh` Phase 2 params.json (AZ11) — remove 4 parameter entries
- `.env.example` — remove the 4 variables
- `README.md` — same treatment as the AKS wizard

**Manifest templates** (`deploy/azure-aks/manifests/`) — only touches `02-configmap.yaml` to remove `OKTA_ISSUER` and `OKTA_AUTHORIZATION_SERVER_ID` from the ConfigMap (they were placeholders from AZ3 that would have been substituted in Phase 3, but now never need to be). The other manifests already had correct content.

**Existing state files** — if the operator has a populated `.azuresetup.state` or `.acasetup.state` from a previous real Azure run, this prompt does NOT touch them. The state file entries will be stale but harmless. The README addition tells operators how to clean them up with `sed` if they care.

## Prerequisites

- AZ7–AZ12 have been run and committed
- The Azure wizards have NOT been run to completion against a real subscription yet (OR have been, but the deployment has been torn down)
- Branch: whatever branch AZ7–AZ12 landed on (typically `feat/azure-scripted-deploy`)

## How to Execute

```bash
cd okta-agent-mcp-adapter
git checkout feat/azure-scripted-deploy
# Paste the prompt body below into Claude Code.
git add -A && git commit -m "AZ13: remove non-required Okta env vars (OKTA_ISSUER, OKTA_AUTHORIZATION_SERVER_ID, OKTA_RELAY_CLIENT_*)"
```

---

## Prompt AZ13: Remove Non-Required Okta Env Vars

### Context

AZ7–AZ12 incorrectly treated `OKTA_ISSUER`, `OKTA_AUTHORIZATION_SERVER_ID`, `OKTA_RELAY_CLIENT_ID`, and `OKTA_RELAY_CLIENT_SECRET` as required Phase 2 inputs. Verification against `okta_agent_proxy/config.py` and `okta_agent_proxy/auth/confidential_relay.py` confirms only `OKTA_DOMAIN` is required. `OKTA_ISSUER` is auto-derived. `OKTA_AUTHORIZATION_SERVER_ID` is not in the config model. The relay credentials now live per-agent in the database, configured via the Admin UI after deployment.

This prompt surgically removes the unnecessary variables from both wizards, both Bicep/manifest templates, both `.env.example` files, both READMEs, and both wizards' Phase 2 Okta handling and Key Vault / Bicep parameter blocks.

### Prompt

*Copy the text below into Claude Code:*

```
Remove the four non-required Okta environment variables from the
Azure wizards and their supporting files. Only OKTA_DOMAIN should
remain as a required Okta input for Phase 2.

Variables being removed:
  - OKTA_ISSUER                   (auto-derived from OKTA_DOMAIN)
  - OKTA_AUTHORIZATION_SERVER_ID  (not in GatewaySettings config)
  - OKTA_RELAY_CLIENT_ID          (wrong name + now per-agent in DB)
  - OKTA_RELAY_CLIENT_SECRET      (same)

Do NOT touch any other Phase 2 logic. The goal is a minimal surgical
edit to remove these four variables and nothing else. After this
prompt, the wizards should still pass bash -n and the Bicep should
still build.

===================================================================
PART A — AKS Wizard (deploy/azure-aks/)
===================================================================

A.1 — Edit deploy/azure-aks/azuresetup.sh

In run_phase_2(), find the "Step 2.1: Load and validate Okta
configuration..." block added by AZ7. Currently it loads 5 Okta
variables. Remove the 4 non-required ones while keeping OKTA_DOMAIN.

Before (current state from AZ7):

  info "Step 2.1: Loading Okta configuration..."

  # Allow loading from state if already saved on a previous Phase 2 run
  OKTA_DOMAIN="${OKTA_DOMAIN:-$(get_state OKTA_DOMAIN)}"
  OKTA_ISSUER="${OKTA_ISSUER:-$(get_state OKTA_ISSUER)}"
  OKTA_AUTHORIZATION_SERVER_ID="${OKTA_AUTHORIZATION_SERVER_ID:-$(get_state OKTA_AUTHORIZATION_SERVER_ID)}"
  OKTA_RELAY_CLIENT_ID="${OKTA_RELAY_CLIENT_ID:-$(get_state OKTA_RELAY_CLIENT_ID)}"
  OKTA_RELAY_CLIENT_SECRET="${OKTA_RELAY_CLIENT_SECRET:-$(get_state OKTA_RELAY_CLIENT_SECRET)}"

  # If still missing in non-interactive mode, fail loud
  if $NON_INTERACTIVE; then
    for var in OKTA_DOMAIN OKTA_ISSUER OKTA_AUTHORIZATION_SERVER_ID \
               OKTA_RELAY_CLIENT_ID OKTA_RELAY_CLIENT_SECRET; do
      if [[ -z "${!var}" ]]; then
        die "$var not set in env, .env, or state file (non-interactive mode)"
      fi
    done
  else
    [[ -z "$OKTA_DOMAIN" ]] && \
      prompt_required OKTA_DOMAIN "Okta domain (e.g. yourorg.okta.com)"
    [[ -z "$OKTA_ISSUER" ]] && \
      prompt_required OKTA_ISSUER "Okta issuer URL (e.g. https://yourorg.okta.com/oauth2/<id>)"
    [[ -z "$OKTA_AUTHORIZATION_SERVER_ID" ]] && \
      prompt_required OKTA_AUTHORIZATION_SERVER_ID "Okta authorization server ID"
    [[ -z "$OKTA_RELAY_CLIENT_ID" ]] && \
      prompt_required OKTA_RELAY_CLIENT_ID "Okta relay client ID"
    [[ -z "$OKTA_RELAY_CLIENT_SECRET" ]] && \
      prompt_required OKTA_RELAY_CLIENT_SECRET "Okta relay client secret"
  fi

  # Sanity-check the issuer URL
  if [[ ! "$OKTA_ISSUER" =~ ^https:// ]]; then
    die "OKTA_ISSUER must start with https://"
  fi
  if [[ ! "$OKTA_ISSUER" =~ /oauth2/ ]]; then
    warn "OKTA_ISSUER does not contain '/oauth2/' — this is unusual"
    if ! $NON_INTERACTIVE; then
      prompt_yesno "Continue anyway?" n || die "Aborted by operator"
    fi
  fi

  # Persist into state — these will be needed by Phase 3 too
  save_state OKTA_DOMAIN "$OKTA_DOMAIN"
  save_state OKTA_ISSUER "$OKTA_ISSUER"
  save_state OKTA_AUTHORIZATION_SERVER_ID "$OKTA_AUTHORIZATION_SERVER_ID"
  save_state OKTA_RELAY_CLIENT_ID "$OKTA_RELAY_CLIENT_ID"
  save_state OKTA_RELAY_CLIENT_SECRET "$OKTA_RELAY_CLIENT_SECRET"
  ok "Okta configuration loaded"

After (replace with):

  info "Step 2.1: Loading Okta configuration..."

  # Only OKTA_DOMAIN is required. The adapter's config.py derives
  # the issuer URL from OKTA_DOMAIN. CIMD relay credentials live
  # per-agent in the database and are configured via the Admin UI
  # after deployment.
  OKTA_DOMAIN="${OKTA_DOMAIN:-$(get_state OKTA_DOMAIN)}"

  if $NON_INTERACTIVE; then
    if [[ -z "$OKTA_DOMAIN" ]]; then
      die "OKTA_DOMAIN not set in env, .env, or state file (non-interactive mode)"
    fi
  else
    if [[ -z "$OKTA_DOMAIN" ]]; then
      prompt_required OKTA_DOMAIN "Okta domain (e.g. yourorg.okta.com)"
    fi
  fi

  # Validate the domain format
  if [[ ! "$OKTA_DOMAIN" =~ \.(okta\.com|oktapreview\.com)$ ]]; then
    warn "OKTA_DOMAIN does not end with .okta.com or .oktapreview.com"
    if ! $NON_INTERACTIVE; then
      prompt_yesno "Continue anyway?" n || die "Aborted by operator"
    fi
  fi

  save_state OKTA_DOMAIN "$OKTA_DOMAIN"
  ok "Okta configuration loaded (OKTA_DOMAIN=$OKTA_DOMAIN)"

A.2 — Edit deploy/azure-aks/azuresetup.sh (Step 2.15 secrets)

In run_phase_2(), find "Step 2.15: Write all 6 secrets to Key Vault"
from AZ9. Remove the 2 okta-relay secret writes and update the
comment to say "4 secrets":

Before:

  # Step 2.15: Write all 6 secrets to Key Vault
  info "Step 2.15: Writing secrets to Key Vault..."

  # ... (DATABASE_URL and REDIS_URL loading unchanged)

  set_kv_secret() {
    local name="$1" value="$2"
    az keyvault secret set --vault-name "$KV_NAME" --name "$name" \
      --value "$value" --output none
    ok "Secret written: $name"
  }

  set_kv_secret encryption-key "$ENCRYPTION_KEY"
  set_kv_secret admin-password "$ADMIN_PASSWORD"
  set_kv_secret database-url "$DATABASE_URL"
  set_kv_secret redis-url "$REDIS_URL"
  set_kv_secret okta-relay-client-id "$OKTA_RELAY_CLIENT_ID"
  set_kv_secret okta-relay-client-secret "$OKTA_RELAY_CLIENT_SECRET"

After:

  # Step 2.15: Write all 4 secrets to Key Vault
  # Note: CIMD relay credentials are NOT stored here. They live
  # per-agent in PostgreSQL and are managed via the Admin UI.
  info "Step 2.15: Writing secrets to Key Vault..."

  # ... (DATABASE_URL and REDIS_URL loading unchanged)

  set_kv_secret() {
    local name="$1" value="$2"
    az keyvault secret set --vault-name "$KV_NAME" --name "$name" \
      --value "$value" --output none
    ok "Secret written: $name"
  }

  set_kv_secret encryption-key "$ENCRYPTION_KEY"
  set_kv_secret admin-password "$ADMIN_PASSWORD"
  set_kv_secret database-url "$DATABASE_URL"
  set_kv_secret redis-url "$REDIS_URL"

A.3 — Edit deploy/azure-aks/azuresetup.sh (summary box)

In run_phase_2(), find the print_summary_box call at the end of
Phase 2. Update the line that mentions "6 written" to say "4 written"
and update the secret list accordingly. The expected current line is:

    "Secrets:     6 written (encryption-key, admin-password," \
    "             database-url, redis-url, 2x okta-relay)" \

Replace with:

    "Secrets:     4 written (encryption-key, admin-password," \
    "             database-url, redis-url)" \
    "             (CIMD relay credentials are per-agent in DB)" \

A.4 — Edit deploy/azure-aks/.env.example

Remove these 4 lines (the full group in the "Required — Okta" section):
  OKTA_ISSUER=
  OKTA_AUTHORIZATION_SERVER_ID=
  OKTA_RELAY_CLIENT_ID=
  OKTA_RELAY_CLIENT_SECRET=

Update the section header comment to say:

  # Required — Okta (needed starting in Phase 2)
  # Only OKTA_DOMAIN is required. The adapter auto-derives the
  # issuer URL. CIMD relay credentials live per-agent in the DB
  # and are configured via the Admin UI after deployment.
  OKTA_DOMAIN=

A.5 — Edit deploy/azure-aks/manifests/02-configmap.yaml

Currently the ConfigMap from AZ3 declares placeholders for 3 Okta
values:
  __OKTA_DOMAIN__, __OKTA_ISSUER__, __OKTA_AUTHORIZATION_SERVER_ID__

Remove the two non-required placeholders from:
  1. The header comment (placeholder declaration list)
  2. The ConfigMap data block

The updated header comment should only declare __OKTA_DOMAIN__.

The updated data block should contain:
  data:
    OKTA_DOMAIN: "__OKTA_DOMAIN__"
    CACHE_PROVIDER: "redis"
    REDIS_TLS_ENABLED: "true"
    REDIS_KEY_PREFIX: "okta-mcp:"
    LOG_LEVEL: "INFO"
    GATEWAY_PORT: "8000"

(Remove the OKTA_ISSUER and OKTA_AUTHORIZATION_SERVER_ID lines.)

A.6 — Edit deploy/azure-aks/README.md

In the "Prerequisites" section or wherever the Okta inputs are
listed, remove any reference to OKTA_ISSUER,
OKTA_AUTHORIZATION_SERVER_ID, OKTA_RELAY_CLIENT_ID, and
OKTA_RELAY_CLIENT_SECRET.

Add a new subsection under "Troubleshooting" titled "CIMD /
Confidential Relay Configuration" with this content:

  ### CIMD / Confidential Relay Configuration

  The adapter supports CIMD (Confidential Client Registration) for
  dynamic MCP client onboarding, but the relay credentials are NOT
  passed as environment variables to the adapter. Instead, they
  live per-agent in PostgreSQL and are configured via the Admin UI
  after deployment.

  To enable CIMD for a specific agent after the wizard finishes:

  1. Visit the Admin UI (https://<ADMIN_HOSTNAME>)
  2. Navigate to Agents → <agent name> → Edit
  3. Under "Okta OIDC Credentials", enter the client_id and
     client_secret for the relay OIDC application in your Okta org
  4. Save

  See `okta_agent_proxy/auth/confidential_relay.py` for the
  implementation details. Earlier versions of this wizard treated
  these credentials as global env vars — that was wrong and has
  been corrected.

===================================================================
PART B — ACA Wizard (deploy/azure-aca/)
===================================================================

B.1 — Edit deploy/azure-aca/acasetup.sh

In run_phase_2(), find "Step 2.1: Loading Okta configuration..."
from AZ10. Apply the same replacement as A.1 above — reduce from
5 variables to just OKTA_DOMAIN, with the same validation and
save_state logic.

B.2 — Edit deploy/azure-aca/bicep/main.bicep

Remove 4 parameter declarations from the top-level parameters block:
  @secure() oktaRelayClientId string
  @secure() oktaRelayClientSecret string
  oktaIssuer string
  oktaAuthorizationServerId string

Then inside the "okta-mcp-adapter" Container App resource:

1. Remove these 2 entries from the secrets[] array:
     { name: 'okta-relay-client-id', value: oktaRelayClientId }
     { name: 'okta-relay-client-secret', value: oktaRelayClientSecret }

2. Remove these 4 entries from the adapter container's env[] array:
     { name: 'OKTA_ISSUER', value: oktaIssuer }
     { name: 'OKTA_AUTHORIZATION_SERVER_ID', value: oktaAuthorizationServerId }
     { name: 'OKTA_RELAY_CLIENT_ID', secretRef: 'okta-relay-client-id' }
     { name: 'OKTA_RELAY_CLIENT_SECRET', secretRef: 'okta-relay-client-secret' }

3. Keep these (they are correct and required):
     { name: 'OKTA_DOMAIN', value: oktaDomain }
     { name: 'CACHE_PROVIDER', value: 'redis' }
     { name: 'REDIS_TLS_ENABLED', value: 'true' }
     { name: 'REDIS_KEY_PREFIX', value: 'okta-mcp:' }
     { name: 'LOG_LEVEL', value: 'INFO' }
     { name: 'GATEWAY_PORT', value: '8000' }
     { name: 'ENCRYPTION_KEY', secretRef: 'encryption-key' }
     { name: 'ADMIN_PASSWORD', secretRef: 'admin-password' }
     { name: 'DATABASE_URL', secretRef: 'database-url' }
     { name: 'REDIS_URL', secretRef: 'redis-url' }

The other two Container App resources (admin-ui, hr-mcp-server) do
not reference any of the removed parameters and should not be edited.

B.3 — Edit deploy/azure-aca/acasetup.sh (params.json generation)

In run_phase_2(), find the "Step 2.5: Write the Bicep parameters file"
block from AZ11. The heredoc currently writes 13 parameter entries.
Remove these 4:
  "oktaRelayClientId": { "value": "$OKTA_RELAY_CLIENT_ID" },
  "oktaRelayClientSecret": { "value": "$OKTA_RELAY_CLIENT_SECRET" },
  "oktaIssuer": { "value": "$OKTA_ISSUER" },
  "oktaAuthorizationServerId": { "value": "$OKTA_AUTHORIZATION_SERVER_ID" }

The resulting params.json should have 9 parameters:
  acaEnvName, acrLoginServer, acrUsername, acrPassword,
  encryptionKey, adminPassword, databaseUrl, redisUrl, oktaDomain

Make sure the trailing-comma syntax is still valid JSON after the
removals. The last entry before the closing brace must NOT have
a trailing comma.

B.4 — Edit deploy/azure-aca/.env.example

Apply the same removal as A.4 above. Only OKTA_DOMAIN should remain
in the Okta section.

B.5 — Edit deploy/azure-aca/README.md

Apply the same edits as A.6 above. Remove the 4 variables from the
prerequisites list and add the "CIMD / Confidential Relay
Configuration" subsection under Troubleshooting.

===================================================================
PART C — Verification
===================================================================

C.1 — Syntax checks

Run bash -n on both wizard scripts:
  bash -n deploy/azure-aks/azuresetup.sh
  bash -n deploy/azure-aca/acasetup.sh

Run shellcheck on both (skip if not installed, document as "skipped"):
  shellcheck deploy/azure-aks/azuresetup.sh
  shellcheck deploy/azure-aca/acasetup.sh

C.2 — Bicep validation

Compile the ACA Bicep to catch any stray references to removed
parameters:
  az bicep build --file deploy/azure-aca/bicep/main.bicep

If az bicep is not installed, skip and document. A grep check
instead:
  grep -E "oktaRelayClientId|oktaRelayClientSecret|oktaIssuer|oktaAuthorizationServerId" \
    deploy/azure-aca/bicep/main.bicep
  # Should produce NO output. If anything matches, the removal
  # missed a reference.

C.3 — No stray references to removed variables

Run these greps — each should return ZERO matches in files under
deploy/azure-aks/ and deploy/azure-aca/ (EXCLUDING any state files
from a prior real run):

  grep -rn "OKTA_ISSUER" deploy/azure-aks deploy/azure-aca \
    --exclude=".azuresetup.state" --exclude=".acasetup.state"
  grep -rn "OKTA_AUTHORIZATION_SERVER_ID" deploy/azure-aks deploy/azure-aca \
    --exclude=".azuresetup.state" --exclude=".acasetup.state"
  grep -rn "OKTA_RELAY_CLIENT_ID" deploy/azure-aks deploy/azure-aca \
    --exclude=".azuresetup.state" --exclude=".acasetup.state"
  grep -rn "OKTA_RELAY_CLIENT_SECRET" deploy/azure-aks deploy/azure-aca \
    --exclude=".azuresetup.state" --exclude=".acasetup.state"
  grep -rn "oktaRelayClientId\|oktaRelayClientSecret\|oktaIssuer\|oktaAuthorizationServerId" \
    deploy/azure-aks deploy/azure-aca

If any grep returns a match, print it and stop. The only acceptable
matches are:
  - README.md mentioning "CIMD / Confidential Relay" (which uses the
    words but not the variable names)
  - Comments explicitly saying "we used to use X, but no longer"
  - A CHANGELOG or similar doc

C.4 — Confirm OKTA_DOMAIN is still present where it needs to be

These greps SHOULD find matches (to confirm we didn't over-remove):

  grep -n "OKTA_DOMAIN" deploy/azure-aks/azuresetup.sh       # expect matches
  grep -n "OKTA_DOMAIN" deploy/azure-aca/acasetup.sh         # expect matches
  grep -n "OKTA_DOMAIN" deploy/azure-aks/.env.example        # expect 1+ matches
  grep -n "OKTA_DOMAIN" deploy/azure-aca/.env.example        # expect 1+ matches
  grep -n "__OKTA_DOMAIN__" deploy/azure-aks/manifests/02-configmap.yaml  # expect 1 match
  grep -n "oktaDomain" deploy/azure-aca/bicep/main.bicep     # expect 3+ matches
                                                             # (1 param + 1 env + 1 use)

C.5 — State file cleanup note

If the operator has an existing .azuresetup.state or .acasetup.state
file from a previous real run, it will contain stale entries for
the removed variables. These are harmless (the updated wizards
simply don't read them) but can be cleaned up with:

  sed -i.bak '/^OKTA_ISSUER=/d;/^OKTA_AUTHORIZATION_SERVER_ID=/d;/^OKTA_RELAY_CLIENT_ID=/d;/^OKTA_RELAY_CLIENT_SECRET=/d' \
    deploy/azure-aks/.azuresetup.state 2>/dev/null || true
  sed -i.bak '/^OKTA_ISSUER=/d;/^OKTA_AUTHORIZATION_SERVER_ID=/d;/^OKTA_RELAY_CLIENT_ID=/d;/^OKTA_RELAY_CLIENT_SECRET=/d' \
    deploy/azure-aca/.acasetup.state 2>/dev/null || true

Do NOT run this automatically as part of AZ13. Just mention it in
the final summary so the operator can decide whether to run it.

C.6 — Final summary

Print a summary listing:
  - Files modified (with line delta for each)
  - bash -n results
  - shellcheck results (or "skipped")
  - Bicep build result (or "skipped")
  - Grep check results (PASS if 0 matches, FAIL with details otherwise)
  - OKTA_DOMAIN presence confirmation
  - State file cleanup command (for operator to run manually if needed)
  - Recommendation: git diff review then commit with
      git add -A
      git commit -m "AZ13: remove non-required Okta env vars"
```

### Expected Output

After this prompt, both wizards treat `OKTA_DOMAIN` as the only required Okta input. The AKS Key Vault stores 4 secrets instead of 6. The ACA Bicep has 9 parameters instead of 13. Both `.env.example` files list only `OKTA_DOMAIN` under the Okta section. Both READMEs have a new subsection explaining that CIMD/Confidential Relay credentials are configured per-agent via the Admin UI rather than as global env vars. `bash -n` and `az bicep build` pass. No stray references to the removed variables remain anywhere under `deploy/azure-aks/` or `deploy/azure-aca/` except the explanatory README text.

---

## After this prompt runs

You're clean to continue with the wizards. When you build AKS Phases 3 and 4 in the next pack, the same correction applies — `OKTA_DOMAIN` is the only Okta env var you need to thread through. No OKTA_ISSUER, no OKTA_AUTHORIZATION_SERVER_ID, no RELAY credentials.

If you have already run the wizards against a real Azure subscription and have stale state files, run the optional `sed` cleanup in step C.5 to remove the dead state entries. It's cosmetic — the updated wizards ignore them — but tidier for future reruns.

## What this does not fix

This prompt does not touch any non-Azure file. If the same four variables appear incorrectly in other places in the repo (for example, `deploy/bundle/`, `deploy/aws-ec2/`, or the admin UI config), that's pre-existing and out of scope. The scope here is strictly the two new Azure wizard directories created in AZ1-AZ12.

If you want a broader cleanup of `OKTA_AUTHORIZATION_SERVER_ID` references elsewhere in the repo (it does appear in some docker-compose files as a passthrough), that's a separate piece of work worth its own prompt.
