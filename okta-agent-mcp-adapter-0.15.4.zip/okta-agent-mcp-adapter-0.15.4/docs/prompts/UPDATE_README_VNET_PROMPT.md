# Prompt: Update deploy/azure-aca/README.md with Custom VNet Documentation

```
You are updating `deploy/azure-aca/README.md` to document the `--custom-vnet`, `--peer-vnet`, and `--peer-name` flags that were recently added to `acasetup.sh`.

## Context

Read `deploy/azure-aca/acasetup.sh` to understand the full implementation. The wizard now supports:

1. `--custom-vnet` flag: creates a custom VNet (`okta-adapter-vnet`) with two subnets (`aca-infra` /23, `private-endpoints` /24), deploys the ACA Environment on the custom subnet, creates Private Endpoints for both Postgres and Redis (Redis is upgraded from Basic C0 to Standard C0 for Private Link support), and sets up Private DNS zones with VNet links for both services.

2. `--peer-vnet <resource-id>` flag: creates bidirectional VNet peering between the adapter's VNet and an existing VNet in another resource group, and links the adapter's Private DNS zones to the remote VNet for DNS resolution.

3. `--peer-name <name>` flag: optional custom name for the peering (defaults to `adapter-to-remote`).

4. The `--destroy` path now cleans up remote VNet peering and Private DNS zone links before deleting the resource group.

## What to add to README.md

Add the following sections to the README. Place them logically — the custom VNet section should go after the existing "Quick Start" and "Phases" sections, before "Day-to-day operations".

### Section: Custom VNet Mode

Document:
- Purpose: enables Private Endpoints for Postgres/Redis, VNet peering with other resource groups, and static outbound IPs via NAT Gateway
- Usage: `./acasetup.sh --custom-vnet`
- What it creates beyond the default path: VNet, two subnets (aca-infra with Microsoft.App/environments delegation, private-endpoints), Private Endpoints + Private DNS zones for both Postgres and Redis
- Cost impact: Redis upgrades from Basic C0 (~$16/mo) to Standard C0 (~$50/mo) for Private Link support. Total estimated cost ~$100-120/mo vs ~$70-80/mo for platform-managed networking.
- The ACA Environment is created with `--infrastructure-subnet-resource-id` pointing to the aca-infra subnet
- Postgres is created with `--public-access none` (vs `0.0.0.0` in default mode)
- Redis is created with `--public-network-access Disabled` and `--sku Standard`
- DATABASE_URL and REDIS_URL remain unchanged — Private DNS resolves the same FQDNs to private IPs inside the VNet

### Section: VNet Peering

Document:
- Purpose: connect the adapter's VNet to an existing VNet in another resource group so the adapter can reach backends deployed there over private networking
- Usage: `./acasetup.sh --custom-vnet --peer-vnet "/subscriptions/SUB/resourceGroups/RG/providers/Microsoft.Network/virtualNetworks/VNET_NAME"`
- Requires `--custom-vnet` (peering without a custom VNet is not supported since platform-managed VNets can't be peered)
- Creates bidirectional peering (local → remote and remote → local)
- Links Private DNS zones to the remote VNet so backends in the peered VNet can resolve Postgres/Redis FQDNs
- The remote peering creation requires Network Contributor (or equivalent) on the remote VNet's resource group. If it fails with 403, the script warns but does not abort — the remote RG owner needs to create the reverse peering manually
- VNet address spaces must not overlap. Default is 10.0.0.0/16. Override with VNET_ADDRESS_PREFIX in .env if the remote VNet uses the same range.
- Optional `--peer-name` flag to customize the peering name (default: adapter-to-remote)

### Section: Custom VNet Environment Variables

Document the optional env vars (also check they're in `.env.example`):
- VNET_NAME (default: okta-adapter-vnet)
- VNET_ADDRESS_PREFIX (default: 10.0.0.0/16)
- ACA_SUBNET_PREFIX (default: 10.0.0.0/23)
- PE_SUBNET_PREFIX (default: 10.0.2.0/24)
- PEER_VNET_RESOURCE_ID (no default — full resource ID)
- PEER_NAME (default: adapter-to-remote)

### Updates to existing sections

1. **Update the Phases table**: Phase 1's "Creates" column should mention "VNet, Private Endpoints (when --custom-vnet)" alongside the existing items.

2. **Update the Options table in Quick Start** (if one exists): add the three new flags.

3. **Update the Teardown section**: note that `--destroy` now also removes remote VNet peering and Private DNS zone links before deleting the resource group.

4. **Update the Environment Variables section**: add a new subsection for Custom VNet variables, noting they are only used when `--custom-vnet` is passed.

5. **Update the cost estimates**: add a note that `--custom-vnet` increases the monthly cost from ~$70-80/mo to ~$100-120/mo due to Redis Standard C0.

## Constraints

- Read `acasetup.sh` thoroughly before writing. The README must match the actual implementation — every flag, every env var, every resource created. Do not invent features that aren't in the script.
- Keep the existing README structure and tone. The current README is terse and practical — match that style.
- Do NOT remove or rewrite existing content that is still accurate. Only add new sections and update existing ones where the new flags change behavior.
- Verify that `.env.example` includes the custom VNet variables. If not, add them with appropriate comments.
```
