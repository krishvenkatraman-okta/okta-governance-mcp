# Database Layer Migration — Operator-Controlled Bootstrap (P15)

**Standalone addendum to `DB_MIGRATION_PROMPTS.md`.** Apply this prompt **after** P14 has been committed. It does not modify any of the P01–P14 prompts; it only adds new functionality to the deploy pipelines.

**Goal:** Add a single flag (`RUN_DB_BOOTSTRAP`, default `true`) that controls whether the deploy pipeline executes both the role bootstrap (`bootstrap_roles.sql`) and the schema migrations, or stops at infrastructure provisioning and hands off to a DBA. When enabled, the deploy script picks the execution path automatically — preferring the cloud-native one-shot job from P13/P14, falling back to local execution if the cloud CLI is unavailable or unauthenticated.

**Drivers:**
- Some customers operate IaC and DBA functions in separate teams with separate change pipelines. They want the IaC pipeline to stop at the network and identity boundary.
- Smaller customers and demo deployments want zero-touch — one command, fully provisioned.
- DBAs occasionally need to run migrations independently (after a code release that ships new migrations but no infra change). A `--migrate-only` mode covers this without requiring full re-deploys.

**Prompt Count:** 1 prompt (P15).

**Test Constraint:** All existing tests continue to pass. New shellcheck and Bicep lint checks must pass on the modified deploy scripts.

---

## Design Decisions (Locked Before Execution)

| Decision | Choice | Rationale |
|----------|--------|-----------|
| Number of flags | One: `RUN_DB_BOOTSTRAP` | A second flag (e.g. separate `RUN_MIGRATIONS`) doubles the matrix without serving real customer needs. Operators who need finer control can use `--migrate-only` after disabling the flag. |
| Default value | `true` (auto-run) | Zero-touch deploys for demos and small customers. Enterprises explicitly set `RUN_DB_BOOTSTRAP=false` in their pipeline config. |
| Execution path selection | Cloud-native job preferred, local execution fallback | Cloud-native job (ECS RunTask / ACA Container Apps Job) runs in the deployed VPC with the right managed identity. Local execution is the fallback when the deploy host can't reach the cloud control plane. |
| Fallback decision | Implicit (CLI presence + auth probe) but always logged | Operators always see which path was taken and why. No silent fallback. |
| Off-mode behavior | Print operator handoff block with masked secrets ARNs and exact commands | DBA gets a copy-pasteable runbook without needing to re-derive any values. |
| Idempotency | Bootstrap and migrate steps must be safe to re-run | `bootstrap_roles.sql` is already idempotent (P09). The migration runner is already idempotent (P03). The new wrapper preserves this. |
| Post-condition verification | `okta-adapter-migrate status` must report `current_version >= MIN_SCHEMA_VERSION` before the deploy declares success | Catches partial failures where the migrate task exits 0 but didn't actually apply migrations. |

---

## Pre-Execution Review Notes (added after auditing post-P14 state)

Before running Prompt P15, the following discrepancies between the prompt text and the actual post-P14 tree were identified. The prompt body below has been edited to match reality; this section captures the rationale so future readers understand why certain steps in P15 are shorter than the original design implied.

1. **Azure entrypoint.** The prompt originally said "P14 added the migrate Container Apps Job invocation to `acasetup.sh`." In fact, `deploy/azure-aca/acasetup.sh` is a 62-line deprecated compatibility shim (it prints a DEPRECATED banner and `exec`s `scripts/deploy.sh`). The real orchestration lives in `deploy/azure-aca/scripts/deploy.sh`, and the migrate-job invocation is Phase 4 of that script (lines 277–331). **All Azure edits target `scripts/deploy.sh`, not `acasetup.sh`.**

2. **Bicep layout.** The migrate Container Apps Job is defined in `deploy/azure-aca/bicep/modules/migrate-job.bicep` (177 lines). `main.bicep` only wires it up (line 497). **No edits to `main.bicep` for the migrate-job command are required.**

3. **Bicep migrate job already runs bootstrap + migrate as one unit.** `modules/migrate-job.bicep:75–116` contains an inline heredoc script that: acquires an Entra token via IMDS + curl, runs `bootstrap_roles.sql` against Postgres as the owner UAMI, registers Entra DB principals idempotently, grants roles, and then runs `python -m okta_agent_proxy.storage.migrate upgrade`. **Step 5 of the original prompt is a no-op; skip it.**

4. **ECS migrate task already runs bootstrap + migrate as one unit.** `deploy/aws-ecs/main.tf:1168–1174` chains `psql "$BOOTSTRAP_URL" -f bootstrap_roles.sql && python -m okta_agent_proxy.storage.migrate upgrade`. In IAM mode the runner picks up `DB_CREDENTIAL_PROVIDER=rds_iam` env vars; in static mode it falls back to `BOOTSTRAP_URL`. **Step 6 of the original prompt is a no-op; skip it.**

5. **Existing CLI flags on `deploy/aws-ecs/deploy.sh`.** `--migrate` and `--skip-migrate` already exist (lines 46–47). The new P15 flag surface must alias to these rather than duplicate them: `--no-bootstrap` is equivalent to `--skip-migrate` and both set `RUN_DB_BOOTSTRAP=false`; `--migrate-only` is equivalent to the existing `--migrate` action.

6. **AWS secret model.** There is one database-related secret: `aws_secretsmanager_secret.db`, containing a single key `DATABASE_URL` with the master credentials. There is no `db_owner_url` secret — in IAM mode the owner role is IAM-authenticated (no standing password). The shared shell lib's `_resolve_owner_db_url` therefore needs to branch on `use_rds_iam`:
   - `use_rds_iam=true` and local-exec path: **not supported** — the deploy host cannot mint an IAM token for the owner role without additional IAM plumbing. Print a clear error telling the operator to either (a) run the cloud-job path, or (b) set `use_rds_iam=false` if they need local-exec.
   - `use_rds_iam=false`: owner URL = BOOTSTRAP_URL = master URL (same as the migrate task does today).

7. **Post-condition verification.** The original prompt had `_verify_post_condition()` connect to the DB from the deploy host after either path completes. This is only feasible for the **local-exec** path (where the deploy host already has DB reachability). In the **cloud-job** path, RDS is in private subnets and Azure Postgres is behind a private endpoint — the deploy host cannot connect. For the cloud-job path, the post-condition is satisfied by the job's own exit code (the job's internal `migrate upgrade` call already verifies `current_version >= MIN_SCHEMA_VERSION` implicitly, because it applies all pending migrations and fails on checksum drift). The updated prompt below only runs `_verify_post_condition` on the local-exec path.

8. **No Phase 1.8 role-bootstrap block to move.** The original prompt said "the role bootstrap that P14 added inline at Phase 1.8 should be MOVED into the new shared lib." No such block exists — P14 placed all bootstrap logic inside the Bicep migrate-job's inline script (see #3 above). **Nothing to move.** The shared lib's local-exec path is new code that mirrors what the Bicep job already does.

9. **Test harness.** Repo convention is pytest (no bats-core or shellspec). Use pytest + subprocess to exercise the shell lib, not bats-core.

10. **Audit events.** `DB_MIGRATION_APPLIED` and `DB_MIGRATION_FAILED` were added in P02 (confirmed at `okta_agent_proxy/audit/events.py:97-98`). The migration runner already emits them; the shared shell lib does not need to emit audit events itself.

---

### Prompt P15: Operator-controlled bootstrap with intelligent fallback

**Context:** P13 always runs the ECS migrate task. P14 always triggers the ACA migrate job. This prompt makes both behaviors gated and adds a local-execution fallback for environments where the cloud-native job can't be triggered (e.g. air-gapped operator workstation, deploy from a CI runner without VPC access).

**Prompt:**

```
Add operator-controlled DB bootstrap execution to the AWS ECS and Azure ACA deploy pipelines.

Read first:
- deploy/aws-ecs/deploy.sh (entry point; already has --migrate and --skip-migrate flags at lines 46-47; migrate task runner lives in run_migrate_task() at line 357)
- deploy/aws-ecs/deploy-adapter.sh (per-revision redeploy; does NOT currently run migrations — P15 adds that)
- deploy/aws-ecs/main.tf (P13 added aws_ecs_task_definition.migrate at line 1146; command at line 1168 already chains bootstrap_roles.sql and the migrate runner — do not duplicate that work)
- deploy/aws-ecs/outputs.tf (migrate_task_definition_family, cluster_name, private_subnet_ids, ecs_tasks_sg_id already exported)
- deploy/azure-aca/scripts/deploy.sh (the REAL Azure deploy entry point; Phase 4 at lines 277-331 triggers the migrate job)
- deploy/azure-aca/acasetup.sh (DEPRECATED 62-line shim — DO NOT edit)
- deploy/azure-aca/bicep/main.bicep (wires modules/migrate-job.bicep at line 497; migrateJobName output at line 568 — do not edit the migrate job command here)
- deploy/azure-aca/bicep/modules/migrate-job.bicep (P14; inline bootstrap+migrate script at lines 75-116 — already correct; leave alone)
- deploy/azure-aca/shell-lib/ (ACA-specific helpers; common.sh has info/ok/warn/die; DO NOT modify)
- deploy/migrations/sql/bootstrap_roles.sql (P09)
- okta_agent_proxy/storage/migrate.py (P03)
- okta_agent_proxy/audit/events.py (DB_MIGRATION_APPLIED, DB_MIGRATION_FAILED at lines 97-98)

Design constraints — do not deviate without flagging in the commit message:
- ONE flag: RUN_DB_BOOTSTRAP. Default true.
- The flag controls BOTH bootstrap_roles.sql AND migrations together as a single unit.
- Auto-run path: try cloud-native job first; fall back to local execution only if the
  cloud CLI is missing OR `aws sts get-caller-identity` / `az account show` fails.
- Both paths must verify the post-condition (current_version >= MIN_SCHEMA_VERSION) before
  declaring success.
- When the flag is false, deploy completes successfully but prints an unambiguous operator
  handoff block. The adapter container will fail to start until the DBA runs migrations,
  which is the desired behavior (the schema-check guard from P08 enforces this).

Execute the following:

1. Create deploy/shell-lib/db_bootstrap.sh — a NEW top-level shared library sourced by both
   AWS and Azure deploy scripts. (Do not modify deploy/azure-aca/shell-lib; that is the
   ACA-specific lib. The new top-level shell-lib is for cross-cloud helpers.)

   #!/usr/bin/env bash
   # Cross-cloud DB bootstrap helpers.
   # Sourcing scripts must define: ok(), info(), warn(), die() output helpers.
   #
   # Required env vars set by caller before invoking db_bootstrap_run:
   #   PLATFORM           - "aws" or "azure"
   #   DB_HOST            - DB endpoint hostname
   #   DB_PORT            - DB port (5432)
   #   DB_NAME            - database name
   #   DB_OWNER_ROLE      - owner role name (default okta_adapter_owner)
   #   DB_APP_ROLE        - app role name (default okta_adapter_app)
   #   MIGRATIONS_DIR     - absolute path to deploy/migrations/sql
   #
   # Platform-specific (AWS):
   #   AWS_REGION
   #   ECS_CLUSTER
   #   MIGRATE_TASK_DEF_ARN
   #   ECS_SUBNETS         - comma-separated subnet IDs
   #   ECS_SECURITY_GROUPS - comma-separated SG IDs
   #   DB_MASTER_SECRET_ARN - Secrets Manager ARN for master creds (single secret;
   #                           key inside the SecretString is DATABASE_URL)
   #   USE_RDS_IAM          - "true"/"false" from terraform output; when true there is
   #                           no standing owner password, so local-exec for the
   #                           migrate step is not supported (only cloud-job path).
   #
   # Platform-specific (Azure):
   #   AZURE_RG
   #   AZURE_PROJECT       - prefix used for resource names
   #   MIGRATE_JOB_NAME    - Container Apps Job name
   #   PG_NAME             - Flexible Server name
   #   PG_MASTER_USER      - master/admin login (bootstrap only)
   #   PG_MASTER_PASSWORD  - master/admin password (bootstrap only; from state file)
   #   ENTRA_OWNER_PRINCIPAL - Entra principal name for owner role
   #
   # Defaults:
   : "${RUN_DB_BOOTSTRAP:=true}"
   : "${DB_BOOTSTRAP_TIMEOUT:=600}"   # seconds to wait for cloud-native job
   : "${DB_BOOTSTRAP_FORCE_LOCAL:=false}"  # set true to skip cloud-job attempt entirely

   # =========================================================================
   # Public entrypoint
   # =========================================================================
   db_bootstrap_run() {
       if [ "$RUN_DB_BOOTSTRAP" != "true" ]; then
           db_bootstrap_print_handoff
           return 0
       fi

       info "RUN_DB_BOOTSTRAP=true — executing role bootstrap and migrations"

       local path
       if [ "$DB_BOOTSTRAP_FORCE_LOCAL" = "true" ]; then
           info "DB_BOOTSTRAP_FORCE_LOCAL=true — skipping cloud-native job"
           path="local"
       elif _cloud_cli_available_and_authed; then
           path="cloud_job"
       else
           warn "Cloud CLI unavailable or not authenticated — falling back to local execution"
           path="local"
       fi

       case "$path" in
           cloud_job)
               _bootstrap_via_cloud_job
               # Post-condition for the cloud_job path is the job's exit code, which
               # _bootstrap_*_cloud_job already die()s on. We cannot re-verify from the
               # deploy host because the DB is in private subnets (AWS) or behind a
               # private endpoint (Azure).
               ;;
           local)
               _bootstrap_via_local_exec
               _verify_post_condition
               ;;
       esac
       ok "Database bootstrap complete (path: $path)"
   }

   # =========================================================================
   # Cloud CLI probe
   # =========================================================================
   _cloud_cli_available_and_authed() {
       case "$PLATFORM" in
           aws)
               command -v aws >/dev/null 2>&1 || return 1
               aws sts get-caller-identity --region "$AWS_REGION" >/dev/null 2>&1 || return 1
               return 0
               ;;
           azure)
               command -v az >/dev/null 2>&1 || return 1
               az account show >/dev/null 2>&1 || return 1
               return 0
               ;;
           *) die "Unknown PLATFORM: $PLATFORM" ;;
       esac
   }

   # =========================================================================
   # Path 1: cloud-native one-shot job
   # =========================================================================
   _bootstrap_via_cloud_job() {
       info "Bootstrap path: cloud-native job"
       case "$PLATFORM" in
           aws)   _bootstrap_aws_ecs_runtask ;;
           azure) _bootstrap_azure_aca_job ;;
       esac
   }

   _bootstrap_aws_ecs_runtask() {
       info "Triggering ECS RunTask: $MIGRATE_TASK_DEF_ARN"
       local task_arn
       task_arn="$(
           aws ecs run-task \
               --region "$AWS_REGION" \
               --cluster "$ECS_CLUSTER" \
               --task-definition "$MIGRATE_TASK_DEF_ARN" \
               --launch-type FARGATE \
               --network-configuration "awsvpcConfiguration={subnets=[$ECS_SUBNETS],securityGroups=[$ECS_SECURITY_GROUPS],assignPublicIp=DISABLED}" \
               --query 'tasks[0].taskArn' --output text
       )" || die "ecs run-task failed"
       [ -n "$task_arn" ] && [ "$task_arn" != "None" ] || die "No task ARN returned"
       info "ECS task started: $task_arn"

       info "Waiting for migrate task to complete (timeout ${DB_BOOTSTRAP_TIMEOUT}s)..."
       aws ecs wait tasks-stopped \
           --region "$AWS_REGION" \
           --cluster "$ECS_CLUSTER" \
           --tasks "$task_arn" || die "Timed out waiting for migrate task"

       local exit_code
       exit_code="$(
           aws ecs describe-tasks \
               --region "$AWS_REGION" \
               --cluster "$ECS_CLUSTER" \
               --tasks "$task_arn" \
               --query 'tasks[0].containers[0].exitCode' --output text
       )"
       if [ "$exit_code" != "0" ]; then
           warn "Migrate task exited with code $exit_code — fetching logs:"
           aws logs tail /ecs/okta-mcp-adapter --region "$AWS_REGION" --since 10m | tail -50
           die "Migration failed (exit $exit_code)"
       fi
       ok "ECS migrate task completed successfully"
   }

   _bootstrap_azure_aca_job() {
       info "Triggering Container Apps Job: $MIGRATE_JOB_NAME"
       local execution_name
       execution_name="$(
           az containerapp job start \
               -g "$AZURE_RG" -n "$MIGRATE_JOB_NAME" \
               --query 'name' -o tsv
       )" || die "Failed to start Container Apps Job"
       info "Job execution started: $execution_name"

       local elapsed=0 status
       info "Waiting for migrate job to complete (timeout ${DB_BOOTSTRAP_TIMEOUT}s)..."
       while [ "$elapsed" -lt "$DB_BOOTSTRAP_TIMEOUT" ]; do
           status="$(
               az containerapp job execution show \
                   -g "$AZURE_RG" -n "$MIGRATE_JOB_NAME" \
                   --job-execution-name "$execution_name" \
                   --query 'properties.status' -o tsv 2>/dev/null
           )"
           case "$status" in
               Succeeded) ok "ACA migrate job completed successfully"; return 0 ;;
               Failed|Degraded)
                   warn "Migrate job status: $status — fetching logs:"
                   az containerapp logs show \
                       -g "$AZURE_RG" -n "$MIGRATE_JOB_NAME" \
                       --type system --tail 50 || true
                   die "Migration failed (status $status)"
                   ;;
           esac
           sleep 10
           elapsed=$((elapsed + 10))
       done
       die "Timed out waiting for migrate job after ${DB_BOOTSTRAP_TIMEOUT}s"
   }

   # =========================================================================
   # Path 2: local execution fallback
   # =========================================================================
   _bootstrap_via_local_exec() {
       info "Bootstrap path: local execution"
       _check_local_prereqs

       local master_url owner_url
       master_url="$(_resolve_master_db_url)"
       owner_url="$(_resolve_owner_db_url)"

       info "Step 1/2: applying bootstrap_roles.sql (idempotent)"
       DB_OWNER_ROLE="$DB_OWNER_ROLE" DB_APP_ROLE="$DB_APP_ROLE" DB_NAME="$DB_NAME" \
           psql "$master_url" -v ON_ERROR_STOP=1 \
                -f "$MIGRATIONS_DIR/bootstrap_roles.sql" \
           || die "bootstrap_roles.sql failed"
       ok "Roles bootstrapped"

       info "Step 2/2: applying migrations"
       python -m okta_agent_proxy.storage.migrate upgrade \
              --migrations-dir "$MIGRATIONS_DIR" \
              --conninfo "$owner_url" \
              --applied-by "deploy.sh@$(hostname)" \
           || die "Migrations failed"
       ok "Migrations applied"
   }

   _check_local_prereqs() {
       command -v psql >/dev/null 2>&1 || die \
         "psql not found. Install postgres-client or set RUN_DB_BOOTSTRAP=false and run migrations from a host that has it."
       command -v python >/dev/null 2>&1 || die \
         "python not found. Install Python 3.12+ or set RUN_DB_BOOTSTRAP=false."
       python -c 'import okta_agent_proxy.storage.migrate' 2>/dev/null || die \
         "okta_agent_proxy package not importable. Run from project root with venv active."
   }

   _resolve_master_db_url() {
       case "$PLATFORM" in
           aws)
               # Single secret in the AWS ECS stack: aws_secretsmanager_secret.db.
               # SecretString is a JSON object with key DATABASE_URL holding the
               # master (postgres superuser) connection URL.
               aws secretsmanager get-secret-value \
                   --region "$AWS_REGION" \
                   --secret-id "$DB_MASTER_SECRET_ARN" \
                   --query SecretString --output text \
                 | python -c 'import sys,json; print(json.load(sys.stdin)["DATABASE_URL"])' \
                 || die "Failed to fetch master DB URL"
               ;;
           azure)
               # Azure: assemble from state-file values (master is local-only, never in Key Vault)
               local enc_pwd
               enc_pwd="$(_url_encode "$PG_MASTER_PASSWORD")"
               echo "postgresql://${PG_MASTER_USER}:${enc_pwd}@${DB_HOST}:${DB_PORT}/${DB_NAME}?sslmode=require"
               ;;
       esac
   }

   _resolve_owner_db_url() {
       case "$PLATFORM" in
           aws)
               if [ "${USE_RDS_IAM:-false}" = "true" ]; then
                   die "Local-exec path is not supported when USE_RDS_IAM=true. The owner role has no standing password; deploy-host IAM-token minting is not wired in. Run with DB_BOOTSTRAP_FORCE_LOCAL=false (cloud-job path) or set use_rds_iam=false in terraform and redeploy."
               fi
               # Static-password mode: the owner role doesn't exist as a separate
               # Secrets Manager entry. The migrate task's current behavior is to
               # run both bootstrap and migrations using the master URL. Match that.
               _resolve_master_db_url
               ;;
           azure)
               # Azure with Entra: owner is a managed identity. Local exec falls back to
               # master credentials for migrations since we can't easily impersonate the MI
               # from the deploy host. This is acceptable because local-exec is the fallback,
               # not the recommended path.
               warn "Local-exec on Azure uses master credentials for migrations (fallback only)"
               _resolve_master_db_url
               ;;
       esac
   }

   _url_encode() {
       python -c 'import sys, urllib.parse; print(urllib.parse.quote(sys.argv[1], safe=""))' "$1"
   }

   # =========================================================================
   # Post-condition verification
   # =========================================================================
   _verify_post_condition() {
       info "Verifying schema_migrations.current_version >= MIN_SCHEMA_VERSION"
       local owner_url current min
       owner_url="$(_resolve_owner_db_url)"
       current="$(
           python -m okta_agent_proxy.storage.migrate version --conninfo "$owner_url" 2>/dev/null
       )"
       min="$(python -c 'from okta_agent_proxy.storage.constants import MIN_SCHEMA_VERSION; print(MIN_SCHEMA_VERSION)')"
       if [ -z "$current" ] || [ "$current" = "(none)" ]; then
           die "Post-condition failed: schema_migrations is empty after bootstrap"
       fi
       if [ "$current" \< "$min" ]; then
           die "Post-condition failed: current_version=$current < MIN_SCHEMA_VERSION=$min"
       fi
       ok "Schema version verified: $current"
   }

   # =========================================================================
   # Off-mode handoff
   # =========================================================================
   db_bootstrap_print_handoff() {
       local owner_secret_ref
       case "$PLATFORM" in
           aws)
               owner_secret_ref="aws secretsmanager get-secret-value --region $AWS_REGION --secret-id $DB_OWNER_SECRET_ARN --query SecretString --output text"
               ;;
           azure)
               owner_secret_ref="(use the Entra-authenticated owner identity: ${ENTRA_OWNER_PRINCIPAL})"
               ;;
       esac

       cat <<EOF

════════════════════════════════════════════════════════════════════════════════
DEPLOYMENT COMPLETE — DATABASE BOOTSTRAP NOT YET RUN (RUN_DB_BOOTSTRAP=false)
════════════════════════════════════════════════════════════════════════════════

The adapter will FAIL TO START until your DBA completes the steps below.
This is intentional: the application will not create schema at runtime.

Required role names:
  Owner role: ${DB_OWNER_ROLE}
  App role:   ${DB_APP_ROLE}
  Database:   ${DB_NAME} on ${DB_HOST}:${DB_PORT}

Owner-role credentials:
  ${owner_secret_ref}

────────────────────────────────────────────────────────────────────────────────
OPTION A: trigger the cloud-native one-shot job (recommended)
────────────────────────────────────────────────────────────────────────────────
EOF
       case "$PLATFORM" in
           aws) cat <<EOF
  aws ecs run-task \\
      --region ${AWS_REGION} \\
      --cluster ${ECS_CLUSTER} \\
      --task-definition ${MIGRATE_TASK_DEF_ARN} \\
      --launch-type FARGATE \\
      --network-configuration 'awsvpcConfiguration={subnets=[${ECS_SUBNETS}],securityGroups=[${ECS_SECURITY_GROUPS}],assignPublicIp=DISABLED}'

EOF
               ;;
           azure) cat <<EOF
  az containerapp job start -g ${AZURE_RG} -n ${MIGRATE_JOB_NAME}

EOF
               ;;
       esac
       cat <<EOF
────────────────────────────────────────────────────────────────────────────────
OPTION B: run from a DBA jump host with psql + the project venv
────────────────────────────────────────────────────────────────────────────────
  # 1. Create roles (idempotent):
  DB_OWNER_ROLE=${DB_OWNER_ROLE} DB_APP_ROLE=${DB_APP_ROLE} DB_NAME=${DB_NAME} \\
      psql "<master-url>" -f deploy/migrations/sql/bootstrap_roles.sql

  # 2. Apply migrations as the owner role:
  python -m okta_agent_proxy.storage.migrate upgrade \\
      --conninfo "<owner-url>"

  # 3. Verify (optional):
  python -m okta_agent_proxy.storage.migrate status --conninfo "<owner-url>"

────────────────────────────────────────────────────────────────────────────────
After bootstrap completes, restart the adapter Container App / ECS service.
The schema-version guard will pass and the adapter will start normally.
════════════════════════════════════════════════════════════════════════════════

EOF
   }

2. Update deploy/aws-ecs/deploy.sh to source and use the shared lib.

   - Existing flags: `--migrate` and `--skip-migrate` already exist. Keep them working as
     aliases. Add `--no-bootstrap` as a synonym for `--skip-migrate` (both set
     RUN_DB_BOOTSTRAP=false). Add `--migrate-only` as a synonym for the existing
     `--migrate` action (both skip terraform apply and just run the bootstrap path).
   - Replace the inline `run_migrate_task` function (lines 357-420) with a call to
     `db_bootstrap_run` from the shared lib. The existing function hard-codes the
     cloud-native path; the shared lib is a drop-in replacement that adds the
     local-exec fallback and the off-mode handoff.
   - Source deploy/shell-lib/db_bootstrap.sh near the top after the existing helpers.
   - After the Terraform apply completes and outputs are available, populate the env
     vars listed in db_bootstrap.sh's caller contract (PLATFORM=aws, ECS_CLUSTER,
     MIGRATE_TASK_DEF_ARN from terraform output, DB_MASTER_SECRET_ARN, etc.), then
     call db_bootstrap_run. Use existing outputs: cluster_name,
     migrate_task_definition_family (→ resolve to ARN via aws ecs describe-task-definition),
     private_subnet_ids, ecs_tasks_sg_id, secrets_db_arn.
   - For --migrate-only mode: skip terraform apply, read the values from
     `terraform output -json` against the existing state, then call db_bootstrap_run.
   - Update the help text printed by --help to document RUN_DB_BOOTSTRAP,
     --no-bootstrap (alias), --migrate-only (alias), --skip-migrate (alias),
     and --migrate (alias). Keep all five flag names working.

3. Update deploy/aws-ecs/deploy-adapter.sh — this per-revision redeploy currently does
   NOT run migrations. New releases may ship new migrations, so it MUST run them now.
   Source the shared lib, populate env vars from `terraform output -json` (assumes the
   state file is in deploy/aws-ecs/), and call db_bootstrap_run before the
   `aws ecs update-service --force-new-deployment` call. Add the same
   `--no-bootstrap` / `--migrate-only` / `RUN_DB_BOOTSTRAP` surface.

4. Update deploy/azure-aca/scripts/deploy.sh (NOT acasetup.sh — that is a deprecated
   shim; leave it untouched):

   - Add CLI flag parsing: `--no-bootstrap` (sets RUN_DB_BOOTSTRAP=false) and
     `--migrate-only` (skips Phase 3a/3b/3c/5 and only runs Phase 4). Place alongside
     the existing --yes/--skip-preflight/--skip-build/--what-if/--destroy flags.
   - Replace the inline Phase 4 block (lines 277-331) — the one that does
     `az containerapp job start ... | polling loop | az containerapp job execution show`
     — with a call to `db_bootstrap_run` from the shared lib. The shared lib's
     `_bootstrap_azure_aca_job` function is a functional replacement; the inline
     retry/status polling is exactly what the shared lib does.
   - Source deploy/shell-lib/db_bootstrap.sh at the top after the existing shell-lib
     sources (shell-lib/common.sh etc.).
   - Populate the Azure env vars before calling db_bootstrap_run: PLATFORM=azure,
     AZURE_RG=$RESOURCE_GROUP, MIGRATE_JOB_NAME=$MIGRATE_JOB_NAME, PG_NAME (from
     state), DB_HOST (from postgresServerFqdn output), DB_NAME=gateway_db,
     ENTRA_OWNER_PRINCIPAL (the owner UAMI name).
   - DO NOT touch bicep/modules/migrate-job.bicep — its inline script already runs
     bootstrap_roles.sql + principal registration + migrate upgrade as a single unit.
   - DO NOT touch bicep/main.bicep — it only wires the migrate-job module.

5. *(Skipped in reconciled P15 — the Bicep migrate job already runs
   bootstrap_roles.sql and the migrate runner as a single unit. Verify this by reading
   modules/migrate-job.bicep:75-116. No changes required.)*

6. *(Skipped in reconciled P15 — the ECS migrate task definition already runs
   bootstrap_roles.sql and the migrate runner as a single unit. Verify this by reading
   deploy/aws-ecs/main.tf:1168-1174. No changes required.)*

7. Add new tests:

   tests/test_deploy_db_bootstrap.py — pytest-based test harness that shells out to
   `bash` and drives the shared lib via stub PATH entries (repo convention is pytest;
   do not add bats-core or shellspec dependencies). Cover:
   - test_run_db_bootstrap_false_prints_handoff_block_with_correct_secret_arns
   - test_cloud_cli_probe_returns_false_when_aws_missing
   - test_cloud_cli_probe_returns_false_when_az_unauthenticated (mock az to exit 1)
   - test_local_exec_calls_psql_then_migrate_in_order
   - test_post_condition_verification_fails_when_schema_empty
   - test_force_local_skips_cloud_job_attempt
   - test_aws_local_exec_refuses_when_use_rds_iam_true (new — see Review Note 6)
   - test_migrate_only_mode_skips_terraform

   Implementation pattern: each test creates a temp directory, writes stub `aws`,
   `az`, `psql`, `python` executables that log their argv to a file and exit with a
   controlled code, prepends the temp dir to PATH, and invokes
   `bash -c 'source deploy/shell-lib/db_bootstrap.sh; db_bootstrap_run'` with the
   caller-contract env vars pre-set. Assertions read the argv log file.

   Run shellcheck on deploy/shell-lib/db_bootstrap.sh, deploy/aws-ecs/deploy.sh,
   deploy/aws-ecs/deploy-adapter.sh, deploy/azure-aca/scripts/deploy.sh. All must
   pass. (Do NOT shellcheck deploy/azure-aca/acasetup.sh — it is an untouched
   deprecated shim; no new findings can be introduced there.)

   Run `bicep lint deploy/azure-aca/bicep/main.bicep` and
   `bicep lint deploy/azure-aca/bicep/modules/migrate-job.bicep`. No errors.
   (Both files are unchanged in P15; this is a regression check only.)

8. Update documentation:

   - deploy/README.md (or deploy/aws-ecs/README.md and deploy/azure-aca/README.md):
     new section "Database Bootstrap Control" documenting RUN_DB_BOOTSTRAP, the two
     execution paths, --no-bootstrap, and --migrate-only.
   - docs/OPERATIONS.md: add a "DBA-Controlled Migration Workflow" subsection under
     the existing Database Bootstrap section. Show the four-step DBA workflow:
     (1) operator runs deploy with --no-bootstrap, (2) operator hands off the
     handoff block to the DBA, (3) DBA runs the cloud-job command or the local
     command, (4) operator runs `deploy.sh --restart` to bounce the adapter so
     the schema-check passes.
   - CHANGELOG.md: entry under the next release noting the new flag, the new
     --migrate-only mode, and that auto-run is the default (no behavior change for
     existing customers who don't set the env var).

9. Smoke test (manual, document in commit message):

   AWS:
   - Fresh deploy with default flag (auto-run, cloud path): RUN_DB_BOOTSTRAP unset,
     deploy.sh completes, adapter starts cleanly.
   - Fresh deploy with auto-run, force local: DB_BOOTSTRAP_FORCE_LOCAL=true ./deploy.sh,
     verify logs show "Bootstrap path: local execution".
   - Fresh deploy with off mode: RUN_DB_BOOTSTRAP=false ./deploy.sh, verify handoff
     block prints, verify adapter container is in CrashLoopBackoff with the schema-not-
     initialized error from P08.
   - Recovery: run `./deploy.sh --migrate-only`, verify adapter recovers.

   Azure: same four scenarios using ./scripts/deploy.sh (NOT ./acasetup.sh — that
   shim is untouched and just execs scripts/deploy.sh).

10. Run the full Python test suite one more time (no Python code changes in this prompt,
    but we want to verify nothing has regressed):
    pytest tests/ -x -q

Commit: "P15: operator-controlled DB bootstrap flag with cloud-job/local fallback"
```

**Expected Output:** Single `RUN_DB_BOOTSTRAP` flag wired through both deploy pipelines. Cloud-native job preferred, local execution fallback when cloud CLI unavailable. Off-mode prints actionable operator handoff. `--migrate-only` mode for DBA-driven re-runs.

---

## Post-P15 Verification Checklist

After P15 has been applied and committed, verify:

1. **Default behavior unchanged for existing customers:** A deploy invoked with no env vars set behaves identically to post-P14 — auto-runs the cloud-native migrate job. Confirm by diffing the success-path log output against a P14 deploy.

2. **Off-mode produces actionable output:** `RUN_DB_BOOTSTRAP=false ./deploy.sh` prints the handoff block with no `<placeholder>` markers — every value is resolved from Terraform/Bicep outputs and cloud secret stores. The block is copy-pasteable.

3. **Fallback path works without cloud CLI:** On a host where `aws` is uninstalled, `./deploy.sh` (with infra already provisioned via a different host) detects the missing CLI, logs the fallback decision, and runs migrations locally. Same for `az`.

4. **`--migrate-only` mode is operator-safe:** Running `./deploy.sh --migrate-only` against an already-deployed stack does not modify infrastructure. It only runs `db_bootstrap_run`. Idempotent — running it twice changes nothing on the second run.

5. **Post-condition guard catches partial failures:** Manually inject a failure (e.g., set `MIN_SCHEMA_VERSION` to a value higher than what's actually in `schema_migrations`), confirm `_verify_post_condition` fails the deploy with a clear error.

6. **Cloud-native job runs both bootstrap and migrate as a unit:** Inspect ECS task logs / ACA job logs after a clean deploy. Both `bootstrap_roles.sql` execution and `okta-adapter-migrate upgrade` execution must appear in the same task/job run.

7. **shellcheck and bicep lint pass:** No new warnings introduced.

8. **Documentation cross-references:** Search `docs/`, `deploy/`, `CLAUDE.md` for `RUN_DB_BOOTSTRAP`. Every reference should point to the same canonical explanation in `docs/OPERATIONS.md`.

---

## Rollback Plan

P15 is purely additive in behavior. If issues are found:

- **Revert option (full):** `git revert` the P15 commit. Behavior returns to P14: cloud-native job always runs.
- **Operator workaround (no revert needed):** Existing customers can set `DB_BOOTSTRAP_FORCE_LOCAL=true` to skip the cloud-job attempt, or `RUN_DB_BOOTSTRAP=false` to opt out entirely. No code change required.

The shared shell library is the only new file outside the deploy folders. If it causes problems for one cloud but not the other, the affected platform can temporarily inline its old P13 / P14 logic while the shared lib is fixed.

---

*End of DB_MIGRATION_P15_PROMPTS.md*
