> **Historical (pre-v0.15.x):** Password-based admin login references in this document are obsolete. The adapter accepts only Okta OAuth access tokens — see [docs/OPERATIONS.md § Admin API Authentication](../OPERATIONS.md#admin-api-authentication).

# Okta MCP Adapter — AKS Wizard Phase 3 + Phase 4 Implementation Prompts

## Application Deployment, AGC Ingress, Smoke Tests, Lockdown

**6 Prompts • Sequential • Completes the AKS wizard end-to-end**

---

## Overview

This is the final pack for the AKS wizard. After running these 6 prompts, `deploy/azure-aks/azuresetup.sh` will be a complete, tested, production-grade deployment tool that takes a dev/ops team from an empty Azure subscription to a working Okta MCP Adapter behind TLS-terminated Application Gateway for Containers ingress.

**Scope of this pack:**

- **Phase 3 (Application + Ingress)** — build adapter/admin-ui/hr-backend images via `az acr build`, materialize the 10 manifest templates by substituting `__PLACEHOLDER__` tokens with real state values, apply manifests to the AKS cluster in order, create the ALB controller's own workload identity and federated credential, install the ALB controller via Helm, apply the `ApplicationLoadBalancer` CR + `Gateway` + `HTTPRoute` resources, capture the AGC FQDN, and print CNAME instructions for the operator
- **Phase 4 (Smoke Tests + Lockdown)** — enable Container Insights, run the five smoke tests (oauth metadata, health, admin login, list agents, cache_provider=redis), disable Key Vault public network access (the "public-then-disable" window opened in Phase 2 finally closes here), print the final summary box, mark `PHASE_4_COMPLETE=true`

**Decisions baked into this pack** (confirmed before writing):

1. **Phase 3 + Phase 4 in one combined pack** — Phase 4 is small enough (smoke tests + one `az keyvault update`) that splitting it across packs would be clumsy
2. **Image tags use `adapter:<git-sha>`** for immutability, not `:latest`. Reproducible rollouts. ACA can keep `:latest` since it's an explicit demo; AKS is production
3. **ALB controller Helm version NOT pinned** — the wizard takes whatever is current from the OCI registry and captures the installed version into state after install, so you have a reproducibility record
4. **DNS handoff is Option A (manual)** — Phase 3 prints the AGC FQDN and tells the operator "create CNAME records, then run Phase 4 when they've propagated." The wizard does NOT wait for DNS from inside
5. **Smoke test #5 (`cache_provider=redis`) is non-fatal** with a warning. Matches the ACA treatment
6. **`OKTA_DOMAIN` is the only required Okta env var** — AZ13 correction applies here too

**Two significant gotchas I discovered while researching this pack:**

1. **The ALB controller needs its OWN workload identity**, separate from the adapter's `okta-mcp-workload-id` that Phase 1 created. The controller identity is conventionally named `azure-alb-identity` and is federated against the service account `system:serviceaccount:azure-alb-system:alb-controller-sa`. **This needs to be created in Phase 3**, not Phase 1, because Phase 1 didn't know about it. The Helm install passes `--set albController.podIdentity.clientID=<id>` at install time to wire it up.

2. **The ALB controller identity needs two role assignments**, both at separate scopes: `Reader` on the AKS **node** resource group (the auto-generated `MC_*` group, not the main RG), and `AppGw for Containers Configuration Manager` on the **AGC subnet**. I caught this by reading the Microsoft quickstart for the Helm path. Miss either and the controller spins in `CrashLoopBackOff` with auth errors.

These are now explicit steps in AZ14 (prereqs) and AZ17 (ALB controller install).

## Prompt Map

| # | Prompt | Phase | Creates / Modifies | Est. Time |
|---|---|---|---|---|
| AZ14 | Phase 3 prereqs + hostnames + ALB identity | 3 | `azuresetup.sh` (Phase 3 prereq block), creates ALB controller identity + RBAC | 35 min |
| AZ15 | Image build via az acr build | 3 | `azuresetup.sh` (Phase 3 image build step) | 20 min |
| AZ16 | Manifest substitution + kubectl apply | 3 | `azuresetup.sh` (Phase 3 workload deploy), adds `substitute_manifest` helper to `azure-helpers.sh` | 40 min |
| AZ17 | ALB controller Helm install + AGC provisioning | 3 | `azuresetup.sh` (Phase 3 ingress block), prints FQDN + CNAME instructions | 35 min |
| AZ18 | Phase 4 smoke tests + Container Insights | 4 | `azuresetup.sh` (Phase 4 body) | 30 min |
| AZ19 | Phase 4 Key Vault lockdown + final summary + README | 4 | `azuresetup.sh` (Phase 4 finalization), README updates | 25 min |

Total estimated implementation time: about 3 hours of Claude Code execution. Total wall-clock when running the wizard itself (Phase 3 + Phase 4 end-to-end on real Azure) is about 25 minutes plus whatever the operator takes to configure DNS between Phases 3 and 4.

---

## Prerequisites

- AZ1–AZ13 have been run and committed
- `deploy/azure-aks/azuresetup.sh --phase 1` and `--phase 2` have been verified against a real Azure subscription at least once (the bar for Phase 3 is higher than the earlier phases because workload identity federation across two separate identities is fiddly)
- The operator knows the DNS provider they'll use for the two hostnames, and can create CNAME records there after Phase 3 finishes
- `kubectl` and `helm` are installed locally (they were listed as prereqs in AZ4 but this pack actually uses them for the first time)

## How to Execute

```bash
cd okta-agent-mcp-adapter
git checkout feat/azure-scripted-deploy
# Paste each prompt body into Claude Code, one at a time.
# Commit after each green run:
git add -A && git commit -m "AZ<N>: <prompt title>"
```

---

## Prompt AZ14: Phase 3 Prereqs + Hostnames + ALB Controller Identity

### Context

Phase 3 begins with a prereq block that checks Phase 2 completion, reloads state from the previous phases, and loads two new env vars that Phase 3 needs for the first time: `ADAPTER_HOSTNAME` and `ADMIN_HOSTNAME`. These are the public DNS hostnames the operator wants for the adapter and admin UI.

The prereq block also **creates the ALB controller's workload identity** — a second user-assigned managed identity separate from the adapter's Key Vault identity from Phase 1. The controller's identity gets federated with the AKS OIDC issuer for the service account `system:serviceaccount:azure-alb-system:alb-controller-sa`, and gets two role assignments: `Reader` on the MC_* node resource group, and `AppGw for Containers Configuration Manager` on the AGC subnet. Without these, the ALB controller that Phase 3 installs via Helm later will fail with auth errors.

**Why this is in the prereq block and not the ALB install step:** role assignments in Azure take time to propagate (Microsoft recommends 60 seconds). Creating the identity and granting RBAC early, then letting the other Phase 3 steps run for a while, means by the time we get to the Helm install in AZ17 the propagation has already happened.

### Prompt

*Copy the text below into Claude Code:*

```
Add the Phase 3 prerequisite check, hostname loading, and ALB
controller workload identity creation to the AKS wizard.

Pre-check:
1. Confirm deploy/azure-aks/azuresetup.sh exists with run_phase_3
   as a stub (should print "Phase 3 not yet implemented in
   scaffolding").
2. Confirm .azuresetup.state from a successful Phase 2 run has
   PHASE_2_COMPLETE=true along with KV_NAME, PG_FQDN, REDIS_FQDN,
   AGC_SUBNET_ID, WORKLOAD_IDENTITY_CLIENT_ID, AKS_OIDC_ISSUER,
   AKS_NAME, AZURE_RG.

Edits to deploy/azure-aks/azuresetup.sh:

Replace the run_phase_3 stub with the following body. Keep the
PLACEHOLDER comments in place — AZ15, AZ16, and AZ17 will each
replace one.

run_phase_3() {
  print_banner "Phase 3: Application + Ingress"

  # Step 3.0: Verify Phase 2 completed
  info "Step 3.0: Verifying Phase 2 completion..."
  if [[ "$(get_state PHASE_2_COMPLETE)" != "true" ]]; then
    die "Phase 2 has not completed. Run: ./azuresetup.sh --phase 2"
  fi

  # Reload state from Phases 1 and 2
  AZURE_SUBSCRIPTION_ID="$(get_state AZURE_SUBSCRIPTION_ID)"
  AZURE_LOCATION="$(get_state AZURE_LOCATION)"
  AZURE_RG="$(get_state AZURE_RG)"
  TENANT_ID="$(get_state TENANT_ID)"
  AKS_NAME="$(get_state AKS_NAME)"
  AKS_OIDC_ISSUER="$(get_state AKS_OIDC_ISSUER)"
  AZURE_ACR_NAME="$(get_state AZURE_ACR_NAME)"
  ACR_LOGIN_SERVER="$(get_state ACR_LOGIN_SERVER)"
  AGC_SUBNET_ID="$(get_state AGC_SUBNET_ID)"
  WORKLOAD_IDENTITY_CLIENT_ID="$(get_state WORKLOAD_IDENTITY_CLIENT_ID)"
  KV_NAME="$(get_state KV_NAME)"
  OKTA_DOMAIN="$(get_state OKTA_DOMAIN)"

  for var in AZURE_SUBSCRIPTION_ID AZURE_LOCATION AZURE_RG TENANT_ID \
             AKS_NAME AKS_OIDC_ISSUER AZURE_ACR_NAME ACR_LOGIN_SERVER \
             AGC_SUBNET_ID WORKLOAD_IDENTITY_CLIENT_ID KV_NAME \
             OKTA_DOMAIN; do
    [[ -z "${!var}" ]] && die "$var missing from state. Rerun Phase 1 or 2."
  done

  az account set --subscription "$AZURE_SUBSCRIPTION_ID"
  ok "Phase 1 and 2 state loaded"

  # Ensure kubectl context is set (the operator may have been on
  # a different cluster since Phase 1)
  info "Ensuring kubectl context points at $AKS_NAME..."
  az aks get-credentials -g "$AZURE_RG" -n "$AKS_NAME" \
    --overwrite-existing --output none
  ok "kubectl context set"

  # Step 3.1: Load and validate hostnames
  info "Step 3.1: Loading public hostnames..."

  ADAPTER_HOSTNAME="${ADAPTER_HOSTNAME:-$(get_state ADAPTER_HOSTNAME)}"
  ADMIN_HOSTNAME="${ADMIN_HOSTNAME:-$(get_state ADMIN_HOSTNAME)}"

  if $NON_INTERACTIVE; then
    [[ -z "$ADAPTER_HOSTNAME" ]] && die "ADAPTER_HOSTNAME not set (non-interactive mode)"
    [[ -z "$ADMIN_HOSTNAME" ]] && die "ADMIN_HOSTNAME not set (non-interactive mode)"
  else
    [[ -z "$ADAPTER_HOSTNAME" ]] && \
      prompt_required ADAPTER_HOSTNAME "Adapter hostname (e.g. mcp.example.com)"
    [[ -z "$ADMIN_HOSTNAME" ]] && \
      prompt_required ADMIN_HOSTNAME "Admin UI hostname (e.g. admin-mcp.example.com)"
  fi

  # Sanity check: must not be IPs, must contain a dot, must not be
  # the same as each other
  for hn in "$ADAPTER_HOSTNAME" "$ADMIN_HOSTNAME"; do
    if [[ ! "$hn" =~ \. ]] || [[ "$hn" =~ ^[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+$ ]]; then
      die "Hostname '$hn' is not a valid DNS name"
    fi
  done
  if [[ "$ADAPTER_HOSTNAME" == "$ADMIN_HOSTNAME" ]]; then
    die "ADAPTER_HOSTNAME and ADMIN_HOSTNAME must be different"
  fi

  save_state ADAPTER_HOSTNAME "$ADAPTER_HOSTNAME"
  save_state ADMIN_HOSTNAME "$ADMIN_HOSTNAME"
  ok "Adapter hostname: $ADAPTER_HOSTNAME"
  ok "Admin hostname:   $ADMIN_HOSTNAME"

  # Step 3.2: Create the ALB controller's workload identity
  # This is SEPARATE from the adapter's workload identity created in
  # Phase 1. The ALB controller runs as a pod in azure-alb-system and
  # needs its own managed identity with its own federated credential
  # and its own RBAC assignments.
  info "Step 3.2: Creating ALB controller workload identity..."
  ALB_IDENTITY_NAME="azure-alb-identity"

  if az identity show -g "$AZURE_RG" -n "$ALB_IDENTITY_NAME" &>/dev/null; then
    ok "Managed identity $ALB_IDENTITY_NAME already exists"
  else
    az identity create -g "$AZURE_RG" -n "$ALB_IDENTITY_NAME" \
      -l "$AZURE_LOCATION" --output none
    ok "Managed identity $ALB_IDENTITY_NAME created"
  fi
  ALB_IDENTITY_CLIENT_ID="$(az identity show -g "$AZURE_RG" \
    -n "$ALB_IDENTITY_NAME" --query clientId -o tsv)"
  ALB_IDENTITY_PRINCIPAL_ID="$(az identity show -g "$AZURE_RG" \
    -n "$ALB_IDENTITY_NAME" --query principalId -o tsv)"
  save_state ALB_IDENTITY_CLIENT_ID "$ALB_IDENTITY_CLIENT_ID"
  save_state ALB_IDENTITY_PRINCIPAL_ID "$ALB_IDENTITY_PRINCIPAL_ID"

  # Step 3.3: Federate the identity with the AKS OIDC issuer
  # The ALB Helm chart deploys a ServiceAccount named alb-controller-sa
  # in the azure-alb-system namespace. The federated credential binds
  # the managed identity to that specific service account.
  info "Step 3.3: Federating ALB identity with AKS OIDC issuer..."
  if az identity federated-credential list -g "$AZURE_RG" \
       --identity-name "$ALB_IDENTITY_NAME" \
       --query "[?name=='azure-alb-identity-fc']" -o tsv | grep -q .; then
    ok "Federated credential azure-alb-identity-fc already exists"
  else
    az identity federated-credential create \
      --name azure-alb-identity-fc \
      --identity-name "$ALB_IDENTITY_NAME" \
      --resource-group "$AZURE_RG" \
      --issuer "$AKS_OIDC_ISSUER" \
      --subject "system:serviceaccount:azure-alb-system:alb-controller-sa" \
      --output none
    ok "Federated credential created"
  fi

  # Step 3.4: Grant the ALB identity Reader on the AKS node RG (MC_*)
  # The controller reads AKS node metadata to figure out the cluster
  # topology. Without this it cannot start.
  info "Step 3.4: Granting ALB identity Reader on node resource group..."
  MC_RG="$(az aks show -g "$AZURE_RG" -n "$AKS_NAME" \
    --query nodeResourceGroup -o tsv)"
  MC_RG_ID="$(az group show -n "$MC_RG" --query id -o tsv)"
  save_state MC_RG "$MC_RG"

  if az role assignment list \
       --assignee "$ALB_IDENTITY_PRINCIPAL_ID" \
       --scope "$MC_RG_ID" \
       --query "[?roleDefinitionName=='Reader']" -o tsv | grep -q .; then
    ok "ALB identity already has Reader on $MC_RG"
  else
    az role assignment create \
      --role "Reader" \
      --assignee-object-id "$ALB_IDENTITY_PRINCIPAL_ID" \
      --assignee-principal-type ServicePrincipal \
      --scope "$MC_RG_ID" \
      --output none
    ok "Reader role granted on $MC_RG"
  fi

  # Step 3.5: Grant the ALB identity AppGw for Containers Configuration
  # Manager on the AGC subnet. This lets the controller provision
  # AGC resources inside agc-subnet.
  info "Step 3.5: Granting ALB identity subnet join permission..."
  if az role assignment list \
       --assignee "$ALB_IDENTITY_PRINCIPAL_ID" \
       --scope "$AGC_SUBNET_ID" \
       --query "[?roleDefinitionName=='AppGw for Containers Configuration Manager']" \
       -o tsv | grep -q .; then
    ok "ALB identity already has AppGw Configuration Manager on agc-subnet"
  else
    az role assignment create \
      --role "AppGw for Containers Configuration Manager" \
      --assignee-object-id "$ALB_IDENTITY_PRINCIPAL_ID" \
      --assignee-principal-type ServicePrincipal \
      --scope "$AGC_SUBNET_ID" \
      --output none
    ok "AppGw Configuration Manager role granted on agc-subnet"
  fi

  info "Waiting 60s for role assignments to propagate..."
  sleep 60
  ok "Propagation wait complete"

  # PLACEHOLDER for AZ15: Image build via az acr build
  # PLACEHOLDER for AZ16: Manifest substitution + kubectl apply
  # PLACEHOLDER for AZ17: ALB controller Helm install + AGC provisioning

  warn "AZ14 only — image build added in AZ15"
  exit 0
}

Verification:

1. bash -n deploy/azure-aks/azuresetup.sh
2. shellcheck deploy/azure-aks/azuresetup.sh (skip if not installed)

3. Synthesize a fake Phase 2 state for structural testing:
     cat >> deploy/azure-aks/.azuresetup.state <<'EOF'
     PHASE_2_COMPLETE=true
     KV_NAME=okta-mcp-kv-fake
     PG_FQDN=fake.postgres.database.azure.com
     REDIS_FQDN=fake.redis.cache.windows.net
     EOF

   If none of Phase 1 state is present, first add fake Phase 1 state:
     cat >> deploy/azure-aks/.azuresetup.state <<'EOF'
     PHASE_1_COMPLETE=true
     AZURE_SUBSCRIPTION_ID=00000000-0000-0000-0000-000000000000
     AZURE_LOCATION=eastus2
     AZURE_RG=okta-mcp-prod
     TENANT_ID=00000000-0000-0000-0000-000000000000
     AKS_NAME=okta-mcp-aks
     AKS_OIDC_ISSUER=https://eastus2.oic.prod-aks.azure.com/fake/fake/
     AZURE_ACR_NAME=oktamcpprodfake
     ACR_LOGIN_SERVER=oktamcpprodfake.azurecr.io
     AGC_SUBNET_ID=/subscriptions/00000000-0000-0000-0000-000000000000/resourceGroups/okta-mcp-prod/providers/Microsoft.Network/virtualNetworks/okta-mcp-vnet/subnets/agc-subnet
     WORKLOAD_IDENTITY_CLIENT_ID=00000000-0000-0000-0000-000000000000
     OKTA_DOMAIN=test.okta.com
     EOF

   Then run with hostnames set:
     ADAPTER_HOSTNAME=mcp.test.com \
     ADMIN_HOSTNAME=admin-mcp.test.com \
     ./deploy/azure-aks/azuresetup.sh --phase 3 --non-interactive

   Expected: passes state checks, attempts to connect to the fake
   cluster, fails at the kubectl context step OR the az identity
   step (fake RG doesn't exist). That's fine — goal is just to
   confirm the prereq block dispatches cleanly. Look for the
   "Phase 1 and 2 state loaded" ok line before it fails.

4. Clean up: rm -f deploy/azure-aks/.azuresetup.state

5. If AZURE_SMOKE_SUBSCRIPTION is set AND a real Phase 1 + Phase 2
   state file exists, optionally run Phase 3 for real. It will
   succeed for steps 3.0-3.5 and exit at the AZ15 placeholder. The
   ALB controller identity, federated credential, and role
   assignments will actually be created in Azure — these ARE
   billable resources but cost effectively zero.

Print a summary listing:
  - Lines added to azuresetup.sh
  - bash -n result
  - shellcheck result
  - Structural test result (ran to expected exit point)
  - Real-run result if AZURE_SMOKE_SUBSCRIPTION is set
```

### Expected Output

`run_phase_3()` now begins with a complete prereq block: Phase 2 completion guard, state reload, kubectl context refresh, hostname load and validation, ALB controller identity creation + federated credential + two role assignments + propagation wait. Stops at the AZ15 placeholder.

---

## Prompt AZ15: Image Build via az acr build

### Context

Builds the adapter, admin-ui, and hr-backend images using `az acr build` (server-side, no local Docker required). Unlike ACA Phase 2 which used `:latest` plus a timestamp tag, AKS uses `:<git-sha>` for immutable, reproducible rollouts. The git sha is captured into state and used in AZ16 when substituting image references into the manifest templates.

The `--skip-build` flag from the wizard's global args is honored here — if the operator passes `--skip-build`, this step is a no-op and AZ16 reuses whatever tag is already in state (useful for rerunning Phase 3 after a Phase 4 smoke test failure without rebuilding images).

### Prompt

*Copy the text below into Claude Code:*

```
Add the image build step to the AKS wizard's Phase 3.

Pre-check:
1. AZ14 has been completed: run_phase_3 ends at the
   "PLACEHOLDER for AZ15" line after the 60-second propagation wait.

Edits to deploy/azure-aks/azuresetup.sh:

Replace the "PLACEHOLDER for AZ15" block in run_phase_3 with:

  # Step 3.6: Build images via az acr build
  info "Step 3.6: Building images..."

  # Resolve the repo root — wizard lives at deploy/azure-aks/
  REPO_ROOT="$(cd "$SCRIPT_DIR/../.." && pwd)"

  # Resolve the image tag. For production we use the git sha so
  # rollouts are immutable and reproducible. Fall back to "manual"
  # if we're not inside a git repo.
  IMAGE_TAG="$(get_state IMAGE_TAG)"
  if [[ -z "$IMAGE_TAG" ]] || ! $SKIP_BUILD; then
    if git -C "$REPO_ROOT" rev-parse --short HEAD &>/dev/null; then
      IMAGE_TAG="$(git -C "$REPO_ROOT" rev-parse --short HEAD)"
    else
      IMAGE_TAG="manual-$(date +%Y%m%d-%H%M%S)"
      warn "Not inside a git repo — using tag $IMAGE_TAG"
    fi
    save_state IMAGE_TAG "$IMAGE_TAG"
  fi
  ok "Image tag: $IMAGE_TAG"

  if $SKIP_BUILD; then
    info "Step 3.6: Skipping image builds (--skip-build)"
    ok "Reusing existing tag $IMAGE_TAG in ACR"
  else
    info "Building adapter image..."
    az acr build --registry "$AZURE_ACR_NAME" \
      --image "adapter:$IMAGE_TAG" \
      --file "$REPO_ROOT/Dockerfile" \
      "$REPO_ROOT" \
      --output none
    ok "adapter:$IMAGE_TAG built"

    info "Building admin-ui image..."
    az acr build --registry "$AZURE_ACR_NAME" \
      --image "admin-ui:$IMAGE_TAG" \
      --file "$REPO_ROOT/okta_agent_proxy_admin_ui/Dockerfile" \
      "$REPO_ROOT/okta_agent_proxy_admin_ui" \
      --output none
    ok "admin-ui:$IMAGE_TAG built"

    info "Building hr-backend image..."
    az acr build --registry "$AZURE_ACR_NAME" \
      --image "hr-backend:$IMAGE_TAG" \
      --file "$REPO_ROOT/examples/01-hr-system/Dockerfile" \
      "$REPO_ROOT/examples/01-hr-system" \
      --output none
    ok "hr-backend:$IMAGE_TAG built"
  fi

  # Verify all three tags exist in ACR
  info "Verifying images in ACR..."
  for repo in adapter admin-ui hr-backend; do
    if ! az acr repository show-tags \
           --name "$AZURE_ACR_NAME" \
           --repository "$repo" \
           --query "contains(@, '$IMAGE_TAG')" -o tsv | grep -qi true; then
      die "Image $repo:$IMAGE_TAG not found in ACR. Build failed?"
    fi
    ok "$repo:$IMAGE_TAG confirmed in ACR"
  done

Verification:

1. bash -n deploy/azure-aks/azuresetup.sh
2. shellcheck deploy/azure-aks/azuresetup.sh (skip if not installed)
3. Structural check: confirm --skip-build branch is reachable
     grep -n "SKIP_BUILD" deploy/azure-aks/azuresetup.sh
4. If AZURE_SMOKE_SUBSCRIPTION is set and a Phase 2 state from a
   real run exists, optionally run with --phase 3 to exercise the
   real build. Takes ~5-8 minutes total.

Print a summary with file size delta, bash -n result, and
shellcheck result.
```

### Expected Output

Three images built and pushed to ACR with git-sha tags. The `IMAGE_TAG` is captured into state for AZ16 to consume. `--skip-build` is honored for rerun scenarios.

---

## Prompt AZ16: Manifest Substitution + kubectl Apply

### Context

The 10 YAML templates in `deploy/azure-aks/manifests/` (created in AZ3, corrected in AZ13) contain `__PLACEHOLDER__` tokens that need real values substituted before they can be applied. Rather than cluttering the wizard with inline `sed` calls, this prompt adds a `substitute_manifest()` helper to `azure-helpers.sh` that takes a source manifest path, a destination path, and a list of `NAME=value` substitutions, and fails fast if any declared placeholder from the manifest header comment wasn't substituted.

After substituting all 10 manifests into a temp directory, the wizard applies them in dependency order (namespace/SA first, then CSI SecretProviderClass + ConfigMap, then workload Deployments, then HPA/PDB/NetworkPolicies). It waits for each workload rollout, verifies the Key Vault CSI secret was materialized, and prints pod status at the end.

**Ordering matters.** The Deployments can't start until the SecretProviderClass has been applied (otherwise the CSI volume mount fails), and the NetworkPolicies can't be applied until the pods exist (otherwise the selectors match nothing and the default-deny rule silently isolates all traffic before the adapter is up).

### Prompt

*Copy the text below into Claude Code:*

```
Add manifest substitution and kubectl apply logic to the AKS wizard's
Phase 3. Introduce a substitute_manifest() helper in azure-helpers.sh.

Pre-check:
1. AZ15 has been completed: run_phase_3 ends at the image build /
   IMAGE_TAG capture with image verification.
2. deploy/azure-aks/manifests/ contains 10 YAML files from AZ3/AZ13
   with __PLACEHOLDER__ tokens declared in header comments.

PART A — Add helper to azure-helpers.sh

Edit BOTH deploy/azure-aks/shell-lib/azure-helpers.sh AND
deploy/azure-aca/shell-lib/azure-helpers.sh to add the function
below. They must remain byte-identical after this edit.

  # substitute_manifest SRC DEST KEY1=VAL1 [KEY2=VAL2 ...]
  #   Reads SRC, substitutes __KEY__ tokens with VAL values, writes
  #   to DEST. Validates that every __NAME__ declared in the source
  #   file's header comment was substituted (the header comment
  #   lists placeholders on lines starting with "# Placeholders:").
  #   Dies if any declared placeholder remains or if any token in
  #   the body wasn't declared in the header.
  substitute_manifest() {
    local src="$1" dest="$2"
    shift 2

    [[ -f "$src" ]] || die "substitute_manifest: source $src not found"

    # Build sed expressions from the KEY=VAL args
    local sed_args=()
    local -A subs
    for kv in "$@"; do
      local k="${kv%%=*}"
      local v="${kv#*=}"
      subs["$k"]=1
      # Use | as sed delimiter to avoid issues with / in ARM IDs
      sed_args+=( -e "s|__${k}__|${v}|g" )
    done

    # Apply substitutions
    sed "${sed_args[@]}" "$src" > "$dest"

    # Validate: parse declared placeholders from the header comment
    local declared
    declared=$(awk '/^#/ {print} !/^#/ {exit}' "$src" | \
               grep -oE '__[A-Z_]+__' | sort -u || true)

    # Check every declared placeholder was substituted (i.e. is NOT
    # present in dest). If any remain in dest, die.
    for ph in $declared; do
      if grep -q "$ph" "$dest"; then
        die "substitute_manifest: placeholder $ph in $src was not substituted"
      fi
    done

    # Check every substitution key was actually needed (i.e. was
    # declared in the header). This catches typos like passing
    # KV_URI when the header only has KV_NAME.
    for k in "${!subs[@]}"; do
      if ! echo "$declared" | grep -q "__${k}__"; then
        warn "substitute_manifest: key $k was not declared in $src header (unused?)"
      fi
    done
  }

After editing both files, verify:
  diff deploy/azure-aks/shell-lib/azure-helpers.sh \
       deploy/azure-aca/shell-lib/azure-helpers.sh
  # Should produce no output.

PART B — Edit deploy/azure-aks/azuresetup.sh

Replace the "PLACEHOLDER for AZ16" block in run_phase_3 with:

  # Step 3.7: Substitute manifest templates into a temp directory
  info "Step 3.7: Materializing manifest templates..."
  RENDERED_DIR="$(mktemp -d)"
  trap 'rm -rf "$RENDERED_DIR"' EXIT

  MANIFESTS_SRC="$SCRIPT_DIR/manifests"
  [[ -d "$MANIFESTS_SRC" ]] || die "Missing manifests directory: $MANIFESTS_SRC"

  # Namespace + ServiceAccount — needs workload identity client ID
  substitute_manifest \
    "$MANIFESTS_SRC/00-namespace-sa.yaml" \
    "$RENDERED_DIR/00-namespace-sa.yaml" \
    "WORKLOAD_IDENTITY_CLIENT_ID=$WORKLOAD_IDENTITY_CLIENT_ID"

  # SecretProviderClass — needs KV name, tenant, workload identity
  substitute_manifest \
    "$MANIFESTS_SRC/01-spc-keyvault.yaml" \
    "$RENDERED_DIR/01-spc-keyvault.yaml" \
    "KV_NAME=$KV_NAME" \
    "TENANT_ID=$TENANT_ID" \
    "WORKLOAD_IDENTITY_CLIENT_ID=$WORKLOAD_IDENTITY_CLIENT_ID"

  # ConfigMap — only OKTA_DOMAIN (per AZ13 correction)
  substitute_manifest \
    "$MANIFESTS_SRC/02-configmap.yaml" \
    "$RENDERED_DIR/02-configmap.yaml" \
    "OKTA_DOMAIN=$OKTA_DOMAIN"

  # Workload deployments — need ACR login server and image tag
  # NOTE: the templates from AZ3 hardcode ":latest" in the image
  # reference. We substitute the registry but then also do a
  # sed pass to replace :latest with :$IMAGE_TAG for reproducibility.
  for f in 20-adapter.yaml 21-admin-ui.yaml 22-hr-backend.yaml; do
    substitute_manifest \
      "$MANIFESTS_SRC/$f" \
      "$RENDERED_DIR/$f" \
      "ACR_LOGIN_SERVER=$ACR_LOGIN_SERVER"
    # Pin image tags to the git sha from AZ15
    sed -i.bak "s|:latest|:$IMAGE_TAG|g" "$RENDERED_DIR/$f"
    rm -f "$RENDERED_DIR/$f.bak"
  done

  # ALB (30), Gateway (31), HTTPRoutes (32) — hostnames and AGC subnet
  # Applied in AZ17 (AGC provisioning), but materialized here so all
  # rendering happens in one place.
  substitute_manifest \
    "$MANIFESTS_SRC/30-alb.yaml" \
    "$RENDERED_DIR/30-alb.yaml" \
    "AGC_SUBNET_ID=$AGC_SUBNET_ID"

  cp "$MANIFESTS_SRC/31-gateway.yaml" "$RENDERED_DIR/31-gateway.yaml"

  substitute_manifest \
    "$MANIFESTS_SRC/32-routes.yaml" \
    "$RENDERED_DIR/32-routes.yaml" \
    "ADAPTER_HOSTNAME=$ADAPTER_HOSTNAME" \
    "ADMIN_HOSTNAME=$ADMIN_HOSTNAME"

  # Network policies — no substitution (hardcoded CIDRs from AZ3)
  cp "$MANIFESTS_SRC/40-network-policies.yaml" \
     "$RENDERED_DIR/40-network-policies.yaml"

  save_state RENDERED_DIR "$RENDERED_DIR"
  ok "10 manifests materialized into $RENDERED_DIR"

  # Step 3.8: Apply namespace + ServiceAccount first
  info "Step 3.8: Applying namespace and ServiceAccount..."
  kubectl apply -f "$RENDERED_DIR/00-namespace-sa.yaml"

  # Step 3.9: Apply SecretProviderClass and ConfigMap
  info "Step 3.9: Applying SecretProviderClass and ConfigMap..."
  kubectl apply -f "$RENDERED_DIR/01-spc-keyvault.yaml"
  kubectl apply -f "$RENDERED_DIR/02-configmap.yaml"

  # Step 3.10: Apply workload Deployments and Services
  info "Step 3.10: Applying workload deployments..."
  kubectl apply -f "$RENDERED_DIR/20-adapter.yaml"
  kubectl apply -f "$RENDERED_DIR/21-admin-ui.yaml"
  kubectl apply -f "$RENDERED_DIR/22-hr-backend.yaml"

  # Step 3.11: Wait for rollouts
  info "Step 3.11: Waiting for workload rollouts..."
  kubectl -n okta-mcp rollout status deployment/okta-mcp-adapter --timeout=300s
  kubectl -n okta-mcp rollout status deployment/admin-ui --timeout=180s
  kubectl -n okta-mcp rollout status deployment/hr-mcp-server --timeout=180s
  ok "All three workloads rolled out"

  # Step 3.12: Verify the Key Vault CSI secret was materialized
  # This proves the Secrets Store CSI driver could authenticate to
  # Key Vault and pull the 4 secrets that Phase 2 wrote. If this
  # fails, the workload identity RBAC from Phase 2 is misconfigured.
  info "Step 3.12: Verifying Key Vault secret materialization..."
  local secret_keys
  secret_keys=$(kubectl -n okta-mcp get secret okta-mcp-secrets \
    -o jsonpath='{.data}' 2>/dev/null || echo "")
  if [[ -z "$secret_keys" ]]; then
    fail "Secret okta-mcp-secrets was NOT materialized."
    fail "This usually means workload identity cannot read Key Vault."
    fail "Debug: kubectl -n okta-mcp describe pod -l app=okta-mcp-adapter"
    die "Aborting Phase 3"
  fi
  # Count keys without printing values
  local key_count
  key_count=$(kubectl -n okta-mcp get secret okta-mcp-secrets \
    -o jsonpath='{.data}' | jq 'length' 2>/dev/null || echo "0")
  if [[ "$key_count" -lt 4 ]]; then
    warn "Expected 4 keys in okta-mcp-secrets, found $key_count"
  fi
  ok "Key Vault secret materialized with $key_count keys"

  # Step 3.13: Apply HPA, PDB, and network policies
  # Network policies must come AFTER the workload pods exist so the
  # default-deny doesn't orphan the first pod scheduling attempt.
  info "Step 3.13: Applying NetworkPolicies..."
  kubectl apply -f "$RENDERED_DIR/40-network-policies.yaml"
  ok "NetworkPolicies applied"

  # Step 3.14: Print workload status
  info "Step 3.14: Current workload state:"
  kubectl get pods,svc,hpa,pdb -n okta-mcp

  # PLACEHOLDER for AZ17: ALB controller Helm install + AGC provisioning

  warn "AZ16 only — ALB controller and AGC added in AZ17"
  exit 0

Verification:

1. diff deploy/azure-aks/shell-lib/azure-helpers.sh \
        deploy/azure-aca/shell-lib/azure-helpers.sh
   Should produce no output.

2. bash -n deploy/azure-aks/azuresetup.sh
3. bash -n deploy/azure-aks/shell-lib/azure-helpers.sh
4. shellcheck on both (skip if not installed)

5. Unit test substitute_manifest in isolation:
     # Create a fake manifest with declared placeholders
     cat > /tmp/test-manifest.yaml <<'EOF'
     # Test manifest
     # Placeholders: __FOO__ __BAR__
     apiVersion: v1
     kind: ConfigMap
     metadata:
       name: __FOO__
       namespace: __BAR__
     EOF
     source deploy/azure-aks/shell-lib/common.sh
     source deploy/azure-aks/shell-lib/azure-helpers.sh
     substitute_manifest /tmp/test-manifest.yaml /tmp/test-out.yaml \
       FOO=hello BAR=world
     cat /tmp/test-out.yaml
     # Expected: foo and bar values substituted, no __ tokens left
     rm -f /tmp/test-manifest.yaml /tmp/test-out.yaml

6. Negative test: missing substitution should die
     cat > /tmp/test-manifest.yaml <<'EOF'
     # Test
     # Placeholders: __FOO__ __BAR__
     name: __FOO__
     ns: __BAR__
     EOF
     set +e
     substitute_manifest /tmp/test-manifest.yaml /tmp/test-out.yaml FOO=hello
     exit_code=$?
     set -e
     [[ $exit_code -ne 0 ]] || die "Negative test failed: expected nonzero exit"
     rm -f /tmp/test-manifest.yaml /tmp/test-out.yaml

Print a summary with byte delta, bash -n results, helper diff result,
and the unit test + negative test outcomes.
```

### Expected Output

`substitute_manifest` added to both copies of `azure-helpers.sh` (verified identical). `run_phase_3()` now materializes all 10 manifests, applies them in correct dependency order, waits for rollouts, verifies the Key Vault CSI secret, applies NetworkPolicies after pods exist, and prints workload status. Stops at the AZ17 placeholder.

---

## Prompt AZ17: ALB Controller Helm Install + AGC Provisioning

### Context

Installs the ALB controller into `azure-alb-system` namespace via Helm (using the OCI registry `oci://mcr.microsoft.com/application-lb/charts/alb-controller`), passing the `albController.podIdentity.clientID` value that wires it to the managed identity AZ14 created. Version is NOT pinned — whatever is current at install time is captured into state for reproducibility. Waits for the controller deployment to roll out.

Then applies the ApplicationLoadBalancer CR, Gateway, and HTTPRoute resources from the rendered manifests directory (AZ16 already materialized them). Polls until the `Gateway` has a programmed address, captures the AGC FQDN into state, and prints CNAME instructions for the operator.

This is where Phase 3 ends. The operator is expected to create the two DNS CNAMEs pointing at the AGC FQDN, wait for propagation, then run `./azuresetup.sh --phase 4` when they're ready for smoke tests and lockdown.

### Prompt

*Copy the text below into Claude Code:*

```
Add the ALB controller Helm install and AGC provisioning steps to
the AKS wizard's Phase 3. This is the last step before the operator
has to take manual action (DNS) and re-run as Phase 4.

Pre-check:
1. AZ16 has been completed: run_phase_3 ends after applying
   NetworkPolicies and printing workload state.

Edits to deploy/azure-aks/azuresetup.sh:

Replace the "PLACEHOLDER for AZ17" block with:

  # Step 3.15: Install ALB controller via Helm
  info "Step 3.15: Installing ALB controller via Helm..."
  info "         Pulling from oci://mcr.microsoft.com/application-lb/charts/alb-controller"
  info "         Version is NOT pinned — using current."

  # helm registry login is not needed for the public MCR OCI registry
  # but some helm versions emit a warning — suppress it

  if helm status alb-controller -n azure-alb-system &>/dev/null; then
    ok "ALB controller already installed — running helm upgrade"
    HELM_ACTION=upgrade
  else
    HELM_ACTION=install
  fi

  helm "$HELM_ACTION" alb-controller \
    oci://mcr.microsoft.com/application-lb/charts/alb-controller \
    --namespace azure-alb-system \
    --create-namespace \
    --set "albController.podIdentity.clientID=$ALB_IDENTITY_CLIENT_ID" \
    --wait --timeout 5m
  ok "ALB controller Helm $HELM_ACTION complete"

  # Capture the installed version for reproducibility
  ALB_CHART_VERSION="$(helm list -n azure-alb-system -o json | \
    jq -r '.[] | select(.name=="alb-controller") | .chart' | \
    sed 's/alb-controller-//')"
  save_state ALB_CHART_VERSION "$ALB_CHART_VERSION"
  ok "Installed ALB controller chart: alb-controller-$ALB_CHART_VERSION"

  # Step 3.16: Wait for the ALB controller deployment to be ready
  info "Step 3.16: Waiting for ALB controller pods..."
  kubectl -n azure-alb-system rollout status deployment/alb-controller \
    --timeout=300s
  ok "ALB controller is ready"

  # Step 3.17: Apply the ApplicationLoadBalancer custom resource
  # This tells the controller to provision an AGC instance bound to
  # agc-subnet. Takes ~2-5 minutes to provision.
  info "Step 3.17: Creating ApplicationLoadBalancer CR..."
  kubectl apply -f "$RENDERED_DIR/30-alb.yaml"

  # Poll until status shows Deployment=Ready (up to 10 min)
  info "Waiting for ApplicationLoadBalancer to be Ready..."
  local alb_elapsed=0 alb_max=600
  local alb_state=""
  while (( alb_elapsed < alb_max )); do
    alb_state=$(kubectl get applicationloadbalancer okta-mcp-alb \
      -n okta-mcp \
      -o jsonpath='{.status.conditions[?(@.type=="Deployment")].status}' \
      2>/dev/null || echo "")
    if [[ "$alb_state" == "True" ]]; then
      echo ""
      ok "ApplicationLoadBalancer Ready after ${alb_elapsed}s"
      break
    fi
    printf "."
    sleep 15
    alb_elapsed=$((alb_elapsed + 15))
  done
  echo ""
  if [[ "$alb_state" != "True" ]]; then
    fail "ApplicationLoadBalancer did not reach Ready after ${alb_max}s"
    fail "Inspect with: kubectl describe applicationloadbalancer okta-mcp-alb -n okta-mcp"
    fail "And: kubectl logs -n azure-alb-system deployment/alb-controller"
    die "Aborting Phase 3"
  fi

  # Step 3.18: Apply the Gateway and HTTPRoutes
  info "Step 3.18: Applying Gateway and HTTPRoutes..."
  kubectl apply -f "$RENDERED_DIR/31-gateway.yaml"
  kubectl apply -f "$RENDERED_DIR/32-routes.yaml"

  # Step 3.19: Wait for the Gateway to have a programmed address
  info "Step 3.19: Waiting for Gateway to get a programmed address..."
  local gw_elapsed=0 gw_max=300 gw_fqdn=""
  while (( gw_elapsed < gw_max )); do
    gw_fqdn=$(kubectl get gateway okta-mcp-gw -n okta-mcp \
      -o jsonpath='{.status.addresses[0].value}' 2>/dev/null || echo "")
    if [[ -n "$gw_fqdn" ]]; then
      echo ""
      ok "Gateway programmed after ${gw_elapsed}s"
      break
    fi
    printf "."
    sleep 10
    gw_elapsed=$((gw_elapsed + 10))
  done
  echo ""
  if [[ -z "$gw_fqdn" ]]; then
    fail "Gateway did not reach a programmed state after ${gw_max}s"
    fail "Inspect with: kubectl describe gateway okta-mcp-gw -n okta-mcp"
    die "Aborting Phase 3"
  fi
  save_state AGC_FQDN "$gw_fqdn"

  # Step 3.20: Mark Phase 3 complete and print CNAME instructions
  save_state PHASE_3_COMPLETE "true"

  print_summary_box "Phase 3 Complete: Application Deployed" \
    "AGC FQDN: $gw_fqdn" \
    "" \
    "NEXT STEP — Create DNS records:" \
    "" \
    "  $ADAPTER_HOSTNAME   CNAME   $gw_fqdn" \
    "  $ADMIN_HOSTNAME     CNAME   $gw_fqdn" \
    "" \
    "After DNS has propagated (5-30 min), run:" \
    "  ./azuresetup.sh --phase 4" \
    "" \
    "Phase 4 runs smoke tests, enables Container Insights," \
    "and disables Key Vault public network access."
}

Verification:

1. bash -n deploy/azure-aks/azuresetup.sh
2. shellcheck deploy/azure-aks/azuresetup.sh (skip if not installed)

3. Grep verify that Helm install uses client ID correctly:
     grep "albController.podIdentity.clientID" deploy/azure-aks/azuresetup.sh
     # Should find exactly 1 match

4. If AZURE_SMOKE_SUBSCRIPTION is set and AZ14-AZ16 have been run
   for real, optionally execute Phase 3 end-to-end. Wall-clock is
   ~15 minutes (5 min build + 5 min deploy + 5 min AGC). At the
   end, verify:
     - PHASE_3_COMPLETE=true in state
     - AGC_FQDN captured in state
     - All three workload deployments are Running
     - ApplicationLoadBalancer shows Deployment=True
     - Gateway shows a programmed address
     - Summary box printed with CNAME instructions

Print a final Phase 3 summary with file size and check results.
```

### Expected Output

`run_phase_3()` is now complete end to end. After AZ17, an operator runs `./azuresetup.sh --phase 3`, waits ~15 minutes for the image build + deploy + AGC provisioning, and gets a summary box with the AGC FQDN and CNAME instructions. They then configure DNS themselves and run Phase 4 when ready.

---

## Prompt AZ18: Phase 4 Smoke Tests + Container Insights

### Context

Phase 4 is much smaller than Phase 3. This prompt covers the observability enable and the five smoke tests. The next prompt (AZ19) handles the Key Vault lockdown and final summary.

The smoke tests are the same five used in the ACA wizard. The first two (oauth metadata, health) hit public endpoints via HTTPS against `$ADAPTER_HOSTNAME`. The next two (admin login, list agents) use the admin password read from the Kubernetes secret (which was materialized from Key Vault in Phase 3 via the CSI driver). The fifth (`cache_provider=redis`) is non-fatal with a warning — matching ACA — because the `/health/cache` endpoint may not exist on the adapter yet.

The smoke tests depend on DNS being propagated and the AGC managed certificate being issued. Both of those are out of the wizard's control and operator-dependent. If the tests fail, it's likely DNS or cert propagation, not an adapter issue.

### Prompt

*Copy the text below into Claude Code:*

```
Add the Phase 4 prerequisite check, Container Insights enable, and
smoke tests to the AKS wizard.

Pre-check:
1. run_phase_4 is still a stub from AZ4 that prints "Phase 4 not
   yet implemented in scaffolding".

Replace the run_phase_4 stub with:

run_phase_4() {
  print_banner "Phase 4: Smoke Tests + Lockdown"

  # Step 4.0: Verify Phase 3 completed
  info "Step 4.0: Verifying Phase 3 completion..."
  if [[ "$(get_state PHASE_3_COMPLETE)" != "true" ]]; then
    die "Phase 3 has not completed. Run: ./azuresetup.sh --phase 3"
  fi

  # Reload state
  AZURE_RG="$(get_state AZURE_RG)"
  AKS_NAME="$(get_state AKS_NAME)"
  KV_NAME="$(get_state KV_NAME)"
  ADAPTER_HOSTNAME="$(get_state ADAPTER_HOSTNAME)"
  ADMIN_HOSTNAME="$(get_state ADMIN_HOSTNAME)"
  AGC_FQDN="$(get_state AGC_FQDN)"

  for var in AZURE_RG AKS_NAME KV_NAME ADAPTER_HOSTNAME ADMIN_HOSTNAME \
             AGC_FQDN; do
    [[ -z "${!var}" ]] && die "$var missing from state. Rerun Phase 3."
  done
  ok "Phase 3 state loaded"

  # Ensure kubectl context is fresh
  az aks get-credentials -g "$AZURE_RG" -n "$AKS_NAME" \
    --overwrite-existing --output none

  # Step 4.1: Verify DNS resolves for both hostnames
  # If the operator ran Phase 4 before creating CNAMEs, the smoke
  # tests will fail with TLS or connection errors that are confusing.
  # Check DNS first and give a clear message.
  info "Step 4.1: Verifying DNS resolution..."
  for hn in "$ADAPTER_HOSTNAME" "$ADMIN_HOSTNAME"; do
    local resolved
    resolved=$(getent hosts "$hn" 2>/dev/null | head -1 | awk '{print $1}' || true)
    if [[ -z "$resolved" ]]; then
      fail "$hn does not resolve in DNS."
      fail "Create these CNAME records before running Phase 4:"
      fail "  $ADAPTER_HOSTNAME   CNAME   $AGC_FQDN"
      fail "  $ADMIN_HOSTNAME     CNAME   $AGC_FQDN"
      die "Aborting Phase 4 — DNS not ready"
    fi
    ok "$hn -> $resolved"
  done

  # Step 4.2: Enable Container Insights
  info "Step 4.2: Enabling Container Insights..."
  if az aks show -g "$AZURE_RG" -n "$AKS_NAME" \
       --query "addonProfiles.omsagent.enabled" -o tsv 2>/dev/null | \
       grep -qi true; then
    ok "Container Insights already enabled"
  else
    az aks enable-addons -g "$AZURE_RG" -n "$AKS_NAME" \
      --addons monitoring --output none
    ok "Container Insights enabled"
    info "Waiting 60s for the agent DaemonSet to come up..."
    sleep 60
  fi

  # Step 4.3: Smoke tests
  info "Step 4.3: Running smoke tests against https://$ADAPTER_HOSTNAME ..."
  local pass=0 total=5

  # Smoke 1: oauth-protected-resource metadata
  if curl -sf "https://$ADAPTER_HOSTNAME/.well-known/oauth-protected-resource" \
       >/dev/null 2>&1; then
    ok "Smoke 1/5: oauth-protected-resource metadata"
    pass=$((pass + 1))
  else
    fail "Smoke 1/5: oauth-protected-resource metadata"
    warn "  If this is the first Phase 4 run after Phase 3, the AGC"
    warn "  managed certificate may still be provisioning (up to 30 min"
    warn "  after DNS propagation)."
  fi

  # Smoke 2: health endpoint
  if curl -sf "https://$ADAPTER_HOSTNAME/health" >/dev/null 2>&1; then
    ok "Smoke 2/5: health endpoint"
    pass=$((pass + 1))
  else
    fail "Smoke 2/5: health endpoint"
  fi

  # Smoke 3: admin login
  # Read the admin password from the k8s secret (materialized from
  # Key Vault via the CSI driver in Phase 3)
  local admin_pw
  admin_pw=$(kubectl -n okta-mcp get secret okta-mcp-secrets \
    -o jsonpath='{.data.ADMIN_PASSWORD}' 2>/dev/null | base64 -d || true)
  if [[ -z "$admin_pw" ]]; then
    warn "Smoke 3/5: could not read admin password from secret"
  else
    local login_response access_token
    login_response=$(curl -sf -X POST "https://$ADAPTER_HOSTNAME/api/admin/login" \
      -H "Content-Type: application/json" \
      -d "{\"username\":\"admin\",\"password\":\"$admin_pw\"}" \
      2>/dev/null || true)
    access_token=$(echo "$login_response" | jq -r '.access_token // empty' \
      2>/dev/null || true)
    if [[ -n "$access_token" ]]; then
      ok "Smoke 3/5: admin login"
      pass=$((pass + 1))
    else
      fail "Smoke 3/5: admin login (no access_token in response)"
    fi
  fi

  # Smoke 4: list agents with token from smoke 3
  if [[ -n "${access_token:-}" ]]; then
    if curl -sf "https://$ADAPTER_HOSTNAME/api/admin/agents" \
         -H "Authorization: Bearer $access_token" >/dev/null 2>&1; then
      ok "Smoke 4/5: list agents"
      pass=$((pass + 1))
    else
      fail "Smoke 4/5: list agents"
    fi
  else
    warn "Smoke 4/5: skipped (no token from smoke 3)"
  fi

  # Smoke 5: cache_provider=redis confirmation
  # NON-FATAL — the /health/cache endpoint may not exist on the
  # adapter yet. Mirrors the ACA treatment.
  local cache_health
  cache_health=$(curl -sf "https://$ADAPTER_HOSTNAME/health/cache" 2>/dev/null || \
                 curl -sf "https://$ADAPTER_HOSTNAME/health" 2>/dev/null || true)
  if echo "$cache_health" | grep -q '"cache_provider":\s*"redis"' 2>/dev/null; then
    ok "Smoke 5/5: cache_provider=redis confirmed"
    pass=$((pass + 1))
  else
    warn "Smoke 5/5: could not confirm cache_provider=redis"
    warn "          (the adapter may not expose this endpoint yet — non-fatal)"
  fi

  info "Smoke results: ${pass}/${total} passed"
  save_state LAST_SMOKE_PASS "$pass"
  save_state LAST_SMOKE_TOTAL "$total"

  # If none of the security-critical smoke tests passed, bail out
  # before we lock down Key Vault. We don't want an unreachable
  # adapter AND a sealed vault.
  if (( pass < 2 )); then
    fail "Only $pass/$total smoke tests passed."
    fail "Refusing to proceed with Key Vault lockdown."
    fail "Investigate the deployment before running Phase 4 again."
    die "Aborting Phase 4"
  fi

  # PLACEHOLDER for AZ19: Key Vault lockdown + final summary

  warn "AZ18 only — Key Vault lockdown and final summary added in AZ19"
  exit 0
}

Verification:

1. bash -n deploy/azure-aks/azuresetup.sh
2. shellcheck deploy/azure-aks/azuresetup.sh (skip if not installed)

3. Confirm the "refuse to proceed if smoke tests fail" guard exists:
     grep -A2 "Refusing to proceed" deploy/azure-aks/azuresetup.sh

Print a summary with file size delta, bash -n result, and
shellcheck result.
```

### Expected Output

`run_phase_4()` now has a complete prereq + DNS check + Container Insights enable + 5 smoke tests. Stops at the AZ19 placeholder. If fewer than 2 smoke tests pass, the phase aborts before AZ19's Key Vault lockdown can run — a deliberate safety guard so you never end up with an unreachable adapter behind a sealed vault.

---

## Prompt AZ19: Phase 4 Key Vault Lockdown + Final Summary + README

### Context

The last prompt. Closes the Phase 2 "public access enabled" window on Key Vault by setting `publicNetworkAccess=Disabled`. Prints the final summary box with URLs, cost breakdown, and teardown command. Marks `PHASE_4_COMPLETE=true`. Updates the README to reflect that the wizard is now fully complete and documents the day-in-the-life operations.

After AZ19 the AKS wizard is **done**. Both wizards (AKS and ACA) are complete, tested, packageable, and ready to ship.

### Prompt

*Copy the text below into Claude Code:*

```
Add the Key Vault lockdown, final summary box, and README completion
to the AKS wizard's Phase 4.

Pre-check:
1. AZ18 has been completed: run_phase_4 ends at the
   "PLACEHOLDER for AZ19" line after the smoke test guard.

PART A — Edit deploy/azure-aks/azuresetup.sh

Replace the "PLACEHOLDER for AZ19" block with:

  # Step 4.4: Lock down Key Vault public network access
  # This closes the "public-then-disable" window opened in Phase 2.
  # The adapter pods authenticate via workload identity, not via
  # public endpoint — so locking it down has no effect on runtime.
  info "Step 4.4: Disabling Key Vault public network access..."
  local kv_public
  kv_public=$(az keyvault show -n "$KV_NAME" \
    --query "properties.publicNetworkAccess" -o tsv 2>/dev/null || echo "")
  if [[ "$kv_public" == "Disabled" ]]; then
    ok "Key Vault public access already Disabled"
  else
    az keyvault update -n "$KV_NAME" \
      --public-network-access Disabled --output none
    ok "Key Vault public access disabled"
  fi

  # Step 4.5: Print the final summary box
  save_state PHASE_4_COMPLETE "true"

  local smoke_summary="${pass}/${total} smoke tests passed"

  print_summary_box "Phase 4 Complete: Wizard Done" \
    "Adapter URL:  https://$ADAPTER_HOSTNAME" \
    "Admin URL:    https://$ADMIN_HOSTNAME" \
    "" \
    "$smoke_summary" \
    "" \
    "Key Vault:    $KV_NAME (PRIVATE)" \
    "Postgres:     $(get_state PG_FQDN)" \
    "Redis:        $(get_state REDIS_FQDN) (PRIVATE)" \
    "" \
    "Est. cost:    ~\$700/mo on-demand" \
    "              ~\$550/mo with 1-yr RIs" \
    "" \
    "Teardown:     ./azuresetup.sh --destroy" \
    "              (deletes the entire resource group)"
}

PART B — Edit deploy/azure-aks/README.md

1. In the "Phases" section, change any remaining "not yet implemented"
   or "stub" text for Phases 3 and 4 to their actual descriptions:

   | Phase | Name | Creates | Duration |
   |---|---|---|---|
   | 1 | Foundation | RG, providers, ACR, VNet, AKS Automatic, workload identity | ~10 min |
   | 2 | Stateful tier | Postgres GP, Redis Standard, Key Vault, 4 secrets | ~25 min |
   | 3 | Application + ingress | Image build, K8s deploy, ALB controller, AGC, Gateway API | ~15 min + DNS |
   | 4 | Smoke + lockdown | DNS check, Container Insights, 5 smoke tests, KV lockdown | ~5 min |

2. Add a new section after "Phases" titled "The DNS gap between
   Phase 3 and Phase 4":

   ## The DNS gap between Phase 3 and Phase 4

   Phase 3 ends by creating the Application Gateway for Containers
   (AGC) and capturing its public FQDN (something like
   `abc123-xyz.eastus2.alb.azure.com`). Before you run Phase 4, you
   must create CNAME records in your DNS provider pointing
   `ADAPTER_HOSTNAME` and `ADMIN_HOSTNAME` at that FQDN:

   ```
   mcp.example.com         CNAME   abc123-xyz.eastus2.alb.azure.com
   admin-mcp.example.com   CNAME   abc123-xyz.eastus2.alb.azure.com
   ```

   DNS propagation usually takes 5-30 minutes. After the CNAMEs have
   propagated, the AGC managed certificate will provision itself
   automatically (this can take an additional 15-30 minutes — AGC
   needs to validate domain ownership via the DNS record before
   issuing the cert).

   When you run `./azuresetup.sh --phase 4`, the wizard first checks
   that both hostnames resolve in DNS. If they don't, it fails fast
   with a clear message rather than running smoke tests that would
   all mysteriously return connection errors.

   If DNS resolves but the smoke tests fail with TLS errors, the
   managed cert has not yet been issued. Wait 15 minutes and try
   again:

   ```bash
   ./azuresetup.sh --phase 4
   ```

   Phase 4 is fully re-runnable — every step checks for "already
   done" before doing work. Running it twice is harmless.

3. Add a new subsection under "Troubleshooting" titled "Phase 3
   Common Issues":

   ### Phase 3 Common Issues

   **Pods stuck Pending with "SecretProviderClass not found" in events**

   The CSI driver pod hasn't come up yet. Wait 30s and check:

   ```
   kubectl -n kube-system get pods -l app=secrets-store-csi-driver
   ```

   **Pods in CrashLoopBackOff with "failed to get secret from keyvault"**

   Workload identity RBAC is misconfigured. Check:

   ```
   az role assignment list \
     --assignee $(get_state WORKLOAD_IDENTITY_PRINCIPAL_ID) \
     --scope $(az keyvault show -n $(get_state KV_NAME) --query id -o tsv)
   ```

   Should show `Key Vault Secrets User`. If not, Phase 2 did not
   complete cleanly — rerun Phase 2.

   **ApplicationLoadBalancer stuck in "Creating"**

   The ALB controller pod is probably in CrashLoopBackOff. Check:

   ```
   kubectl logs -n azure-alb-system deployment/alb-controller
   ```

   If you see "unable to find user assigned identity", the client
   ID was not passed correctly to the Helm install. Check state
   has `ALB_IDENTITY_CLIENT_ID` and re-run Phase 3.

   If you see "403 Forbidden" on the AGC subnet, the
   `AppGw for Containers Configuration Manager` role assignment
   from AZ14 Step 3.5 didn't propagate in time. Wait 2 minutes
   and re-run Phase 3.

   **Gateway never gets a programmed address**

   The ALB controller is running but the AppGw provisioning is
   still in progress. This is normal — it can take up to 10 min.
   The wizard polls for 5 min then gives up. Re-run Phase 3 if
   it bailed out; the poll will resume.

PART C — Verification

1. bash -n deploy/azure-aks/azuresetup.sh
2. shellcheck deploy/azure-aks/azuresetup.sh (skip if not installed)

3. README updates:
     grep -q "DNS gap between Phase 3 and Phase 4" deploy/azure-aks/README.md
     grep -q "Phase 3 Common Issues" deploy/azure-aks/README.md
     grep -q "ApplicationLoadBalancer stuck" deploy/azure-aks/README.md

4. Final structural check — verify all 4 phase functions now have
   real bodies and not stubs:
     grep -A1 "^run_phase_[1-4]()" deploy/azure-aks/azuresetup.sh
     # None of the bodies should contain "not yet implemented"

5. If AZURE_SMOKE_SUBSCRIPTION is set and Phase 3 has been run to
   completion (CNAMEs set, DNS propagated, cert issued), run Phase 4
   for real:
     ./deploy/azure-aks/azuresetup.sh --phase 4 --non-interactive

   Expected:
     - DNS check passes
     - Container Insights enabled (or confirmed existing)
     - 3-5 of 5 smoke tests pass (5/5 if the adapter exposes
       /health/cache, otherwise 4/5 with the non-fatal warning)
     - Key Vault public access set to Disabled
     - PHASE_4_COMPLETE=true in state
     - Final summary box printed
     - Adapter is reachable from outside Azure at the public URLs

Print a final summary listing:
  - Files modified
  - bash -n result
  - shellcheck result
  - All 4 phase stubs verified as implemented
  - README updates verified
  - Real-run result if applicable

Recommendation:
  git add deploy/azure-aks
  git commit -m "AZ14-AZ19: AKS wizard Phase 3 + Phase 4 complete"
```

### Expected Output

`run_phase_4()` is complete end to end. The wizard script has all four phase bodies fully implemented. README describes the DNS gap between phases, Phase 3 common issues, and the complete phase table. After this prompt, the AKS wizard is fully functional and can be demoed against a real Azure subscription.

---

## After Completion

When all 6 prompts have been run, both Azure wizards are complete end-to-end:

**AKS wizard** (`deploy/azure-aks/`) — production-grade
- 4 phases, fully implemented
- `./azuresetup.sh --phase 1` through `--phase 4` (or `--phase all`)
- Teardown via `./azuresetup.sh --destroy`
- Target cost ~$700/mo on-demand, ~$550/mo with 1-yr RIs

**ACA wizard** (`deploy/azure-aca/`) — demo-grade
- 2 phases, fully implemented (from the earlier Phase 2 pack)
- `./acasetup.sh` runs both phases end-to-end in ~30 min
- `./demo-stop.sh` drops cost to ~$25/mo; `./demo-start.sh` brings it back
- Teardown via `./acasetup.sh --destroy`

To verify the AKS wizard end-to-end against a real Azure subscription:

```bash
cd deploy/azure-aks
cp .env.example .env
vi .env  # fill in AZURE_SUBSCRIPTION_ID, OKTA_DOMAIN,
         # ADAPTER_HOSTNAME, ADMIN_HOSTNAME

# Phase 1-3 can run unattended
./azuresetup.sh --phase 1
./azuresetup.sh --phase 2
./azuresetup.sh --phase 3

# Phase 3 prints the AGC FQDN. Now:
# 1. Create CNAME records for ADAPTER_HOSTNAME and ADMIN_HOSTNAME
#    pointing at the AGC FQDN
# 2. Wait 15-30 minutes for DNS + cert provisioning
# 3. Run Phase 4:
./azuresetup.sh --phase 4

# Adapter is now reachable at https://<ADAPTER_HOSTNAME>
# Admin UI at https://<ADMIN_HOSTNAME>

# Teardown
./azuresetup.sh --destroy
```

## What's left

Nothing in the wizard itself. The core deliverable is complete.

Optional follow-up work if you want to push further:

1. **Run `package.sh` on both wizards** and distribute the tarballs to the SE team for evaluation. The `package.sh` files were created in AZ6 of the scaffolding pack but haven't been exercised end-to-end yet.

2. **Capture an SE walkthrough video** or write a "first deployment" guide that screen-records an actual end-to-end run. The README documents the DNS gap, but watching someone actually navigate it is more useful.

3. **Add `./status.sh` helpers** for both wizards that summarize the current state of a deployed environment (pods running, AGC health, Key Vault access, recent smoke test results). The aws-ec2 pattern has one; the Azure wizards don't yet.

4. **Terraform equivalent of the AKS wizard** — the original Azure deployment prompt pack sketched this as `A12` (two-phase Terraform matching deploy/gcp). Not needed for the dev/ops team to ship customer deployments, but nice to have for cross-cloud parity.

None of that is required. The wizards are done.
