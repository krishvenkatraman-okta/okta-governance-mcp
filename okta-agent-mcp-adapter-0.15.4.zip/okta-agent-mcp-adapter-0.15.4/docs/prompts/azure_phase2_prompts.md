> **Historical (pre-v0.15.x):** Password-based admin login references in this document are obsolete. The adapter accepts only Okta OAuth access tokens — see [docs/OPERATIONS.md § Admin API Authentication](../OPERATIONS.md#admin-api-authentication).

# Okta MCP Adapter — Azure Wizard Phase 2 Implementation Prompts

## AKS Phase 2 (Stateful Tier) + ACA Phase 2 (Application Deployment)

**6 Prompts • Sequential • Builds Phase 2 of both wizards on top of the Phase 1 scaffolding**

---

## Overview

This pack continues the work from `azure_scripted_deploy_prompts.md` (the scaffolding pack, AZ1–AZ6). After running those 6 prompts you have working Phase 1 implementations of both `deploy/azure-aks/azuresetup.sh` and `deploy/azure-aca/acasetup.sh`. This pack adds:

- **AKS Phase 2 (Stateful tier)** — Postgres GP D2ds_v5 with ZR HA, Redis Standard C1, Key Vault, all 6 secrets stored. Uses parallel kickoff so wall-clock is ~20 min instead of ~30 min sequential.
- **ACA Phase 2 (Application deployment)** — completes `bicep/main.bicep` with three Container App resources, builds the three images via `az acr build`, deploys the Bicep template, runs smoke tests, and writes `demo-stop.sh` / `demo-start.sh` helpers. After this phase the ACA wizard is **complete** (only AKS Phases 3 and 4 remain in a future pack).

The 6 prompts are sequenced so AKS work and ACA work do not interleave — AZ7–AZ9 are AKS, AZ10–AZ12 are ACA. You can run AZ7–AZ9 to completion against a real subscription, validate AKS Phase 2 is working, then run AZ10–AZ12 for ACA. Or run all six in sequence and validate at the end.

## Decisions baked into this pack

These were resolved before authoring:

1. **Image build mechanism** — `az acr build` for both wizards. No Docker required on the operator's machine.
2. **Custom hostnames on ACA** — skipped. The ACA wizard uses the `azurecontainerapps.io` managed FQDN. Customers wanting vanity hostnames should use the AKS wizard.
3. **AKS Key Vault public-then-disable window** — accepted. Phase 2 creates the vault with public access enabled so the operator's `az` CLI can write secrets. Phase 4 (in a future pack) will disable public access after AKS workload identity has its RBAC grant. The window is documented in the README.
4. **AKS Phase 2 must parallelize Postgres + Redis** — sequential is 30 min wall-clock, parallel is 20 min. The wizard kicks both off with `--no-wait` and uses dedicated waiters to poll until both finish. This is called out explicitly in AZ8 so Claude Code does not accidentally serialize.

## Prompt Map

| # | Prompt | Wizard | Creates / Modifies | Est. Time |
|---|---|---|---|---|
| AZ7 | Phase 2 prerequisites + Okta env loading | AKS | `azuresetup.sh` (Phase 2 prereq block) | 20 min |
| AZ8 | Postgres + Redis (parallel) + private endpoints | AKS | `azuresetup.sh` (Phase 2 stateful resources) | 50 min |
| AZ9 | Key Vault + secrets + workload identity RBAC | AKS | `azuresetup.sh` (Phase 2 secrets), README updates | 30 min |
| AZ10 | ACA Bicep resources + parameters | ACA | `bicep/main.bicep` (3 Container App resources), `acasetup.sh` (Phase 2 prereq + secret gen) | 40 min |
| AZ11 | ACA image build + deploy + health check | ACA | `acasetup.sh` (Phase 2 deploy block) | 30 min |
| AZ12 | ACA smoke tests + start/stop helpers + summary | ACA | `acasetup.sh` (Phase 2 finalization), `demo-stop.sh`, `demo-start.sh` | 25 min |

Total estimated implementation time: about 3 hours of Claude Code execution. Total wall-clock when running the wizards themselves on real Azure is roughly 25 min (AKS Phase 2) + 15 min (ACA Phase 2).

---

## Prerequisites

- AZ1–AZ6 from the scaffolding pack have been run and committed
- `deploy/azure-aks/azuresetup.sh --phase 1` has been verified to run cleanly (against a real or throwaway subscription)
- `deploy/azure-aca/acasetup.sh --phase 1` has been verified the same way
- The operator running these prompts knows their target Okta values:
  - `OKTA_DOMAIN`
  - `OKTA_ISSUER`
  - `OKTA_AUTHORIZATION_SERVER_ID`
  - `OKTA_RELAY_CLIENT_ID`
  - `OKTA_RELAY_CLIENT_SECRET`

## How to Execute

```bash
cd okta-agent-mcp-adapter
git checkout feat/azure-scripted-deploy   # the same branch as the scaffolding pack
# Paste each prompt body into Claude Code, one at a time.
# Commit after each green run:
git add -A && git commit -m "AZ<N>: <prompt title>"
```

---

## Prompt AZ7: AKS Phase 2 Prerequisites + Okta Env Loading

### Context

Phase 2 needs all five Okta values. Phase 1 did not. This prompt adds the prerequisite-check function that loads them from the environment (or `.env`), validates them, and saves them into `.azuresetup.state` so subsequent phase reruns don't have to re-prompt. It also adds a Phase 1 completion check — Phase 2 must refuse to run if Phase 1 hasn't completed.

This prompt does **not** create any Azure resources. It just installs the validation skeleton that AZ8 and AZ9 will build on. Verifying it in isolation confirms the wizard's prereq-check pattern works cleanly before the long-running provisioning steps.

### Prompt

*Copy the text below into Claude Code:*

```
Add the Phase 2 prerequisite check and Okta env loading to the AKS
wizard. Do NOT add any provisioning logic in this prompt — only the
validation block.

Pre-check:
1. Confirm deploy/azure-aks/azuresetup.sh exists from AZ4.
2. Confirm Phase 1 still runs cleanly: bash -n deploy/azure-aks/azuresetup.sh

Edits to deploy/azure-aks/azuresetup.sh:

A. Replace the existing run_phase_2() stub with a new function that
   begins with prerequisites validation but stops short of
   provisioning. The body of run_phase_2 for now should be:

run_phase_2() {
  print_banner "Phase 2: Stateful Tier"

  # Step 2.0: Verify Phase 1 completed
  info "Step 2.0: Verifying Phase 1 completion..."
  if [[ "$(get_state PHASE_1_COMPLETE)" != "true" ]]; then
    die "Phase 1 has not completed. Run: ./azuresetup.sh --phase 1"
  fi

  # Reload state from Phase 1
  AZURE_SUBSCRIPTION_ID="$(get_state AZURE_SUBSCRIPTION_ID)"
  AZURE_LOCATION="$(get_state AZURE_LOCATION)"
  AZURE_RG="$(get_state AZURE_RG)"
  TENANT_ID="$(get_state TENANT_ID)"
  AKS_NAME="$(get_state AKS_NAME)"
  PE_SUBNET_ID="$(get_state PE_SUBNET_ID)"
  WORKLOAD_IDENTITY_PRINCIPAL_ID="$(get_state WORKLOAD_IDENTITY_PRINCIPAL_ID)"

  for var in AZURE_SUBSCRIPTION_ID AZURE_LOCATION AZURE_RG TENANT_ID \
             AKS_NAME PE_SUBNET_ID WORKLOAD_IDENTITY_PRINCIPAL_ID; do
    if [[ -z "${!var}" ]]; then
      die "$var missing from state. Rerun Phase 1."
    fi
  done

  az account set --subscription "$AZURE_SUBSCRIPTION_ID"
  ok "Phase 1 state loaded"

  # Step 2.1: Load and validate Okta values
  info "Step 2.1: Loading Okta configuration..."

  # Allow loading from state if already saved on a previous Phase 2 run
  OKTA_DOMAIN="${OKTA_DOMAIN:-$(get_state OKTA_DOMAIN)}"
  OKTA_ISSUER="${OKTA_ISSUER:-$(get_state OKTA_ISSUER)}"
  OKTA_AUTHORIZATION_SERVER_ID="${OKTA_AUTHORIZATION_SERVER_ID:-$(get_state OKTA_AUTHORIZATION_SERVER_ID)}"
  OKTA_RELAY_CLIENT_ID="${OKTA_RELAY_CLIENT_ID:-$(get_state OKTA_RELAY_CLIENT_ID)}"
  OKTA_RELAY_CLIENT_SECRET="${OKTA_RELAY_CLIENT_SECRET:-$(get_state OKTA_RELAY_CLIENT_SECRET)}"

  # If still missing in non-interactive mode, fail loud
  if $NON_INTERACTIVE; then
    for var in OKTA_DOMAIN OKTA_ISSUER OKTA_AUTHORIZATION_SERVER_ID \
               OKTA_RELAY_CLIENT_ID OKTA_RELAY_CLIENT_SECRET; do
      if [[ -z "${!var}" ]]; then
        die "$var not set in env, .env, or state file (non-interactive mode)"
      fi
    done
  else
    [[ -z "$OKTA_DOMAIN" ]] && \
      prompt_required OKTA_DOMAIN "Okta domain (e.g. yourorg.okta.com)"
    [[ -z "$OKTA_ISSUER" ]] && \
      prompt_required OKTA_ISSUER "Okta issuer URL (e.g. https://yourorg.okta.com/oauth2/<id>)"
    [[ -z "$OKTA_AUTHORIZATION_SERVER_ID" ]] && \
      prompt_required OKTA_AUTHORIZATION_SERVER_ID "Okta authorization server ID"
    [[ -z "$OKTA_RELAY_CLIENT_ID" ]] && \
      prompt_required OKTA_RELAY_CLIENT_ID "Okta relay client ID"
    [[ -z "$OKTA_RELAY_CLIENT_SECRET" ]] && \
      prompt_required OKTA_RELAY_CLIENT_SECRET "Okta relay client secret"
  fi

  # Sanity-check the issuer URL
  if [[ ! "$OKTA_ISSUER" =~ ^https:// ]]; then
    die "OKTA_ISSUER must start with https://"
  fi
  if [[ ! "$OKTA_ISSUER" =~ /oauth2/ ]]; then
    warn "OKTA_ISSUER does not contain '/oauth2/' — this is unusual"
    if ! $NON_INTERACTIVE; then
      prompt_yesno "Continue anyway?" n || die "Aborted by operator"
    fi
  fi

  # Persist into state — these will be needed by Phase 3 too
  save_state OKTA_DOMAIN "$OKTA_DOMAIN"
  save_state OKTA_ISSUER "$OKTA_ISSUER"
  save_state OKTA_AUTHORIZATION_SERVER_ID "$OKTA_AUTHORIZATION_SERVER_ID"
  save_state OKTA_RELAY_CLIENT_ID "$OKTA_RELAY_CLIENT_ID"
  save_state OKTA_RELAY_CLIENT_SECRET "$OKTA_RELAY_CLIENT_SECRET"
  ok "Okta configuration loaded"

  # PLACEHOLDER for AZ8: Postgres + Redis provisioning
  # PLACEHOLDER for AZ9: Key Vault + secrets

  warn "AZ7 scaffolding only — Postgres/Redis/KV provisioning added in AZ8 and AZ9"
  exit 0
}

B. Verification

  1. bash -n deploy/azure-aks/azuresetup.sh
  2. ./deploy/azure-aks/azuresetup.sh --phase 2 --non-interactive
     against a fake env where Phase 1 state does NOT exist
     (rm -f .azuresetup.state || true).
     Expected: dies with "Phase 1 has not completed".
  3. Synthesize a fake Phase 1 state for testing:
       cat > deploy/azure-aks/.azuresetup.state <<'EOF'
       PHASE_1_COMPLETE=true
       AZURE_SUBSCRIPTION_ID=00000000-0000-0000-0000-000000000000
       AZURE_LOCATION=eastus2
       AZURE_RG=okta-mcp-prod
       TENANT_ID=00000000-0000-0000-0000-000000000000
       AKS_NAME=okta-mcp-aks
       PE_SUBNET_ID=/subscriptions/00000000-0000-0000-0000-000000000000/resourceGroups/okta-mcp-prod/providers/Microsoft.Network/virtualNetworks/okta-mcp-vnet/subnets/pe-subnet
       WORKLOAD_IDENTITY_PRINCIPAL_ID=00000000-0000-0000-0000-000000000000
       EOF
     Then run with all Okta env vars set:
       OKTA_DOMAIN=test.okta.com \
       OKTA_ISSUER=https://test.okta.com/oauth2/abc \
       OKTA_AUTHORIZATION_SERVER_ID=abc \
       OKTA_RELAY_CLIENT_ID=xyz \
       OKTA_RELAY_CLIENT_SECRET=secret \
       ./deploy/azure-aks/azuresetup.sh --phase 2 --non-interactive
     Expected: passes prereq checks, prints "AZ7 scaffolding only", exits 0.
     The fake state file should contain the new OKTA_* keys appended.
  4. Clean up the fake state file: rm -f deploy/azure-aks/.azuresetup.state
  5. shellcheck deploy/azure-aks/azuresetup.sh (skip if not installed)

Print a summary listing:
  - Lines added to azuresetup.sh
  - bash -n result
  - Phase 1 completion guard test result
  - Okta env loading test result
  - Whether OKTA_* values appeared in the test state file
  - shellcheck result (or "skipped")
```

### Expected Output

`run_phase_2()` now begins with a Phase 1 completion guard, loads all Phase 1 state values, and validates/persists the five Okta values. A `--phase 2` run with no Phase 1 state dies cleanly. A `--phase 2` run with fake Phase 1 state and Okta env vars set passes the prerequisites and exits at the placeholder. No real Azure resources are touched.

---

## Prompt AZ8: Postgres + Redis Parallel Provisioning + Private Endpoints

### Context

The longest-running prompt in the pack. Provisions Postgres Flexible Server (GP D2ds_v5 with zone-redundant HA) and Azure Cache for Redis (Standard C1) **in parallel**, then creates private endpoints for both into the `pe-subnet` from Phase 1.

The parallelization detail matters. Sequential `az postgres flexible-server create` (8-12 min) followed by `az redis create` (15-20 min) is roughly 30 min wall-clock. Kicking both off with `--no-wait` and then waiting on each saves about 10 minutes.

The Postgres CLI has a dedicated `az postgres flexible-server wait --created` subcommand that polls `provisioningState=Succeeded`. The Redis CLI does not have a comparable wait subcommand, so the wizard polls `az redis show` directly using a small helper.

### Prompt

*Copy the text below into Claude Code:*

```
Add Postgres + Redis parallel provisioning + private endpoint creation
to the AKS wizard's Phase 2.

Pre-check:
1. Confirm AZ7 has been completed and run_phase_2 has the prereq
   block but ends at the "AZ7 scaffolding only" placeholder.
2. Confirm shell-lib/azure-helpers.sh has wait_for_resource and
   urlencode_password from AZ2.

Edits to deploy/azure-aks/shell-lib/azure-helpers.sh:

A. Add a new helper function poll_redis_provisioned() because az redis
   does not have a dedicated wait subcommand. Place it near
   wait_for_resource.

  # poll_redis_provisioned RG REDIS_NAME [TIMEOUT_SEC]
  #   Polls az redis show every 30 seconds until provisioningState
  #   reaches "Succeeded". Default timeout 1800 seconds (30 min).
  poll_redis_provisioned() {
    local rg="$1" name="$2" timeout="${3:-1800}"
    local elapsed=0 interval=30
    local spin_chars='|/-\'
    local spin_idx=0 state=""

    while (( elapsed < timeout )); do
      state="$(az redis show -g "$rg" -n "$name" \
                --query provisioningState -o tsv 2>/dev/null || echo "Unknown")"
      if [[ "$state" == "Succeeded" ]]; then
        printf "\r${GREEN}[  OK]${NC}  Redis %s provisioned (%d:%02d elapsed)        \n" \
          "$name" $((elapsed/60)) $((elapsed%60))
        return 0
      fi
      if [[ "$state" == "Failed" ]]; then
        printf "\r"
        die "Redis $name provisioning FAILED. Inspect with: az redis show -g $rg -n $name"
      fi
      local c="${spin_chars:$spin_idx:1}"
      printf "\r${CYAN}[INFO]${NC}  Waiting for redis %s... %s %02d:%02d (state: %s)" \
        "$name" "$c" $((elapsed/60)) $((elapsed%60)) "$state"
      spin_idx=$(( (spin_idx + 1) % 4 ))
      sleep "$interval"
      elapsed=$((elapsed + interval))
    done
    printf "\r"
    die "Timeout after ${timeout}s waiting for redis $name (last state: $state)"
  }

  Both copies of azure-helpers.sh (azure-aks and azure-aca) must be
  updated identically. Verify with diff after editing.

B. Edits to deploy/azure-aks/azuresetup.sh

Replace the "PLACEHOLDER for AZ8" block in run_phase_2 with the body
below. Keep the "PLACEHOLDER for AZ9" line in place — AZ9 will
replace it.

  # Step 2.2: Resolve / generate names for Postgres and Redis
  info "Step 2.2: Resolving Postgres and Redis resource names..."

  PG_NAME="${PG_NAME:-$(get_state PG_NAME)}"
  if [[ -z "$PG_NAME" ]]; then
    PG_NAME="okta-mcp-pg-$(random_suffix 4)"
  fi
  save_state PG_NAME "$PG_NAME"

  REDIS_NAME="${REDIS_NAME:-$(get_state REDIS_NAME)}"
  if [[ -z "$REDIS_NAME" ]]; then
    REDIS_NAME="okta-mcp-redis-$(random_suffix 4)"
  fi
  save_state REDIS_NAME "$REDIS_NAME"

  ok "Postgres: $PG_NAME"
  ok "Redis:    $REDIS_NAME"

  # Step 2.3: Generate / load Postgres password
  info "Step 2.3: Resolving Postgres admin password..."
  PG_PASSWORD="$(get_state PG_PASSWORD)"
  if [[ -z "$PG_PASSWORD" ]]; then
    PG_PASSWORD="$(generate_password 24)"
    save_state PG_PASSWORD "$PG_PASSWORD"
    ok "Generated new Postgres admin password"
  else
    ok "Loaded existing Postgres password from state"
  fi

  # Step 2.4: Kick off Postgres + Redis in parallel (BOTH --no-wait)
  info "Step 2.4: Kicking off Postgres + Redis provisioning in parallel..."
  warn "         Sequential would be ~30 min wall-clock. Parallel = ~20 min."

  # Postgres — only kick off if it doesn't already exist
  if az postgres flexible-server show -g "$AZURE_RG" -n "$PG_NAME" &>/dev/null; then
    ok "Postgres $PG_NAME already exists — skipping create"
  else
    info "Starting Postgres GP D2ds_v5 + ZR HA provisioning (--no-wait)..."
    az postgres flexible-server create \
      --resource-group "$AZURE_RG" \
      --location "$AZURE_LOCATION" \
      --name "$PG_NAME" \
      --tier GeneralPurpose \
      --sku-name Standard_D2ds_v5 \
      --version 15 \
      --storage-size 64 \
      --high-availability ZoneRedundant \
      --zone 1 \
      --standby-zone 2 \
      --vnet okta-mcp-vnet \
      --subnet pe-subnet \
      --private-dns-zone privatelink.postgres.database.azure.com \
      --admin-user pgadmin \
      --admin-password "$PG_PASSWORD" \
      --backup-retention 14 \
      --yes \
      --no-wait \
      --output none
    ok "Postgres provisioning kicked off"
  fi

  # Redis — only kick off if it doesn't already exist
  if az redis show -g "$AZURE_RG" -n "$REDIS_NAME" &>/dev/null; then
    ok "Redis $REDIS_NAME already exists — skipping create"
  else
    info "Starting Redis Standard C1 provisioning (--no-wait)..."
    az redis create \
      --resource-group "$AZURE_RG" \
      --location "$AZURE_LOCATION" \
      --name "$REDIS_NAME" \
      --sku Standard --vm-size c1 \
      --enable-non-ssl-port false \
      --minimum-tls-version 1.2 \
      --redis-version 6 \
      --no-wait \
      --output none
    ok "Redis provisioning kicked off"
  fi

  # Step 2.5: Wait for both to finish
  # Postgres wait first because it's typically faster (8-12 min) and
  # we want to fail fast if it errors. Redis polling continues after.
  info "Step 2.5: Waiting for Postgres to reach provisioningState=Succeeded..."
  az postgres flexible-server wait \
    --resource-group "$AZURE_RG" \
    --name "$PG_NAME" \
    --created \
    --interval 30 \
    --timeout 1500
  ok "Postgres $PG_NAME ready"

  info "Step 2.5b: Waiting for Redis to reach provisioningState=Succeeded..."
  poll_redis_provisioned "$AZURE_RG" "$REDIS_NAME" 1800

  # Step 2.6: Create the gateway database in Postgres
  info "Step 2.6: Creating gateway_db database..."
  if az postgres flexible-server db show -g "$AZURE_RG" -s "$PG_NAME" \
       -d gateway_db &>/dev/null; then
    ok "Database gateway_db already exists"
  else
    az postgres flexible-server db create -g "$AZURE_RG" \
      -s "$PG_NAME" -d gateway_db --output none
    ok "Database gateway_db created"
  fi

  PG_FQDN="${PG_NAME}.postgres.database.azure.com"
  save_state PG_FQDN "$PG_FQDN"

  # Step 2.7: Disable Redis public network access and create private endpoint
  info "Step 2.7: Disabling Redis public network access..."
  az redis update -g "$AZURE_RG" -n "$REDIS_NAME" \
    --set publicNetworkAccess=Disabled --output none
  ok "Redis public access disabled"

  info "Step 2.8: Creating Redis private endpoint..."
  REDIS_PE_NAME="${REDIS_NAME}-pe"
  if az network private-endpoint show -g "$AZURE_RG" -n "$REDIS_PE_NAME" &>/dev/null; then
    ok "Private endpoint $REDIS_PE_NAME already exists"
  else
    REDIS_RESOURCE_ID="$(az redis show -g "$AZURE_RG" -n "$REDIS_NAME" \
      --query id -o tsv)"
    az network private-endpoint create \
      -g "$AZURE_RG" -l "$AZURE_LOCATION" \
      --name "$REDIS_PE_NAME" \
      --vnet-name okta-mcp-vnet --subnet pe-subnet \
      --private-connection-resource-id "$REDIS_RESOURCE_ID" \
      --group-id redisCache \
      --connection-name "${REDIS_NAME}-pe-conn" \
      --output none
    ok "Private endpoint created"
  fi

  info "Step 2.8b: Linking Redis private endpoint to private DNS zone..."
  if az network private-endpoint dns-zone-group show \
       -g "$AZURE_RG" --endpoint-name "$REDIS_PE_NAME" \
       -n redis-zg &>/dev/null; then
    ok "DNS zone group already exists"
  else
    az network private-endpoint dns-zone-group create \
      -g "$AZURE_RG" --endpoint-name "$REDIS_PE_NAME" \
      -n redis-zg \
      --private-dns-zone privatelink.redis.cache.windows.net \
      --zone-name redis \
      --output none
    ok "DNS zone group created"
  fi

  REDIS_FQDN="${REDIS_NAME}.redis.cache.windows.net"
  save_state REDIS_FQDN "$REDIS_FQDN"

  # Step 2.9: Build connection strings for later phases
  info "Step 2.9: Building connection strings..."
  PG_PASSWORD_ENC="$(urlencode_password "$PG_PASSWORD")"
  DATABASE_URL="postgresql://pgadmin:${PG_PASSWORD_ENC}@${PG_FQDN}:5432/gateway_db?sslmode=require"

  REDIS_KEY="$(az redis list-keys -g "$AZURE_RG" -n "$REDIS_NAME" \
    --query primaryKey -o tsv)"
  REDIS_URL="rediss://:${REDIS_KEY}@${REDIS_FQDN}:6380/0"

  # Save into state so AZ9 can pull them when writing to Key Vault
  save_state DATABASE_URL "$DATABASE_URL"
  save_state REDIS_URL "$REDIS_URL"
  ok "Connection strings staged for Key Vault"

  # PLACEHOLDER for AZ9: Key Vault + secrets

  warn "AZ8 only — Key Vault + secrets added in AZ9"
  exit 0

C. Verification

1. diff deploy/azure-aks/shell-lib/azure-helpers.sh \
        deploy/azure-aca/shell-lib/azure-helpers.sh
   Should produce no output (poll_redis_provisioned added to BOTH).

2. bash -n deploy/azure-aks/azuresetup.sh
3. bash -n deploy/azure-aks/shell-lib/azure-helpers.sh
4. shellcheck on both (skip if not installed)

5. If AZURE_SMOKE_SUBSCRIPTION is set in env AND a Phase 1 state file
   from a real Phase 1 run exists, optionally do a real run to verify:
       ./deploy/azure-aks/azuresetup.sh --phase 2 --non-interactive
   Otherwise skip and document. The real run takes ~25 min — note
   that the operator can interrupt with Ctrl+C and the state will
   persist for resume.

Print a summary listing:
  - Lines added to azuresetup.sh and azure-helpers.sh
  - diff result for the two helper copies
  - bash -n results
  - shellcheck results
  - Real-run result (or "skipped — set AZURE_SMOKE_SUBSCRIPTION")
```

### Expected Output

`run_phase_2()` now provisions Postgres and Redis in parallel, waits for both, creates the gateway database, locks down Redis public access, creates the Redis private endpoint with DNS zone group binding, and builds the DATABASE_URL and REDIS_URL connection strings. State persists for AZ9 to consume. The `poll_redis_provisioned` helper is added to both copies of `azure-helpers.sh` and they remain byte-identical.

---

## Prompt AZ9: Key Vault + Secrets + Workload Identity RBAC

### Context

Final piece of AKS Phase 2. Creates the Key Vault with **public access enabled** so the operator's `az` CLI can write the six secrets, creates a private endpoint for it (so future workload identity reads go over the VNet), generates the AES-256 encryption key and admin password, writes all six secrets, and grants the workload identity from Phase 1 the `Key Vault Secrets User` RBAC role at the vault scope.

The "create with public access enabled, lock down later" trade-off is deliberate. Phase 4 (in a future pack) will disable public network access after the AKS pods are running and the workload identity has confirmed RBAC works. The window is documented in the README.

### Prompt

*Copy the text below into Claude Code:*

```
Add Key Vault provisioning, secrets writing, and workload identity
RBAC to the AKS wizard's Phase 2.

Pre-check:
1. AZ8 has been completed: run_phase_2 ends with the
   "PLACEHOLDER for AZ9" line after staging DATABASE_URL and REDIS_URL.

Edits to deploy/azure-aks/azuresetup.sh:

Replace the "PLACEHOLDER for AZ9" block in run_phase_2 with the
following. After this block, run_phase_2 marks PHASE_2_COMPLETE and
prints the summary box.

  # Step 2.10: Resolve / generate Key Vault name
  info "Step 2.10: Resolving Key Vault name..."
  KV_NAME="${KV_NAME:-$(get_state KV_NAME)}"
  if [[ -z "$KV_NAME" ]]; then
    KV_NAME="okta-mcp-kv-$(random_suffix 4)"
  fi
  save_state KV_NAME "$KV_NAME"
  ok "Key Vault: $KV_NAME"

  # Step 2.11: Create Key Vault with RBAC mode and purge protection
  # NOTE: Public network access is left ENABLED here so this script
  # can write the secrets from the operator's machine. Phase 4 will
  # disable it once the AKS workload identity has been verified to
  # have its Key Vault Secrets User role.
  info "Step 2.11: Creating Key Vault (RBAC mode, purge protection)..."
  if az keyvault show -n "$KV_NAME" &>/dev/null; then
    ok "Key Vault $KV_NAME already exists"
  else
    az keyvault create -g "$AZURE_RG" -n "$KV_NAME" \
      -l "$AZURE_LOCATION" \
      --enable-rbac-authorization true \
      --enable-purge-protection true \
      --retention-days 90 \
      --output none
    ok "Key Vault created"
  fi
  KV_URI="$(az keyvault show -n "$KV_NAME" --query properties.vaultUri -o tsv)"
  save_state KV_URI "$KV_URI"

  # Step 2.12: Grant the operator running this script the
  # "Key Vault Secrets Officer" role so we can write secrets
  info "Step 2.12: Granting current user Key Vault Secrets Officer RBAC..."
  CURRENT_USER_ID="$(az ad signed-in-user show --query id -o tsv 2>/dev/null || true)"
  if [[ -z "$CURRENT_USER_ID" ]]; then
    # Fall back to service principal context if signed-in-user fails
    CURRENT_USER_ID="$(az account show --query user.name -o tsv)"
    warn "Using service principal identity for RBAC: $CURRENT_USER_ID"
  fi
  KV_SCOPE="$(az keyvault show -n "$KV_NAME" --query id -o tsv)"

  # Idempotent role assignment — check if already granted
  if az role assignment list --assignee "$CURRENT_USER_ID" \
       --scope "$KV_SCOPE" \
       --query "[?roleDefinitionName=='Key Vault Secrets Officer']" \
       -o tsv | grep -q .; then
    ok "Operator already has Key Vault Secrets Officer"
  else
    az role assignment create \
      --role "Key Vault Secrets Officer" \
      --assignee "$CURRENT_USER_ID" \
      --scope "$KV_SCOPE" \
      --output none
    ok "Role assignment created — waiting 30s for propagation"
    sleep 30
  fi

  # Step 2.13: Create private endpoint for Key Vault
  info "Step 2.13: Creating Key Vault private endpoint..."
  KV_PE_NAME="${KV_NAME}-pe"
  if az network private-endpoint show -g "$AZURE_RG" -n "$KV_PE_NAME" &>/dev/null; then
    ok "Private endpoint $KV_PE_NAME already exists"
  else
    az network private-endpoint create \
      -g "$AZURE_RG" -l "$AZURE_LOCATION" \
      --name "$KV_PE_NAME" \
      --vnet-name okta-mcp-vnet --subnet pe-subnet \
      --private-connection-resource-id "$KV_SCOPE" \
      --group-id vault \
      --connection-name "${KV_NAME}-pe-conn" \
      --output none
    ok "Private endpoint created"
  fi

  if az network private-endpoint dns-zone-group show \
       -g "$AZURE_RG" --endpoint-name "$KV_PE_NAME" \
       -n kv-zg &>/dev/null; then
    ok "DNS zone group already exists"
  else
    az network private-endpoint dns-zone-group create \
      -g "$AZURE_RG" --endpoint-name "$KV_PE_NAME" \
      -n kv-zg \
      --private-dns-zone privatelink.vaultcore.azure.net \
      --zone-name vault \
      --output none
    ok "DNS zone group created"
  fi

  # Step 2.14: Generate the AES-256 encryption key and admin password
  info "Step 2.14: Generating encryption key and admin password..."
  ENCRYPTION_KEY="${ENCRYPTION_KEY:-$(get_state ENCRYPTION_KEY)}"
  if [[ -z "$ENCRYPTION_KEY" ]]; then
    ENCRYPTION_KEY="$(generate_encryption_key)"
    save_state ENCRYPTION_KEY "$ENCRYPTION_KEY"
    ok "Generated new ENCRYPTION_KEY"
  else
    ok "Loaded existing ENCRYPTION_KEY from state"
  fi

  ADMIN_PASSWORD="${ADMIN_PASSWORD:-$(get_state ADMIN_PASSWORD)}"
  if [[ -z "$ADMIN_PASSWORD" ]]; then
    # 16-char alphanumeric — easier to type during demos
    ADMIN_PASSWORD="$(generate_password 16 | tr -d '!@#%^*' | head -c 16)"
    if (( ${#ADMIN_PASSWORD} < 16 )); then
      # Fallback if symbol-stripping shortened it too much
      ADMIN_PASSWORD="$(LC_ALL=C tr -dc 'A-Za-z0-9' </dev/urandom | head -c 16)"
    fi
    save_state ADMIN_PASSWORD "$ADMIN_PASSWORD"
    ok "Generated new ADMIN_PASSWORD"
  else
    ok "Loaded existing ADMIN_PASSWORD from state"
  fi

  # Step 2.15: Write all 6 secrets to Key Vault
  info "Step 2.15: Writing secrets to Key Vault..."

  # Reload connection strings from state (saved by AZ8)
  DATABASE_URL="$(get_state DATABASE_URL)"
  REDIS_URL="$(get_state REDIS_URL)"
  [[ -z "$DATABASE_URL" ]] && die "DATABASE_URL missing from state"
  [[ -z "$REDIS_URL" ]] && die "REDIS_URL missing from state"

  set_kv_secret() {
    local name="$1" value="$2"
    az keyvault secret set --vault-name "$KV_NAME" --name "$name" \
      --value "$value" --output none
    ok "Secret written: $name"
  }

  set_kv_secret encryption-key "$ENCRYPTION_KEY"
  set_kv_secret admin-password "$ADMIN_PASSWORD"
  set_kv_secret database-url "$DATABASE_URL"
  set_kv_secret redis-url "$REDIS_URL"
  set_kv_secret okta-relay-client-id "$OKTA_RELAY_CLIENT_ID"
  set_kv_secret okta-relay-client-secret "$OKTA_RELAY_CLIENT_SECRET"

  # Step 2.16: Grant the workload identity Key Vault Secrets User RBAC
  info "Step 2.16: Granting workload identity Key Vault Secrets User..."
  if az role assignment list \
       --assignee "$WORKLOAD_IDENTITY_PRINCIPAL_ID" \
       --scope "$KV_SCOPE" \
       --query "[?roleDefinitionName=='Key Vault Secrets User']" \
       -o tsv | grep -q .; then
    ok "Workload identity already has Key Vault Secrets User"
  else
    az role assignment create \
      --role "Key Vault Secrets User" \
      --assignee-object-id "$WORKLOAD_IDENTITY_PRINCIPAL_ID" \
      --assignee-principal-type ServicePrincipal \
      --scope "$KV_SCOPE" \
      --output none
    ok "Role assignment created"
  fi

  # Mark phase 2 complete
  save_state PHASE_2_COMPLETE "true"

  print_summary_box "Phase 2 Complete: Stateful Tier Ready" \
    "Postgres:    $PG_FQDN" \
    "             Standard_D2ds_v5 + ZR HA" \
    "Redis:       $REDIS_FQDN" \
    "             Standard C1 (private endpoint)" \
    "Key Vault:   $KV_NAME" \
    "             Public access ENABLED until Phase 4" \
    "Secrets:     6 written (encryption-key, admin-password," \
    "             database-url, redis-url, 2x okta-relay)" \
    "Workload ID: granted Key Vault Secrets User" \
    "" \
    "Next: ./azuresetup.sh --phase 3"
}

Edits to deploy/azure-aks/README.md:

Add a new subsection under Troubleshooting titled "Key Vault Public
Access Window" with this content:

  ### Key Vault Public Access Window

  Phase 2 creates the Key Vault with public network access ENABLED so
  the operator's local `az` CLI can write the six runtime secrets
  (ENCRYPTION_KEY, ADMIN_PASSWORD, DATABASE_URL, REDIS_URL, and the
  two Okta relay credentials).

  Phase 4 disables public network access once the AKS pods have
  successfully read the secrets via the Secrets Store CSI driver and
  workload identity. Between Phase 2 and Phase 4 there is roughly a
  15-minute window where the vault is reachable from the public
  internet.

  This window is intentional — locking down the vault before workload
  identity RBAC is verified would risk a deployment where pods cannot
  read their secrets and the only way to recover is to re-enable
  public access manually.

  If your security policy forbids public Key Vault access at any
  point, run AZ7-AZ9 from a jumpbox VM inside the VNet and skip the
  initial public-access window by passing `--public-network-access
  Disabled` directly to `az keyvault create`. This requires a
  jumpbox with `az` CLI installed and is out of scope for the wizard.

Verification:

1. bash -n deploy/azure-aks/azuresetup.sh
2. shellcheck deploy/azure-aks/azuresetup.sh (skip if not installed)
3. With the fake Phase 1 state from AZ7 still present and DATABASE_URL,
   REDIS_URL pre-populated, do a smoke run:
     # Pre-populate fake state for AZ8/AZ9 outputs
     cat >> deploy/azure-aks/.azuresetup.state <<'EOF'
     PG_NAME=okta-mcp-pg-fake
     PG_FQDN=okta-mcp-pg-fake.postgres.database.azure.com
     REDIS_NAME=okta-mcp-redis-fake
     REDIS_FQDN=okta-mcp-redis-fake.redis.cache.windows.net
     DATABASE_URL=postgresql://test:test@test:5432/gateway_db
     REDIS_URL=rediss://:fakekey@test:6380/0
     EOF
   This won't actually run successfully because az commands will fail
   on the fake names — the goal is just to confirm the script PARSES
   correctly and dispatches to AZ9's code path. Skip the actual run
   unless AZURE_SMOKE_SUBSCRIPTION is set.
4. Clean up: rm -f deploy/azure-aks/.azuresetup.state

5. If AZURE_SMOKE_SUBSCRIPTION is set and the operator wants to do a
   real end-to-end Phase 2 test (this takes ~25 minutes wall-clock
   and provisions real billable Azure resources), run:
     ./deploy/azure-aks/azuresetup.sh --phase 2 --non-interactive
   At the end, verify:
     - All 6 secrets exist in Key Vault:
         az keyvault secret list --vault-name $KV_NAME --query [].name -o tsv
     - PHASE_2_COMPLETE=true is in the state file
     - The summary box was printed
   Then tear down with: ./deploy/azure-aks/azuresetup.sh --destroy

Print a final summary listing:
  - Lines added to azuresetup.sh
  - bash -n result
  - shellcheck result
  - README updated (yes/no)
  - Real-run result (or "skipped")
  - Total Phase 2 wall-clock time if real run was executed
```

### Expected Output

`run_phase_2()` is now complete end-to-end. After this prompt, an operator can run `./azuresetup.sh --phase 2` against a Phase 1-completed environment and walk away for ~25 minutes; on return, Postgres and Redis are provisioned with private endpoints, the Key Vault holds all six secrets, and `PHASE_2_COMPLETE=true` is in the state file. The README's troubleshooting section explains the public-access window.

---

## Prompt AZ10: ACA Bicep Resources + Phase 2 Prerequisites + Secret Generation

### Context

Switches from AKS to ACA. Fills in the three Container App resources in `deploy/azure-aca/bicep/main.bicep` (which only had parameter declarations after AZ5) and adds the Phase 2 prerequisite block to `acasetup.sh`. The Bicep file becomes the single source of truth for what gets deployed; `acasetup.sh` Phase 2 just generates secrets, builds a parameters file, and invokes `az deployment group create`.

The three Container Apps differ in scaling policy: the adapter is pinned to `min=1 max=4` (it can't scale to zero because the adapter must always be ready to receive a request), while admin-ui and hr-mcp-server scale to zero (admin-ui is browser-driven so cold starts are tolerable; hr-mcp-server is only invoked through the adapter and rarely matters in a demo).

### Prompt

*Copy the text below into Claude Code:*

```
Author the three Container App resources in the ACA Bicep template
and add the Phase 2 prerequisite + secret generation block to the
ACA wizard.

Pre-check:
1. deploy/azure-aca/bicep/main.bicep exists from AZ5 with parameter
   declarations only (no resources yet).
2. deploy/azure-aca/acasetup.sh exists from AZ5 with run_phase_2 as
   a stub.

PART A — Edits to deploy/azure-aca/bicep/main.bicep

After the parameter declarations, add a reference to the existing
Container Apps environment and the three Container App resources.

  // Reference the existing Container Apps managed environment
  // (created by acasetup.sh Phase 1)
  resource acaEnv 'Microsoft.App/managedEnvironments@2024-03-01' existing = {
    name: acaEnvName
  }

  // -----------------------------------------------------------------
  // Container App: okta-mcp-adapter
  // - Min 1 / max 4 (cannot scale to zero — must always be ready)
  // - HTTP scaling rule on 80 concurrent requests
  // - External ingress on port 8000
  // - All 6 runtime secrets are wired in
  // -----------------------------------------------------------------
  resource adapter 'Microsoft.App/containerApps@2024-03-01' = {
    name: 'okta-mcp-adapter'
    location: resourceGroup().location
    properties: {
      managedEnvironmentId: acaEnv.id
      configuration: {
        ingress: {
          external: true
          targetPort: 8000
          transport: 'auto'
          allowInsecure: false
        }
        registries: [
          {
            server: acrLoginServer
            username: acrUsername
            passwordSecretRef: 'acr-password'
          }
        ]
        secrets: [
          { name: 'acr-password', value: acrPassword }
          { name: 'encryption-key', value: encryptionKey }
          { name: 'admin-password', value: adminPassword }
          { name: 'database-url', value: databaseUrl }
          { name: 'redis-url', value: redisUrl }
          { name: 'okta-relay-client-id', value: oktaRelayClientId }
          { name: 'okta-relay-client-secret', value: oktaRelayClientSecret }
        ]
      }
      template: {
        containers: [
          {
            name: 'adapter'
            image: '${acrLoginServer}/adapter:latest'
            resources: {
              cpu: json('1.0')
              memory: '2.0Gi'
            }
            env: [
              { name: 'OKTA_DOMAIN', value: oktaDomain }
              { name: 'OKTA_ISSUER', value: oktaIssuer }
              { name: 'OKTA_AUTHORIZATION_SERVER_ID', value: oktaAuthorizationServerId }
              { name: 'CACHE_PROVIDER', value: 'redis' }
              { name: 'REDIS_TLS_ENABLED', value: 'true' }
              { name: 'REDIS_KEY_PREFIX', value: 'okta-mcp:' }
              { name: 'LOG_LEVEL', value: 'INFO' }
              { name: 'GATEWAY_PORT', value: '8000' }
              { name: 'ENCRYPTION_KEY', secretRef: 'encryption-key' }
              { name: 'ADMIN_PASSWORD', secretRef: 'admin-password' }
              { name: 'DATABASE_URL', secretRef: 'database-url' }
              { name: 'REDIS_URL', secretRef: 'redis-url' }
              { name: 'OKTA_RELAY_CLIENT_ID', secretRef: 'okta-relay-client-id' }
              { name: 'OKTA_RELAY_CLIENT_SECRET', secretRef: 'okta-relay-client-secret' }
            ]
            probes: [
              {
                type: 'Liveness'
                httpGet: {
                  path: '/health'
                  port: 8000
                }
                initialDelaySeconds: 30
                periodSeconds: 15
                failureThreshold: 5
              }
              {
                type: 'Readiness'
                httpGet: {
                  path: '/health'
                  port: 8000
                }
                initialDelaySeconds: 10
                periodSeconds: 5
              }
            ]
          }
        ]
        scale: {
          minReplicas: 1
          maxReplicas: 4
          rules: [
            {
              name: 'http-scale'
              http: {
                metadata: {
                  concurrentRequests: '80'
                }
              }
            }
          ]
        }
      }
    }
  }

  // -----------------------------------------------------------------
  // Container App: admin-ui
  // - Scales to zero between uses
  // - External ingress on port 3001
  // -----------------------------------------------------------------
  resource adminUi 'Microsoft.App/containerApps@2024-03-01' = {
    name: 'admin-ui'
    location: resourceGroup().location
    properties: {
      managedEnvironmentId: acaEnv.id
      configuration: {
        ingress: {
          external: true
          targetPort: 3001
          transport: 'auto'
          allowInsecure: false
        }
        registries: [
          {
            server: acrLoginServer
            username: acrUsername
            passwordSecretRef: 'acr-password'
          }
        ]
        secrets: [
          { name: 'acr-password', value: acrPassword }
        ]
      }
      template: {
        containers: [
          {
            name: 'admin-ui'
            image: '${acrLoginServer}/admin-ui:latest'
            resources: {
              cpu: json('0.5')
              memory: '1.0Gi'
            }
            env: [
              { name: 'ADAPTER_URL', value: 'https://${adapter.properties.configuration.ingress.fqdn}' }
            ]
          }
        ]
        scale: {
          minReplicas: 0
          maxReplicas: 2
        }
      }
    }
  }

  // -----------------------------------------------------------------
  // Container App: hr-mcp-server
  // - Internal only (no external ingress)
  // - Scales to zero
  // - Reached by the adapter via Container Apps internal DNS
  // -----------------------------------------------------------------
  resource hrBackend 'Microsoft.App/containerApps@2024-03-01' = {
    name: 'hr-mcp-server'
    location: resourceGroup().location
    properties: {
      managedEnvironmentId: acaEnv.id
      configuration: {
        ingress: {
          external: false
          targetPort: 8001
          transport: 'auto'
          allowInsecure: false
        }
        registries: [
          {
            server: acrLoginServer
            username: acrUsername
            passwordSecretRef: 'acr-password'
          }
        ]
        secrets: [
          { name: 'acr-password', value: acrPassword }
        ]
      }
      template: {
        containers: [
          {
            name: 'hr-backend'
            image: '${acrLoginServer}/hr-backend:latest'
            resources: {
              cpu: json('0.25')
              memory: '0.5Gi'
            }
          }
        ]
        scale: {
          minReplicas: 0
          maxReplicas: 1
        }
      }
    }
  }

  // -----------------------------------------------------------------
  // Outputs — consumed by acasetup.sh Phase 2 to print the summary
  // -----------------------------------------------------------------
  output adapterFqdn string = adapter.properties.configuration.ingress.fqdn
  output adminUiFqdn string = adminUi.properties.configuration.ingress.fqdn
  output hrBackendFqdn string = hrBackend.properties.configuration.ingress.fqdn

Remove the placeholder comment block at the bottom of main.bicep
("RESOURCES (to be added in Phase 2)") since the resources are
now present.

PART B — Edits to deploy/azure-aca/acasetup.sh

Replace the existing run_phase_2() stub with the following body. Note
the body STOPS short of building images — that work is in AZ11.

run_phase_2() {
  print_banner "Phase 2: Application Deployment"

  # Step 2.0: Verify Phase 1 completed
  info "Step 2.0: Verifying Phase 1 completion..."
  if [[ "$(get_state PHASE_1_COMPLETE)" != "true" ]]; then
    die "Phase 1 has not completed. Run: ./acasetup.sh --phase 1"
  fi

  # Reload Phase 1 state
  AZURE_SUBSCRIPTION_ID="$(get_state AZURE_SUBSCRIPTION_ID)"
  AZURE_LOCATION="$(get_state AZURE_LOCATION)"
  AZURE_RG="$(get_state AZURE_RG)"
  AZURE_ACR_NAME="$(get_state AZURE_ACR_NAME)"
  ACR_LOGIN_SERVER="$(get_state ACR_LOGIN_SERVER)"
  PG_FQDN="$(get_state PG_FQDN)"
  PG_NAME="$(get_state PG_NAME)"
  PG_PASSWORD="$(get_state PG_PASSWORD)"
  REDIS_NAME="$(get_state REDIS_NAME)"
  REDIS_URL="$(get_state REDIS_URL)"
  ACA_ENV="$(get_state ACA_ENV)"
  DATABASE_URL="$(get_state DATABASE_URL)"

  for var in AZURE_SUBSCRIPTION_ID AZURE_LOCATION AZURE_RG AZURE_ACR_NAME \
             ACR_LOGIN_SERVER PG_FQDN PG_PASSWORD REDIS_URL ACA_ENV \
             DATABASE_URL; do
    [[ -z "${!var}" ]] && die "$var missing from state. Rerun Phase 1."
  done

  az account set --subscription "$AZURE_SUBSCRIPTION_ID"
  ok "Phase 1 state loaded"

  # Step 2.1: Load and validate Okta values (same pattern as AKS AZ7)
  info "Step 2.1: Loading Okta configuration..."
  OKTA_DOMAIN="${OKTA_DOMAIN:-$(get_state OKTA_DOMAIN)}"
  OKTA_ISSUER="${OKTA_ISSUER:-$(get_state OKTA_ISSUER)}"
  OKTA_AUTHORIZATION_SERVER_ID="${OKTA_AUTHORIZATION_SERVER_ID:-$(get_state OKTA_AUTHORIZATION_SERVER_ID)}"
  OKTA_RELAY_CLIENT_ID="${OKTA_RELAY_CLIENT_ID:-$(get_state OKTA_RELAY_CLIENT_ID)}"
  OKTA_RELAY_CLIENT_SECRET="${OKTA_RELAY_CLIENT_SECRET:-$(get_state OKTA_RELAY_CLIENT_SECRET)}"

  if $NON_INTERACTIVE; then
    for var in OKTA_DOMAIN OKTA_ISSUER OKTA_AUTHORIZATION_SERVER_ID \
               OKTA_RELAY_CLIENT_ID OKTA_RELAY_CLIENT_SECRET; do
      [[ -z "${!var}" ]] && die "$var not set in env, .env, or state file"
    done
  else
    [[ -z "$OKTA_DOMAIN" ]] && \
      prompt_required OKTA_DOMAIN "Okta domain"
    [[ -z "$OKTA_ISSUER" ]] && \
      prompt_required OKTA_ISSUER "Okta issuer URL"
    [[ -z "$OKTA_AUTHORIZATION_SERVER_ID" ]] && \
      prompt_required OKTA_AUTHORIZATION_SERVER_ID "Okta authorization server ID"
    [[ -z "$OKTA_RELAY_CLIENT_ID" ]] && \
      prompt_required OKTA_RELAY_CLIENT_ID "Okta relay client ID"
    [[ -z "$OKTA_RELAY_CLIENT_SECRET" ]] && \
      prompt_required OKTA_RELAY_CLIENT_SECRET "Okta relay client secret"
  fi

  save_state OKTA_DOMAIN "$OKTA_DOMAIN"
  save_state OKTA_ISSUER "$OKTA_ISSUER"
  save_state OKTA_AUTHORIZATION_SERVER_ID "$OKTA_AUTHORIZATION_SERVER_ID"
  save_state OKTA_RELAY_CLIENT_ID "$OKTA_RELAY_CLIENT_ID"
  save_state OKTA_RELAY_CLIENT_SECRET "$OKTA_RELAY_CLIENT_SECRET"
  ok "Okta configuration loaded"

  # Step 2.2: Generate or load the encryption key and admin password
  info "Step 2.2: Generating encryption key and admin password..."
  ENCRYPTION_KEY="${ENCRYPTION_KEY:-$(get_state ENCRYPTION_KEY)}"
  if [[ -z "$ENCRYPTION_KEY" ]]; then
    ENCRYPTION_KEY="$(generate_encryption_key)"
    save_state ENCRYPTION_KEY "$ENCRYPTION_KEY"
    ok "Generated new ENCRYPTION_KEY"
  else
    ok "Loaded ENCRYPTION_KEY from state"
  fi

  ADMIN_PASSWORD="${ADMIN_PASSWORD:-$(get_state ADMIN_PASSWORD)}"
  if [[ -z "$ADMIN_PASSWORD" ]]; then
    ADMIN_PASSWORD="$(LC_ALL=C tr -dc 'A-Za-z0-9' </dev/urandom | head -c 16)"
    save_state ADMIN_PASSWORD "$ADMIN_PASSWORD"
    ok "Generated new ADMIN_PASSWORD"
  else
    ok "Loaded ADMIN_PASSWORD from state"
  fi

  # Step 2.3: Get the ACR admin credentials (Container Apps will use
  # these to pull images — Phase 1 enabled admin on the ACR Basic SKU)
  info "Step 2.3: Fetching ACR admin credentials..."
  ACR_USERNAME="$(az acr credential show -n "$AZURE_ACR_NAME" \
    --query username -o tsv)"
  ACR_PASSWORD="$(az acr credential show -n "$AZURE_ACR_NAME" \
    --query 'passwords[0].value' -o tsv)"
  ok "ACR credentials retrieved"

  # PLACEHOLDER for AZ11: Image build + Bicep deploy
  # PLACEHOLDER for AZ12: Smoke tests + helper scripts

  warn "AZ10 only — image build and deploy added in AZ11"
  exit 0
}

PART C — Verification

1. az bicep build --file deploy/azure-aca/bicep/main.bicep
   Should compile cleanly. If az bicep is not installed locally,
   skip and document.

2. bash -n deploy/azure-aca/acasetup.sh
3. shellcheck deploy/azure-aca/acasetup.sh (skip if not installed)

4. Synthesize a fake Phase 1 state for testing the prereq block:
     cat > deploy/azure-aca/.acasetup.state <<'EOF'
     PHASE_1_COMPLETE=true
     AZURE_SUBSCRIPTION_ID=00000000-0000-0000-0000-000000000000
     AZURE_LOCATION=eastus2
     AZURE_RG=okta-mcp-demo
     AZURE_ACR_NAME=oktamcpdemofake
     ACR_LOGIN_SERVER=oktamcpdemofake.azurecr.io
     PG_NAME=okta-mcp-pg-demo-fake
     PG_FQDN=okta-mcp-pg-demo-fake.postgres.database.azure.com
     PG_PASSWORD=fakepassword123
     REDIS_NAME=okta-mcp-redis-demo-fake
     REDIS_URL=rediss://:fakekey@fake:6380/0
     ACA_ENV=okta-mcp-env
     DATABASE_URL=postgresql://test:test@test:5432/gateway_db
     EOF

   Run with all Okta env vars set — but do NOT actually let it call
   az commands successfully. The Step 2.3 ACR credential fetch will
   fail because the fake ACR doesn't exist. That's expected. The
   goal is to verify steps 2.0 through 2.2 work and the script exits
   with the AZ10 placeholder OR fails at Step 2.3.

   Skip this if AZURE_SMOKE_SUBSCRIPTION is not set — the structural
   bash -n check is enough.

5. Clean up: rm -f deploy/azure-aca/.acasetup.state

Print a summary listing:
  - Lines added to main.bicep (with resource count)
  - Lines added to acasetup.sh
  - bicep build result (or "skipped")
  - bash -n result
  - shellcheck result
  - Whether the three resources are present in the bicep outputs:
      grep -c "Microsoft.App/containerApps" deploy/azure-aca/bicep/main.bicep
    (should be 3)
```

### Expected Output

`bicep/main.bicep` is now a complete deployment template with three Container App resources and three FQDN outputs. `acasetup.sh` Phase 2 has a working prereq block plus secret generation, ending at the placeholder for AZ11.

---

## Prompt AZ11: ACA Image Build + Bicep Deploy + Health Check

### Context

Builds the three images via `az acr build` (server-side, no local Docker required), writes the Bicep parameters file, deploys the template, and polls the adapter health endpoint until it returns 200. This is the moment the demo deployment becomes real — at the end of this prompt you have a publicly-reachable adapter at an `azurecontainerapps.io` URL.

The parameters file is generated as `.params.json` inside `deploy/azure-aca/bicep/` and added to `.gitignore` (the .gitignore from AZ2 already excludes `.env` but the parameters file is separate). The file is written with mode 600 because it contains every secret in cleartext.

### Prompt

*Copy the text below into Claude Code:*

```
Add the image build, Bicep deploy, and health check steps to the
ACA wizard's Phase 2.

Pre-check:
1. AZ10 has been completed: run_phase_2 ends at the
   "PLACEHOLDER for AZ11" line after fetching ACR credentials.
2. deploy/azure-aca/bicep/main.bicep has the three Container App
   resources and three outputs.

Edits to deploy/azure-aca/.gitignore:

Append:
  bicep/.params.json
  bicep/main.json

Edits to deploy/azure-aca/acasetup.sh:

Replace the "PLACEHOLDER for AZ11" block in run_phase_2 with:

  # Step 2.4: Build images via az acr build (server-side)
  if $SKIP_BUILD; then
    info "Step 2.4: Skipping image builds (--skip-build)"
  else
    info "Step 2.4: Building images via az acr build (no Docker required)..."
    info "         This takes ~3-5 min per image."

    # Resolve the repo root — the wizard lives at deploy/azure-aca/
    REPO_ROOT="$(cd "$SCRIPT_DIR/../.." && pwd)"

    info "Building adapter..."
    az acr build --registry "$AZURE_ACR_NAME" \
      --image adapter:latest \
      --image "adapter:demo-$(date +%Y%m%d-%H%M%S)" \
      --file "$REPO_ROOT/Dockerfile" \
      "$REPO_ROOT" \
      --output none
    ok "adapter built"

    info "Building admin-ui..."
    az acr build --registry "$AZURE_ACR_NAME" \
      --image admin-ui:latest \
      --file "$REPO_ROOT/okta_agent_proxy_admin_ui/Dockerfile" \
      "$REPO_ROOT/okta_agent_proxy_admin_ui" \
      --output none
    ok "admin-ui built"

    info "Building hr-backend..."
    az acr build --registry "$AZURE_ACR_NAME" \
      --image hr-backend:latest \
      --file "$REPO_ROOT/examples/01-hr-system/Dockerfile" \
      "$REPO_ROOT/examples/01-hr-system" \
      --output none
    ok "hr-backend built"
  fi

  # Step 2.5: Write the Bicep parameters file
  info "Step 2.5: Writing Bicep parameters file..."
  PARAMS_FILE="$SCRIPT_DIR/bicep/.params.json"
  cat > "$PARAMS_FILE" <<EOF
{
  "\$schema": "https://schema.management.azure.com/schemas/2019-04-01/deploymentParameters.json#",
  "contentVersion": "1.0.0.0",
  "parameters": {
    "acaEnvName": { "value": "$ACA_ENV" },
    "acrLoginServer": { "value": "$ACR_LOGIN_SERVER" },
    "acrUsername": { "value": "$ACR_USERNAME" },
    "acrPassword": { "value": "$ACR_PASSWORD" },
    "encryptionKey": { "value": "$ENCRYPTION_KEY" },
    "adminPassword": { "value": "$ADMIN_PASSWORD" },
    "databaseUrl": { "value": "$DATABASE_URL" },
    "redisUrl": { "value": "$REDIS_URL" },
    "oktaRelayClientId": { "value": "$OKTA_RELAY_CLIENT_ID" },
    "oktaRelayClientSecret": { "value": "$OKTA_RELAY_CLIENT_SECRET" },
    "oktaDomain": { "value": "$OKTA_DOMAIN" },
    "oktaIssuer": { "value": "$OKTA_ISSUER" },
    "oktaAuthorizationServerId": { "value": "$OKTA_AUTHORIZATION_SERVER_ID" }
  }
}
EOF
  chmod 600 "$PARAMS_FILE"
  ok "Parameters file written (mode 600)"

  # Step 2.6: Validate the bicep template before deploy
  info "Step 2.6: Validating Bicep template..."
  az deployment group validate \
    --resource-group "$AZURE_RG" \
    --template-file "$SCRIPT_DIR/bicep/main.bicep" \
    --parameters "@$PARAMS_FILE" \
    --output none
  ok "Bicep template valid"

  # Step 2.7: Deploy the Container Apps
  info "Step 2.7: Deploying Container Apps (~3-5 min)..."
  DEPLOYMENT_NAME="okta-mcp-aca-$(date +%Y%m%d-%H%M%S)"
  az deployment group create \
    --resource-group "$AZURE_RG" \
    --name "$DEPLOYMENT_NAME" \
    --template-file "$SCRIPT_DIR/bicep/main.bicep" \
    --parameters "@$PARAMS_FILE" \
    --output none
  ok "Bicep deployment complete"
  save_state ACA_DEPLOYMENT_NAME "$DEPLOYMENT_NAME"

  # Step 2.8: Fetch FQDNs from deployment outputs
  info "Step 2.8: Fetching application FQDNs..."
  ADAPTER_FQDN="$(az deployment group show -g "$AZURE_RG" -n "$DEPLOYMENT_NAME" \
    --query properties.outputs.adapterFqdn.value -o tsv)"
  ADMIN_FQDN="$(az deployment group show -g "$AZURE_RG" -n "$DEPLOYMENT_NAME" \
    --query properties.outputs.adminUiFqdn.value -o tsv)"
  HR_FQDN="$(az deployment group show -g "$AZURE_RG" -n "$DEPLOYMENT_NAME" \
    --query properties.outputs.hrBackendFqdn.value -o tsv)"
  save_state ADAPTER_FQDN "$ADAPTER_FQDN"
  save_state ADMIN_FQDN "$ADMIN_FQDN"
  save_state HR_FQDN "$HR_FQDN"
  ok "Adapter:  https://$ADAPTER_FQDN"
  ok "Admin UI: https://$ADMIN_FQDN"
  ok "HR (internal): $HR_FQDN"

  # Step 2.9: Wait for the adapter health endpoint
  info "Step 2.9: Polling adapter health endpoint..."
  local elapsed=0 max_wait=180
  while (( elapsed < max_wait )); do
    if curl -sf "https://$ADAPTER_FQDN/health" >/dev/null 2>&1; then
      ok "Adapter is healthy after ${elapsed}s"
      break
    fi
    printf "."
    sleep 5
    elapsed=$((elapsed + 5))
  done
  echo ""
  if (( elapsed >= max_wait )); then
    warn "Adapter health endpoint did not respond after ${max_wait}s"
    warn "Check logs: az containerapp logs show -g $AZURE_RG -n okta-mcp-adapter --follow"
  fi

  # PLACEHOLDER for AZ12: Smoke tests + helper scripts

  warn "AZ11 only — smoke tests and start/stop helpers added in AZ12"
  exit 0

Verification:

1. bash -n deploy/azure-aca/acasetup.sh
2. shellcheck deploy/azure-aca/acasetup.sh (skip if not installed)
3. Confirm bicep/.params.json and bicep/main.json are in .gitignore:
     grep -E "params.json|main.json" deploy/azure-aca/.gitignore
4. If AZURE_SMOKE_SUBSCRIPTION is set and Phase 1 has run for ACA,
   optionally do a real Phase 2 run (~15 min wall-clock):
     ./deploy/azure-aca/acasetup.sh --phase 2 --non-interactive
   At the end, verify:
     - All three Container Apps exist:
         az containerapp list -g $AZURE_RG -o table
     - Adapter responds to /health
     - .params.json file has mode 600
     - State has ADAPTER_FQDN, ADMIN_FQDN, HR_FQDN

Print a summary listing:
  - Lines added to acasetup.sh
  - .gitignore updated (yes/no)
  - bash -n result
  - shellcheck result
  - Real-run result if AZURE_SMOKE_SUBSCRIPTION is set
```

### Expected Output

`run_phase_2()` now builds the three images, writes a secured parameters file, deploys the Bicep template, captures the FQDNs, and waits for the adapter to become healthy. Stops at the placeholder for AZ12.

---

## Prompt AZ12: ACA Smoke Tests + Start/Stop Helpers + Final Summary

### Context

Last prompt of the pack. Closes out ACA Phase 2 with the same five smoke tests used in the production deployment, writes `demo-stop.sh` and `demo-start.sh` (the day-to-day ops scripts that drop the bill from ~$70-80/mo active to ~$25/mo idle), prints the final summary box with URLs and cost reminders, and marks `PHASE_2_COMPLETE=true` for the ACA wizard.

After this prompt the ACA wizard is **complete** end to end — the operator can deploy a working demo with `./acasetup.sh` and stop/start it between sessions.

### Prompt

*Copy the text below into Claude Code:*

```
Add the smoke tests, start/stop helper scripts, and final summary to
the ACA wizard's Phase 2.

Pre-check:
1. AZ11 has been completed: run_phase_2 ends with the
   "PLACEHOLDER for AZ12" line after the health check.

Edits to deploy/azure-aca/acasetup.sh:

Replace the "PLACEHOLDER for AZ12" block with:

  # Step 2.10: Smoke tests — five checks that prove end-to-end works
  info "Step 2.10: Running smoke tests..."
  local pass=0 total=5

  # Smoke 1: oauth-protected-resource metadata
  if curl -sf "https://$ADAPTER_FQDN/.well-known/oauth-protected-resource" \
       >/dev/null 2>&1; then
    ok "Smoke 1/5: oauth-protected-resource metadata"
    pass=$((pass + 1))
  else
    fail "Smoke 1/5: oauth-protected-resource metadata"
  fi

  # Smoke 2: health endpoint (already polled in step 2.9 but double-check)
  if curl -sf "https://$ADAPTER_FQDN/health" >/dev/null 2>&1; then
    ok "Smoke 2/5: health endpoint"
    pass=$((pass + 1))
  else
    fail "Smoke 2/5: health endpoint"
  fi

  # Smoke 3: admin login
  local login_response
  login_response=$(curl -sf -X POST "https://$ADAPTER_FQDN/api/admin/login" \
    -H "Content-Type: application/json" \
    -d "{\"username\":\"admin\",\"password\":\"$ADMIN_PASSWORD\"}" 2>/dev/null || true)
  local access_token
  access_token=$(echo "$login_response" | jq -r '.access_token // empty' 2>/dev/null || true)
  if [[ -n "$access_token" ]]; then
    ok "Smoke 3/5: admin login"
    pass=$((pass + 1))
  else
    fail "Smoke 3/5: admin login (no access_token in response)"
  fi

  # Smoke 4: list agents (using token from smoke 3)
  if [[ -n "$access_token" ]]; then
    if curl -sf "https://$ADAPTER_FQDN/api/admin/agents" \
         -H "Authorization: Bearer $access_token" >/dev/null 2>&1; then
      ok "Smoke 4/5: list agents"
      pass=$((pass + 1))
    else
      fail "Smoke 4/5: list agents"
    fi
  else
    warn "Smoke 4/5: skipped (no token from smoke 3)"
  fi

  # Smoke 5: cache provider reports redis
  local cache_health
  cache_health=$(curl -sf "https://$ADAPTER_FQDN/health/cache" 2>/dev/null || \
                 curl -sf "https://$ADAPTER_FQDN/health" 2>/dev/null || true)
  if echo "$cache_health" | grep -q '"cache_provider":\s*"redis"' 2>/dev/null; then
    ok "Smoke 5/5: cache_provider=redis confirmed"
    pass=$((pass + 1))
  else
    warn "Smoke 5/5: could not confirm cache_provider=redis"
    warn "          (the adapter may not expose this endpoint yet — non-fatal)"
  fi

  info "Smoke results: ${pass}/${total} passed"

  # Step 2.11: Write demo-stop.sh helper
  info "Step 2.11: Writing demo-stop.sh and demo-start.sh helpers..."
  cat > "$SCRIPT_DIR/demo-stop.sh" <<'STOPEOF'
#!/usr/bin/env bash
# =============================================================
# demo-stop.sh — Stop the ACA demo to drop cost
# =============================================================
# Stops Postgres (storage-only billing) and scales all Container
# Apps to 0 replicas. Drops cost from ~$70-80/mo to ~$25/mo.
#
# Redis Basic C0 cannot be stopped — it stays at ~$16/mo.
#
# Usage:
#   ./demo-stop.sh
#   AZURE_RG=other-rg ./demo-stop.sh
# =============================================================
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
STATE_FILE="${SCRIPT_DIR}/.acasetup.state"

if [[ ! -f "$STATE_FILE" ]]; then
  echo "ERROR: $STATE_FILE not found. Run acasetup.sh first." >&2
  exit 1
fi

# Source the state file
# shellcheck disable=SC1090
source "$STATE_FILE"

RG="${AZURE_RG:-okta-mcp-demo}"

echo "Stopping Postgres $PG_NAME..."
az postgres flexible-server stop -g "$RG" -n "$PG_NAME" --output none
echo "  done"

for app in okta-mcp-adapter admin-ui hr-mcp-server; do
  echo "Scaling $app to 0..."
  az containerapp update -g "$RG" -n "$app" \
    --min-replicas 0 --max-replicas 0 --output none
  echo "  done"
done

echo ""
echo "Demo stopped. Idle cost: ~\$25/mo (Redis + PG storage + ACR + LA)"
echo "Restart with: ./demo-start.sh"
STOPEOF
  chmod +x "$SCRIPT_DIR/demo-stop.sh"
  ok "demo-stop.sh written"

  # Step 2.12: Write demo-start.sh helper
  cat > "$SCRIPT_DIR/demo-start.sh" <<'STARTEOF'
#!/usr/bin/env bash
# =============================================================
# demo-start.sh — Restart the ACA demo after demo-stop.sh
# =============================================================
# Starts Postgres and restores Container App scaling. Wait ~60s
# after this completes for the adapter to become healthy.
# =============================================================
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
STATE_FILE="${SCRIPT_DIR}/.acasetup.state"

if [[ ! -f "$STATE_FILE" ]]; then
  echo "ERROR: $STATE_FILE not found. Run acasetup.sh first." >&2
  exit 1
fi

# shellcheck disable=SC1090
source "$STATE_FILE"

RG="${AZURE_RG:-okta-mcp-demo}"

echo "Starting Postgres $PG_NAME..."
az postgres flexible-server start -g "$RG" -n "$PG_NAME" --output none
echo "  done"

echo "Restoring Container App replicas..."
az containerapp update -g "$RG" -n okta-mcp-adapter \
  --min-replicas 1 --max-replicas 4 --output none
az containerapp update -g "$RG" -n admin-ui \
  --min-replicas 0 --max-replicas 2 --output none
az containerapp update -g "$RG" -n hr-mcp-server \
  --min-replicas 0 --max-replicas 1 --output none

echo ""
echo "Demo restarted. Wait ~60s for the adapter to become healthy."
echo "Adapter URL: https://${ADAPTER_FQDN}"
STARTEOF
  chmod +x "$SCRIPT_DIR/demo-start.sh"
  ok "demo-start.sh written"

  # Step 2.13: Mark Phase 2 complete and print summary
  save_state PHASE_2_COMPLETE "true"

  print_summary_box "Phase 2 Complete: Demo Ready" \
    "Adapter:    https://$ADAPTER_FQDN" \
    "Admin UI:   https://$ADMIN_FQDN" \
    "HR (int):   $HR_FQDN" \
    "" \
    "Smoke:      ${pass}/${total} passed" \
    "" \
    "Cost:       ~\$70-80/mo active, ~\$25/mo stopped" \
    "" \
    "Stop demo:  ./demo-stop.sh" \
    "Start demo: ./demo-start.sh" \
    "Teardown:   ./acasetup.sh --destroy"
}

Edits to deploy/azure-aca/README.md:

Update the Phases section to mark Phase 2 as complete and document
the start/stop helpers. Specifically:

1. In the "Phases" table, change Phase 2's description from "(stub)"
   to:
     "Build images, deploy Bicep, smoke test, write demo-stop.sh
      and demo-start.sh"

2. Add a new section after "Quick Start" titled "Day-to-day operations"
   with this content:

   ## Day-to-day operations

   After running `./acasetup.sh` once, use these helpers to control
   the demo between sessions:

   ```bash
   # Drop cost from ~$70-80/mo to ~$25/mo
   ./demo-stop.sh

   # Bring it back (~60s for adapter to become healthy)
   ./demo-start.sh
   ```

   Both scripts read `.acasetup.state` for resource names and the
   resource group, so they work without any environment variables
   as long as you run them from the `deploy/azure-aca/` directory.

   The Redis Basic C0 cache cannot be stopped — it stays at ~$16/mo
   even when the demo is "stopped." If you need to drop to truly
   zero cost, run `./acasetup.sh --destroy` and re-deploy when
   needed (~30 min).

Verification:

1. bash -n deploy/azure-aca/acasetup.sh
2. shellcheck deploy/azure-aca/acasetup.sh (skip if not installed)

3. After running this prompt, demo-stop.sh and demo-start.sh do NOT
   yet exist in deploy/azure-aca/ — they are written at runtime when
   Phase 2 is executed against a real subscription. To verify the
   shell HEREDOC blocks parse, do this synthetic test:

     # Extract the heredoc bodies and shell-check them
     awk '/<<.STOPEOF/,/^STOPEOF$/' deploy/azure-aca/acasetup.sh | \
       sed '1d;$d' > /tmp/demo-stop-test.sh
     bash -n /tmp/demo-stop-test.sh

     awk '/<<.STARTEOF/,/^STARTEOF$/' deploy/azure-aca/acasetup.sh | \
       sed '1d;$d' > /tmp/demo-start-test.sh
     bash -n /tmp/demo-start-test.sh

     rm -f /tmp/demo-stop-test.sh /tmp/demo-start-test.sh

4. README updated:
     grep -q "Day-to-day operations" deploy/azure-aca/README.md
     grep -q "demo-stop.sh" deploy/azure-aca/README.md

5. If AZURE_SMOKE_SUBSCRIPTION is set and Phases 1 + 2 have been run
   end-to-end, verify:
     - PHASE_2_COMPLETE=true in .acasetup.state
     - demo-stop.sh and demo-start.sh exist and are executable
     - Run ./demo-stop.sh, then check pods are scaled to 0:
         az containerapp list -g $AZURE_RG \
           --query "[].{name:name,minReplicas:properties.template.scale.minReplicas}" \
           -o table
     - Run ./demo-start.sh, then poll the adapter URL:
         curl -sf https://$ADAPTER_FQDN/health
     - Tear down: ./acasetup.sh --destroy

Print a final summary:
  - Total lines added to acasetup.sh in this prompt
  - Heredoc parse check results
  - README updated (yes/no)
  - bash -n result
  - shellcheck result
  - Real run result if AZURE_SMOKE_SUBSCRIPTION is set
  - Recommendation:
      git add deploy/azure-aks deploy/azure-aca
      git commit -m "AZ7-AZ12: Azure wizard Phase 2 complete (AKS stateful + ACA full)"
```

### Expected Output

`acasetup.sh` Phase 2 is now complete end to end. After running this against a real subscription, the operator has a working demo URL, two helper scripts for cost management, and the wizard is ready to be packaged and shipped.

---

## After Completion

When all 6 prompts have been run, the deliverables are:

**AKS wizard** (`deploy/azure-aks/`)
- Phase 1 (foundation) — complete from the scaffolding pack
- Phase 2 (stateful tier) — complete from this pack
- Phase 3 (application + ingress) — still a stub (next pack)
- Phase 4 (smoke + lockdown) — still a stub (next pack)
- README documents the Phase 2/4 Key Vault public access window

**ACA wizard** (`deploy/azure-aca/`)
- Phase 1 (foundation) — complete from the scaffolding pack
- Phase 2 (application deployment) — complete from this pack — **wizard is fully functional**
- `demo-stop.sh` and `demo-start.sh` get written to the deploy directory when Phase 2 runs against a real subscription
- README documents day-to-day operations

To verify against a real Azure subscription:

```bash
# Demo wizard (full end-to-end, ~30 min)
cd deploy/azure-aca
cp .env.example .env
vi .env  # fill in AZURE_SUBSCRIPTION_ID and the 5 OKTA_* values
./acasetup.sh                # runs Phase 1 + Phase 2 end-to-end
# At the end, you have a working demo at https://<adapter-fqdn>

# Try the cost-saver scripts
./demo-stop.sh               # drops to ~$25/mo
./demo-start.sh              # back up in ~60s

# AKS wizard (Phase 1 + Phase 2 only — Phase 3+4 stubs will exit early)
cd ../azure-aks
cp .env.example .env
vi .env
./azuresetup.sh --phase 1    # ~10 min
./azuresetup.sh --phase 2    # ~25 min — provisions PG, Redis, KV, secrets
# Phase 3 will print "not yet implemented in scaffolding"

# Tear down both
cd ../azure-aca && ./acasetup.sh --destroy
cd ../azure-aks && ./azuresetup.sh --destroy
```

## What's left after this pack

Only AKS Phases 3 and 4 remain. The next pack (call it `AZ13–AZ18` or so) will build:

- **AKS Phase 3** — image build via `az acr build`, manifest substitution from `manifests/*.yaml` templates, `kubectl apply`, ALB controller install via Helm, ApplicationLoadBalancer + Gateway + HTTPRoute resources, AGC FQDN capture and CNAME instructions for the operator
- **AKS Phase 4** — Container Insights enable, the same five smoke tests used in ACA Phase 2 (proving cache_provider=redis works in the cluster), Key Vault public network access disable, final summary box

Estimate: 5-7 prompts, similar shape to this pack. After that, both wizards are 100% complete and ready to ship.
