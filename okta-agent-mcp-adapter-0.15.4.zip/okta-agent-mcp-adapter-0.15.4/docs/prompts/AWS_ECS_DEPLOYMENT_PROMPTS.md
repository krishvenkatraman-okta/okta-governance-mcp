> **Historical (pre-v0.15.x):** Password-based admin login references in this document are obsolete. The adapter accepts only Okta OAuth access tokens — see [docs/OPERATIONS.md § Admin API Authentication](../OPERATIONS.md#admin-api-authentication).

# AWS ECS Fargate Deployment Prompts

## Okta MCP Adapter — Demo & Small Production

9 sequential prompts that build an ECS Fargate deployment with managed RDS PostgreSQL, ElastiCache Redis (Serverless or instance, selectable), Secrets Manager, ALB with ACM TLS, and CloudWatch observability. Supports two deployment sizes via a single Terraform variable.

| Deployment Size | Adapter Tasks | RDS | ElastiCache | ALB | Multi-AZ | Monthly Cost |
|---|---|---|---|---|---|---|
| `demo` | 1 | `db.t4g.micro` Single-AZ | `cache.t4g.micro` or Serverless | Shared | No | ~$90–120 |
| `small-prod` | 2 (spread across AZs) | `db.t4g.small` Multi-AZ | `cache.t4g.small` + replica or Serverless | Shared | Yes | ~$200–250 |
| Stopped (demo) | 0 | Stopped (storage only) | Running or deleted | Running | — | ~$15–20 |

---

## Prerequisites

> **⚠ AWS Administrators:** Before the operator runs `deploy.sh`, review **Prompt E10** which generates `deploy/aws-ecs/iam/README.md` and a minimum-scope IAM policy. In enterprise environments, the operator's user/role typically does not have the IAM permissions required to create the resources in this deployment. E10 provides the concrete policy to attach and documents common SCP/permission-boundary conflicts.

- AWS account with permissions for: VPC, ECS, ECR, RDS, ElastiCache, ALB, ACM, Route53, Secrets Manager, IAM, CloudWatch, CodeBuild (optional) — see E10 for the concrete IAM policy
- AWS CLI v2 authenticated (`aws sts get-caller-identity` succeeds)
- Terraform >= 1.6
- Docker installed and running (unless using the CodeBuild fallback in E9)
- Okta org with Custom Authorization Server + OIDC Web App configured
- Redis caching migration completed — verify with: `pytest tests/integration/test_redis_multipod.py`
- A Route53 hosted zone for your domain (the prompts create DNS records in it)

### Required environment variables

```bash
export AWS_REGION="us-east-1"
export AWS_ACCOUNT_ID="123456789012"
export TF_VAR_okta_domain="your-org.okta.com"
export TF_VAR_okta_issuer="https://your-org.okta.com/oauth2/<AS_ID>"
export TF_VAR_okta_authorization_server_id="<AS_ID>"
export TF_VAR_okta_relay_client_id="<RELAY_CLIENT_ID>"
export TF_VAR_okta_relay_client_secret="<RELAY_CLIENT_SECRET>"
export TF_VAR_adapter_hostname="mcp.example.com"
export TF_VAR_admin_hostname="admin-mcp.example.com"
export TF_VAR_route53_zone_id="Z0123456789ABCDEF"

# Admin UI Okta OIDC (separate app from the adapter relay)
export TF_VAR_admin_ui_okta_domain="your-org.okta.com"
export TF_VAR_admin_ui_okta_client_id="<ADMIN_UI_CLIENT_ID>"
export TF_VAR_admin_ui_okta_client_secret="<ADMIN_UI_CLIENT_SECRET>"

# Optional: deployment size (default: demo)
export TF_VAR_deployment_size="demo"   # or "small-prod"

# Optional: ElastiCache type (default: instance)
export TF_VAR_cache_type="instance"    # or "serverless"
```

---

## How to Execute

Copy each prompt body into Claude Code in order. Wait for completion, then commit before starting the next. Each prompt is self-contained and idempotent — re-running a partially failed prompt is safe.

```bash
cd okta-agent-mcp-adapter
git checkout -b feat/aws-ecs-deployment

# Then paste each prompt into Claude Code, one at a time.
# After each prompt completes:
git add -A && git commit -m "AWS ECS E<N>: <prompt title>"
```

---

## Prompt Map

| # | Prompt | Creates / Modifies | Est. Time |
|---|---|---|---|
| E1 | AWS account bootstrap — VPC + ECR | VPC, subnets, IGW, NAT GW, ECR repos × 3 | 5 min |
| E2 | RDS PostgreSQL + ElastiCache Redis | RDS instance, ElastiCache (toggle), security groups | 10 min |
| E3 | Secrets Manager + IAM roles | 4 secrets, ECS task role, task execution role | 5 min |
| E4 | Build & push images to ECR | adapter, admin-ui, hr-backend in ECR | 5 min |
| E5 | ECS cluster + task definitions | Cluster, 4 task defs, FireLens, Service Connect namespace | 10 min |
| E6 | ECS services + ALB + DNS | 4 services, ALB, target groups, ACM cert, Route53 records | 15 min |
| E7 | Smoke tests + stop/start scripts | 5 smoke tests, stop.sh, start.sh | 10 min |
| E8 | Terraform wrapper + deploy.sh + README | deploy/aws-ecs/ Terraform module, deploy.sh, cost table, teardown | 15 min |
| E9 | CodeBuild fallback for image builds | CodeBuild project, buildspec.yml, --use-codebuild flag | 10 min |
| E10 | IAM prerequisites + operator policy docs | operator-policy.json, iam/README.md, deploy.sh pre-flight checks | 10 min |
| E11 | External DNS provider support (retrofit) | dns_provider variable, conditional Route53 resources, manual CNAME workflow | 10 min |
| E12 | Deployment tarball packaging | package.sh — self-contained tarball for distribution | 10 min |
| E13 | Quick redeploy scripts for individual components | deploy-adapter.sh, deploy-ui.sh, deploy-backend.sh + README section | 10 min |
| ~~E14~~ | ~~Enterprise VPC and policy compatibility (retrofit)~~ | **Superseded by E15 — do NOT execute E14** | — |
| E15 | Enterprise BYO compatibility (full retrofit) | BYO-VPC, BYO-ECR, BYO-ACM, BYO-KMS, BYO-S3, BYO-Logs, BYO-WAF + internal ALB + tags + IAM + preflight-enterprise.sh | 30 min |

---

## Prompt E1: AWS Account Bootstrap — VPC + ECR

### Context

Creates the foundational AWS networking and container registry. The VPC has 2 public subnets (for ALB) and 2 private subnets (for ECS tasks, RDS, ElastiCache) across 2 AZs. A single NAT Gateway provides outbound internet for private subnets (the adapter needs to reach Okta). ECR repositories are created for all three images. All resources are tagged with `Project=okta-mcp-adapter` and `Environment=demo|small-prod`.

### Prompt

```
Bootstrap the AWS account for the Okta MCP Adapter ECS Fargate deployment.

Read deploy/aws-ec2/ first to understand existing AWS patterns (VPC
discovery, security group creation, tagging conventions). This new
deployment goes in deploy/aws-ecs/ and is Terraform-based, not a
shell wizard.

Create deploy/aws-ecs/main.tf (this will be the single-phase Terraform
module — we build it incrementally across prompts E1–E8, then wrap it
in deploy.sh in E8).

For E1, add these resources to deploy/aws-ecs/main.tf:

1. terraform and provider blocks:
   - required_providers: aws ~> 5.0
   - provider "aws" reading var.aws_region
   - A locals block with:
     project_name = "okta-mcp"
     common_tags = { Project = "okta-mcp-adapter", Environment = var.deployment_size, ManagedBy = "terraform" }

2. Create deploy/aws-ecs/variables.tf with ALL variables the full
   module will need (we define them all now so later prompts just
   reference them):
   - aws_region (default: "us-east-1")
   - deployment_size (default: "demo", validation: demo or small-prod)
   - cache_type (default: "instance", validation: instance or serverless)
   - okta_domain (no default, sensitive: false)
   - okta_issuer (no default)
   - okta_authorization_server_id (no default)
   - okta_relay_client_id (no default, sensitive: true)
   - okta_relay_client_secret (no default, sensitive: true)
   - adapter_hostname (no default)
   - admin_hostname (no default)
   - route53_zone_id (no default)
   - admin_ui_okta_domain (no default)
   - admin_ui_okta_client_id (no default, sensitive: true)
   - admin_ui_okta_client_secret (no default, sensitive: true)
   - admin_username (default: "admin")
   - admin_password (no default, sensitive: true, description mentions
     it will be auto-generated by deploy.sh if not set)
   - encryption_key (no default, sensitive: true, description mentions
     it will be auto-generated by deploy.sh if not set)
   - db_instance_class (default computed from deployment_size:
     demo = "db.t4g.micro", small-prod = "db.t4g.small")
   - db_multi_az (default computed: demo = false, small-prod = true)
   - adapter_desired_count (default computed: demo = 1, small-prod = 2)

3. VPC:
   - aws_vpc with CIDR 10.0.0.0/16, enable_dns_hostnames = true
   - 2 public subnets: 10.0.1.0/24 and 10.0.2.0/24 in AZ a and b
   - 2 private subnets: 10.0.10.0/24 and 10.0.11.0/24 in AZ a and b
   - Internet Gateway attached to VPC
   - 1 NAT Gateway in public subnet a (Elastic IP allocated)
     - Comment: "Single NAT GW keeps demo costs low. For production
       HA, add a second NAT GW in subnet b."
   - Public route table: 0.0.0.0/0 → IGW, associated with both
     public subnets
   - Private route table: 0.0.0.0/0 → NAT GW, associated with both
     private subnets
   - Tag all subnets with Name = "${local.project_name}-{public|private}-{a|b}"

4. ECR repositories (3):
   - "${local.project_name}-adapter"
   - "${local.project_name}-admin-ui"
   - "${local.project_name}-hr-backend"
   - image_tag_mutability = "MUTABLE" (latest tag is overwritten)
   - image_scanning_configuration: scan_on_push = true
   - lifecycle_policy: keep last 10 images, expire untagged after 7 days
   - force_delete = true (so terraform destroy works cleanly)

5. Create deploy/aws-ecs/outputs.tf with placeholders for outputs
   we will add in later prompts. For now, output:
   - vpc_id
   - private_subnet_ids (list)
   - public_subnet_ids (list)
   - ecr_adapter_url
   - ecr_admin_ui_url
   - ecr_hr_backend_url

6. Run terraform fmt on all files.
   Run terraform validate.
   Run terraform plan with placeholder variable values to confirm
   no syntax errors.

7. Do NOT apply — we are authoring IaC incrementally.
```

### Expected Output

`deploy/aws-ecs/` exists with `main.tf`, `variables.tf`, `outputs.tf`. VPC, subnets, IGW, NAT GW, and 3 ECR repos are defined. `terraform validate` passes.

---

## Prompt E2: RDS PostgreSQL + ElastiCache Redis

### Context

Creates the data tier. RDS PostgreSQL instance class and Multi-AZ setting are driven by `var.deployment_size`. ElastiCache supports two modes via `var.cache_type`: "instance" (a `cache.t4g.micro` or `cache.t4g.small` replication group) or "serverless" (ElastiCache Serverless). Both modes support encryption in transit and at rest. Security groups enforce that only ECS tasks in the private subnets can reach the data tier.

### Prompt

```
Add the data tier to the Okta MCP Adapter ECS deployment.

Read deploy/aws-ecs/main.tf (from E1) and add the following resources.

1. DB subnet group:
   - aws_db_subnet_group using the 2 private subnets

2. RDS PostgreSQL instance:
   - aws_db_instance with:
     engine = "postgres", engine_version = "15"
     instance_class = local.db_instance_class (computed from
       var.deployment_size: demo → "db.t4g.micro",
       small-prod → "db.t4g.small")
     allocated_storage = 20, max_allocated_storage = 50, storage_type = "gp3"
     db_name = "gateway_db"
     username = "gateway_user"
     password = random_password.db_password.result
     multi_az = local.db_multi_az (demo → false, small-prod → true)
     db_subnet_group_name = the subnet group above
     vpc_security_group_ids = [aws_security_group.rds_sg.id]
     storage_encrypted = true
     backup_retention_period = 7
     skip_final_snapshot = true (for demo teardown simplicity)
     deletion_protection = false
     performance_insights_enabled = true (free tier on t4g)
     apply_immediately = true
     tags = local.common_tags
   - Add a random_password resource "db_password" with length=24,
     special=true, override_special="!#$%^&*()-_=+"

3. RDS security group:
   - aws_security_group "rds_sg" in the VPC
   - Ingress: TCP 5432 from aws_security_group.ecs_tasks_sg.id
     (we create the ECS SG here as a forward reference)
   - Egress: none needed (RDS doesn't initiate connections)
   - Tag: Name = "${local.project_name}-rds"

4. ECS tasks security group (forward declaration — services attach later):
   - aws_security_group "ecs_tasks_sg" in the VPC
   - Ingress: TCP 8000 from aws_security_group.alb_sg.id (adapter)
   - Ingress: TCP 3001 from aws_security_group.alb_sg.id (admin UI)
   - Ingress: TCP 8001 from self (hr-backend, adapter → backend east-west)
   - Egress: all traffic to 0.0.0.0/0 (adapter needs Okta, ECR, etc.)
   - Tag: Name = "${local.project_name}-ecs-tasks"

5. ALB security group (forward declaration — ALB created in E6):
   - aws_security_group "alb_sg" in the VPC
   - Ingress: TCP 443 from 0.0.0.0/0
   - Ingress: TCP 80 from 0.0.0.0/0 (HTTP → HTTPS redirect)
   - Egress: TCP 8000 to ecs_tasks_sg (adapter)
   - Egress: TCP 3001 to ecs_tasks_sg (admin UI)
   - Tag: Name = "${local.project_name}-alb"

6. ElastiCache — CONDITIONAL on var.cache_type:

   When cache_type = "instance":
   - aws_elasticache_subnet_group using private subnets
   - aws_elasticache_replication_group with:
     replication_group_id = "${local.project_name}-redis"
     description = "Okta MCP Adapter Redis"
     engine = "redis", engine_version = "7.1"
     node_type = local.cache_instance_class (computed:
       demo → "cache.t4g.micro", small-prod → "cache.t4g.small")
     num_cache_clusters = local.cache_replicas (demo → 1, small-prod → 2)
     automatic_failover_enabled = (small-prod → true, demo → false)
     at_rest_encryption_enabled = true
     transit_encryption_enabled = true
     auth_token = random_password.redis_password.result
     subnet_group_name = the subnet group above
     security_group_ids = [aws_security_group.redis_sg.id]
     port = 6379
     tags = local.common_tags

   When cache_type = "serverless":
   - aws_elasticache_serverless_cache with:
     engine = "redis"
     name = "${local.project_name}-redis"
     subnet_ids = private subnet IDs
     security_group_ids = [aws_security_group.redis_sg.id]
     tags = local.common_tags
   - Note: Serverless manages encryption and auth automatically.
     The REDIS_URL will use the serverless endpoint with TLS.

   - Add random_password "redis_password" with length=32,
     special=false (ElastiCache AUTH tokens cannot contain
     special characters when using certain configurations)

   Use count or dynamic blocks to conditionally create the right
   set of resources based on var.cache_type.

7. Redis security group:
   - aws_security_group "redis_sg" in the VPC
   - Ingress: TCP 6379 from ecs_tasks_sg
   - Egress: none
   - Tag: Name = "${local.project_name}-redis"

8. Add locals block entries for computed values:
   db_instance_class = var.deployment_size == "demo" ? "db.t4g.micro" : "db.t4g.small"
   db_multi_az = var.deployment_size == "small-prod"
   cache_instance_class = var.deployment_size == "demo" ? "cache.t4g.micro" : "cache.t4g.small"
   cache_replicas = var.deployment_size == "demo" ? 1 : 2
   adapter_desired_count = var.deployment_size == "demo" ? 1 : 2

9. Add outputs:
   - rds_endpoint (aws_db_instance.this.endpoint)
   - rds_db_name
   - redis_endpoint (conditional: instance primary endpoint or
     serverless endpoint)

10. Run terraform fmt and terraform validate.

Do NOT apply.
```

### Expected Output

`main.tf` now includes RDS, ElastiCache (both modes), 4 security groups, random passwords. `terraform validate` passes.

---

## Prompt E3: Secrets Manager + IAM Roles

### Context

Creates AWS Secrets Manager entries for all sensitive configuration and the IAM roles ECS tasks need. The ECS task execution role can pull images from ECR and read secrets. The ECS task role gives the running container permission to access Secrets Manager at runtime (for any future secret refresh needs). Secrets are organized as JSON blobs to minimize API calls and cost.

### Prompt

```
Add Secrets Manager and IAM roles for the Okta MCP Adapter ECS deployment.

Read deploy/aws-ecs/main.tf and add:

1. Secrets Manager — 4 secrets, each a JSON object:

   a. "${local.project_name}/db" containing:
      { "DATABASE_URL": "postgresql://gateway_user:<db_password>@<rds_endpoint>/gateway_db" }
      Use the random_password.db_password.result and
      aws_db_instance.this.endpoint to construct the value.

   b. "${local.project_name}/redis" containing:
      {
        "REDIS_URL": "<constructed from endpoint + password + TLS flag>",
        "REDIS_PASSWORD": "<random_password.redis_password.result>",
        "REDIS_TLS_ENABLED": "true"
      }
      The REDIS_URL format differs by cache_type:
        instance: "rediss://:<password>@<primary_endpoint>:6379/0"
          (note: "rediss://" for TLS)
        serverless: "rediss://:<password>@<serverless_endpoint>:6379/0"
      Use a local to compute the correct URL.

   c. "${local.project_name}/okta" containing:
      {
        "OKTA_DOMAIN": var.okta_domain,
        "OKTA_ISSUER": var.okta_issuer,
        "OKTA_AUTHORIZATION_SERVER_ID": var.okta_authorization_server_id,
        "RELAY_OKTA_CLIENT_ID": var.okta_relay_client_id,
        "RELAY_OKTA_CLIENT_SECRET": var.okta_relay_client_secret
      }

   d. "${local.project_name}/app" containing:
      {
        "ENCRYPTION_KEY": var.encryption_key,
        "ADMIN_USERNAME": var.admin_username,
        "ADMIN_PASSWORD": var.admin_password,
        "GATEWAY_BASE_URL": "https://${var.adapter_hostname}",
        "ADMIN_UI_NEXTAUTH_SECRET": random_password.nextauth_secret.result,
        "ADMIN_UI_OKTA_CLIENT_SECRET": var.admin_ui_okta_client_secret
      }
      Add random_password "nextauth_secret" length=48 special=false.

   All secrets: recovery_window_in_days = 0 (immediate delete for
   demo teardown), tags = local.common_tags

2. ECS task execution role:
   - aws_iam_role "ecs_task_execution" with assume_role_policy
     for ecs-tasks.amazonaws.com
   - Attach AmazonECSTaskExecutionRolePolicy (managed policy)
   - Inline policy "secrets-access" with:
     secretsmanager:GetSecretValue on the 4 secret ARNs
   - Inline policy "ecr-access" with:
     ecr:GetAuthorizationToken (resource: "*")
     ecr:BatchCheckLayerAvailability, ecr:GetDownloadUrlForLayer,
     ecr:BatchGetImage on the 3 ECR repo ARNs
   - Inline policy "logs" with:
     logs:CreateLogGroup, logs:CreateLogStream, logs:PutLogEvents
     on "arn:aws:logs:${var.aws_region}:${data.aws_caller_identity.current.account_id}:*"
   - Add data "aws_caller_identity" "current" {}

3. ECS task role:
   - aws_iam_role "ecs_task" with assume_role_policy for
     ecs-tasks.amazonaws.com
   - Inline policy "secrets-read" with:
     secretsmanager:GetSecretValue on the 4 secret ARNs
     (adapter may need runtime secret access for rotation)
   - This role is what the running container assumes. Keep it
     minimal — only secrets read access.

4. Add outputs:
   - ecs_task_execution_role_arn
   - ecs_task_role_arn
   - secrets_db_arn
   - secrets_redis_arn
   - secrets_okta_arn
   - secrets_app_arn

5. Run terraform fmt and terraform validate.

Do NOT apply.
```

### Expected Output

4 Secrets Manager secrets (JSON), 2 IAM roles with scoped policies. `terraform validate` passes.

---

## Prompt E4: Build & Push Images to ECR

### Context

Builds all three Docker images locally and pushes them to ECR. This prompt is executed by the operator (not Terraform) — it creates a helper script `deploy/aws-ecs/build-images.sh` that authenticates to ECR, builds multi-platform images (amd64 for Fargate), and pushes. The script is idempotent and can be re-run to push updated images.

### Prompt

```
Create the image build and push script for the ECS deployment.

Read the project root Dockerfile and the existing
deploy/aws-ec2/package.sh for build context patterns.

Create deploy/aws-ecs/build-images.sh:

#!/usr/bin/env bash
set -euo pipefail

1. Read required env vars (error if missing):
   AWS_REGION, AWS_ACCOUNT_ID
   Derive ECR_REGISTRY="${AWS_ACCOUNT_ID}.dkr.ecr.${AWS_REGION}.amazonaws.com"

2. Authenticate Docker to ECR:
   aws ecr get-login-password --region $AWS_REGION | \
     docker login --username AWS --password-stdin $ECR_REGISTRY

3. Determine the repo root (script is in deploy/aws-ecs/, so
   REPO_ROOT is two directories up).

4. Build and push the adapter image:
   docker buildx build \
     --platform linux/amd64 \
     -t ${ECR_REGISTRY}/okta-mcp-adapter:latest \
     -f ${REPO_ROOT}/Dockerfile \
     --push \
     ${REPO_ROOT}
   Print: "✓ Adapter image pushed"

5. Build and push the admin UI image:
   docker buildx build \
     --platform linux/amd64 \
     -t ${ECR_REGISTRY}/okta-mcp-admin-ui:latest \
     -f ${REPO_ROOT}/okta_agent_proxy_admin_ui/Dockerfile \
     --push \
     ${REPO_ROOT}/okta_agent_proxy_admin_ui
   Print: "✓ Admin UI image pushed"

6. Build and push the hr-backend image:
   docker buildx build \
     --platform linux/amd64 \
     -t ${ECR_REGISTRY}/okta-mcp-hr-backend:latest \
     -f ${REPO_ROOT}/examples/01-hr-system/Dockerfile \
     --push \
     ${REPO_ROOT}/examples/01-hr-system
   Print: "✓ HR backend image pushed"

7. Print summary:
   ┌─────────────────────────────────────────┐
   │  Images pushed to ECR                   │
   │                                         │
   │  adapter:   <repo_url>:latest           │
   │  admin-ui:  <repo_url>:latest           │
   │  hr-backend:<repo_url>:latest           │
   └─────────────────────────────────────────┘

Make the script executable: chmod +x deploy/aws-ecs/build-images.sh

Also add a .dockerignore in deploy/aws-ecs/ if one doesn't exist
in the project root (check first — the root .dockerignore should
already cover what we need).
```

### Expected Output

`deploy/aws-ecs/build-images.sh` exists, is executable, and handles all three images with ECR authentication.

---

## Prompt E5: ECS Cluster + Task Definitions

### Context

Creates the ECS cluster with Fargate capacity providers, CloudWatch Container Insights enabled, and ECS Service Connect namespace. Then defines 3 task definitions: adapter, admin-ui, and hr-backend. Secrets are injected via `valueFrom` referencing Secrets Manager ARNs with JSON key paths. The adapter task definition includes all environment variables the adapter needs.

### Prompt

```
Add the ECS cluster and task definitions for the Okta MCP Adapter.

Read deploy/aws-ecs/main.tf and the root .env.example for the full
list of environment variables the adapter expects. Also read
deploy/bundle/docker-compose.bundle.yml for the container environment
mapping pattern.

Add to deploy/aws-ecs/main.tf:

1. ECS Cluster:
   - aws_ecs_cluster with name = "${local.project_name}-cluster"
   - setting: containerInsights = "enabled"
   - tags = local.common_tags

2. ECS Cluster Capacity Providers:
   - aws_ecs_cluster_capacity_providers attaching FARGATE and
     FARGATE_SPOT. Default strategy: FARGATE for demo,
     FARGATE_SPOT for small-prod (cost savings, acceptable
     for stateless workloads with retry).

3. CloudWatch Log Groups (3):
   - /ecs/${local.project_name}/adapter
   - /ecs/${local.project_name}/admin-ui
   - /ecs/${local.project_name}/hr-backend
   retention_in_days = 30, tags = local.common_tags

4. Service Connect namespace:
   - aws_service_discovery_private_dns_namespace
     name = "${local.project_name}.local"
     vpc = the VPC ID
   This gives us internal DNS: adapter.okta-mcp.local,
   hr-backend.okta-mcp.local, etc.

5. Task Definition — Adapter:
   - aws_ecs_task_definition "adapter" with:
     family = "${local.project_name}-adapter"
     requires_compatibilities = ["FARGATE"]
     network_mode = "awsvpc"
     cpu = 512, memory = 1024
     execution_role_arn = ecs_task_execution role
     task_role_arn = ecs_task role

   Container definition (JSON):
   - name = "adapter"
   - image = "${aws_ecr_repository.adapter.repository_url}:latest"
   - essential = true
   - portMappings: [{ containerPort: 8000, name: "adapter-http", protocol: "tcp" }]
   - healthCheck:
       command: ["CMD-SHELL", "curl -f http://localhost:8000/.well-known/oauth-protected-resource || exit 1"]
       interval: 30, timeout: 5, retries: 3, startPeriod: 30

   - environment (non-sensitive, hardcoded):
     GATEWAY_PORT = "8000"
     CACHE_PROVIDER = "redis"
     REDIS_KEY_PREFIX = "okta-mcp:"
     REDIS_TLS_ENABLED = "true"
     LOG_LEVEL = "INFO"
     LOG_FORMAT = "json"
     DEPLOYMENT_MODE = "standalone"
     CIMD_ENABLED = "true"
     CIMD_REQUIRE_HTTPS = "true"
     CIMD_TRUSTED_BACKEND_ACCESS = "hr-system,deploy-server"
     CIMD_UNKNOWN_BACKEND_ACCESS = "hr-system,deploy-server"
     PYTHONUNBUFFERED = "1"
     PYTHONDONTWRITEBYTECODE = "1"

   - secrets (from Secrets Manager, using JSON key paths):
     DATABASE_URL = "${secrets_db_arn}:DATABASE_URL::"
     REDIS_URL = "${secrets_redis_arn}:REDIS_URL::"
     REDIS_PASSWORD = "${secrets_redis_arn}:REDIS_PASSWORD::"
     OKTA_DOMAIN = "${secrets_okta_arn}:OKTA_DOMAIN::"
     OKTA_ISSUER = "${secrets_okta_arn}:OKTA_ISSUER::"
     OKTA_AUTHORIZATION_SERVER_ID = "${secrets_okta_arn}:OKTA_AUTHORIZATION_SERVER_ID::"
     RELAY_OKTA_CLIENT_ID = "${secrets_okta_arn}:RELAY_OKTA_CLIENT_ID::"
     RELAY_OKTA_CLIENT_SECRET = "${secrets_okta_arn}:RELAY_OKTA_CLIENT_SECRET::"
     ENCRYPTION_KEY = "${secrets_app_arn}:ENCRYPTION_KEY::"
     ADMIN_USERNAME = "${secrets_app_arn}:ADMIN_USERNAME::"
     ADMIN_PASSWORD = "${secrets_app_arn}:ADMIN_PASSWORD::"
     GATEWAY_BASE_URL = "${secrets_app_arn}:GATEWAY_BASE_URL::"

   - logConfiguration:
       logDriver = "awslogs"
       options:
         awslogs-group = the adapter log group
         awslogs-region = var.aws_region
         awslogs-stream-prefix = "adapter"

6. Task Definition — Admin UI:
   - family = "${local.project_name}-admin-ui"
   - cpu = 256, memory = 512
   - Container:
     name = "admin-ui"
     image = "${aws_ecr_repository.admin_ui.repository_url}:latest"
     portMappings: [{ containerPort: 3001, name: "admin-ui-http" }]
     environment:
       NEXT_PUBLIC_API_URL = "http://adapter.${local.project_name}.local:8000"
       API_URL = "http://adapter.${local.project_name}.local:8000"
       NEXT_PUBLIC_APP_NAME = "Okta MCP Adapter Admin"
       NODE_ENV = "production"
       PORT = "3001"
       HOSTNAME = "0.0.0.0"
       NEXTAUTH_URL = "https://${var.admin_hostname}"
       OKTA_DOMAIN = var.admin_ui_okta_domain
       OKTA_CLIENT_ID = var.admin_ui_okta_client_id
     secrets:
       NEXTAUTH_SECRET = "${secrets_app_arn}:ADMIN_UI_NEXTAUTH_SECRET::"
       OKTA_CLIENT_SECRET = "${secrets_app_arn}:ADMIN_UI_OKTA_CLIENT_SECRET::"
     healthCheck: ["CMD-SHELL", "wget --spider -q http://localhost:3001/ || exit 1"]
     logConfiguration: awslogs to the admin-ui log group

7. Task Definition — HR Backend:
   - family = "${local.project_name}-hr-backend"
   - cpu = 256, memory = 512
   - Container:
     name = "hr-backend"
     image = "${aws_ecr_repository.hr_backend.repository_url}:latest"
     portMappings: [{ containerPort: 8001, name: "hr-backend-http" }]
     environment:
       PORT = "8001"
       PSK_TOKEN = "demo-psk-token"  (hardcoded for demo — not
         production sensitive, the hr-backend is an example)
     healthCheck: ["CMD-SHELL", "curl -f http://localhost:8001/health || exit 1"]
     logConfiguration: awslogs to hr-backend log group

8. Run terraform fmt and terraform validate.

Do NOT apply.

IMPORTANT: When constructing the container definitions JSON, ensure
all secrets references use the correct Secrets Manager ARN format:
  "arn:aws:secretsmanager:REGION:ACCOUNT:secret:NAME-RANDOM:JSON_KEY::"
Terraform provides the full ARN from aws_secretsmanager_secret.X.arn
so use that directly with the JSON key path appended.
```

### Expected Output

ECS cluster, 3 log groups, Service Connect namespace, and 3 task definitions with proper secret injection. `terraform validate` passes.

---

## Prompt E6: ECS Services + ALB + DNS

### Context

Creates the Application Load Balancer with ACM certificate (DNS-validated via Route53), target groups, listener rules, and the 3 ECS services. The adapter service uses Service Connect so the admin UI and hr-backend can reach it via internal DNS. Route53 alias records point the custom hostnames to the ALB.

### Prompt

```
Add the ALB, ECS services, and DNS records for the Okta MCP Adapter.

Read deploy/aws-ecs/main.tf and add:

1. ACM Certificate:
   - aws_acm_certificate for both hostnames:
     domain_name = var.adapter_hostname
     subject_alternative_names = [var.admin_hostname]
     validation_method = "DNS"
     tags = local.common_tags
     lifecycle { create_before_destroy = true }

2. Route53 DNS validation records:
   - aws_route53_record for each domain_validation_option
     (use for_each on aws_acm_certificate.this.domain_validation_options)
   - aws_acm_certificate_validation that waits for the cert to be issued

3. Application Load Balancer:
   - aws_lb "main" with:
     name = "${local.project_name}-alb"
     internal = false
     load_balancer_type = "application"
     security_groups = [alb_sg.id]
     subnets = public subnet IDs
     enable_deletion_protection = false
     tags = local.common_tags

4. Target Groups:
   a. Adapter target group:
      - name = "${local.project_name}-adapter"
      - port = 8000, protocol = "HTTP", target_type = "ip"
      - vpc_id = VPC ID
      - health_check:
          path = "/.well-known/oauth-protected-resource"
          port = "traffic-port"
          healthy_threshold = 2, unhealthy_threshold = 3
          interval = 30, timeout = 5
      - deregistration_delay = 30

   b. Admin UI target group:
      - name = "${local.project_name}-admin-ui"
      - port = 3001, protocol = "HTTP", target_type = "ip"
      - health_check: path = "/", port = "traffic-port"
      - deregistration_delay = 30

5. ALB Listeners:
   a. HTTPS listener (port 443):
      - default_action: fixed-response 404 (no matching host header)
      - certificate_arn = the ACM cert
      - ssl_policy = "ELBSecurityPolicy-TLS13-1-2-2021-06"

   b. HTTP listener (port 80):
      - default_action: redirect to HTTPS (status 301)

6. Listener Rules:
   a. Adapter rule:
      - condition: host_header = [var.adapter_hostname]
      - action: forward to adapter target group
      - priority = 100

   b. Admin UI rule:
      - condition: host_header = [var.admin_hostname]
      - action: forward to admin-ui target group
      - priority = 200

7. ECS Service — Adapter:
   - aws_ecs_service "adapter" with:
     name = "adapter"
     cluster = cluster ARN
     task_definition = adapter task def ARN
     desired_count = local.adapter_desired_count
     launch_type = "FARGATE"
     platform_version = "LATEST"
     health_check_grace_period_seconds = 60

     network_configuration:
       subnets = private subnet IDs
       security_groups = [ecs_tasks_sg.id]
       assign_public_ip = false

     load_balancer:
       target_group_arn = adapter TG ARN
       container_name = "adapter"
       container_port = 8000

     service_connect_configuration:
       enabled = true
       namespace = service discovery namespace ARN
       service:
         port_name = "adapter-http"  (must match portMappings name
           in the adapter task def from E5)
         discovery_name = "adapter"
         client_alias:
           port = 8000
           dns_name = "adapter.${local.project_name}.local"

     deployment_circuit_breaker:
       enable = true
       rollback = true

     force_new_deployment = true

   For small-prod, also create:
   - aws_appautoscaling_target for ECS service
     min_capacity = 2, max_capacity = 4
   - aws_appautoscaling_policy target tracking on
     ECSServiceAverageCPUUtilization = 70
   Use count = var.deployment_size == "small-prod" ? 1 : 0

8. ECS Service — Admin UI:
   - desired_count = 1
   - network_configuration same as adapter
   - load_balancer pointing to admin-ui TG, port 3001
   - service_connect: enabled = true, namespace = namespace ARN
     No service block needed (admin UI consumes adapter, not the
     other way around).
   - deployment_circuit_breaker enabled

9. ECS Service — HR Backend:
   - desired_count = 1
   - No load_balancer (not internet-facing)
   - service_connect: enabled, advertise as "hr-backend" on port 8001
     so the adapter can reach hr-backend.okta-mcp.local:8001
     service:
       port_name = "hr-backend-http"
       discovery_name = "hr-backend"
       client_alias:
         port = 8001
         dns_name = "hr-backend.${local.project_name}.local"

10. Route53 alias records:
    a. aws_route53_record for var.adapter_hostname:
       type = "A", alias to ALB DNS name and zone ID
    b. aws_route53_record for var.admin_hostname:
       type = "A", alias to ALB DNS name and zone ID

11. Add outputs:
    - alb_dns_name
    - adapter_url = "https://${var.adapter_hostname}"
    - admin_url = "https://${var.admin_hostname}"
    - acm_certificate_arn

12. Run terraform fmt and terraform validate.

Do NOT apply.
```

### Expected Output

ALB with ACM cert, 2 target groups, 2 listener rules, 3 ECS services (adapter with Service Connect + auto-scaling for small-prod, admin-ui with ALB, hr-backend with Service Connect only), Route53 records. `terraform validate` passes.

---

## Prompt E7: Smoke Tests + Stop/Start Scripts

### Context

Creates operational scripts the SE runs after deployment. The smoke test script validates the full deployment is healthy. The stop/start scripts minimize cost between demos by scaling ECS services to zero and stopping RDS (ElastiCache stays running to avoid data loss). The start script reverses the process.

### Prompt

```
Create operational scripts for the ECS deployment: smoke tests,
stop, and start.

Read deploy/aws-ec2/awsetup.sh for the verification pattern
(the Phase 3 verification section) and the existing teardown.sh
for cleanup patterns.

1. Create deploy/aws-ecs/smoke-test.sh:

#!/usr/bin/env bash
set -euo pipefail

Read ADAPTER_HOSTNAME and ADMIN_HOSTNAME from env vars
TF_VAR_adapter_hostname and TF_VAR_admin_hostname.
Fallback: read from terraform output in the deploy/aws-ecs/ dir.

Run 5 tests, print pass/fail for each:

Test 1: Adapter health
  curl -sf https://${ADAPTER_HOSTNAME}/.well-known/oauth-protected-resource
  Expect: HTTP 200 with JSON containing "resource"

Test 2: Adapter /health
  curl -sf https://${ADAPTER_HOSTNAME}/health
  Expect: HTTP 200

Test 3: Admin UI reachable
  curl -sf -o /dev/null -w "%{http_code}" https://${ADMIN_HOSTNAME}/
  Expect: HTTP 200 or 302 (redirect to Okta login)

Test 4: TLS certificate valid
  echo | openssl s_client -connect ${ADAPTER_HOSTNAME}:443 \
    -servername ${ADAPTER_HOSTNAME} 2>/dev/null | \
    openssl x509 -noout -dates
  Expect: exit 0 (cert is parseable and not expired)

Test 5: Service Connect — adapter can reach hr-backend (indirect)
  curl -sf https://${ADAPTER_HOSTNAME}/admin/resources
  Expect: HTTP 200 or 401 (confirms adapter is processing requests,
  not a connection timeout)

Print summary:
  ✓ 5/5 tests passed — deployment is healthy
  or
  ✗ N/5 tests passed — check CloudWatch logs

2. Create deploy/aws-ecs/stop.sh:

#!/usr/bin/env bash
set -euo pipefail

Read AWS_REGION from env or default to us-east-1.
Derive cluster name and RDS instance identifier from the
project naming convention (okta-mcp-cluster, okta-mcp-db).

Steps:
a. Scale all ECS services to 0:
   for svc in adapter admin-ui hr-backend; do
     aws ecs update-service --cluster okta-mcp-cluster \
       --service $svc --desired-count 0 --region $AWS_REGION \
       --no-cli-pager
   done
   echo "✓ ECS services scaled to 0"

b. Stop RDS instance:
   aws rds stop-db-instance \
     --db-instance-identifier okta-mcp-db --region $AWS_REGION \
     --no-cli-pager 2>/dev/null || echo "RDS may already be stopped"
   echo "✓ RDS instance stopping (takes ~5 min)"
   echo "⚠ RDS auto-restarts after 7 days. Re-run stop.sh if needed."

c. Print cost estimate while stopped:
   echo ""
   echo "┌────────────────────────────────────────┐"
   echo "│  Monthly cost while stopped: ~\$15-20   │"
   echo "│                                        │"
   echo "│  ALB:          ~\$18 (fixed charge)     │"
   echo "│  ElastiCache:  ~\$0-15 (depends)        │"
   echo "│  RDS storage:  ~\$3                     │"
   echo "│  ECR:          ~\$1                     │"
   echo "│                                        │"
   echo "│  Restart: ./start.sh                   │"
   echo "└────────────────────────────────────────┘"

3. Create deploy/aws-ecs/start.sh:

#!/usr/bin/env bash
set -euo pipefail

Read same vars as stop.sh.

Steps:
a. Start RDS instance:
   aws rds start-db-instance \
     --db-instance-identifier okta-mcp-db --region $AWS_REGION \
     --no-cli-pager
   echo "Starting RDS instance (takes ~5 min)..."

   Wait for RDS to be available:
   aws rds wait db-instance-available \
     --db-instance-identifier okta-mcp-db --region $AWS_REGION
   echo "✓ RDS instance available"

b. Scale ECS services back up:
   ADAPTER_COUNT="${ADAPTER_COUNT:-1}"
   aws ecs update-service --cluster okta-mcp-cluster \
     --service adapter --desired-count $ADAPTER_COUNT \
     --region $AWS_REGION --no-cli-pager
   aws ecs update-service --cluster okta-mcp-cluster \
     --service admin-ui --desired-count 1 \
     --region $AWS_REGION --no-cli-pager
   aws ecs update-service --cluster okta-mcp-cluster \
     --service hr-backend --desired-count 1 \
     --region $AWS_REGION --no-cli-pager
   echo "✓ ECS services scaling up"

c. Wait for services to stabilize:
   aws ecs wait services-stable --cluster okta-mcp-cluster \
     --services adapter admin-ui hr-backend --region $AWS_REGION
   echo "✓ All services stable"

d. Run smoke tests:
   echo ""
   echo "Running smoke tests..."
   bash "$(dirname "$0")/smoke-test.sh"

Make all three scripts executable: chmod +x deploy/aws-ecs/*.sh
```

### Expected Output

Three executable scripts in `deploy/aws-ecs/`: `smoke-test.sh`, `stop.sh`, `start.sh`. Each handles error cases and prints clear status.

---

## Prompt E8: Terraform Wrapper + deploy.sh + README

### Context

Wraps all Terraform resources into a clean deployment experience. The `deploy.sh` script auto-generates `ENCRYPTION_KEY` and `ADMIN_PASSWORD` if not set, runs `terraform init/apply`, and prints a summary box with URLs, cost reminder, and teardown hint. The README covers prerequisites, quick start, cost expectations, and troubleshooting.

### Prompt

```
Create the deploy.sh wrapper and README for the ECS deployment.

Read deploy/gcp/deploy.sh for the interface contract (--apply,
--destroy, --plan) and the summary box format. Also read
deploy/aws-ec2/README.md for the documentation style.

1. Create deploy/aws-ecs/deploy.sh:

#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
cd "$SCRIPT_DIR"

Parse arguments:
  --apply       Run terraform init + apply (default if no args)
  --plan        Run terraform init + plan
  --destroy     Run terraform destroy
  --use-codebuild  Set flag for E9's CodeBuild image build path
  -h|--help     Print usage

Pre-flight checks:
  - aws sts get-caller-identity succeeds (print account ID)
  - terraform version >= 1.6
  - Docker available (unless --use-codebuild), warn but don't fail
    if not available and --use-codebuild not set
  - Required TF_VAR_ env vars present: okta_domain, okta_issuer,
    adapter_hostname, admin_hostname, route53_zone_id

Auto-generate if not set:
  - TF_VAR_encryption_key: openssl rand -base64 32
  - TF_VAR_admin_password: openssl rand -base64 24 | tr -d '/+=' | head -c 24
  - AWS_ACCOUNT_ID: derive from aws sts get-caller-identity
  Print: "Auto-generated ENCRYPTION_KEY and ADMIN_PASSWORD"
  Save them to a local .generated-secrets file (gitignored) so
  stop/start/re-apply can re-read them.

For --apply:
  a. terraform init -upgrade
  b. terraform plan -out=tfplan
  c. Prompt: "Apply this plan? [y/N]"
     If not confirmed, exit 0.
  d. terraform apply tfplan
  e. Build and push images:
     If --use-codebuild flag set:
       echo "Building images via CodeBuild..."
       bash "$SCRIPT_DIR/build-codebuild.sh"
     Else:
       bash "$SCRIPT_DIR/build-images.sh"
  f. Force new deployment on ECS services (to pull latest images):
     for svc in adapter admin-ui hr-backend; do
       aws ecs update-service --cluster okta-mcp-cluster \
         --service $svc --force-new-deployment \
         --region ${AWS_REGION:-us-east-1} --no-cli-pager
     done
  g. Wait for services to stabilize (timeout 10 min):
     aws ecs wait services-stable --cluster okta-mcp-cluster \
       --services adapter admin-ui hr-backend \
       --region ${AWS_REGION:-us-east-1}
  h. Run smoke tests:
     bash "$SCRIPT_DIR/smoke-test.sh" || true
  i. Print summary box:

  ┌──────────────────────────────────────────────────────────┐
  │  Okta MCP Adapter — ECS Fargate Deployment              │
  │                                                         │
  │  Adapter:   https://<adapter_hostname>                  │
  │  Admin UI:  https://<admin_hostname>                    │
  │  Profile:   A (Standalone)                              │
  │  Size:      <demo|small-prod>                           │
  │                                                         │
  │  Admin credentials:                                     │
  │    Username: <admin_username>                            │
  │    Password: <admin_password>                            │
  │                                                         │
  │  Cost: ~$90-120/mo (demo) or ~$200-250/mo (small-prod)  │
  │  Stop between demos: ./stop.sh (~$15-20/mo idle)        │
  │  Teardown: ./deploy.sh --destroy                        │
  │                                                         │
  │  ⚠ Update Okta redirect URIs to:                       │
  │    Adapter: https://<adapter_hostname>/oauth/callback    │
  │    Admin:   https://<admin_hostname>/api/auth/callback/okta │
  └──────────────────────────────────────────────────────────┘

For --destroy:
  a. Confirm: "Destroy all ECS resources? This is irreversible. [y/N]"
  b. terraform destroy -auto-approve
  c. Clean up .generated-secrets
  d. Print: "All resources destroyed."

For --plan:
  a. terraform init -upgrade
  b. terraform plan

Make deploy.sh executable.

2. Add .gitignore in deploy/aws-ecs/:
   .terraform/
   .terraform.lock.hcl
   *.tfstate
   *.tfstate.backup
   tfplan
   .generated-secrets

3. Create deploy/aws-ecs/README.md with these sections:

   # AWS ECS Fargate Deployment

   ## Overview
   (paragraph: what this deploys, Profile A standalone, two sizes)

   ## Architecture
   VPC → 2 public subnets (ALB) + 2 private subnets (ECS, RDS, Redis)
   → NAT GW for outbound → ALB with ACM cert → ECS Fargate tasks
   → Service Connect for east-west → RDS + ElastiCache in private subnets

   ## Prerequisites
   (AWS CLI, Terraform, Docker, Okta org, Route53 zone)

   ## Quick Start
   ```bash
   export AWS_REGION="us-east-1"
   export TF_VAR_okta_domain="..."
   # ... (all required vars from the Prerequisites section above)
   ./deploy.sh --apply
   ```

   ## Deployment Sizes
   (table: demo vs small-prod comparison)

   ## Cost Breakdown
   (table matching discussion document costs)

   ## ElastiCache Options
   instance (default) vs serverless
   Set: export TF_VAR_cache_type="serverless"

   ## Building Without Docker (CodeBuild)
   export TF_VAR_enable_codebuild=true
   ./deploy.sh --apply --use-codebuild

   ## Stop/Start for Cost Savings
   ./stop.sh  →  ~$15-20/mo idle
   ./start.sh →  back up in ~5 min

   ## Okta Redirect URIs
   After deployment, update Okta OIDC apps with the URLs
   printed in the deploy summary box.

   ## Troubleshooting
   - ECS tasks failing: check CloudWatch log groups
     /ecs/okta-mcp/adapter, /ecs/okta-mcp/admin-ui
   - ACM cert pending: verify Route53 CNAME validation records
   - Adapter can't reach RDS/Redis: check security group rules
   - "exec format error": rebuild with --platform linux/amd64
   - RDS auto-restarted: re-run stop.sh (7-day AWS limit)
   - Service Connect DNS not resolving: verify namespace and
     service registration in ECS console
   - Secrets Manager permission denied: verify task execution
     role has secretsmanager:GetSecretValue on all 4 secrets

   ## Teardown
   ./deploy.sh --destroy  (~10 min, fully cleans up)

Run terraform fmt on any modified .tf files.
```

### Expected Output

`deploy/aws-ecs/deploy.sh` (executable) with `--apply`, `--destroy`, `--plan` interface. `deploy/aws-ecs/README.md` with complete documentation. `deploy/aws-ecs/.gitignore` for Terraform state files.

---

## Prompt E9: CodeBuild Fallback for Image Builds

### Context

Some customers cannot run Docker locally (corporate laptops, security policies). This prompt adds a CodeBuild project that builds all three images server-side on AWS, pushing to the same ECR repos. The `deploy.sh --use-codebuild` flag triggers this path instead of local Docker builds.

### Prompt

```
Add a CodeBuild fallback for image builds in the ECS deployment.

Read deploy/aws-ecs/build-images.sh for the images that need to be
built, and deploy/aws-ecs/deploy.sh for the --use-codebuild flag.

1. Add to deploy/aws-ecs/main.tf:

   Variable:
   - enable_codebuild (type = bool, default = false,
     description = "Provision CodeBuild project for server-side
     image builds. Use when Docker is not available locally.")

   S3 bucket for CodeBuild source:
   - aws_s3_bucket "codebuild_source" with:
     bucket = "${local.project_name}-codebuild-${data.aws_caller_identity.current.account_id}"
     force_destroy = true
     count = var.enable_codebuild ? 1 : 0
     tags = local.common_tags

   - aws_s3_bucket_versioning on the bucket (enabled)

   CodeBuild IAM role:
   - aws_iam_role "codebuild" with assume_role_policy for
     codebuild.amazonaws.com
   - count = var.enable_codebuild ? 1 : 0
   - Inline policy with:
     ecr:GetAuthorizationToken (resource: "*")
     ecr:BatchCheckLayerAvailability, ecr:PutImage,
     ecr:InitiateLayerUpload, ecr:UploadLayerPart,
     ecr:CompleteLayerUpload, ecr:BatchGetImage,
     ecr:GetDownloadUrlForLayer on the 3 ECR repo ARNs
     logs:CreateLogGroup, logs:CreateLogStream, logs:PutLogEvents
     on "arn:aws:logs:${var.aws_region}:${data.aws_caller_identity.current.account_id}:log-group:/codebuild/${local.project_name}*"
     s3:GetObject, s3:GetBucketLocation on the source bucket ARN/*

   CodeBuild project:
   - aws_codebuild_project "image_builder" with:
     count = var.enable_codebuild ? 1 : 0
     name = "${local.project_name}-image-builder"
     service_role = codebuild role ARN
     source:
       type = "S3"
       location = "${aws_s3_bucket.codebuild_source[0].id}/source.zip"
       buildspec = file("${path.module}/buildspec.yml")
     environment:
       compute_type = "BUILD_GENERAL1_SMALL"
       image = "aws/codebuild/amazonlinux2-x86_64-standard:5.0"
       type = "LINUX_CONTAINER"
       privileged_mode = true  (required for Docker builds)
       environment_variable:
         AWS_ACCOUNT_ID = data.aws_caller_identity.current.account_id
         AWS_DEFAULT_REGION = var.aws_region
         ECR_ADAPTER_REPO = aws_ecr_repository.adapter.repository_url
         ECR_ADMIN_UI_REPO = aws_ecr_repository.admin_ui.repository_url
         ECR_HR_BACKEND_REPO = aws_ecr_repository.hr_backend.repository_url
     artifacts: type = "NO_ARTIFACTS"
     logs_config:
       cloudwatch_logs:
         group_name = "/codebuild/${local.project_name}"
         stream_name = "image-build"
     tags = local.common_tags

2. Create deploy/aws-ecs/buildspec.yml:

   version: 0.2
   phases:
     pre_build:
       commands:
         - echo Logging in to ECR...
         - aws ecr get-login-password --region $AWS_DEFAULT_REGION |
           docker login --username AWS --password-stdin
           $AWS_ACCOUNT_ID.dkr.ecr.$AWS_DEFAULT_REGION.amazonaws.com
     build:
       commands:
         - echo Building adapter image...
         - docker build -t $ECR_ADAPTER_REPO:latest -f Dockerfile .
         - echo Building admin-ui image...
         - docker build -t $ECR_ADMIN_UI_REPO:latest
           -f okta_agent_proxy_admin_ui/Dockerfile
           okta_agent_proxy_admin_ui/
         - echo Building hr-backend image...
         - docker build -t $ECR_HR_BACKEND_REPO:latest
           -f examples/01-hr-system/Dockerfile
           examples/01-hr-system/
     post_build:
       commands:
         - echo Pushing images to ECR...
         - docker push $ECR_ADAPTER_REPO:latest
         - docker push $ECR_ADMIN_UI_REPO:latest
         - docker push $ECR_HR_BACKEND_REPO:latest
         - echo "✓ All images pushed successfully"

3. Create deploy/aws-ecs/build-codebuild.sh:

#!/usr/bin/env bash
set -euo pipefail

# Packages the source, uploads to S3, triggers CodeBuild, waits.

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
REPO_ROOT="$(cd "$SCRIPT_DIR/../.." && pwd)"

AWS_REGION="${AWS_REGION:-us-east-1}"
PROJECT_NAME="okta-mcp"
ACCOUNT_ID=$(aws sts get-caller-identity --query Account --output text)
S3_BUCKET="${PROJECT_NAME}-codebuild-${ACCOUNT_ID}"
CODEBUILD_PROJECT="${PROJECT_NAME}-image-builder"

# Package source for CodeBuild
echo "Packaging source for CodeBuild..."
TMPDIR=$(mktemp -d)
trap "rm -rf $TMPDIR" EXIT

cd "$REPO_ROOT"
zip -rq "$TMPDIR/source.zip" \
  Dockerfile .dockerignore requirements.txt pyproject.toml \
  alembic.ini alembic/ \
  okta_agent_proxy/ \
  okta_agent_proxy_admin_ui/ \
  examples/01-hr-system/ \
  scripts/ \
  -x "*.pyc" "__pycache__/*" "node_modules/*" \
     ".git/*" "tests/*" ".claude/*" "*.md"

echo "Uploading source to S3..."
aws s3 cp "$TMPDIR/source.zip" "s3://${S3_BUCKET}/source.zip" \
  --region "$AWS_REGION" --quiet

echo "Starting CodeBuild..."
BUILD_ID=$(aws codebuild start-build \
  --project-name "$CODEBUILD_PROJECT" \
  --region "$AWS_REGION" \
  --query 'build.id' --output text)

echo "Build ID: $BUILD_ID"
echo "Waiting for build to complete (typically 5-10 min)..."

# Poll until complete
while true; do
  STATUS=$(aws codebuild batch-get-builds --ids "$BUILD_ID" \
    --region "$AWS_REGION" \
    --query 'builds[0].buildStatus' --output text)
  case "$STATUS" in
    SUCCEEDED)
      echo "✓ CodeBuild completed successfully"
      break ;;
    FAILED|FAULT|TIMED_OUT|STOPPED)
      echo "✗ CodeBuild failed: $STATUS"
      echo "View logs:"
      echo "  aws codebuild batch-get-builds --ids $BUILD_ID --region $AWS_REGION"
      echo "  aws logs tail /codebuild/${PROJECT_NAME} --region $AWS_REGION"
      exit 1 ;;
    *)
      printf "\r  Status: %-20s" "$STATUS"
      sleep 10 ;;
  esac
done

Make build-codebuild.sh executable: chmod +x deploy/aws-ecs/build-codebuild.sh

4. Update deploy/aws-ecs/deploy.sh:
   In the image build section after terraform apply, add:
   if [[ "${USE_CODEBUILD:-false}" == "true" ]]; then
     # Ensure CodeBuild resources exist
     if ! terraform output -raw codebuild_project_name 2>/dev/null; then
       echo "CodeBuild not provisioned. Re-applying with enable_codebuild=true..."
       export TF_VAR_enable_codebuild=true
       terraform apply -auto-approve
     fi
     bash "$SCRIPT_DIR/build-codebuild.sh"
   else
     bash "$SCRIPT_DIR/build-images.sh"
   fi

5. Add outputs (conditional):
   - codebuild_project_name (count-gated)
   - codebuild_source_bucket (count-gated)

6. Update README.md — add under "Building Without Docker":

   ## Building Without Docker (CodeBuild)

   If Docker is not available on your machine (corporate policy,
   no admin access, etc.), use AWS CodeBuild for server-side builds:

   ```bash
   export TF_VAR_enable_codebuild=true
   ./deploy.sh --apply --use-codebuild
   ```

   This provisions:
   - An S3 bucket for source upload (~$0.02/GB)
   - A CodeBuild project (~$0.005/build-minute, typically 5-10 min)

   Subsequent image rebuilds:
   ```bash
   ./build-codebuild.sh
   ```

7. Run terraform fmt and terraform validate.

Do NOT apply.
```

### Expected Output

CodeBuild project (conditional on `enable_codebuild`), S3 source bucket, `buildspec.yml`, `build-codebuild.sh`, updated `deploy.sh` with `--use-codebuild` path, updated README. `terraform validate` passes.

---

## Prompt E10: IAM Prerequisites & Operator Permissions Documentation

### Context

The ECS deployment creates IAM roles at Terraform apply time (ECS task execution role, ECS task role, CodeBuild role), but the **operator running `deploy.sh`** needs their own IAM permissions to create those roles and all the other AWS resources. In enterprise environments, the operator typically has a scoped developer role — not administrator — and the AWS administrator must explicitly grant additional permissions before deployment succeeds.

This prompt generates:

1. A concrete **minimum-scope IAM policy** (`operator-policy.json`) that an AWS administrator attaches to the operator's IAM user or role
2. An **administrator-facing README** covering operator policy attachment, SCP conflicts, permission boundaries, and the assume-role pattern common in regulated organizations
3. An updated **main README** with a prominent "For AWS Administrators" section
4. A **pre-flight IAM probe** in `deploy.sh` that fails fast with actionable errors if permissions are missing

### Prompt

```
Document the IAM prerequisites for the Okta MCP Adapter ECS deployment
and add operator pre-flight permission checks.

Read deploy/aws-ecs/main.tf to enumerate every AWS service and resource
type the Terraform creates. Also read deploy/aws-ecs/deploy.sh to add
the pre-flight probe.

1. Create deploy/aws-ecs/iam/operator-policy.json:

   This is the minimum-scope IAM policy an AWS administrator attaches
   to the operator's IAM user/role to enable terraform apply AND
   terraform destroy. It must cover every resource type in main.tf.

   Structure the policy as separate statements grouped by service.
   Use Resource ARN scoping where AWS supports it; use Resource: "*"
   only where the service requires it (VPC-level resources, ECR
   GetAuthorizationToken, STS GetCallerIdentity).

   Include statements for:

   a. EC2 / VPC (Resource: "*" — VPC resources don't support ARN-level
      permissions on create):
      ec2:CreateVpc, ec2:DeleteVpc, ec2:DescribeVpcs, ec2:ModifyVpcAttribute
      ec2:CreateSubnet, ec2:DeleteSubnet, ec2:DescribeSubnets,
        ec2:ModifySubnetAttribute
      ec2:CreateInternetGateway, ec2:DeleteInternetGateway,
        ec2:AttachInternetGateway, ec2:DetachInternetGateway,
        ec2:DescribeInternetGateways
      ec2:AllocateAddress, ec2:ReleaseAddress, ec2:DescribeAddresses
      ec2:CreateNatGateway, ec2:DeleteNatGateway, ec2:DescribeNatGateways
      ec2:CreateRouteTable, ec2:DeleteRouteTable, ec2:DescribeRouteTables,
        ec2:CreateRoute, ec2:DeleteRoute, ec2:AssociateRouteTable,
        ec2:DisassociateRouteTable
      ec2:CreateSecurityGroup, ec2:DeleteSecurityGroup,
        ec2:DescribeSecurityGroups, ec2:AuthorizeSecurityGroupIngress,
        ec2:AuthorizeSecurityGroupEgress, ec2:RevokeSecurityGroupIngress,
        ec2:RevokeSecurityGroupEgress
      ec2:CreateTags, ec2:DeleteTags, ec2:DescribeTags
      ec2:DescribeAvailabilityZones, ec2:DescribeAccountAttributes

   b. ECR — scope to repo name pattern okta-mcp-*:
      ecr:CreateRepository, ecr:DeleteRepository, ecr:DescribeRepositories,
        ecr:TagResource, ecr:UntagResource, ecr:ListTagsForResource
        on arn:aws:ecr:*:*:repository/okta-mcp-*
      ecr:PutLifecyclePolicy, ecr:DeleteLifecyclePolicy,
        ecr:GetLifecyclePolicy
        on arn:aws:ecr:*:*:repository/okta-mcp-*
      ecr:PutImageScanningConfiguration, ecr:PutImageTagMutability
        on arn:aws:ecr:*:*:repository/okta-mcp-*
      ecr:GetAuthorizationToken on Resource: "*"
      ecr:BatchCheckLayerAvailability, ecr:PutImage,
        ecr:InitiateLayerUpload, ecr:UploadLayerPart,
        ecr:CompleteLayerUpload, ecr:BatchGetImage,
        ecr:GetDownloadUrlForLayer
        on arn:aws:ecr:*:*:repository/okta-mcp-*
      (Image push perms are only needed for the operator if NOT using
      CodeBuild. Include them by default; scoped to okta-mcp-* repos.)

   c. RDS — scope to db-name pattern okta-mcp*:
      rds:CreateDBInstance, rds:DeleteDBInstance, rds:DescribeDBInstances,
        rds:ModifyDBInstance, rds:StopDBInstance, rds:StartDBInstance
        on arn:aws:rds:*:*:db:okta-mcp*
      rds:CreateDBSubnetGroup, rds:DeleteDBSubnetGroup,
        rds:DescribeDBSubnetGroups, rds:ModifyDBSubnetGroup
        on arn:aws:rds:*:*:subgrp:okta-mcp*
      rds:AddTagsToResource, rds:RemoveTagsFromResource,
        rds:ListTagsForResource on arn:aws:rds:*:*:db:okta-mcp*
        and arn:aws:rds:*:*:subgrp:okta-mcp*
      rds:DescribeDBParameters, rds:DescribeDBParameterGroups,
        rds:DescribeEngineDefaultParameters on Resource: "*"

   d. ElastiCache — scope to replication-group and serverless names:
      elasticache:CreateReplicationGroup, elasticache:DeleteReplicationGroup,
        elasticache:DescribeReplicationGroups, elasticache:ModifyReplicationGroup
        on arn:aws:elasticache:*:*:replicationgroup:okta-mcp*
      elasticache:CreateCacheSubnetGroup, elasticache:DeleteCacheSubnetGroup,
        elasticache:DescribeCacheSubnetGroups
        on arn:aws:elasticache:*:*:subnetgroup:okta-mcp*
      elasticache:CreateServerlessCache, elasticache:DeleteServerlessCache,
        elasticache:DescribeServerlessCaches
        on arn:aws:elasticache:*:*:serverlesscache:okta-mcp*
      elasticache:AddTagsToResource, elasticache:RemoveTagsFromResource,
        elasticache:ListTagsForResource on the above ARNs
      elasticache:DescribeCacheClusters on Resource: "*"

   e. ECS — scope to cluster/service/task-def names okta-mcp*:
      ecs:CreateCluster, ecs:DeleteCluster, ecs:DescribeClusters,
        ecs:PutClusterCapacityProviders, ecs:UpdateCluster,
        ecs:TagResource, ecs:UntagResource
        on arn:aws:ecs:*:*:cluster/okta-mcp*
      ecs:CreateService, ecs:UpdateService, ecs:DeleteService,
        ecs:DescribeServices
        on arn:aws:ecs:*:*:service/okta-mcp*/*
      ecs:RegisterTaskDefinition, ecs:DeregisterTaskDefinition,
        ecs:DescribeTaskDefinition, ecs:ListTaskDefinitions
        on Resource: "*"  (task def ARNs are version-scoped, hard to pin)

   f. ELB v2 — scope to LB/TG names okta-mcp*:
      elasticloadbalancing:CreateLoadBalancer, elasticloadbalancing:DeleteLoadBalancer,
        elasticloadbalancing:DescribeLoadBalancers,
        elasticloadbalancing:ModifyLoadBalancerAttributes
        on arn:aws:elasticloadbalancing:*:*:loadbalancer/app/okta-mcp*/*
      elasticloadbalancing:CreateTargetGroup, elasticloadbalancing:DeleteTargetGroup,
        elasticloadbalancing:DescribeTargetGroups,
        elasticloadbalancing:ModifyTargetGroup, elasticloadbalancing:ModifyTargetGroupAttributes
        on arn:aws:elasticloadbalancing:*:*:targetgroup/okta-mcp*/*
      elasticloadbalancing:CreateListener, elasticloadbalancing:DeleteListener,
        elasticloadbalancing:DescribeListeners, elasticloadbalancing:ModifyListener,
        elasticloadbalancing:CreateRule, elasticloadbalancing:DeleteRule,
        elasticloadbalancing:DescribeRules, elasticloadbalancing:ModifyRule
        on arn:aws:elasticloadbalancing:*:*:listener/*/okta-mcp*/*/*
        and arn:aws:elasticloadbalancing:*:*:listener-rule/*/okta-mcp*/*/*/*
      elasticloadbalancing:AddTags, elasticloadbalancing:RemoveTags,
        elasticloadbalancing:DescribeTags on the above ARNs
      elasticloadbalancing:DescribeAccountLimits,
        elasticloadbalancing:DescribeSSLPolicies on Resource: "*"

   g. ACM — must be Resource: "*" because certificate ARNs are only
      known post-creation:
      acm:RequestCertificate, acm:DeleteCertificate, acm:DescribeCertificate,
        acm:ListCertificates, acm:AddTagsToCertificate,
        acm:RemoveTagsFromCertificate, acm:ListTagsForCertificate

   h. Route53 — scope to the hosted zone ID the operator provides:
      IMPORTANT: The zone ID is provided via TF_VAR_route53_zone_id.
      Generate the policy with a placeholder "<ROUTE53_ZONE_ID>" and
      document in iam/README.md that the admin must replace it with
      the actual zone ID (or use "*" if the admin is willing to grant
      access to all hosted zones).

      route53:ChangeResourceRecordSets, route53:GetChange,
        route53:ListResourceRecordSets
        on arn:aws:route53:::hostedzone/<ROUTE53_ZONE_ID>
      route53:ListHostedZones on Resource: "*"

   i. Secrets Manager — scope to secret name pattern okta-mcp/*:
      secretsmanager:CreateSecret, secretsmanager:DeleteSecret,
        secretsmanager:DescribeSecret, secretsmanager:GetSecretValue,
        secretsmanager:PutSecretValue, secretsmanager:UpdateSecret,
        secretsmanager:TagResource, secretsmanager:UntagResource
        on arn:aws:secretsmanager:*:*:secret:okta-mcp/*
      secretsmanager:ListSecrets on Resource: "*"

   j. IAM — scope to role name pattern okta-mcp*:
      iam:CreateRole, iam:DeleteRole, iam:GetRole, iam:UpdateRole,
        iam:UpdateAssumeRolePolicy, iam:TagRole, iam:UntagRole,
        iam:ListRoleTags
        on arn:aws:iam::*:role/okta-mcp*
      iam:PutRolePolicy, iam:DeleteRolePolicy, iam:GetRolePolicy,
        iam:ListRolePolicies
        on arn:aws:iam::*:role/okta-mcp*
      iam:AttachRolePolicy, iam:DetachRolePolicy, iam:ListAttachedRolePolicies
        on arn:aws:iam::*:role/okta-mcp*
      iam:PassRole on arn:aws:iam::*:role/okta-mcp* with a condition:
        StringEquals { iam:PassedToService:
          [ecs-tasks.amazonaws.com, codebuild.amazonaws.com] }
      iam:ListPolicies, iam:GetPolicy, iam:GetPolicyVersion
        on Resource: "*" (for AWS managed policies like
        AmazonECSTaskExecutionRolePolicy)

   k. CloudWatch Logs — scope to log group name patterns:
      logs:CreateLogGroup, logs:DeleteLogGroup, logs:DescribeLogGroups,
        logs:PutRetentionPolicy, logs:DeleteRetentionPolicy,
        logs:TagLogGroup, logs:UntagLogGroup, logs:ListTagsForResource,
        logs:TagResource, logs:UntagResource
        on arn:aws:logs:*:*:log-group:/ecs/okta-mcp/*
        and arn:aws:logs:*:*:log-group:/codebuild/okta-mcp*

   l. Application Auto Scaling (for small-prod):
      application-autoscaling:RegisterScalableTarget,
        application-autoscaling:DeregisterScalableTarget,
        application-autoscaling:DescribeScalableTargets,
        application-autoscaling:PutScalingPolicy,
        application-autoscaling:DeleteScalingPolicy,
        application-autoscaling:DescribeScalingPolicies,
        application-autoscaling:TagResource, application-autoscaling:UntagResource
        on Resource: "*"  (service doesn't support ARN-level scoping
        for most actions)

   m. Service Discovery / Cloud Map:
      servicediscovery:CreatePrivateDnsNamespace,
        servicediscovery:DeleteNamespace, servicediscovery:GetNamespace,
        servicediscovery:ListNamespaces, servicediscovery:GetOperation,
        servicediscovery:TagResource, servicediscovery:UntagResource
        on Resource: "*"
      servicediscovery:CreateService, servicediscovery:DeleteService,
        servicediscovery:GetService, servicediscovery:ListServices,
        servicediscovery:UpdateService on Resource: "*"

   n. S3 + CodeBuild (only if enable_codebuild = true):
      Add a comment in the policy indicating these are optional.
      s3:CreateBucket, s3:DeleteBucket, s3:ListBucket, s3:GetBucketLocation,
        s3:PutBucketVersioning, s3:GetBucketVersioning,
        s3:PutBucketTagging, s3:GetBucketTagging, s3:PutBucketPolicy,
        s3:GetBucketPolicy, s3:DeleteBucketPolicy,
        s3:PutBucketPublicAccessBlock, s3:GetBucketPublicAccessBlock
        on arn:aws:s3:::okta-mcp-codebuild-*
      s3:PutObject, s3:GetObject, s3:DeleteObject
        on arn:aws:s3:::okta-mcp-codebuild-*/*
      codebuild:CreateProject, codebuild:DeleteProject,
        codebuild:UpdateProject, codebuild:BatchGetProjects,
        codebuild:ListProjects, codebuild:StartBuild,
        codebuild:BatchGetBuilds, codebuild:StopBuild
        on arn:aws:codebuild:*:*:project/okta-mcp*

   o. STS (always required):
      sts:GetCallerIdentity on Resource: "*"

   Wrap the whole thing in a valid IAM policy document with Version
   "2012-10-17" and a meaningful Sid per statement.

2. Create deploy/aws-ecs/iam/README.md:

   # IAM Prerequisites for AWS Administrators

   This document is for the **AWS administrator** who grants the
   operator (SE, deployment engineer, or CI/CD pipeline) the
   permissions needed to deploy the Okta MCP Adapter to AWS ECS.

   ## TL;DR

   Attach `operator-policy.json` to the operator's IAM user or role.
   The policy is minimum-scoped: every resource ARN is restricted
   to names matching `okta-mcp*` where AWS supports ARN-level
   conditions.

   ```bash
   # Replace <OPERATOR_USER_OR_ROLE> and <ROUTE53_ZONE_ID>
   sed -i '' 's/<ROUTE53_ZONE_ID>/Z0123456789ABCDEF/g' \
     deploy/aws-ecs/iam/operator-policy.json

   aws iam put-user-policy \
     --user-name <OPERATOR_USER_OR_ROLE> \
     --policy-name OktaMcpAdapterDeployment \
     --policy-document file://deploy/aws-ecs/iam/operator-policy.json
   ```

   ## What the deployment creates

   When the operator runs `./deploy.sh --apply`, Terraform creates:

   | Resource type | Scope | Why the operator needs permissions |
   |---|---|---|
   | VPC + subnets + IGW + NAT GW | One VPC (10.0.0.0/16) | Network isolation |
   | Security groups (4) | In the created VPC | Least-privilege network rules |
   | ECR repos (3) | `okta-mcp-*` | Image storage |
   | RDS PostgreSQL | `okta-mcp-db` | Adapter state |
   | ElastiCache Redis | `okta-mcp-redis` | Token/session cache |
   | Secrets Manager (4) | `okta-mcp/*` | Config and credentials |
   | IAM roles (2–3) | `okta-mcp-*` | ECS + CodeBuild assume |
   | ECS cluster + 3 services | `okta-mcp-cluster` | Runtime |
   | ALB + ACM cert | `okta-mcp-alb`, provided hostnames | TLS ingress |
   | Route53 records (3) | The provided hosted zone | DNS |
   | CloudWatch log groups (3) | `/ecs/okta-mcp/*` | Observability |
   | CodeBuild + S3 (optional) | `okta-mcp*` | Server-side image builds |

   ## Placeholders the administrator must customize

   The generated `operator-policy.json` contains placeholders:

   | Placeholder | Replace with | Notes |
   |---|---|---|
   | `<ROUTE53_ZONE_ID>` | Actual Route53 zone ID (e.g., `Z0123456789ABCDEF`) | Restrict Route53 access to one zone. Use `*` for all zones only if policy requires it. |

   ## Common enterprise blockers

   ### Service Control Policies (SCPs)

   If your AWS Organization has SCPs, verify the operator's principal
   is not denied any of these actions. Common SCP conflicts:

   - **Region restriction** — SCPs often limit actions to approved
     regions. Ensure your deployment region is allowed.
   - **Required tags** — SCPs may require specific tags (cost center,
     owner, data classification). If so, add them to
     `local.common_tags` in `main.tf` before deployment.
   - **Forbidden services** — Some orgs block ElastiCache Serverless,
     public ALBs, or NAT Gateways. Adjust the deployment accordingly.
   - **IAM role creation** — Many SCPs restrict `iam:CreateRole`
     unless a permission boundary is attached. See next section.

   ### Permission boundaries

   Some organizations require every IAM role to have a permission
   boundary attached. If that applies:

   1. The operator policy needs `iam:PutRolePermissionsBoundary` and
      `iam:DeleteRolePermissionsBoundary` added (scoped to
      `arn:aws:iam::*:role/okta-mcp*`).
   2. You must modify `main.tf` to attach the boundary when creating
      the ECS task roles. Add to each `aws_iam_role`:
      ```hcl
      permissions_boundary = "arn:aws:iam::ACCOUNT:policy/YourBoundaryName"
      ```
   3. Pass the boundary ARN as a Terraform variable so it's environment-
      specific.

   ### Assume-role pattern (recommended for regulated orgs)

   In regulated environments, rather than attaching the operator
   policy directly to a user, create a dedicated deployment role
   that the operator assumes:

   ```bash
   # 1. Create the deployment role (admin does this once):
   aws iam create-role \
     --role-name OktaMcpAdapterDeploymentRole \
     --assume-role-policy-document '{
       "Version": "2012-10-17",
       "Statement": [{
         "Effect": "Allow",
         "Principal": { "AWS": "arn:aws:iam::ACCOUNT:user/OPERATOR" },
         "Action": "sts:AssumeRole",
         "Condition": {
           "Bool": { "aws:MultiFactorAuthPresent": "true" }
         }
       }]
     }'

   # 2. Attach the operator-policy.json to that role:
   aws iam put-role-policy \
     --role-name OktaMcpAdapterDeploymentRole \
     --policy-name OktaMcpAdapterDeployment \
     --policy-document file://deploy/aws-ecs/iam/operator-policy.json

   # 3. Operator assumes the role before running deploy.sh:
   eval $(aws sts assume-role \
     --role-arn arn:aws:iam::ACCOUNT:role/OktaMcpAdapterDeploymentRole \
     --role-session-name okta-mcp-deploy \
     --query 'Credentials.[AccessKeyId,SecretAccessKey,SessionToken]' \
     --output text | awk '{
       print "export AWS_ACCESS_KEY_ID="$1;
       print "export AWS_SECRET_ACCESS_KEY="$2;
       print "export AWS_SESSION_TOKEN="$3
     }')

   # 4. Now run deploy.sh:
   cd deploy/aws-ecs && ./deploy.sh --apply
   ```

   This pattern gives you MFA enforcement, time-bounded credentials,
   and a clean audit trail in CloudTrail.

   ## Verifying the operator has the right permissions

   Run this command as the operator to simulate the deployment:

   ```bash
   ./deploy.sh --plan
   ```

   If permissions are missing, Terraform will fail with specific
   `AccessDenied` errors. The pre-flight probe in `deploy.sh`
   (added by E10) catches the most common cases before Terraform runs.

   For a more thorough check, use `aws iam simulate-principal-policy`:

   ```bash
   aws iam simulate-principal-policy \
     --policy-source-arn arn:aws:iam::ACCOUNT:user/OPERATOR \
     --action-names ec2:CreateVpc rds:CreateDBInstance iam:CreateRole \
                    ecs:CreateCluster elasticloadbalancing:CreateLoadBalancer
   ```

   ## Policy size considerations

   The generated `operator-policy.json` is around 80-120 statements.
   AWS IAM managed policies have a 6,144 character limit and inline
   policies a 10,240 character limit. The generated policy fits
   within the inline policy limit but may exceed the managed policy
   limit.

   If you need a managed policy, split `operator-policy.json` into
   two parts:
   - `operator-policy-network-data.json` (VPC, RDS, ElastiCache, IAM, STS)
   - `operator-policy-compute-ingress.json` (ECS, ECR, ELB, ACM,
     Route53, Secrets, Logs, CodeBuild, Cloud Map, Auto Scaling)

   Attach both to the operator's role.

   ## Revoking access after deployment

   Once deployed, if the operator only needs to run stop/start/smoke
   tests (not re-deploy), you can swap the operator policy for a
   much smaller runtime policy:

   - `ecs:UpdateService` on the 3 service ARNs
   - `rds:StartDBInstance`, `rds:StopDBInstance` on the DB ARN
   - `ecs:DescribeServices`, `ecs:ListTasks` on the cluster
   - `aws sts get-caller-identity` (for smoke tests)

   Re-attach the full `operator-policy.json` when a redeploy is needed.

3. Update deploy/aws-ecs/README.md:

   Add a new top-level section RIGHT AFTER the "Overview" section
   (before "Prerequisites"):

   ## For AWS Administrators

   Before the operator runs `./deploy.sh`, an AWS administrator must
   grant the operator's IAM principal the permissions to create the
   resources in this deployment.

   See **`iam/README.md`** for:
   - The concrete IAM policy (`iam/operator-policy.json`)
   - Instructions for attaching it directly or via an assume-role pattern
   - Guidance on SCP conflicts, permission boundaries, and regulated
     environments
   - A smaller runtime-only policy for post-deployment operations

   **The operator policy scopes every resource to names matching
   `okta-mcp*` where AWS supports ARN-level conditions.** It is not
   administrator-equivalent.

4. Update deploy/aws-ecs/deploy.sh:

   Add a pre-flight IAM probe function that runs before terraform init.
   The probe makes cheap read-only API calls to verify core permissions
   are present, and prints a clear error pointing to iam/README.md
   if anything fails:

   preflight_iam_check() {
     local failures=()

     echo "Running pre-flight IAM permission checks..."

     # Probe STS (foundational)
     if ! aws sts get-caller-identity --no-cli-pager >/dev/null 2>&1; then
       failures+=("sts:GetCallerIdentity — is AWS CLI configured?")
     fi

     # Probe EC2
     if ! aws ec2 describe-vpcs --max-results 5 \
          --region "${AWS_REGION:-us-east-1}" \
          --no-cli-pager >/dev/null 2>&1; then
       failures+=("ec2:DescribeVpcs — cannot read VPCs")
     fi

     # Probe ECS
     if ! aws ecs list-clusters \
          --region "${AWS_REGION:-us-east-1}" \
          --no-cli-pager >/dev/null 2>&1; then
       failures+=("ecs:ListClusters — cannot read ECS")
     fi

     # Probe RDS
     if ! aws rds describe-db-instances \
          --region "${AWS_REGION:-us-east-1}" \
          --max-items 1 --no-cli-pager >/dev/null 2>&1; then
       failures+=("rds:DescribeDBInstances — cannot read RDS")
     fi

     # Probe IAM (most commonly restricted)
     if ! aws iam list-roles --max-items 1 \
          --no-cli-pager >/dev/null 2>&1; then
       failures+=("iam:ListRoles — cannot read IAM roles")
     fi

     # Probe Secrets Manager
     if ! aws secretsmanager list-secrets --max-results 1 \
          --region "${AWS_REGION:-us-east-1}" \
          --no-cli-pager >/dev/null 2>&1; then
       failures+=("secretsmanager:ListSecrets — cannot read Secrets Manager")
     fi

     # Probe Route53 (zone-scoped)
     if [[ -n "${TF_VAR_route53_zone_id:-}" ]]; then
       if ! aws route53 get-hosted-zone \
            --id "$TF_VAR_route53_zone_id" \
            --no-cli-pager >/dev/null 2>&1; then
         failures+=("route53:GetHostedZone — cannot read zone $TF_VAR_route53_zone_id")
       fi
     fi

     if [[ ${#failures[@]} -gt 0 ]]; then
       echo ""
       echo "✗ Pre-flight IAM checks failed:"
       for f in "${failures[@]}"; do
         echo "  - $f"
       done
       echo ""
       echo "The operator principal is missing required permissions."
       echo "See: deploy/aws-ecs/iam/README.md for the concrete IAM"
       echo "policy an AWS administrator must attach."
       echo ""
       echo "To skip this check (NOT recommended): export SKIP_IAM_CHECK=true"
       exit 1
     fi

     echo "✓ Pre-flight IAM checks passed"
   }

   Call this at the top of the --apply, --plan, and --destroy paths
   (before terraform init), UNLESS SKIP_IAM_CHECK=true is set.

   IMPORTANT: The probe only does read-only calls. It does NOT
   guarantee write permissions work — Terraform will still fail on
   write actions if the operator has Read-only access to a service.
   The probe catches the most common enterprise misconfiguration:
   the operator has full Read but restricted Write.

5. Update the main README's "Troubleshooting" section to add:

   - **Pre-flight check failed** — the operator's IAM principal is
     missing permissions. See `iam/README.md` for the full policy
     and `aws iam simulate-principal-policy` instructions.
   - **terraform apply fails with AccessDenied** — Terraform reveals
     which specific action is denied. Match it to the statement in
     `iam/operator-policy.json` and verify the operator's attached
     policies include it.
   - **"Cannot assume role X"** — the operator has permission to
     create IAM roles but not to pass them to the ECS service. Verify
     the `iam:PassRole` statement in the operator policy includes
     `ecs-tasks.amazonaws.com` in the condition.

6. Validate the generated policy:
   a. Use aws-policy-validator if available, otherwise python:
      python3 -c "import json; json.load(open('deploy/aws-ecs/iam/operator-policy.json'))"
   b. Optionally run `aws accessanalyzer validate-policy` on it if
      AccessAnalyzer is enabled in the account.

Do NOT execute deploy.sh — this prompt only authors documentation
and the pre-flight probe.
```

### Expected Output

- `deploy/aws-ecs/iam/operator-policy.json` — valid IAM policy document covering every AWS action the Terraform module invokes, scoped to `okta-mcp*` resources where possible
- `deploy/aws-ecs/iam/README.md` — administrator-facing documentation with TL;DR, resource inventory, SCP/permission-boundary guidance, assume-role pattern
- Updated `deploy/aws-ecs/README.md` with prominent "For AWS Administrators" section
- Updated `deploy/aws-ecs/deploy.sh` with `preflight_iam_check` function called before `terraform init` in all three modes
- Updated Troubleshooting section with IAM-specific entries

---

## Prompt E11: External DNS Provider Support (Retrofit)

### Context

The original E1–E10 prompts assume the customer's DNS is hosted in Route53. Many enterprise customers host DNS at GoDaddy, Cloudflare, Namecheap, NS1, or corporate DNS (BIND, Infoblox, etc.). This prompt retrofits the ECS deployment to support three DNS tiers:

- **Tier 1 (`route53`):** Full automation. Original behavior. Zone ID is in the same AWS account.
- **Tier 2 (`route53_delegated`):** Customer's primary domain is external, but they've delegated a subdomain (e.g., `aws.example.com`) to a Route53 hosted zone. Deployment still fully automated; documentation in README explains the one-time NS delegation setup.
- **Tier 3 (`external`):** DNS managed entirely outside AWS. Terraform creates the ACM cert and outputs the validation CNAME; operator manually creates the CNAME in their DNS provider; Terraform waits for validation. Same pattern for hostname records post-deploy.

This retrofit is designed to be applied to an already-deployed Tier 1 environment without disruption: the default remains `dns_provider = "route53"`, and existing Terraform state is compatible.

### Prompt

```
Retrofit the Okta MCP Adapter ECS deployment to support external DNS
providers (GoDaddy, Cloudflare, corporate DNS, etc.) in addition to
Route53.

Read deploy/aws-ecs/main.tf, deploy/aws-ecs/variables.tf,
deploy/aws-ecs/deploy.sh, deploy/aws-ecs/iam/operator-policy.json,
and deploy/aws-ecs/README.md first — you are modifying all of them.

This is a retrofit prompt: it must not break existing Tier 1
(Route53) deployments. The default for dns_provider is "route53"
and existing terraform state must apply cleanly with no resource
recreation.

1. Modify deploy/aws-ecs/variables.tf:

   Add variable "dns_provider":
     type = string
     default = "route53"
     description = "DNS provider tier: 'route53' (fully automated,
       zone in this AWS account), 'route53_delegated' (subdomain
       delegated to Route53 — treated identically to route53 by
       Terraform; customer handles NS delegation out-of-band), or
       'external' (DNS at GoDaddy/Cloudflare/corporate — manual
       CNAME steps required)."
     validation {
       condition = contains(["route53", "route53_delegated", "external"],
         var.dns_provider)
       error_message = "dns_provider must be route53, route53_delegated, or external."
     }

   Modify existing variable "route53_zone_id":
     - Change default from no-default to default = ""
     - Update description: "Route53 hosted zone ID. Required when
       dns_provider is 'route53' or 'route53_delegated'. Ignored
       when dns_provider is 'external'."
     - Add validation:
       condition = var.dns_provider == "external" || length(var.route53_zone_id) > 0
       error_message = "route53_zone_id is required when dns_provider is route53 or route53_delegated."

   Add variable "external_dns_validation_timeout":
     type = string
     default = "30m"
     description = "How long Terraform waits for external DNS CNAME
       validation records to propagate before failing. Only applies
       when dns_provider = 'external'."

2. Modify deploy/aws-ecs/main.tf — ACM certificate section (from E6):

   Keep the aws_acm_certificate resource unchanged — it's DNS-provider
   agnostic.

   Modify the Route53 validation CNAME resource:
     resource "aws_route53_record" "cert_validation" {
       for_each = var.dns_provider != "external" ? {
         for dvo in aws_acm_certificate.this.domain_validation_options :
         dvo.domain_name => {
           name   = dvo.resource_record_name
           record = dvo.resource_record_value
           type   = dvo.resource_record_type
         }
       } : {}

       allow_overwrite = true
       name            = each.value.name
       records         = [each.value.record]
       ttl             = 60
       type            = each.value.type
       zone_id         = var.route53_zone_id
     }

   Modify the aws_acm_certificate_validation resource:
     When dns_provider is 'route53' or 'route53_delegated':
       validation_record_fqdns = [for r in aws_route53_record.cert_validation : r.fqdn]
       timeouts { create = "15m" }

     When dns_provider is 'external':
       Use a different strategy — we don't have FQDNs to list because
       Terraform didn't create the records. Instead:

       validation_record_fqdns = [
         for dvo in aws_acm_certificate.this.domain_validation_options :
         dvo.resource_record_name
       ]
       timeouts { create = var.external_dns_validation_timeout }

     Use count = var.dns_provider == "external" ? 0 : 1 on the
     route53-based validation, and count = var.dns_provider == "external" ? 1 : 0
     on the external-DNS validation. Name them _route53 and _external
     suffixed.

   IMPORTANT: Both validation resources reference the same ACM cert,
   but only one is active at a time. The output
   acm_certificate_validation_complete should coalesce from whichever
   is active.

3. Modify deploy/aws-ecs/main.tf — hostname alias records (from E6):

   The two aws_route53_record resources for var.adapter_hostname and
   var.admin_hostname need count gating:

     resource "aws_route53_record" "adapter" {
       count = var.dns_provider != "external" ? 1 : 0
       zone_id = var.route53_zone_id
       name    = var.adapter_hostname
       type    = "A"
       alias {
         name                   = aws_lb.main.dns_name
         zone_id                = aws_lb.main.zone_id
         evaluate_target_health = true
       }
     }

     (Same pattern for admin_hostname with count = external ? 0 : 1.)

4. Add a null_resource to guide the operator when dns_provider = "external":

   resource "null_resource" "external_dns_instructions" {
     count = var.dns_provider == "external" ? 1 : 0

     triggers = {
       cert_arn = aws_acm_certificate.this.arn
     }

     provisioner "local-exec" {
       command = <<-EOT
         echo ""
         echo "═══════════════════════════════════════════════════════════"
         echo "  EXTERNAL DNS ACTION REQUIRED"
         echo "═══════════════════════════════════════════════════════════"
         echo ""
         echo "The ACM certificate is pending DNS validation. Create the"
         echo "following CNAME records in your DNS provider:"
         echo ""
         ${join("\n", [
           for dvo in aws_acm_certificate.this.domain_validation_options :
           "echo '  Name:  ${dvo.resource_record_name}'\n echo '  Value: ${dvo.resource_record_value}'\n echo '  Type:  ${dvo.resource_record_type}'\n echo ''"
         ])}
         echo "Terraform will wait up to ${var.external_dns_validation_timeout}"
         echo "for these records to propagate. Press Ctrl+C if you need"
         echo "more time — re-run deploy.sh --apply when records are set."
         echo ""
         echo "═══════════════════════════════════════════════════════════"
       EOT
     }
   }

   Make aws_acm_certificate_validation depend_on this null_resource
   so the instructions print before the wait begins.

5. Add outputs to deploy/aws-ecs/outputs.tf:

   Always output these (they're useful in all three tiers):

     output "acm_validation_records" {
       description = "DNS validation records for the ACM certificate.
         In Tier 1/2 Terraform creates these automatically. In Tier 3
         the operator creates them manually in the external DNS provider."
       value = [
         for dvo in aws_acm_certificate.this.domain_validation_options : {
           name  = dvo.resource_record_name
           value = dvo.resource_record_value
           type  = dvo.resource_record_type
         }
       ]
     }

     output "alb_hostname_records_required" {
       description = "CNAME records the operator must create when
         dns_provider = 'external'. In Tier 1/2 Terraform creates
         these automatically and this output is informational only."
       value = var.dns_provider == "external" ? [
         {
           name  = var.adapter_hostname
           value = aws_lb.main.dns_name
           type  = "CNAME"
         },
         {
           name  = var.admin_hostname
           value = aws_lb.main.dns_name
           type  = "CNAME"
         }
       ] : []
     }

     output "dns_provider_tier" {
       value = var.dns_provider
     }

6. Modify deploy/aws-ecs/deploy.sh:

   In the summary box logic, after terraform apply succeeds, check
   the dns_provider output and branch:

     DNS_PROVIDER=$(terraform output -raw dns_provider_tier)

     if [[ "$DNS_PROVIDER" == "external" ]]; then
       echo ""
       echo "═══════════════════════════════════════════════════════════"
       echo "  POST-DEPLOY: Create hostname CNAMEs in your DNS provider"
       echo "═══════════════════════════════════════════════════════════"
       echo ""
       echo "Create these CNAME records so customers can reach the adapter:"
       echo ""
       terraform output -json alb_hostname_records_required | \
         jq -r '.[] | "  \(.name)  CNAME  \(.value)"'
       echo ""
       echo "Until these records are created, smoke tests will fail"
       echo "and the adapter URL will not resolve."
       echo ""
       SKIP_SMOKE_TESTS=true  # Don't run smoke tests in external mode
                              # until operator confirms CNAMEs exist
     fi

   In the preflight_iam_check function (added in E10):

     Gate the Route53 probe on dns_provider:

       if [[ "${TF_VAR_dns_provider:-route53}" != "external" && -n "${TF_VAR_route53_zone_id:-}" ]]; then
         if ! aws route53 get-hosted-zone \
              --id "$TF_VAR_route53_zone_id" \
              --no-cli-pager >/dev/null 2>&1; then
           failures+=("route53:GetHostedZone — cannot read zone $TF_VAR_route53_zone_id")
         fi
       fi

7. Modify deploy/aws-ecs/iam/operator-policy.json:

   Make Route53 permissions a separate SID that admins can remove
   when dns_provider = "external":

     {
       "Sid": "Route53DNSManagement",
       "Effect": "Allow",
       "Action": [
         "route53:ChangeResourceRecordSets",
         "route53:GetChange",
         "route53:ListResourceRecordSets"
       ],
       "Resource": "arn:aws:route53:::hostedzone/<ROUTE53_ZONE_ID>",
       "Comment_for_external_dns": "REMOVE THIS STATEMENT when dns_provider = 'external'. The operator does not need Route53 access in that tier."
     },
     {
       "Sid": "Route53ListZones",
       "Effect": "Allow",
       "Action": ["route53:ListHostedZones"],
       "Resource": "*"
     }

   (IAM policies don't actually support "Comment_" fields — that's
   just for clarity during generation. When the policy is finalized
   strip those fields. Instead, document the conditional in the
   iam/README.md.)

8. Update deploy/aws-ecs/iam/README.md — add a new section right
   after "Common enterprise blockers":

   ## DNS provider conditionals

   The operator's Route53 permissions depend on the deployment's
   `dns_provider` setting:

   | DNS Provider Tier | Route53 permissions needed? |
   |---|---|
   | `route53` (zone in this AWS account) | Yes — full scope to zone ID |
   | `route53_delegated` (subdomain NS-delegated from external) | Yes — scope to the delegated zone ID |
   | `external` (GoDaddy, Cloudflare, corporate) | No — remove the Route53 statements |

   For Tier 3 deployments, delete the `Route53DNSManagement` and
   `Route53ListZones` statements from `operator-policy.json` before
   attaching it. The operator will not create or modify any Route53
   resources.

9. Update deploy/aws-ecs/README.md — replace the "Prerequisites"
   DNS bullet and add a full "DNS Provider Options" section:

   Under Prerequisites, change:
   - "A Route53 hosted zone for your domain (the prompts create DNS
      records in it)"
   To:
   - "DNS for your adapter and admin hostnames. See 'DNS Provider
      Options' below for supported tiers."

   Add new section after Prerequisites and before "Required
   environment variables":

   ## DNS Provider Options

   The deployment supports three DNS tiers. Choose based on where
   your domain lives:

   ### Tier 1: Route53 (recommended — fully automated)
   Your domain's authoritative DNS is in Route53 in this AWS account.
   Terraform handles everything: ACM certificate validation, hostname
   records, health check integration. No manual DNS steps.

   ```bash
   export TF_VAR_dns_provider="route53"
   export TF_VAR_route53_zone_id="Z0123456789ABCDEF"
   ```

   ### Tier 2: Route53 Delegated Subdomain (recommended for external domains)
   Your primary domain is at GoDaddy/Cloudflare/etc., but you've
   delegated a subdomain (e.g., `aws.example.com`) to a Route53
   hosted zone in this AWS account. From the deployment's perspective
   this is identical to Tier 1.

   **One-time setup:**
   1. Create a public hosted zone in Route53 for `aws.example.com`
      ```bash
      aws route53 create-hosted-zone \
        --name aws.example.com \
        --caller-reference "okta-mcp-$(date +%s)"
      ```
   2. Route53 returns 4 nameservers (e.g., `ns-123.awsdns-15.com`).
   3. In your external DNS provider, create NS records for
      `aws.example.com` pointing to the 4 Route53 nameservers.
   4. Wait 5–60 minutes for NS propagation.
   5. Deploy with `adapter_hostname=mcp.aws.example.com` etc.

   ```bash
   export TF_VAR_dns_provider="route53_delegated"
   export TF_VAR_route53_zone_id="Z0987654321FEDCBA"  # The delegated zone
   export TF_VAR_adapter_hostname="mcp.aws.example.com"
   export TF_VAR_admin_hostname="admin-mcp.aws.example.com"
   ```

   Costs: $0.50/month for the Route53 zone. Zero operational overhead.

   ### Tier 3: External DNS (GoDaddy, Cloudflare, corporate)
   Your DNS stays entirely at your existing provider. Terraform
   creates the ACM certificate but cannot create the validation
   records — you do that manually. Same for hostname CNAMEs.

   ```bash
   export TF_VAR_dns_provider="external"
   # route53_zone_id NOT needed
   ```

   Deployment flow:
   1. Run `./deploy.sh --apply`
   2. Terraform creates the ACM cert and pauses with instructions:
      ```
      Create the following CNAME in your DNS:
        Name:  _abc123.mcp.example.com
        Value: _xyz789.acm-validations.aws
        Type:  CNAME
      ```
   3. Create the CNAME in your DNS provider (GoDaddy/Cloudflare/etc.)
   4. Terraform waits up to 30 minutes for validation to complete.
   5. After validation, the ALB is created and deploy.sh prints the
      ALB DNS name along with two more CNAMEs to create:
      ```
        mcp.example.com         CNAME  okta-mcp-alb-1234567890.us-east-1.elb.amazonaws.com
        admin-mcp.example.com   CNAME  okta-mcp-alb-1234567890.us-east-1.elb.amazonaws.com
      ```
   6. Create the hostname CNAMEs in your DNS provider.
   7. Run `./smoke-test.sh` once DNS propagates.

   **Caveats for Tier 3:**
   - No health-check-based DNS failover (Route53 alias feature).
     Not meaningful for a single-region deployment.
   - If you rebuild the ALB (terraform destroy + apply), you get a
     new ALB DNS name and must update the hostname CNAMEs again.
     ALB DNS names don't change within a deployment's lifetime, only
     across recreations.
   - ACM certificate renewal also uses DNS-01 validation. ACM
     auto-renews 60 days before expiry; if the validation CNAME is
     still in your DNS (you didn't delete it), renewal is automatic.
     **Keep the _abc123 validation CNAMEs in your DNS permanently.**
   - GoDaddy's DNS API is rate-limited and not well-supported by
     IaC tools. Manual record creation via the GoDaddy UI works
     fine but adds friction to redeployments.

   ### Which tier should you use?

   - **You control DNS and domain is in AWS or you're willing to put
     it there:** Tier 1.
   - **Your domain is elsewhere but you can get a subdomain delegated:**
     Tier 2. Best experience for most external-DNS customers.
   - **Corporate DNS team controls everything and delegation isn't an
     option:** Tier 3. Works but requires coordination with the DNS
     team at deploy time.

10. Update deploy/aws-ecs/README.md troubleshooting section:

    Add:
    - **ACM cert stuck in PENDING_VALIDATION (Tier 1/2):** Check that
      TF_VAR_route53_zone_id is correct and the zone contains your
      hostname's parent domain. For Tier 2, verify NS delegation
      from the parent domain has propagated (`dig NS aws.example.com`).
    - **ACM cert stuck in PENDING_VALIDATION (Tier 3):** Verify the
      validation CNAME exists in your DNS with `dig CNAME
      _abc123.mcp.example.com`. Common mistake: DNS provider
      UIs sometimes auto-append the domain, turning
      `_abc123.mcp.example.com` into
      `_abc123.mcp.example.com.example.com`.
    - **Smoke tests fail with DNS resolution error (Tier 3):** The
      hostname CNAMEs weren't created yet, or DNS hasn't propagated.
      Wait a few minutes or check with `dig CNAME mcp.example.com`.
    - **Terraform destroy leaves ACM cert behind (Tier 3):** The cert
      can't be deleted while it's validating. If stuck, manually
      disassociate it from any ALB listeners and retry destroy.

11. Run terraform fmt and terraform validate.

Do NOT apply. Existing Tier 1 deployments should be able to run
terraform plan against the retrofitted module and see NO CHANGES.
Verify this by:
  terraform plan
  Expected: "No changes. Your infrastructure matches the configuration."
```

### Expected Output

- `variables.tf` has `dns_provider`, modified `route53_zone_id`, and `external_dns_validation_timeout`
- `main.tf` has conditional Route53 resources (validation CNAMEs, hostname aliases) gated by `dns_provider`
- `main.tf` has `null_resource.external_dns_instructions` that prints manual CNAME instructions in Tier 3
- `outputs.tf` has `acm_validation_records`, `alb_hostname_records_required`, and `dns_provider_tier` outputs
- `deploy.sh` branches on `dns_provider` in both the summary box and the pre-flight probe
- `iam/operator-policy.json` has Route53 statements flagged as removable for Tier 3
- `iam/README.md` has the "DNS provider conditionals" section
- `README.md` has the "DNS Provider Options" section with all three tiers documented
- `README.md` troubleshooting section has DNS-specific entries
- `terraform plan` against an existing Tier 1 deployment shows zero changes

### Migrating an existing Tier 1 deployment

For operators who have already deployed with E1–E10 and want to verify the retrofit:

```bash
cd deploy/aws-ecs

# After applying E11, pull down existing state
terraform init

# Confirm no changes to existing infrastructure
terraform plan
# Expected: "No changes. Your infrastructure matches the configuration."

# If changes are shown, they should be cosmetic (tag updates,
# count-index additions on existing resources). Review carefully.
```

To switch an existing deployment from Tier 1 to Tier 3 (rare but supported):

```bash
export TF_VAR_dns_provider="external"
unset TF_VAR_route53_zone_id

./deploy.sh --apply
# Terraform will DESTROY the Route53 records (cert validation + hostname
# aliases) and keep the ACM cert + ALB. Operator then creates CNAMEs
# in external DNS. ACM will revalidate via the new CNAMEs (may take
# 15-30 min).
```

Migrating back Tier 3 → Tier 1 works the same way in reverse.

---

## Prompt E12: Deployment Tarball Packaging

### Context

The ECS deployment needs a `package.sh` that produces a self-contained tarball an SE can hand to a customer — no git clone required, no repo access needed. The tarball includes everything required to run `deploy.sh --apply`: Terraform files, deployment scripts, IAM policy docs, Docker build context (adapter source, admin UI source, example backends), and supporting files. Tests, docs, dev tooling, Claude configuration, and sibling deployment targets are stripped.

This matches the existing pattern established by `deploy/azure-aca/package.sh` and `deploy/aws-ec2/package.sh`. The critical structural requirement is that the tarball preserves the `deploy/aws-ecs/` → repo root relative path so that `build-images.sh`'s `REPO_ROOT="$(cd "$SCRIPT_DIR/../.." && pwd)"` still resolves to the correct location for Docker builds.

### Prompt

```
Create a package.sh for the AWS ECS deployment that produces a
self-contained deployment tarball.

Read deploy/azure-aca/package.sh and deploy/aws-ec2/package.sh first
to understand the established packaging patterns. The ECS package.sh
must follow the same conventions: flag parsing (--version, --output-dir,
--dry-run), version from pyproject.toml, color output, staging directory,
file exclusions, summary with file count/size/checksum.

Create deploy/aws-ecs/package.sh:

#!/usr/bin/env bash
set -euo pipefail

# =============================================================
# package.sh — Build a self-contained ECS deployment tarball
# =============================================================
# Run from the deploy/aws-ecs/ directory or any location.
# Produces: okta-ps-adapter-aws-ecs-${VERSION}.tar.gz
#
# The tarball is self-contained: an SE extracts it, cd's into
# deploy/aws-ecs/, and runs ./deploy.sh --apply. No git clone
# or repo access required.
# =============================================================

CRITICAL LAYOUT REQUIREMENT:
The tarball MUST preserve this directory structure:

  okta-ps-adapter-aws-ecs-<version>/
  ├── Dockerfile                        # adapter image (Docker build context root)
  ├── .dockerignore
  ├── requirements.txt
  ├── pyproject.toml
  ├── alembic.ini
  ├── alembic/                          # Postgres migrations (run on adapter startup)
  ├── scripts/
  │   └── docker-entrypoint.sh          # only the entrypoint — not dev/migration scripts
  ├── okta_agent_proxy/                 # adapter source (FastAPI gateway)
  ├── okta_agent_proxy_admin_ui/        # Next.js Admin UI source
  ├── examples/
  │   ├── 01-hr-system/                 # PSK-auth example backend
  │   └── 05-deploy-server/             # XAA example backend
  └── deploy/
      └── aws-ecs/                      # ← operator runs everything from here
          ├── deploy.sh
          ├── build-images.sh
          ├── build-codebuild.sh
          ├── buildspec.yml
          ├── smoke-test.sh
          ├── stop.sh
          ├── start.sh
          ├── main.tf
          ├── variables.tf
          ├── outputs.tf
          ├── .terraform.lock.hcl       # lock file for reproducible init
          ├── .gitignore
          ├── README.md
          └── iam/
              ├── README.md
              └── operator-policy.json

This layout is essential because:
- build-images.sh uses REPO_ROOT="$(cd "$SCRIPT_DIR/../.." && pwd)"
  to find Dockerfile and source directories for docker buildx
- build-codebuild.sh does the same for CodeBuild source packaging
- The Dockerfile COPYs from the repo root context (requirements.txt,
  okta_agent_proxy/, alembic/, scripts/)
- The admin-ui and hr-backend Dockerfiles are in their respective
  directories under okta_agent_proxy_admin_ui/ and examples/01-hr-system/

Implementation:

1. Same flag parsing as deploy/azure-aca/package.sh:
   --version VERSION  (default: from pyproject.toml, fallback: "dev")
   --output-dir DIR   (default: ./dist)
   --dry-run          (list files without creating tarball)
   -h|--help

2. Same color/info/ok/warn/die helpers as the existing package.sh files.

3. Resolve SCRIPT_DIR and REPO_ROOT:
   SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
   REPO_ROOT="$(cd "$SCRIPT_DIR/../.." && pwd)"

4. Verify source files exist (fail fast):
   - $REPO_ROOT/Dockerfile
   - $REPO_ROOT/okta_agent_proxy (directory)
   - $SCRIPT_DIR/deploy.sh
   - $SCRIPT_DIR/main.tf

5. Clean staging directory:
   STAGING_DIR="/tmp/okta-ps-adapter-aws-ecs-${VERSION}"
   rm -rf "$STAGING_DIR" && mkdir -p "$STAGING_DIR"

6. Copy ECS deployment scripts and Terraform:
   ECS_DIR="$STAGING_DIR/deploy/aws-ecs"
   mkdir -p "$ECS_DIR"

   Copy from $SCRIPT_DIR into $ECS_DIR:
   - deploy.sh
   - build-images.sh
   - build-codebuild.sh
   - buildspec.yml
   - smoke-test.sh
   - stop.sh
   - start.sh
   - main.tf
   - variables.tf
   - outputs.tf
   - .terraform.lock.hcl (if exists — provides reproducible init)
   - .gitignore
   - README.md
   - iam/ directory (README.md + operator-policy.json)

7. Copy adapter source code (Docker build context):
   cp $REPO_ROOT/Dockerfile $STAGING_DIR/
   cp $REPO_ROOT/.dockerignore $STAGING_DIR/
   cp $REPO_ROOT/requirements.txt $STAGING_DIR/
   cp $REPO_ROOT/pyproject.toml $STAGING_DIR/
   cp -r $REPO_ROOT/okta_agent_proxy $STAGING_DIR/
   cp $REPO_ROOT/alembic.ini $STAGING_DIR/
   cp -r $REPO_ROOT/alembic $STAGING_DIR/

   # Only docker-entrypoint.sh from scripts/ — not dev tools
   mkdir -p "$STAGING_DIR/scripts"
   cp $REPO_ROOT/scripts/docker-entrypoint.sh $STAGING_DIR/scripts/

8. Copy Admin UI source (for admin-ui container image build):
   if [[ -d "$REPO_ROOT/okta_agent_proxy_admin_ui" ]]; then
     cp -r "$REPO_ROOT/okta_agent_proxy_admin_ui" "$STAGING_DIR/"
   fi

9. Copy example backends (for hr-backend container image build):
   mkdir -p "$STAGING_DIR/examples"
   [[ -d "$REPO_ROOT/examples/01-hr-system" ]] && \
     cp -r "$REPO_ROOT/examples/01-hr-system" "$STAGING_DIR/examples/"
   [[ -d "$REPO_ROOT/examples/05-deploy-server" ]] && \
     cp -r "$REPO_ROOT/examples/05-deploy-server" "$STAGING_DIR/examples/"

10. Remove excluded patterns (same exclusion list as the existing
    package.sh files — keep in sync):
    # VCS and CI
    find "$STAGING_DIR" -type d -name ".git" -exec rm -rf {} + 2>/dev/null || true
    find "$STAGING_DIR" -type d -name ".github" -exec rm -rf {} + 2>/dev/null || true
    find "$STAGING_DIR" -name ".gitignore" -not -path "*/deploy/aws-ecs/.gitignore" -delete 2>/dev/null || true

    # Claude / AI tooling
    find "$STAGING_DIR" -name "CLAUDE.md" -delete 2>/dev/null || true
    find "$STAGING_DIR" -name "CLAUDE_CONVENTIONS.md" -delete 2>/dev/null || true
    find "$STAGING_DIR" -type d -name ".claude" -exec rm -rf {} + 2>/dev/null || true

    # Tests
    find "$STAGING_DIR" -type d -name "tests" -exec rm -rf {} + 2>/dev/null || true
    find "$STAGING_DIR" -name "pytest.ini" -delete 2>/dev/null || true
    find "$STAGING_DIR" -name "conftest.py" -delete 2>/dev/null || true
    find "$STAGING_DIR" -type d -name ".pytest_cache" -exec rm -rf {} + 2>/dev/null || true

    # Python cache
    find "$STAGING_DIR" -type d -name "__pycache__" -exec rm -rf {} + 2>/dev/null || true
    find "$STAGING_DIR" -name "*.pyc" -delete 2>/dev/null || true
    find "$STAGING_DIR" -name "*.pyo" -delete 2>/dev/null || true
    find "$STAGING_DIR" -name ".coverage" -delete 2>/dev/null || true

    # Node.js build artifacts
    find "$STAGING_DIR" -type d -name "node_modules" -exec rm -rf {} + 2>/dev/null || true
    find "$STAGING_DIR" -type d -name ".next" -exec rm -rf {} + 2>/dev/null || true

    # Office docs (design docs, not deployment artifacts)
    find "$STAGING_DIR" -name "*.docx" -delete 2>/dev/null || true
    find "$STAGING_DIR" -name "*.pptx" -delete 2>/dev/null || true
    find "$STAGING_DIR" -name "*.xlsx" -delete 2>/dev/null || true

    # Internal development prompts and analysis docs
    find "$STAGING_DIR" -name "*_PROMPTS*.md" -delete 2>/dev/null || true
    find "$STAGING_DIR" -name "*_ANALYSIS*.md" -delete 2>/dev/null || true
    find "$STAGING_DIR" -name "*ADR_*.md" -delete 2>/dev/null || true

    # .env files (keep .env.example if present)
    find "$STAGING_DIR" -maxdepth 1 -name ".env" -not -name ".env.*" -delete 2>/dev/null || true

    # Terraform state files (should not be packaged)
    find "$STAGING_DIR" -name "*.tfstate" -delete 2>/dev/null || true
    find "$STAGING_DIR" -name "*.tfstate.backup" -delete 2>/dev/null || true
    find "$STAGING_DIR" -name "tfplan" -delete 2>/dev/null || true
    find "$STAGING_DIR" -type d -name ".terraform" -exec rm -rf {} + 2>/dev/null || true
    find "$STAGING_DIR" -name ".generated-secrets" -delete 2>/dev/null || true

    # Root-level setup.sh (dev-only Docker Compose setup)
    rm -f "$STAGING_DIR/setup.sh" 2>/dev/null || true

11. File listing and summary:
    FILE_COUNT=$(find "$STAGING_DIR" -type f | wc -l | tr -d ' ')
    TOTAL_SIZE=$(du -sh "$STAGING_DIR" | cut -f1)

    Print file count and size.

    If --dry-run: list all files sorted, print total, clean up, exit.

12. Create tarball:
    mkdir -p "$OUTPUT_DIR"
    (cd /tmp && tar czf "${OUTPUT_DIR}/${TARBALL_NAME}" \
      "okta-ps-adapter-aws-ecs-${VERSION}")

13. Print summary box:
    ┌──────────────────────────────────────────────────────────┐
    │  Okta MCP Adapter — AWS ECS Deployment Tarball           │
    │                                                          │
    │  File:       okta-ps-adapter-aws-ecs-<version>.tar.gz    │
    │  Files:      <count>                                     │
    │  Unpacked:   <size>                                      │
    │  Compressed: <size>                                      │
    │  SHA-256:    <hash>                                      │
    │                                                          │
    │  To deploy:                                              │
    │    tar xzf okta-ps-adapter-aws-ecs-<version>.tar.gz      │
    │    cd okta-ps-adapter-aws-ecs-<version>/deploy/aws-ecs   │
    │    export TF_VAR_okta_domain=...                         │
    │    ./deploy.sh --apply                                   │
    └──────────────────────────────────────────────────────────┘

14. Cleanup staging directory.

Make the script executable: chmod +x deploy/aws-ecs/package.sh

15. Verify the tarball structure by running a dry-run:
    bash deploy/aws-ecs/package.sh --dry-run

    Confirm the output shows:
    - deploy/aws-ecs/ with all terraform and script files
    - Dockerfile at root
    - okta_agent_proxy/ at root
    - okta_agent_proxy_admin_ui/ at root
    - examples/01-hr-system/ and examples/05-deploy-server/
    - alembic/ and alembic.ini at root
    - scripts/docker-entrypoint.sh
    - NO .terraform/, NO *.tfstate, NO node_modules/, NO tests/,
      NO __pycache__/, NO .claude/, NO *.docx
```

### Expected Output

`deploy/aws-ecs/package.sh` exists and is executable. Running `./package.sh --dry-run` lists the complete tarball contents with the correct directory structure. Running `./package.sh` produces `dist/okta-ps-adapter-aws-ecs-<version>.tar.gz` with SHA-256 checksum printed.

### Verification

After creating the tarball, verify the deployment workflow works from it:

```bash
# Extract to a temp directory
mkdir -p /tmp/ecs-test && cd /tmp/ecs-test
tar xzf <path>/okta-ps-adapter-aws-ecs-<version>.tar.gz
cd okta-ps-adapter-aws-ecs-<version>/deploy/aws-ecs

# Verify REPO_ROOT resolution
bash -c 'SCRIPT_DIR=$(pwd); REPO_ROOT=$(cd "$SCRIPT_DIR/../.." && pwd); echo "REPO_ROOT=$REPO_ROOT"; ls "$REPO_ROOT/Dockerfile"'
# Should print the path and show the Dockerfile

# Verify Terraform
terraform init && terraform validate
# Should pass

# Verify build-images.sh can find Dockerfiles
bash -c 'source build-images.sh --help 2>/dev/null || head -15 build-images.sh'
# Should reference correct paths

# Cleanup
rm -rf /tmp/ecs-test
```

---

## Prompt E13: Quick Redeploy Scripts for Individual Components

### Context

After the initial `deploy.sh --apply`, SEs and developers frequently need to redeploy just one component — the adapter after a code change, the admin UI after a frontend fix, or a demo backend after updating its tool catalog. Running `deploy.sh --apply` again would re-run the full Terraform cycle (~5 min) even if only one container image changed.

This prompt creates lightweight redeploy scripts that do the minimum: build one image, push to ECR, and force a new ECS service deployment (~2–3 min per component). It also adds a "Quick Redeploy" section to the README with both the script commands and the equivalent manual `aws` CLI commands.

This matches the pattern established by `deploy/azure-aca/deploy-adapter.sh` and `deploy/azure-aca/deploy-ui.sh`.

### Prompt

```
Create quick redeploy scripts for individual components in the ECS
deployment, matching the pattern in deploy/azure-aca/deploy-adapter.sh
and deploy/azure-aca/deploy-ui.sh.

Read deploy/azure-aca/deploy-adapter.sh and deploy/azure-aca/deploy-ui.sh
for the established pattern (build image with timestamp tag, update
the service, wait for health). Also read deploy/aws-ecs/build-images.sh
for the ECR authentication and Docker build patterns.

The key difference from ACA: on Azure, the scripts use az acr build
(server-side) and az containerapp update. On AWS, the scripts use
docker buildx (local) and aws ecs update-service --force-new-deployment.
ECS doesn't have a direct "update container image" command — you
force a new deployment which pulls the :latest tag from ECR.

1. Create deploy/aws-ecs/deploy-adapter.sh:

#!/usr/bin/env bash
set -euo pipefail

# =============================================================
# deploy-adapter.sh — Quick redeploy of just the adapter
# =============================================================
# Builds a new adapter image, pushes to ECR, and forces a new
# ECS service deployment. Run from the deploy/aws-ecs/ directory.
# ~2-3 minutes for a full rebuild + deploy cycle.
# =============================================================

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
REPO_ROOT="$(cd "$SCRIPT_DIR/../.." && pwd)"

# Colors (same pattern as existing scripts)
# info/ok/die helpers

# Read required env vars
AWS_REGION="${AWS_REGION:-us-east-1}"
AWS_ACCOUNT_ID="${AWS_ACCOUNT_ID:-$(aws sts get-caller-identity --query Account --output text)}"
ECR_REGISTRY="${AWS_ACCOUNT_ID}.dkr.ecr.${AWS_REGION}.amazonaws.com"
CLUSTER_NAME="${CLUSTER_NAME:-okta-mcp-cluster}"
SERVICE_NAME="adapter"

# Build tag with timestamp for traceability
BUILD_TAG="build-$(date +%Y%m%d-%H%M%S)"

# Authenticate to ECR
info "Authenticating to ECR..."
aws ecr get-login-password --region "$AWS_REGION" | \
  docker login --username AWS --password-stdin "$ECR_REGISTRY" 2>/dev/null

# Build and push
info "Building adapter image ($BUILD_TAG)..."
docker buildx build \
  --platform linux/amd64 \
  -t "${ECR_REGISTRY}/okta-mcp-adapter:${BUILD_TAG}" \
  -t "${ECR_REGISTRY}/okta-mcp-adapter:latest" \
  -f "${REPO_ROOT}/Dockerfile" \
  --push \
  "${REPO_ROOT}"
ok "Image pushed: okta-mcp-adapter:${BUILD_TAG}"

# Force new deployment (ECS pulls :latest on next task start)
info "Forcing new ECS deployment..."
aws ecs update-service \
  --cluster "$CLUSTER_NAME" \
  --service "$SERVICE_NAME" \
  --force-new-deployment \
  --region "$AWS_REGION" \
  --no-cli-pager >/dev/null
ok "Deployment triggered"

# Wait for service to stabilize
info "Waiting for service to stabilize..."
if aws ecs wait services-stable \
     --cluster "$CLUSTER_NAME" \
     --services "$SERVICE_NAME" \
     --region "$AWS_REGION" 2>/dev/null; then
  ok "Service stable"
else
  warn "Stabilization timed out. Check: aws ecs describe-services --cluster $CLUSTER_NAME --services $SERVICE_NAME"
fi

# Health check
ADAPTER_HOSTNAME="${TF_VAR_adapter_hostname:-}"
if [[ -n "$ADAPTER_HOSTNAME" ]]; then
  info "Running health check..."
  elapsed=0
  while (( elapsed < 120 )); do
    if curl -sf "https://$ADAPTER_HOSTNAME/health" >/dev/null 2>&1; then
      ok "Adapter healthy after ${elapsed}s"
      echo ""
      ok "Adapter redeployed: ${BUILD_TAG}"
      exit 0
    fi
    printf "."
    sleep 5
    elapsed=$((elapsed + 5))
  done
  echo ""
  die "Health check timed out. Check: aws ecs describe-services --cluster $CLUSTER_NAME --services $SERVICE_NAME --region $AWS_REGION"
else
  ok "No TF_VAR_adapter_hostname set — skipping health check"
  echo ""
  ok "Adapter redeployed: ${BUILD_TAG}"
fi

Make executable.

2. Create deploy/aws-ecs/deploy-ui.sh:

#!/usr/bin/env bash
set -euo pipefail

# =============================================================
# deploy-ui.sh — Quick redeploy of just the Admin UI
# =============================================================

Same structure as deploy-adapter.sh but:
- Image: okta-mcp-admin-ui
- Dockerfile: ${REPO_ROOT}/okta_agent_proxy_admin_ui/Dockerfile
- Build context: ${REPO_ROOT}/okta_agent_proxy_admin_ui
- SERVICE_NAME: admin-ui
- Health check: https://$ADMIN_HOSTNAME/ (expect 200 or 302)
- Use TF_VAR_admin_hostname for the health check URL

Make executable.

3. Create deploy/aws-ecs/deploy-backend.sh:

#!/usr/bin/env bash
set -euo pipefail

# =============================================================
# deploy-backend.sh — Quick redeploy of a demo backend
# =============================================================
# Usage:
#   ./deploy-backend.sh hr          # Redeploy hr-backend
#   ./deploy-backend.sh deploy      # Redeploy deploy-server
#   ./deploy-backend.sh             # Defaults to hr-backend
# =============================================================

Parse the first argument to determine which backend:
  "hr" | "hr-backend" | "" (default):
    IMAGE_NAME="okta-mcp-hr-backend"
    DOCKERFILE="${REPO_ROOT}/examples/01-hr-system/Dockerfile"
    BUILD_CONTEXT="${REPO_ROOT}/examples/01-hr-system"
    SERVICE_NAME="hr-backend"

  "deploy" | "deploy-server":
    IMAGE_NAME="okta-mcp-deploy-server"
    DOCKERFILE="${REPO_ROOT}/examples/05-deploy-server/Dockerfile"
    BUILD_CONTEXT="${REPO_ROOT}/examples/05-deploy-server"
    SERVICE_NAME="deploy-server"

Same build/push/force-deployment/wait pattern as deploy-adapter.sh.
No health check URL (backends are not internet-facing) — just wait
for service stability.

Make executable.

4. Update deploy/aws-ecs/README.md:

Add a new section "Quick Redeploy" right after the "deploy.sh
Reference" section and before "Troubleshooting":

## Quick Redeploy

After the initial `./deploy.sh --apply`, use these scripts to
redeploy individual components without rerunning the full
Terraform cycle (~2-3 min each):

```bash
# Redeploy just the adapter (build + push + force new deployment + health check)
./deploy-adapter.sh

# Redeploy just the Admin UI
./deploy-ui.sh

# Redeploy a demo backend
./deploy-backend.sh hr          # HR System backend
./deploy-backend.sh deploy      # Deploy Server backend
```

Each script builds a timestamped image tag (e.g.,
`build-20260417-143022`) for traceability, pushes both the
timestamped tag and `:latest` to ECR, and forces a new ECS
service deployment.

### Manual redeploy commands

If you prefer to run the commands directly:

```bash
# Set common variables
AWS_REGION="${AWS_REGION:-us-east-1}"
AWS_ACCOUNT_ID=$(aws sts get-caller-identity --query Account --output text)
ECR="${AWS_ACCOUNT_ID}.dkr.ecr.${AWS_REGION}.amazonaws.com"
CLUSTER="okta-mcp-cluster"

# Authenticate to ECR
aws ecr get-login-password --region "$AWS_REGION" | \
  docker login --username AWS --password-stdin "$ECR"

# --- Adapter ---
docker buildx build --platform linux/amd64 \
  -t "${ECR}/okta-mcp-adapter:latest" \
  -f ../../Dockerfile ../.. --push
aws ecs update-service --cluster "$CLUSTER" --service adapter \
  --force-new-deployment --region "$AWS_REGION" --no-cli-pager

# --- Admin UI ---
docker buildx build --platform linux/amd64 \
  -t "${ECR}/okta-mcp-admin-ui:latest" \
  -f ../../okta_agent_proxy_admin_ui/Dockerfile \
  ../../okta_agent_proxy_admin_ui --push
aws ecs update-service --cluster "$CLUSTER" --service admin-ui \
  --force-new-deployment --region "$AWS_REGION" --no-cli-pager

# --- HR Backend ---
docker buildx build --platform linux/amd64 \
  -t "${ECR}/okta-mcp-hr-backend:latest" \
  -f ../../examples/01-hr-system/Dockerfile \
  ../../examples/01-hr-system --push
aws ecs update-service --cluster "$CLUSTER" --service hr-backend \
  --force-new-deployment --region "$AWS_REGION" --no-cli-pager

# --- Deploy Server ---
docker buildx build --platform linux/amd64 \
  -t "${ECR}/okta-mcp-deploy-server:latest" \
  -f ../../examples/05-deploy-server/Dockerfile \
  ../../examples/05-deploy-server --push
aws ecs update-service --cluster "$CLUSTER" --service deploy-server \
  --force-new-deployment --region "$AWS_REGION" --no-cli-pager

# Wait for all services to stabilize
aws ecs wait services-stable --cluster "$CLUSTER" \
  --services adapter admin-ui hr-backend --region "$AWS_REGION"
```

### CodeBuild alternative

If you're using CodeBuild instead of local Docker, rebuild all
images via CodeBuild and then force new deployments:

```bash
./build-codebuild.sh
aws ecs update-service --cluster okta-mcp-cluster --service adapter \
  --force-new-deployment --region "$AWS_REGION" --no-cli-pager
aws ecs update-service --cluster okta-mcp-cluster --service admin-ui \
  --force-new-deployment --region "$AWS_REGION" --no-cli-pager
aws ecs update-service --cluster okta-mcp-cluster --service hr-backend \
  --force-new-deployment --region "$AWS_REGION" --no-cli-pager
```

CodeBuild rebuilds all three images in one build. There is no
per-component CodeBuild build — use local Docker for single-component
redeploys when possible.

5. Update deploy/aws-ecs/package.sh (from E12):

   Add the three new scripts to the list of files copied into
   ECS_DIR:
   - deploy-adapter.sh
   - deploy-ui.sh
   - deploy-backend.sh

   These must be included in the tarball so the packaged deployment
   supports quick redeploys.

6. Make all three scripts executable:
   chmod +x deploy/aws-ecs/deploy-adapter.sh
   chmod +x deploy/aws-ecs/deploy-ui.sh
   chmod +x deploy/aws-ecs/deploy-backend.sh
```

### Expected Output

- `deploy/aws-ecs/deploy-adapter.sh` — builds + pushes adapter image, forces ECS deployment, health checks
- `deploy/aws-ecs/deploy-ui.sh` — builds + pushes admin-ui image, forces ECS deployment
- `deploy/aws-ecs/deploy-backend.sh` — builds + pushes a demo backend by name, forces ECS deployment
- Updated `deploy/aws-ecs/README.md` with "Quick Redeploy" section including scripts, manual commands, and CodeBuild alternative
- Updated `deploy/aws-ecs/package.sh` to include the three new scripts in the tarball

---

## Prompt E14: [SUPERSEDED]

E14 has been superseded by E15. Do NOT execute E14. Go directly to E15.

---

## Prompt E15: Enterprise BYO Compatibility (Full Retrofit)

### Context

The ECS deployment (E1–E13) was designed for greenfield AWS accounts where the operator owns the entire account and can create everything from scratch. Enterprise AWS accounts with existing infrastructure, Service Control Policies (SCPs), permission boundaries, and centralized resource management hit multiple blockers:

- **VPC quota exceeded** — cannot create a new VPC (default limit: 5 per region)
- **Secrets Manager `UntagResource` denied** — SCP restricts tag modification
- **ECR immutable tags required** — SCP forbids `MUTABLE` image tag mutability
- **ACM certificates centrally managed** — applications reference existing cert ARNs
- **KMS key creation denied** — only security team can create CMKs
- **Internet-facing ALBs denied** — SCP requires `scheme=internal`
- **WAF Web ACL mandatory** — ALBs must have a WAF attached
- **CloudWatch Logs naming convention** — `/aws/app/<team>/...` required
- **S3 bucket naming restrictions** — CodeBuild bucket doesn't match convention
- **Required tags** — SCP enforces `CostCenter`, `Owner`, `DataClassification`
- **IAM role path/boundary** — roles must use specific path with permissions boundary
- **Role naming convention** — names must match `<team>-<purpose>-<env>-role`

This prompt applies a single consistent pattern across all affected resources: for each resource, add a `byo_<resource>` variable (or equivalent), count-gate the resource creation, and use a computed local that resolves to either the created resource or an operator-provided existing one.

**Backward compatibility is non-negotiable:** All BYO variables default to `false` / empty strings. Existing greenfield deployments (E1–E13) show zero changes on `terraform plan`.

### Prompt

```
Retrofit the ECS deployment for enterprise AWS accounts with existing
infrastructure, centralized resource management, and Service Control
Policies (SCPs). Apply a consistent BYO pattern across all affected
resources.

Read deploy/aws-ecs/main.tf, deploy/aws-ecs/variables.tf,
deploy/aws-ecs/outputs.tf, deploy/aws-ecs/deploy.sh, and
deploy/aws-ecs/README.md to understand the current patterns.

CRITICAL REQUIREMENT: This retrofit must be fully backward compatible.
Every new variable defaults to greenfield behavior (create new resources).
terraform plan on an existing E1-E13 deployment must show zero changes.

The BYO pattern applied uniformly:
  1. Add variable byo_<resource> (bool, default false) OR
     variable existing_<resource>_arn (string, default "")
  2. count = var.byo_<resource> ? 0 : 1  on the resource block
  3. locals { <resource>_ref = var.byo_<resource> ? var.existing_<resource>_arn : aws_<resource>.this[0].arn }
  4. Update all downstream references to use local.<resource>_ref

PART 1: VARIABLES

Add these variables to deploy/aws-ecs/variables.tf, organized by
resource group. Include validation blocks where the BYO mode requires
an accompanying input:

Group A — VPC and Networking:

  variable "use_existing_vpc" {
    type        = bool
    default     = false
    description = "Deploy into an existing VPC instead of creating a new one. When true, provide existing_vpc_id and subnet IDs."
  }

  variable "existing_vpc_id" {
    type        = string
    default     = ""
    description = "Existing VPC ID. Required when use_existing_vpc = true. VPC must have DNS hostnames and DNS support enabled."
    validation {
      condition     = var.use_existing_vpc == false || length(var.existing_vpc_id) > 0
      error_message = "existing_vpc_id is required when use_existing_vpc = true."
    }
  }

  variable "existing_private_subnet_ids" {
    type        = list(string)
    default     = []
    description = "Private subnet IDs (2+ across different AZs) for ECS tasks, RDS, and ElastiCache. Must have NAT Gateway egress."
    validation {
      condition     = var.use_existing_vpc == false || length(var.existing_private_subnet_ids) >= 2
      error_message = "At least 2 private subnets in different AZs required when use_existing_vpc = true."
    }
  }

  variable "existing_public_subnet_ids" {
    type        = list(string)
    default     = []
    description = "Public subnet IDs (2+ across different AZs) for the ALB. Required unless alb_scheme = 'internal'."
    validation {
      condition     = var.use_existing_vpc == false || var.alb_scheme == "internal" || length(var.existing_public_subnet_ids) >= 2
      error_message = "At least 2 public subnets required when use_existing_vpc = true and alb_scheme != 'internal'."
    }
  }

Group B — ALB:

  variable "alb_scheme" {
    type        = string
    default     = "internet-facing"
    description = "ALB scheme: 'internet-facing' or 'internal'. Enterprise environments may require 'internal' with separate ingress (TGW, PrivateLink)."
    validation {
      condition     = contains(["internet-facing", "internal"], var.alb_scheme)
      error_message = "alb_scheme must be 'internet-facing' or 'internal'."
    }
  }

  variable "existing_waf_web_acl_arn" {
    type        = string
    default     = ""
    description = "ARN of an existing WAF v2 Web ACL to associate with the ALB. Leave empty to skip WAF association (default) or require WAF creation by a separate process."
  }

  variable "alb_access_logs_s3_bucket" {
    type        = string
    default     = ""
    description = "Name of an existing S3 bucket for ALB access logs. Leave empty to skip access logging. The bucket must have the ELB service account as a writer (see AWS docs)."
  }

Group C — ACM Certificate:

  variable "existing_acm_certificate_arn" {
    type        = string
    default     = ""
    description = "ARN of an existing ACM certificate covering the adapter and admin hostnames. When set, Terraform skips certificate creation and DNS validation. Most common enterprise pattern: wildcard cert managed by a central team."
  }

Group D — ECR:

  variable "byo_ecr_repos" {
    type        = bool
    default     = false
    description = "Use existing ECR repositories instead of creating them. When true, provide the three existing repo URLs."
  }

  variable "existing_ecr_adapter_url" {
    type        = string
    default     = ""
    description = "Existing ECR repository URL for the adapter image (e.g., 123456789012.dkr.ecr.us-east-1.amazonaws.com/myorg/adapter). Required when byo_ecr_repos = true."
  }

  variable "existing_ecr_admin_ui_url" {
    type        = string
    default     = ""
    description = "Existing ECR repository URL for the admin UI image. Required when byo_ecr_repos = true."
  }

  variable "existing_ecr_hr_backend_url" {
    type        = string
    default     = ""
    description = "Existing ECR repository URL for the hr-backend image. Required when byo_ecr_repos = true."
  }

  variable "ecr_image_tag_mutability" {
    type        = string
    default     = "MUTABLE"
    description = "Image tag mutability for created ECR repos. Enterprise environments may require 'IMMUTABLE'. When IMMUTABLE, redeploy scripts must use unique tags (not :latest)."
    validation {
      condition     = contains(["MUTABLE", "IMMUTABLE"], var.ecr_image_tag_mutability)
      error_message = "ecr_image_tag_mutability must be 'MUTABLE' or 'IMMUTABLE'."
    }
  }

  variable "ecr_scan_on_push" {
    type        = bool
    default     = true
    description = "Enable image scanning on push. Set to false if the account uses ECR Enhanced Scanning (account-level)."
  }

Group E — KMS:

  variable "existing_kms_key_arn_rds" {
    type        = string
    default     = ""
    description = "ARN of an existing CMK for RDS encryption. Leave empty to use the AWS-managed RDS key (default)."
  }

  variable "existing_kms_key_arn_elasticache" {
    type        = string
    default     = ""
    description = "ARN of an existing CMK for ElastiCache encryption. Leave empty to use the AWS-managed key."
  }

  variable "existing_kms_key_arn_secrets" {
    type        = string
    default     = ""
    description = "ARN of an existing CMK for Secrets Manager encryption. Leave empty to use the AWS-managed aws/secretsmanager key."
  }

  variable "existing_kms_key_arn_logs" {
    type        = string
    default     = ""
    description = "ARN of an existing CMK for CloudWatch Logs encryption. Leave empty to use default encryption."
  }

Group F — CloudWatch Logs:

  variable "log_group_prefix" {
    type        = string
    default     = "/ecs/oktaps-mcp"
    description = "Prefix for CloudWatch log group names. Adjust to match organizational naming conventions (e.g., '/aws/app/oktaps-mcp')."
  }

  variable "log_group_retention_days" {
    type        = number
    default     = 30
    description = "CloudWatch log retention period in days. Enterprise accounts may require minimum 90 days."
  }

Group G — S3 (CodeBuild):

  variable "existing_codebuild_source_bucket" {
    type        = string
    default     = ""
    description = "Name of an existing S3 bucket for CodeBuild source uploads. Leave empty to create a new bucket (default)."
  }

  variable "codebuild_source_bucket_name" {
    type        = string
    default     = ""
    description = "Name to use when creating a new CodeBuild source bucket. Leave empty to use the default pattern 'oktaps-mcp-codebuild-<account_id>'."
  }

Group H — RDS Enterprise Config:

  variable "rds_parameter_group_name" {
    type        = string
    default     = ""
    description = "Existing RDS parameter group name. Leave empty to use the AWS default parameter group."
  }

  variable "rds_deletion_protection" {
    type        = bool
    default     = false
    description = "Enable RDS deletion protection. Production deployments should set to true. Must be false (default) for clean terraform destroy in demo environments."
  }

  variable "rds_backup_retention_days" {
    type        = number
    default     = 7
    description = "RDS automated backup retention in days. Enterprise accounts may require 30+."
  }

Group I — ElastiCache Enterprise Config:

  variable "elasticache_parameter_group_name" {
    type        = string
    default     = ""
    description = "Existing ElastiCache parameter group name. Leave empty to use the AWS default."
  }

Group J — Tags:

  variable "additional_tags" {
    type        = map(string)
    default     = {}
    description = "Additional tags merged into all resources. Use to satisfy organizational tag requirements (CostCenter, Owner, DataClassification, etc.)."
  }

  variable "skip_resource_tagging_on_secrets" {
    type        = bool
    default     = false
    description = "When true, Secrets Manager secrets are created without tags. Set when the SCP restricts secretsmanager:UntagResource."
  }

Group K — IAM:

  variable "iam_role_path" {
    type        = string
    default     = "/"
    description = "Path for IAM roles. Enterprise accounts may require '/app/' or '/deployment/'."
  }

  variable "iam_permissions_boundary" {
    type        = string
    default     = ""
    description = "ARN of the IAM permissions boundary to attach to all created roles. Leave empty if not required."
  }

  variable "iam_role_name_prefix" {
    type        = string
    default     = "oktaps-mcp"
    description = "Name prefix for IAM roles. Adjust to match organizational naming conventions."
  }

Group L — EC2/Fargate:

  variable "fargate_spot_enabled" {
    type        = bool
    default     = false
    description = "Enable FARGATE_SPOT as a capacity provider. Some SCPs block spot. Default false for enterprise compatibility."
  }

PART 2: LOCALS

Update the locals block in main.tf to add computed references:

locals {
  project_name = "oktaps-mcp"

  common_tags = merge(
    {
      Project     = "oktaps-mcp-adapter"
      Environment = var.deployment_size
      ManagedBy   = "terraform"
    },
    var.additional_tags
  )

  # VPC and networking
  vpc_id = var.use_existing_vpc ? var.existing_vpc_id : aws_vpc.main[0].id

  private_subnet_ids = var.use_existing_vpc ? var.existing_private_subnet_ids : [
    aws_subnet.private_a[0].id,
    aws_subnet.private_b[0].id,
  ]

  public_subnet_ids = var.use_existing_vpc ? var.existing_public_subnet_ids : [
    aws_subnet.public_a[0].id,
    aws_subnet.public_b[0].id,
  ]

  # ECR
  ecr_adapter_url    = var.byo_ecr_repos ? var.existing_ecr_adapter_url    : aws_ecr_repository.adapter[0].repository_url
  ecr_admin_ui_url   = var.byo_ecr_repos ? var.existing_ecr_admin_ui_url   : aws_ecr_repository.admin_ui[0].repository_url
  ecr_hr_backend_url = var.byo_ecr_repos ? var.existing_ecr_hr_backend_url : aws_ecr_repository.hr_backend[0].repository_url

  # ACM
  acm_certificate_arn = var.existing_acm_certificate_arn != "" ? var.existing_acm_certificate_arn : aws_acm_certificate.this[0].arn

  # CodeBuild S3
  codebuild_source_bucket = var.existing_codebuild_source_bucket != "" ? var.existing_codebuild_source_bucket : (
    var.codebuild_source_bucket_name != "" ? var.codebuild_source_bucket_name : "oktaps-mcp-codebuild-${data.aws_caller_identity.current.account_id}"
  )

  # IAM role names
  iam_role_ecs_task_execution = "${var.iam_role_name_prefix}-ecs-task-execution"
  iam_role_ecs_task           = "${var.iam_role_name_prefix}-ecs-task"
  iam_role_codebuild          = "${var.iam_role_name_prefix}-codebuild"
}

PART 3: COUNT-GATE AND UPDATE RESOURCES

For EACH resource below, add count = var.<byo_var> ? 0 : 1 and update
all downstream references to use the computed locals from Part 2.

3a. VPC resources (count = var.use_existing_vpc ? 0 : 1):
    - aws_vpc.main
    - aws_subnet.public_a, public_b, private_a, private_b
    - aws_internet_gateway.main
    - aws_eip.nat
    - aws_nat_gateway.main
    - aws_route_table.public, private
    - aws_route_table_association.public_a, public_b, private_a, private_b
    - aws_route.public_internet, private_nat

    Update all security groups to use local.vpc_id instead of aws_vpc.main.id.
    Update aws_db_subnet_group.main to use local.private_subnet_ids.
    Update aws_elasticache_subnet_group.main to use local.private_subnet_ids.
    Update aws_lb.main to use local.public_subnet_ids.
    Update ECS services network_configuration to use local.private_subnet_ids.
    Update aws_service_discovery_private_dns_namespace.main to use local.vpc_id.

3b. ECR repositories (count = var.byo_ecr_repos ? 0 : 1):
    - aws_ecr_repository.adapter
    - aws_ecr_repository.admin_ui
    - aws_ecr_repository.hr_backend
    - aws_ecr_lifecycle_policy resources

    Update:
    - image_tag_mutability = var.ecr_image_tag_mutability
    - image_scanning_configuration.scan_on_push = var.ecr_scan_on_push

    Update ECS task definitions to reference local.ecr_*_url instead of
    aws_ecr_repository.*.repository_url.

    Update the operator policy ecr permissions to cover both ARN patterns
    (self-created + existing). Simplest: use Resource = "*" for ECR
    permissions when byo_ecr_repos = true, or add the existing ARN to
    the policy's resource list.

3c. ACM certificate (count = var.existing_acm_certificate_arn == "" ? 1 : 0):
    - aws_acm_certificate.this
    - aws_acm_certificate_validation.this
    - aws_route53_record.cert_validation (Tier 1/2 only)
    - null_resource.external_dns_instructions (Tier 3 only)

    Update ALB listener certificate_arn to use local.acm_certificate_arn.
    Update all outputs that expose the certificate ARN.

3d. ALB with scheme and WAF changes:
    - aws_lb.main: internal = var.alb_scheme == "internal"
    - aws_lb.main: subnets = var.alb_scheme == "internal" ? local.private_subnet_ids : local.public_subnet_ids
    - When alb_scheme = "internal", the ALB uses PRIVATE subnets (not public).
      Document: customer needs separate ingress (TGW, PrivateLink, VPN).

    - Add aws_lb.main access_logs block, conditional:
      dynamic "access_logs" {
        for_each = var.alb_access_logs_s3_bucket != "" ? [1] : []
        content {
          bucket  = var.alb_access_logs_s3_bucket
          enabled = true
          prefix  = "oktaps-mcp-alb"
        }
      }

    - Add WAF association, conditional:
      resource "aws_wafv2_web_acl_association" "alb" {
        count        = var.existing_waf_web_acl_arn != "" ? 1 : 0
        resource_arn = aws_lb.main.arn
        web_acl_arn  = var.existing_waf_web_acl_arn
      }

    - When alb_scheme = "internal", skip Route53 alias records (they
      would point to an internal ALB which external DNS can't resolve
      anyway). Add count logic to the Route53 alias records:
      count = var.dns_provider != "external" && var.alb_scheme != "internal" ? 1 : 0

    - Add local variable and output:
      locals {
        alb_scheme = var.alb_scheme
      }
      output "alb_scheme" { value = var.alb_scheme }

3e. KMS conditional encryption:

    RDS — add kms_key_id:
    resource "aws_db_instance" "this" {
      ...
      storage_encrypted = true
      kms_key_id = var.existing_kms_key_arn_rds != "" ? var.existing_kms_key_arn_rds : null
      # When kms_key_id is null AND storage_encrypted = true, AWS uses aws/rds managed key
    }

    ElastiCache — add kms_key_id:
    resource "aws_elasticache_replication_group" "main" {
      ...
      at_rest_encryption_enabled = true
      kms_key_id = var.existing_kms_key_arn_elasticache != "" ? var.existing_kms_key_arn_elasticache : null
    }

    Secrets Manager — add kms_key_id:
    For EACH aws_secretsmanager_secret resource, add:
    kms_key_id = var.existing_kms_key_arn_secrets != "" ? var.existing_kms_key_arn_secrets : null

    CloudWatch Logs — add kms_key_id:
    resource "aws_cloudwatch_log_group" "adapter" {
      name              = "${var.log_group_prefix}/adapter"
      retention_in_days = var.log_group_retention_days
      kms_key_id        = var.existing_kms_key_arn_logs != "" ? var.existing_kms_key_arn_logs : null
      tags              = local.common_tags
    }
    (Same for admin_ui and hr_backend log groups)

3f. CloudWatch Logs naming and retention:
    Already covered in 3e above — all log groups use var.log_group_prefix
    and var.log_group_retention_days.

3g. S3 CodeBuild source (count = var.existing_codebuild_source_bucket == "" && var.enable_codebuild ? 1 : 0):
    - aws_s3_bucket.codebuild_source
    - aws_s3_bucket_versioning.codebuild_source

    Update CodeBuild project source.location to use local.codebuild_source_bucket:
    source {
      type     = "S3"
      location = "${local.codebuild_source_bucket}/source.zip"
    }

    Update build-codebuild.sh to use the computed bucket name.

3h. RDS parameter group and enterprise config:
    - aws_db_instance.this:
        parameter_group_name = var.rds_parameter_group_name != "" ? var.rds_parameter_group_name : null
        deletion_protection = var.rds_deletion_protection
        backup_retention_period = var.rds_backup_retention_days

3i. ElastiCache parameter group:
    - aws_elasticache_replication_group.main:
        parameter_group_name = var.elasticache_parameter_group_name != "" ? var.elasticache_parameter_group_name : null
    (Serverless cache doesn't support parameter groups, so no change there)

3j. Secrets Manager conditional tagging:
    For EACH aws_secretsmanager_secret resource:
    tags = var.skip_resource_tagging_on_secrets ? {} : local.common_tags

    Add comment explaining why:
    # Tags are conditionally applied because some AWS Organizations
    # restrict secretsmanager:UntagResource via SCP. Set
    # skip_resource_tagging_on_secrets = true in those environments.

3k. IAM roles — path, boundary, and naming:
    For EACH aws_iam_role resource (ecs_task_execution, ecs_task, codebuild):
      name                 = local.iam_role_<role>  # from locals
      path                 = var.iam_role_path
      permissions_boundary = var.iam_permissions_boundary != "" ? var.iam_permissions_boundary : null

3l. Fargate spot capacity providers:
    resource "aws_ecs_cluster_capacity_providers" "main" {
      cluster_name = aws_ecs_cluster.main.name
      capacity_providers = var.fargate_spot_enabled ? ["FARGATE", "FARGATE_SPOT"] : ["FARGATE"]

      default_capacity_provider_strategy {
        base              = 1
        weight            = 100
        capacity_provider = "FARGATE"
      }
    }

PART 4: OUTPUTS

Update deploy/aws-ecs/outputs.tf:

Replace direct resource references with computed locals:
  vpc_id              = local.vpc_id
  ecr_adapter_url     = local.ecr_adapter_url
  ecr_admin_ui_url    = local.ecr_admin_ui_url
  ecr_hr_backend_url  = local.ecr_hr_backend_url
  acm_certificate_arn = local.acm_certificate_arn

Add new outputs:
  output "using_existing_vpc"         { value = var.use_existing_vpc }
  output "using_existing_acm_cert"    { value = var.existing_acm_certificate_arn != "" }
  output "using_existing_ecr_repos"   { value = var.byo_ecr_repos }
  output "alb_scheme"                 { value = var.alb_scheme }
  output "waf_attached"               { value = var.existing_waf_web_acl_arn != "" }

PART 5: ENTERPRISE PRE-FLIGHT SCRIPT

Create deploy/aws-ecs/preflight-enterprise.sh (executable):

#!/usr/bin/env bash
set -euo pipefail

# Enterprise compatibility pre-flight check
# Run BEFORE deploy.sh to identify organizational blockers before
# Terraform fails halfway through.

# Colors (same pattern as other scripts)
# info/ok/warn/die helpers

AWS_REGION="${AWS_REGION:-us-east-1}"

echo "Enterprise Pre-Flight Checks"
echo "============================"
echo ""
failures=()
warnings=()

# 1. VPC quota
current_vpcs=$(aws ec2 describe-vpcs --region "$AWS_REGION" \
  --query "length(Vpcs)" --output text)
vpc_quota=$(aws service-quotas get-service-quota \
  --service-code vpc --quota-code L-F678F1CE \
  --region "$AWS_REGION" \
  --query "Quota.Value" --output text 2>/dev/null || echo "5")
echo "VPCs: ${current_vpcs}/${vpc_quota}"
if (( ${current_vpcs%.*} >= ${vpc_quota%.*} )); then
  if [[ "${TF_VAR_use_existing_vpc:-false}" != "true" ]]; then
    failures+=("VPC quota reached. Set: export TF_VAR_use_existing_vpc=true")
  fi
fi

# 2. EIP quota
current_eips=$(aws ec2 describe-addresses --region "$AWS_REGION" \
  --query "length(Addresses)" --output text)
eip_quota=$(aws service-quotas get-service-quota \
  --service-code ec2 --quota-code L-0263D0A3 \
  --region "$AWS_REGION" \
  --query "Quota.Value" --output text 2>/dev/null || echo "5")
echo "Elastic IPs: ${current_eips}/${eip_quota}"
if (( ${current_eips%.*} >= ${eip_quota%.*} )) && [[ "${TF_VAR_use_existing_vpc:-false}" != "true" ]]; then
  failures+=("EIP quota reached. Use BYO-VPC mode.")
fi

# 3. Secrets Manager: test create + tag + untag
echo ""
echo "Testing Secrets Manager permissions..."
test_secret="oktaps-mcp-preflight-test-$$-$(date +%s)"
if aws secretsmanager create-secret \
     --name "$test_secret" \
     --secret-string "test" \
     --tags Key=PreflightTest,Value=true \
     --region "$AWS_REGION" --no-cli-pager >/dev/null 2>&1; then
  if aws secretsmanager untag-resource \
       --secret-id "$test_secret" \
       --tag-keys PreflightTest \
       --region "$AWS_REGION" --no-cli-pager >/dev/null 2>&1; then
    echo "  ✓ Secrets Manager tag/untag: OK"
  else
    warnings+=("Secrets Manager UntagResource denied. Set: export TF_VAR_skip_resource_tagging_on_secrets=true")
  fi
  aws secretsmanager delete-secret \
    --secret-id "$test_secret" \
    --force-delete-without-recovery \
    --region "$AWS_REGION" --no-cli-pager >/dev/null 2>&1 || true
else
  failures+=("secretsmanager:CreateSecret denied. Check SCPs and IAM.")
fi

# 4. ECR tag mutability test
echo ""
echo "Testing ECR tag mutability policy..."
test_repo="oktaps-mcp-preflight-test-$$-$(date +%s)"
if aws ecr create-repository \
     --repository-name "$test_repo" \
     --image-tag-mutability MUTABLE \
     --region "$AWS_REGION" --no-cli-pager >/dev/null 2>&1; then
  echo "  ✓ ECR MUTABLE tags: OK"
  aws ecr delete-repository --repository-name "$test_repo" \
    --region "$AWS_REGION" --force --no-cli-pager >/dev/null 2>&1 || true
else
  warnings+=("ECR MUTABLE tags denied. Set: export TF_VAR_ecr_image_tag_mutability=IMMUTABLE or use: export TF_VAR_byo_ecr_repos=true")
fi

# 5. ACM certificate request test (soft — may fail in enterprise)
echo ""
echo "Testing ACM certificate creation..."
# Don't actually request a cert (it would need DNS validation).
# Just check if the API is accessible.
if aws acm list-certificates --region "$AWS_REGION" --no-cli-pager >/dev/null 2>&1; then
  echo "  ✓ ACM API accessible"
else
  warnings+=("ACM API denied. Use: export TF_VAR_existing_acm_certificate_arn=<arn>")
fi

# 6. ALB creation — test describe (soft)
echo ""
echo "Testing ALB permissions..."
if aws elbv2 describe-load-balancers --region "$AWS_REGION" --no-cli-pager >/dev/null 2>&1; then
  echo "  ✓ ELBv2 API accessible"
else
  failures+=("elasticloadbalancing:DescribeLoadBalancers denied.")
fi

# 7. KMS key creation test (soft — don't actually create)
echo ""
echo "Testing KMS permissions..."
if aws kms list-keys --limit 1 --region "$AWS_REGION" --no-cli-pager >/dev/null 2>&1; then
  echo "  ✓ KMS API accessible"
else
  warnings+=("KMS API restricted. Provide existing CMK ARNs via TF_VAR_existing_kms_key_arn_*.")
fi

# 8. IAM role creation test with specified path
echo ""
iam_path="${TF_VAR_iam_role_path:-/}"
echo "Testing IAM role creation (path=$iam_path)..."
test_role="oktaps-mcp-preflight-test-$$-$(date +%s)"
if aws iam create-role \
     --role-name "$test_role" \
     --path "$iam_path" \
     --assume-role-policy-document '{
       "Version":"2012-10-17",
       "Statement":[{
         "Effect":"Allow",
         "Principal":{"Service":"ecs-tasks.amazonaws.com"},
         "Action":"sts:AssumeRole"
       }]
     }' --no-cli-pager >/dev/null 2>&1; then
  echo "  ✓ IAM role creation at $iam_path: OK"
  aws iam delete-role --role-name "$test_role" --no-cli-pager >/dev/null 2>&1 || true
else
  failures+=("iam:CreateRole denied at path '$iam_path'. Check SCPs/permission boundaries.")
fi

# 9. Tag policies check
echo ""
echo "Checking for Organization tag policies..."
if aws organizations list-policies --filter TAG_POLICY \
     --no-cli-pager >/dev/null 2>&1; then
  tag_policies=$(aws organizations list-policies --filter TAG_POLICY \
    --query "length(Policies)" --output text 2>/dev/null || echo "0")
  if (( tag_policies > 0 )); then
    warnings+=("Organization has ${tag_policies} tag policies. Set required tags via TF_VAR_additional_tags.")
  fi
else
  echo "  ℹ Cannot query Organization policies (not an error — may be cross-account)"
fi

# 10. Internet-facing ALB test (by attempting describe on a test SG for ELB)
echo ""
echo "Checking internet-facing ALB eligibility..."
# Attempt to detect common SCP: "deny creating internet-facing LBs"
# We can't perfectly test this without creating one, but we can warn.
if [[ "${TF_VAR_alb_scheme:-internet-facing}" == "internet-facing" ]]; then
  echo "  ℹ Cannot pre-verify internet-facing ALB SCP — will fail at apply if denied."
  echo "    If it fails: export TF_VAR_alb_scheme=internal + set up alternate ingress."
fi

# Summary
echo ""
echo "============================"
if [[ ${#failures[@]} -eq 0 && ${#warnings[@]} -eq 0 ]]; then
  echo "✓ All pre-flight checks passed"
elif [[ ${#failures[@]} -eq 0 ]]; then
  echo "✓ No blockers found"
  echo ""
  echo "⚠ ${#warnings[@]} warning(s):"
  for w in "${warnings[@]}"; do
    echo "  → $w"
  done
  echo ""
  echo "Warnings are recommendations based on detected policies."
  echo "The deployment may still work; adjust variables as needed."
else
  echo "✗ ${#failures[@]} blocker(s) found:"
  for f in "${failures[@]}"; do
    echo "  → $f"
  done
  if [[ ${#warnings[@]} -gt 0 ]]; then
    echo ""
    echo "⚠ ${#warnings[@]} warning(s):"
    for w in "${warnings[@]}"; do
      echo "  → $w"
    done
  fi
  echo ""
  echo "Fix blockers before running deploy.sh."
  exit 1
fi

Make executable: chmod +x deploy/aws-ecs/preflight-enterprise.sh

PART 6: DEPLOY.SH UPDATES

Update deploy/aws-ecs/deploy.sh:

In the pre-flight section, add a BYO mode verification:
- If use_existing_vpc=true, verify VPC and subnets exist
- If byo_ecr_repos=true, verify repos exist
- If existing_acm_certificate_arn is set, verify the cert exists and
  is in the ISSUED state

Update the summary box to show BYO mode status:
  │  VPC:      <existing vpc-abc123> (BYO) or <new vpc-xyz789>     │
  │  ACM:      <existing arn:...> (BYO) or <created>               │
  │  ECR:      <BYO: using existing repos> or <3 new repos>        │
  │  ALB:      <internet-facing> or <internal — use TGW/PrivateLink>│
  │  WAF:      <attached> or <not attached>                        │

PART 7: README UPDATES

Update deploy/aws-ecs/README.md. Add a new top-level section
"Enterprise Deployment" right after "DNS Provider Options":

## Enterprise Deployment

If your AWS account is part of an Organization with existing
infrastructure, SCPs, permission boundaries, or centralized resource
management, run the enterprise pre-flight check first:

```bash
./preflight-enterprise.sh
```

This probes your account for 10 common enterprise blockers and prints
actionable remediation steps.

### BYO (Bring Your Own) resource modes

Every major AWS resource supports BYO mode — you provide an existing
resource ARN/ID instead of having Terraform create one:

| Resource | BYO Variable | When to use |
|---|---|---|
| VPC + subnets | `TF_VAR_use_existing_vpc=true` + IDs | VPC quota exceeded; networking team manages VPCs |
| ECR repositories | `TF_VAR_byo_ecr_repos=true` + URLs | Central image registry; immutable tag policy |
| ACM certificate | `TF_VAR_existing_acm_certificate_arn=<arn>` | Wildcard cert managed centrally |
| KMS keys (RDS/Redis/Secrets/Logs) | `TF_VAR_existing_kms_key_arn_*=<arn>` | KMS creation restricted to security team |
| S3 bucket (CodeBuild) | `TF_VAR_existing_codebuild_source_bucket=<name>` | Bucket naming restrictions |
| WAF Web ACL | `TF_VAR_existing_waf_web_acl_arn=<arn>` | Central WAF with shared rules |

### Other enterprise variables

| Variable | Default | Enterprise Use |
|---|---|---|
| `alb_scheme` | `internet-facing` | Set to `internal` when public ALBs are denied (requires TGW/PrivateLink for external access) |
| `alb_access_logs_s3_bucket` | (none) | Set to central log bucket name |
| `ecr_image_tag_mutability` | `MUTABLE` | Set to `IMMUTABLE` if SCP requires |
| `ecr_scan_on_push` | `true` | Set to `false` if account uses Enhanced Scanning |
| `log_group_prefix` | `/ecs/oktaps-mcp` | Adjust to match naming convention (e.g., `/aws/app/oktaps-mcp`) |
| `log_group_retention_days` | `30` | Set to 90+ for compliance requirements |
| `rds_parameter_group_name` | (AWS default) | Specify custom parameter group |
| `rds_deletion_protection` | `false` | Set to `true` for production |
| `rds_backup_retention_days` | `7` | Set to 30+ for compliance |
| `fargate_spot_enabled` | `false` | Default for enterprise (some SCPs block spot) |
| `additional_tags` | `{}` | Required tag keys (CostCenter, Owner, etc.) |
| `skip_resource_tagging_on_secrets` | `false` | Set when SCP blocks `secretsmanager:UntagResource` |
| `iam_role_path` | `/` | Set to required path (e.g., `/app/`) |
| `iam_permissions_boundary` | (none) | Set to required boundary ARN |
| `iam_role_name_prefix` | `oktaps-mcp` | Adjust to match naming convention |

### Information to gather from your AWS administrator

Before deployment, use this checklist:

| Item | Example | Where to find it |
|---|---|---|
| VPC ID | `vpc-0abc...` | VPC Console → Your VPCs (filter by team tag) |
| Private subnet IDs | `subnet-0aaa...`, `subnet-0bbb...` | VPC Console → Subnets |
| Public subnet IDs | `subnet-0ccc...`, `subnet-0ddd...` | VPC Console → Subnets |
| Internet-facing ALB allowed? | yes/no | Ask platform team (check SCPs) |
| WAF Web ACL ARN | `arn:aws:wafv2:...` | WAF Console → Web ACLs (regional) |
| Existing ACM cert ARN | `arn:aws:acm:...` | ACM Console (must cover your hostnames) |
| Required tag keys | CostCenter, Owner, Team | Ask platform team |
| IAM role path | `/app/` or `/` | Ask security team |
| Permissions boundary ARN | `arn:aws:iam::...` | Ask security team |
| KMS CMK ARNs (RDS, Redis, Secrets, Logs) | `arn:aws:kms:...` | KMS Console (ask for pre-approved keys) |
| Log group naming convention | `/aws/app/<team>/...` | Ask platform team |
| Log retention policy | 30 / 90 / 365 days | Ask security/compliance team |
| RDS parameter group name | `custom-postgres15-audit` | Ask platform team |
| S3 bucket for CodeBuild source | `myorg-deployments-us-east-1` | Ask platform team |
| Route53 zone ID (if BYO DNS) | `Z0123456...` | Route53 Console (or Tier 2/3 from DNS guide) |
| Fargate Spot allowed? | yes/no | Check SCPs |

### Sample enterprise deployment

```bash
# Networking (from your networking team)
export TF_VAR_use_existing_vpc=true
export TF_VAR_existing_vpc_id="vpc-0abc123"
export TF_VAR_existing_private_subnet_ids='["subnet-0aaa","subnet-0bbb"]'
export TF_VAR_existing_public_subnet_ids='["subnet-0ccc","subnet-0ddd"]'

# ALB + WAF (from your platform team)
export TF_VAR_alb_scheme="internet-facing"
export TF_VAR_existing_waf_web_acl_arn="arn:aws:wafv2:us-east-1:123456789012:regional/webacl/central-waf/abc-123"
export TF_VAR_alb_access_logs_s3_bucket="myorg-alb-logs-us-east-1"

# Certificate (from your certificate management team)
export TF_VAR_existing_acm_certificate_arn="arn:aws:acm:us-east-1:123456789012:certificate/wildcard-abc"

# KMS (from your security team)
export TF_VAR_existing_kms_key_arn_rds="arn:aws:kms:us-east-1:123456789012:key/rds-cmk-id"
export TF_VAR_existing_kms_key_arn_secrets="arn:aws:kms:us-east-1:123456789012:key/secrets-cmk-id"
export TF_VAR_existing_kms_key_arn_logs="arn:aws:kms:us-east-1:123456789012:key/logs-cmk-id"

# IAM (from your security team)
export TF_VAR_iam_role_path="/app/oktaps/"
export TF_VAR_iam_permissions_boundary="arn:aws:iam::123456789012:policy/AppBoundary"

# Tags (from your platform team)
export TF_VAR_additional_tags='{"CostCenter":"IT-12345","Owner":"joey@okta.com","DataClassification":"Internal"}'
export TF_VAR_skip_resource_tagging_on_secrets=true  # if SCP blocks untag

# Logs
export TF_VAR_log_group_prefix="/aws/app/oktaps-mcp"
export TF_VAR_log_group_retention_days=90

# RDS hardening
export TF_VAR_rds_deletion_protection=true
export TF_VAR_rds_backup_retention_days=30

# Standard deployment variables (same as greenfield)
export TF_VAR_okta_domain="..."
export TF_VAR_adapter_hostname="..."
# etc.

# Run pre-flight, then deploy
./preflight-enterprise.sh
./deploy.sh --apply
```

PART 8: PACKAGE.SH UPDATE

Update deploy/aws-ecs/package.sh to include preflight-enterprise.sh
in the list of files copied to the tarball.

PART 9: VERIFICATION

Run terraform fmt and terraform validate.

Run terraform plan against an existing E1-E13 deployment (greenfield
configuration, no BYO vars set). The plan MUST show zero changes.
If changes are shown, the backward compatibility is broken and must
be fixed before proceeding.
```

### Expected Output

- 25+ new variables in `variables.tf` organized in 12 groups
- Count-gated VPC, ECR, ACM, S3 (CodeBuild) resources
- Computed locals for VPC, ECR, ACM, CodeBuild bucket, IAM role names
- KMS conditional encryption on RDS, ElastiCache, Secrets Manager, CloudWatch Logs
- ALB scheme toggle (`internet-facing` / `internal`) with appropriate subnet + DNS handling
- WAF association (conditional on `existing_waf_web_acl_arn`)
- ALB access logs (conditional on `alb_access_logs_s3_bucket`)
- Conditional tagging on Secrets Manager
- IAM role path, permissions boundary, and name prefix on all roles
- Fargate spot toggle
- `preflight-enterprise.sh` — new executable with 10 compatibility probes
- Updated `deploy.sh` with BYO verification and enhanced summary box
- Updated `README.md` with "Enterprise Deployment" section
- Updated `package.sh` to include `preflight-enterprise.sh`
- `terraform plan` on existing greenfield deployment shows ZERO changes

---

## Post-Deployment Checklist

After running `./deploy.sh --apply`:

1. **Update Okta redirect URIs** — the deploy summary box prints the exact URIs to add to your Okta OIDC apps
2. **Sign in to Admin UI** — navigate to `https://<admin_hostname>` and authenticate with Okta
3. **Register agents and resources** — use the Admin UI or Admin API
4. **Run smoke tests** — `./smoke-test.sh` to verify end-to-end
5. **Stop when idle** — `./stop.sh` to drop to ~$15-20/mo

## Cost Summary

| Deployment Size | Active | Stopped | 1-yr Savings Plan |
|---|---|---|---|
| Demo | ~$90–120/mo | ~$15–20/mo | n/a |
| Small-prod | ~$200–250/mo | ~$30–40/mo | ~$160–200/mo |

## Next Steps

After the ECS pack is deployed and validated, the EKS production pack (K1–K14) provides the heavier-weight Kubernetes deployment for larger production environments at ~$785/mo. The EKS pack mirrors the `deploy/gcp/` two-phase Terraform shape and adds HPA, PDB, NetworkPolicies, WAF, Karpenter, and Secrets Store CSI Driver.
