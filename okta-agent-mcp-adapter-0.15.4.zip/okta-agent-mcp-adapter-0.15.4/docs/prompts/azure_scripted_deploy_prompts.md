> **Historical (pre-v0.15.x):** Password-based admin login references in this document are obsolete. The adapter accepts only Okta OAuth access tokens — see [docs/OPERATIONS.md § Admin API Authentication](../OPERATIONS.md#admin-api-authentication).

# Okta MCP Adapter — Azure Scripted Deploy Wizards

## Implementation Prompts (Scaffolding + Phase 1)

**6 Prompts • Sequential • Builds runnable bash wizards for AKS production and Container Apps demo**

---

## Overview

This pack tells Claude Code how to build **two real, runnable deployment wizards** for Azure that mirror the existing `deploy/aws-ec2/awsetup.sh` pattern. The deliverable is bash scripts that a dev/ops team can `chmod +x` and run themselves — there is no AI in the loop at deploy time.

This is explicitly **not** the same thing as the earlier "Azure Deployment Prompts" pack. That pack was Claude-Code-driven (an SE pastes prompts, Claude does the deployment). This pack produces shippable artifacts that work without Claude.

The two wizards being built:

| Wizard | Profile | Audience | Cost target |
|---|---|---|---|
| `deploy/azure-aks/azuresetup.sh` | Production AKS Automatic + managed Postgres + managed Redis + AGC ingress | Enterprise customer deployments | ~$700/mo |
| `deploy/azure-aca/acasetup.sh` | Demo Container Apps + Burstable Postgres + Basic Redis | SE-led POCs and customer evaluations | ~$70/mo active, ~$25/mo stopped |

This pack covers **scaffolding + Phase 1 of each wizard** as a working proof. Phases 2-4 of the AKS wizard and Phase 2 of the ACA wizard are follow-up work in subsequent prompt packs. After running these 6 prompts you will have:

- A working `azuresetup.sh --phase 1` that creates the foundation (RG, providers, ACR, VNet, subnets, private DNS, AKS Automatic, workload identity)
- A working `acasetup.sh --phase 1` that creates the foundation (RG, ACR, Postgres Burstable, Redis Basic, Container Apps environment)
- Shared `shell-lib/` between both wizards (logging, prompts, state, validation)
- Manifest templates, README files, env templates, and the package.sh tarball builder
- Both wizards verified to run cleanly against a throwaway Azure subscription

---

## What "scripted like aws-ec2" actually means

Reading `deploy/aws-ec2/awsetup.sh` shows the pattern has six load-bearing properties. The Azure wizards must have all six:

1. **Single-file entrypoint** at the top of the deploy directory that the operator runs
2. **Phased execution** with `--phase 1|2|3|4|all`, where each phase is independently re-runnable
3. **State file** (`.azuresetup.state`) that persists every discovered/chosen value as `KEY=VALUE` so a Ctrl+C or a failed phase can be picked up exactly where it died
4. **Shared library** under `shell-lib/` with logging, prompting, validation, and state helpers — so the main script reads cleanly
5. **Two execution modes**: interactive (prompts the operator for missing values) and `--non-interactive` (reads everything from `.env` + state file, fails if anything is missing)
6. **Ctrl+C trap** that writes a "rerun to resume" message and exits cleanly

Three things must be different from aws-ec2 because Azure is not AWS:

- **Long-running operations need spinners + retry, not just `wait`.** Postgres provisioning takes 8-12 min, Redis takes 15-20 min, AGC managed cert takes up to 30 min after DNS. aws-ec2 doesn't have any operations that long. Add a `wait_for_resource()` helper in `azure-helpers.sh` that polls every 15s with a spinner and a max timeout.
- **Two cleanup paths don't exist.** aws-ec2 has surgical teardown because the surrounding ALB and ACM cert can be reused. AKS doesn't work that way — `--destroy` should delete the entire resource group with `az group delete -n $AZURE_RG --yes --no-wait`. There's no middle ground worth supporting in a wizard.
- **The two profiles are separate wizards, not one with a `--profile` flag.** AKS and ACA share almost no Azure resources (no VNet, no Key Vault, no Helm in ACA). One conditional-laden wizard would be unmaintainable. Build two siblings that share `shell-lib/`.

---

## Prompt Map

| # | Prompt | Creates / Modifies | Est. Time |
|---|---|---|---|
| AZ1 | Reference audit | `reports/azure-wizard-audit.md` (read-only) | 10 min |
| AZ2 | Scaffold + shared shell-lib | `deploy/azure-aks/`, `deploy/azure-aca/`, `shell-lib/common.sh`, `shell-lib/azure-helpers.sh` | 30 min |
| AZ3 | AKS manifest templates | `deploy/azure-aks/manifests/*.yaml` (10 files) | 25 min |
| AZ4 | AKS Phase 1 wizard | `deploy/azure-aks/azuresetup.sh` (skeleton + Phase 1) | 45 min |
| AZ5 | ACA Phase 1 wizard + Bicep | `deploy/azure-aca/acasetup.sh` (skeleton + Phase 1), `deploy/azure-aca/bicep/main.bicep` (skeleton) | 35 min |
| AZ6 | Docs + package.sh + smoke verification | `README.md` (×2), `.env.example` (×2), `package.sh` (×2), dry-run smoke check | 25 min |

Total estimated implementation time: about 3 hours of Claude Code execution.

---

## Prerequisites

- Claude Code CLI authenticated and pointed at the `okta-agent-mcp-adapter` repository root
- Existing `deploy/aws-ec2/` directory present (the wizards are modeled on it)
- A clean working tree on a feature branch named `feat/azure-scripted-deploy`
- `az cli` installed locally (the smoke check in AZ6 will optionally exercise it against a throwaway subscription, but is not required for the build itself)

## How to Execute

Copy each prompt body into the Claude Code CLI in order. Each prompt is self-contained and idempotent. Wait for each to complete before starting the next, and commit after each successful prompt so you can bisect any regression.

```bash
# From the project root:
cd okta-agent-mcp-adapter
git checkout -b feat/azure-scripted-deploy

# Then paste each prompt body into Claude Code, one at a time.
# Commit after each green run:
git add -A && git commit -m "AZ<N>: <prompt title>"
```

---

## Prompt AZ1: Reference Audit

### Context

Before creating any new files, capture the conventions from `deploy/aws-ec2/` so the Azure wizards can mirror them exactly. This is read-only and writes a single report file. It exists so the implementation prompts that follow have a shared ground truth and so we don't accidentally invent new conventions when the existing ones already work.

### Prompt

*Copy the text below into Claude Code:*

```
Audit the existing deploy/aws-ec2/ directory and produce a reference
report for the Azure wizards we are about to build. Do NOT modify any
source files. Write the result to reports/azure-wizard-audit.md.

Steps:

1. Read deploy/aws-ec2/awsetup.sh end to end. Capture:
   - The flag-parsing block (--phase, --profile, --non-interactive,
     --skip-build, --with-observability, --help)
   - The Ctrl+C trap pattern
   - The version-resolution pattern (reading from pyproject.toml)
   - How phases are dispatched (function per phase, case statement
     at the bottom)
   - How state is loaded at the start of each phase function
   - How state is saved after each step within a phase
   - The colored output style (info / ok / warn / fail / die)
   - The summary box format printed at the end of each phase

2. Read deploy/aws-ec2/shell-lib/common.sh end to end. Capture:
   - The exact list of exported functions (info, ok, warn, fail, die,
     prompt_required, prompt_default, prompt_yesno, validate_command,
     check_port_available, save_state, load_state, get_state,
     and any AWS-specific helpers like _imds_get / detect_region)
   - Which functions are cloud-agnostic (we will reuse) vs AWS-specific
     (we will replace with Azure equivalents)
   - The state file format (.awsetup.state, key=value, one per line)

3. Read deploy/aws-ec2/package.sh end to end. Capture:
   - How VERSION is resolved (pyproject.toml grep)
   - The staging directory pattern
   - Which files are copied
   - Which patterns are excluded (CLAUDE.md, tests/, __pycache__, etc.)
   - How the tarball is named and where it lands
   - The --dry-run mode

4. Read deploy/aws-ec2/README.md if it exists. Capture:
   - The section structure
   - How prerequisites are listed
   - How the quick-start command is presented
   - How phases are documented

5. Look for and capture any other supporting files:
   - .env.template / .env.example
   - teardown.sh
   - status.sh
   - Anything under deploy/aws-ec2/ not already covered above

6. Write the report with these sections:
   - Executive Summary (3-5 bullets describing the awsetup.sh design)
   - File Inventory (table of every file with one-line description)
   - Function Catalog (every function in common.sh with cloud-agnostic
     vs cloud-specific classification)
   - State File Format (key=value example)
   - Phase Dispatch Pattern (code excerpt showing the case statement)
   - Color and Output Conventions (the exact ANSI codes and prefixes)
   - Summary Box Format (sample output from the end of a phase)
   - Conventions to Reuse Verbatim (functions, patterns, file layout)
   - Conventions to Replace for Azure (anything AWS-specific that needs
     an Azure equivalent — IMDSv2 helpers, AWS_REGION detection, etc.)
   - Recommended Azure helper functions (a list of az cli wrappers
     and waiters that the new shell-lib/azure-helpers.sh should expose)

Do NOT propose code changes in this report. Do NOT touch any file
outside of reports/. Only create reports/azure-wizard-audit.md.
```

### Expected Output

A single new file at `reports/azure-wizard-audit.md` with the complete inventory of `deploy/aws-ec2/`, the function catalog, and a clear list of what to reuse vs. what to add for Azure. No source files modified. Use this report as the reference for prompts AZ2 through AZ6.

---

## Prompt AZ2: Scaffold + Shared Shell Library

### Context

Creates the directory structure for both wizards and the shared shell library they will use. The cloud-agnostic functions from `aws-ec2/shell-lib/common.sh` (logging, prompts, state, validation) are copied verbatim — the audit report from AZ1 lists exactly which ones. The Azure-specific helpers (az cli wrappers, long-poll waiters, parallel kickoff) go in a new `azure-helpers.sh`.

This is the one place in the pack where we make a decision about file layout: both wizards live in their own top-level directories under `deploy/`, and the shared `shell-lib/` is **copied** into each, not symlinked. Symlinks are fragile across Windows checkouts and tarball builds. The duplication is small (<10 KB) and worth the simplicity.

### Prompt

*Copy the text below into Claude Code:*

```
Create the scaffolding for the Azure deployment wizards: two sibling
directories under deploy/, each with its own shell-lib/ copy.

Pre-check:
1. Read reports/azure-wizard-audit.md from AZ1. If it does not exist,
   stop and tell the operator to run AZ1 first.
2. Read deploy/aws-ec2/shell-lib/common.sh end to end so the new
   common.sh starts as an exact copy of the cloud-agnostic functions.

Requirements:

A. Directory creation

Create these directories with mkdir -p:

  deploy/azure-aks/
  deploy/azure-aks/shell-lib/
  deploy/azure-aks/manifests/
  deploy/azure-aca/
  deploy/azure-aca/shell-lib/
  deploy/azure-aca/bicep/

Add a .gitignore in each top-level directory (deploy/azure-aks/ and
deploy/azure-aca/) containing:
  .azuresetup.state
  .acasetup.state
  .env
  dist/

B. Shared common.sh — write to BOTH locations

Create deploy/azure-aks/shell-lib/common.sh AND
deploy/azure-aca/shell-lib/common.sh. They must be byte-identical
copies. The contents are an exact copy of the CLOUD-AGNOSTIC functions
from deploy/aws-ec2/shell-lib/common.sh:

  - Color constants block (RED, GREEN, YELLOW, CYAN, BOLD, NC) with
    NO_COLOR + non-TTY detection
  - Logging functions: info, ok, warn, fail, die
  - Prompt helpers: prompt_required, prompt_default, prompt_yesno
  - Validation helpers: validate_command, check_port_available
  - State management:
      STATE_FILE="${STATE_FILE:-.azuresetup.state}"
      save_state, load_state, get_state
    NOTE: change the default STATE_FILE name from .awsetup.state to
    .azuresetup.state for the AKS wizard. The ACA wizard will override
    STATE_FILE to .acasetup.state at the top of acasetup.sh before
    sourcing common.sh.

  Do NOT copy any of the AWS-specific helpers (_imds_token, _imds_get,
  detect_region, detect_instance_id, detect_vpc_id, detect_ec2_sg,
  find_public_subnets). Those are AWS-only and have no Azure analog.

  Add a header comment at the top of common.sh:
    # =============================================================
    # common.sh — Shared cloud-agnostic functions for Azure wizards
    # =============================================================
    # Source this file, do not execute it directly.
    # Adapted from deploy/aws-ec2/shell-lib/common.sh.
    # =============================================================

C. New azure-helpers.sh — write to BOTH locations

Create deploy/azure-aks/shell-lib/azure-helpers.sh AND
deploy/azure-aca/shell-lib/azure-helpers.sh as byte-identical copies.
The file must define these functions:

  1. az_login_check()
     - Verify `az account show` succeeds. If not, die with a clear
       message telling the operator to run `az login`.
     - If AZURE_SUBSCRIPTION_ID is set in env, also verify the active
       subscription matches it. If not, set it with `az account set`
       and warn that the active subscription was changed.

  2. az_provider_register PROVIDER
     - Registers a single provider and waits up to 5 min for it to
       reach "Registered" state.
     - Idempotent — does nothing if already registered.
     - Polls every 10 seconds, prints a single dot per poll for
       visible progress.
     - Returns nonzero if the timeout elapses.

  3. az_resource_exists RESOURCE_GROUP RESOURCE_TYPE NAME
     - Returns 0 if the resource exists, 1 if not.
     - Used by every "create or skip" check in the wizards.
     - Example call:
         if az_resource_exists $RG Microsoft.ContainerRegistry/registries $ACR_NAME; then
           ok "ACR $ACR_NAME already exists"
         else
           az acr create ...
         fi

  4. wait_for_resource RESOURCE_ID PROPERTY EXPECTED_VALUE [TIMEOUT_SEC]
     - Polls `az resource show --ids $RESOURCE_ID --query $PROPERTY -o tsv`
       every 15 seconds until the value matches EXPECTED_VALUE.
     - Default timeout 1800 seconds (30 min) for the long-pole
       operations like Postgres and Redis provisioning.
     - Prints a spinner character (cycling through | / - \) on the
       same line, with the elapsed time, e.g.:
         [INFO]  Waiting for redis cache okta-mcp-redis-1234... | 02:30
     - On success: clear the line and print [  OK] followed by the
       elapsed time.
     - On timeout: clear the line and die with a message containing
       the resource ID and the last observed value of the property.

  5. random_suffix [LENGTH]
     - Generates a random lowercase alphanumeric suffix of LENGTH
       characters (default 4) for globally-unique resource names.
     - Use openssl rand or /dev/urandom — must work on macOS and
       Linux without GNU coreutils.

  6. generate_password [LENGTH]
     - Generates a strong password of LENGTH characters (default 24).
     - Mix of uppercase, lowercase, digits, and the safe symbols
       !@#%^* (avoid characters that break shell quoting or URL
       encoding: $ & ' " \ / : ; < > ? = + space).
     - Used for Postgres admin and the adapter ADMIN_PASSWORD.

  7. generate_encryption_key
     - Returns a base64-encoded 32-byte AES-256 key.
     - Implementation: python3 -c "import os,base64; print(base64.b64encode(os.urandom(32)).decode())"
     - Falls back to openssl if python3 is unavailable.

  8. urlencode_password PASSWORD
     - URL-encodes a password for safe inclusion in a postgres://
       connection string.
     - Implementation: python3 -c 'import sys,urllib.parse; print(urllib.parse.quote(sys.argv[1], safe=""))'
       — pass the password as a command-line arg, NOT via stdin or
       env, to avoid shell quoting issues. Use a heredoc-style
       sys.argv approach:
         python3 -c 'import sys,urllib.parse; print(urllib.parse.quote(sys.argv[1], safe=""))' "$1"

  9. validate_azure_prereqs
     - Calls validate_command for: az, jq, python3, openssl
     - Plus kubectl and helm ONLY if a flag --requires-k8s is passed
       (the AKS wizard needs them; the ACA wizard does not).
     - Calls az_login_check.

D. Header comment for azure-helpers.sh

  # =============================================================
  # azure-helpers.sh — Azure-specific helper functions
  # =============================================================
  # Source this file AFTER common.sh, do not execute it directly.
  # Provides: az login checks, provider registration, resource
  # existence checks, long-poll waiters, password and key generators.
  # =============================================================

E. Verification

  1. Confirm both common.sh files are byte-identical:
       diff deploy/azure-aks/shell-lib/common.sh \
            deploy/azure-aca/shell-lib/common.sh
     Should produce no output.

  2. Confirm both azure-helpers.sh files are byte-identical:
       diff deploy/azure-aks/shell-lib/azure-helpers.sh \
            deploy/azure-aca/shell-lib/azure-helpers.sh
     Should produce no output.

  3. Run shellcheck on both shell-lib files. If shellcheck is not
     installed locally, skip this check and document it in the
     summary instead.

  4. Source-test each file in a subshell to confirm there are no
     syntax errors:
       bash -n deploy/azure-aks/shell-lib/common.sh
       bash -n deploy/azure-aks/shell-lib/azure-helpers.sh
       bash -n deploy/azure-aca/shell-lib/common.sh
       bash -n deploy/azure-aca/shell-lib/azure-helpers.sh

Print a summary listing:
  - Directories created
  - Files created (with byte sizes)
  - shellcheck pass/fail per file (or "skipped" if not installed)
  - bash -n pass/fail per file
```

### Expected Output

Two parallel deploy directories exist with shell-lib subdirectories. Both `common.sh` files are identical. Both `azure-helpers.sh` files are identical. All four files pass `bash -n`. The `.gitignore` files are in place so state and env files won't accidentally be committed.

---

## Prompt AZ3: AKS Manifest Templates

### Context

Creates the Kubernetes YAML templates the AKS wizard will materialize at deploy time. Each template uses `__PLACEHOLDER__` style tokens that the wizard substitutes via `sed` in Phase 3. This is mechanical content but it has to be correct because the wizard cannot fix bad YAML at runtime.

The templates correspond exactly to the manifests that prompts A8 through A10 in the original Azure deployment prompt pack would have generated inline. Pulling them out into static files means: (a) they can be reviewed and edited independently of the wizard, (b) they can be linted with `kubectl --dry-run=server` before the wizard runs, and (c) the wizard stays under 1000 lines.

### Prompt

*Copy the text below into Claude Code:*

```
Create the Kubernetes manifest templates for the AKS production wizard.

Pre-check:
1. deploy/azure-aks/manifests/ exists (created by AZ2). If not,
   stop and tell the operator to run AZ2 first.

Background to load:
- The wizard will substitute placeholders by running sed on each
  manifest at deploy time.
- Placeholders use the format __NAME__ (double underscore, all caps,
  double underscore). Examples: __ACR_LOGIN_SERVER__, __KV_NAME__,
  __TENANT_ID__, __WORKLOAD_IDENTITY_CLIENT_ID__, __OKTA_DOMAIN__.
- Every placeholder must appear in the file's header comment so the
  wizard can validate that it substituted all of them.

Create these 10 files under deploy/azure-aks/manifests/:

------------------------------------------------------------------
1. 00-namespace-sa.yaml
------------------------------------------------------------------
Header comment listing placeholders: __WORKLOAD_IDENTITY_CLIENT_ID__

Contents:
  - apiVersion: v1, kind: Namespace, name: okta-mcp
    labels: { name: okta-mcp }
  - apiVersion: v1, kind: ServiceAccount, name: okta-mcp-sa,
    namespace: okta-mcp
    annotations:
      azure.workload.identity/client-id: "__WORKLOAD_IDENTITY_CLIENT_ID__"
    labels:
      azure.workload.identity/use: "true"

------------------------------------------------------------------
2. 01-spc-keyvault.yaml
------------------------------------------------------------------
Header comment listing placeholders:
  __KV_NAME__, __TENANT_ID__, __WORKLOAD_IDENTITY_CLIENT_ID__

Contents: a SecretProviderClass named okta-mcp-spc in namespace
okta-mcp. provider: azure. parameters:
  usePodIdentity: "false"
  useVMManagedIdentity: "false"
  clientID: "__WORKLOAD_IDENTITY_CLIENT_ID__"
  keyvaultName: "__KV_NAME__"
  tenantId: "__TENANT_ID__"
  objects: |
    array:
      - |
        objectName: encryption-key
        objectType: secret
      - |
        objectName: admin-password
        objectType: secret
      - |
        objectName: database-url
        objectType: secret
      - |
        objectName: redis-url
        objectType: secret
      - |
        objectName: okta-relay-client-id
        objectType: secret
      - |
        objectName: okta-relay-client-secret
        objectType: secret
secretObjects:
  - secretName: okta-mcp-secrets
    type: Opaque
    data:
      - objectName: encryption-key
        key: ENCRYPTION_KEY
      - objectName: admin-password
        key: ADMIN_PASSWORD
      - objectName: database-url
        key: DATABASE_URL
      - objectName: redis-url
        key: REDIS_URL
      - objectName: okta-relay-client-id
        key: OKTA_RELAY_CLIENT_ID
      - objectName: okta-relay-client-secret
        key: OKTA_RELAY_CLIENT_SECRET

------------------------------------------------------------------
3. 02-configmap.yaml
------------------------------------------------------------------
Header comment listing placeholders:
  __OKTA_DOMAIN__, __OKTA_ISSUER__, __OKTA_AUTHORIZATION_SERVER_ID__

Contents: ConfigMap okta-mcp-config in namespace okta-mcp with
data:
  OKTA_DOMAIN: "__OKTA_DOMAIN__"
  OKTA_ISSUER: "__OKTA_ISSUER__"
  OKTA_AUTHORIZATION_SERVER_ID: "__OKTA_AUTHORIZATION_SERVER_ID__"
  CACHE_PROVIDER: "redis"
  REDIS_TLS_ENABLED: "true"
  REDIS_KEY_PREFIX: "okta-mcp:"
  LOG_LEVEL: "INFO"
  GATEWAY_PORT: "8000"

------------------------------------------------------------------
4. 20-adapter.yaml
------------------------------------------------------------------
Header comment listing placeholders: __ACR_LOGIN_SERVER__

Contents:
  - Deployment okta-mcp-adapter in namespace okta-mcp, 2 replicas
    selector + template labels: app=okta-mcp-adapter,
                                 azure.workload.identity/use="true"
    template spec:
      serviceAccountName: okta-mcp-sa
      containers:
        - name: adapter
          image: __ACR_LOGIN_SERVER__/adapter:latest
          ports: [ containerPort: 8000 ]
          envFrom:
            - secretRef: { name: okta-mcp-secrets }
            - configMapRef: { name: okta-mcp-config }
          resources:
            requests: { cpu: 500m, memory: 512Mi }
            limits:   { cpu: "1",  memory: 1Gi  }
          readinessProbe:
            httpGet: { path: /health, port: 8000 }
            initialDelaySeconds: 10
            periodSeconds: 5
          livenessProbe:
            httpGet: { path: /health, port: 8000 }
            initialDelaySeconds: 30
            periodSeconds: 15
            failureThreshold: 5
          volumeMounts:
            - name: kv-secrets
              mountPath: /mnt/secrets-store
              readOnly: true
      volumes:
        - name: kv-secrets
          csi:
            driver: secrets-store.csi.k8s.io
            readOnly: true
            volumeAttributes:
              secretProviderClass: okta-mcp-spc
  - Service okta-mcp-adapter, type ClusterIP, port 8000 -> targetPort 8000
  - HorizontalPodAutoscaler v2:
      minReplicas: 2, maxReplicas: 6
      metrics: cpu utilization 70%
      targetRef: Deployment/okta-mcp-adapter
  - PodDisruptionBudget:
      minAvailable: 1
      selector matchLabels app=okta-mcp-adapter

------------------------------------------------------------------
5. 21-admin-ui.yaml
------------------------------------------------------------------
Header comment listing placeholders: __ACR_LOGIN_SERVER__

Contents:
  - Deployment admin-ui in namespace okta-mcp, 1 replica
    container: image __ACR_LOGIN_SERVER__/admin-ui:latest, port 3001
    envFrom configMapRef okta-mcp-config
    resources requests cpu 250m memory 256Mi limits cpu 500m memory 512Mi
  - Service admin-ui ClusterIP port 3001 -> targetPort 3001

------------------------------------------------------------------
6. 22-hr-backend.yaml
------------------------------------------------------------------
Header comment listing placeholders: __ACR_LOGIN_SERVER__

Contents:
  - Deployment hr-mcp-server in namespace okta-mcp, 1 replica
    container: image __ACR_LOGIN_SERVER__/hr-backend:latest, port 8001
    resources requests cpu 100m memory 128Mi limits cpu 250m memory 256Mi
  - Service hr-mcp-server ClusterIP port 8001 -> targetPort 8001

------------------------------------------------------------------
7. 30-alb.yaml
------------------------------------------------------------------
Header comment listing placeholders: __AGC_SUBNET_ID__

Contents:
  apiVersion: alb.networking.azure.io/v1
  kind: ApplicationLoadBalancer
  metadata:
    name: okta-mcp-alb
    namespace: okta-mcp
  spec:
    associations:
      - "__AGC_SUBNET_ID__"

------------------------------------------------------------------
8. 31-gateway.yaml
------------------------------------------------------------------
Header comment listing placeholders: (none — purely declarative)

Contents:
  apiVersion: gateway.networking.k8s.io/v1
  kind: Gateway
  metadata:
    name: okta-mcp-gw
    namespace: okta-mcp
    annotations:
      alb.networking.azure.io/alb-name: okta-mcp-alb
      alb.networking.azure.io/alb-namespace: okta-mcp
  spec:
    gatewayClassName: azure-alb-external
    listeners:
      - name: https
        port: 443
        protocol: HTTPS
        tls:
          mode: Terminate
          options:
            alb.networking.azure.io/managed-cert: "true"
        allowedRoutes:
          namespaces:
            from: Same

------------------------------------------------------------------
9. 32-routes.yaml
------------------------------------------------------------------
Header comment listing placeholders:
  __ADAPTER_HOSTNAME__, __ADMIN_HOSTNAME__

Contents: two HTTPRoute objects in namespace okta-mcp, both with
parentRefs pointing to Gateway okta-mcp-gw:
  - adapter-route: hostname __ADAPTER_HOSTNAME__,
    backendRefs okta-mcp-adapter port 8000
  - admin-route: hostname __ADMIN_HOSTNAME__,
    backendRefs admin-ui port 3001

------------------------------------------------------------------
10. 40-network-policies.yaml
------------------------------------------------------------------
Header comment listing placeholders: (none)

Contents: a default-deny NetworkPolicy plus per-service allow rules.
All policies live in namespace okta-mcp.

  - NetworkPolicy default-deny-ingress
    podSelector: {} (matches all pods)
    policyTypes: [Ingress]
    ingress: []  (deny all)

  - NetworkPolicy allow-adapter-from-agc
    podSelector: matchLabels app=okta-mcp-adapter
    policyTypes: [Ingress]
    ingress:
      - from:
          - ipBlock: { cidr: 10.50.17.0/24 }   # agc-subnet
        ports:
          - protocol: TCP
            port: 8000

  - NetworkPolicy allow-adapter-egress
    podSelector: matchLabels app=okta-mcp-adapter
    policyTypes: [Egress]
    egress:
      - to:
          - ipBlock: { cidr: 10.50.16.0/24 }   # pe-subnet (PG, Redis, KV)
        ports:
          - protocol: TCP
            port: 5432
          - protocol: TCP
            port: 6380
          - protocol: TCP
            port: 443
      - to:
          - podSelector: { matchLabels: { app: hr-mcp-server } }
        ports:
          - protocol: TCP
            port: 8001
      # Allow DNS egress
      - to:
          - namespaceSelector: {}
            podSelector:
              matchLabels:
                k8s-app: kube-dns
        ports:
          - protocol: UDP
            port: 53
      # Allow HTTPS egress to the public internet (Okta)
      - ports:
          - protocol: TCP
            port: 443

  - NetworkPolicy allow-admin-from-agc
    podSelector: matchLabels app=admin-ui
    policyTypes: [Ingress]
    ingress:
      - from:
          - ipBlock: { cidr: 10.50.17.0/24 }
        ports:
          - protocol: TCP
            port: 3001

  - NetworkPolicy allow-hr-from-adapter
    podSelector: matchLabels app=hr-mcp-server
    policyTypes: [Ingress]
    ingress:
      - from:
          - podSelector: { matchLabels: { app: okta-mcp-adapter } }
        ports:
          - protocol: TCP
            port: 8001

------------------------------------------------------------------

Verification:

1. Run kubectl --dry-run=client -f against each manifest to catch
   YAML syntax errors:
     for f in deploy/azure-aks/manifests/*.yaml; do
       kubectl apply --dry-run=client -f "$f" 2>&1 | tee -a /tmp/dryrun.log
     done
   If kubectl is not installed locally, skip and document it.

2. Verify every placeholder mentioned in a file's header comment
   actually appears in the file body (and vice versa). Write a short
   bash check:
     for f in deploy/azure-aks/manifests/*.yaml; do
       declared=$(grep -oE '__[A-Z_]+__' "$f" | sort -u)
       in_header=$(awk '/^#/ {print} !/^#/ {exit}' "$f" | \
                   grep -oE '__[A-Z_]+__' | sort -u)
       diff <(echo "$declared") <(echo "$in_header") || \
         echo "MISMATCH in $f"
     done

3. Print a table of all files with their placeholder list and
   final byte size.
```

### Expected Output

10 manifest YAML files in `deploy/azure-aks/manifests/`, each with a header comment declaring its placeholders, each passing `kubectl --dry-run=client` (or skipped if kubectl unavailable), and each with placeholder declarations consistent with file contents.

---

## Prompt AZ4: AKS Phase 1 Wizard

### Context

This is the largest single prompt in the pack. It builds the `azuresetup.sh` wizard skeleton (flag parsing, phase dispatch, state loading, Ctrl+C trap) **plus** the complete Phase 1 implementation — the foundation phase that creates the resource group, registers providers, creates the ACR, builds the VNet with three subnets, sets up private DNS zones, provisions AKS Automatic, and federates a workload identity for Key Vault access in later phases.

Phase 1 is the right scope for this initial prompt because (a) it is independently runnable and verifiable, (b) it does not require any Okta values or hostnames from the operator, and (c) it produces the AKS cluster which is the long pole for the entire deployment. Once Phase 1 works, Phases 2-4 in subsequent prompts only have to layer state on top.

The wizard skeleton (everything except Phase 1's body) must be complete in this prompt — flag parsing, phase dispatch case statement with all four phases declared, state file management, Ctrl+C trap, summary box helper. Phases 2, 3, and 4 should exist as stub functions that print "Phase N not yet implemented in scaffolding." This way the dispatch logic is testable end-to-end even though only Phase 1 has a body.

### Prompt

*Copy the text below into Claude Code:*

```
Build the AKS production deployment wizard skeleton plus the Phase 1
foundation step.

Pre-check:
1. Read reports/azure-wizard-audit.md for the conventions to follow.
2. Read deploy/aws-ec2/awsetup.sh in full as the structural reference.
3. Confirm deploy/azure-aks/shell-lib/common.sh and azure-helpers.sh
   exist (created by AZ2).

Create deploy/azure-aks/azuresetup.sh with the structure below.

------------------------------------------------------------------
File header
------------------------------------------------------------------

#!/usr/bin/env bash
set -euo pipefail

# =============================================================
# azuresetup.sh — Okta MCP Adapter AKS Production Wizard
# =============================================================
# Interactive wizard that deploys the adapter on AKS Automatic
# with managed Postgres, managed Redis, and Application Gateway
# for Containers ingress.
#
# Phase 1: Foundation (RG, providers, ACR, VNet, AKS Automatic,
#          workload identity)
# Phase 2: Stateful tier (Postgres, Redis, Key Vault, secrets)
# Phase 3: Application + ingress (build, deploy, AGC)
# Phase 4: Smoke tests + Key Vault lockdown
# =============================================================

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
cd "$SCRIPT_DIR"

# Source shared libraries
source "$SCRIPT_DIR/shell-lib/common.sh"
source "$SCRIPT_DIR/shell-lib/azure-helpers.sh"

# Disable az cli paging so it never blocks on `less`
export AZURE_CORE_OUTPUT_NOWARN=1
export AZURE_CORE_NO_COLOR=false

------------------------------------------------------------------
Ctrl+C handler
------------------------------------------------------------------

cleanup() {
  echo ""
  warn "Interrupted. State saved to .azuresetup.state — rerun to resume."
  exit 130
}
trap cleanup INT TERM

------------------------------------------------------------------
Version detection
------------------------------------------------------------------

VERSION="dev"
if [[ -f "$SCRIPT_DIR/../../pyproject.toml" ]]; then
  VERSION="$(grep -m1 '^version' "$SCRIPT_DIR/../../pyproject.toml" | sed 's/.*= *"\(.*\)"/\1/')"
fi

------------------------------------------------------------------
Defaults and flag parsing
------------------------------------------------------------------

PHASE="all"
NON_INTERACTIVE=false
SKIP_BUILD=false

show_help() {
  cat <<'USAGE'
Usage: azuresetup.sh [OPTIONS]

Options:
  --phase PHASE          Run a specific phase: 1, 2, 3, 4, all (default: all)
  --subscription ID      Azure subscription ID (overrides current)
  --location REGION      Azure region (default: eastus2)
  --non-interactive      Use values from .env and .azuresetup.state, never prompt
  --skip-build           Skip docker image builds (use existing tags in ACR)
  --destroy              Delete the resource group and all resources
  -h, --help             Show this help

Phases:
  1  Foundation: RG, providers, ACR, VNet, AKS Automatic, workload identity
  2  Stateful tier: Postgres, Redis, Key Vault, secrets
  3  Application + ingress: build images, deploy K8s, AGC
  4  Smoke tests + Key Vault lockdown

Environment variables (or .env file):
  AZURE_SUBSCRIPTION_ID     Required
  AZURE_LOCATION            Default: eastus2
  AZURE_RG                  Default: okta-mcp-prod
  OKTA_DOMAIN               Required for Phase 2
  OKTA_ISSUER               Required for Phase 2
  OKTA_AUTHORIZATION_SERVER_ID  Required for Phase 2
  OKTA_RELAY_CLIENT_ID      Required for Phase 2
  OKTA_RELAY_CLIENT_SECRET  Required for Phase 2
  ADAPTER_HOSTNAME          Required for Phase 3
  ADMIN_HOSTNAME            Required for Phase 3
USAGE
}

while [[ $# -gt 0 ]]; do
  case "$1" in
    --phase)             PHASE="$2"; shift 2 ;;
    --subscription)      export AZURE_SUBSCRIPTION_ID="$2"; shift 2 ;;
    --location)          export AZURE_LOCATION="$2"; shift 2 ;;
    --non-interactive)   NON_INTERACTIVE=true; shift ;;
    --skip-build)        SKIP_BUILD=true; shift ;;
    --destroy)           PHASE="destroy"; shift ;;
    -h|--help)           show_help; exit 0 ;;
    *) die "Unknown flag: $1 (use --help)" ;;
  esac
done

[[ "$PHASE" =~ ^(1|2|3|4|all|destroy)$ ]] || \
  die "--phase must be 1, 2, 3, 4, all, or destroy"

------------------------------------------------------------------
.env loading
------------------------------------------------------------------

if [[ -f "$SCRIPT_DIR/.env" ]]; then
  set -a
  source "$SCRIPT_DIR/.env"
  set +a
fi

------------------------------------------------------------------
Load existing state if present
------------------------------------------------------------------

load_state

------------------------------------------------------------------
Banner helper (matches awsetup.sh style)
------------------------------------------------------------------

print_banner() {
  local title="$1"
  echo ""
  printf "${CYAN}┌──────────────────────────────────────────────────┐${NC}\n"
  printf "${CYAN}│${NC}  ${BOLD}%-48s${NC}${CYAN}│${NC}\n" "$title"
  printf "${CYAN}└──────────────────────────────────────────────────┘${NC}\n"
  echo ""
}

print_summary_box() {
  local title="$1"; shift
  echo ""
  printf "${GREEN}┌──────────────────────────────────────────────────┐${NC}\n"
  printf "${GREEN}│${NC}  ${BOLD}%-48s${NC}${GREEN}│${NC}\n" "$title"
  printf "${GREEN}├──────────────────────────────────────────────────┤${NC}\n"
  for line in "$@"; do
    printf "${GREEN}│${NC}  %-48s${GREEN}│${NC}\n" "$line"
  done
  printf "${GREEN}└──────────────────────────────────────────────────┘${NC}\n"
  echo ""
}

------------------------------------------------------------------
Phase 1: Foundation
------------------------------------------------------------------

run_phase_1() {
  print_banner "Phase 1: Foundation"

  # Step 1.1: Validate prerequisites
  info "Step 1.1: Validating prerequisites..."
  validate_command az "Install: https://learn.microsoft.com/cli/azure/install-azure-cli"
  validate_command jq
  validate_command python3
  validate_command openssl
  validate_command kubectl "Install: https://kubernetes.io/docs/tasks/tools/"
  validate_command helm "Install: https://helm.sh/docs/intro/install/"
  az_login_check
  ok "Prerequisites OK"

  # Step 1.2: Resolve subscription, region, RG, ACR name
  info "Step 1.2: Resolving Azure subscription and region..."

  if [[ -z "${AZURE_SUBSCRIPTION_ID:-}" ]]; then
    AZURE_SUBSCRIPTION_ID="$(get_state AZURE_SUBSCRIPTION_ID)"
  fi
  if [[ -z "$AZURE_SUBSCRIPTION_ID" ]]; then
    if $NON_INTERACTIVE; then
      die "AZURE_SUBSCRIPTION_ID not set in env, .env, or state file"
    fi
    local current_sub
    current_sub="$(az account show --query id -o tsv 2>/dev/null || true)"
    prompt_default AZURE_SUBSCRIPTION_ID "Azure subscription ID" "$current_sub"
  fi
  az account set --subscription "$AZURE_SUBSCRIPTION_ID"
  save_state AZURE_SUBSCRIPTION_ID "$AZURE_SUBSCRIPTION_ID"

  AZURE_LOCATION="${AZURE_LOCATION:-$(get_state AZURE_LOCATION)}"
  AZURE_LOCATION="${AZURE_LOCATION:-eastus2}"
  if ! $NON_INTERACTIVE && [[ -z "$(get_state AZURE_LOCATION)" ]]; then
    prompt_default AZURE_LOCATION "Azure region" "$AZURE_LOCATION"
  fi
  save_state AZURE_LOCATION "$AZURE_LOCATION"

  AZURE_RG="${AZURE_RG:-$(get_state AZURE_RG)}"
  AZURE_RG="${AZURE_RG:-okta-mcp-prod}"
  save_state AZURE_RG "$AZURE_RG"

  AZURE_ACR_NAME="${AZURE_ACR_NAME:-$(get_state AZURE_ACR_NAME)}"
  if [[ -z "$AZURE_ACR_NAME" ]]; then
    AZURE_ACR_NAME="oktamcpprod$(random_suffix 4)"
  fi
  save_state AZURE_ACR_NAME "$AZURE_ACR_NAME"

  TENANT_ID="$(az account show --query tenantId -o tsv)"
  save_state TENANT_ID "$TENANT_ID"

  ok "Subscription: $AZURE_SUBSCRIPTION_ID"
  ok "Region:       $AZURE_LOCATION"
  ok "Resource group: $AZURE_RG"
  ok "ACR name:     $AZURE_ACR_NAME"

  # Step 1.3: Register providers
  info "Step 1.3: Registering required Azure providers..."
  for provider in \
    Microsoft.ContainerService \
    Microsoft.ContainerRegistry \
    Microsoft.DBforPostgreSQL \
    Microsoft.Cache \
    Microsoft.KeyVault \
    Microsoft.OperationalInsights \
    Microsoft.Network \
    Microsoft.ServiceNetworking \
    Microsoft.ManagedIdentity ; do
    az_provider_register "$provider"
  done
  ok "All providers registered"

  # Step 1.4: Create resource group
  info "Step 1.4: Creating resource group..."
  if az group show -n "$AZURE_RG" &>/dev/null; then
    ok "Resource group $AZURE_RG already exists"
  else
    az group create -n "$AZURE_RG" -l "$AZURE_LOCATION" --output none
    ok "Resource group created"
  fi

  # Step 1.5: Create Azure Container Registry
  info "Step 1.5: Creating Azure Container Registry..."
  if az acr show -n "$AZURE_ACR_NAME" &>/dev/null; then
    ok "ACR $AZURE_ACR_NAME already exists"
  else
    az acr create -g "$AZURE_RG" -n "$AZURE_ACR_NAME" \
      --sku Standard --admin-enabled false --output none
    ok "ACR created"
  fi
  ACR_LOGIN_SERVER="$(az acr show -n "$AZURE_ACR_NAME" --query loginServer -o tsv)"
  save_state ACR_LOGIN_SERVER "$ACR_LOGIN_SERVER"

  # Step 1.6: Create VNet and subnets
  info "Step 1.6: Creating VNet and subnets..."
  VNET_NAME="okta-mcp-vnet"
  if az network vnet show -g "$AZURE_RG" -n "$VNET_NAME" &>/dev/null; then
    ok "VNet $VNET_NAME already exists"
  else
    az network vnet create -g "$AZURE_RG" -n "$VNET_NAME" \
      -l "$AZURE_LOCATION" --address-prefix 10.50.0.0/16 \
      --output none
    ok "VNet created"
  fi

  for subnet_def in \
    "aks-subnet:10.50.0.0/20:" \
    "pe-subnet:10.50.16.0/24:" \
    "agc-subnet:10.50.17.0/24:Microsoft.ServiceNetworking/trafficControllers" ; do
    local name="${subnet_def%%:*}"
    local rest="${subnet_def#*:}"
    local cidr="${rest%%:*}"
    local delegation="${rest##*:}"

    if az network vnet subnet show -g "$AZURE_RG" --vnet-name "$VNET_NAME" \
         -n "$name" &>/dev/null; then
      ok "Subnet $name already exists"
    else
      local args=( -g "$AZURE_RG" --vnet-name "$VNET_NAME" -n "$name" \
                   --address-prefix "$cidr" --output none )
      [[ -n "$delegation" ]] && args+=( --delegations "$delegation" )
      az network vnet subnet create "${args[@]}"
      ok "Subnet $name created ($cidr)"
    fi
  done

  AKS_SUBNET_ID="$(az network vnet subnet show -g "$AZURE_RG" \
    --vnet-name "$VNET_NAME" -n aks-subnet --query id -o tsv)"
  PE_SUBNET_ID="$(az network vnet subnet show -g "$AZURE_RG" \
    --vnet-name "$VNET_NAME" -n pe-subnet --query id -o tsv)"
  AGC_SUBNET_ID="$(az network vnet subnet show -g "$AZURE_RG" \
    --vnet-name "$VNET_NAME" -n agc-subnet --query id -o tsv)"
  save_state AKS_SUBNET_ID "$AKS_SUBNET_ID"
  save_state PE_SUBNET_ID "$PE_SUBNET_ID"
  save_state AGC_SUBNET_ID "$AGC_SUBNET_ID"

  # Disable PE network policies on pe-subnet so private endpoints work
  az network vnet subnet update -g "$AZURE_RG" --vnet-name "$VNET_NAME" \
    -n pe-subnet --disable-private-endpoint-network-policies true \
    --output none

  # Step 1.7: Create private DNS zones
  info "Step 1.7: Creating private DNS zones and VNet links..."
  for zone in \
    privatelink.postgres.database.azure.com \
    privatelink.redis.cache.windows.net \
    privatelink.vaultcore.azure.net ; do
    if az network private-dns zone show -g "$AZURE_RG" -n "$zone" &>/dev/null; then
      ok "DNS zone $zone already exists"
    else
      az network private-dns zone create -g "$AZURE_RG" -n "$zone" --output none
      ok "DNS zone $zone created"
    fi
    local link_name="${zone//./-}-link"
    if az network private-dns link vnet show -g "$AZURE_RG" \
         -n "$link_name" -z "$zone" &>/dev/null; then
      ok "VNet link for $zone already exists"
    else
      az network private-dns link vnet create -g "$AZURE_RG" \
        -n "$link_name" -z "$zone" -v "$VNET_NAME" \
        --registration-enabled false --output none
      ok "VNet link for $zone created"
    fi
  done

  # Step 1.8: Create AKS Automatic cluster
  info "Step 1.8: Creating AKS Automatic cluster (5-8 min)..."
  AKS_NAME="okta-mcp-aks"
  if az aks show -g "$AZURE_RG" -n "$AKS_NAME" &>/dev/null; then
    ok "AKS cluster $AKS_NAME already exists"
  else
    az aks create -g "$AZURE_RG" -n "$AKS_NAME" -l "$AZURE_LOCATION" \
      --sku automatic \
      --vnet-subnet-id "$AKS_SUBNET_ID" \
      --enable-managed-identity \
      --enable-workload-identity \
      --enable-oidc-issuer \
      --enable-azure-keyvault-secrets-provider \
      --attach-acr "$AZURE_ACR_NAME" \
      --output none
    ok "AKS Automatic cluster created"
  fi
  save_state AKS_NAME "$AKS_NAME"

  # Fetch credentials
  az aks get-credentials -g "$AZURE_RG" -n "$AKS_NAME" \
    --overwrite-existing --output none
  ok "kubectl context configured"

  AKS_OIDC_ISSUER="$(az aks show -g "$AZURE_RG" -n "$AKS_NAME" \
    --query oidcIssuerProfile.issuerUrl -o tsv)"
  save_state AKS_OIDC_ISSUER "$AKS_OIDC_ISSUER"

  # Step 1.9: Create user-assigned managed identity and federate it
  info "Step 1.9: Creating workload identity and federating with AKS..."
  WORKLOAD_IDENTITY_NAME="okta-mcp-workload-id"
  if az identity show -g "$AZURE_RG" -n "$WORKLOAD_IDENTITY_NAME" &>/dev/null; then
    ok "Managed identity $WORKLOAD_IDENTITY_NAME already exists"
  else
    az identity create -g "$AZURE_RG" -n "$WORKLOAD_IDENTITY_NAME" \
      -l "$AZURE_LOCATION" --output none
    ok "Managed identity created"
  fi
  WORKLOAD_IDENTITY_CLIENT_ID="$(az identity show -g "$AZURE_RG" \
    -n "$WORKLOAD_IDENTITY_NAME" --query clientId -o tsv)"
  WORKLOAD_IDENTITY_PRINCIPAL_ID="$(az identity show -g "$AZURE_RG" \
    -n "$WORKLOAD_IDENTITY_NAME" --query principalId -o tsv)"
  save_state WORKLOAD_IDENTITY_CLIENT_ID "$WORKLOAD_IDENTITY_CLIENT_ID"
  save_state WORKLOAD_IDENTITY_PRINCIPAL_ID "$WORKLOAD_IDENTITY_PRINCIPAL_ID"

  # Federated credential (idempotent — list and skip if exists)
  if az identity federated-credential list -g "$AZURE_RG" \
       --identity-name "$WORKLOAD_IDENTITY_NAME" \
       --query "[?name=='okta-mcp-fc']" -o tsv | grep -q .; then
    ok "Federated credential okta-mcp-fc already exists"
  else
    az identity federated-credential create \
      --name okta-mcp-fc \
      --identity-name "$WORKLOAD_IDENTITY_NAME" \
      --resource-group "$AZURE_RG" \
      --issuer "$AKS_OIDC_ISSUER" \
      --subject "system:serviceaccount:okta-mcp:okta-mcp-sa" \
      --output none
    ok "Federated credential created"
  fi

  # Mark phase 1 complete
  save_state PHASE_1_COMPLETE "true"

  print_summary_box "Phase 1 Complete: Foundation Ready" \
    "Subscription: $AZURE_SUBSCRIPTION_ID" \
    "Region:       $AZURE_LOCATION" \
    "RG:           $AZURE_RG" \
    "ACR:          $ACR_LOGIN_SERVER" \
    "AKS cluster:  $AKS_NAME" \
    "VNet:         $VNET_NAME (10.50.0.0/16)" \
    "Workload ID:  $WORKLOAD_IDENTITY_CLIENT_ID" \
    "" \
    "Next: ./azuresetup.sh --phase 2"
}

------------------------------------------------------------------
Phase 2-4 stubs
------------------------------------------------------------------

run_phase_2() {
  print_banner "Phase 2: Stateful Tier"
  warn "Phase 2 not yet implemented in scaffolding."
  warn "This will provision Postgres, Redis, Key Vault, and write secrets."
  exit 0
}

run_phase_3() {
  print_banner "Phase 3: Application + Ingress"
  warn "Phase 3 not yet implemented in scaffolding."
  warn "This will build images, deploy K8s manifests, and provision AGC."
  exit 0
}

run_phase_4() {
  print_banner "Phase 4: Smoke Tests + Lockdown"
  warn "Phase 4 not yet implemented in scaffolding."
  warn "This will run smoke tests and disable Key Vault public access."
  exit 0
}

------------------------------------------------------------------
Destroy
------------------------------------------------------------------

run_destroy() {
  print_banner "Destroy: Delete Resource Group"
  AZURE_RG="${AZURE_RG:-$(get_state AZURE_RG)}"
  [[ -z "$AZURE_RG" ]] && die "AZURE_RG not set in env or state"
  if ! $NON_INTERACTIVE; then
    if ! prompt_yesno "Delete resource group '$AZURE_RG' AND ALL RESOURCES in it?" n; then
      info "Aborted."
      exit 0
    fi
  fi
  az group delete -n "$AZURE_RG" --yes --no-wait
  ok "Delete initiated (running asynchronously). Track with:"
  ok "  az group show -n $AZURE_RG"
  rm -f "$SCRIPT_DIR/.azuresetup.state"
  ok "State file removed."
}

------------------------------------------------------------------
Main dispatch
------------------------------------------------------------------

case "$PHASE" in
  1)       run_phase_1 ;;
  2)       run_phase_2 ;;
  3)       run_phase_3 ;;
  4)       run_phase_4 ;;
  all)     run_phase_1 && run_phase_2 && run_phase_3 && run_phase_4 ;;
  destroy) run_destroy ;;
esac

------------------------------------------------------------------

Verification:

1. chmod +x deploy/azure-aks/azuresetup.sh
2. bash -n deploy/azure-aks/azuresetup.sh
3. shellcheck deploy/azure-aks/azuresetup.sh
   (skip if shellcheck not installed; document in summary)
4. ./deploy/azure-aks/azuresetup.sh --help
   Should print the help text and exit 0.
5. ./deploy/azure-aks/azuresetup.sh --phase 99 || true
   Should die with the "must be 1, 2, 3, 4, all, or destroy" message.

Print a summary listing:
  - Total file size in lines
  - bash -n result
  - shellcheck result (or "skipped")
  - --help output
  - --phase 99 error path output
```

### Expected Output

A complete `azuresetup.sh` that passes `bash -n`, prints help, validates phase numbers, has working Phase 1 logic, and stubbed Phase 2-4 functions. Phase 1 is independently re-runnable: every step checks for "already exists" before creating. State is written after every meaningful step so an interrupted run can resume.

---

## Prompt AZ5: ACA Phase 1 Wizard + Bicep Skeleton

### Context

Builds the smaller demo wizard. The structure mirrors the AKS wizard exactly (same flag parsing, same Ctrl+C trap, same state file pattern) but the body is much simpler: no VNet, no Key Vault, no Helm, no kubectl. Container Apps' built-in Envoy ingress and managed certs replace the AGC + Helm controller dance from the production pack.

The Bicep file is created as a skeleton with placeholders the wizard will substitute when Phase 2 runs. It is not invoked in Phase 1.

### Prompt

*Copy the text below into Claude Code:*

```
Build the Container Apps demo wizard skeleton plus the Phase 1
foundation step, and create the Bicep skeleton.

Pre-check:
1. deploy/azure-aca/shell-lib/common.sh and azure-helpers.sh exist
   (created by AZ2)
2. deploy/azure-aca/bicep/ exists (created by AZ2)

Create deploy/azure-aca/acasetup.sh with the same overall structure
as deploy/azure-aks/azuresetup.sh but with these differences:

A. State file override

Before sourcing common.sh, set:
  STATE_FILE="${STATE_FILE:-.acasetup.state}"
  export STATE_FILE
This must come BEFORE the source line for common.sh.

B. File header

#!/usr/bin/env bash
set -euo pipefail

# =============================================================
# acasetup.sh — Okta MCP Adapter ACA Demo Wizard
# =============================================================
# Lightweight wizard that deploys the adapter on Azure Container
# Apps with Burstable Postgres and Basic Redis. Designed for
# SE-led customer demos and POCs.
#
# Phase 1: Foundation (RG, ACR, Postgres B1ms, Redis Basic C0,
#          Container Apps environment)
# Phase 2: Application (build images, deploy Bicep, smoke test,
#          write demo-stop.sh / demo-start.sh helpers)
# =============================================================

C. Flag parsing

Same as azuresetup.sh but with only --phase 1, 2, all, destroy.
The help text should describe the demo profile and reference
~$70/mo active and ~$25/mo stopped.

D. Phase 1 body

run_phase_1() {
  print_banner "Phase 1: Demo Foundation"

  # Step 1.1: Validate prerequisites (note: NO kubectl/helm needed)
  info "Step 1.1: Validating prerequisites..."
  validate_command az "Install: https://learn.microsoft.com/cli/azure/install-azure-cli"
  validate_command jq
  validate_command python3
  validate_command openssl
  az_login_check
  ok "Prerequisites OK"

  # Step 1.2: Resolve subscription, region, RG, ACR name
  info "Step 1.2: Resolving Azure subscription and region..."
  # ... (same pattern as AKS Phase 1.2 but with defaults
  #      AZURE_RG=okta-mcp-demo, AZURE_ACR_NAME=oktamcpdemo<random4>)

  TENANT_ID="$(az account show --query tenantId -o tsv)"
  save_state TENANT_ID "$TENANT_ID"

  # Step 1.3: Register providers (smaller list than AKS)
  info "Step 1.3: Registering Azure providers..."
  for provider in \
    Microsoft.App \
    Microsoft.ContainerRegistry \
    Microsoft.OperationalInsights \
    Microsoft.DBforPostgreSQL \
    Microsoft.Cache ; do
    az_provider_register "$provider"
  done

  # Step 1.4: Create resource group
  info "Step 1.4: Creating resource group..."
  if az group show -n "$AZURE_RG" &>/dev/null; then
    ok "Resource group $AZURE_RG already exists"
  else
    az group create -n "$AZURE_RG" -l "$AZURE_LOCATION" --output none
    ok "Resource group created"
  fi

  # Step 1.5: Create ACR Basic (admin-enabled for Container Apps pull)
  info "Step 1.5: Creating Azure Container Registry (Basic, admin-enabled)..."
  if az acr show -n "$AZURE_ACR_NAME" &>/dev/null; then
    ok "ACR $AZURE_ACR_NAME already exists"
  else
    az acr create -g "$AZURE_RG" -n "$AZURE_ACR_NAME" \
      --sku Basic --admin-enabled true --output none
    ok "ACR created (admin-enabled for Container Apps pull)"
  fi
  ACR_LOGIN_SERVER="$(az acr show -n "$AZURE_ACR_NAME" --query loginServer -o tsv)"
  save_state ACR_LOGIN_SERVER "$ACR_LOGIN_SERVER"

  # Step 1.6: Create Postgres Flexible Server (Burstable B1ms)
  info "Step 1.6: Creating Postgres Flexible Server B1ms (~5 min)..."
  PG_NAME="${PG_NAME:-$(get_state PG_NAME)}"
  if [[ -z "$PG_NAME" ]]; then
    PG_NAME="okta-mcp-pg-demo-$(random_suffix 4)"
  fi
  if az postgres flexible-server show -g "$AZURE_RG" -n "$PG_NAME" &>/dev/null; then
    ok "Postgres $PG_NAME already exists"
    PG_PASSWORD="$(get_state PG_PASSWORD)"
    [[ -z "$PG_PASSWORD" ]] && \
      die "Postgres exists but PG_PASSWORD not in state. Manual recovery needed."
  else
    PG_PASSWORD="$(generate_password 24)"
    save_state PG_PASSWORD "$PG_PASSWORD"
    az postgres flexible-server create \
      --resource-group "$AZURE_RG" \
      --location "$AZURE_LOCATION" \
      --name "$PG_NAME" \
      --tier Burstable \
      --sku-name Standard_B1ms \
      --version 15 \
      --storage-size 32 \
      --public-access 0.0.0.0 \
      --admin-user pgadmin \
      --admin-password "$PG_PASSWORD" \
      --backup-retention 7 \
      --yes \
      --output none
    ok "Postgres B1ms created"
  fi
  save_state PG_NAME "$PG_NAME"

  # Create the gateway database
  if az postgres flexible-server db show -g "$AZURE_RG" -s "$PG_NAME" \
       -d gateway_db &>/dev/null; then
    ok "Database gateway_db already exists"
  else
    az postgres flexible-server db create -g "$AZURE_RG" \
      -s "$PG_NAME" -d gateway_db --output none
    ok "Database gateway_db created"
  fi
  PG_FQDN="${PG_NAME}.postgres.database.azure.com"
  save_state PG_FQDN "$PG_FQDN"

  # Build DATABASE_URL for later phases
  PG_PASSWORD_ENC="$(urlencode_password "$PG_PASSWORD")"
  DATABASE_URL="postgresql://pgadmin:${PG_PASSWORD_ENC}@${PG_FQDN}:5432/gateway_db?sslmode=require"
  save_state DATABASE_URL "$DATABASE_URL"

  # Step 1.7: Create Azure Cache for Redis Basic C0
  info "Step 1.7: Creating Azure Cache for Redis Basic C0 (~15 min)..."
  REDIS_NAME="${REDIS_NAME:-$(get_state REDIS_NAME)}"
  if [[ -z "$REDIS_NAME" ]]; then
    REDIS_NAME="okta-mcp-redis-demo-$(random_suffix 4)"
  fi
  if az redis show -g "$AZURE_RG" -n "$REDIS_NAME" &>/dev/null; then
    ok "Redis $REDIS_NAME already exists"
  else
    az redis create \
      --resource-group "$AZURE_RG" \
      --location "$AZURE_LOCATION" \
      --name "$REDIS_NAME" \
      --sku Basic --vm-size c0 \
      --enable-non-ssl-port false \
      --minimum-tls-version 1.2 \
      --redis-version 6 \
      --output none
    ok "Redis Basic C0 created"
  fi
  save_state REDIS_NAME "$REDIS_NAME"

  # Build REDIS_URL
  REDIS_KEY="$(az redis list-keys -g "$AZURE_RG" -n "$REDIS_NAME" \
    --query primaryKey -o tsv)"
  REDIS_FQDN="${REDIS_NAME}.redis.cache.windows.net"
  save_state REDIS_FQDN "$REDIS_FQDN"
  REDIS_URL="rediss://:${REDIS_KEY}@${REDIS_FQDN}:6380/0"
  save_state REDIS_URL "$REDIS_URL"

  # Step 1.8: Create Container Apps environment + Log Analytics
  info "Step 1.8: Creating Log Analytics workspace..."
  LA_NAME="okta-mcp-logs"
  if az monitor log-analytics workspace show -g "$AZURE_RG" \
       -n "$LA_NAME" &>/dev/null; then
    ok "Log Analytics workspace $LA_NAME already exists"
  else
    az monitor log-analytics workspace create -g "$AZURE_RG" \
      -n "$LA_NAME" -l "$AZURE_LOCATION" --retention-time 30 \
      --output none
    ok "Log Analytics workspace created"
  fi
  LA_ID="$(az monitor log-analytics workspace show -g "$AZURE_RG" \
    -n "$LA_NAME" --query customerId -o tsv)"
  LA_KEY="$(az monitor log-analytics workspace get-shared-keys -g "$AZURE_RG" \
    -n "$LA_NAME" --query primarySharedKey -o tsv)"

  info "Step 1.9: Creating Container Apps environment..."
  ACA_ENV="okta-mcp-env"
  if az containerapp env show -g "$AZURE_RG" -n "$ACA_ENV" &>/dev/null; then
    ok "Container Apps environment $ACA_ENV already exists"
  else
    az containerapp env create -g "$AZURE_RG" -n "$ACA_ENV" \
      -l "$AZURE_LOCATION" \
      --logs-workspace-id "$LA_ID" \
      --logs-workspace-key "$LA_KEY" \
      --output none
    ok "Container Apps environment created"
  fi
  save_state ACA_ENV "$ACA_ENV"
  ACA_DEFAULT_DOMAIN="$(az containerapp env show -g "$AZURE_RG" -n "$ACA_ENV" \
    --query properties.defaultDomain -o tsv)"
  save_state ACA_DEFAULT_DOMAIN "$ACA_DEFAULT_DOMAIN"

  # Mark phase 1 complete
  save_state PHASE_1_COMPLETE "true"

  print_summary_box "Phase 1 Complete: Demo Foundation Ready" \
    "Subscription: $AZURE_SUBSCRIPTION_ID" \
    "Region:       $AZURE_LOCATION" \
    "RG:           $AZURE_RG" \
    "ACR:          $ACR_LOGIN_SERVER" \
    "Postgres:     $PG_FQDN (Burstable B1ms)" \
    "Redis:        $REDIS_FQDN (Basic C0)" \
    "ACA env:      $ACA_ENV" \
    "ACA domain:   $ACA_DEFAULT_DOMAIN" \
    "" \
    "Next: ./acasetup.sh --phase 2"
}

run_phase_2() {
  print_banner "Phase 2: Application Deployment"
  warn "Phase 2 not yet implemented in scaffolding."
  warn "This will build images, deploy the Bicep template, smoke test,"
  warn "and write demo-stop.sh / demo-start.sh helpers."
  exit 0
}

run_destroy() {
  # Same pattern as AKS run_destroy
  ...
}

# Dispatch case statement supporting 1, 2, all, destroy

E. Bicep skeleton

Create deploy/azure-aca/bicep/main.bicep with placeholder structure.
This file is NOT invoked in Phase 1 — Phase 2 will consume it. It
exists now so the directory layout is complete and so a future prompt
can edit it incrementally.

Header:
  // =============================================================
  // main.bicep — Container Apps deployment for the Okta MCP Adapter
  // =============================================================
  // Phase 2 of acasetup.sh consumes this file via:
  //   az deployment group create --template-file main.bicep \
  //     --parameters @.params.json
  // =============================================================

Top-level parameters (just the declarations, no resources yet):
  - acaEnvName string
  - acrLoginServer string
  - acrUsername string
  - @secure() acrPassword string
  - @secure() encryptionKey string
  - @secure() adminPassword string
  - @secure() databaseUrl string
  - @secure() redisUrl string
  - @secure() oktaRelayClientId string
  - @secure() oktaRelayClientSecret string
  - oktaDomain string
  - oktaIssuer string
  - oktaAuthorizationServerId string

Add a comment block at the bottom listing the resources that Phase 2
will add:
  // RESOURCES (to be added in Phase 2):
  //   - Microsoft.App/containerApps okta-mcp-adapter
  //   - Microsoft.App/containerApps admin-ui
  //   - Microsoft.App/containerApps hr-mcp-server

Verification:

1. chmod +x deploy/azure-aca/acasetup.sh
2. bash -n deploy/azure-aca/acasetup.sh
3. shellcheck deploy/azure-aca/acasetup.sh (skip if not installed)
4. ./deploy/azure-aca/acasetup.sh --help
5. az bicep build --file deploy/azure-aca/bicep/main.bicep
   (skip if az bicep not installed; document in summary)

Print a summary with file sizes and check results.
```

### Expected Output

A complete `acasetup.sh` that passes `bash -n` and prints help, with a working Phase 1 implementation. A `main.bicep` skeleton with all parameter declarations but no resources yet (Phase 2 will add them). State file is `.acasetup.state` (different from the AKS wizard so they can coexist).

---

## Prompt AZ6: Documentation, Packaging, and Smoke Verification

### Context

Final prompt. With both wizards built and Phase 1 of each working, write the operator-facing documentation, the env templates, and the `package.sh` tarball builders. Then run a structural smoke test on both wizards: `--help`, `--phase 99`, `bash -n`, and (optionally) a real `--phase 1` run against a throwaway subscription if `AZURE_SMOKE_SUBSCRIPTION` is set in the operator's environment.

The package.sh files are sized down from `aws-ec2/package.sh` because the Azure wizards don't need to ship the Docker compose stack — Container Apps and AKS pull from ACR directly. The packaged artifact is just the wizard, shell-lib, manifests/bicep, README, and env template.

### Prompt

*Copy the text below into Claude Code:*

```
Author the operator documentation and packaging for both Azure
wizards, then run a structural smoke verification.

Pre-check:
- deploy/azure-aks/azuresetup.sh exists from AZ4
- deploy/azure-aca/acasetup.sh exists from AZ5

PART A — .env.example files

Create deploy/azure-aks/.env.example:

  # =============================================================
  # Okta MCP Adapter — AKS Production Wizard
  # =============================================================
  # Copy this file to .env and fill in the values. Required values
  # are marked. Optional values use the defaults shown.
  # =============================================================

  # Required — Azure
  AZURE_SUBSCRIPTION_ID=
  AZURE_LOCATION=eastus2
  AZURE_RG=okta-mcp-prod

  # Required — Okta (needed starting in Phase 2)
  OKTA_DOMAIN=
  OKTA_ISSUER=
  OKTA_AUTHORIZATION_SERVER_ID=
  OKTA_RELAY_CLIENT_ID=
  OKTA_RELAY_CLIENT_SECRET=

  # Required — Public hostnames (needed starting in Phase 3)
  ADAPTER_HOSTNAME=mcp.example.com
  ADMIN_HOSTNAME=admin-mcp.example.com

  # Optional — Override the auto-generated ACR name
  # AZURE_ACR_NAME=

Create deploy/azure-aca/.env.example with the demo subset:

  # =============================================================
  # Okta MCP Adapter — ACA Demo Wizard
  # =============================================================

  # Required — Azure
  AZURE_SUBSCRIPTION_ID=
  AZURE_LOCATION=eastus2
  AZURE_RG=okta-mcp-demo

  # Required — Okta (needed starting in Phase 2)
  OKTA_DOMAIN=
  OKTA_ISSUER=
  OKTA_AUTHORIZATION_SERVER_ID=
  OKTA_RELAY_CLIENT_ID=
  OKTA_RELAY_CLIENT_SECRET=

  # Optional — Override auto-generated names
  # AZURE_ACR_NAME=
  # PG_NAME=
  # REDIS_NAME=

PART B — README files

Create deploy/azure-aks/README.md with these sections:

  # Okta MCP Adapter — AKS Production Deployment

  ## Overview
  One paragraph describing the production stack: AKS Automatic +
  managed Postgres GP + managed Redis Standard + AGC ingress. Cite
  ~$700/mo on-demand cost and link to the cost breakdown if there
  is a HORIZONTAL_SCALING.md or COST_ANALYSIS.md doc anywhere in the
  repo (search for it; if absent, skip the link).

  ## Prerequisites
  - Azure subscription with Owner or Contributor role
  - az cli, kubectl, helm, jq, python3, openssl on the operator's
    machine
  - Okta org with Custom Auth Server + OIDC Web App configured
  - Two DNS hostnames you control (ADAPTER_HOSTNAME, ADMIN_HOSTNAME)
  - The Redis caching migration must be complete in the adapter
    codebase (verify with: pytest tests/integration/test_redis_multipod.py)

  ## Quick Start
  ```bash
  cp .env.example .env
  vi .env  # fill in required values
  ./azuresetup.sh           # runs all four phases
  ```

  ## Phases
  Table with phase number, name, what it creates, and approximate
  duration:
  | Phase | Name | Creates | Duration |
  |---|---|---|---|
  | 1 | Foundation | RG, providers, ACR, VNet, AKS Automatic, workload identity | ~10 min |
  | 2 | Stateful tier | Postgres GP, Redis Standard, Key Vault, secrets | ~25 min |
  | 3 | Application + ingress | Image build, K8s deploy, AGC | ~15 min |
  | 4 | Smoke + lockdown | Tests + Key Vault private mode | ~5 min |

  Total ~55 min wall-clock. Each phase is independently re-runnable:
    ./azuresetup.sh --phase 1
    ./azuresetup.sh --phase 2

  ## Resume After Interruption
  State is persisted to .azuresetup.state after each step. To resume:
    ./azuresetup.sh --phase <last-completed>+1
  Or just rerun the current phase — every step checks "already exists"
  before creating.

  ## Non-Interactive Mode
  For CI/CD, set every required env var in advance and pass:
    ./azuresetup.sh --non-interactive

  ## Teardown
    ./azuresetup.sh --destroy
  This deletes the entire resource group. There is no surgical
  teardown — for that, use kubectl delete or write your own
  Terraform.

  ## Troubleshooting
  Three common failure modes with one-line diagnoses each:
  - "AKS provisioning stuck at 'Creating'" — usually a quota issue
    in the target region. Check vCPU quotas with:
      az vm list-usage -l $AZURE_LOCATION --query "[?contains(name.value, 'standardDSv5Family')]"
  - "Federated credential creation fails" — workload identity OIDC
    issuer is not yet propagated. Wait 60s and rerun Phase 1.
  - "AGC managed cert pending" — DNS CNAME to AGC FQDN not yet
    propagated. Wait up to 30 min after DNS update.

Create deploy/azure-aca/README.md with the demo equivalent. The
sections are the same but:
  - Cost cited is ~$70-80/mo active, ~$25/mo stopped
  - Only 2 phases
  - Total time ~30 min wall-clock (Redis is the long pole at 15 min)
  - Mention demo-start.sh and demo-stop.sh under "Phases" (Phase 2
    will create them)
  - Troubleshooting: "Container Apps revision stuck at provisioning"
    and "Postgres start command times out"

PART C — package.sh files

Create deploy/azure-aks/package.sh modeled on deploy/aws-ec2/package.sh
but trimmed for the Azure wizard. It should:
  - Read VERSION from the repo root pyproject.toml
  - Stage to /tmp/okta-mcp-azure-aks-${VERSION}/
  - Copy: azuresetup.sh, shell-lib/, manifests/, README.md, .env.example
  - Copy pyproject.toml from repo root for VERSION discovery
  - Exclude: .azuresetup.state, .env, dist/, .git, CLAUDE.md, tests/,
    __pycache__, *.pyc, *.docx, *.pptx, *.xlsx
  - Produce okta-mcp-azure-aks-${VERSION}.tar.gz with sha256
  - Support --version, --output-dir, --dry-run flags
  - Use the same color/info/ok/die helpers (or source common.sh
    if simpler)

Create deploy/azure-aca/package.sh as the demo equivalent. Same
shape, but copies acasetup.sh, shell-lib/, bicep/, README.md,
.env.example. Tarball name: okta-mcp-azure-aca-${VERSION}.tar.gz.

PART D — Smoke verification

Run the following structural checks against both wizards. Print the
result of each check and PASS or FAIL.

For each of azuresetup.sh and acasetup.sh:
  1. bash -n script.sh                              (parse check)
  2. shellcheck script.sh                           (skip if missing)
  3. ./script.sh --help                             (must exit 0)
  4. ./script.sh --phase 99 || true                 (must die with
                                                     phase validation)
  5. ./script.sh --phase 1 --non-interactive
       (only run if the operator has set
        AZURE_SMOKE_SUBSCRIPTION env var; otherwise skip and print
        "Skipped — set AZURE_SMOKE_SUBSCRIPTION to enable")

For each package.sh:
  1. bash -n package.sh
  2. ./package.sh --dry-run                          (lists files,
                                                      exits 0)

PART E — Final summary

Print a final summary listing:
  - Files created in this prompt (count and total size)
  - bash -n results table
  - shellcheck results table (or "skipped" rows)
  - --help output captured (just the first 5 lines of each)
  - --phase 99 error path captured
  - dry-run package output captured
  - If AZURE_SMOKE_SUBSCRIPTION was set, the actual Phase 1
    execution result for both wizards
  - Git status: which files are new vs modified

Recommend the operator commit and push:
  git add deploy/azure-aks deploy/azure-aca
  git commit -m "AZ6: Azure wizard scaffolding + Phase 1 complete"
```

### Expected Output

Two README files, two .env.example files, two package.sh files, and a clean smoke verification report. After this prompt, both wizards are runnable, both are documented, both are packageable into a tarball for distribution, and the next prompt pack can build out Phases 2-4 of AKS and Phase 2 of ACA.

---

## After Completion

When all six prompts have been run, you have a working scaffolding for both Azure wizards. To verify against a real Azure subscription:

```bash
# Set your test subscription
export AZURE_SUBSCRIPTION_ID=<your test sub>
export AZURE_LOCATION=eastus2

# Run the demo wizard Phase 1 (lower cost, faster)
cd deploy/azure-aca
cp .env.example .env
vi .env  # fill in AZURE_SUBSCRIPTION_ID
./acasetup.sh --phase 1
# ~20 minutes wall-clock (Redis is the long pole)

# Verify the resource group has the expected resources
az resource list -g okta-mcp-demo -o table

# Tear down
./acasetup.sh --destroy
```

Once that works, run the AKS wizard Phase 1 the same way against a different resource group. The AKS Phase 1 takes ~10 minutes and produces a working cluster you can poke at with `kubectl`.

## What's still outstanding after this pack

This pack only covers scaffolding + Phase 1. The next pack (call it `AZ7-AZ12`) will build out:

- **AKS Phase 2** — Postgres + Redis + Key Vault + secrets (~5 prompts of work)
- **AKS Phase 3** — Image build, manifest substitution, K8s apply, ALB controller, AGC, Gateway API resources (~5 prompts)
- **AKS Phase 4** — Container Insights, smoke tests, Key Vault lockdown, summary box (~2 prompts)
- **ACA Phase 2** — Image build, Bicep deploy, smoke tests, demo-stop.sh / demo-start.sh helpers (~3 prompts)

That's roughly 12-15 more prompts to fully complete both wizards. The reason for splitting at the scaffolding boundary is that you can verify the scaffolding pattern works on real Azure before committing to building Phases 2-4 — if Phase 1 reveals a flaw in the wizard structure (state management, prompting, helper functions), it's cheaper to fix it before there are 1500+ more lines of bash built on top.

## Open questions to resolve before AZ7

Three things worth deciding before the next pack:

1. **Image build mechanism** — `az acr build` runs builds inside Azure (slower per build but no local Docker required), or local `docker build` + `docker push` (faster if your laptop is fast and you're rebuilding repeatedly). The original Azure prompt pack used `az acr build` for both profiles. For the wizards I'd default to `az acr build` because the operator persona explicitly may not have Docker installed — the wizard should not require it. Confirm before AZ8 / AZ12.

2. **Custom hostnames on the demo** — the ACA wizard currently leaves the adapter on its `azurecontainerapps.io` FQDN. If the demo needs a vanity hostname, Phase 2 needs an extra step to call `az containerapp hostname add` and upload a cert. This is doable but adds operator burden. Default: skip it for the demo, document that customers wanting a vanity hostname should use the production wizard.

3. **Where Phase 4 lockdown of Key Vault should happen** — the production wizard creates Key Vault with public access enabled in Phase 2 so the `az` CLI from the operator's machine can write the secrets. Phase 4 then disables public access. This works but creates a window where the vault is internet-reachable. The alternative is to have the operator run Phase 2 from a jumpbox inside the VNet, which is cleaner but requires an extra resource. For the wizard I recommend keeping the current plan (public-then-disable) and documenting the trade-off in the README.
