# Global Logout (Okta ITP Universal Logout) — Implementation Prompts (v4)

**Target repository:** `joewitt99/okta-agent-mcp-adapter`
**Feature:** Implement the Global Token Revocation endpoint so Okta Identity Threat Protection (ITP) Universal Logout can revoke a user's tokens and sessions across the adapter.
**Spec references:**
- IETF: `draft-parecki-oauth-global-token-revocation-03`
- Okta admin config: https://help.okta.com/oie/en-us/content/topics/itp/config-universal-logout.htm
- Okta dev guide: https://developer.okta.com/docs/guides/oin-universal-logout-overview/

**Source baseline:** Reviewed against the source bundle dated 2026-04-29.

---

## Architecture context (read first)

**The adapter uses the Okta ORG authorization server, not a custom AS.** This is a deliberate architectural decision tied to the XAA (ID-JAG) flow: the originating token must come from the org AS today. Custom-AS code paths exist in the codebase for a future Okta capability that hasn't shipped yet, but are not exercised in production deployments.

In practice this means:

- `OKTA_ISSUER` in production is `https://{OKTA_DOMAIN}` (the org base URL).
- `GatewaySettings.issuer` (the property in `config.py`) returns this same value — either from `OKTA_ISSUER` env var, or derived from `OKTA_DOMAIN`.
- The org JWKS lives at `https://{OKTA_DOMAIN}/oauth2/v1/keys` and is what `OktaTokenValidator.fetch_jwks()` already returns when the validator is constructed against the org issuer.
- Universal Logout JWTs are signed with the org's signing keys (same keys as the OIDC app's id_tokens) and have `iss = https://{OKTA_DOMAIN}`.

**Implication for this design:** the JWT `iss` (in the auth header) and the request body's `subject.iss` (RFC 9493 identifier) are the **same value** for adapter-issued user tokens. There is no two-iss split. The single `settings.issuer` value validates both.

**Note on the RFC 8414 `issuer` split:** The adapter's OAuth AS discovery metadata advertises `issuer: {GATEWAY_BASE_URL}` (per RFC 8414 §3.3 byte-identity), but the inbound JWTs — both MCP client access tokens AND Universal Logout JWTs from Okta — have `iss = https://{OKTA_DOMAIN}` because Okta is the real signer. The Universal Logout endpoint therefore validates against `settings.issuer`, not against `GATEWAY_BASE_URL`. This mirrors the same split the existing `OktaTokenValidator` already implements for inbound access tokens.

**Forward-compat note:** the implementation reads `settings.issuer` (not `f"https://{okta_domain}"` directly) so that if the adapter is eventually deployed against a custom-AS originator, the Universal Logout code continues to work without modification. Whether Okta will sign Universal Logout JWTs with the custom AS or keep signing with the org AS is an **open question that must be re-verified against Okta's documentation at the time that capability ships**. Do not treat the forward-compat path as guaranteed to work — treat it as "best-effort, re-validate before relying on it."

---

## Design decisions (unchanged from v3)

- Subject format: **`iss_sub` only**. Other formats rejected with `400 unsupported_subject_format`. (Adapter design choice — Okta supports both; we choose immutable `sub` over mutable `email` because token mappings are sub-keyed.)
- Endpoint authentication: Signed JWT, validated against the org JWKS (which is what the existing `OktaTokenValidator` returns).
- JWT `typ` header check: `global-token-revocation+jwt`. Not verified by python-jose default options — we decode the unverified header separately and assert.
- JWT `nbf` validation explicit.
- Optional `GLOBAL_LOGOUT_EXPECTED_CLIENT_ID` env var to pin JWT `sub` to a specific Okta app (the Confidential Relay OIDC app's client_id). Recommended for production — narrows JWT auth to one app.
- Backend MCP session termination: fire-and-forget async, parallelized, per-call 3s timeout.
- Admin-UI "force logout" button: **deferred**.
- Response shape: `204 No Content` on success.
- Per Okta dev guide: return 204 (not 404) for unknown subjects to prevent enumeration.
- Rate limiter: `cachetools.TTLCache`-backed (bounded size + idle eviction), per-replica. No unbounded growth.

## Source-review confirmations (verified against 2026-04-29 snapshot)

- `UserTokenStore.aremove_by_user(user_sub)` exists at lines 361–408 and handles L1 + L2 + pub/sub. Constant `_USER_TOKEN_PREFIX = "user_token:"` at line 35.
- `TokenCache.invalidate(user_id)` does NOT cover STS keys (`sts:{user_hash}:{ri_hash}`). New methods needed.
- `MCPSessionManager.sessions` is local-only; no L2 enumeration. Multi-replica is a known limitation.
- `python-jose` is the JWT lib in use.
- `GatewaySettings.issuer` property lives at `config.py:266`.
- `get_validator()` lives at `okta_validator.py:359`.
- `CorrelationIdMiddleware.clear_request_context()` runs in `finally` (middleware/correlation.py:55). Background tasks must capture+re-set context.
- `set_request_context` replaces ALL context vars (context.py:20) — pass through the full snapshot, don't call with only correlation_id if other context matters.
- `emit_audit_event` signature: `(event_type, severity, resource_name, details, outcome)`. User/agent/IP come from contextvars, NOT kwargs.
- Routes are a flat list; new route must precede the catch-all `Route("/{path:path}", mcp_proxy, ...)`.
- `proxy_handler.session_manager` (handler.py:108) and `router.resource_token_cache` (router.py:195) are the live singletons.

**Execution guidance:** one prompt at a time in Claude Code. Review diff, run full suite, commit, proceed. Recovery: `git reset --hard HEAD`.

**Prompt pack size:** 9 sequential prompts.

---

## Prompt 1: Add Global Logout audit events

### Context

We add the new event types first so subsequent prompts can reference them without forward-declaration. The enum lives in `okta_agent_proxy/audit/events.py`. The last existing member is `CONFIG_PORT_VALIDATION_WARNING` at line 90. Severities used by callers: `INFO` and `WARNING` (no `CRITICAL`, no `ERROR`).

### Prompt

```
Add the following new event types to the AuditEventType enum in
okta_agent_proxy/audit/events.py. Place them at the very end of the
enum (after CONFIG_PORT_VALIDATION_WARNING), grouped under a comment
"# Global logout events (Okta ITP Universal Logout)":

  GLOBAL_LOGOUT_REQUESTED = "global_logout.requested"
  GLOBAL_LOGOUT_AUTH_FAILED = "global_logout.auth.failed"
  GLOBAL_LOGOUT_SUBJECT_INVALID = "global_logout.subject.invalid"
  GLOBAL_LOGOUT_SUBJECT_NOT_FOUND = "global_logout.subject.not_found"
  GLOBAL_LOGOUT_COMPLETED = "global_logout.completed"
  GLOBAL_LOGOUT_BACKEND_SESSION_TERMINATED = "global_logout.backend_session.terminated"
  GLOBAL_LOGOUT_BACKEND_SESSION_FAILED = "global_logout.backend_session.failed"

Severity semantics that callers in later prompts will use (do NOT
encode these in the enum itself):
  REQUESTED, COMPLETED (success), BACKEND_SESSION_TERMINATED,
  SUBJECT_NOT_FOUND -> AuditSeverity.INFO
  AUTH_FAILED, SUBJECT_INVALID, BACKEND_SESSION_FAILED,
  COMPLETED (failure) -> AuditSeverity.WARNING

Do NOT modify any existing event types or any other code in events.py.
Do NOT add to audit/__init__.py exports — the AuditEventType enum is
already exported wholesale.

Add tests/test_global_logout_audit_events.py with seven trivial
assertions:

  def test_global_logout_requested_exists():
      assert AuditEventType.GLOBAL_LOGOUT_REQUESTED.value == "global_logout.requested"

...and similar for the other six.

Run: pytest tests/test_global_logout_audit_events.py -v
```

### Expected output

- 7 new members in `AuditEventType`.
- 1 new test file with 7 assertions.
- `pytest tests/ -q` still passes.

---

## Prompt 2: Confirm `UserTokenStore.aremove_by_user` and lock the contract

### Context

`UserTokenStore.aremove_by_user(user_sub: str) -> int` already exists at lines 361–408. Iterates L1 with deserialize-and-match, calls `clear_prefix` on L2, emits `USER_TOKEN_STORE_REMOVE` audit, publishes per-key invalidation if event_bus is wired, returns L1 count. No production change needed; we add a confirming test file.

The L2 prefix constant is `_USER_TOKEN_PREFIX` defined in `okta_agent_proxy/auth/user_token_store.py`. Tests import the constant rather than hardcoding the literal string, so a future rename is caught by test failure, not by silent drift.

### Prompt

```
Open okta_agent_proxy/auth/user_token_store.py and confirm that
aremove_by_user(user_sub: str) -> int exists at roughly lines 361-408
and matches the contract in the prompt-pack header. Do NOT modify
the method. If the implementation differs, STOP and report rather
than editing.

Create tests/test_user_token_store_global_logout.py:

  import pytest
  from unittest.mock import AsyncMock
  from okta_agent_proxy.auth.user_token_store import (
      UserTokenStore, _USER_TOKEN_PREFIX,
  )

  @pytest.mark.asyncio
  async def test_aremove_by_user_removes_matching_entries():
      store = UserTokenStore(encryption_service=None,
                             default_ttl=86400, max_size=1000)
      store.store("at-1", "id1", "rt1", "userA", "agent1")
      store.store("at-2", "id2", "rt2", "userA", "agent2")
      store.store("at-3", "id3", "rt3", "userB", "agent1")
      count = await store.aremove_by_user("userA")
      assert count == 2
      assert store.lookup("at-1") is None
      assert store.lookup("at-2") is None
      assert store.lookup("at-3") is not None

  @pytest.mark.asyncio
  async def test_aremove_by_user_with_encryption(encryption_service):
      store = UserTokenStore(encryption_service=encryption_service,
                             default_ttl=86400, max_size=1000)
      store.store("at-1", "id1", "rt1", "userA", "agent1")
      store.store("at-2", "id2", "rt2", "userB", "agent1")
      count = await store.aremove_by_user("userA")
      assert count == 1
      assert store.lookup("at-1") is None
      assert store.lookup("at-2") is not None

  @pytest.mark.asyncio
  async def test_aremove_by_user_zero_when_no_match():
      store = UserTokenStore(encryption_service=None,
                             default_ttl=86400, max_size=1000)
      store.store("at-1", "id1", "rt1", "userA", "agent1")
      assert await store.aremove_by_user("userZ") == 0
      assert store.lookup("at-1") is not None

  @pytest.mark.asyncio
  async def test_aremove_by_user_calls_l2_clear_prefix():
      mock_cs = AsyncMock()
      store = UserTokenStore(encryption_service=None,
                             default_ttl=86400, max_size=1000,
                             cache_service=mock_cs)
      store.store("at-1", "id1", "rt1", "userA", "agent1")
      await store.aremove_by_user("userA")
      mock_cs.clear_prefix.assert_awaited_once_with(_USER_TOKEN_PREFIX)

  @pytest.mark.asyncio
  async def test_aremove_by_user_publishes_pubsub_when_event_bus_wired():
      mock_bus = AsyncMock()
      store = UserTokenStore(encryption_service=None,
                             default_ttl=86400, max_size=1000,
                             event_bus=mock_bus)
      store.store("at-1", "id1", "rt1", "userA", "agent1")
      store.store("at-2", "id2", "rt2", "userA", "agent2")
      count = await store.aremove_by_user("userA")
      assert count == 2
      assert mock_bus.publish.await_count == 2

  @pytest.mark.asyncio
  async def test_aremove_by_user_no_publish_when_count_is_zero():
      mock_bus = AsyncMock()
      store = UserTokenStore(encryption_service=None,
                             default_ttl=86400, max_size=1000,
                             event_bus=mock_bus)
      await store.aremove_by_user("userA")
      mock_bus.publish.assert_not_awaited()

Use the real `encryption_service` fixture from tests/conftest.py
(function-scoped, uses AES-GCM with a session-level test key).
The `mock_encryption_service` fixture has a 16-byte IV but
cache/serializers.py slices the first 12 bytes as IV — round-trip
deserialization corrupts the JSON, so the encryption path must use
the real service for assertions to hold.

Run: pytest tests/test_user_token_store_global_logout.py -v
```

### Expected output

- No production code changes.
- New test file with 6 async tests, all passing.

---

## Prompt 3: Add user-scoped sweep methods to `MCPSessionManager` and `TokenCache`

### Context

Two store-side gaps:

**`MCPSessionManager`**: has `terminate_session(user_id, resource_name, resource_url, session_id)` for one backend. We add a fan-out that snapshots local sessions for a user and parallel-terminates each. `MCPSessionManager.sessions` is a local `cachetools.TTLCache`; CacheService L2 has no enumeration API. Peer replicas can't be reached. Documented in P9.

**`TokenCache.invalidate(user_id)`** clears keys with raw `user_id` prefix but does NOT cover STS keys (`sts:{sha256(user_id)[:12]}:{sha256(ri)[:12]}`). We expose BOTH sync and async variants of the new method:

- `invalidate_all_for_user(user_id)` — sync, existing call-site style.
- `ainvalidate_all_for_user(user_id)` — async, calls `CacheService` directly via `await` instead of the blocking thread-pool fallback in `_run_async`. The orchestrator in P4 calls the async variant to avoid blocking the handler's event loop under load.

### Prompt

```
TASK A — okta_agent_proxy/proxy/session_manager.py

Update the audit import to include AuditSeverity:

    from okta_agent_proxy.audit import emit_audit_event, AuditEventType, AuditSeverity

Add a new async method to MCPSessionManager (place it immediately
after terminate_session, before invalidate_session):

    async def terminate_all_for_user(
        self,
        user_id: str,
        per_call_timeout: float = 3.0,
    ) -> dict[str, bool]:
        """
        Terminate all locally-cached MCP sessions for a user across all
        backends, in parallel, with a per-call timeout.

        Used by global logout. Only iterates self.sessions (local L1).
        In multi-replica deployments, sessions held by peer replicas
        will not be terminated by this call — peer replicas' caches
        cannot be enumerated through CacheService. Those backend
        sessions die when the cache TTL expires; the UserTokenStore
        cross-pod pub/sub already cuts the user off at Layer 2 on
        every peer.

        Behavior:
        1. Snapshot keys of self.sessions matching f"{user_id}:" prefix
           and capture each entry's session_id and resource_url.
        2. If no matches, return {} immediately (no audit events).
        3. For each match, fire terminate_session in parallel via
           asyncio.gather with return_exceptions=True. Each call is
           wrapped in asyncio.wait_for(..., timeout=per_call_timeout).
        4. Per result:
           - True: emit GLOBAL_LOGOUT_BACKEND_SESSION_TERMINATED
             at INFO with resource_name and details
             {"user_id": user_id, "resource_name": resource_name}.
           - False / TimeoutError / Exception: emit
             GLOBAL_LOGOUT_BACKEND_SESSION_FAILED at WARNING with
             outcome="failure" and details
             {"user_id": user_id, "resource_name": resource_name,
              "error": exc_class_name + ": " + str(exc)[:180]}
             (or "non_2xx_response" if False without exception).
        5. Return dict[resource_name -> bool].

Imports needed beyond the updated audit import: asyncio (already
imported).

TASK B — okta_agent_proxy/cache/token_cache.py

Add TWO new methods to TokenCache, placed immediately after invalidate:

    def invalidate_all_for_user(self, user_id: str) -> None:
        """Sync convenience wrapper. Prefer ainvalidate_all_for_user
        from async call-sites (it does not block on the thread-pool
        fallback used by _run_async under a running loop).
        """
        self._invalidate_user_id_family(user_id)
        self._invalidate_sts_family(user_id)

    async def ainvalidate_all_for_user(self, user_id: str) -> None:
        """Async variant — awaits CacheService directly.

        Orchestrator (auth/global_logout.py) calls this.
        """
        await self._ainvalidate_user_id_family(user_id)
        await self._ainvalidate_sts_family(user_id)

Also add the four private helpers below invalidate_all_for_user:

    # ---- Helpers for invalidate_all_for_user / ainvalidate_all_for_user ----

    def _invalidate_user_id_family(self, user_id: str) -> None:
        """Clear ID-JAG / connection-scoped keys for a user (sync)."""
        self.invalidate(user_id)

    async def _ainvalidate_user_id_family(self, user_id: str) -> None:
        """Clear ID-JAG / connection-scoped keys for a user (async)."""
        if self._cache_service:
            try:
                prefix = f"{_TOKEN_PREFIX}{user_id}"
                count = await self._cache_service.clear_prefix(prefix)
                logger.info(
                    f"All tokens invalidated (service) for user: {user_id} ({count} tokens)"
                )
            except Exception as e:
                logger.warning(f"CacheService clear_prefix failed, falling back to local: {e}")
        keys_to_delete = [
            k for k in list(self.cache.keys())
            if isinstance(k, str) and k.startswith(user_id)
        ]
        for key in keys_to_delete:
            self.cache.pop(key, None)
        if keys_to_delete:
            logger.info(
                f"All tokens invalidated (local) for user: {user_id} ({len(keys_to_delete)} tokens)"
            )

    @staticmethod
    def _sts_prefix_for_user(user_id: str) -> str:
        import hashlib
        user_hash = hashlib.sha256(user_id.encode()).hexdigest()[:12]
        return f"sts:{user_hash}:"

    def _invalidate_sts_family(self, user_id: str) -> None:
        """Clear sts:<user_hash>:* entries (sync)."""
        sts_prefix = self._sts_prefix_for_user(user_id)
        if self._cache_service:
            try:
                self._run_async(
                    self._cache_service.clear_prefix(f"{_TOKEN_PREFIX}{sts_prefix}")
                )
                logger.info(
                    f"[TOKEN-CACHE] STS sweep (service) for prefix={sts_prefix}"
                )
            except Exception as e:
                logger.warning(
                    f"CacheService STS clear_prefix failed, falling back to local: {e}"
                )
        local_keys = [k for k in list(self.cache.keys())
                      if isinstance(k, str) and k.startswith(sts_prefix)]
        for k in local_keys:
            self.cache.pop(k, None)
        if local_keys:
            logger.info(
                f"[TOKEN-CACHE] STS swept {len(local_keys)} local entries "
                f"for prefix={sts_prefix}"
            )

    async def _ainvalidate_sts_family(self, user_id: str) -> None:
        """Clear sts:<user_hash>:* entries (async)."""
        sts_prefix = self._sts_prefix_for_user(user_id)
        if self._cache_service:
            try:
                await self._cache_service.clear_prefix(f"{_TOKEN_PREFIX}{sts_prefix}")
                logger.info(
                    f"[TOKEN-CACHE] STS sweep (service) for prefix={sts_prefix}"
                )
            except Exception as e:
                logger.warning(
                    f"CacheService STS clear_prefix failed, falling back to local: {e}"
                )
        local_keys = [k for k in list(self.cache.keys())
                      if isinstance(k, str) and k.startswith(sts_prefix)]
        for k in local_keys:
            self.cache.pop(k, None)
        if local_keys:
            logger.info(
                f"[TOKEN-CACHE] STS swept {len(local_keys)} local entries "
                f"for prefix={sts_prefix}"
            )

TASK C — Tests

Create tests/test_session_manager_global_logout.py:

  - test_terminate_all_for_user_empty_returns_empty_dict
  - test_terminate_all_for_user_calls_each_backend
  - test_terminate_all_for_user_handles_partial_failure
  - test_terminate_all_for_user_respects_timeout
  - test_terminate_all_for_user_emits_correct_audit_events
       (use capture_emitter pattern from
       tests/test_audit_proxy_instrumentation.py, await
       asyncio.sleep(0.15) for emitter flush)
  - test_terminate_all_for_user_only_matches_user_prefix
       (substring trap: "user1" vs "user12")

Create tests/test_token_cache_global_logout.py:

  - test_invalidate_all_for_user_clears_idjag_keys
  - test_invalidate_all_for_user_clears_sts_keys_for_user
  - test_invalidate_all_for_user_clears_both_families
  - test_invalidate_all_for_user_no_match_is_noop
  - test_ainvalidate_all_for_user_uses_cache_service_awaitably
       (construct with mock cache_service whose clear_prefix is an
       AsyncMock; call ainvalidate_all_for_user and assert
       clear_prefix was awaited — not thread-pool-submitted)
  - test_ainvalidate_all_for_user_clears_both_families_without_service
       (no cache_service; verify local sweep covers both user_id
       prefix and STS sts:<hash>: prefix)

Run:
  pytest tests/test_session_manager_global_logout.py -v
  pytest tests/test_token_cache_global_logout.py -v
```

### Expected output

- `terminate_all_for_user` added to `MCPSessionManager`.
- `invalidate_all_for_user` (sync) and `ainvalidate_all_for_user` (async) + helpers added to `TokenCache`.
- 12 new tests across two files, all passing.

---

## Prompt 4: Create the `GlobalLogoutHandler` orchestrator

### Context

HTTP-agnostic orchestrator. DI for testability. Steps 1+2 are required; step 3 is best-effort. Per Okta dev doc: return 204 (not 404) for unknown subjects to prevent enumeration. Handler emits `GLOBAL_LOGOUT_SUBJECT_NOT_FOUND` when both `tokens_revoked` and `sessions_terminated` are 0, but still returns successfully.

The orchestrator calls `ainvalidate_all_for_user` (async) rather than `invalidate_all_for_user` (sync) so the handler's event loop is not blocked by the CacheService thread-pool fallback.

### Prompt

```
Create okta_agent_proxy/auth/global_logout.py with:

"""
Global Logout Handler — orchestrates revocation in response to Okta
ITP Universal Logout calls.

This module is HTTP-agnostic. The Starlette route handler in
auth/global_logout_route.py validates the inbound signed JWT and
parses the iss_sub Subject Identifier, then calls
GlobalLogoutHandler.revoke_user(sub, correlation_id).

Revocation sequence:
  1. UserTokenStore.aremove_by_user(user_sub)
       -> drops L1 + L2 entries, emits pub/sub for cross-pod invalidation.
  2. TokenCache.ainvalidate_all_for_user(user_sub)
       -> drops cached backend tokens (ID-JAG and STS) via awaitable
          CacheService calls (no thread-pool fallback blocking).
  3. MCPSessionManager.terminate_all_for_user(user_sub)
       -> fires DELETE to each backend MCP server in parallel.

Step 3 errors do NOT fail the revocation overall — the user is already
cut off at Layer 2 once steps 1 and 2 complete.

Per Okta's dev guide for Universal Logout, an unrecognized subject
returns HTTP 204 (NOT 404) to prevent user-account enumeration. This
handler emits GLOBAL_LOGOUT_SUBJECT_NOT_FOUND when both tokens_revoked
and sessions_terminated are 0, but still returns successfully.
"""

import asyncio
import logging
from typing import Optional, Tuple

from okta_agent_proxy.audit import emit_audit_event
from okta_agent_proxy.audit.events import AuditEventType, AuditSeverity

logger = logging.getLogger(__name__)


class GlobalLogoutHandler:
    """Orchestrates user-scoped revocation across stores and sessions."""

    def __init__(
        self,
        token_store=None,
        token_cache=None,
        session_manager=None,
    ):
        """DI-friendly constructor. None args resolve to singletons
        on first use."""
        self._token_store = token_store
        self._token_cache = token_cache
        self._session_manager = session_manager

    def _get_token_store(self):
        if self._token_store is not None:
            return self._token_store
        from okta_agent_proxy.auth.user_token_store import get_user_token_store
        return get_user_token_store()

    def _get_token_cache(self):
        if self._token_cache is not None:
            return self._token_cache
        from okta_agent_proxy import app as app_module
        return app_module.router.resource_token_cache

    def _get_session_manager(self):
        if self._session_manager is not None:
            return self._session_manager
        from okta_agent_proxy import app as app_module
        return app_module.proxy_handler.session_manager

    @staticmethod
    def parse_iss_sub_subject(subject) -> Tuple[str, str]:
        """Validate and unpack an RFC 9493 iss_sub Subject Identifier.

        Returns (iss, sub).

        Raises ValueError with a description safe to return as
        error_description (no PII beyond what was in the request).

        NOTE: Okta supports both 'iss_sub' and 'email' formats at
        config time. This adapter accepts ONLY 'iss_sub' because:
          - sub is immutable; email is mutable.
          - Token mappings in UserTokenStore are keyed by Okta's sub.
        Operators must select 'Issuer and Subject Identifier' in
        the Okta Logout app config, NOT 'Email Identifier'.
        """
        if not isinstance(subject, dict):
            raise ValueError("subject must be a JSON object")

        fmt = subject.get("format")
        if fmt is None:
            raise ValueError("subject is missing required 'format' field")
        if fmt != "iss_sub":
            raise ValueError(
                f"unsupported subject format {fmt!r}; only 'iss_sub' is accepted"
            )

        iss = subject.get("iss")
        sub = subject.get("sub")

        if not isinstance(iss, str) or not iss.strip():
            raise ValueError("subject is missing or has empty 'iss' field")
        if not isinstance(sub, str) or not sub.strip():
            raise ValueError("subject is missing or has empty 'sub' field")

        return iss, sub

    async def revoke_user(self, user_sub: str, correlation_id: str) -> dict:
        """Perform full revocation for a single user. Returns a summary.

        Summary shape:
          {
            "user_sub": str,
            "correlation_id": str,
            "tokens_revoked": int,
            "cache_swept": bool,
            "sessions_terminated": int,
            "sessions_failed": int,
            "backends": dict[resource_name -> bool],
          }

        On unrecoverable error in step 1 or step 2: emit
        GLOBAL_LOGOUT_COMPLETED with outcome="failure" and re-raise.
        Step 3 errors are absorbed (the user is already cut off).
        """
        summary = {
            "user_sub": user_sub,
            "correlation_id": correlation_id,
            "tokens_revoked": 0,
            "cache_swept": False,
            "sessions_terminated": 0,
            "sessions_failed": 0,
            "backends": {},
        }

        # Step 1: token store
        try:
            store = self._get_token_store()
            count = await store.aremove_by_user(user_sub)
            summary["tokens_revoked"] = count
        except Exception as exc:
            logger.exception(
                "[GLOBAL-LOGOUT] aremove_by_user failed for sub=%s", user_sub
            )
            await emit_audit_event(
                AuditEventType.GLOBAL_LOGOUT_COMPLETED,
                severity=AuditSeverity.WARNING,
                outcome="failure",
                details={
                    "step": "token_store",
                    "error": f"{type(exc).__name__}: {str(exc)[:180]}",
                    "user_sub": user_sub,
                },
            )
            raise

        # Step 2: token cache (async path — no thread-pool blocking)
        try:
            cache = self._get_token_cache()
            await cache.ainvalidate_all_for_user(user_sub)
            summary["cache_swept"] = True
        except Exception as exc:
            logger.exception(
                "[GLOBAL-LOGOUT] ainvalidate_all_for_user failed for sub=%s",
                user_sub,
            )
            await emit_audit_event(
                AuditEventType.GLOBAL_LOGOUT_COMPLETED,
                severity=AuditSeverity.WARNING,
                outcome="failure",
                details={
                    "step": "token_cache",
                    "error": f"{type(exc).__name__}: {str(exc)[:180]}",
                    "user_sub": user_sub,
                    "tokens_revoked": summary["tokens_revoked"],
                },
            )
            raise

        # Step 3: backend MCP sessions (best-effort)
        try:
            sm = self._get_session_manager()
            backends = await sm.terminate_all_for_user(user_sub)
            summary["backends"] = backends
            summary["sessions_terminated"] = sum(1 for v in backends.values() if v)
            summary["sessions_failed"] = sum(1 for v in backends.values() if not v)
        except Exception:
            logger.exception(
                "[GLOBAL-LOGOUT] terminate_all_for_user raised for sub=%s",
                user_sub,
            )
            # Do not re-raise — the user is already cut off

        # Final outcome event
        await emit_audit_event(
            AuditEventType.GLOBAL_LOGOUT_COMPLETED,
            severity=AuditSeverity.INFO,
            details={
                "user_sub": user_sub,
                "tokens_revoked": summary["tokens_revoked"],
                "cache_swept": summary["cache_swept"],
                "sessions_terminated": summary["sessions_terminated"],
                "sessions_failed": summary["sessions_failed"],
                "backends": summary["backends"],
            },
        )

        # Per Okta dev doc: do not 404 on unknown subject (enumeration
        # mitigation). We still record an audit event for ops visibility.
        if summary["tokens_revoked"] == 0 and summary["sessions_terminated"] == 0:
            await emit_audit_event(
                AuditEventType.GLOBAL_LOGOUT_SUBJECT_NOT_FOUND,
                severity=AuditSeverity.INFO,
                details={"user_sub": user_sub},
            )

        return summary


# ------------------------------------------------------------------
# Singleton accessor
# ------------------------------------------------------------------

_handler: Optional[GlobalLogoutHandler] = None


def get_global_logout_handler() -> GlobalLogoutHandler:
    global _handler
    if _handler is None:
        _handler = GlobalLogoutHandler()
    return _handler


def reset_global_logout_handler() -> None:
    """Test-only."""
    global _handler
    _handler = None


Create tests/test_global_logout_handler.py with tests below. Use the
CaptureSink + capture_emitter fixture pattern from
tests/test_audit_proxy_instrumentation.py. Mock token_cache with an
AsyncMock whose ainvalidate_all_for_user is awaitable.

  --- parse_iss_sub_subject ---
  test_parse_iss_sub_happy_path
  test_parse_iss_sub_rejects_email_format
  test_parse_iss_sub_rejects_missing_format
  test_parse_iss_sub_rejects_missing_iss
  test_parse_iss_sub_rejects_missing_sub
  test_parse_iss_sub_rejects_empty_iss
  test_parse_iss_sub_rejects_empty_sub
  test_parse_iss_sub_rejects_non_dict_input

  --- revoke_user with mocks ---
  test_revoke_user_happy_path
  test_revoke_user_no_active_sessions  (tokens_revoked=2, no SUBJECT_NOT_FOUND)
  test_revoke_user_zero_tokens_zero_sessions_emits_subject_not_found
  test_revoke_user_partial_session_failure
  test_revoke_user_token_store_raises_emits_failure_and_reraises
  test_revoke_user_token_cache_raises_emits_failure_and_reraises
  test_revoke_user_session_manager_raises_does_not_reraise
  test_singleton_accessor_returns_same_instance
  test_reset_singleton

Do NOT wire this module into app.py yet.

Run: pytest tests/test_global_logout_handler.py -v
```

### Expected output

- `okta_agent_proxy/auth/global_logout.py` created.
- `tests/test_global_logout_handler.py` with ~17 tests, all passing.

---

## Prompt 5: Create the `/oauth/global-token-revocation` HTTP endpoint

### Context

Per Okta's dev guide for Universal Logout, the inbound JWT looks like:

```
// Header
{ "typ": "global-token-revocation+jwt", "alg": "RS256", "kid": "..." }
// Payload
{
  "jti": "{unique identifier}",
  "iss": "{orgDomainBaseUrl}",                 // org base URL
  "sub": "{client_id of OIDC app}",            // calling Okta APP, not user
  "aud": "{revocation endpoint URL}",
  "iat": <now>,
  "nbf": <now - 5m>,
  "exp": <now + 5m>
}
```

**Architecture context:** The adapter uses the Okta org authorization server. `OKTA_ISSUER` in production is `https://{OKTA_DOMAIN}`. `GatewaySettings.issuer` returns this single value. The same value covers:

- The JWT `iss` claim (org signs the JWT).
- The body `subject.iss` claim (the org AS issues the user tokens we have mappings for).
- The JWKS issuer used to resolve signing keys (`OktaTokenValidator.fetch_jwks()` already targets this).

There is no two-iss split — the existing validator's JWKS is the right keyset and `settings.issuer` is the single comparison value for both checks.

**Context handling:** `CorrelationIdMiddleware` already populates `correlation_id`, `ip_address`, and `user_agent` context vars before this handler runs. The handler SHOULD NOT call `set_request_context(correlation_id=...)` at its top — doing so would clobber `ip_address` and `user_agent` with None (because `set_request_context` sets all vars at once). Instead, pull the current correlation_id via `get_correlation_id()` (generating a fresh one only if none is present, which should not happen when the middleware is wired but is safe for direct-Starlette tests). For the background task, snapshot the full context with `get_request_context()` and re-apply it with `set_request_context(**snapshot)` so emitted events from the bg task still carry IP and UA.

**Rate limiter:** `cachetools.TTLCache` with bounded size. One entry per IP; each entry is a list of monotonic timestamps within the rolling 60s window. TTLCache idle-evicts entries whose last access is older than the cache TTL (we use 120s so the eviction lags the rate window and never drops a hot IP mid-window). The `maxsize` caps dictionary growth under sustained unique-IP load.

### Prompt

```
Create okta_agent_proxy/auth/global_logout_route.py with:

"""
Starlette route handler for /oauth/global-token-revocation.

Implements the Global Token Revocation endpoint
(draft-parecki-oauth-global-token-revocation) so Okta Identity
Threat Protection (ITP) Universal Logout can revoke a user's
tokens and sessions on the adapter.

JWT format (per Okta dev guide, see
https://developer.okta.com/docs/guides/oin-universal-logout-overview/):

  Header:
    typ = "global-token-revocation+jwt"
    alg = signing algorithm (RS256)
    kid = key id from Okta JWKS

  Payload:
    jti = unique identifier
    iss = the issuer of user tokens (the adapter's authorization server)
    sub = client_id of the calling Okta OIDC app
          (the Confidential Relay app's client_id in this adapter)
    aud = the revocation endpoint URL (no query/fragment)
    exp = 5 min in the future
    nbf = 5 min in the past
    iat = current timestamp

The adapter currently uses the Okta org authorization server, so
settings.issuer == https://{OKTA_DOMAIN} and the JWKS URL is
https://{OKTA_DOMAIN}/oauth2/v1/keys. The existing OktaTokenValidator
already fetches and caches that JWKS — we reuse it.

The body subject.iss must match settings.issuer (same value).

Subject identifier format: 'iss_sub' ONLY. 'email' format is rejected
with 400 unsupported_subject_format.

Response codes:
  204 No Content — revocation accepted (also when subject not found,
                   per Okta dev guide on enumeration mitigation).
  400 Bad Request — malformed body or unsupported subject format.
  401 Unauthorized — JWT missing, expired, typ wrong, or sig invalid.
  429 Too Many Requests — rate limit exceeded.

Rate limiter: cachetools.TTLCache-backed, bounded size + idle
eviction. Per-replica counters.

Context handling: CorrelationIdMiddleware already populates the
correlation_id / ip_address / user_agent context vars. We snapshot
that context at handler entry and reapply it inside the scheduled
background task so audit events emitted by the bg task carry IP/UA.

Audit-event flow:
  GLOBAL_LOGOUT_REQUESTED (always, top of handler)
  GLOBAL_LOGOUT_AUTH_FAILED (on JWT failure)
  GLOBAL_LOGOUT_SUBJECT_INVALID (on subject parse / iss mismatch)
  GLOBAL_LOGOUT_COMPLETED (from background task, success or failure)
  GLOBAL_LOGOUT_BACKEND_SESSION_TERMINATED / _FAILED (from sm fan-out)
  GLOBAL_LOGOUT_SUBJECT_NOT_FOUND (when nothing to revoke)
"""

GLOBAL_LOGOUT_PATH = "/oauth/global-token-revocation"

import asyncio
import logging
import os
import time
import uuid
from typing import Optional

import cachetools
from jose import jwt as jose_jwt, JWTError
from starlette.requests import Request
from starlette.responses import JSONResponse, Response

from okta_agent_proxy.audit import emit_audit_event
from okta_agent_proxy.audit.events import AuditEventType, AuditSeverity
from okta_agent_proxy.audit.context import (
    get_correlation_id,
    get_request_context,
    set_request_context,
)
from okta_agent_proxy.auth.global_logout import get_global_logout_handler
from okta_agent_proxy.auth.okta_validator import get_validator
from okta_agent_proxy.config import GatewaySettings

logger = logging.getLogger(__name__)


# ------------------------------------------------------------------
# Constants from Okta spec
# ------------------------------------------------------------------

EXPECTED_TYP = "global-token-revocation+jwt"


# ------------------------------------------------------------------
# Rate limiter (cachetools.TTLCache — bounded size + idle eviction)
# ------------------------------------------------------------------

_RATE_LIMIT_MAX = int(os.environ.get("GLOBAL_LOGOUT_RATE_LIMIT_PER_MIN", "100"))
_RATE_LIMIT_WINDOW = 60.0
_RATE_LIMIT_MAX_IPS = int(os.environ.get("GLOBAL_LOGOUT_RATE_LIMIT_MAX_IPS", "4096"))
# TTL 2x the window so hot IPs are never evicted mid-window; cold IPs age out.
_rate_limit_state: cachetools.TTLCache = cachetools.TTLCache(
    maxsize=_RATE_LIMIT_MAX_IPS, ttl=_RATE_LIMIT_WINDOW * 2
)


def _check_rate_limit(ip: str) -> bool:
    """True if allowed. Per-replica, bounded in memory."""
    now = time.monotonic()
    bucket = _rate_limit_state.get(ip)
    if bucket is None:
        bucket = []
        _rate_limit_state[ip] = bucket  # inserts + resets TTL
    cutoff = now - _RATE_LIMIT_WINDOW
    bucket[:] = [t for t in bucket if t > cutoff]
    if len(bucket) >= _RATE_LIMIT_MAX:
        return False
    bucket.append(now)
    # Re-set to refresh TTL on access (TTLCache refreshes on __setitem__, not get)
    _rate_limit_state[ip] = bucket
    return True


def _reset_rate_limiter() -> None:
    """Test-only."""
    _rate_limit_state.clear()


# ------------------------------------------------------------------
# JWT verification
# ------------------------------------------------------------------

def _expected_audience() -> str:
    """The aud claim Okta puts in the signed logout JWT.

    Default: GATEWAY_BASE_URL + GLOBAL_LOGOUT_PATH.
    Override via GLOBAL_LOGOUT_AUDIENCE env var if Okta is configured
    with a non-default value.
    """
    override = os.environ.get("GLOBAL_LOGOUT_AUDIENCE")
    if override:
        return override
    settings = GatewaySettings()
    return f"{settings.gateway_base_url}{GLOBAL_LOGOUT_PATH}"


def _expected_client_id() -> Optional[str]:
    """Optional pinning of the JWT sub claim to a specific Okta app's
    client_id. When set, narrows JWT auth to that one app.

    Recommended for production: most operators run a single Confidential
    Relay OIDC app and can set GLOBAL_LOGOUT_EXPECTED_CLIENT_ID to its
    client_id for tighter security."""
    val = os.environ.get("GLOBAL_LOGOUT_EXPECTED_CLIENT_ID", "").strip()
    return val or None


async def _verify_logout_jwt(token: str) -> dict:
    """Verify Okta-signed logout JWT. Returns claims or raises ValueError.

    Per Okta dev guide for Universal Logout, validates:
      - typ header == "global-token-revocation+jwt"
      - alg == RS256
      - signature against settings.issuer's JWKS (org JWKS)
      - iss == settings.issuer
      - aud == GATEWAY_BASE_URL + path (or override)
      - exp not expired
      - nbf not before (with small leeway)
      - sub == GLOBAL_LOGOUT_EXPECTED_CLIENT_ID (if pinned)
    """
    if not token:
        raise ValueError("empty token")

    # 1. Header check (typ — non-standard, python-jose doesn't verify it)
    try:
        header = jose_jwt.get_unverified_header(token)
    except JWTError as exc:
        raise ValueError(f"malformed_jwt: {exc}") from exc

    typ = header.get("typ")
    if typ != EXPECTED_TYP:
        raise ValueError(
            f"unexpected_typ: got {typ!r}, expected {EXPECTED_TYP!r}"
        )

    # 2. Signature + standard claims via the existing OktaTokenValidator
    settings = GatewaySettings()
    validator = get_validator()
    jwks = await validator.fetch_jwks()
    expected_iss = settings.issuer
    expected_aud = _expected_audience()

    try:
        claims = jose_jwt.decode(
            token,
            key=jwks,
            algorithms=["RS256"],
            issuer=expected_iss,
            audience=expected_aud,
            options={
                "verify_signature": True,
                "verify_iss": True,
                "verify_aud": True,
                "verify_exp": True,
                "require_exp": True,
                # python-jose verifies nbf when present; explicit for clarity
                "verify_nbf": True,
            },
        )
    except JWTError as exc:
        raise ValueError(f"jwt_verification_failed: {exc}") from exc

    # 3. Optional sub pinning
    expected_sub = _expected_client_id()
    if expected_sub:
        actual_sub = claims.get("sub")
        if actual_sub != expected_sub:
            raise ValueError(
                f"sub_mismatch: got {actual_sub!r}, "
                f"expected {expected_sub!r}"
            )

    return claims


# ------------------------------------------------------------------
# Route handler
# ------------------------------------------------------------------

def _bad_request(code: str, description: str) -> JSONResponse:
    return JSONResponse(
        {"error": code, "error_description": description},
        status_code=400,
    )


async def global_token_revocation(request: Request) -> Response:
    """POST /oauth/global-token-revocation — Okta ITP Universal Logout."""
    # CorrelationIdMiddleware already populated correlation_id / ip / ua.
    # Only generate one if we're running without the middleware (e.g., in
    # unit tests that mount this handler directly on a bare Starlette app).
    correlation_id = get_correlation_id() or str(uuid.uuid4())

    ip = request.client.host if request.client else "unknown"

    if not _check_rate_limit(ip):
        return JSONResponse(
            {"error": "rate_limit_exceeded"},
            status_code=429,
        )

    # REQUESTED — ip is already on the audit event via contextvars from
    # the middleware (ip_address). We emit with an empty details dict to
    # avoid duplicating ip in the payload.
    await emit_audit_event(
        AuditEventType.GLOBAL_LOGOUT_REQUESTED,
        severity=AuditSeverity.INFO,
    )

    # 1. JWT auth
    auth_header = request.headers.get("authorization", "")
    if not auth_header.lower().startswith("bearer "):
        await emit_audit_event(
            AuditEventType.GLOBAL_LOGOUT_AUTH_FAILED,
            severity=AuditSeverity.WARNING,
            outcome="failure",
            details={"reason": "missing_bearer"},
        )
        return JSONResponse(
            {"error": "invalid_client",
             "error_description": "Missing or malformed Authorization header"},
            status_code=401,
        )

    jwt_token = auth_header.split(" ", 1)[1].strip()

    try:
        await _verify_logout_jwt(jwt_token)
    except Exception as exc:
        await emit_audit_event(
            AuditEventType.GLOBAL_LOGOUT_AUTH_FAILED,
            severity=AuditSeverity.WARNING,
            outcome="failure",
            details={"reason": str(exc)[:200]},
        )
        return JSONResponse(
            {"error": "invalid_client",
             "error_description": "JWT verification failed"},
            status_code=401,
        )

    # 2. Body
    try:
        body = await request.json()
    except Exception:
        return _bad_request(
            "malformed_body", "Request body is not valid JSON"
        )

    if not isinstance(body, dict) or "subject" not in body:
        return _bad_request(
            "missing_subject",
            "Request body must contain a 'subject' field"
        )

    subject = body["subject"]

    # 3. Subject parse (iss_sub only)
    handler = get_global_logout_handler()
    try:
        sub_iss, sub_sub = handler.parse_iss_sub_subject(subject)
    except ValueError as exc:
        # Helpful hint when client tried email format
        if isinstance(subject, dict):
            fmt = subject.get("format")
            if fmt and fmt != "iss_sub":
                await emit_audit_event(
                    AuditEventType.GLOBAL_LOGOUT_SUBJECT_INVALID,
                    severity=AuditSeverity.WARNING,
                    outcome="failure",
                    details={"reason": "unsupported_format",
                             "format": str(fmt)[:50]},
                )
                return _bad_request(
                    "unsupported_subject_format",
                    "Adapter only supports subject format 'iss_sub'. "
                    "Configure the Okta Universal Logout integration "
                    "with Subject format type = 'Issuer and Subject "
                    "Identifier'."
                )

        await emit_audit_event(
            AuditEventType.GLOBAL_LOGOUT_SUBJECT_INVALID,
            severity=AuditSeverity.WARNING,
            outcome="failure",
            details={"reason": str(exc)[:200]},
        )
        return _bad_request("invalid_subject", str(exc))

    # 4. Subject.iss must match the adapter's configured issuer.
    # Per RFC 9493, iss_sub identifies a user by (iss, sub) where iss is
    # the AS that issued the sub. Adapter token mappings are keyed by
    # Okta's sub from the configured issuer (settings.issuer).
    # Currently the adapter uses the org AS, so settings.issuer is the
    # org base URL — same value used for the JWT iss check above.
    settings = GatewaySettings()
    expected_iss = settings.issuer
    if sub_iss != expected_iss:
        await emit_audit_event(
            AuditEventType.GLOBAL_LOGOUT_SUBJECT_INVALID,
            severity=AuditSeverity.WARNING,
            outcome="failure",
            details={"reason": "iss_mismatch",
                     "subject_iss": sub_iss[:200],
                     "expected_iss": expected_iss[:200]},
        )
        return _bad_request(
            "invalid_subject",
            "Subject iss does not match the configured token issuer"
        )

    # 5. Schedule revocation as background task. Snapshot the full
    # request context so the bg task's audit events carry the same
    # correlation_id, ip, user_agent.
    ctx_snapshot = get_request_context()
    asyncio.create_task(_run_revocation(sub_sub, ctx_snapshot))

    return Response(status_code=204)


async def _run_revocation(user_sub: str, ctx_snapshot: dict) -> None:
    """Background task. Re-establishes full request context (cleared by
    CorrelationIdMiddleware in its finally block after the response is
    sent)."""
    set_request_context(**ctx_snapshot)
    handler = get_global_logout_handler()
    try:
        await handler.revoke_user(user_sub, ctx_snapshot.get("correlation_id", ""))
    except Exception:
        logger.exception(
            "[GLOBAL-LOGOUT] background task failed for sub=%s (corr=%s)",
            user_sub,
            ctx_snapshot.get("correlation_id", ""),
        )


Do NOT modify app.py in this prompt — route registration is P6.

Run a syntax check only:
  python -c "import okta_agent_proxy.auth.global_logout_route"
```

### Expected output

- New module `okta_agent_proxy/auth/global_logout_route.py` that imports cleanly.

---

## Prompt 6: Wire the route into `app.py`

### Context

Add the route registration. Critical: place it BEFORE the catch-all `Route("/{path:path}", mcp_proxy, ...)`. Best placement: between the `/oauth/consent-skip` route and the `/oauth2/v1/token` route. Reference routes by their path/handler name, not by line number — the file changes often and line numbers drift.

### Prompt

```
Open okta_agent_proxy/app.py.

1. At the top, add an import line near the other auth-module imports:

       from okta_agent_proxy.auth.global_logout_route import (
           GLOBAL_LOGOUT_PATH,
           global_token_revocation,
       )

2. In the flat Starlette routes list, find these two consecutive
   entries:

       Route("/oauth/consent-skip", oauth_consent_skip, methods=["POST"]),
       Route("/oauth2/v1/token", oauth_token_endpoint, methods=["POST", "OPTIONS"]),

   Insert this line BETWEEN them:

       Route(GLOBAL_LOGOUT_PATH, global_token_revocation, methods=["POST"]),

3. Verify that the catch-all route
   Route("/{path:path}", mcp_proxy, methods=["GET", "POST"])
   appears AFTER the new route in the list. If it doesn't, STOP and
   report — the route order is load-bearing.

4. Do NOT touch any other route. Do NOT change ordering of unrelated
   entries.

5. Run: pytest tests/ -q
```

### Expected output

- Two-line edit to `app.py` (one import line, one Route entry).
- `pytest tests/ -q` passes.

---

## Prompt 7: Integration tests for the global logout endpoint

### Context

End-to-end tests using the project's existing minimal-Starlette-app pattern (see `tests/test_consent_interstitial_routes.py`). Mock the JWKS via patching the validator's `fetch_jwks`. Mock the live singletons via the handler's DI hooks. Test JWTs signed with `python-jose`.

The RSA keypair helper follows the same base64url-JWK approach used by `okta_agent_proxy/okta_admin/key_manager.py` (raw `n`/`e` from `public_numbers()` encoded as unpadded base64url). This avoids relying on `python-jose`'s `jwk.construct(pem_bytes, algorithm=...)` shorthand, which is undocumented for PEM inputs and has historically varied between releases. PEM input is kept for the private key so `jose_jwt.encode` can consume it directly.

Since the adapter uses the org AS, the JWT `iss` and the body `subject.iss` are the same value in tests (both `settings.issuer`). No two-iss arrangement.

### Prompt

```
Create tests/test_global_logout_route_integration.py.

Module-level helpers:

  import asyncio
  import base64
  import json
  import time
  import uuid
  from unittest.mock import AsyncMock, MagicMock, patch
  import pytest
  from starlette.applications import Starlette
  from starlette.routing import Route
  from starlette.testclient import TestClient
  from cryptography.hazmat.primitives.asymmetric import rsa
  from cryptography.hazmat.primitives import serialization
  from jose import jwt as jose_jwt

  from okta_agent_proxy.audit.events import AuditEventType
  from okta_agent_proxy.auth.global_logout import (
      GlobalLogoutHandler, reset_global_logout_handler,
  )
  from okta_agent_proxy.auth.global_logout_route import (
      GLOBAL_LOGOUT_PATH, global_token_revocation,
      _reset_rate_limiter, EXPECTED_TYP,
  )

  def _int_to_b64url(n: int) -> str:
      byte_length = (n.bit_length() + 7) // 8
      raw = n.to_bytes(byte_length, byteorder="big")
      return base64.urlsafe_b64encode(raw).rstrip(b"=").decode("ascii")

  def _generate_rsa_keypair(kid: str = "test-key-id"):
      """Return (private_pem, public_jwks) for signing and verifying."""
      key = rsa.generate_private_key(public_exponent=65537, key_size=2048)
      private_pem = key.private_bytes(
          encoding=serialization.Encoding.PEM,
          format=serialization.PrivateFormat.PKCS8,
          encryption_algorithm=serialization.NoEncryption(),
      )
      pub_numbers = key.public_key().public_numbers()
      public_jwk = {
          "kty": "RSA",
          "kid": kid,
          "use": "sig",
          "alg": "RS256",
          "n": _int_to_b64url(pub_numbers.n),
          "e": _int_to_b64url(pub_numbers.e),
      }
      return private_pem, {"keys": [public_jwk]}

  def _sign_jwt(claims: dict, private_pem: bytes,
                kid: str = "test-key-id",
                typ: str = EXPECTED_TYP) -> str:
      return jose_jwt.encode(
          claims, private_pem, algorithm="RS256",
          headers={"kid": kid, "typ": typ},
      )

Fixtures:

  TEST_OKTA_DOMAIN = "test.okta.com"
  TEST_ISSUER = f"https://{TEST_OKTA_DOMAIN}"  # org AS == settings.issuer
  TEST_GATEWAY_URL = "http://localhost:8000"
  TEST_AUDIENCE = TEST_GATEWAY_URL + GLOBAL_LOGOUT_PATH
  TEST_CALLER_CLIENT_ID = "0oarelaytest"

  @pytest.fixture(autouse=True)
  def _env(monkeypatch):
      monkeypatch.setenv("OKTA_DOMAIN", TEST_OKTA_DOMAIN)
      monkeypatch.setenv("OKTA_ISSUER", TEST_ISSUER)
      monkeypatch.setenv("GATEWAY_BASE_URL", TEST_GATEWAY_URL)
      monkeypatch.delenv("GLOBAL_LOGOUT_AUDIENCE", raising=False)
      monkeypatch.delenv("GLOBAL_LOGOUT_EXPECTED_CLIENT_ID", raising=False)
      _reset_rate_limiter()
      reset_global_logout_handler()
      yield
      _reset_rate_limiter()
      reset_global_logout_handler()

  @pytest.fixture
  def keypair():
      return _generate_rsa_keypair()

  @pytest.fixture
  def patched_jwks(keypair):
      """Patch get_validator so the route uses our test JWKS."""
      _, public_jwks = keypair
      with patch(
          "okta_agent_proxy.auth.global_logout_route.get_validator"
      ) as mock_get_validator:
          mock_validator = MagicMock()
          mock_validator.fetch_jwks = AsyncMock(return_value=public_jwks)
          mock_get_validator.return_value = mock_validator
          yield

  @pytest.fixture
  def mock_handler_deps():
      from okta_agent_proxy.auth import global_logout as gl_module

      mock_store = AsyncMock()
      mock_store.aremove_by_user = AsyncMock(return_value=0)

      mock_cache = AsyncMock()
      mock_cache.ainvalidate_all_for_user = AsyncMock(return_value=None)

      mock_sm = AsyncMock()
      mock_sm.terminate_all_for_user = AsyncMock(return_value={})

      handler = GlobalLogoutHandler(
          token_store=mock_store,
          token_cache=mock_cache,
          session_manager=mock_sm,
      )
      gl_module._handler = handler
      yield {"store": mock_store, "cache": mock_cache, "sm": mock_sm}
      gl_module._handler = None

  @pytest.fixture
  def client():
      from okta_agent_proxy.middleware.correlation import CorrelationIdMiddleware
      from starlette.middleware import Middleware

      app = Starlette(
          routes=[
              Route(GLOBAL_LOGOUT_PATH, global_token_revocation, methods=["POST"]),
          ],
          middleware=[Middleware(CorrelationIdMiddleware)],
      )
      return TestClient(app, raise_server_exceptions=False)

  def _valid_claims(aud: str = TEST_AUDIENCE,
                    iss: str = TEST_ISSUER,
                    sub: str = TEST_CALLER_CLIENT_ID) -> dict:
      now = int(time.time())
      return {
          "jti": str(uuid.uuid4()),
          "iss": iss,
          "sub": sub,
          "aud": aud,
          "iat": now,
          "nbf": now - 60,
          "exp": now + 300,
      }

  def _valid_body(sub: str = "00ujane",
                  subject_iss: str = TEST_ISSUER) -> dict:
      """For the org-AS adapter, subject.iss == JWT iss == settings.issuer."""
      return {
          "subject": {
              "format": "iss_sub",
              "iss": subject_iss,
              "sub": sub,
          }
      }

  def _bearer(jwt_token: str) -> dict:
      return {"Authorization": f"Bearer {jwt_token}"}

  def _poll(predicate, timeout: float = 1.0, step: float = 0.025):
      end = time.monotonic() + timeout
      while time.monotonic() < end:
          if predicate():
              return True
          time.sleep(step)
      return False

Test cases:

1. test_happy_path_returns_204:
     Sign valid JWT, post valid body. 204. Poll for
     mock_handler_deps["store"].aremove_by_user.await_count > 0.
     Assert called with sub="00ujane".

2. test_missing_authorization_header_returns_401:
     POST without Authorization. 401, error="invalid_client".

3. test_non_bearer_authorization_returns_401:
     "Basic foo". 401.

4. test_invalid_jwt_signature_returns_401:
     Sign with second keypair not in JWKS. 401.

5. test_expired_jwt_returns_401:
     exp = now - 60. 401.

6. test_nbf_in_future_returns_401:
     nbf = now + 300. 401.

7. test_wrong_typ_header_returns_401:
     typ="JWT" instead of EXPECTED_TYP. 401.

8. test_wrong_audience_returns_401:
     aud = "https://wrong.example.com/...". 401.

9. test_wrong_jwt_issuer_returns_401:
     JWT iss = "https://other.okta.com". 401.

10. test_pinned_client_id_mismatch_returns_401:
     Set GLOBAL_LOGOUT_EXPECTED_CLIENT_ID="0oaexpected". JWT sub
     contains a different value. 401.

11. test_pinned_client_id_match_returns_204:
     Set GLOBAL_LOGOUT_EXPECTED_CLIENT_ID="0oapinned". JWT sub
     contains "0oapinned". 204.

12. test_email_subject_format_returns_400_with_helpful_hint:
     Body = {"subject": {"format": "email", "email": "j@x.com"}}
     400, error="unsupported_subject_format". Description mentions
     "Issuer and Subject Identifier".

13. test_missing_subject_field_returns_400:
     Body = {}. 400, error="missing_subject".

14. test_malformed_body_returns_400:
     "not-json" with Content-Type: application/json. 400,
     error="malformed_body".

15. test_subject_iss_mismatch_returns_400:
     Body subject.iss = "https://evil.example.com". 400,
     error="invalid_subject".

16. test_subject_not_found_still_returns_204:
     mock_handler_deps["store"].aremove_by_user returns 0.
     mock_handler_deps["sm"].terminate_all_for_user returns {}.
     Valid request. 204. Poll for handler call. (Per Okta dev
     guide: 204 not 404 — enumeration mitigation.)

17. test_terminates_mcp_sessions:
     mock_handler_deps["sm"].terminate_all_for_user returns
     {"hr": True, "finance": True}. Post. 204. Poll. Assert sm called.

18. test_rate_limit_exceeded_returns_429:
     Send 100 requests. All 204. 101st returns 429.

19. test_correlation_id_and_context_propagated_to_background_task:
     Send X-Correlation-Id: "test-corr-42" and a User-Agent header.
     Use capture emitter. Poll for background task. Assert one
     GLOBAL_LOGOUT_COMPLETED captured with correlation_id="test-corr-42"
     AND user_agent matching the header — confirms the ctx_snapshot
     reapplication carries through.

20. test_backend_session_termination_failure_still_returns_204:
     mock_handler_deps["sm"].terminate_all_for_user returns
     {"hr": False}. 204.

21. test_rate_limiter_idle_ips_eventually_evicted:
     Monkeypatch the cachetools.TTLCache's ttl to a low value (or
     import the state and replace with a fresh TTLCache with ttl=0.1)
     then send one request from ip "1.2.3.4", sleep 0.2s, and assert
     the ip key is no longer in _rate_limit_state. Confirms no
     unbounded growth.

Run: pytest tests/test_global_logout_route_integration.py -v
```

### Expected output

- New integration test file with ~21 tests, all passing.

---

## Prompt 8: Advertise the endpoint in OAuth AS metadata

### Context

Per IETF spec section 5, advertise via `global_token_revocation_endpoint`. The adapter has TWO metadata handlers in `app.py`: `oauth_authorization_server` (the `/.well-known/oauth-authorization-server` handler, around line 453) and `oauth_authorization_server_by_name` (the per-resource variant at `/.well-known/oauth-authorization-server/{resource}`, around line 502). Both need the new field.

Testing: `tests/test_oauth_metadata.py` does NOT exist. The existing file is `tests/test_oauth_discovery.py`. Extend that file rather than creating a new one.

### Prompt

```
Open okta_agent_proxy/app.py.

1. The import added in P6 is sufficient (GLOBAL_LOGOUT_PATH is already
   in scope from that import).

2. Find the oauth_authorization_server handler (function name, not a
   line number). Its metadata dict contains a "jwks_uri" key. Add a
   new key immediately after jwks_uri:

       "global_token_revocation_endpoint": f"{gateway_base}{GLOBAL_LOGOUT_PATH}",

3. Find oauth_authorization_server_by_name (same file, separate
   handler). Its metadata dict also has "jwks_uri". Add the same key
   in the same relative position:

       "global_token_revocation_endpoint": f"{gateway_base}{GLOBAL_LOGOUT_PATH}",

4. Do NOT add the optional companion field
   global_token_revocation_endpoint_auth_methods_supported. Deferred.

5. Tests — extend tests/test_oauth_discovery.py. Add:

     def test_metadata_advertises_global_token_revocation_endpoint(client):
         resp = client.get("/.well-known/oauth-authorization-server")
         assert resp.status_code == 200
         data = resp.json()
         assert "global_token_revocation_endpoint" in data
         assert data["global_token_revocation_endpoint"].endswith(
             "/oauth/global-token-revocation"
         )
         # RFC 8414 §3.3: issuer byte-matches GATEWAY_BASE_URL in this
         # adapter, and the revocation endpoint is built from the same
         # gateway_base. So the endpoint starts with the advertised
         # issuer.
         assert data["global_token_revocation_endpoint"].startswith(
             data["issuer"]
         )

     def test_metadata_by_name_advertises_global_token_revocation_endpoint(client):
         resp = client.get("/.well-known/oauth-authorization-server/hr")
         assert resp.status_code == 200
         data = resp.json()
         assert "global_token_revocation_endpoint" in data

   Use the existing test fixture/client pattern from
   tests/test_oauth_discovery.py.

Run: pytest tests/test_oauth_discovery.py -v
```

### Expected output

- One field added to two handlers in `app.py`.
- Two new tests in `tests/test_oauth_discovery.py` passing.

---

## Prompt 9: Operator documentation — Okta config + troubleshooting

### Context

Mirror Okta's admin doc (https://help.okta.com/oie/en-us/content/topics/itp/config-universal-logout.htm) and add adapter-specific guidance. Defer Okta Admin Console UI step-by-steps to Okta's docs — their UI evolves and our doc will drift. Link directly.

### Prompt

```
Create docs/GLOBAL_LOGOUT_CONFIGURATION.md. Use the same prose style
as docs/RFC8414_ISSUER_FIX_PROMPTS.md and other docs in the repo.

# Global Logout (Okta ITP Universal Logout)

## Overview
One paragraph: what Okta ITP Universal Logout is, what the adapter
does on receiving a revocation call, and the scope of what gets
revoked: UserTokenStore entries (server-side id_token + refresh_token
mappings), TokenCache entries (cached backend tokens — both ID-JAG
and STS), and locally-known MCP sessions.

## Prerequisites
- Okta Identity Engine tenant with Identity Threat Protection (ITP)
  enabled. ITP is a paid add-on.
- Admin role with permission to manage apps and clear API tokens.
- Adapter deployed at a TLS-reachable URL.

## Architecture context
The adapter currently uses the Okta org authorization server. This
means:
- OKTA_ISSUER == https://{OKTA_DOMAIN}
- All JWT iss values, body subject.iss values, and JWKS lookups go
  through this single issuer.
- Custom AS code paths exist for a future Okta capability (originating
  token from custom AS for the XAA/ID-JAG flow), but are not used
  today. If Okta ever supports that topology, this doc and the JWT
  validation logic must be re-verified against Okta's at-the-time
  guidance for which AS signs Universal Logout JWTs before enabling.

## Adapter-side configuration

  GATEWAY_BASE_URL — externally-visible adapter URL. Used to build
    the expected JWT aud claim (default: GATEWAY_BASE_URL +
    /oauth/global-token-revocation).
  GLOBAL_LOGOUT_AUDIENCE — OPTIONAL. Override the expected aud claim
    if Okta is configured with a non-default value.
  GLOBAL_LOGOUT_RATE_LIMIT_PER_MIN — OPTIONAL. Default 100/IP/min.
    Per-replica.
  GLOBAL_LOGOUT_RATE_LIMIT_MAX_IPS — OPTIONAL. Default 4096. Caps
    the rate-limiter's in-memory IP table (cachetools.TTLCache);
    idle IPs age out after 2x the rate window.
  GLOBAL_LOGOUT_EXPECTED_CLIENT_ID — OPTIONAL but RECOMMENDED. Pin
    the JWT auth to the Confidential Relay OIDC app's client_id.
    Without this, any Okta-signed JWT from the same org with a valid
    signature is accepted (still org-scoped via JWKS, but not
    app-scoped).
  OKTA_DOMAIN, OKTA_ISSUER — already used elsewhere; the adapter
    validates the inbound JWT signature against the org JWKS at
    https://{OKTA_DOMAIN}/oauth2/v1/keys via the existing
    OktaTokenValidator.

## Okta Admin Console configuration

For the full admin-console walkthrough (screens, fields, options),
follow Okta's official documentation:

- Universal Logout setup:
  https://help.okta.com/oie/en-us/content/topics/itp/config-universal-logout.htm
- ITP continuous access policies:
  https://help.okta.com/oie/en-us/content/topics/itp/enforce-continuous-access.htm
- ITP entity risk policies:
  https://help.okta.com/oie/en-us/content/topics/itp/entity-risk-policy.htm

Adapter-specific choices when following Okta's steps:

  Logout endpoint URL:
    https://<adapter>/oauth/global-token-revocation

  Endpoint authentication type:
    Signed JWT (Okta default). No other methods are accepted.

  Subject format type:
    Issuer and Subject Identifier.
    **Do NOT select "Email Identifier".** The adapter persists token
    mappings keyed by Okta's immutable `sub`; email is mutable.
    Selecting Email Identifier will cause every revocation to fail
    with HTTP 400 unsupported_subject_format.

After configuring in Okta, copy the OIDC app's client_id from the
General tab and set it as GLOBAL_LOGOUT_EXPECTED_CLIENT_ID on the
adapter. This prevents logout JWTs intended for other Okta apps
(issued by the same org) from being accepted.

## Verifying the integration

- Manual trigger: follow Okta's instructions for clearing a user's
  sessions with Universal Logout enabled:
  https://help.okta.com/oie/en-us/content/topics/itp/config-universal-logout.htm
- Expected adapter behavior: within ~2 seconds, the user's
  UserTokenStore entries, TokenCache entries, and local MCP sessions
  are cleared. The next inbound MCP call from that user fails JWT
  validation at Layer 2 and returns 401.
- Audit events to expect:
    GLOBAL_LOGOUT_REQUESTED (synchronously, before auth)
    GLOBAL_LOGOUT_COMPLETED (from background task)
  Plus zero or more GLOBAL_LOGOUT_BACKEND_SESSION_TERMINATED per
  backend with an active session.

## Inbound JWT format reference

Per Okta's Universal Logout spec, the inbound POST contains:

  Authorization: Bearer <signed-JWT>

where the JWT looks like:

  // Header
  {
    "typ": "global-token-revocation+jwt",
    "alg": "RS256",
    "kid": "<key-id-from-org-JWKS>"
  }
  // Payload
  {
    "jti": "<unique-id>",
    "iss": "https://<okta_domain>",      // org base URL
    "sub": "<calling-Okta-app-client_id>",
    "aud": "https://<adapter>/oauth/global-token-revocation",
    "iat": <now>,
    "nbf": <now - 5m>,
    "exp": <now + 5m>
  }

The body is JSON with subject identifier per RFC 9493:

  {
    "subject": {
      "format": "iss_sub",
      "iss": "https://<okta_domain>",
      "sub": "<okta-user-id>"
    }
  }

For the org-AS adapter, the JWT iss and the body subject.iss are the
SAME value — both are https://{OKTA_DOMAIN}.

## Troubleshooting

  GLOBAL_LOGOUT_AUTH_FAILED with reason "missing_bearer":
    Okta is calling without a signed JWT. Verify Endpoint
    authentication type is "Signed JWT" in the Okta app config.

  GLOBAL_LOGOUT_AUTH_FAILED with reason "unexpected_typ":
    The JWT typ header isn't "global-token-revocation+jwt". Open a
    support case if you see this with a properly configured Okta app.

  GLOBAL_LOGOUT_AUTH_FAILED with reason mentioning "Signature" or
  "kid":
    JWKS mismatch. Verify OKTA_DOMAIN matches the tenant configured
    for the integration. The adapter caches JWKS for 1 hour; if you
    rotated keys recently, restart the adapter.

  GLOBAL_LOGOUT_AUTH_FAILED with reason mentioning "Issuer":
    The JWT iss doesn't match the adapter's configured issuer.
    Common cause: OKTA_DOMAIN is set to a custom-domain alias on
    the adapter side but the test tenant is using the default org
    domain (or vice versa). Reconcile.

  GLOBAL_LOGOUT_AUTH_FAILED with reason mentioning "audience" or
  "aud":
    The JWT aud claim doesn't match the expected URL. Either fix
    GATEWAY_BASE_URL or set GLOBAL_LOGOUT_AUDIENCE to the exact aud
    Okta is sending.

  GLOBAL_LOGOUT_AUTH_FAILED with reason "sub_mismatch":
    GLOBAL_LOGOUT_EXPECTED_CLIENT_ID is set but the JWT sub doesn't
    match. Verify the env var is set to the OIDC app's client_id
    (the calling Okta app, NOT some agent's client_id).

  GLOBAL_LOGOUT_SUBJECT_INVALID with reason "iss_mismatch":
    Subject.iss in the body doesn't match settings.issuer. For org-AS
    deployments these should be identical.

  HTTP 400 unsupported_subject_format:
    Okta is sending Email format. Change Subject format type to
    "Issuer and Subject Identifier" in the Okta app config.

  HTTP 204 returned for an unknown user:
    Per Okta's developer guide, the adapter returns 204 (not 404)
    for unrecognized users to prevent account enumeration. The audit
    event GLOBAL_LOGOUT_SUBJECT_NOT_FOUND records this case for ops
    visibility.

  HTTP 204 returned but tokens still valid on next call:
    Multi-replica deployment without Redis as the L2 cache provider.
    UserTokenStore.aremove_by_user publishes pub/sub invalidation
    that other replicas listen for; without Redis, peer replicas'
    in-memory caches stay populated. Configure CACHE_PROVIDER=redis
    for production multi-replica deployments.

  Backend MCP sessions still active on peer replicas:
    Known limitation. MCPSessionManager.terminate_all_for_user only
    iterates the local replica's session cache. Sessions held by
    peer replicas die when their TTL (default 1 hour) expires.
    Cross-pod session enumeration is deferred.

  GLOBAL_LOGOUT_BACKEND_SESSION_FAILED:
    A backend MCP server returned non-2xx on the DELETE call or
    timed out (default 3s per call). The adapter's local cache is
    still cleared, so the next user-scoped call fails JWT validation
    upstream regardless. Investigate backend health for repeated
    failures.

## Scope and limitations

- Rate limiter is per-replica. In multi-replica deployments the
  effective limit is N x GLOBAL_LOGOUT_RATE_LIMIT_PER_MIN. The
  in-memory IP table is bounded (GLOBAL_LOGOUT_RATE_LIMIT_MAX_IPS,
  default 4096) and idle-evicts; no unbounded growth.
- In-flight tool calls that already passed Layer 2 will complete.
  The NEXT call after revocation is guaranteed to fail.
- Multi-replica MCP session termination is local-only.
- The adapter does NOT implement OIDC Back-Channel Logout (sid-based)
  in this release.
- `email` subject format is not supported (adapter design choice).
- Admin-UI initiated force-logout is a planned follow-up.
- jti replay protection is not yet implemented. Per Okta dev guide,
  jti is included in the JWT but not currently tracked.
- This implementation assumes the Okta ORG authorization server is
  the originating issuer. When Okta supports custom-AS as the
  originator for XAA flows, re-verify Okta's guidance on which AS
  signs Universal Logout JWTs before enabling.

## References
- IETF: draft-parecki-oauth-global-token-revocation
- Okta admin doc: https://help.okta.com/oie/en-us/content/topics/itp/config-universal-logout.htm
- Okta developer guide: https://developer.okta.com/docs/guides/oin-universal-logout-overview/
- Subject identifiers: RFC 9493

Update README.md: add a one-line bullet under Security Features (or
Operations) section linking to the new doc:

  - **Global Logout (Okta ITP)** — the adapter accepts Okta
    Universal Logout calls to revoke a user's tokens and sessions.
    See [docs/GLOBAL_LOGOUT_CONFIGURATION.md](docs/GLOBAL_LOGOUT_CONFIGURATION.md).

No code changes. Deliverable is documentation only.
```

### Expected output

- New file `docs/GLOBAL_LOGOUT_CONFIGURATION.md`.
- One-line addition to `README.md`.

---

## Post-implementation checklist

- `pytest tests/ -q` passes in full.
- `POST /oauth/global-token-revocation` is reachable.
- `GET /.well-known/oauth-authorization-server` returns
  `global_token_revocation_endpoint`.
- A manual end-user-session in Okta Admin Console triggers a visible
  `GLOBAL_LOGOUT_COMPLETED` audit event and clears that user's
  cached state within ~2 seconds.
- `docs/GLOBAL_LOGOUT_CONFIGURATION.md` exists.

## Deferred to future prompt packs

- Admin-UI "force logout this user" button — internal admin endpoint that reuses `GlobalLogoutHandler.revoke_user`.
- `global_token_revocation_endpoint_auth_methods_supported` metadata field.
- OIDC Back-Channel Logout (sid-based) for non-Okta IdPs.
- SSF completion callback.
- Cross-replica MCP session enumeration.
- Distributed rate limiter.
- `email` subject format support.
- `jti` replay protection (bounded LRU).
- Custom-AS Universal Logout re-verification — when Okta supports custom-AS as the originating token issuer for XAA flows, re-read Okta's at-the-time docs to confirm which AS signs Universal Logout JWTs and whether a configuration toggle is needed.

---

## Changelog vs v3

Architecture correction: the adapter uses the Okta org authorization server, not a custom AS. The two-iss split in v3 was based on a wrong assumption about adapter deployment topology. v4 corrections:

- **Reverted to reusing `OktaTokenValidator.fetch_jwks()`** (v2's approach). The existing validator is constructed against `settings.issuer`, which IS the org issuer in production. v3's dedicated org JWKS fetcher is unnecessary.
- **Single `settings.issuer` value** validates both the JWT `iss` and the body `subject.iss`. v3's two separate values collapse into one.
- **Test fixtures simplified.** v3 had `TEST_ORG_ISSUER` vs `TEST_AS_ISSUER`; v4 has just `TEST_ISSUER`.

v4 revisions after source review (2026-04-29):

- **P2** uses the imported `_USER_TOKEN_PREFIX` constant in assertions instead of hardcoding `"user_token:"`.
- **P3** adds an async variant `ainvalidate_all_for_user` and refactors into small `_invalidate_user_id_family` / `_invalidate_sts_family` helpers so sync and async paths share behavior. The orchestrator in P4 calls the async variant to avoid thread-pool blocking.
- **P4** calls `ainvalidate_all_for_user` instead of `invalidate_all_for_user`.
- **P5** rate limiter is a `cachetools.TTLCache` (bounded size + idle eviction) instead of an unbounded dict. Added `GLOBAL_LOGOUT_RATE_LIMIT_MAX_IPS` env var.
- **P5** handler no longer calls `set_request_context(correlation_id=...)` at its top — that would clobber middleware-populated `ip_address` / `user_agent` context vars. It reads `get_correlation_id()` instead. The background task reapplies the FULL context snapshot (`get_request_context()`).
- **P5** `GLOBAL_LOGOUT_REQUESTED` no longer duplicates `ip` in the details dict; the middleware-populated `ip_address` context var is already emitted on every audit event via `create_audit_event`.
- **P6** references routes by handler/path name, not by line number (line numbers drift).
- **P7** keypair helper uses the `n`/`e` base64url-JWK approach used by `okta_admin/key_manager.py` instead of `jose.jwk.construct(pem_bytes, algorithm=...)`. Added a dedicated test for idle-eviction of the rate limiter.
- **P7** the integration-test Starlette app wires `CorrelationIdMiddleware` so correlation-id / IP / user-agent propagation matches production behavior.
- **P8** tests extend the existing `tests/test_oauth_discovery.py` (the file actually in the repo) rather than referencing a non-existent `test_oauth_metadata.py`.
- **P9** defers Okta Admin Console step-by-step screenshots to Okta's own docs via direct links, noting only the adapter-specific field choices. Drops the "per-replica rate-limit has unbounded IP table" limitation bullet (fixed in P5). Softens the forward-compat language on custom-AS originating tokens.

## Changelog vs v2 / v1

(Earlier version histories preserved in v2 and v3 files.)
