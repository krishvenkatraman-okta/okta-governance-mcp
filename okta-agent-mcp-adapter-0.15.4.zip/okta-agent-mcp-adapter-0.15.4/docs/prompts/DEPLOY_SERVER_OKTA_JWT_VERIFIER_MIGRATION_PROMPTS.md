# Deploy Server SDK Migration — `okta-ai-sdk` → `okta-jwt-verifier`

> **Target:** `examples/05-deploy-server/` in the `joewitt99/okta-agent-mcp-adapter` repo.
> **Goal:** Drop the `DEPLOY_OKTA_CLIENT_ID` requirement by replacing the `okta-ai-sdk-proto` verifier (which requires a `clientId` even for verify-only use) with the official Okta `okta-jwt-verifier` package, which only needs `issuer` + `audience` for access-token validation.
> **Format:** Sequential, copy-paste-ready Claude Code CLI prompts. Run them top-to-bottom. Each prompt is self-contained — clear context between prompts.

---

## Background — why this migration

The deploy-server is a **resource server**: it only validates inbound AT-2 tokens issued by the OK1Az2 custom AS. It never signs anything, never requests tokens, never authenticates outbound.

Today it uses `okta-ai-sdk-proto` (`OktaAISDK` + `OktaAIConfig`), whose constructor demands a `clientId` even though the verify path only fetches public JWKS. That forced operators to put the **Confidential Relay app's** Client ID into `.env` as `DEPLOY_OKTA_CLIENT_ID` purely to satisfy the SDK constructor — see `AZURE_ACA_DEPLOYMENT_GUIDE.md` Section 7, which calls this out as a quirk that "will go away with the SDK migration."

We initially considered swapping to `okta-client-python` (the SDK already used elsewhere in the adapter for `CrossAppAccessFlow` / `TokenExchangeFlow`). After review of [okta/okta-client-python](https://github.com/okta/okta-client-python), that package contains **no resource-server verifier surface** — every module is for *issuing* tokens (`AuthorizationCodeFlow`, `JWTBearerFlow`, `RefreshTokenFlow`, `CrossAppAccessFlow`, etc.). It is not the right tool for this job.

The right Okta-published package for a resource-server validating an access token issued by a custom AS is **[`okta-jwt-verifier`](https://github.com/okta/okta-jwt-verifier-python)** (latest 0.4.0, Jan 2026). Its `AccessTokenVerifier(issuer=..., audience=...).verify(token)` API needs only the issuer URL and the expected audience — **no client_id, no client_secret, no private key, no principal_id**. It internally fetches and caches JWKS, validates RS256 signature, checks `iss` / `aud` / `exp`. This is exactly the deploy-server's job.

## Decisions baked into these prompts

1. **Target SDK:** `okta-jwt-verifier>=0.4.0` (Okta-published, async, JWKS-cached).
2. **`DEPLOY_AUTH_DISABLED` is removed.** No mock-mode bypass. The server always verifies — if Okta config is missing or wrong, the server fails fast at startup with a clear error. Tests use mocks at the verifier-instance boundary, not env-driven bypass.
3. **`DEPLOY_OKTA_CLIENT_ID` is deprecated, not hard-removed.** If still present in `.env`, the server logs a one-line `WARNING` at startup and ignores it. This keeps existing `.env` files working through one upgrade cycle.
4. **`MockTokenVerifier` is deleted.** It only existed to support `DEPLOY_AUTH_DISABLED`.
5. **Async boundary is hidden inside the verifier wrapper.** `okta-jwt-verifier` is async; `validate_bearer_token()` in `server.py` stays synchronous so the FastMCP tool surface is unchanged. The wrapper uses `asyncio.run()` internally — acceptable because each request is its own short-lived call.
6. **Issuer is constructed from `DEPLOY_OKTA_DOMAIN` + `DEPLOY_OKTA_AUTH_SERVER_ID`** (`https://{domain}/oauth2/{auth_server_id}`). No new env var introduced.

## Files in scope

| File | Change |
|---|---|
| `examples/05-deploy-server/requirements.txt` | swap SDK package |
| `examples/05-deploy-server/auth.py` | full rewrite of `DeployTokenVerifier`; delete `MockTokenVerifier`; new `_init_verifier()` semantics |
| `examples/05-deploy-server/server.py` | remove `MockTokenVerifier` import + `DEPLOY_AUTH_DISABLED` branch |
| `examples/05-deploy-server/.env.example` | mark `DEPLOY_OKTA_CLIENT_ID` as deprecated; remove `DEPLOY_AUTH_DISABLED` |
| `examples/05-deploy-server/docker-compose.yml` | drop `DEPLOY_OKTA_CLIENT_ID` env passthrough |
| `examples/05-deploy-server/README.md` | rewrite SDK section, env table, troubleshooting |
| `examples/05-deploy-server/tests/helpers.py` | replace `MockVerificationResult` with mock claims dict |
| `examples/05-deploy-server/tests/conftest.py` | rewire `mock_sdk_verifier` fixture; delete `auth_disabled_env` |
| `examples/05-deploy-server/tests/test_auth.py` | rewrite SDK init tests, delete auth-disabled tests, add deprecation-warning test |
| `AZURE_ACA_DEPLOYMENT_GUIDE.md` | update Section 7 (line ~296) and Section 9 `.env` block |

---

## Prompt 01 — Swap the SDK dependency

```
Update examples/05-deploy-server/requirements.txt to replace the legacy Okta AI SDK with the official Okta JWT verifier package.

Specifically:
1. Remove the line: okta-ai-sdk-proto>=1.0.3
2. Add the line:    okta-jwt-verifier>=0.4.0

Keep all other dependencies (fastmcp, uvicorn, python-jose[cryptography], httpx, pydantic) untouched.

Show the final contents of requirements.txt after the edit.

Do not modify any Python source files in this prompt — that comes next.
```

---

## Prompt 02 — Rewrite `auth.py`

```
Rewrite examples/05-deploy-server/auth.py end-to-end. The file must implement Bearer-token verification using the official okta-jwt-verifier package (AccessTokenVerifier), drop all references to client_id / client_secret / private key, delete MockTokenVerifier, and provide backward-compatible deprecation handling for the DEPLOY_OKTA_CLIENT_ID env var.

Requirements — produce exactly this behavior:

1. Imports
   - import asyncio, logging, os, warnings
   - from typing import Any, Dict
   - from okta_jwt_verifier import AccessTokenVerifier
   - from okta_jwt_verifier.exceptions import JWTValidationException, JWKException

2. Class: DeployTokenVerifier
   - Constructor signature:
       __init__(self, okta_domain: str, auth_server_id: str, audience: str | None = None, leeway: int = 0)
   - Normalize okta_domain:
       * strip trailing slashes
       * upgrade http:// to https://
       * prepend https:// if scheme is missing
   - Construct issuer:  f"{okta_domain}/oauth2/{auth_server_id}"
   - Store issuer, audience, leeway as instance attributes.
   - Lazily construct a single AccessTokenVerifier instance (self._verifier) using
     AccessTokenVerifier(issuer=self.issuer, audience=self.audience, leeway=self.leeway).
     Build it in __init__ so JWKS is fetched on first verify() call (the SDK
     handles caching).
   - Log at INFO on init: "DeployTokenVerifier initialized (issuer=%s, audience=%s)"
   - Provide a synchronous verify(token: str) -> Dict[str, Any] method that:
       * calls asyncio.run(self._verifier.verify(token)) to bridge the SDK's async API
       * On success, the SDK returns nothing — the verify() call simply does not
         raise. To extract claims for the caller, decode the JWT payload with
         python-jose (already a dependency) WITHOUT re-verifying signature
         (verify=False) — signature was already validated by the SDK call. Use:
             from jose import jwt as jose_jwt
             claims = jose_jwt.get_unverified_claims(token)
       * Build and return a dict with keys: valid, sub, aud, iss, scope, exp.
         scope is taken from claims.get("scp") (Okta convention) falling back to
         claims.get("scope"). If scp is a list, join with single spaces.
       * Log at INFO: "Token verified -- sub=%s (XAA user identity)"
       * Log at DEBUG with aud, iss, scope.
       * On JWTValidationException or JWKException, log WARNING with the SDK's
         error message and re-raise as ValueError(f"Token verification failed: {e}").
       * On any other unexpected exception, log ERROR and re-raise as ValueError.

3. NO MockTokenVerifier class. Delete it entirely. Do NOT add any
   "mock", "stub", "disabled", or "bypass" code path anywhere in this file.

4. Function: _init_verifier() — note: NO auth_disabled parameter anymore
   - Read env vars:
       domain         = os.getenv("DEPLOY_OKTA_DOMAIN", "").strip()
       auth_server_id = os.getenv("DEPLOY_OKTA_AUTH_SERVER_ID", "").strip()
       audience       = os.getenv("DEPLOY_OKTA_AUDIENCE", "").strip() or None
       legacy_cid     = os.getenv("DEPLOY_OKTA_CLIENT_ID", "").strip()
   - If legacy_cid is non-empty:
       Emit a DeprecationWarning via warnings.warn(...)
       AND log at WARNING level (single line):
       "DEPLOY_OKTA_CLIENT_ID is deprecated and ignored — the new okta-jwt-verifier
       SDK does not require a client_id for resource-server token validation. "
       "Remove this variable from your .env."
   - If domain is empty OR auth_server_id is empty:
       Raise RuntimeError with a clear actionable message listing exactly which
       required env vars are missing. Format the message so an operator can copy
       the missing variable names directly. Do NOT silently fall back to anything
       — the server must refuse to start.
   - Otherwise return DeployTokenVerifier(okta_domain=domain, auth_server_id=auth_server_id, audience=audience).

5. Module-level docstring: replace the existing docstring with a short one
   explaining this module wraps okta-jwt-verifier's AccessTokenVerifier for
   resource-server validation of XAA AT-2 tokens, requires no client_id/secret/
   private_key, and that DEPLOY_AUTH_DISABLED has been removed.

6. Logger: keep `logger = logging.getLogger(__name__)` at module top.

When done, show the complete new contents of examples/05-deploy-server/auth.py
and confirm:
- No reference to `okta_ai_sdk`, `OktaAISDK`, `OktaAIConfig`, `principalId`, `privateJWK`,
  `clientSecret`, `MockTokenVerifier`, or `auth_disabled` anywhere in the file.
- No `client_id` parameter on DeployTokenVerifier.__init__.
- DEPLOY_OKTA_CLIENT_ID is read only to emit the deprecation warning, never used.
```

---

## Prompt 03 — Update `server.py`

```
Update examples/05-deploy-server/server.py to align with the new auth module:

1. Update the module docstring's "Auth:" line to reference okta-jwt-verifier
   instead of okta-ai-sdk. Update the line "validates it using verify_auth_server_token()"
   to "validates it using okta-jwt-verifier AccessTokenVerifier".

2. Change the import from auth:
       OLD: from auth import DeployTokenVerifier, MockTokenVerifier, _init_verifier
       NEW: from auth import DeployTokenVerifier, _init_verifier

3. Remove the AUTH_DISABLED constant entirely:
       DELETE: AUTH_DISABLED = os.getenv("DEPLOY_AUTH_DISABLED", "false").lower() in ("true", "1", "yes")

4. Replace the verifier initialization line:
       OLD: verifier = _init_verifier(auth_disabled=AUTH_DISABLED)
       NEW: verifier = _init_verifier()

5. Leave the rest of server.py untouched — validate_bearer_token(), all FastMCP
   tools, the SERVER_HOST/SERVER_PORT/LOG_LEVEL config, and the if __name__ == "__main__"
   block remain exactly as-is. The verify() method on the new DeployTokenVerifier
   has the same sync signature, so no call-site changes are needed.

Confirm by grepping the file:
- `grep -n "MockTokenVerifier\|AUTH_DISABLED\|auth_disabled\|DEPLOY_AUTH_DISABLED" examples/05-deploy-server/server.py`
  must return zero matches.
- `grep -n "_init_verifier\|DeployTokenVerifier" examples/05-deploy-server/server.py`
  must show the new import + the call.

Show the diff (or the changed lines + 2 lines of context above and below).
```

---

## Prompt 04 — Update `.env.example`

```
Rewrite examples/05-deploy-server/.env.example with the following content. Preserve
section banner style and comment density; only change what's listed below.

Required behavior:
1. Remove the DEPLOY_AUTH_DISABLED line and its preceding comment line entirely.
   The server no longer supports a mock/disabled mode.
2. Keep DEPLOY_OKTA_CLIENT_ID in the file BUT mark it as deprecated. Replace its
   block with this exact text:

   # ------------------------------------------------------------
   # DEPRECATED — DEPLOY_OKTA_CLIENT_ID is no longer required.
   # The deploy-server now uses okta-jwt-verifier (AccessTokenVerifier),
   # which validates access tokens with only issuer + audience.
   # If this variable is set, the server will log a one-line warning at
   # startup and ignore it. Remove it from your .env at your convenience.
   # ------------------------------------------------------------
   # DEPLOY_OKTA_CLIENT_ID=

3. Keep all other variables unchanged:
   - DEPLOY_OKTA_DOMAIN (still required, full https URL of the Okta org)
   - DEPLOY_OKTA_AUTH_SERVER_ID (still required, OK1Az2 id)
   - DEPLOY_OKTA_AUDIENCE (still required, must match OK1Az2 audience)
   - SERVER_HOST, SERVER_PORT, LOG_LEVEL

4. Update the file header banner to reflect the SDK change. Replace any reference
   to "okta-ai-sdk" or "private key" with the new posture: "Validates inbound
   XAA AT-2 tokens via okta-jwt-verifier (no client credentials required)."

Show the complete new contents of .env.example.
```

---

## Prompt 05 — Update `docker-compose.yml`

```
In examples/05-deploy-server/docker-compose.yml, remove the env passthrough for
the deprecated client_id variable.

Specifically:
1. Delete the line: DEPLOY_OKTA_CLIENT_ID: ${DEPLOY_OKTA_CLIENT_ID}
   from the deploy-server service's environment block.
2. Do not delete the variable from .env (Prompt 04 already commented it out as
   deprecated) — only remove the docker-compose passthrough so the container
   never sees it. This makes the deprecation effectively complete at the
   container boundary while still tolerating the var in .env for one upgrade
   cycle.
3. Leave DEPLOY_OKTA_DOMAIN, DEPLOY_OKTA_AUTH_SERVER_ID, and DEPLOY_OKTA_AUDIENCE
   passthroughs intact.
4. Also check examples/05-deploy-server/docker-compose.override.yml and apply the
   same removal there if (and only if) DEPLOY_OKTA_CLIENT_ID appears in its
   environment block.

Show the diff for both files (or "no change needed" for the override file if
applicable).
```

---

## Prompt 06 — Update tests: helpers and conftest

```
Rewrite examples/05-deploy-server/tests/helpers.py and examples/05-deploy-server/tests/conftest.py to fixture the new okta-jwt-verifier-based DeployTokenVerifier.

The mocking strategy changes: previously we mocked the legacy SDK's
verify_auth_server_token() to return a MockVerificationResult dataclass. The new
SDK's AccessTokenVerifier.verify() returns nothing on success and raises an
exception on failure. We mock at the DeployTokenVerifier.verify boundary by
patching the module-level `server.verifier` with a MagicMock-shaped object whose
.verify(token) returns the desired claims dict (or raises ValueError).

== helpers.py — full rewrite ==

Replace the entire file with:

    """
    Shared test helpers for the Deploy Server test suite.

    Mocking strategy (post okta-jwt-verifier migration):
    DeployTokenVerifier.verify() returns a claims dict on success and raises
    ValueError on failure. Tests replace the module-level `server.verifier`
    with a MagicMock-backed object that returns canned claims or raises.
    """

    from typing import Any, Dict, Optional
    from unittest.mock import MagicMock


    def make_claims(
        sub: str = "alice@acme.dev",
        aud: str = "api://deploy-server",
        iss: str = "https://org-b.okta.com/oauth2/ausABC123",
        scope: str = "mcp:read mcp:write",
        exp: int = 9999999999,
    ) -> Dict[str, Any]:
        """Build a verified-claims dict matching DeployTokenVerifier.verify()'s shape."""
        return {
            "valid": True,
            "sub": sub,
            "aud": aud,
            "iss": iss,
            "scope": scope,
            "exp": exp,
        }


    def make_context(headers: Optional[Dict[str, str]] = None) -> MagicMock:
        """Create a mock FastMCP Context with configurable request headers."""
        ctx = MagicMock()
        ctx.request = MagicMock()
        _headers = headers or {}
        ctx.request.headers = MagicMock()
        ctx.request.headers.get = lambda key, default="": _headers.get(key, default)
        return ctx

Note: MockVerificationResult is gone. The new SDK has no equivalent dataclass —
DeployTokenVerifier.verify() now returns a plain dict.

== conftest.py — full rewrite ==

Replace the entire file with:

    """
    Shared fixtures for the Deploy Server test suite (post okta-jwt-verifier migration).

    Note: DEPLOY_AUTH_DISABLED has been removed from the production code, so the
    auth_disabled_env fixture is gone. All tests that previously relied on it
    have been deleted or rewritten to mock the verifier directly.
    """

    import os
    import sys
    from unittest.mock import MagicMock

    import pytest

    sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
    sys.path.insert(0, os.path.dirname(__file__))

    from helpers import make_claims, make_context


    @pytest.fixture
    def mock_valid_claims():
        """Default valid claims dict used by tests."""
        return make_claims()


    @pytest.fixture
    def mock_sdk_verifier(mock_valid_claims):
        """Replace server.verifier with a MagicMock that returns claims from .verify().

        Yields a setter function. Call set_result(claims_dict) to change the
        return value or set_error(exc) to make .verify raise.
        """
        import server

        original_verifier = server.verifier
        mock_verifier = MagicMock()
        mock_verifier.verify = MagicMock(return_value=mock_valid_claims)
        server.verifier = mock_verifier

        def set_result(claims):
            mock_verifier.verify.side_effect = None
            mock_verifier.verify.return_value = claims

        def set_error(exc):
            mock_verifier.verify.side_effect = exc

        # Expose both setters by attribute on the returned function for convenience
        set_result.set_error = set_error
        yield set_result

        server.verifier = original_verifier


    @pytest.fixture
    def mock_ctx():
        """A Context with a valid Bearer token header."""
        return make_context({"authorization": "Bearer test-token-abc123"})


    @pytest.fixture
    def mock_ctx_no_auth():
        """A Context with no Authorization header."""
        return make_context({})


    @pytest.fixture
    def mock_ctx_basic_auth():
        """A Context with Basic auth instead of Bearer."""
        return make_context({"authorization": "Basic dXNlcjpwYXNz"})

Note: the auth_disabled_env, mock_valid_verification, mock_invalid_verification
fixtures are intentionally removed.

When done, show the final contents of both files and confirm there are zero
references to MockTokenVerifier, MockVerificationResult, DEPLOY_AUTH_DISABLED,
or auth_disabled in either file.
```

---

## Prompt 07 — Rewrite `tests/test_auth.py`

```
Rewrite examples/05-deploy-server/tests/test_auth.py to match the new auth.py
and the new conftest fixtures. Keep test coverage parity for what still applies;
delete tests for behavior that no longer exists.

Required test cases (rewrite the file to contain exactly these):

== Token verification (using mock_sdk_verifier) ==

1. test_valid_token_returns_claims(mock_sdk_verifier, mock_ctx)
   - Call server.validate_bearer_token(mock_ctx).
   - Assert all six claim keys (valid, sub, aud, iss, scope, exp) match the
     defaults from make_claims().

2. test_invalid_token_raises(mock_sdk_verifier, mock_ctx)
   - Use mock_sdk_verifier.set_error(ValueError("Token verification failed: signature invalid"))
   - Assert validate_bearer_token raises ValueError matching "Token verification failed".

3. test_sub_claim_extracted(mock_sdk_verifier, mock_ctx)
   - Call mock_sdk_verifier(make_claims(sub="bob.smith@partner.org",
     iss="https://partner.okta.com/oauth2/ausXYZ789", scope="mcp:read"))
   - Assert claims["sub"] == "bob.smith@partner.org" and iss matches.

== Authorization header validation ==

4. test_missing_auth_header(mock_sdk_verifier, mock_ctx_no_auth)
   - Assert ValueError("Missing Authorization header").

5. test_malformed_auth_header(mock_sdk_verifier, mock_ctx_basic_auth)
   - Assert ValueError("Authorization header must use Bearer scheme").

6. test_empty_bearer_token(mock_sdk_verifier)
   - ctx with header "Bearer " (trailing space, no token).
   - Assert ValueError("Bearer token is empty").

== DeployTokenVerifier construction ==

7. test_verifier_init_constructs_issuer()
   - Patch sys.modules["okta_jwt_verifier"] with a MagicMock exposing
     AccessTokenVerifier as a MagicMock class. Patch sys.modules["okta_jwt_verifier.exceptions"]
     similarly with JWTValidationException = type("JWTValidationException", (Exception,), {})
     and JWKException = type("JWKException", (Exception,), {}).
   - Reimport `auth` (use importlib.reload).
   - Construct DeployTokenVerifier(okta_domain="dev-12345.okta.com",
     auth_server_id="ausABC123", audience="api://deploy-server").
   - Assert AccessTokenVerifier was called once with kwargs:
       issuer="https://dev-12345.okta.com/oauth2/ausABC123"
       audience="api://deploy-server"
       leeway=0
   - Assert verifier.issuer == "https://dev-12345.okta.com/oauth2/ausABC123".

8. test_no_client_id_parameter()
   - Verify DeployTokenVerifier.__init__ has NO client_id parameter via
     inspect.signature(DeployTokenVerifier.__init__).
   - Assert "client_id" NOT in the parameter names.
   - Assert "client_secret" NOT in the parameter names.
   - Assert "private_jwk" NOT in the parameter names.

9. test_domain_normalization_https()  — already-https unchanged
10. test_domain_normalization_http()   — http:// upgraded to https://
11. test_domain_normalization_bare()   — bare domain gets https:// prepended
12. test_domain_normalization_trailing_slash() — trailing / stripped

For 9–12, use the same sys.modules patch pattern as test 7, then assert
verifier.issuer is constructed correctly. Each test uses auth_server_id="aus1".

== _init_verifier behavior ==

13. test_init_verifier_missing_domain_raises()
    - Patch env: DEPLOY_OKTA_DOMAIN="", DEPLOY_OKTA_AUTH_SERVER_ID="aus1"
    - Assert _init_verifier() raises RuntimeError mentioning DEPLOY_OKTA_DOMAIN.

14. test_init_verifier_missing_auth_server_id_raises()
    - Patch env: DEPLOY_OKTA_DOMAIN="dev.okta.com", DEPLOY_OKTA_AUTH_SERVER_ID=""
    - Assert _init_verifier() raises RuntimeError mentioning DEPLOY_OKTA_AUTH_SERVER_ID.

15. test_init_verifier_legacy_client_id_emits_deprecation_warning(caplog)
    - Patch env: DEPLOY_OKTA_DOMAIN="dev.okta.com",
      DEPLOY_OKTA_AUTH_SERVER_ID="aus1", DEPLOY_OKTA_CLIENT_ID="0oaLEGACY"
    - Patch sys.modules for okta_jwt_verifier as in test 7.
    - Use pytest.warns(DeprecationWarning) AND caplog at WARNING level.
    - Reimport auth, call _init_verifier().
    - Assert at least one log record at WARNING level contains "DEPLOY_OKTA_CLIENT_ID"
      and "deprecated".
    - Assert _init_verifier() returns a DeployTokenVerifier instance (the legacy
      var must NOT block startup).

16. test_init_verifier_no_client_id_no_warning(caplog)
    - Patch env with DEPLOY_OKTA_CLIENT_ID NOT set (use os.environ.pop with
      default to ensure it's absent).
    - Reimport auth, call _init_verifier().
    - Assert no WARNING log record mentions "DEPLOY_OKTA_CLIENT_ID".

== DELETE all of the following tests — they exercise removed behavior ==

- test_auth_disabled_bypass
- test_auth_disabled_accepts_any_token
- test_init_verifier_auth_disabled
- test_init_verifier_missing_client_id  (CLIENT_ID is no longer required, so
  missing it is now correct behavior)
- test_no_private_key_required (the SDK has no concept of a private key on this
  path — the test no longer makes sense)

== DELETE the import of MockVerificationResult ==

When done, show the complete new contents of test_auth.py and run:
    cd examples/05-deploy-server && pip install -r requirements.txt && \
    python -m pytest tests/test_auth.py -v
Expect all tests to pass. Report the pass/fail count.
```

---

## Prompt 08 — Sanity-check `tests/test_tools.py` and `tests/test_data.py`

```
Inspect examples/05-deploy-server/tests/test_tools.py and
examples/05-deploy-server/tests/test_data.py for any references to:
- MockVerificationResult
- MockTokenVerifier
- DEPLOY_AUTH_DISABLED / auth_disabled / auth_disabled_env
- okta_ai_sdk / OktaAISDK / OktaAIConfig
- DeployTokenVerifier with a client_id argument
- mock_valid_verification / mock_invalid_verification fixtures

For each match found, update the test to use the new fixtures and helpers from
Prompt 06 (mock_sdk_verifier setter, make_claims). Preserve test intent —
do not delete coverage of tool behavior, only update the auth-mocking layer.

If no matches are found in either file, report "no changes needed" and move on.

After any edits, run:
    cd examples/05-deploy-server && python -m pytest tests/ -v
and report the full pass/fail counts.
```

---

## Prompt 09 — Update `examples/05-deploy-server/README.md`

```
Update examples/05-deploy-server/README.md to reflect the new SDK and the
removal of DEPLOY_AUTH_DISABLED. Apply the following changes precisely:

1. Replace every occurrence of "okta-ai-sdk" with "okta-jwt-verifier".

2. Replace every occurrence of "verify_auth_server_token()" with
   "AccessTokenVerifier.verify()".

3. Find the section that says (or close to):
   "When `DEPLOY_AUTH_DISABLED=true`, no Okta configuration is needed. The
    deploy server uses a mock verifier that returns placeholder claims."
   DELETE this paragraph entirely and any surrounding sentences that depend on it.
   The server no longer supports auth-disabled mode.

4. Find the section that mentions creating an OIDC Web Application "to get
   DEPLOY_OKTA_CLIENT_ID". DELETE the bullet about creating an OIDC Web App
   solely to obtain a client_id. Replace with: "No OIDC application needs to
   be created for the deploy-server itself — it only validates tokens issued
   by the OK1Az2 custom AS."

5. In the env-vars table, find the row:
       | `DEPLOY_OKTA_CLIENT_ID` | Yes* | - | OAuth client ID for the deploy server app |
   Replace with:
       | `DEPLOY_OKTA_CLIENT_ID` | Deprecated | - | No longer used. Logs a deprecation warning if set. Remove from `.env`. |

6. In the same table, find any row for DEPLOY_AUTH_DISABLED and DELETE it.

7. Find the example .env block (around line 95-105, starts with
   `DEPLOY_OKTA_DOMAIN=...`). Remove the DEPLOY_OKTA_CLIENT_ID and
   DEPLOY_AUTH_DISABLED lines from the example. The remaining example should
   show only DEPLOY_OKTA_DOMAIN, DEPLOY_OKTA_AUTH_SERVER_ID, DEPLOY_OKTA_AUDIENCE,
   plus the SERVER_* and LOG_LEVEL vars.

8. Find the "**Note:** No `privateJWK` is required..." paragraph. Replace with:
   "**Note:** The deploy-server requires no client credentials whatsoever — no
   client_id, no client_secret, no private key. okta-jwt-verifier validates
   inbound access tokens using only the issuer URL and the expected audience,
   fetching the OK1Az2 JWKS internally."

9. In the troubleshooting section "### \"Token verification failed\" from deploy server",
   keep the four numbered checks but update check #1 to read:
   "1. Check `DEPLOY_OKTA_DOMAIN` and `DEPLOY_OKTA_AUTH_SERVER_ID` together
      construct the expected issuer:
      `https://{DEPLOY_OKTA_DOMAIN}/oauth2/{DEPLOY_OKTA_AUTH_SERVER_ID}`.
      This must match the `iss` claim in the AT-2 token."

10. In the file structure block, update the auth.py comment from
    "# Token verification (okta-ai-sdk, no private key)"
    to
    "# Token verification (okta-jwt-verifier, no client credentials)".

After all edits, grep the file:
   grep -n "okta-ai-sdk\|verify_auth_server_token\|DEPLOY_AUTH_DISABLED\|MockTokenVerifier\|privateJWK" examples/05-deploy-server/README.md
This must return zero matches. Report that result.
```

---

## Prompt 10 — Update `AZURE_ACA_DEPLOYMENT_GUIDE.md`

```
Update the top-level AZURE_ACA_DEPLOYMENT_GUIDE.md to reflect that
DEPLOY_OKTA_CLIENT_ID is no longer required.

Apply these targeted edits:

1. Section 7 (Okta Step 3 — Confidential Relay OIDC Web App), find the paragraph
   that begins:
       "**Put the Client ID in `.env` as `DEPLOY_OKTA_CLIENT_ID`.** The
        deploy-server container's `okta-ai-sdk` initialization requires a
        `clientId` value in its config object..."
   REPLACE the entire paragraph with:
       "**No `.env` entry is needed for the Relay app's Client ID.** As of the
       okta-jwt-verifier SDK migration, the deploy-server validates inbound
       AT-2 tokens using only the issuer URL and the expected audience —
       no client_id is required on the resource-server side. The Relay app's
       Client ID is still discovered automatically by the Admin UI's
       Import-from-Okta flow (Section 11) via the AI Agent's Linked Application
       relationship from Step 4. If you have an older `.env` with
       `DEPLOY_OKTA_CLIENT_ID` set, the deploy-server will log a one-time
       deprecation warning at startup and ignore it."

2. In Section 7, also find the bullet that says
       "- Save. Copy the **Client ID** — the **only** place you'll paste it
        manually is `.env` as `DEPLOY_OKTA_CLIENT_ID` (see below). ..."
   UPDATE the bullet to:
       "- Save. The **Client ID** does not need to be copied anywhere manually.
        The Admin UI will discover it automatically when you sync the AI Agent
        from Okta in Section 11, via the Linked Application relationship you'll
        set up in Step 4. The **Client secret** is also never manually copied —
        the Admin UI fetches it from Okta as part of the same sync."

3. Section 9 (Populate `.env` and run...), find the `.env` block with these
   three lines:
       DEPLOY_OKTA_CLIENT_ID=0oaYYYYYYYYYYYYYYY          # Reuse the Confidential Relay client_id from Step 3
       DEPLOY_OKTA_AUTH_SERVER_ID=ausZZZZZZZZZZZZZZZ     # OK1Az2 id from Step 1
       DEPLOY_OKTA_AUDIENCE=api://deploy-server          # must match OK1Az2 audience from Step 1
   REMOVE the DEPLOY_OKTA_CLIENT_ID line entirely. Keep the other two.

4. Immediately below the `.env` block in Section 9, find the blockquote that
   starts:
       "> The Confidential Relay Client ID is used twice: once in `.env` as
        `DEPLOY_OKTA_CLIENT_ID` (for deploy-server SDK init)..."
   REPLACE the entire blockquote with:
       "> The Confidential Relay Client ID is no longer needed in `.env`. It is
       discovered automatically by the Admin UI's Import-from-Okta flow
       (Section 11) via the AI Agent's Linked Application relationship from
       Step 4, and stored per-agent in Postgres. The Client secret is also
       fetched automatically by the Admin UI during Import."

After edits, grep the file:
   grep -n "DEPLOY_OKTA_CLIENT_ID\|okta-ai-sdk" AZURE_ACA_DEPLOYMENT_GUIDE.md
The only remaining matches should be inside the new "deprecation warning" mention
from edit #1 (where we explain that an older .env with the var still works).
There should be zero references to "okta-ai-sdk".
Report the grep results.
```

---

## Prompt 11 — Final verification and smoke test

```
Run the following verification sequence and report the result of each step.
If any step fails, stop and report the failure rather than continuing.

1. Dependency install:
       cd examples/05-deploy-server
       pip install -r requirements.txt
   Expect: okta-jwt-verifier installs cleanly, okta-ai-sdk-proto is NOT installed.
   Verify with:
       pip show okta-jwt-verifier && pip show okta-ai-sdk-proto || echo "OK: okta-ai-sdk-proto not installed"

2. Static repo grep for stale references (run from repo root):
       grep -rn "okta-ai-sdk\|okta_ai_sdk\|OktaAISDK\|OktaAIConfig\|MockTokenVerifier\|DEPLOY_AUTH_DISABLED\|verify_auth_server_token" examples/05-deploy-server/ AZURE_ACA_DEPLOYMENT_GUIDE.md
   Expect: zero matches.

3. Static repo grep for the deprecation safety net:
       grep -n "DEPLOY_OKTA_CLIENT_ID" examples/05-deploy-server/auth.py
   Expect: exactly one or two matches — the lines that read the env var and emit
   the deprecation warning.

4. Run the full test suite:
       cd examples/05-deploy-server && python -m pytest tests/ -v
   Report the pass/fail count and any failures verbatim.

5. Boot smoke test (no Okta call, just verify imports + startup wiring):
       cd examples/05-deploy-server
       DEPLOY_OKTA_DOMAIN=https://example.okta.com \
       DEPLOY_OKTA_AUTH_SERVER_ID=ausTEST123 \
       DEPLOY_OKTA_AUDIENCE=api://deploy-server \
       python -c "import auth; v = auth._init_verifier(); print('issuer:', v.issuer); print('audience:', v.audience)"
   Expect: prints
       issuer: https://example.okta.com/oauth2/ausTEST123
       audience: api://deploy-server

6. Boot smoke test for deprecation warning:
       cd examples/05-deploy-server
       DEPLOY_OKTA_DOMAIN=https://example.okta.com \
       DEPLOY_OKTA_AUTH_SERVER_ID=ausTEST123 \
       DEPLOY_OKTA_AUDIENCE=api://deploy-server \
       DEPLOY_OKTA_CLIENT_ID=0oaLEGACY \
       python -c "import logging, auth; logging.basicConfig(level=logging.WARNING); auth._init_verifier()"
   Expect: stderr contains a single WARNING line mentioning DEPLOY_OKTA_CLIENT_ID
   and "deprecated".

7. Boot smoke test for missing-config failure:
       cd examples/05-deploy-server
       DEPLOY_OKTA_DOMAIN= \
       DEPLOY_OKTA_AUTH_SERVER_ID= \
       python -c "import auth; auth._init_verifier()" 2>&1 | tail -5
   Expect: RuntimeError mentioning DEPLOY_OKTA_DOMAIN and DEPLOY_OKTA_AUTH_SERVER_ID.

If all seven steps pass, the migration is complete. Produce a short bulleted
summary of what changed, listing each modified file and a one-line description
of the change.
```

---

## Notes for the operator

- **Why `okta-jwt-verifier` and not `okta-client-python`:** the latter has no
  resource-server verifier surface — every flow in it is for *issuing* tokens.
  See https://github.com/okta/okta-client-python README for the full module list.
  The right Okta SDK for our use case (validating an access token issued by a
  custom AS) is `okta-jwt-verifier`, which uses `AccessTokenVerifier(issuer, audience)`
  and requires no client_id.

- **Async-to-sync bridging:** `okta-jwt-verifier` exposes async APIs
  (`await verifier.verify(token)`). The deploy-server's FastMCP tool surface is
  synchronous, so `DeployTokenVerifier.verify()` wraps the async call with
  `asyncio.run()`. This is acceptable because each tool invocation creates a
  fresh event loop for one short verification call. If the deploy-server is ever
  refactored to be fully async, drop the `asyncio.run()` and propagate `await`.

- **JWKS caching:** `AccessTokenVerifier` caches JWKS internally. We construct
  one verifier instance per process (singleton via module-level `verifier =
  _init_verifier()` in `server.py`), so JWKS fetch happens once at first use
  and is reused for every subsequent token validation.

- **Backward compatibility window:** the deprecation handling for
  `DEPLOY_OKTA_CLIENT_ID` is intentionally one upgrade cycle. After operators
  have had time to remove the var from their `.env` files, a follow-up PR can
  delete the deprecation-warning code from `auth.py` (~5 lines) and the
  deprecated comment block from `.env.example`.

- **No audit logging changes required.** Per the standing rule, audit events
  only need to be added/updated when modifying request/auth/token-exchange paths
  in the *adapter*. The deploy-server is a backend MCP server that receives
  already-authenticated requests; its auth posture (verify-or-reject) is
  unchanged. The adapter's existing audit events for backend dispatch (`router.py`,
  `cross_app_access.py`) are unaffected by this migration.
