# Redis Credential Provider — Phase 2 Implementation Prompts

**Feature:** AWS ElastiCache IAM authentication + Azure Managed Redis Entra ID authentication
**Phase:** 2 of 4 — Cloud-native identity providers replace static-password requirement in production
**Prerequisite:** Phase 1 (P01–P05) complete and merged
**Prompt count:** 7 sequential prompts
**Test constraint:** All Phase 1 tests + new Phase 2 tests pass
**Audit constraint:** Every credential mint emits `REDIS_CREDENTIAL_MINTED`; refresh failures emit `REDIS_CREDENTIAL_REFRESH_FAILED`

---

## Phase Map

| #   | Prompt                                          | Creates / Modifies                                                                  | Est. Time |
| --- | ----------------------------------------------- | ----------------------------------------------------------------------------------- | --------- |
| P06 | AWS IAM provider + scheduled refresh seam       | `cache/redis_credential_providers/aws_iam.py`, `cache/redis_provider.py`            | 45 min    |
| P07 | Azure Entra provider                            | `cache/redis_credential_providers/azure_entra.py`, factory                          | 30 min    |
| P08 | Factory + startup preflight + audit on refresh  | `cache/redis_credentials.py`, `app.py`, health endpoint                             | 35 min    |
| P09 | AWS ECS Terraform — switch to IAM               | `deploy/aws-ecs/main.tf`, `deploy/aws-ecs/README.md`                                | 30 min    |
| P10 | Azure ACA Bicep — switch to Entra MI            | `deploy/azure-aca/bicep/modules/apps.bicep`, `deploy/azure-aca/acasetup.sh`, README | 35 min    |
| P11 | Audit field enrichment for credential observability | `cache/redis_provider.py`, `app.py` (audit details enrichments)          | 25 min    |
| P12 | Documentation + security-review deliverables    | `.env.example`, `CLAUDE.md`, `README.md`, deploy READMEs                            | 25 min    |

**Total estimated time:** ~3h 45m of Claude Code execution.

**Key delta from Phase 1:** the static gate gets *removed* from the deploy templates in P09 and P10. After Phase 2, production deployments authenticate to Redis with no shared secret of any kind. The static path remains in code for local dev only.

---

## Prerequisites

- Phase 1 P01–P05 merged. Verify by running `pytest tests/cache/ -v` — should show 39 tests passing.
- AWS account access for one integration smoke test (P09 step 8). Local unit tests use `moto`.
- Azure subscription access with permission to create role assignments on Azure Managed Redis (P10 step 9). Local unit tests use mocked `azure-identity`.
- `pyproject.toml` will gain four new dependencies in P06/P07:
  - `boto3>=1.34.0` (for AWS SigV4 signing)
  - `botocore>=1.34.0` (transitive, but pin)
  - `azure-identity>=1.15.0`
  - `pyjwt>=2.8.0` (decode unsigned Entra tokens to extract `oid`)

---

## How to Execute

```bash
cd okta-agent-mcp-adapter
git checkout -b feature/redis-credential-provider-phase-2

# For each prompt:
# 1. Paste the prompt verbatim into Claude Code
# 2. Wait for completion + test count
# 3. Verify the working tree
# 4. git commit -m "redis-creds P0X: <one-line summary>"
# 5. /clear  (clear context for next prompt)
```

Phase 2 has two cross-cutting changes that *must* land in the right order — P06 introduces the scheduled refresh seam that all expiring providers depend on, and P08 wires the factory to recognize the new mode strings. Do not skip ahead.

---

# Phase 2: Cloud-Native Identity Providers

---

## Prompt P06: AWS IAM Provider + Scheduled Refresh Seam

**Context:** This prompt does two things: (1) introduces the `AwsIamElastiCacheProvider`, which mints SigV4-signed pre-signed URLs as Redis AUTH tokens with 15-minute lifetime; (2) extends `RedisCacheProvider` with a scheduled-refresh task that closes and rebuilds the per-loop client ahead of credential expiry. The refresh seam is generic — Entra (P07), mTLS (Phase 3), and Vault (Phase 3) all use it.

The seam belongs in P06 because AWS IAM has the shortest lifetime (15 min) and is the most aggressive driver of the refresh requirement. Without scheduled refresh, IAM tokens would expire mid-request and produce NOAUTH errors.

**Prompt:**

````
Add AwsIamElastiCacheProvider and the scheduled-refresh seam to the
RedisCacheProvider.

Read first:
- okta_agent_proxy/cache/redis_credentials.py (RedisCredentials, RedisCredentialProvider, get_redis_credential_provider factory)
- okta_agent_proxy/cache/redis_provider.py (current RedisCacheProvider — note _get_redis() has per-loop client cache, _strip_url_credentials helper, _emit_mint_audit method, _minted_loops set)
- okta_agent_proxy/cache/redis_credential_providers/static.py (file layout pattern, from_env classmethod pattern, module-level constants for env var names)
- okta_agent_proxy/audit/events.py (AuditEventType — append-only; AuditSeverity has only INFO, WARNING, CRITICAL — NO HIGH)
- pyproject.toml (current dependencies block)
- tests/cache/test_static_password_provider.py (test pattern: imports module-level env constants, uses monkeypatch + AsyncMock)

Execute the following:

1. Add boto3 dependency.

   In pyproject.toml, append to the dependencies list (alphabetical with existing
   entries). Use a lower bound that matches what AWS publishes for ElastiCache IAM
   support:

       "boto3>=1.34.0",
       "botocore>=1.34.0",

   In requirements.txt (if it exists and is pinned), add the same two lines.
   Run `pip install -e .` to confirm resolution before continuing — if there's a
   conflict with an existing transitive boto3 from okta-sdk, document it but
   proceed (the version range should be wide enough).

2. Create okta_agent_proxy/cache/redis_credential_providers/aws_iam.py.

   Module docstring:
   "AWS ElastiCache IAM credential provider.

   Mints a SigV4-signed pre-signed URL whose query string acts as the Redis
   AUTH password. Tokens are valid for 15 minutes (AWS-imposed maximum for
   elasticache:Connect). The Redis username is the IAM-enabled ElastiCache
   user ID — NOT the IAM role/principal name.

   Mint cost is purely local (no network round-trip; SigV4 signing happens
   in-process), so we re-mint on every reconnect rather than caching the
   token. The 2.5-minute refresh safety window provides headroom for clock
   skew and slow client reconnects.

   Required IAM permissions on the ECS task role / EC2 instance role / EKS
   service account:

       {
         \"Effect\": \"Allow\",
         \"Action\": \"elasticache:Connect\",
         \"Resource\": [
           \"arn:aws:elasticache:<region>:<account>:serverlesscache:<cache-name>\",
           \"arn:aws:elasticache:<region>:<account>:user:<user-id>\"
         ]
       }

   For a self-designed (non-serverless) cluster, the resource ARN is
   `arn:aws:elasticache:<region>:<account>:replicationgroup:<group-id>`."

   Imports:
   - import datetime
   - import logging
   - import os
   - from typing import Optional
   - from urllib.parse import urlparse, urlencode
   - from botocore.auth import SigV4QueryAuth
   - from botocore.awsrequest import AWSRequest
   - from botocore.session import Session
   - from okta_agent_proxy.cache.redis_credentials import (
         RedisCredentialProvider, RedisCredentials, CredentialUnavailableError
     )

   Module logger.

   Module-level constants (env var names):
       USER_ID_ENV = "REDIS_AWS_USER_ID"
       CACHE_NAME_ENV = "REDIS_AWS_CACHE_NAME"
       REGION_ENV = "AWS_REGION"
       SERVERLESS_ENV = "REDIS_AWS_SERVERLESS"  # default true

   TOKEN_LIFETIME_SECONDS = 900  # 15 minutes (AWS max for elasticache:Connect)
   ACTION = "connect"
   SERVICE = "elasticache"

   Class AwsIamElastiCacheProvider(RedisCredentialProvider):
       name = "aws-iam"

       def __init__(
           self,
           user_id: str,
           cache_name: str,
           region: str,
           is_serverless: bool = True,
           session: Optional[Session] = None,
       ):
           if not user_id:
               raise ValueError("user_id is required for aws-iam provider")
           if not cache_name:
               raise ValueError("cache_name is required for aws-iam provider")
           if not region:
               raise ValueError("region is required for aws-iam provider")
           self._user_id = user_id
           self._cache_name = cache_name
           self._region = region
           self._is_serverless = is_serverless
           self._session = session or Session()

       @classmethod
       def from_env(cls) -> "AwsIamElastiCacheProvider":
           """Construct from environment.

           Required: REDIS_AWS_USER_ID, REDIS_AWS_CACHE_NAME, AWS_REGION.
           Optional: REDIS_AWS_SERVERLESS (default 'true').
           """
           user_id = os.environ.get(USER_ID_ENV, "").strip()
           cache_name = os.environ.get(CACHE_NAME_ENV, "").strip()
           region = os.environ.get(REGION_ENV, "").strip()
           if not user_id or not cache_name or not region:
               raise CredentialUnavailableError(
                   f"REDIS_AUTH_MODE=aws-iam requires {USER_ID_ENV}, "
                   f"{CACHE_NAME_ENV}, and {REGION_ENV} to be set."
               )
           is_serverless = (
               os.environ.get(SERVERLESS_ENV, "true").strip().lower() == "true"
           )
           return cls(user_id=user_id, cache_name=cache_name,
                      region=region, is_serverless=is_serverless)

       async def get_credentials(self) -> RedisCredentials:
           """Mint a fresh SigV4 pre-signed URL token.

           This is a synchronous boto3 call wrapped in async. Mint cost is
           local — there is no network round-trip — so the call returns
           in microseconds. We do not run it in a thread executor.
           """
           try:
               creds = self._session.get_credentials()
               if creds is None:
                   raise CredentialUnavailableError(
                       "AWS credential chain returned no credentials. "
                       "Ensure the ECS task role, EC2 instance role, EKS service "
                       "account, or AWS_ACCESS_KEY_ID/AWS_SECRET_ACCESS_KEY env "
                       "vars are configured."
                   )
               frozen = creds.get_frozen_credentials()

               # Build the canonical pre-sign URL. The format AWS expects for
               # ElastiCache IAM auth:
               #   <cache-name>/?Action=connect&User=<user-id>
               # We sign this as a GET, then strip the scheme+host from the
               # signed URL — the remainder (path + signed query string) is
               # the AUTH token.
               query = {"Action": ACTION, "User": self._user_id}
               url = f"http://{self._cache_name}/?{urlencode(query)}"
               request = AWSRequest(method="GET", url=url)
               # SigV4QueryAuth uses the X-Amz-Expires query param; set it via
               # the request context.
               request.context["timeout"] = TOKEN_LIFETIME_SECONDS
               signer = SigV4QueryAuth(frozen, SERVICE, self._region)
               signer.add_auth(request)
               signed_url = request.url

               # Token = signed_url with scheme://host/ stripped.
               # boto3's signed_url includes "http://<cache-name>/?..." — we want
               # "<cache-name>/?..." so Redis sees the path + signed query.
               parsed = urlparse(signed_url)
               token = f"{parsed.netloc}{parsed.path}?{parsed.query}"

               principal = f"arn:aws:iam::*:role/{frozen.access_key}"
               # frozen.access_key is the IAM access key id (usable for audit),
               # NOT a secret — secret_key and token are not logged.

               return RedisCredentials(
                   username=self._user_id,
                   password=token,
                   expires_at=datetime.datetime.now(datetime.timezone.utc)
                       + datetime.timedelta(seconds=TOKEN_LIFETIME_SECONDS),
                   ssl_context=None,
                   principal=principal,
               )
           except CredentialUnavailableError:
               raise
           except Exception as e:
               # Wrap unexpected errors so the caller gets a typed exception.
               raise CredentialUnavailableError(
                   f"Failed to mint AWS IAM token for ElastiCache: {e}"
               ) from e

       def refresh_safety_window(self) -> datetime.timedelta:
           # 2.5 minutes — about 17% of the 15-min lifetime. Provides headroom
           # for clock skew and slow client reconnects.
           return datetime.timedelta(minutes=2, seconds=30)

3. Modify okta_agent_proxy/cache/redis_provider.py to add scheduled-refresh.

   The existing RedisCacheProvider mints once per loop and never refreshes. AWS
   IAM tokens expire after 15 minutes, so we need a per-client refresh task
   that closes and rebuilds the connection ahead of expiry.

   Add to RedisCacheProvider.__init__:
       self._refresh_tasks: dict[int, asyncio.Task] = {}

   Add to imports at top:
       import asyncio

   In _get_redis(), after the line that adds to _minted_loops and emits the
   mint audit, but before the function returns the client, schedule a
   refresh task IF the credential is expiring:

       # Schedule a refresh task if credentials expire and we don't already
       # have one for this loop.
       if (
           self._credential_provider is not None
           and creds.is_expiring()
           and loop_id not in self._refresh_tasks
       ):
           self._refresh_tasks[loop_id] = asyncio.create_task(
               self._scheduled_refresh(loop_id, creds, self._credential_provider),
               name=f"redis-cred-refresh-loop-{loop_id}",
           )

   Add as a new method on RedisCacheProvider:

       async def _scheduled_refresh(
           self,
           loop_id: int,
           initial_creds,
           provider,
       ):
           """Sleep until refresh-safety-window before expiry, then close
           the cached client so the next _get_redis() rebuilds with fresh
           credentials.

           If the provider's get_credentials raises during refresh, audit
           the failure and let the existing client run until the cached
           token actually expires; the next get/set will fail with NOAUTH
           and trigger a normal reconnect attempt."""
           try:
               window = provider.refresh_safety_window()
               # Compute time-to-refresh from "now" so we don't drift on long
               # provider chains.
               now = datetime.datetime.now(datetime.timezone.utc)
               refresh_at = initial_creds.expires_at - window
               sleep_seconds = max(1.0, (refresh_at - now).total_seconds())
               logger.debug(
                   "[redis-creds] scheduled refresh for loop %s in %ss "
                   "(expires_at=%s, window=%s)",
                   loop_id, sleep_seconds,
                   initial_creds.expires_at.isoformat(), window,
               )
               await asyncio.sleep(sleep_seconds)

               # Close the cached client so the next _get_redis() call rebuilds.
               # We do NOT pre-mint here — the provider will be called again
               # synchronously inside _get_redis() and the new client built
               # with fresh credentials.
               client = self._clients.pop(loop_id, None)
               self._minted_loops.discard(loop_id)
               self._refresh_tasks.pop(loop_id, None)
               if client is not None:
                   try:
                       await client.aclose()
                   except Exception as e:
                       logger.warning(
                           "[redis-creds] error closing client during refresh: %s", e
                       )

               await self._emit_refresh_audit(provider, success=True)
           except asyncio.CancelledError:
               raise
           except Exception as e:
               # Refresh failed — log and audit, but don't crash the process.
               # The cached client continues working until the actual expiry,
               # and the next failed Redis call will trigger reconnect.
               logger.error(
                   "[redis-creds] scheduled refresh failed for loop %s: %s",
                   loop_id, e,
               )
               await self._emit_refresh_audit(provider, success=False, error=str(e))
               # Clean up so the next _get_redis() will retry the schedule.
               self._refresh_tasks.pop(loop_id, None)

       async def _emit_refresh_audit(self, provider, success: bool, error: Optional[str] = None):
           try:
               from okta_agent_proxy.audit import emit_audit_event
               from okta_agent_proxy.audit.events import AuditEventType, AuditSeverity
               event_type = (
                   AuditEventType.REDIS_CREDENTIAL_REFRESH_SUCCESS if success
                   else AuditEventType.REDIS_CREDENTIAL_REFRESH_FAILED
               )
               severity = AuditSeverity.INFO if success else AuditSeverity.WARNING
               details = {"provider": provider.name}
               if error:
                   details["error"] = error
               await emit_audit_event(
                   event_type, severity,
                   resource_name="redis", details=details,
                   outcome="success" if success else "failure",
               )
           except Exception as e:
               logger.warning(f"[redis-creds] refresh audit emission failed: {e}")

   IMPORTANT: also ensure the close() / __del__ path cancels any pending
   refresh tasks. Find the existing close method (or add one if absent):

       async def close(self):
           # Cancel pending refresh tasks first.
           for task in list(self._refresh_tasks.values()):
               if not task.done():
                   task.cancel()
           self._refresh_tasks.clear()
           # Close all cached clients.
           for client in list(self._clients.values()):
               try:
                   await client.aclose()
               except Exception:
                   pass
           self._clients.clear()
           self._minted_loops.clear()

4. Create tests/cache/test_aws_iam_provider.py.

   Use moto's mock_aws decorator (or a manual SigV4 mock if moto's elasticache
   support is missing — verify with `python -c "from moto import mock_aws"`).

   Tests:

   - test_from_env_raises_when_user_id_missing
     (REDIS_AWS_CACHE_NAME and AWS_REGION set, REDIS_AWS_USER_ID unset →
      CredentialUnavailableError)
   - test_from_env_raises_when_cache_name_missing
   - test_from_env_raises_when_region_missing
   - test_from_env_succeeds_with_all_required
   - test_from_env_serverless_defaults_to_true
   - test_from_env_serverless_false_when_explicitly_set
   - test_get_credentials_returns_user_id_as_username
   - test_get_credentials_password_is_not_empty
   - test_get_credentials_password_does_not_contain_aws_secret_key
     (sign with a known fake secret key, assert that secret key string does
     NOT appear anywhere in the returned password — SigV4 signs WITH the
     secret but the signature is opaque)
   - test_get_credentials_expires_at_is_15_minutes_from_now
     (assert expires_at - now is between 14m45s and 15m15s)
   - test_get_credentials_principal_includes_access_key
   - test_refresh_safety_window_is_2_minutes_30_seconds
   - test_get_credentials_raises_when_aws_creds_chain_empty
     (mock Session().get_credentials() to return None)
   - test_get_credentials_wraps_botocore_errors_in_credential_unavailable
     (mock the signer to raise, assert CredentialUnavailableError chain)

   For tests that need fake AWS credentials, set
   AWS_ACCESS_KEY_ID=AKIAIOSFODNN7EXAMPLE and
   AWS_SECRET_ACCESS_KEY=wJalrXUtnFEMI/K7MDENG/bPxRfiCYEXAMPLEKEY (the AWS
   docs example values) via monkeypatch.

5. Add tests for the scheduled-refresh seam in
   tests/cache/test_redis_provider_scheduled_refresh.py:

   - test_refresh_task_scheduled_when_credential_expires
     (FakeProvider returns creds with expires_at=now+30s,
     refresh_safety_window=10s. Call _get_redis(), then sleep 25s.
     Assert that a new client was built — i.e., _minted_loops was cleared
     and refilled.)
   - test_refresh_task_not_scheduled_for_non_expiring_creds
     (StaticProvider-like: expires_at=None. Assert no task in _refresh_tasks.)
   - test_refresh_failure_emits_warning_audit
     (Provider that raises on second get_credentials. Verify
     REDIS_CREDENTIAL_REFRESH_FAILED is emitted with WARNING severity.)
   - test_close_cancels_pending_refresh_tasks
     (Schedule a task, call close(), assert task.cancelled() is True.)
   - test_refresh_emits_success_audit
     (Provider with short expiry, verify
     REDIS_CREDENTIAL_REFRESH_SUCCESS is emitted with INFO severity.)

   Use a `FakeExpiringProvider` subclass of RedisCredentialProvider
   in the test module. Mock aioredis.from_url to return an AsyncMock
   client whose aclose is also AsyncMock. Use asyncio.wait_for with
   short timeouts.

6. Run tests:
   pytest tests/cache/test_aws_iam_provider.py -v
   pytest tests/cache/test_redis_provider_scheduled_refresh.py -v
   All must pass.

7. Run the full suite:
   pytest tests/ -x -q
   No regressions allowed. Phase 1's 39 cache tests must still pass.

8. Print:
   "P06 complete: AwsIamElastiCacheProvider + scheduled-refresh seam.
    AWS IAM tests: <N>. Refresh tests: <M>. Total suite: <T>."
````

**Expected Output:**
- New file: `okta_agent_proxy/cache/redis_credential_providers/aws_iam.py`
- New file: `tests/cache/test_aws_iam_provider.py` (~14 tests)
- New file: `tests/cache/test_redis_provider_scheduled_refresh.py` (~5 tests)
- Modified: `okta_agent_proxy/cache/redis_provider.py` (refresh seam)
- Modified: `pyproject.toml` (boto3, botocore)
- All Phase 1 tests still passing.

**Commit:** `redis-creds P06: AwsIamElastiCacheProvider + scheduled refresh`

---

## Prompt P07: Azure Entra Provider

**Context:** Adds the `EntraManagedIdentityProvider` for Azure Managed Redis (default since 2024 GA) and Azure Cache for Redis Standard/Premium with Entra explicitly enabled. Token lifetime is ~1 hour (issued by Entra, varies). Username is the Object ID of the managed identity; password is the access token. The 5-minute refresh window matches Microsoft's published guidance ("at least three minutes before expiry").

The provider piggy-backs on the scheduled-refresh seam from P06 — no new infrastructure here, just the provider implementation.

**Prompt:**

````
Add EntraManagedIdentityProvider to the Redis credential abstraction.

Read first:
- okta_agent_proxy/cache/redis_credential_providers/aws_iam.py (from P06 — match the file layout, env-var constants, error wrapping pattern)
- okta_agent_proxy/cache/redis_credentials.py (RedisCredentialProvider abstract; refresh_safety_window default)
- pyproject.toml (current dependencies)

Execute the following:

1. Add Azure dependencies.

   In pyproject.toml (alphabetical):

       "azure-identity>=1.15.0",
       "azure-core>=1.30.0",
       "pyjwt>=2.8.0",

   pyjwt is needed only to decode the Entra access token (without signature
   verification) to extract the `oid` claim that becomes the Redis username.
   We do NOT verify the signature — Azure Managed Redis itself validates
   the token; the adapter only reads the `oid` claim for the AUTH username.

   Run pip install -e . to confirm resolution.

2. Create okta_agent_proxy/cache/redis_credential_providers/azure_entra.py.

   Module docstring:
   "Azure Entra ID credential provider for Azure Managed Redis and
   Azure Cache for Redis Standard/Premium tiers with Entra enabled.

   Acquires an access token from Entra ID via the Azure Identity SDK
   (DefaultAzureCredential or a more constrained ManagedIdentityCredential).
   The token is presented as the Redis AUTH password; the username is the
   Object ID (oid claim) of the calling identity.

   Token lifetime is whatever Entra issues — typically ~1 hour for managed
   identities, sometimes shorter under Conditional Access policies. The
   5-minute refresh safety window matches Microsoft's published guidance
   for Azure Managed Redis (refresh at least 3 minutes before expiry; we
   use 5 for clock skew margin).

   Note: Azure Cache for Redis BASIC tier does NOT support Entra ID. This
   provider only works against Standard/Premium tiers with Entra explicitly
   enabled, OR against Azure Managed Redis (where Entra is the default)."

   Imports:
   - import datetime
   - import logging
   - import os
   - from typing import Optional
   - import jwt  # PyJWT
   - from azure.identity.aio import DefaultAzureCredential, ManagedIdentityCredential
   - from azure.core.exceptions import ClientAuthenticationError
   - from okta_agent_proxy.cache.redis_credentials import (
         RedisCredentialProvider, RedisCredentials, CredentialUnavailableError
     )

   Module logger.

   Module-level constants:
       USE_MSI_ENV = "REDIS_AZURE_USE_MSI"  # default true
       PRINCIPAL_OID_ENV = "REDIS_AZURE_PRINCIPAL_OID"  # optional override
       CLIENT_ID_ENV = "REDIS_AZURE_CLIENT_ID"  # optional, for UAMI

   REDIS_SCOPE = "https://redis.azure.com/.default"
   REFRESH_WINDOW_MINUTES = 5

   Class EntraManagedIdentityProvider(RedisCredentialProvider):
       name = "azure-entra"

       def __init__(
           self,
           use_msi: bool = True,
           client_id: Optional[str] = None,
           principal_oid: Optional[str] = None,
       ):
           if use_msi:
               # ManagedIdentityCredential is more constrained than
               # DefaultAzureCredential — fails fast in container apps if
               # IMDS isn't reachable, rather than falling through to
               # developer creds and silently using the wrong identity.
               kwargs = {}
               if client_id:
                   # User-assigned MI: must specify which one
                   kwargs["client_id"] = client_id
               self._cred = ManagedIdentityCredential(**kwargs)
           else:
               self._cred = DefaultAzureCredential()
           self._principal_oid = principal_oid  # cached / pre-set

       @classmethod
       def from_env(cls) -> "EntraManagedIdentityProvider":
           use_msi_str = os.environ.get(USE_MSI_ENV, "true").strip().lower()
           use_msi = use_msi_str == "true"
           client_id = os.environ.get(CLIENT_ID_ENV, "").strip() or None
           principal_oid = os.environ.get(PRINCIPAL_OID_ENV, "").strip() or None
           return cls(
               use_msi=use_msi,
               client_id=client_id,
               principal_oid=principal_oid,
           )

       async def get_credentials(self) -> RedisCredentials:
           try:
               token = await self._cred.get_token(REDIS_SCOPE)
           except ClientAuthenticationError as e:
               raise CredentialUnavailableError(
                   f"Entra credential acquisition failed: {e}"
               ) from e
           except Exception as e:
               raise CredentialUnavailableError(
                   f"Unexpected error acquiring Entra token: {e}"
               ) from e

           # Extract Object ID from the access token if not already cached.
           # The `oid` claim is stable for the lifetime of the identity.
           if self._principal_oid is None:
               try:
                   # Decode without signature verification — Azure Managed Redis
                   # is the verifying party for this token, not the adapter.
                   claims = jwt.decode(
                       token.token,
                       options={"verify_signature": False, "verify_aud": False},
                   )
                   self._principal_oid = (
                       claims.get("oid") or claims.get("appid") or claims.get("sub")
                   )
                   if not self._principal_oid:
                       raise CredentialUnavailableError(
                           "Entra access token has no oid/appid/sub claim — "
                           "cannot use as Redis AUTH username"
                       )
               except jwt.PyJWTError as e:
                   raise CredentialUnavailableError(
                       f"Could not decode Entra access token: {e}"
                   ) from e

           # token.expires_on is a Unix timestamp.
           expires_at = datetime.datetime.fromtimestamp(
               token.expires_on, tz=datetime.timezone.utc
           )

           return RedisCredentials(
               username=self._principal_oid,
               password=token.token,
               expires_at=expires_at,
               ssl_context=None,
               principal=self._principal_oid,
           )

       def refresh_safety_window(self) -> datetime.timedelta:
           return datetime.timedelta(minutes=REFRESH_WINDOW_MINUTES)

       async def health_check(self) -> bool:
           try:
               await self.get_credentials()
               return True
           except Exception:
               return False

3. Create tests/cache/test_azure_entra_provider.py.

   Mock both DefaultAzureCredential and ManagedIdentityCredential. Use
   unittest.mock.AsyncMock for get_token. Build fake unsigned JWTs with
   PyJWT for the oid extraction tests:

       def _make_fake_token(oid="00000000-0000-0000-0000-000000000001",
                            expires_in=3600):
           import jwt as _jwt, datetime as dt
           payload = {
               "oid": oid,
               "appid": "test-app-id",
               "exp": int((dt.datetime.now() + dt.timedelta(seconds=expires_in)).timestamp()),
           }
           # Sign with a dummy key — we only decode without verification, but
           # PyJWT requires a key for encoding.
           return _jwt.encode(payload, "dummy", algorithm="HS256")

   Tests:

   - test_from_env_defaults_to_msi
     (no env set → use_msi=True, ManagedIdentityCredential constructed)
   - test_from_env_with_msi_false_uses_default_chain
   - test_from_env_picks_up_client_id_for_user_assigned_mi
   - test_from_env_uses_pre_set_principal_oid_when_provided
   - test_get_credentials_returns_oid_as_username
     (mock get_token to return a fake JWT with oid="abc-123",
      assert credentials.username == "abc-123")
   - test_get_credentials_falls_back_to_appid_when_no_oid
   - test_get_credentials_falls_back_to_sub_when_no_oid_no_appid
   - test_get_credentials_raises_when_no_oid_appid_or_sub
   - test_get_credentials_password_is_token_string
   - test_get_credentials_expires_at_matches_token_exp
     (build fake token expiring in 3600s, assert
      abs((expires_at - now) - timedelta(hours=1)) < 5s)
   - test_get_credentials_caches_oid_after_first_call
     (verify get_token called twice but jwt.decode called only once)
   - test_get_credentials_wraps_client_authentication_error
   - test_get_credentials_wraps_unexpected_errors
   - test_refresh_safety_window_is_5_minutes
   - test_health_check_returns_true_on_success
   - test_health_check_returns_false_on_failure

4. Run:
   pytest tests/cache/test_azure_entra_provider.py -v
   All tests must pass.

5. Run the full suite:
   pytest tests/ -x -q
   No regressions.

6. Print:
   "P07 complete: EntraManagedIdentityProvider. Tests: <N>. Total suite: <T>."
````

**Expected Output:**
- New file: `okta_agent_proxy/cache/redis_credential_providers/azure_entra.py`
- New file: `tests/cache/test_azure_entra_provider.py` (~16 tests)
- Modified: `pyproject.toml` (azure-identity, azure-core, pyjwt)
- All previous tests passing.

**Commit:** `redis-creds P07: EntraManagedIdentityProvider`

---

## Prompt P08: Wire Factory + Startup Preflight + Audit on Refresh

**Context:** P06 and P07 created provider classes but the factory in `redis_credentials.py` still raises `ValueError` on `aws-iam` and `azure-entra` (it was deliberately set up that way in Phase 1). P08 turns those modes on by registering both new providers in the factory, adds a startup preflight that mints a credential before the readiness probe goes green (catches misconfigured IAM roles or missing Entra grants at deploy time, not first-traffic time), and extends the `/health` endpoint to surface the preflight result.

The preflight matters because the alternative — lazy mint on first Redis call — means a misconfigured cloud identity surfaces as a 5xx to a real user request after rolling deploy completes. Customers doing canary deployments specifically asked for fail-fast at startup.

**Prompt:**

````
Wire the AWS IAM and Entra providers into the credential factory, and add
a startup preflight that mints a credential before the adapter accepts
traffic.

Read first:
- okta_agent_proxy/cache/redis_credentials.py (current factory — only knows 'static')
- okta_agent_proxy/cache/redis_credential_providers/aws_iam.py (P06)
- okta_agent_proxy/cache/redis_credential_providers/azure_entra.py (P07)
- okta_agent_proxy/app.py (find the existing health_check handler around line 2570 and the credential provider construction around line 86)
- tests/cache/test_redis_credential_provider_contract.py (existing factory tests — note test_factory_explicit_aws_iam_raises_valueerror_in_phase_1 will need updating)
- tests/cache/test_redis_credential_provider_compat.py (existing compat matrix — extend, don't rewrite)

Execute the following:

1. Modify okta_agent_proxy/cache/redis_credentials.py.

   Replace the factory body to dispatch on all five mode strings. Keep the
   import-inside-branch pattern from Phase 1 — this avoids loading boto3 /
   azure-identity at startup when they aren't needed:

       def get_redis_credential_provider() -> RedisCredentialProvider:
           import os

           mode = os.environ.get("REDIS_AUTH_MODE", "static").lower().strip()

           if mode == "static":
               from okta_agent_proxy.cache.redis_credential_providers.static import (
                   StaticPasswordProvider,
               )
               return StaticPasswordProvider.from_env()

           if mode == "aws-iam":
               from okta_agent_proxy.cache.redis_credential_providers.aws_iam import (
                   AwsIamElastiCacheProvider,
               )
               return AwsIamElastiCacheProvider.from_env()

           if mode == "azure-entra":
               from okta_agent_proxy.cache.redis_credential_providers.azure_entra import (
                   EntraManagedIdentityProvider,
               )
               return EntraManagedIdentityProvider.from_env()

           raise ValueError(
               f"Unsupported REDIS_AUTH_MODE: {mode!r}. "
               f"Supported: static, aws-iam, azure-entra. "
               f"Phase 3 will add: mtls, vault."
           )

2. Update tests/cache/test_redis_credential_provider_contract.py.

   Find test_factory_explicit_aws_iam_raises_valueerror_in_phase_1.
   Replace it with two tests:

   - test_factory_aws_iam_constructs_provider_when_env_complete
     (Set REDIS_AUTH_MODE=aws-iam plus all required AWS env vars and
      AWS_ACCESS_KEY_ID/SECRET. Mock boto3.session.Session if needed.
      Assert provider.name == "aws-iam".)

   - test_factory_aws_iam_raises_credential_unavailable_when_env_missing
     (REDIS_AUTH_MODE=aws-iam but REDIS_AWS_USER_ID unset.
      Assert raises CredentialUnavailableError.)

   - test_factory_azure_entra_constructs_provider
     (REDIS_AUTH_MODE=azure-entra. Mock the azure-identity import path
      so DefaultAzureCredential / ManagedIdentityCredential don't try to
      contact IMDS. Assert provider.name == "azure-entra".)

   - test_factory_unsupported_mode_lists_phase_3_modes
     (REDIS_AUTH_MODE=mtls → ValueError listing static, aws-iam, azure-entra
      as supported and mtls, vault as Phase 3.)

   Update test_audit_event_types_include_five_new_redis_events to remain
   green (no changes needed; the events were added in P01).

3. Update tests/cache/test_redis_credential_provider_compat.py.

   Add new tests at the end of the file:

   - test_compat_aws_iam_with_complete_env_constructs
     (CACHE_PROVIDER=redis, REDIS_URL set, REDIS_AUTH_MODE=aws-iam,
      REDIS_AWS_USER_ID/CACHE_NAME set, AWS_REGION set, fake AWS creds.
      Mock the boto3 session if needed. Verify CacheService.create_from_env
      builds without error and the wired provider is AwsIamElastiCacheProvider.)

   - test_compat_aws_iam_missing_env_fails_fast
     (REDIS_AUTH_MODE=aws-iam but only REDIS_AWS_USER_ID set →
      CredentialUnavailableError at CacheService.create_from_env.)

   - test_compat_azure_entra_constructs
     (REDIS_AUTH_MODE=azure-entra, mock managed identity. Verify
      EntraManagedIdentityProvider is wired.)

   - test_compat_aws_iam_does_not_require_static_gate
     (Set REDIS_AUTH_MODE=aws-iam and ensure ALLOW_STATIC_REDIS_PASSWORD
      is unset. Verify CacheService.create_from_env succeeds. The static
      gate must NOT block non-static modes.)

4. Verify the existing test_unsupported_auth_mode_lists_supported_modes test
   still passes — its assertion list should now match what the factory raises.
   Update its assertion strings if necessary to match the new error message.

5. Add the startup preflight to app.py.

   The current credential provider construction in app.py (around line 86)
   builds the provider but never calls get_credentials() until the first
   Redis operation. This means a misconfigured IAM role or missing Entra
   grant only surfaces when real traffic hits — which is too late if a
   rolling deploy already routed traffic to the misconfigured pod.

   Add an async preflight function near the top of app.py, AFTER the
   _redis_credential_provider construction block:

       # --- Redis credential preflight (Phase 2) ---
       # Mint a credential at startup to fail fast on misconfigured IAM
       # roles, missing Entra grants, or unreachable IMDS. The result is
       # exposed via the /health endpoint so readiness probes can gate on it.
       _redis_preflight_result: dict = {
           "ok": None,           # None = not yet run, True = passed, False = failed
           "provider": None,
           "principal": None,
           "expires_at": None,
           "error": None,
           "checked_at": None,
       }

       async def _redis_credential_preflight() -> None:
           """Mint a credential once at startup. Records the outcome in
           _redis_preflight_result for /health to surface. Does NOT raise —
           a failed preflight downgrades readiness but doesn't crash the
           process (so operators can still inspect /health and logs)."""
           import datetime as _dt
           if _redis_credential_provider is None:
               # No Redis configured (CACHE_PROVIDER=memory). Preflight is N/A.
               _redis_preflight_result["ok"] = True
               _redis_preflight_result["provider"] = "memory"
               _redis_preflight_result["checked_at"] = _dt.datetime.now(
                   _dt.timezone.utc
               ).isoformat()
               return
           try:
               creds = await _redis_credential_provider.get_credentials()
               _redis_preflight_result.update({
                   "ok": True,
                   "provider": _redis_credential_provider.name,
                   "principal": creds.principal,
                   "expires_at": (
                       creds.expires_at.isoformat() if creds.expires_at else None
                   ),
                   "error": None,
                   "checked_at": _dt.datetime.now(_dt.timezone.utc).isoformat(),
               })
               logger.info(
                   "[redis-preflight] OK provider=%s principal=%s expires=%s",
                   _redis_credential_provider.name,
                   creds.principal,
                   creds.expires_at,
               )
               # Audit the successful preflight as a regular mint event.
               try:
                   from okta_agent_proxy.audit import emit_audit_event
                   from okta_agent_proxy.audit.events import (
                       AuditEventType, AuditSeverity,
                   )
                   await emit_audit_event(
                       AuditEventType.REDIS_CREDENTIAL_MINTED,
                       AuditSeverity.INFO,
                       resource_name="redis",
                       details={
                           "provider": _redis_credential_provider.name,
                           "principal": creds.principal,
                           "preflight": True,
                       },
                       outcome="success",
                   )
               except Exception:
                   pass  # Audit failure must not block startup.
           except Exception as e:
               _redis_preflight_result.update({
                   "ok": False,
                   "provider": _redis_credential_provider.name,
                   "principal": None,
                   "expires_at": None,
                   "error": f"{type(e).__name__}: {e}",
                   "checked_at": _dt.datetime.now(_dt.timezone.utc).isoformat(),
               })
               logger.error(
                   "[redis-preflight] FAILED provider=%s error=%s",
                   _redis_credential_provider.name, e,
               )
               try:
                   from okta_agent_proxy.audit import emit_audit_event
                   from okta_agent_proxy.audit.events import (
                       AuditEventType, AuditSeverity,
                   )
                   await emit_audit_event(
                       AuditEventType.REDIS_CREDENTIAL_REFRESH_FAILED,
                       AuditSeverity.WARNING,
                       resource_name="redis",
                       details={
                           "provider": _redis_credential_provider.name,
                           "preflight": True,
                           "error": f"{type(e).__name__}: {e}",
                       },
                       outcome="failure",
                   )
               except Exception:
                   pass

   Wire the preflight into FastAPI startup. Find the existing startup hook
   (look for `@app.on_event("startup")` or the lifespan context manager
   — your app uses one or the other). Add a call to the preflight:

       # In the startup handler:
       await _redis_credential_preflight()

   If the app uses a lifespan context manager, place the await before
   the yield:

       @asynccontextmanager
       async def lifespan(app):
           # ... existing startup ...
           await _redis_credential_preflight()
           yield
           # ... existing shutdown ...

   Search app.py for `on_event` and `lifespan` to find the right spot.

6. Extend the /health endpoint to surface preflight result.

   Find the existing health_check handler (currently around line 2570 in
   app.py — search for `async def health_check`). It returns a JSON
   response with cache_provider and cache_healthy. Add the preflight
   block to the response:

       async def health_check(request: Request):
           try:
               # ... existing checks (resources_count, agents_count, cache_healthy) ...

               # Redis credential preflight result (Phase 2)
               redis_creds = dict(_redis_preflight_result)  # copy

               # Compute overall readiness: if preflight ran and failed,
               # status is degraded.
               if redis_creds.get("ok") is False:
                   status_value = "degraded"
                   http_status = 503
               else:
                   status_value = "healthy"
                   http_status = 200

               return JSONResponse({
                   "status": status_value,
                   # ... existing fields ...
                   "redis_credentials": redis_creds,
               }, status_code=http_status)
           except Exception as e:
               # ... existing exception path ...

   IMPORTANT: only return 503 when the preflight result is explicitly False.
   If preflight is None (still running) or True (passed), return 200. This
   matches Kubernetes readiness probe semantics — "not ready yet" and
   "ready" both get 200; only "permanently broken" gets 503.

   Note for K8s deployments: the readiness probe should be configured with
   `initialDelaySeconds: 5` and `failureThreshold: 3` to give the
   preflight a fair window before marking the pod unready.

7. Add tests/cache/test_credential_preflight.py:

   - test_preflight_with_memory_cache_marks_ok
     (no _redis_credential_provider — preflight result.ok is True,
      provider is "memory")
   - test_preflight_with_static_provider_marks_ok
     (gate set, password set — preflight succeeds, principal is "static")
   - test_preflight_records_principal_and_expires_at
     (FakeProvider returning known values — assert _redis_preflight_result
      contains them after preflight runs)
   - test_preflight_failure_does_not_raise
     (FakeProvider whose get_credentials raises — assert preflight returns
      normally, _redis_preflight_result.ok is False, error string captured)
   - test_preflight_failure_emits_warning_audit
     (mock emit_audit_event, assert REDIS_CREDENTIAL_REFRESH_FAILED is
      emitted with WARNING severity and preflight: True in details)
   - test_preflight_success_emits_info_audit
     (assert REDIS_CREDENTIAL_MINTED with preflight: True)

   Use a module-level test fixture that patches
   _redis_credential_provider directly. The preflight function imports
   it from app.py module scope — your tests will need to monkeypatch the
   module attribute, e.g.,
       monkeypatch.setattr("okta_agent_proxy.app._redis_credential_provider", fake)

8. Add tests/test_health_endpoint_redis.py (or extend an existing health test):

   - test_health_returns_200_when_preflight_ok
   - test_health_returns_503_when_preflight_failed
   - test_health_returns_200_when_preflight_pending
     (set _redis_preflight_result["ok"] = None, GET /health returns 200
      with status="healthy")
   - test_health_includes_redis_credentials_block

   Use the existing test client fixture (probably in tests/conftest.py or
   a per-test TestClient). If the test scaffolding doesn't exist, follow
   the pattern in tests/test_oauth_discovery.py.

9. Verify the existing test_unsupported_auth_mode_lists_supported_modes test
   still passes.

10. Run:
    pytest tests/cache/test_redis_credential_provider_contract.py \
          tests/cache/test_redis_credential_provider_compat.py \
          tests/cache/test_credential_preflight.py \
          tests/test_health_endpoint_redis.py -v

    All tests must pass.

11. Run the full suite:
    pytest tests/ -x -q
    No regressions.

12. Smoke test the factory:

   # All three modes resolvable from env
   AWS_ACCESS_KEY_ID=AKIAIOSFODNN7EXAMPLE \
   AWS_SECRET_ACCESS_KEY=wJalrXUtnFEMI/K7MDENG/bPxRfiCYEXAMPLEKEY \
   REDIS_AWS_USER_ID=test-user \
   REDIS_AWS_CACHE_NAME=test-cache \
   AWS_REGION=us-west-2 \
   REDIS_AUTH_MODE=aws-iam \
   python -c "from okta_agent_proxy.cache.redis_credentials import get_redis_credential_provider; print(get_redis_credential_provider().name)"
   # Expect: aws-iam

   REDIS_AUTH_MODE=azure-entra \
   REDIS_AZURE_USE_MSI=false \
   python -c "from okta_agent_proxy.cache.redis_credentials import get_redis_credential_provider; print(get_redis_credential_provider().name)"
   # Expect: azure-entra (no IMDS contact required to construct;
   # only get_credentials() would fail without credentials)

   ALLOW_STATIC_REDIS_PASSWORD=true \
   python -c "from okta_agent_proxy.cache.redis_credentials import get_redis_credential_provider; print(get_redis_credential_provider().name)"
   # Expect: static

13. Print:
    "P08 complete: factory dispatches static / aws-iam / azure-entra,
     startup preflight wired, /health surfaces preflight result.
     Updated tests: <N>. Total suite: <T>."
````

**Expected Output:**
- Modified: `okta_agent_proxy/cache/redis_credentials.py` (factory dispatch)
- Modified: `okta_agent_proxy/app.py` (preflight + health endpoint)
- Modified: `tests/cache/test_redis_credential_provider_contract.py` (+4, -1)
- Modified: `tests/cache/test_redis_credential_provider_compat.py` (+4)
- New file: `tests/cache/test_credential_preflight.py` (~6 tests)
- New file: `tests/test_health_endpoint_redis.py` (~4 tests)
- Smoke tests confirm all three modes construct.

**Commit:** `redis-creds P08: factory + startup preflight + /health surface`

---

## Prompt P09: AWS ECS Terraform — Switch to IAM Auth

**Context:** This prompt removes the static-password machinery from `deploy/aws-ecs/main.tf` and adds the ElastiCache user with IAM authentication. After this prompt, the AWS reference deployment has no shared secret of any kind for Redis access.

The diff is significant. Phase 1 added the gate flag in two env entries; Phase 2 deletes those, removes the random password resource, removes the Secrets Manager block for Redis, adds the ElastiCache IAM user, attaches the connect policy, and replaces the env vars with the new mode + identity hints.

**Prompt:**

````
Switch the AWS ECS Terraform from static-password Redis auth to ElastiCache IAM.

Read first:
- deploy/aws-ecs/main.tf (sections to modify):
  * lines ~395-405: random_password.redis_password resource + tracking comment
  * lines ~607-650: aws_elasticache_replication_group / serverless_cache resources
  * lines ~620-635: replication group's auth_token usage (if non-serverless)
  * lines ~683-705: aws_secretsmanager_secret.redis + _version blocks
  * lines ~853-880: aws_iam_role.ecs_task and existing inline policies
  * lines ~970-1020: adapter task definition environment + secrets blocks
- deploy/aws-ecs/README.md (Phase-1 note section to update for Phase 2)
- okta_agent_proxy/cache/redis_credential_providers/aws_iam.py (env var names — REDIS_AWS_USER_ID, REDIS_AWS_CACHE_NAME, REDIS_AWS_SERVERLESS, AWS_REGION)
- okta_agent_proxy/cache/cache_service.py (REDIS_URL still used to find the host even when auth is IAM)

Execute the following:

1. Add new Terraform variables.

   In deploy/aws-ecs/variables.tf (or main.tf if variables are inline), add:

       variable "redis_iam_user_id" {
         description = "ElastiCache user ID for IAM authentication. Must match the IAM user created below."
         type        = string
         default     = "okta-mcp-adapter"
       }

   No new variable needed for cache name — we already build the endpoint from
   the cluster/serverless cache name (local.redis_endpoint at line ~59).

2. Remove the static-password resources from main.tf.

   Delete:
   - The random_password.redis_password resource (~line 396)
   - The tracking comment block immediately above it (added in P05)
   - The aws_secretsmanager_secret.redis resource (~line 683)
   - The aws_secretsmanager_secret_version.redis resource (~line 696)

   Modify the local.redis_url definition. The current form (line ~62) is:

       redis_url = "rediss://:${random_password.redis_password.result}@${local.redis_endpoint}:6379/0"

   Change it to a no-credentials URL — IAM auth supplies credentials at
   connection time:

       redis_url = "rediss://${local.redis_endpoint}:6379/0"

3. Remove auth_token from the ElastiCache cluster (non-serverless path).

   Find aws_elasticache_replication_group.main (~line 616). It has:

       auth_token                 = random_password.redis_password.result

   This must be removed. Self-designed replication groups with IAM
   authentication enabled cannot have an auth_token. Replace the auth_token
   line and any related lines with:

       transit_encryption_enabled = true   # required for IAM auth
       # auth_token removed — IAM authentication is enabled via ElastiCache user

   For aws_elasticache_serverless_cache.main (~line 646), check whether
   any user_group_id or auth-token-equivalent setting needs updating. The
   user group association is set in step 4.

4. Add the IAM-enabled ElastiCache user and user group.

   Add (anywhere logical, near the existing ElastiCache resources around
   line ~610):

       resource "aws_elasticache_user" "adapter" {
         user_id       = var.redis_iam_user_id
         user_name     = var.redis_iam_user_id
         engine        = "REDIS"

         authentication_mode {
           type = "iam"
         }

         access_string = "on ~* +@all"

         tags = local.common_tags
       }

       resource "aws_elasticache_user_group" "adapter" {
         engine        = "REDIS"
         user_group_id = "${local.project_name}-adapter"
         user_ids      = [aws_elasticache_user.adapter.user_id, "default"]

         tags = local.common_tags

         lifecycle {
           ignore_changes = [user_ids]
         }
       }

   Wire the user group into the ElastiCache cluster:

   - For aws_elasticache_serverless_cache.main, add:
       user_group_id = aws_elasticache_user_group.adapter.user_group_id
       (Inside the resource block. Some AWS provider versions name this
       differently — check provider docs if `terraform validate` complains.)

   - For aws_elasticache_replication_group.main, add:
       user_group_ids = [aws_elasticache_user_group.adapter.user_group_id]

   Note: ElastiCache requires the "default" user be present in any user
   group, hence including it above.

5. Attach the elasticache:Connect policy to the ECS task role.

   Find aws_iam_role.ecs_task (~line 853). Add a new inline policy:

       resource "aws_iam_role_policy" "ecs_task_elasticache_iam" {
         name = "${local.project_name}-elasticache-iam"
         role = aws_iam_role.ecs_task.id

         policy = jsonencode({
           Version = "2012-10-17"
           Statement = [{
             Effect = "Allow"
             Action = "elasticache:Connect"
             Resource = local.is_serverless ? [
               # Serverless: cache and user are addressed individually
               aws_elasticache_serverless_cache.main[0].arn,
               aws_elasticache_user.adapter.arn,
             ] : [
               # Self-designed: replication group plus user
               aws_elasticache_replication_group.main[0].arn,
               aws_elasticache_user.adapter.arn,
             ]
           }]
         })
       }

   If local.is_serverless does not exist, create it near other locals
   (~line 50):

       is_serverless = var.elasticache_mode == "serverless"

   (or whatever the existing variable is — check variables.tf for the
   existing toggle between serverless and self-designed.)

6. Update the adapter task definition env block (~line 998).

   Remove these two entries (added in P05):
       { name = "REDIS_AUTH_MODE", value = "static" },
       { name = "ALLOW_STATIC_REDIS_PASSWORD", value = "true" },

   Replace with:

       # --- Redis credential provider (Phase 2) ---
       # IAM authentication: no shared secret. The task role's
       # elasticache:Connect permission (see ecs_task_elasticache_iam policy)
       # authorizes this task to mint short-lived AUTH tokens at connect time.
       { name = "REDIS_AUTH_MODE", value = "aws-iam" },
       { name = "REDIS_AWS_USER_ID", value = var.redis_iam_user_id },
       { name = "REDIS_AWS_CACHE_NAME", value = local.redis_endpoint },
       { name = "REDIS_AWS_SERVERLESS", value = local.is_serverless ? "true" : "false" },
       { name = "AWS_REGION", value = var.aws_region },

   Remove the two REDIS_PASSWORD references from the secrets block:
       { name = "REDIS_URL", valueFrom = "${aws_secretsmanager_secret.redis.arn}:REDIS_URL::" },
       { name = "REDIS_PASSWORD", valueFrom = "${aws_secretsmanager_secret.redis.arn}:REDIS_PASSWORD::" },

   The REDIS_URL still needs to flow to the adapter — but now it carries no
   password. Replace the secret-sourced REDIS_URL with a plain env entry:

       { name = "REDIS_URL", value = local.redis_url },

   And drop the entire REDIS_PASSWORD line.

7. Update the deploy server task definition (~line 1054 area) similarly if it
   also consumes REDIS_URL or REDIS_PASSWORD. Check by grepping for
   REDIS_PASSWORD in the file — there should be zero remaining references
   after this prompt.

8. Update deploy/aws-ecs/README.md.

   Replace the existing "Phase 1 Note" section with a "Phase 2: IAM
   authentication" section:

       ## Redis Authentication: ElastiCache IAM

       This deployment uses ElastiCache IAM authentication. The ECS task
       role is granted `elasticache:Connect` permission against the cache
       and the adapter's IAM-enabled ElastiCache user. At connection time,
       the adapter's `aws-iam` Redis credential provider mints a SigV4-
       signed token (15-minute TTL) and presents it as the Redis AUTH
       password.

       **No shared secret exists for Redis access** — there is no random
       password resource, no Secrets Manager entry for `REDIS_PASSWORD`,
       no `auth_token` on the cluster, and no static-password gate flag.
       Customer security review will see only the IAM permission grant and
       the user/user-group resources.

       ### Resources involved

       | Terraform resource                              | Purpose                              |
       | ----------------------------------------------- | ------------------------------------ |
       | aws_elasticache_user.adapter                    | IAM-authenticated ElastiCache user   |
       | aws_elasticache_user_group.adapter              | User group attached to the cache     |
       | aws_iam_role_policy.ecs_task_elasticache_iam    | Grants elasticache:Connect to tasks  |

       ### Auditability

       Every credential mint emits a `redis.credential.minted` audit event
       with the IAM principal in the `principal` field. Every scheduled
       refresh emits `redis.credential.refresh.success` (or `.failed`).
       Search the adapter audit stream for these event types to confirm
       cred lifecycle activity.

       ### Migrating from Phase 1

       If upgrading from a Phase-1 deployment that used static passwords:
       1. Apply the new Terraform — the `aws_elasticache_user`,
          `aws_elasticache_user_group`, and IAM policy attach to existing
          resources without disruption.
       2. The next ECS deployment picks up the new task definition.
          New tasks come up with IAM auth before old static-auth tasks
          drain.
       3. Once all tasks are on the new revision, the old
          `random_password.redis_password` and `aws_secretsmanager_secret.redis`
          resources are gone (Terraform plan should show "destroy" for
          these — confirm before applying).

9. Validate Terraform.

   cd deploy/aws-ecs
   terraform fmt -check
   terraform init -backend=false
   terraform validate

   All must succeed. Common errors to expect and fix:
   - Reference to undefined attribute on serverless cache: AWS provider
     versions vary on whether it's `user_group_id` or `user_group_ids`.
     Check the version in versions.tf and adjust.
   - Missing `is_serverless` local: define it in step 5 if not already
     present.

10. Print:
    "P09 complete: AWS ECS Terraform now uses ElastiCache IAM auth.
     Removed: random_password.redis_password, aws_secretsmanager_secret.redis (×2).
     Added: aws_elasticache_user.adapter, aws_elasticache_user_group.adapter,
     ecs_task_elasticache_iam inline policy.
     Task env: REDIS_AUTH_MODE=aws-iam, REDIS_AWS_USER_ID/CACHE_NAME/SERVERLESS,
     AWS_REGION. No REDIS_PASSWORD references remain in main.tf."
````

**Expected Output:**
- Modified: `deploy/aws-ecs/main.tf` (substantial — ~30 lines removed, ~40 added)
- Modified: `deploy/aws-ecs/variables.tf` (one new variable)
- Modified: `deploy/aws-ecs/README.md`
- Terraform validates.

**Commit:** `redis-creds P09: AWS ECS Terraform switches to ElastiCache IAM`

---

## Prompt P10: Azure ACA Bicep — Switch to Entra Managed Identity

**Context:** Removes the access-key-based Redis URL from `acasetup.sh` and `apps.bicep`, configures the Azure Managed Redis (or Azure Cache for Redis with Entra) to grant the existing User-Assigned Managed Identity (UAMI) data-access, and updates the adapter env to use `azure-entra` mode. The adapter already has UAMI wiring from Phase 1 — Phase 2 just adds the Redis access policy and switches modes.

**Prompt:**

````
Switch Azure ACA Bicep from access-key Redis auth to Entra Managed Identity.

Read first:
- deploy/azure-aca/bicep/main.bicep (orchestrator — note `uamiPrincipalId` output at ~line 479; this is the Object ID we grant Redis access to)
- deploy/azure-aca/bicep/modules/identity.bicep (UAMI definition; `principalId` output)
- deploy/azure-aca/bicep/modules/apps.bicep (adapter container env array at ~line 158-180; REDIS_AUTH_MODE/ALLOW_STATIC_REDIS_PASSWORD added in P05)
- deploy/azure-aca/acasetup.sh (Redis provisioning at ~line 440-505; az redis list-keys at line 497; Bicep parameters block at ~line 956-985)
- okta_agent_proxy/cache/redis_credential_providers/azure_entra.py (env var names — REDIS_AZURE_USE_MSI, REDIS_AZURE_CLIENT_ID, REDIS_AZURE_PRINCIPAL_OID)
- deploy/azure-aca/README.md (Phase-1 note to update)

CRITICAL: This prompt assumes the deployment provisions Azure Cache for
Redis (the Standard/Premium SKU created by `az redis create`). Entra ID
authentication requires Standard or Premium SKU. If the deployment is on
Basic SKU, this prompt cannot complete — Basic does not support Entra.
Phase 1 uses C0 (Basic) by default, so we must also upgrade the SKU.

Execute the following:

1. Update Redis SKU in acasetup.sh.

   Find the redis_sku selection (~line 441-445):

       REDIS_SKU="Basic"   # or Standard, depending on environment

   Force Standard SKU when Entra is required:

       # Phase 2: Standard SKU is required for Entra ID authentication.
       # Basic SKU does not support Entra; upgrade or use Azure Managed
       # Redis (preview, deployed separately).
       if [[ "${REDIS_AUTH_MODE:-azure-entra}" == "azure-entra" ]]; then
         REDIS_SKU="Standard"
       fi

   Add a corresponding `--enable-non-ssl-port false` and any other Standard-
   tier flags as needed. Verify by running `az redis create --help` for the
   Standard tier requirements.

2. Enable Entra authentication on the Redis cache.

   In acasetup.sh, after the `az redis create` block (~line 460-470),
   add a step to enable Entra:

       # Step 1.7c: Enable Entra ID authentication on Redis (Phase 2)
       info "Step 1.7c: Enabling Entra ID authentication on $REDIS_NAME..."
       az redis update -g "$AZURE_RG" -n "$REDIS_NAME" \
         --set "redisConfiguration.aad-enabled=true" \
         --output none
       ok "Entra ID authentication enabled"

   Then assign the Data Owner role to the UAMI:

       # Step 1.7d: Grant the UAMI 'Data Owner' access on Redis
       info "Step 1.7d: Granting UAMI Redis Data Owner access..."
       UAMI_PRINCIPAL_ID="$(az identity show -g "$AZURE_RG" -n "$UAMI_NAME" \
         --query principalId -o tsv)"
       REDIS_RESOURCE_ID="$(az redis show -g "$AZURE_RG" -n "$REDIS_NAME" \
         --query id -o tsv)"

       # Use the well-known role definition ID for Redis Cache Data Owner.
       REDIS_DATA_OWNER_ROLE_ID="3df8b902-2a6f-47c7-8cc5-360e9b272a7e"

       az redis access-policy-assignment create \
         -g "$AZURE_RG" -n "$REDIS_NAME" \
         --access-policy-name "Data Owner" \
         --object-id "$UAMI_PRINCIPAL_ID" \
         --object-id-alias "okta-mcp-adapter-uami" \
         --policy-assignment-name "okta-mcp-adapter-data-owner" \
         --output none
       ok "UAMI granted Redis Data Owner access"

       save_state UAMI_PRINCIPAL_ID "$UAMI_PRINCIPAL_ID"

   Note: the `az redis access-policy-assignment` command may require a
   recent Azure CLI version. If the deployment environment uses an older
   CLI, fall back to:

       az role assignment create \
         --role "Redis Cache Data Owner" \
         --assignee-object-id "$UAMI_PRINCIPAL_ID" \
         --assignee-principal-type ServicePrincipal \
         --scope "$REDIS_RESOURCE_ID"

3. Stop computing the access-key-embedded REDIS_URL.

   Find the REDIS_URL build block (~line 496-502):

       # Build REDIS_URL
       REDIS_KEY="$(az redis list-keys -g "$AZURE_RG" -n "$REDIS_NAME" \
         --query primaryKey -o tsv)"
       REDIS_FQDN="${REDIS_NAME}.redis.cache.windows.net"
       save_state REDIS_FQDN "$REDIS_FQDN"
       REDIS_URL="rediss://:${REDIS_KEY}@${REDIS_FQDN}:6380/0"
       save_state REDIS_URL "$REDIS_URL"

   Replace with:

       # Phase 2: REDIS_URL no longer carries an access key.
       # The adapter's azure-entra credential provider supplies AUTH at
       # connect time using the UAMI's Entra token.
       REDIS_FQDN="${REDIS_NAME}.redis.cache.windows.net"
       save_state REDIS_FQDN "$REDIS_FQDN"
       REDIS_URL="rediss://${REDIS_FQDN}:6380/0"
       save_state REDIS_URL "$REDIS_URL"

   Add a new state save for the UAMI client_id (used by ManagedIdentityCredential):

       UAMI_CLIENT_ID="$(az identity show -g "$AZURE_RG" -n "$UAMI_NAME" \
         --query clientId -o tsv)"
       save_state UAMI_CLIENT_ID "$UAMI_CLIENT_ID"

4. Update the Bicep parameters block in acasetup.sh (~line 956-985).

   Add a new parameter line after `redisUrl`:

       "uamiClientId": { "value": "$UAMI_CLIENT_ID" },

   And in the deploy_state file load (~line 750-765), add UAMI_CLIENT_ID to
   the list of state values pulled in.

5. Update deploy/azure-aca/bicep/modules/apps.bicep.

   Add a new param near the other params (~line 20):

       param uamiClientId string

   In the adapter container env array (~line 158-180), remove the two
   Phase-1 lines:

       { name: 'REDIS_AUTH_MODE', value: 'static' }
       { name: 'ALLOW_STATIC_REDIS_PASSWORD', value: 'true' }

   Replace with:

       // --- Redis credential provider (Phase 2) ---
       // Entra ID authentication via the UAMI. No access key, no shared
       // secret. The container app's identity (uamiClientId) acquires
       // an Entra token for the redis.azure.com scope at connect time.
       { name: 'REDIS_AUTH_MODE', value: 'azure-entra' }
       { name: 'REDIS_AZURE_USE_MSI', value: 'true' }
       { name: 'REDIS_AZURE_CLIENT_ID', value: uamiClientId }

   Note: The redis-url secretRef stays — REDIS_URL is still needed (the
   adapter parses host and port from it), it just no longer carries
   credentials.

6. Update deploy/azure-aca/bicep/main.bicep to pass uamiClientId through.

   Find the existing UAMI module call around line 320 (where principalId is
   referenced). The UAMI module already exposes principalId; we now also
   need clientId. In modules/identity.bicep, ensure clientId is exported:

       output clientId string = byoUami ? uamiRef.properties.clientId : uami.properties.clientId

   In main.bicep, where apps.bicep is called (~line 408), pass the new param:

       module apps 'modules/apps.bicep' = {
         name: 'apps'
         params: {
           // ... existing params ...
           uamiPrincipalId: identity.outputs.principalId
           uamiClientId: identity.outputs.clientId
         }
       }

7. Update deploy/azure-aca/README.md.

   Replace the Phase 1 Note section with:

       ## Redis Authentication: Entra Managed Identity

       This deployment uses Microsoft Entra ID authentication for Azure
       Cache for Redis (Standard SKU). The Container App's User-Assigned
       Managed Identity (UAMI) is granted the "Redis Cache Data Owner"
       role on the cache. At connection time, the adapter's `azure-entra`
       credential provider acquires an access token for the
       `redis.azure.com/.default` scope and presents it as the Redis
       AUTH password (with the UAMI's Object ID as the username).

       **No shared secret exists for Redis access** — there is no
       `az redis list-keys` call, the access key is not embedded in
       `REDIS_URL`, and the adapter does not store any Redis credential.

       ### Resources involved

       | Resource                                | Purpose                                  |
       | --------------------------------------- | ---------------------------------------- |
       | UAMI (existing, from Phase 1 deploy)    | Adapter's workload identity              |
       | redisConfiguration.aad-enabled = true   | Enables Entra auth on the cache          |
       | RBAC: Redis Cache Data Owner role       | Grants the UAMI data access on the cache |

       ### Auditability

       Every credential mint emits a `redis.credential.minted` audit event
       with the UAMI's Object ID in the `principal` field. Token refreshes
       (every ~55 minutes) emit `redis.credential.refresh.success`.

       ### Tier requirements

       Entra ID authentication for Azure Cache for Redis requires
       **Standard or Premium SKU**. Basic SKU is not supported. The
       acasetup.sh script forces Standard SKU when REDIS_AUTH_MODE is
       azure-entra. If you must use Basic SKU, fall back to Phase-1
       static-password mode (see git history for the Phase 1 README).

       Azure Managed Redis (a separate product, currently in preview as
       of mid-2026) supports Entra by default and is the recommended
       target once GA.

8. Validate Bicep.

   cd deploy/azure-aca
   az bicep build --file bicep/main.bicep --stdout > /dev/null

   If the CLI is missing, document this and proceed.

9. Print:
   "P10 complete: Azure ACA Bicep now uses Entra ID auth.
    Removed: az redis list-keys, REDIS_KEY embedding in REDIS_URL,
    Phase-1 ALLOW_STATIC_REDIS_PASSWORD env entry.
    Added: redis access-policy-assignment to UAMI,
    aad-enabled=true on cache, REDIS_AUTH_MODE=azure-entra +
    REDIS_AZURE_USE_MSI/CLIENT_ID env entries.
    SKU forced to Standard. Bicep validates."
````

**Expected Output:**
- Modified: `deploy/azure-aca/bicep/modules/apps.bicep`
- Modified: `deploy/azure-aca/bicep/modules/identity.bicep` (add clientId output if missing)
- Modified: `deploy/azure-aca/bicep/main.bicep` (thread uamiClientId)
- Modified: `deploy/azure-aca/acasetup.sh` (Entra enable + RBAC + URL build)
- Modified: `deploy/azure-aca/README.md`

**Commit:** `redis-creds P10: Azure ACA Bicep switches to Entra Managed Identity`

---

## Prompt P11: Audit Stream Enrichment for Credential Observability

**Context:** Customers running their own SIEM (Splunk via the existing webhook sink, or Loki via `deploy/observability/`) want credential-lifecycle visibility in the same observability lane as everything else. Phase 1 mint audits and Phase 2 refresh audits already carry most of this — this prompt closes the gap with two small enrichments so customers can build their own dashboards without joining events.

**No new endpoints, no new dependencies, no new authentication surface.** The deliverable is field richness on existing events.

**Why this instead of Prometheus:**

A second observability lane (Prometheus `/metrics`) means a second set of access controls, a second scrape configuration, and a second mental model for "where do I see what the adapter is doing?". Customers already get the audit stream piped to Splunk HEC or Loki via `AUDIT_SINKS=webhook` (Phase 1 SIEM streaming). The audit stream answers "what happened?" *and* "is it healthy?" if the events are rich enough. This prompt makes them rich enough.

**The four signals customers asked for, in audit-query form:**

| Signal                     | Source event(s)                                                | Query shape                                            |
| -------------------------- | -------------------------------------------------------------- | ------------------------------------------------------ |
| Mints per provider         | `redis.credential.minted`                                      | count by `details.provider`                            |
| Refresh outcome rate       | `redis.credential.refresh.success`/`.failed`                   | count by `details.provider`, event_type               |
| Time-to-expiry (real-time) | latest `redis.credential.minted` (or refresh.success)          | `details.expires_at - now()`                          |
| Preflight status           | `redis.credential.minted` with `details.preflight=true`        | latest, group by `details.provider`                   |

**Prompt:**

````
Enrich Redis credential audit events so customers can build SIEM dashboards
without event joins. No new endpoints, no new dependencies.

Read first:
- okta_agent_proxy/cache/redis_provider.py (specifically _emit_mint_audit and
  _emit_refresh_audit — already emit on every mint and refresh)
- okta_agent_proxy/app.py (the _redis_credential_preflight added in P08 —
  emits REDIS_CREDENTIAL_MINTED with preflight=true)
- tests/cache/test_redis_provider_with_credential_provider.py (existing
  audit assertion patterns — extend, don't rewrite)
- okta_agent_proxy/audit/__init__.py (emit_audit_event signature; do NOT
  add new fields beyond the existing details dict)

Execute the following:

1. Enrich _emit_refresh_audit in okta_agent_proxy/cache/redis_provider.py.

   The current refresh audit (added in P06) carries only {"provider": ...}
   on success and {"provider": ..., "error": ...} on failure. To let
   customers compute time-to-expiry from the refresh event directly
   (without joining the next mint event), add the new credential's
   expires_at to the success path.

   Modify the _scheduled_refresh method's success branch. The current code
   pops the cached client and emits the audit. Before emitting, query the
   provider once more for the FRESH credential's expiry — but do NOT
   build a real Redis client (that's the next _get_redis() call's job).
   This single extra get_credentials() call costs nothing for AWS IAM
   (local SigV4 sign) and one round-trip for Entra (cached after the
   azure-identity SDK's internal cache).

   Replace the success-path block:

       client = self._clients.pop(loop_id, None)
       self._minted_loops.discard(loop_id)
       self._refresh_tasks.pop(loop_id, None)
       if client is not None:
           try:
               await client.aclose()
           except Exception as e:
               logger.warning(...)
       await self._emit_refresh_audit(provider, success=True)

   With:

       client = self._clients.pop(loop_id, None)
       self._minted_loops.discard(loop_id)
       self._refresh_tasks.pop(loop_id, None)
       if client is not None:
           try:
               await client.aclose()
           except Exception as e:
               logger.warning(...)

       # Peek at the new credential's expiry for the audit event so SIEM
       # consumers can compute time-to-expiry without joining events.
       new_expires_at = None
       new_principal = None
       try:
           peek = await provider.get_credentials()
           new_expires_at = peek.expires_at
           new_principal = peek.principal
       except Exception:
           # Don't fail the refresh on a peek failure — the next
           # _get_redis() will surface the real error if it persists.
           pass
       await self._emit_refresh_audit(
           provider, success=True,
           new_expires_at=new_expires_at,
           new_principal=new_principal,
       )

   Update _emit_refresh_audit's signature and body:

       async def _emit_refresh_audit(
           self,
           provider,
           success: bool,
           error: Optional[str] = None,
           new_expires_at: Optional[datetime.datetime] = None,
           new_principal: Optional[str] = None,
       ):
           try:
               from okta_agent_proxy.audit import emit_audit_event
               from okta_agent_proxy.audit.events import AuditEventType, AuditSeverity
               event_type = (
                   AuditEventType.REDIS_CREDENTIAL_REFRESH_SUCCESS if success
                   else AuditEventType.REDIS_CREDENTIAL_REFRESH_FAILED
               )
               severity = AuditSeverity.INFO if success else AuditSeverity.WARNING
               details = {"provider": provider.name}
               if error:
                   details["error"] = error
               if new_expires_at is not None:
                   details["expires_at"] = new_expires_at.isoformat()
                   # Pre-computed seconds-until-expiry as a float — avoids
                   # the SIEM having to parse ISO timestamps to compute
                   # this for alerting.
                   import datetime as _dt
                   now = _dt.datetime.now(_dt.timezone.utc)
                   if new_expires_at.tzinfo is None:
                       new_expires_at = new_expires_at.replace(tzinfo=_dt.timezone.utc)
                   details["expires_in_seconds"] = (new_expires_at - now).total_seconds()
               if new_principal is not None:
                   details["principal"] = new_principal
               await emit_audit_event(
                   event_type, severity,
                   resource_name="redis", details=details,
                   outcome="success" if success else "failure",
               )
           except Exception as e:
               logger.warning(f"[redis-creds] refresh audit emission failed: {e}")

2. Enrich _emit_mint_audit in okta_agent_proxy/cache/redis_provider.py.

   The mint audit already carries `expires_at` (from P03). Add the same
   `expires_in_seconds` pre-computed field for query simplicity. This is
   purely additive — existing consumers of `expires_at` continue to work.

   In _emit_mint_audit, modify the details dict:

       details = {
           "provider": self._credential_provider.name,
           "principal": creds.principal,
           "expires_at": creds.expires_at.isoformat() if creds.expires_at else None,
           "username_set": creds.username is not None,
       }
       # NEW: pre-computed seconds-until-expiry for SIEM alerting.
       if creds.expires_at is not None:
           import datetime as _dt
           now = _dt.datetime.now(_dt.timezone.utc)
           expires_at = creds.expires_at
           if expires_at.tzinfo is None:
               expires_at = expires_at.replace(tzinfo=_dt.timezone.utc)
           details["expires_in_seconds"] = (expires_at - now).total_seconds()

3. Enrich the preflight audit in app.py (added in P08).

   The success branch of _redis_credential_preflight emits
   REDIS_CREDENTIAL_MINTED with `preflight: true`. Add `expires_in_seconds`
   for the same alerting reason. Find the success-path emit_audit_event
   call and update its details dict:

       details={
           "provider": _redis_credential_provider.name,
           "principal": creds.principal,
           "preflight": True,
           "expires_at": (
               creds.expires_at.isoformat() if creds.expires_at else None
           ),
       }
       # Add expires_in_seconds when expiring
       if creds.expires_at is not None:
           import datetime as _dt
           now = _dt.datetime.now(_dt.timezone.utc)
           expires_at = creds.expires_at
           if expires_at.tzinfo is None:
               expires_at = expires_at.replace(tzinfo=_dt.timezone.utc)
           details["expires_in_seconds"] = (expires_at - now).total_seconds()

4. Update tests/cache/test_redis_provider_with_credential_provider.py.

   Find the existing test that asserts REDIS_CREDENTIAL_MINTED is emitted
   with provider/principal/expires_at. Add an assertion for
   expires_in_seconds:

       def test_redis_provider_mint_audit_includes_expires_in_seconds(...):
           # Set up a FakeProvider returning expires_at = now + 900s
           # Trigger _get_redis()
           # Capture the emit_audit_event call
           details = captured["details"]
           assert "expires_in_seconds" in details
           assert 890 < details["expires_in_seconds"] < 910

       def test_redis_provider_mint_audit_omits_expires_in_seconds_for_static(...):
           # FakeProvider with expires_at=None
           details = captured["details"]
           assert "expires_in_seconds" not in details

5. Add tests in tests/cache/test_redis_provider_scheduled_refresh.py
   (created in P06):

   - test_refresh_success_audit_includes_new_expires_at
     (FakeExpiringProvider returns creds expiring in 30s, then on second
      get_credentials returns creds expiring in 900s. Verify
      REDIS_CREDENTIAL_REFRESH_SUCCESS event details.expires_at matches
      the second credential.)
   - test_refresh_success_audit_includes_new_principal
   - test_refresh_success_audit_includes_expires_in_seconds
   - test_refresh_peek_failure_does_not_fail_refresh
     (FakeExpiringProvider whose second get_credentials raises. Verify
      the refresh task completes successfully — refresh_audit is emitted
      with success=True but without new_expires_at/new_principal/expires_in_seconds.)
   - test_refresh_failure_audit_omits_expires_fields
     (refresh that fails entirely — REDIS_CREDENTIAL_REFRESH_FAILED has
      provider+error but NO expires_at, expires_in_seconds, or principal.)

6. Update tests/cache/test_credential_preflight.py (created in P08):

   - test_preflight_success_audit_includes_expires_in_seconds
   - test_preflight_static_provider_omits_expires_in_seconds
     (StaticProvider has expires_at=None — preflight succeeds, audit has
      preflight: true but NO expires_in_seconds)

7. Run:
   pytest tests/cache/ -v
   All cache tests must pass — the new assertions are additive.

8. Run the full suite:
   pytest tests/ -x -q
   No regressions.

9. Smoke test the audit stream.

   Spin up the dev stack and trigger a static-mode mint. The static
   provider has expires_at=None, so expires_in_seconds should be ABSENT
   from the audit details (verifying the conditional include works):

       docker-compose up -d adapter redis
       sleep 5
       # Trigger a Redis call so the mint audit fires
       curl -sf http://localhost:8000/health > /dev/null
       # Inspect the audit log for the mint event
       docker-compose logs adapter | grep "redis.credential.minted" | tail -1

   The log line for the static-mode mint should NOT contain
   "expires_in_seconds" — only static is non-expiring, so this is the
   only mode where the field is omitted. For aws-iam or azure-entra in a
   real deployment, the field will be present with a value around 900
   (15 min) or 3600 (1 hr) respectively.

10. Print:
    "P11 complete: audit events enriched for SIEM observability.
     Added details.expires_in_seconds (mints + refreshes + preflight),
     details.expires_at on refresh.success (was missing),
     details.principal on refresh.success (was missing).
     No new endpoints, no new dependencies.
     Tests: <N>. Total suite: <T>."
````

**Expected Output:**
- Modified: `okta_agent_proxy/cache/redis_provider.py` (mint + refresh audit field additions)
- Modified: `okta_agent_proxy/app.py` (preflight audit field additions)
- Modified: `tests/cache/test_redis_provider_with_credential_provider.py` (+2 tests)
- Modified: `tests/cache/test_redis_provider_scheduled_refresh.py` (+5 tests)
- Modified: `tests/cache/test_credential_preflight.py` (+2 tests)
- All previous tests still passing.

**Commit:** `redis-creds P11: enrich credential audit events for SIEM consumers`

---

## Prompt P12: Documentation + Security-Review Deliverables

**Context:** Phase 2 closes by updating customer-facing documentation, the developer-facing CLAUDE.md, and the .env.example to reflect that production auth modes are now real and the static path is local-dev-only. This is the prompt that produces the artifacts you attach to a customer security review.

**Prompt:**

````
Finalize Phase 2 with documentation updates.

Read first:
- .env.example (Phase 1 form — REDIS_AUTH_MODE=static commented out)
- CLAUDE.md (Phase 1 "Redis Credential Providers" section)
- README.md (Phase 1 quick reference)
- deploy/aws-ecs/README.md (P09 update)
- deploy/azure-aca/README.md (P10 update)

Execute the following:

1. Update .env.example.

   Replace the REDIS section to mark static as dev-only and document the
   two real production modes:

       # ============================================================
       # REDIS / VALKEY CREDENTIAL PROVIDER
       # ============================================================
       # Cache provider: 'redis' (default, matches docker-compose) or 'memory'.
       CACHE_PROVIDER=redis

       # Redis connection URL — host and port only when REDIS_AUTH_MODE
       # is aws-iam, azure-entra, mtls, or vault. For static (local dev),
       # the password may be embedded in the URL OR set via REDIS_PASSWORD.
       REDIS_URL=redis://:${REDIS_PASSWORD:-redis-secret}@redis:6379/0

       REDIS_KEY_PREFIX=okta-mcp:
       REDIS_TLS_ENABLED=false

       # ------------------------------------------------------------
       # Auth mode: static | aws-iam | azure-entra | mtls | vault
       # ------------------------------------------------------------
       # static (local dev only — requires the gate flag below)
       # aws-iam: AWS ElastiCache for Redis 7+ or Valkey
       # azure-entra: Azure Managed Redis or Cache for Redis Std+ with Entra
       # mtls / vault: Phase 3 (not yet implemented)
       REDIS_AUTH_MODE=static

       # Static mode (DEV ONLY — production deployments must NOT set this)
       ALLOW_STATIC_REDIS_PASSWORD=true
       REDIS_PASSWORD=redis-secret
       # REDIS_USERNAME=

       # AWS IAM mode (no shared secret)
       # REDIS_AWS_USER_ID=okta-mcp-adapter
       # REDIS_AWS_CACHE_NAME=my-elasticache-name
       # REDIS_AWS_SERVERLESS=true
       # AWS_REGION=us-west-2

       # Azure Entra mode (no shared secret)
       # REDIS_AZURE_USE_MSI=true
       # REDIS_AZURE_CLIENT_ID=<UAMI clientId, optional for system-assigned MI>
       # REDIS_AZURE_PRINCIPAL_OID=<override; otherwise read from token>

2. Replace the "Redis Credential Providers" section in CLAUDE.md.

   Update the section to reflect Phase 2 maturity:

       ## Redis Credential Providers

       The adapter authenticates to Redis through a pluggable credential
       provider in `okta_agent_proxy/cache/redis_credentials.py`. As of
       Phase 2, three providers are implemented:

       | Mode          | Module                                        | Lifetime  | Refresh    |
       | ------------- | --------------------------------------------- | --------- | ---------- |
       | static        | redis_credential_providers/static.py          | none      | n/a        |
       | aws-iam       | redis_credential_providers/aws_iam.py         | 15 min    | 2.5 min    |
       | azure-entra   | redis_credential_providers/azure_entra.py     | ~1 hour   | 5 min      |

       Phase 3 will add `mtls` and `vault`. The factory dispatches by
       `REDIS_AUTH_MODE`; unknown modes raise ValueError listing the
       supported set.

       ### Scheduled refresh

       Expiring credentials trigger a per-loop refresh task that closes
       the cached client `refresh_safety_window` before expiry. The next
       `_get_redis()` call rebuilds the client with fresh credentials.
       Refresh failures emit `redis.credential.refresh.failed` (WARNING)
       and let the existing client run until natural expiry — fail-open
       on refresh, fail-closed on actual auth.

       ### Startup preflight

       The adapter mints a credential at startup before accepting traffic.
       The result is exposed via `/health` in the `redis_credentials`
       block (`ok`, `provider`, `principal`, `expires_at`). A failed
       preflight degrades `/health` to status 503; Kubernetes readiness
       probes can gate on this. Preflight emits the same audit events
       (`redis.credential.minted` on success, `redis.credential.refresh.failed`
       on failure) with `preflight: true` in the details for filtering.

       ### Observability

       Credential lifecycle visibility comes through the existing audit
       stream — no separate metrics endpoint, no second access-control
       surface. Phase 1 wired the audit pipeline to Splunk HEC and Loki
       (via `AUDIT_SINKS=webhook` and `deploy/observability/`); Phase 2
       enriches the events so SIEM consumers can build dashboards
       without joining records.

       Audit events and their key fields:

       | Event type                              | Severity | Key details                                                |
       | --------------------------------------- | -------- | ---------------------------------------------------------- |
       | redis.credential.minted                 | INFO     | provider, principal, expires_at, expires_in_seconds        |
       | redis.credential.refresh.success        | INFO     | provider, principal (new), expires_at (new), expires_in_seconds |
       | redis.credential.refresh.failed         | WARNING  | provider, error                                            |
       | redis.auth.failure                      | WARNING  | provider, error                                            |
       | redis.static_password.used              | CRITICAL | provider                                                   |

       Mint events emitted during startup preflight have `preflight: true`
       in details for separate accounting.

       Suggested SIEM queries (Splunk SPL syntax — adapt to LogQL/KQL):

           # Credential mint rate per provider (last 1h)
           index=audit event_type=redis.credential.minted earliest=-1h
           | stats count by details.provider

           # Refresh failure alert (>=3 in 5m)
           index=audit event_type=redis.credential.refresh.failed earliest=-5m
           | stats count by details.provider
           | where count >= 3

           # Time-to-expiry trending below safety window
           index=audit event_type=redis.credential.minted earliest=-15m
           | dedup details.provider sortby -_time
           | where details.expires_in_seconds < 60

           # Static-password gate accidentally enabled in prod
           index=audit event_type=redis.static_password.used

       `expires_in_seconds` is pre-computed at emit time (mint, refresh,
       preflight) so SIEM alert rules don't need to parse ISO timestamps
       to compute time-to-expiry.

       Static-mode mints do NOT emit `expires_in_seconds` (the static
       provider has no expiry). Filter for `expires_in_seconds=*` if you
       want only expiring-credential events.

       ### IAM identities by deployment

       | Target                  | Identity                       | Source             |
       | ----------------------- | ------------------------------ | ------------------ |
       | AWS ECS                 | Task role                      | task_role_arn      |
       | AWS EKS                 | Service account (IRSA)         | pod identity       |
       | Azure Container Apps    | UAMI (User-Assigned MI)        | identity.bicep     |
       | Azure AKS               | Workload Identity              | service account    |
       | Local dev / Compose     | Static password (gated)        | REDIS_PASSWORD env |

       ### The static gate (still in place)

       `static` mode requires `ALLOW_STATIC_REDIS_PASSWORD=true`.
       Production deployments do not set this — they use `aws-iam` or
       `azure-entra`. The gate remains as an explicit grep target for
       security reviewers.

       ### Adding a new provider (Phase 3+)

       1. Subclass `RedisCredentialProvider` in
          `cache/redis_credential_providers/<name>.py`.
       2. Implement `get_credentials()` returning `RedisCredentials` with
          `expires_at` set to a real expiry (None only for non-expiring
          credentials like static or mTLS).
       3. Override `refresh_safety_window()` if your token TTL has
          provider-specific guidance.
       4. Add `from_env()` classmethod with explicit env-var name
          constants at module level.
       5. Wire into `get_redis_credential_provider()` in
          `redis_credentials.py`.
       6. Add unit tests under `tests/cache/`.
       7. Add deploy templates under `deploy/`.

       ### Valkey compatibility

       Valkey is wire-compatible with Redis. AWS ElastiCache for Valkey
       supports IAM auth identically — point `REDIS_AWS_CACHE_NAME` at a
       Valkey ElastiCache and the `aws-iam` provider works unchanged.
       Azure does not yet have a managed Valkey product; self-hosted
       Valkey can use the static (dev) or `mtls`/`vault` (Phase 3) paths.

3. Update README.md quick reference table.

   Find the existing Phase 1 table and replace:

       | `REDIS_AUTH_MODE` | Use case                                     | Status |
       | ----------------- | -------------------------------------------- | ------ |
       | `static`          | Local development with Docker Compose        | ✅      |
       | `aws-iam`         | AWS ElastiCache for Redis 7+ or Valkey      | ✅      |
       | `azure-entra`     | Azure Managed Redis or Cache for Redis Std+ | ✅      |
       | `mtls`            | Self-hosted Redis/Valkey with X.509 client  | Phase 3 |
       | `vault`           | HashiCorp Vault Redis secrets engine         | Phase 3 |

   Update the "Production" subsection. Old text said "wait for Phase 2."
   New text:

       ### Production

       Set `REDIS_AUTH_MODE=aws-iam` (AWS) or `REDIS_AUTH_MODE=azure-entra`
       (Azure) and the matching identity hints from `.env.example`. The
       reference deployments under `deploy/aws-ecs/` and
       `deploy/azure-aca/` provision the IAM roles and managed-identity
       grants automatically — `terraform apply` and `acasetup.sh` are
       sufficient.

       Static-password mode is local-dev-only. Production deployments do
       not set `ALLOW_STATIC_REDIS_PASSWORD`.

4. Run the full suite to confirm documentation changes broke nothing:

   pytest tests/ -x -q

5. Generate the security-review deliverable.

   Create docs/redis-credentials-security-summary.md (a new file, not a
   modification — this is what gets attached to security review):

       # Redis Credential Architecture — Security Summary

       ## What changed

       The adapter no longer requires a long-lived shared secret to
       authenticate to Redis. Production deployments use cloud-native
       identity:

       - AWS: ElastiCache IAM (15-min SigV4 tokens, minted per-connection)
       - Azure: Entra Managed Identity (~1-hr Entra tokens)

       The static-password path is gated by `ALLOW_STATIC_REDIS_PASSWORD`
       and exists only for local development. Production manifests do
       not contain this flag.

       ## Evidence

       1. **Codebase**: All credential acquisition flows through the
          `RedisCredentialProvider` abstraction at
          `okta_agent_proxy/cache/redis_credentials.py`. Search for
          "REDIS_PASSWORD" — it appears only in:
          - The static provider (gated)
          - Docker Compose dev configs
          - Tests that exercise the static path
          No production code path consumes `REDIS_PASSWORD` directly.

       2. **AWS deployment**: `terraform plan` against
          `deploy/aws-ecs/` shows zero secret-manager entries for
          Redis. The IAM role attached to the ECS task has only
          `elasticache:Connect` permission scoped to the cache and
          user. No password rotation procedure required.

       3. **Azure deployment**: `az redis access-policy-assignment list`
          on the deployed cache shows the UAMI granted Data Owner. The
          Container App env contains no Redis credential. Access keys
          are not retrieved (`acasetup.sh` no longer calls
          `az redis list-keys`).

       4. **Audit stream**: Every credential mint emits a structured
          audit event (`redis.credential.minted`) with the IAM principal
          or UAMI Object ID. Filter the audit log by event type to see
          per-process credential lifecycle. Preflight events are tagged
          `preflight: true` in the details for separate accounting.

       5. **Startup preflight**: The adapter mints a credential at startup
          before accepting traffic. A misconfigured IAM role, missing Entra
          grant, or unreachable IMDS surfaces immediately at `/health`
          (status 503) rather than as 5xx errors to user requests after
          rolling deploy completes. Kubernetes readiness probes gate on
          this. Audit event: `redis.credential.refresh.failed` with
          `preflight: true`.

       6. **Audit-stream observability**: Every credential lifecycle event
          flows through the existing audit pipeline to Splunk HEC or Loki
          (configured in Phase 1 via `AUDIT_SINKS=webhook`). Events carry
          pre-computed `expires_in_seconds` so SIEM alert rules don't need
          to parse ISO timestamps. The four signals customers asked for
          (mint rate by provider, refresh outcome, time-to-expiry,
          preflight status) are all queryable from the audit log without
          a separate metrics endpoint to secure.

       ## Open considerations

       - **Local development** still uses static passwords with the
         gate flag. This is restricted to the developer's own machine
         — no production reach.
       - **Self-hosted Redis** customers should use `mtls` or `vault`
         providers (Phase 3) rather than the static path.
       - **Conditional Access** policies on the workload identity
         apply transitively to Redis access — useful for customers who
         want CA-based revocation.
       - **No /metrics endpoint** — observability flows through the
         audit stream the customer already controls. There is no
         second access-control surface to manage. Customers wanting
         a synchronous health signal use `/health`, which already
         carries the credential preflight result.

       ## References

       - Implementation prompts: `REDIS_CREDS_PHASE2_PROMPTS.md`
       - Code: `okta_agent_proxy/cache/redis_credential_providers/`
       - Audit fields: `okta_agent_proxy/cache/redis_provider.py` (search for `_emit_mint_audit`, `_emit_refresh_audit`)
       - Preflight + health: `app.py` (search for `_redis_credential_preflight`)

6. Print Phase 2 completion summary:

   "Phase 2 complete:
    - 2 cloud-native providers shipped (aws-iam, azure-entra)
    - Scheduled refresh seam in RedisCacheProvider
    - Startup preflight wired into /health (fail-fast on misconfigured IAM)
    - Audit events enriched with expires_in_seconds for SIEM dashboards
    - 5 audit events flowing on every mint and refresh (preflight tagged separately)
    - AWS ECS Terraform: ElastiCache IAM, no shared secret
    - Azure ACA Bicep: Entra MI, no access keys
    - Static gate retained for local dev only
    - <N> new tests, total suite: <T>
    - Security-review summary at docs/redis-credentials-security-summary.md

    Next: Phase 3 (mtls + vault) when self-hosted customers come online."
````

**Expected Output:**
- Modified: `.env.example`, `CLAUDE.md`, `README.md`
- New file: `docs/redis-credentials-security-summary.md`
- All tests still passing.

**Commit:** `redis-creds P12: Phase 2 documentation + security-review summary`

---

# What ships at the end of Phase 2

- `aws-iam` and `azure-entra` providers, fully tested.
- Scheduled refresh on every expiring credential — refresh emits audit on success and failure.
- Startup preflight that mints a credential before traffic flows; failure surfaces as `/health` 503 for K8s readiness probes.
- Audit events enriched with `expires_in_seconds` and per-refresh `expires_at`/`principal` so SIEM consumers can build dashboards without joining records. No `/metrics` endpoint, no second access-control surface.
- AWS ECS reference deployment uses ElastiCache IAM end to end, with zero static secrets.
- Azure ACA reference deployment uses UAMI + Entra ID, with zero access keys.
- Security-review summary at `docs/redis-credentials-security-summary.md` for security review.
- Static gate retained for local dev only, prominently marked dev-only in all documentation.

# What does NOT ship in Phase 2

- `mtls` provider — Phase 3, when first self-hosted customer requests it.
- `vault` provider — Phase 3.
- OPA Vault provider for Redis — Phase 3 (uses existing OktaVaultSecretExchanger, treats OPA as static-secret store with policy-driven refresh).
- GCP Memorystore for Valkey IAM provider — Phase 4, when GCP deployment lands.
- OpenTelemetry export for credential-lifecycle traces — Phase 4 (audit stream is sufficient for v1; OTel adds tracing context).
- Prometheus `/metrics` endpoint — deliberately not shipped. Audit-stream observability via Splunk/Loki is the canonical lane; a separate metrics endpoint would add an access-control surface customers don't want. Revisit if a customer specifically requires Prometheus.
- Admin endpoint exposing current credential principal in detail — Phase 4 nice-to-have (the `/health` block is sufficient for now).

# Pre-flight checklist before P06

- [ ] Phase 1 fully merged, on a clean working tree
- [ ] `pytest tests/cache/ -v` shows 39 tests passing
- [ ] Feature branch created: `feature/redis-credential-provider-phase-2`
- [ ] AWS account access for at least one integration smoke test (P09)
- [ ] Azure subscription with permission to create role assignments on Redis (P10)
- [ ] `pip install -e .` resolves new boto3/azure-identity additions cleanly

# After P12 — what to deliver to security review

1. The architecture doc (Phase 1 deliverable, still valid)
2. `docs/redis-credentials-security-summary.md` (P12 deliverable — this is the new artifact)
3. The Phase 2 commits, kept as a series for reviewability
4. A Terraform plan output from `deploy/aws-ecs` showing zero `random_password` and zero `aws_secretsmanager_secret.redis` resources
5. An `az resource list` output from the Azure RG showing zero stored Redis access keys, and `az redis access-policy-assignment list` showing the UAMI grant
6. A `curl /health` snapshot showing the `redis_credentials` block with the actual production principal
7. A Splunk/Loki query snapshot showing recent `redis.credential.minted` events with the actual IAM/Entra principal in `details.principal`

The Phase 1 finding (static gate present) is closed by this delivery. The audit stream now shows IAM/Entra principals on every mint, which is the proof reviewers asked for.
