# Global Logout — v5 Additive Prompts (P10 and P11)

**Target repository:** `atko-proservices/okta-agent-mcp-adapter`
**Baseline:** v4 prompt pack already executed. The endpoint, orchestrator, audit events, JWT verification with `GLOBAL_LOGOUT_EXPECTED_CLIENT_ID` env-var pinning, and operator docs are already in place.

**What's changing in v5 (and why):**

The Confidential Relay no longer uses a single shared Okta OIDC app — each Agent record is linked to its own Okta OIDC app (which may be shared across agents). v4's single-pin env var `GLOBAL_LOGOUT_EXPECTED_CLIENT_ID` doesn't fit this model: legitimate Universal Logout calls can come from any registered agent's linked app, not just one. v5 replaces the env-var pin with a database-backed allowlist sourced from `store.get_all_agents(enabled_only=False)`, with TTL caching and pub/sub invalidation hooked into the existing `CHANNEL_AGENT_INVALIDATE` channel.

Note: the `ConfidentialRelay` class in `auth/confidential_relay.py` still exists and is central to CIMD flows; it now uses per-agent credentials from the DB instead of a single shared relay app. "Relay app no longer exists" in this doc refers only to the single-shared-app identity, not the class/module.

**The recommended Okta operator pattern shifts** from "configure Universal Logout on one app" to "configure Universal Logout on each agent's linked Okta OIDC app." The adapter automatically trusts any registered agent's `client_id` as a valid Universal Logout source. Disabled agents remain trusted (their existing users' tokens still need to be revocable). When an agent is removed entirely, its `client_id` is no longer accepted.

**Pub/sub design:** The codebase already publishes to `CHANNEL_AGENT_INVALIDATE` from every agent CRUD path (`admin/routes.py` create/update/delete, `admin/credential_routes.py` fetch-secret and generate-keypair, `auth/dcr_handler.py` DCR-driven creation). A subscriber `_on_agent_invalidate` already exists in `app.py` startup. We hook our cache-flush into that subscriber rather than introducing a new channel — four lines appended to an existing handler, no new publish call sites needed.

**Trust window with TTL = 1 hour:** The TTL is a safety net for pub/sub failures (Redis partition, replica lag). Best-case: agent CRUD propagates within milliseconds. Worst-case (replica disconnected from Redis at the moment of CRUD, then reconnects): up to 1 hour of stale trust before TTL expires. Acceptable for a security-relevant cache because (a) the pub/sub path heals on reconnection (replicas re-subscribe), (b) the consequences of stale trust are bounded — a deactivated agent's `client_id` could still authorize logout JWTs for up to an hour, but it can't do anything that doesn't also flow through the JWT signature check against Okta JWKS.

**Pack size:** 2 sequential prompts.
**Recovery:** `git reset --hard HEAD` per prompt.

---

## Prompt 10: Replace env-var pin with DB-backed allowlist + pub/sub invalidation

### Context

`auth/global_logout_route.py` currently has `_expected_client_id()` reading `GLOBAL_LOGOUT_EXPECTED_CLIENT_ID` env var. We replace this with a TTL-cached lookup against the agents table.

Key facts confirmed from source review:
- `from okta_agent_proxy.database import get_store` — module-level accessor for the live `Postgres` storage instance. Used the same way in `admin/routes.py` (line 18).
- `store.get_all_agents(enabled_only: bool = True) -> List[Dict[str, Any]]` — returns list of agent dicts; each has a `client_id` field (the Okta OIDC app's client_id). For our purposes we want `enabled_only=False` so disabled agents stay in the allowlist.
- `CHANNEL_AGENT_INVALIDATE = "agent_invalidate"` exists in `cache/pubsub.py:35` and is in `ALL_CHANNELS`.
- The subscriber `_on_agent_invalidate` is defined in `app.py` around line 2759 inside an inner function in the startup handler. We modify that handler to also flush our new cache.
- Publishers already in place: `admin/routes.py` (lines 296, 407, 496: create/update/delete), `admin/credential_routes.py` (lines 69, 120: fetch-secret, generate-keypair), `auth/dcr_handler.py` (line 317: DCR-driven creation). No new publishes needed.

### Prompt

```
TASK A — okta_agent_proxy/auth/global_logout_route.py

Replace env-var-based JWT sub pinning with a DB-backed allowlist
sourced from the agents table. The allowlist is the set of all
Okta OIDC client_ids known to the adapter (one per agent, possibly
shared across agents). Cache it with TTL + pub/sub invalidation.

1. Add at module level near the other state (after the rate-limit
   state):

       # ---- Agent client_id allowlist (for JWT sub validation) ----
       _ALLOWLIST_TTL_SECONDS = int(
           os.environ.get("GLOBAL_LOGOUT_ALLOWLIST_TTL_SECONDS", "3600")
       )
       _allowlist_cache: dict = {
           "set": frozenset(),
           "fetched_at": 0.0,
           "loaded": False,
       }
       _allowlist_lock = asyncio.Lock()

2. Add async helper to populate the cache (place after the rate
   limiter helpers, before _verify_logout_jwt):

       async def _load_agent_client_id_allowlist() -> frozenset[str]:
           """Build the allowlist from the agents table. Includes
           disabled agents (their tokens are still in flight)."""
           from okta_agent_proxy.database import get_store
           store = get_store()
           agents = store.get_all_agents(enabled_only=False)
           client_ids = {
               a.get("client_id") for a in agents
               if isinstance(a.get("client_id"), str) and a.get("client_id")
           }
           return frozenset(client_ids)

       async def _get_agent_client_id_allowlist() -> frozenset[str]:
           """Return the cached allowlist, refreshing from DB if stale."""
           now = time.monotonic()
           cached = _allowlist_cache
           if (cached["loaded"]
                   and (now - cached["fetched_at"]) < _ALLOWLIST_TTL_SECONDS):
               return cached["set"]

           async with _allowlist_lock:
               # Re-check after acquiring lock (another coroutine may
               # have refreshed)
               now = time.monotonic()
               if (_allowlist_cache["loaded"]
                       and (now - _allowlist_cache["fetched_at"])
                            < _ALLOWLIST_TTL_SECONDS):
                   return _allowlist_cache["set"]
               try:
                   client_ids = await _load_agent_client_id_allowlist()
               except Exception as exc:
                   logger.warning(
                       "[GLOBAL-LOGOUT] allowlist refresh failed; "
                       "keeping previous value: %s", exc
                   )
                   # Return last known good value rather than empty set —
                   # empty set would reject every legitimate call. If we
                   # have no prior value (first load failed), return empty
                   # which will cause 401 — that is the safer default.
                   return _allowlist_cache["set"]
               _allowlist_cache["set"] = client_ids
               _allowlist_cache["fetched_at"] = time.monotonic()
               _allowlist_cache["loaded"] = True
               logger.info(
                   "[GLOBAL-LOGOUT] allowlist refreshed: %d client_ids",
                   len(client_ids),
               )
               return client_ids

       def invalidate_agent_client_id_allowlist() -> None:
           """Force the next allowlist read to re-query the DB. Called
           by the CHANNEL_AGENT_INVALIDATE pub/sub subscriber and from
           local agent CRUD via the existing publish path."""
           _allowlist_cache["loaded"] = False
           # Don't clear the set itself — keep it as the last-known
           # value in case the next refresh fails (see _get_... fallback)
           _allowlist_cache["fetched_at"] = 0.0

       def _reset_allowlist_cache() -> None:
           """Test-only: full reset including the cached set."""
           _allowlist_cache["set"] = frozenset()
           _allowlist_cache["fetched_at"] = 0.0
           _allowlist_cache["loaded"] = False

3. Remove the _expected_client_id() function entirely. Remove all
   references to GLOBAL_LOGOUT_EXPECTED_CLIENT_ID env var, including
   the docstring comment about it.

4. In _verify_logout_jwt, replace this block:

       # 3. Optional sub pinning
       expected_sub = _expected_client_id()
       if expected_sub:
           actual_sub = claims.get("sub")
           if actual_sub != expected_sub:
               raise ValueError(
                   f"sub_mismatch: got {actual_sub!r}, "
                   f"expected {expected_sub!r}"
               )

   With:

       # 3. JWT sub must be a registered agent's client_id
       actual_sub = claims.get("sub")
       allowlist = await _get_agent_client_id_allowlist()
       if not actual_sub or actual_sub not in allowlist:
           raise ValueError(
               f"sub_not_in_allowlist: client_id {actual_sub!r} is not "
               f"a registered agent's Okta app client_id"
           )

5. Scrub references to the env var and to the "single Confidential
   Relay OIDC app" pattern from TWO docstrings (not just the module
   docstring — the env var name lives in the function docstring):

   (a) Module docstring (top of file, around line 1-59): Remove any
       reference to a "single Confidential Relay OIDC app". Replace
       with per-agent-linked-app wording consistent with Prompt 11.

   (b) `_verify_logout_jwt` docstring (around line 171): Remove the
       line `sub == GLOBAL_LOGOUT_EXPECTED_CLIENT_ID (if pinned)` and
       replace with:

           sub must be a registered agent's Okta app client_id
               (auto-maintained from the agents table — both enabled
               and disabled agents are trusted; only deleted agents
               are rejected).

   (c) The stale guidance paragraph in `_expected_client_id()`'s
       docstring about "most operators run a single Confidential Relay
       OIDC app" is deleted along with the function itself (step 3).
       No separate action needed beyond removing the function.

TASK B — okta_agent_proxy/app.py

Modify the existing _on_agent_invalidate subscriber (currently around
line 2759 inside the startup handler) to also flush the global-logout
allowlist. The current body is:

    async def _on_agent_invalidate(message: str):
        logger.info(f"Pub/sub: agent invalidation received ({message})")
        from okta_agent_proxy.storage.cached_store import CachedResourceStore
        if isinstance(store, CachedResourceStore):
            try:
                event_bus._cache_service.l1.close()  # clear L1
            except Exception:
                pass

Append the following block (four lines including the import) at the
end of this function, before the dedent that ends the inner function,
preserving everything else:

        # Flush the global-logout client_id allowlist so the next JWT
        # verification re-queries the agents table.
        from okta_agent_proxy.auth.global_logout_route import (
            invalidate_agent_client_id_allowlist,
        )
        invalidate_agent_client_id_allowlist()

Do NOT modify any other subscriber. Do NOT modify the publish call
sites in admin/routes.py or auth/dcr_handler.py — they already publish
to CHANNEL_AGENT_INVALIDATE on every agent CRUD.

TASK C — Tests

Update tests/test_global_logout_route_integration.py:

1. Remove the v4 _env fixture line that deletes
   GLOBAL_LOGOUT_EXPECTED_CLIENT_ID — env var no longer exists.
   Add a line that resets the allowlist cache:

       from okta_agent_proxy.auth.global_logout_route import (
           ..., _reset_allowlist_cache, ...,
       )

       # In the _env fixture:
       _reset_allowlist_cache()
       # ... existing resets ...
       yield
       _reset_allowlist_cache()

1a. CRITICAL — Add an autouse fixture that patches the allowlist
    loader so existing v4 happy-path tests (which sign JWTs with
    sub=TEST_CALLER_CLIENT_ID) keep passing. Without this, ~10
    existing tests (test_happy_path_returns_204,
    test_subject_not_found_still_returns_204, test_terminates_mcp_sessions,
    test_rate_limit_exceeded_returns_429,
    test_correlation_id_and_context_propagated_to_background_task,
    test_backend_session_termination_failure_still_returns_204,
    test_rate_limiter_idle_ips_eventually_evicted,
    test_email_subject_format_returns_400_with_helpful_hint,
    test_subject_iss_mismatch_returns_400,
    test_missing_subject_field_returns_400,
    test_malformed_body_returns_400) will 401 because the new
    mandatory allowlist check has no data — conftest's autouse
    reset_database_state truncates the agents table after each
    test and no fixture patches the DB or get_store for this route.

    Add this fixture at module scope (before the `client` fixture):

        @pytest.fixture(autouse=True)
        def _default_allowlist(monkeypatch):
            """Patch _load_agent_client_id_allowlist so existing v4
            tests using TEST_CALLER_CLIENT_ID authorize by default.
            Tests that need a different allowlist can override by
            re-patching the loader and calling
            invalidate_agent_client_id_allowlist() to force a reread."""
            async def _default_loader():
                return frozenset({
                    TEST_CALLER_CLIENT_ID,
                    "0oaagent1abc",
                    "0oaagent2def",
                })
            monkeypatch.setattr(
                "okta_agent_proxy.auth.global_logout_route."
                "_load_agent_client_id_allowlist",
                _default_loader,
            )
            _reset_allowlist_cache()
            yield
            _reset_allowlist_cache()

    Keep TEST_CALLER_CLIENT_ID = "0oarelaytest" unchanged — the
    default loader includes it, so the existing _valid_claims()
    default sub continues to authorize without per-test changes.

2. Remove the v4 tests test_pinned_client_id_mismatch_returns_401
   and test_pinned_client_id_match_returns_204. They reference the
   deleted env var.

3. Add a new fixture that patches store.get_all_agents to return a
   controlled allowlist. Tests that use this fixture are the ones
   that mutate the allowlist at runtime (TTL expiry, invalidation,
   first-load-failure, etc.) — they override the autouse default
   by re-patching the loader explicitly and calling
   invalidate_agent_client_id_allowlist() to force a reread:

       @pytest.fixture
       def patched_allowlist(monkeypatch):
           """Return a list-of-dicts shaped like store.get_all_agents,
           and let tests mutate it to simulate agent CRUD."""
           agents_data = [
               {"agent_id": "a1", "client_id": "0oaagent1abc"},
               {"agent_id": "a2", "client_id": "0oaagent2def"},
           ]

           class _MockStore:
               def get_all_agents(self, enabled_only=True):
                   return list(agents_data)

           import okta_agent_proxy.auth.global_logout_route as gl_route
           monkeypatch.setattr(
               "okta_agent_proxy.auth.global_logout_route._load_agent_client_id_allowlist",
               # Replace the loader so we don't need a real DB
               AsyncMock(side_effect=lambda: frozenset(
                   a["client_id"] for a in agents_data
               )),
           )
           yield agents_data
           # Cleanup is handled by _env fixture's _reset_allowlist_cache

4. Update _valid_claims default sub to use a value from the
   patched_allowlist (e.g. "0oaagent1abc"). Update TEST_CALLER_CLIENT_ID
   constant accordingly.

5. Add new tests:

   def test_jwt_sub_in_allowlist_returns_204(client, keypair, patched_jwks,
                                              patched_allowlist,
                                              mock_handler_deps):
       private_pem, _ = keypair
       claims = _valid_claims(sub="0oaagent1abc")
       jwt_token = _sign_jwt(claims, private_pem)
       resp = client.post(
           GLOBAL_LOGOUT_PATH,
           json=_valid_body(),
           headers=_bearer(jwt_token),
       )
       assert resp.status_code == 204

   def test_jwt_sub_not_in_allowlist_returns_401(client, keypair,
                                                  patched_jwks,
                                                  patched_allowlist):
       private_pem, _ = keypair
       claims = _valid_claims(sub="0oaUNKNOWNapp")
       jwt_token = _sign_jwt(claims, private_pem)
       resp = client.post(
           GLOBAL_LOGOUT_PATH,
           json=_valid_body(),
           headers=_bearer(jwt_token),
       )
       assert resp.status_code == 401
       assert resp.json()["error"] == "invalid_client"

   def test_jwt_sub_missing_returns_401(client, keypair, patched_jwks,
                                         patched_allowlist):
       """JWT with no sub claim still rejected by allowlist check."""
       private_pem, _ = keypair
       claims = _valid_claims()
       claims.pop("sub")
       jwt_token = _sign_jwt(claims, private_pem)
       resp = client.post(
           GLOBAL_LOGOUT_PATH,
           json=_valid_body(),
           headers=_bearer(jwt_token),
       )
       assert resp.status_code == 401

   def test_disabled_agent_client_id_still_in_allowlist(client, keypair,
                                                         patched_jwks,
                                                         patched_allowlist,
                                                         mock_handler_deps):
       """The loader uses enabled_only=False; assert disabled agents
       (which would still appear in the loader output) are accepted."""
       # Append a disabled agent's client_id to the mocked data;
       # the loader doesn't filter on enabled, so its client_id is
       # in the allowlist.
       patched_allowlist.append(
           {"agent_id": "disabled1", "client_id": "0oaDISABLEDx",
            "enabled": False}
       )
       # Force cache refresh so the new entry is picked up
       from okta_agent_proxy.auth.global_logout_route import (
           invalidate_agent_client_id_allowlist,
       )
       invalidate_agent_client_id_allowlist()

       private_pem, _ = keypair
       claims = _valid_claims(sub="0oaDISABLEDx")
       jwt_token = _sign_jwt(claims, private_pem)
       resp = client.post(
           GLOBAL_LOGOUT_PATH,
           json=_valid_body(),
           headers=_bearer(jwt_token),
       )
       assert resp.status_code == 204

   def test_allowlist_cache_invalidation_picks_up_new_agent(
       client, keypair, patched_jwks, patched_allowlist, mock_handler_deps
   ):
       """Simulate adding a new agent post-startup: cache invalidation
       triggers a re-query and the new client_id is accepted."""
       private_pem, _ = keypair

       # First request with new-agent's client_id should fail (not in
       # allowlist yet).
       claims = _valid_claims(sub="0oaNEWagent")
       jwt_token = _sign_jwt(claims, private_pem)
       resp = client.post(
           GLOBAL_LOGOUT_PATH,
           json=_valid_body(),
           headers=_bearer(jwt_token),
       )
       assert resp.status_code == 401

       # Add the new agent and invalidate the cache (simulates CRUD +
       # pub/sub propagation)
       patched_allowlist.append(
           {"agent_id": "new1", "client_id": "0oaNEWagent"}
       )
       from okta_agent_proxy.auth.global_logout_route import (
           invalidate_agent_client_id_allowlist,
       )
       invalidate_agent_client_id_allowlist()

       # Second request should now succeed
       claims = _valid_claims(sub="0oaNEWagent")
       jwt_token = _sign_jwt(claims, private_pem)
       resp = client.post(
           GLOBAL_LOGOUT_PATH,
           json=_valid_body(),
           headers=_bearer(jwt_token),
       )
       assert resp.status_code == 204

   def test_allowlist_load_failure_keeps_previous_value(
       client, keypair, patched_jwks, patched_allowlist, mock_handler_deps,
       monkeypatch,
   ):
       """If the DB load fails on a refresh, the existing allowlist
       value is preserved (do not regress to empty set)."""
       # First, do a successful request to populate the cache
       private_pem, _ = keypair
       claims = _valid_claims(sub="0oaagent1abc")
       jwt_token = _sign_jwt(claims, private_pem)
       resp = client.post(
           GLOBAL_LOGOUT_PATH,
           json=_valid_body(),
           headers=_bearer(jwt_token),
       )
       assert resp.status_code == 204

       # Make the loader raise; force a refresh
       async def _raising_loader():
           raise RuntimeError("DB unavailable")
       monkeypatch.setattr(
           "okta_agent_proxy.auth.global_logout_route._load_agent_client_id_allowlist",
           _raising_loader,
       )
       from okta_agent_proxy.auth.global_logout_route import (
           invalidate_agent_client_id_allowlist,
       )
       invalidate_agent_client_id_allowlist()

       # Should still succeed using the cached value
       claims = _valid_claims(sub="0oaagent1abc")
       jwt_token = _sign_jwt(claims, private_pem)
       resp = client.post(
           GLOBAL_LOGOUT_PATH,
           json=_valid_body(),
           headers=_bearer(jwt_token),
       )
       assert resp.status_code == 204

   def test_allowlist_first_load_failure_returns_empty_set_rejecting_all(
       client, keypair, patched_jwks, monkeypatch,
   ):
       """If the FIRST allowlist load (no prior value) fails, the
       allowlist is empty and all logout calls are rejected — fail
       closed. This test overrides the autouse _default_allowlist by
       re-patching the loader to raise, then resetting the cache."""
       async def _raising_loader():
           raise RuntimeError("DB unavailable on startup")
       monkeypatch.setattr(
           "okta_agent_proxy.auth.global_logout_route._load_agent_client_id_allowlist",
           _raising_loader,
       )
       # Full cache reset (clears last-known-good set, not just the
       # loaded flag) so the raising loader's failure has no fallback.
       _reset_allowlist_cache()

       private_pem, _ = keypair
       claims = _valid_claims(sub="0oaanything")
       jwt_token = _sign_jwt(claims, private_pem)
       resp = client.post(
           GLOBAL_LOGOUT_PATH,
           json=_valid_body(),
           headers=_bearer(jwt_token),
       )
       assert resp.status_code == 401

   def test_allowlist_ttl_expiration_triggers_refresh(
       client, keypair, patched_jwks, patched_allowlist, mock_handler_deps,
       monkeypatch,
   ):
       """After TTL expires, the next request triggers a re-query."""
       monkeypatch.setattr(
           "okta_agent_proxy.auth.global_logout_route._ALLOWLIST_TTL_SECONDS",
           0.05,
       )

       # First request populates the cache
       private_pem, _ = keypair
       claims = _valid_claims(sub="0oaagent1abc")
       jwt_token = _sign_jwt(claims, private_pem)
       resp = client.post(
           GLOBAL_LOGOUT_PATH,
           json=_valid_body(),
           headers=_bearer(jwt_token),
       )
       assert resp.status_code == 204

       # Sleep past TTL, add a new agent, do NOT invalidate explicitly —
       # the TTL-triggered refresh should pick it up.
       time.sleep(0.1)
       patched_allowlist.append(
           {"agent_id": "ttltest", "client_id": "0oaTTLagent"}
       )

       claims = _valid_claims(sub="0oaTTLagent")
       jwt_token = _sign_jwt(claims, private_pem)
       resp = client.post(
           GLOBAL_LOGOUT_PATH,
           json=_valid_body(),
           headers=_bearer(jwt_token),
       )
       assert resp.status_code == 204

6. Add a unit test for the pub/sub subscriber wiring:

   Create tests/test_global_logout_pubsub_invalidation.py:

   import pytest
   from okta_agent_proxy.auth.global_logout_route import (
       _allowlist_cache,
       invalidate_agent_client_id_allowlist,
       _reset_allowlist_cache,
   )

   @pytest.fixture(autouse=True)
   def _clean():
       _reset_allowlist_cache()
       yield
       _reset_allowlist_cache()

   def test_invalidate_marks_cache_unloaded():
       _allowlist_cache["set"] = frozenset({"old"})
       _allowlist_cache["fetched_at"] = 9999.0
       _allowlist_cache["loaded"] = True
       invalidate_agent_client_id_allowlist()
       assert _allowlist_cache["loaded"] is False
       assert _allowlist_cache["fetched_at"] == 0.0
       # The set itself is preserved as last-known-good
       assert _allowlist_cache["set"] == frozenset({"old"})

   def test_invalidate_is_idempotent_when_unloaded():
       """Invalidating an already-unloaded cache is a no-op."""
       invalidate_agent_client_id_allowlist()
       invalidate_agent_client_id_allowlist()  # second call must not raise
       assert _allowlist_cache["loaded"] is False

Run:
  pytest tests/test_global_logout_route_integration.py -v
  pytest tests/test_global_logout_pubsub_invalidation.py -v
  pytest tests/ -q  (full suite still passes)
```

### Expected output

- `auth/global_logout_route.py` modified: env-var-pin removed, allowlist cache + helpers added, `_verify_logout_jwt` updated.
- `app.py` modified: 4-line addition to existing `_on_agent_invalidate` subscriber.
- `tests/test_global_logout_route_integration.py` updated: 2 v4 tests removed, autouse `_default_allowlist` fixture added so existing v4 happy-path tests keep passing, ~7 new tests added.
- `tests/test_global_logout_pubsub_invalidation.py` created with 2 tests.
- Full test suite passes.

---

## Prompt 11: Update operator documentation for per-linked-app pattern

### Context

`docs/GLOBAL_LOGOUT_CONFIGURATION.md` currently recommends configuring Universal Logout on the Confidential Relay app (which doesn't exist) and pinning via `GLOBAL_LOGOUT_EXPECTED_CLIENT_ID`. Replace both with the per-agent-linked-app pattern and the auto-allowlist behavior.

### Prompt

```
Update docs/GLOBAL_LOGOUT_CONFIGURATION.md.

1. In the "Adapter-side configuration" section, REMOVE the
   GLOBAL_LOGOUT_EXPECTED_CLIENT_ID env-var bullet. Replace with:

     GLOBAL_LOGOUT_ALLOWLIST_TTL_SECONDS — OPTIONAL. Default 3600
       (1 hour). The adapter caches the set of trusted Universal
       Logout client_ids from the agents table for this duration.
       The cache is also invalidated immediately on any agent CRUD
       via the CHANNEL_AGENT_INVALIDATE pub/sub channel, so this
       TTL is a safety net for pub/sub partition scenarios rather
       than the primary refresh path. Lower values reduce the
       max-stale-trust window at the cost of more DB queries.

2. In the "Okta Admin Console configuration" section, REPLACE the
   single-app guidance with the per-linked-app pattern. New text:

   ### Per-agent-linked-app configuration

   The adapter has no single "front door" Okta application. Each
   Agent record in the adapter is linked to an Okta OIDC application.
   Multiple agents may share one Okta app, or each may have its own.

   For Universal Logout to revoke a user's tokens on the adapter,
   the Okta app the user signed in through MUST have Universal
   Logout configured. Therefore: configure Universal Logout on
   every Okta OIDC app that any agent is linked to.

   Coverage by construction: a user can only obtain adapter-issued
   tokens by authenticating through one of these linked apps. So
   if Universal Logout is configured on every linked app, every
   user with adapter access is covered.

   Per-app configuration steps mirror Okta's docs at:
   https://help.okta.com/oie/en-us/content/topics/itp/config-universal-logout.htm

   For each agent's linked Okta OIDC app:

     Logout endpoint URL:
       https://<adapter>/oauth/global-token-revocation
       (Same endpoint for every app — the adapter accepts logout
       JWTs from any registered agent's linked app.)

     Endpoint authentication type:
       Signed JWT (Okta default).

     Subject format type:
       Issuer and Subject Identifier.
       Do NOT select Email Identifier — the adapter rejects email
       format with HTTP 400 unsupported_subject_format.

   Auto-trust: The adapter validates the JWT sub claim (the calling
   Okta app's client_id) against the set of client_ids in its agents
   table. There is no env var to maintain — when an agent is
   registered, its linked app's client_id is automatically accepted
   as a Universal Logout source. When an agent is deleted, its
   client_id stops being accepted (after pub/sub propagation, or
   within GLOBAL_LOGOUT_ALLOWLIST_TTL_SECONDS in the worst case).
   Disabled agents remain in the allowlist — their existing users
   may still hold tokens that need revocation.

3. In the "Verifying the integration" section, ADD a paragraph after
   the existing audit-event list:

   ### Detecting linked apps with Universal Logout NOT configured

   Run a periodic reconciliation report comparing two sets:

     A. The set of all client_ids in the adapter's agents table:
        admin API GET /api/admin/agents → collect each agent.client_id.

     B. The set of client_ids that have ever appeared as the JWT sub
        in a successful GLOBAL_LOGOUT_REQUESTED audit event over the
        observation window (e.g. last 30 days).

   Any client_id in A but not in B is a linked Okta app that has
   never sent a Universal Logout call to the adapter. This may be
   benign (no logout-triggering events for users of that app in the
   window) or may indicate Universal Logout is not configured on
   that app. Investigate with the Okta admin to confirm.

   Conversely, any client_id in B but not in A is a logout source
   that is no longer a registered agent — the JWT verification
   would now reject it, and the audit row is historical only.

4. In the "Inbound JWT format reference" section, update the sub
   claim description:

     sub = client_id of the calling Okta OIDC app. The adapter
           validates this against the set of client_ids in its
           agents table (via store.get_all_agents). Both enabled
           and disabled agents are trusted; only deleted agents are
           rejected.

5. In the "Troubleshooting" section, REPLACE the
   GLOBAL_LOGOUT_AUTH_FAILED with reason "sub_mismatch" entry with:

     GLOBAL_LOGOUT_AUTH_FAILED with reason "sub_not_in_allowlist":
       The JWT sub (the calling Okta app's client_id) does not
       match any registered agent's linked-app client_id. Possible
       causes:

       (a) The Okta app sending the JWT is for an agent that has
           been deleted from the adapter. Audit will show the agent
           in question; this is benign if expected.

       (b) The Okta app is for an agent that exists in the adapter
           but its client_id field has drifted from the actual Okta
           app (e.g. the app was rotated in Okta but not updated in
           the adapter). Reconcile via the admin API — get the
           agent and update its client_id to match Okta.

       (c) The Okta app sending the JWT is not actually a registered
           agent in the adapter (someone configured Universal Logout
           on an unrelated app pointing at our endpoint). Reject is
           correct; investigate why the app was misconfigured.

       (d) Recent agent CRUD has not yet propagated to this replica.
           Wait up to GLOBAL_LOGOUT_ALLOWLIST_TTL_SECONDS (default
           3600s = 1h). If the replica is healthy and Redis is
           reachable, pub/sub propagation should be sub-second; the
           TTL is only a fallback.

6. In the "Scope and limitations" section, KEEP the existing bullet
   about admin-UI force-logout being deferred (it is the only place
   in the doc where this limitation is documented — there is no
   separate deferred list elsewhere to dedupe against). Do NOT
   remove it. ADD this new bullet beneath it:

     - Universal Logout client_id allowlist is sourced from the
       agents table. CRUD updates propagate via the
       CHANNEL_AGENT_INVALIDATE pub/sub channel within sub-second
       window when Redis is reachable; otherwise refreshes every
       GLOBAL_LOGOUT_ALLOWLIST_TTL_SECONDS (default 1 hour).

7. In the "Architecture context" section, REPLACE the existing
   one-paragraph explanation with the following two paragraphs:

   ### Architecture context

   The adapter currently uses the Okta org authorization server.
   This means OKTA_ISSUER == https://{OKTA_DOMAIN} in production,
   and all JWT iss values, body subject.iss values, and JWKS lookups
   resolve through this single issuer. Custom AS code paths exist
   for a future Okta capability (originating token from custom AS
   for the XAA/ID-JAG flow) but are not used today. If Okta ever
   supports that topology, this doc and the JWT validation logic
   must be re-verified against Okta's at-the-time guidance for
   which AS signs Universal Logout JWTs before enabling.

   The adapter does not have a single Okta application that all
   users sign in through. Each Agent record is linked to its own
   Okta OIDC application (which may be shared across multiple
   agents or be unique per agent — operator's choice). Universal
   Logout is therefore configured per linked Okta app, and the
   adapter automatically maintains the trust set of accepted JWT
   sub values from its agents table.

8. Verify no GLOBAL_LOGOUT_EXPECTED_CLIENT_ID references remain
   anywhere in the doc:

     grep -n "GLOBAL_LOGOUT_EXPECTED_CLIENT_ID" docs/GLOBAL_LOGOUT_CONFIGURATION.md

   Should return no matches.

Optional but recommended: spot-check top-level README.md for any
"Confidential Relay" references. Currently none exist there, so
nothing to scrub.

OUT OF SCOPE for v5: deployment-guide cleanup. The stale
"Confidential Relay OIDC Web App" guidance lives in
docs/AZURE_ACA_DEPLOYMENT_GUIDE.md, deploy/azure-aks/README.md,
deploy/bundle/README.md, and docs/DCR_CIMD_OPERATIONS.md. Those
deserve their own deploy-docs prompt pack — do not touch them here.
v5 scope is the Universal Logout feature docs only.

No code changes. Deliverable is documentation only.
```

### Expected output

- `docs/GLOBAL_LOGOUT_CONFIGURATION.md` updated end-to-end.
- All `GLOBAL_LOGOUT_EXPECTED_CLIENT_ID` references gone from the Universal Logout docs.
- Top-level README.md spot-checked (no matches expected).
- Deployment-guide "Confidential Relay OIDC Web App" references NOT touched — deferred to a separate deploy-docs prompt pack.
- No tests changed (docs-only).

---

## Post-v5 checklist

After P10 and P11 complete:

- `pytest tests/ -q` passes.
- `GLOBAL_LOGOUT_EXPECTED_CLIENT_ID` env var no longer recognized anywhere.
- A new agent created through the admin API has its `client_id` accepted as a Universal Logout source within sub-second on every replica (verify via `redis-cli` watching the channel + a curl probe with the new agent's client_id).
- A deleted agent's `client_id` stops being accepted within sub-second on every replica.
- Operator docs reflect the per-linked-app pattern.

## What's still deferred

Unchanged from v4:
- Admin-UI "force logout this user" button.
- `global_token_revocation_endpoint_auth_methods_supported` metadata field.
- OIDC Back-Channel Logout (sid-based) for non-Okta IdPs.
- SSF completion callback.
- Cross-replica MCP session enumeration.
- Distributed rate limiter.
- `email` subject format support.
- `jti` replay protection.
- Custom-AS Universal Logout re-verification (when Okta ships originating-from-custom-AS).

New in v5:
- (none added)
