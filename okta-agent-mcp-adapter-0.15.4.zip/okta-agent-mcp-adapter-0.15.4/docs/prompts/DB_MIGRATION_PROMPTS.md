# Database Layer Migration — Claude Code Implementation Prompts

**Goal:** Remove SQLAlchemy + Alembic + greenlet from the runtime image, eliminate runtime DDL, and add a pluggable database credential provider so customers can use AWS RDS IAM, Azure Entra (Microsoft Entra ID), or HashiCorp Vault dynamic secrets instead of static `DATABASE_URL` passwords.

**Drivers:**
- CWE-121 stack-based buffer overflow finding in `src/greenlet/TStackState.cpp:259`. greenlet ships transitively with `sqlalchemy>=2.0.0` regardless of asyncio usage. The only durable fix is removing SQLAlchemy from `requirements.txt`.
- Two enterprise customers have flagged that the adapter creates schema at runtime (`Base.metadata.create_all(self.engine)` in `okta_agent_proxy/storage/postgres.py:81`) and uses static credentials baked into `DATABASE_URL`. They want DBA-controlled migrations and rotatable / dynamic credentials.

**Scope:** Replace `sqlalchemy` + `alembic` + `psycopg2-binary` with `psycopg[binary]` (psycopg3) + `psycopg_pool` and a small in-tree migration runner. Preserve the existing `ResourceConfigStore` interface so the rest of the application (admin UI, route handlers, cache, audit, etc.) is unaffected.

**Prompt Count:** 14 sequential prompts across 5 phases.

**Test Constraint:** All 1,950+ existing test functions across 112 test files must continue passing after each prompt (or be migrated in the same prompt that breaks them — never leave the suite red between prompts).

**Test-Infrastructure Note (READ BEFORE P02):** The current test suite runs against **SQLite in-memory** via the session-scoped `test_engine` fixture in `tests/conftest.py:126` — `create_engine("sqlite:///:memory:")` with `Base.metadata.create_all(engine)`. SQLAlchemy's dialect layer currently lets the Postgres-targeted code run on SQLite for tests. Once we move to raw psycopg3 + `BYTEA`/`JSONB`/`TIMESTAMPTZ`, the psycopg3 path cannot use SQLite. Before executing P02, decide one of:
  1. Add `pytest-postgresql` (or a Docker-based fixture) and run the new `psycopg` branch of the parametrized fixture against a real ephemeral Postgres.
  2. Keep SQLite for the `sqlalchemy` backend (legacy, until P07) and gate the `psycopg` branch on a real Postgres fixture.

P02–P06's "both backends" assumption only holds if option 1 or 2 is implemented up front.

**Audit Constraint:** Every prompt that modifies the request/auth/exchange paths must add appropriate `AuditEventType` entries and `emit_audit_event()` calls. The DB-bootstrap prompts add migration audit events.

---

## Prompt Execution Order

```
Phase 1 — Foundation (P01–P03):     Driver swap, repository scaffold, migration runner
Phase 2 — Repository Migration (P04–P07): Resources, Agents, DCR/CIMD, Audit/Config
Phase 3 — Lifecycle Hardening (P08–P09):  Remove create_all, schema-init guard, two-role bootstrap
Phase 4 — Credential Providers (P10–P12): Provider interface, RDS IAM, Entra ID, Vault
Phase 5 — Deploy Targets (P13–P14):       AWS ECS Terraform, Azure ACA Bicep + acasetup.sh
```

Each prompt is self-contained. Clear context between prompts. Commit after each. Do not skip ahead.

---

## Architecture Decisions (Locked Before Execution)

| Decision | Choice | Rationale |
|----------|--------|-----------|
| Driver | `psycopg[binary]` (psycopg3) | Pure-Python with optional C extension. **No greenlet.** Mature, async-capable, actively maintained. |
| Pool | `psycopg_pool.ConnectionPool` (sync) | Matches existing sync codebase. Switch to `AsyncConnectionPool` is a one-liner if we later go async. |
| Migrations | Raw SQL files in `deploy/migrations/sql/` + tiny Python runner `okta_agent_proxy/storage/migrate.py` | DBAs review hand-written SQL. No Alembic in supply chain. Runner is standalone (~150 lines, no SQLAlchemy). |
| Migration tracking | `schema_migrations` table: `(version VARCHAR PK, applied_at TIMESTAMPTZ, checksum VARCHAR)` | Matches Flyway/Sqitch convention. Customers who already use Flyway can drop it in. |
| Repository pattern | Plain classes with explicit SQL via `psycopg.sql.SQL` and `Identifier` | Auditable. No ORM magic. Pydantic models stay; SQLAlchemy models go. |
| `DATABASE_URL` | Stays as the convenience env var **for static-credential mode only** | Backward compat. New `DB_CREDENTIAL_PROVIDER` env var selects provider. When unset, behaves exactly as today. |
| Two-role split | `{prefix}_owner` (DDL, runs migrations) and `{prefix}_app` (DML only) | Default prefix `okta_adapter`. Configurable via `DB_OWNER_ROLE` / `DB_APP_ROLE`. |
| Schema-init failure mode | Adapter probes `schema_migrations` at startup. If table missing or `current_version` < pinned `MIN_SCHEMA_VERSION`, **fail fast with explicit error message naming the migration command**. | No silent runtime DDL. Operator gets a clear, fixable error. |
| Backward compat for SQLAlchemy models file | Delete entirely after P07. Pydantic models that mirror table rows live in `okta_agent_proxy/storage/types.py`. | Single source of truth. No half-migration where both exist. |

---

## Phase 1: Foundation

---

### Prompt P01: Driver swap, dependency cleanup, baseline test pass

**Context:** This prompt only swaps dependencies and verifies the test suite still passes via a thin SQLAlchemy compatibility shim. It does not refactor any application code yet. Goal: get a clean dependency baseline so subsequent prompts can be evaluated cleanly.

**Prompt:**

```
Update the Okta MCP Adapter dependency manifest to prepare for the SQLAlchemy/Alembic removal.

Read these files first to understand current state:
- requirements.txt
- pyproject.toml
- Dockerfile
- okta_agent_proxy/storage/postgres.py (note: imports sqlalchemy at top, uses sessionmaker, Base.metadata.create_all)
- okta_agent_proxy/storage/models.py (12 SQLAlchemy model classes — these stay for now)
- okta_agent_proxy/database.py (also creates an engine)
- alembic.ini and alembic/env.py
- tests/test_postgres_repository.py (1,120 lines — exercises full storage surface)

Execute the following:

1. Add new dependencies to requirements.txt (place ABOVE the existing sqlalchemy/alembic/psycopg2 lines so reviewers see the migration intent):
   psycopg[binary]>=3.2.0
   psycopg-pool>=3.2.0

2. DO NOT remove sqlalchemy, alembic, or psycopg2-binary in this prompt — they remain so the existing code continues to work during the migration. Add a comment block above them in requirements.txt:
   # ---- Scheduled for removal in DB migration prompt P07 ----
   # CWE-121 driver: greenlet ships transitively with sqlalchemy.
   # Do NOT add new code that imports from these. See DB_MIGRATION_PROMPTS.md.
   sqlalchemy>=2.0.0
   psycopg2-binary>=2.9.9
   alembic>=1.13.0
   # ---------------------------------------------------------

3. Create a new constant file okta_agent_proxy/storage/constants.py with:
   - SCHEMA_MIGRATIONS_TABLE = "schema_migrations"
   - MIN_SCHEMA_VERSION = "001"  # bumped as new migrations land
   - DEFAULT_OWNER_ROLE = "okta_adapter_owner"
   - DEFAULT_APP_ROLE = "okta_adapter_app"
   - DEFAULT_DB_NAME = "gateway_db"

4. Add a CI guard script scripts/check_no_new_sqlalchemy_imports.sh. NOTE: the current tree imports sqlalchemy from 10 files, not 4. The allowlist below reflects reality as of P01; it shrinks in P07.
   #!/usr/bin/env bash
   # Prevents new code from importing SQLAlchemy outside the already-known set.
   # During the migration, only these files are allowed to import sqlalchemy.
   # Verify current state with:
   #   grep -rln "from sqlalchemy\|import sqlalchemy" okta_agent_proxy/ tests/ --include="*.py"
   set -e
   ALLOWED_RE='^(okta_agent_proxy/app\.py|okta_agent_proxy/database\.py|okta_agent_proxy/storage/postgres\.py|okta_agent_proxy/storage/models\.py|alembic/env\.py|tests/conftest\.py|tests/test_postgres_repository\.py|tests/test_resource_map_models\.py|tests/test_okta_syncer\.py|tests/test_linkage_model\.py|tests/test_app_lifecycle\.py)$'
   VIOLATIONS=$(grep -rln "from sqlalchemy\|import sqlalchemy" okta_agent_proxy/ tests/ --include="*.py" \
     | grep -v -E "$ALLOWED_RE" || true)
   if [ -n "$VIOLATIONS" ]; then
     echo "ERROR: New SQLAlchemy imports detected in files not on the allowlist:"
     echo "$VIOLATIONS"
     exit 1
   fi
   echo "OK: no new SQLAlchemy imports."

   chmod +x scripts/check_no_new_sqlalchemy_imports.sh

5. Run pip install -r requirements.txt in a clean venv to verify both psycopg3 and the legacy SQLAlchemy/psycopg2 install side-by-side without conflicts.

6. Run the FULL existing test suite: pytest tests/ -x -q
   All tests must pass. If any tests fail because pip resolved a different sub-dependency, pin the failing dep and retry. Do not modify tests in this prompt.

7. Run the new CI guard script: bash scripts/check_no_new_sqlalchemy_imports.sh
   It should print "OK: no new SQLAlchemy imports."

Commit with message: "P01: add psycopg3 alongside SQLAlchemy, add CI guard for new imports"
```

**Expected Output:** psycopg3 installed alongside SQLAlchemy. No code changed. Full suite passes. CI guard script in place.

---

### Prompt P02: Connection pool wrapper and credential-provider stub

**Context:** Introduces the new connection layer. The credential provider abstraction is stubbed here (env-var-only impl) so subsequent prompts can build against the final interface. Real RDS IAM / Entra / Vault impls come in P10–P12.

**Prompt:**

```
Create the new database connection layer for the Okta MCP Adapter, decoupled from SQLAlchemy.

Read first:
- okta_agent_proxy/database.py (current engine factory pattern — note `init_database`, `_engine`, `_SessionLocal`, `get_config_store`)
- okta_agent_proxy/storage/postgres.py:54-86 (current __init__ and engine creation)
- okta_agent_proxy/storage/constants.py (created in P01)
- okta_agent_proxy/audit/events.py (AuditEventType enum pattern)

Execute the following:

1. Create okta_agent_proxy/storage/credentials.py with:

   from abc import ABC, abstractmethod
   from dataclasses import dataclass
   from typing import Optional
   import os
   import logging
   import urllib.parse

   logger = logging.getLogger(__name__)

   @dataclass(frozen=True)
   class DatabaseCredential:
       username: str
       password: str
       host: str
       port: int
       dbname: str
       sslmode: str = "prefer"
       sslrootcert: Optional[str] = None
       # TTL hint in seconds. Pool uses this to decide max connection age.
       # None = static credential, no rotation expected.
       ttl_seconds: Optional[int] = None

       def to_conninfo(self) -> str:
           """psycopg3 conninfo string (key=value form). Password is shell-safe quoted."""
           # Implement using psycopg.conninfo.make_conninfo for proper escaping.

       def to_url(self) -> str:
           """Return libpq URL form for tools that require it (e.g., psql, migration runner)."""

   class DatabaseCredentialProvider(ABC):
       """Provider for database credentials. May return short-lived or static creds."""

       @abstractmethod
       def get_credential(self) -> DatabaseCredential: ...

       @property
       @abstractmethod
       def name(self) -> str: ...

       def supports_rotation(self) -> bool:
           """True if get_credential() may return a fresh password each call."""
           return False

   class StaticUrlCredentialProvider(DatabaseCredentialProvider):
       """Parses DATABASE_URL once. Backward-compatible with current deployments."""
       name = "static_url"

       def __init__(self, database_url: Optional[str] = None):
           url = database_url or os.getenv("DATABASE_URL")
           if not url:
               raise RuntimeError("DATABASE_URL not set; StaticUrlCredentialProvider requires it.")
           parsed = urllib.parse.urlparse(url)
           if parsed.scheme not in ("postgresql", "postgres"):
               raise RuntimeError(f"Unsupported scheme: {parsed.scheme}")
           # Extract sslmode from query string if present
           qs = urllib.parse.parse_qs(parsed.query)
           sslmode = qs.get("sslmode", ["prefer"])[0]
           sslrootcert = qs.get("sslrootcert", [None])[0]
           self._cred = DatabaseCredential(
               username=urllib.parse.unquote(parsed.username or ""),
               password=urllib.parse.unquote(parsed.password or ""),
               host=parsed.hostname or "localhost",
               port=parsed.port or 5432,
               dbname=(parsed.path or "/").lstrip("/") or "postgres",
               sslmode=sslmode,
               sslrootcert=sslrootcert,
               ttl_seconds=None,
           )

       def get_credential(self) -> DatabaseCredential:
           return self._cred

   def get_credential_provider() -> DatabaseCredentialProvider:
       """Factory. Selects provider via DB_CREDENTIAL_PROVIDER env var.
       Values: 'static' (default), 'rds_iam', 'azure_entra', 'vault'.
       The non-static providers are stubs in P02; implemented in P10–P12.
       """
       kind = os.getenv("DB_CREDENTIAL_PROVIDER", "static").lower()
       if kind == "static":
           return StaticUrlCredentialProvider()
       raise NotImplementedError(
           f"DB_CREDENTIAL_PROVIDER='{kind}' is registered but not yet implemented. "
           f"Implementations land in prompts P10 (rds_iam), P11 (azure_entra), P12 (vault)."
       )

2. Create okta_agent_proxy/storage/pool.py with class DatabasePool:

   import logging
   import threading
   from typing import Optional
   from psycopg_pool import ConnectionPool
   from psycopg import Connection
   from psycopg.rows import dict_row
   from .credentials import DatabaseCredentialProvider, DatabaseCredential

   logger = logging.getLogger(__name__)

   class DatabasePool:
       """psycopg3 connection pool with credential-provider integration.

       For static providers, behaves like a normal pool.
       For rotating providers (RDS IAM, Vault), the pool is configured with
       max_lifetime tied to the credential TTL so connections recycle naturally.
       """

       def __init__(
           self,
           credential_provider: DatabaseCredentialProvider,
           min_size: int = 1,
           max_size: int = 10,
           timeout: float = 30.0,
       ):
           self._provider = credential_provider
           self._lock = threading.Lock()
           self._pool: Optional[ConnectionPool] = None
           self._min_size = min_size
           self._max_size = max_size
           self._timeout = timeout
           self._open()

       def _build_conninfo(self) -> str:
           cred = self._provider.get_credential()
           return cred.to_conninfo()

       def _open(self):
           cred = self._provider.get_credential()
           # Connection max age: 80% of credential TTL (with 60s floor) so we
           # rotate cleanly before the credential expires. None TTL = no max age.
           max_lifetime = (
               max(int(cred.ttl_seconds * 0.8), 60) if cred.ttl_seconds else 3600.0
           )
           self._pool = ConnectionPool(
               conninfo=self._build_conninfo(),
               min_size=self._min_size,
               max_size=self._max_size,
               timeout=self._timeout,
               max_lifetime=max_lifetime,
               # For rotating providers, refresh conninfo on each new connection
               configure=self._configure_connection,
               kwargs={"row_factory": dict_row},
               open=True,
           )
           logger.info(
               "DatabasePool opened (provider=%s, host=%s, max_lifetime=%ss, rotates=%s)",
               self._provider.name, cred.host, max_lifetime,
               self._provider.supports_rotation(),
           )

       def _configure_connection(self, conn: Connection):
           # Set search_path, application_name, etc. on each new connection.
           with conn.cursor() as cur:
               cur.execute("SET application_name = %s", ("okta-mcp-adapter",))

       def connection(self):
           """Context manager. Use with `with pool.connection() as conn:`."""
           if not self._pool:
               raise RuntimeError("DatabasePool not initialized")
           return self._pool.connection()

       def close(self):
           with self._lock:
               if self._pool:
                   self._pool.close()
                   self._pool = None

       @property
       def provider_name(self) -> str:
           return self._provider.name

3. Create tests/test_database_pool.py with at least these tests, using a real ephemeral Postgres via pytest-postgresql (already used in repo) OR a Docker-based fixture if pytest-postgresql is not available:
   - test_static_url_provider_parses_database_url
   - test_static_url_provider_parses_sslmode_from_query
   - test_static_url_provider_url_encoded_password (DATABASE_URL with %21 in password decodes to '!')
   - test_database_credential_to_conninfo_quotes_special_chars
   - test_pool_open_close
   - test_pool_executes_simple_query (SELECT 1)
   - test_pool_returns_dict_rows
   - test_get_credential_provider_unknown_raises_not_implemented (set DB_CREDENTIAL_PROVIDER=rds_iam, expect NotImplementedError until P10)

   Target: 12+ tests passing.

4. Add audit event types to okta_agent_proxy/audit/events.py (after the last existing entry):
   # Database lifecycle events (P02–P09)
   DB_POOL_OPENED = "db.pool.opened"
   DB_POOL_CLOSED = "db.pool.closed"
   DB_CREDENTIAL_ROTATED = "db.credential.rotated"
   DB_SCHEMA_VERSION_CHECKED = "db.schema.version_checked"
   DB_SCHEMA_VERSION_MISMATCH = "db.schema.version_mismatch"
   DB_MIGRATION_APPLIED = "db.migration.applied"
   DB_MIGRATION_FAILED = "db.migration.failed"

5. Run pytest tests/test_database_pool.py -v
   Run pytest tests/ -x -q (full suite still green).

Commit: "P02: add psycopg3 connection pool and credential-provider abstraction"
```

**Expected Output:** New `okta_agent_proxy/storage/credentials.py` and `okta_agent_proxy/storage/pool.py`. 12+ new tests passing. Full suite still green. New audit events registered.

---

### Prompt P03: Migration runner and bootstrap SQL

**Context:** Replace Alembic with a small, dependency-free migration runner that applies raw SQL files in order. Convert the three existing Alembic migrations to plain SQL. The runner is what the DBA / CI pipeline will invoke; the application never runs DDL.

**Prompt:**

```
Create the SQL migration runner for the Okta MCP Adapter and convert the three existing Alembic migrations to raw SQL.

Read first:
- alembic/versions/001_initial_schema.py
- alembic/versions/002_dcr_agent_selection.py
- alembic/versions/003_agent_connection_resource_linkage.py
- okta_agent_proxy/storage/models.py (for column type details)
- okta_agent_proxy/storage/constants.py (SCHEMA_MIGRATIONS_TABLE, MIN_SCHEMA_VERSION)
- okta_agent_proxy/storage/pool.py (created in P02)

Execute the following:

1. Create deploy/migrations/sql/ directory. Convert each Alembic migration to a paired up/down SQL file. Naming: {version}__{slug}.up.sql and {version}__{slug}.down.sql.

   Files to create:
   - 001__initial_schema.up.sql
   - 001__initial_schema.down.sql
   - 002__dcr_agent_selection.up.sql
   - 002__dcr_agent_selection.down.sql
   - 003__agent_connection_resource_linkage.up.sql
   - 003__agent_connection_resource_linkage.down.sql

   Translate each op.create_table(...) to CREATE TABLE, op.create_index to CREATE INDEX, op.add_column to ALTER TABLE ADD COLUMN, etc. Use BIGSERIAL where the original used Integer autoincrement, JSONB where the original used JSONB. Verify column types match models.py exactly. Each .up.sql must be idempotent where possible (use IF NOT EXISTS for indexes, CREATE TABLE IF NOT EXISTS where the original migration did not assume a clean DB).

   At the top of each file, add a header comment:
   -- Migration: 001 — initial schema
   -- Author: <git author>
   -- Source: alembic/versions/001_initial_schema.py
   -- Applied to: schema_migrations table on success

2. Create deploy/migrations/sql/000__bootstrap.up.sql for the schema_migrations table itself:

   CREATE TABLE IF NOT EXISTS schema_migrations (
       version          VARCHAR(16) PRIMARY KEY,
       applied_at       TIMESTAMPTZ NOT NULL DEFAULT NOW(),
       applied_by       VARCHAR(255),
       checksum         VARCHAR(64) NOT NULL,
       execution_ms     INTEGER NOT NULL DEFAULT 0
   );

   CREATE INDEX IF NOT EXISTS idx_schema_migrations_applied_at
       ON schema_migrations(applied_at);

   No 000__bootstrap.down.sql — the migration runner never drops this table.

3. Create okta_agent_proxy/storage/migrate.py — the runner. Approximately 200 lines. No SQLAlchemy imports.

   NOTE: Alembic today owns 3 migrations under alembic/versions/: 001_initial_schema.py, 002_dcr_agent_selection.py, 003_agent_connection_resource_linkage.py. No other version files exist. The alembic_version-table references in env.py cover only those three. P07 drops `alembic_version` — the new runner tracks state in `schema_migrations`.

   Module contents:

   import argparse
   import hashlib
   import logging
   import os
   import re
   import sys
   import time
   from dataclasses import dataclass
   from pathlib import Path
   from typing import List, Optional
   import psycopg
   from psycopg import sql

   logger = logging.getLogger(__name__)

   MIGRATION_PATTERN = re.compile(r"^(\d{3})__([a-z0-9_]+)\.up\.sql$")

   @dataclass(frozen=True)
   class Migration:
       version: str
       name: str
       up_path: Path
       down_path: Optional[Path]
       checksum: str

       @classmethod
       def load(cls, up_path: Path) -> "Migration":
           m = MIGRATION_PATTERN.match(up_path.name)
           if not m:
               raise ValueError(f"Invalid migration filename: {up_path.name}")
           version, name = m.group(1), m.group(2)
           up_sql = up_path.read_bytes()
           down_path = up_path.parent / f"{version}__{name}.down.sql"
           return cls(
               version=version,
               name=name,
               up_path=up_path,
               down_path=down_path if down_path.exists() else None,
               checksum=hashlib.sha256(up_sql).hexdigest(),
           )

   def discover_migrations(migrations_dir: Path) -> List[Migration]:
       """Return migrations sorted by version. Excludes 000__bootstrap (applied separately)."""
       found = []
       for p in sorted(migrations_dir.glob("*.up.sql")):
           if p.name.startswith("000__"):
               continue
           found.append(Migration.load(p))
       return sorted(found, key=lambda m: m.version)

   def ensure_bootstrap(conn: psycopg.Connection, migrations_dir: Path) -> None:
       """Create schema_migrations table if missing."""
       bootstrap = migrations_dir / "000__bootstrap.up.sql"
       sql_text = bootstrap.read_text()
       with conn.cursor() as cur:
           cur.execute(sql_text)
       conn.commit()

   def get_applied_versions(conn: psycopg.Connection) -> dict:
       """Return {version: checksum} of applied migrations."""
       with conn.cursor() as cur:
           cur.execute("SELECT version, checksum FROM schema_migrations ORDER BY version")
           return dict(cur.fetchall())

   def get_current_version(conn: psycopg.Connection) -> Optional[str]:
       """Return the highest applied version, or None if none applied."""
       with conn.cursor() as cur:
           cur.execute("SELECT MAX(version) FROM schema_migrations")
           row = cur.fetchone()
           return row[0] if row else None

   def apply_migration(
       conn: psycopg.Connection, migration: Migration, applied_by: str
   ) -> None:
       """Apply one migration in a transaction. Records to schema_migrations on success."""
       logger.info("Applying migration %s — %s", migration.version, migration.name)
       sql_text = migration.up_path.read_text()
       start = time.monotonic()
       try:
           with conn.cursor() as cur:
               cur.execute(sql_text)
               cur.execute(
                   "INSERT INTO schema_migrations (version, applied_at, applied_by, checksum, execution_ms) "
                   "VALUES (%s, NOW(), %s, %s, %s)",
                   (
                       migration.version, applied_by, migration.checksum,
                       int((time.monotonic() - start) * 1000),
                   ),
               )
           conn.commit()
           logger.info("✓ Migration %s applied in %dms", migration.version, int((time.monotonic() - start) * 1000))
       except Exception:
           conn.rollback()
           logger.exception("Migration %s failed; rolled back", migration.version)
           raise

   def upgrade(
       conninfo: str,
       migrations_dir: Path,
       applied_by: str = None,
       target_version: Optional[str] = None,
   ) -> List[str]:
       """Apply all pending migrations (or up to target_version). Returns list of applied versions."""
       applied_by = applied_by or os.getenv("USER", "migrate-runner")
       with psycopg.connect(conninfo) as conn:
           ensure_bootstrap(conn, migrations_dir)
           applied = get_applied_versions(conn)
           pending = [m for m in discover_migrations(migrations_dir) if m.version not in applied]
           if target_version:
               pending = [m for m in pending if m.version <= target_version]
           # Verify checksums of already-applied migrations have not drifted
           for m in discover_migrations(migrations_dir):
               if m.version in applied and applied[m.version] != m.checksum:
                   raise RuntimeError(
                       f"Checksum mismatch for migration {m.version}: file changed after apply. "
                       f"Migrations are immutable. Roll forward with a new version instead."
                   )
           applied_versions = []
           for m in pending:
               apply_migration(conn, m, applied_by)
               applied_versions.append(m.version)
           return applied_versions

   def status(conninfo: str, migrations_dir: Path) -> dict:
       """Return {'current_version': str, 'pending': List[str], 'applied': List[str]}."""
       with psycopg.connect(conninfo) as conn:
           ensure_bootstrap(conn, migrations_dir)
           applied = get_applied_versions(conn)
           all_migrations = discover_migrations(migrations_dir)
           pending = [m.version for m in all_migrations if m.version not in applied]
           return {
               "current_version": max(applied.keys()) if applied else None,
               "applied": sorted(applied.keys()),
               "pending": pending,
           }

   def main():
       parser = argparse.ArgumentParser(description="Okta MCP Adapter SQL migration runner")
       parser.add_argument("command", choices=["upgrade", "status", "version"])
       parser.add_argument("--migrations-dir", default="deploy/migrations/sql")
       parser.add_argument("--target", default=None, help="Stop at this version (inclusive)")
       parser.add_argument("--conninfo", default=os.getenv("DATABASE_URL"),
                           help="psycopg conninfo or libpq URL (default: DATABASE_URL env)")
       parser.add_argument("--applied-by", default=None)
       args = parser.parse_args()

       if not args.conninfo:
           print("ERROR: --conninfo or DATABASE_URL required", file=sys.stderr)
           return 2

       logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
       migrations_dir = Path(args.migrations_dir).resolve()

       if args.command == "upgrade":
           applied = upgrade(args.conninfo, migrations_dir, args.applied_by, args.target)
           print(f"Applied {len(applied)} migration(s): {applied}")
       elif args.command == "status":
           s = status(args.conninfo, migrations_dir)
           print(f"Current version: {s['current_version']}")
           print(f"Applied: {s['applied']}")
           print(f"Pending: {s['pending']}")
       elif args.command == "version":
           with psycopg.connect(args.conninfo) as conn:
               v = get_current_version(conn)
               print(v if v else "(none)")
       return 0

   if __name__ == "__main__":
       sys.exit(main())

4. Update setup.py / pyproject.toml entrypoints to expose the runner:
   [project.scripts]
   okta-adapter-migrate = "okta_agent_proxy.storage.migrate:main"

5. Replace the contents of run_migrations.sh. The CURRENT script runs `docker-compose exec -T okta-agent-mcp-adapter sh -c 'cd /app && alembic upgrade head'` — it shells into the running adapter container. Preserve that Docker-based workflow so existing customer pipelines don't break; add a local-python fallback for CI / bare-metal runs:

   #!/usr/bin/env bash
   # Apply pending SQL migrations. Replaces the prior `alembic upgrade head` call.
   # Usage:
   #   ./run_migrations.sh                 # docker-compose mode (default; matches legacy behavior)
   #   MIGRATION_MODE=local ./run_migrations.sh  # run against $DATABASE_URL from the host
   set -euo pipefail
   MODE="${MIGRATION_MODE:-docker}"
   if [[ "$MODE" == "docker" ]]; then
     echo "Running migrations inside okta-agent-mcp-adapter container..."
     exec docker-compose exec -T okta-agent-mcp-adapter sh -c \
       "cd /app && python -m okta_agent_proxy.storage.migrate upgrade --migrations-dir deploy/migrations/sql $*"
   else
     exec python -m okta_agent_proxy.storage.migrate upgrade --migrations-dir deploy/migrations/sql "$@"
   fi

6. Create tests/test_migrate.py with these tests (use a real ephemeral Postgres):
   - test_discover_migrations_returns_sorted
   - test_discover_migrations_excludes_bootstrap
   - test_apply_migration_records_to_schema_migrations
   - test_apply_migration_rolls_back_on_error
   - test_upgrade_idempotent (running twice applies nothing the second time)
   - test_upgrade_target_version_stops_at_target
   - test_upgrade_checksum_mismatch_raises (modify a migration file after apply, expect RuntimeError)
   - test_status_returns_correct_shape
   - test_get_current_version_empty_returns_none
   - test_bootstrap_table_idempotent
   - test_migrations_001_through_003_match_alembic_schema (apply via runner, then query information_schema.columns and assert column counts/types match what alembic would have produced — use a snapshot of the alembic-generated schema as the baseline)

   Target: 11+ tests passing.

7. Run pytest tests/test_migrate.py -v
   Run pytest tests/ -x -q

8. Verify the migrations work end-to-end against a clean DB:
   docker run -d --name pg-test -e POSTGRES_PASSWORD=test -p 55432:5432 postgres:15
   sleep 5
   DATABASE_URL=postgresql://postgres:test@localhost:55432/postgres bash run_migrations.sh
   DATABASE_URL=postgresql://postgres:test@localhost:55432/postgres python -m okta_agent_proxy.storage.migrate status
   docker rm -f pg-test
   The status output must show all 3 migrations as applied.

Commit: "P03: SQL migration runner replaces Alembic; 3 migrations converted; runner script preserved"
```

**Expected Output:** `deploy/migrations/sql/` populated with bootstrap + 3 paired up/down files. `okta_agent_proxy/storage/migrate.py` runner. New `okta-adapter-migrate` console script. 11+ tests passing. Full suite green.

---

## Phase 2: Repository Migration

The next four prompts replace `PostgresResourceStore` (1,717 lines, 36 methods) with a set of repository classes that use psycopg3 directly. The strategy: build the new repository in parallel with the old store, gate it behind an env var (`STORAGE_BACKEND=psycopg|sqlalchemy`), default to sqlalchemy initially. Each prompt migrates a logical slice and switches its tests to the new backend.

---

### Prompt P04: Resource repository (psycopg3) — first slice

**Context:** Migrate the resource-related methods (`get_all_resources` at postgres.py:131, `get_resource` at :166, `create_resource` at :199, `update_resource` at :285, `delete_resource` at :361, `enable_resource`, `disable_resource`, `_create_audit_log` at :98, `_extract_sensitive_auth_fields` at :262) to a new psycopg3-based repository. Add a feature flag so the old store still runs by default.

**Prompt:**

```
Create the first repository slice (Resources) using psycopg3 directly, behind a feature flag.

Read first:
- okta_agent_proxy/storage/postgres.py lines 98-454 (resource methods, _create_audit_log, _extract_sensitive_auth_fields — note PostgresResourceStore class starts at line 42)
- okta_agent_proxy/storage/base.py (ResourceConfigStore abstract methods)
- okta_agent_proxy/storage/cached_store.py (uses ResourceConfigStore methods)
- okta_agent_proxy/crypto/encryption.py (EncryptionService — preserve verbatim)
- okta_agent_proxy/storage/pool.py (created in P02)
- tests/test_postgres_repository.py (look at the resource-related tests — they need to work against both backends)

Execute the following:

1. Create okta_agent_proxy/storage/repositories/__init__.py (empty module init).

2. Create okta_agent_proxy/storage/repositories/_base.py with helpers shared across repos:

   from contextlib import contextmanager
   from typing import Iterator
   import psycopg
   from okta_agent_proxy.storage.pool import DatabasePool

   class RepositoryBase:
       def __init__(self, pool: DatabasePool, encryption_service):
           self._pool = pool
           self._encryption = encryption_service

       @contextmanager
       def _conn(self) -> Iterator[psycopg.Connection]:
           with self._pool.connection() as conn:
               yield conn

   def write_audit_log(
       conn: psycopg.Connection,
       *, entity_type: str, entity_id: str, action: str,
       changes: dict | None, changed_by: str,
       ip_address: str | None = None, user_agent: str | None = None,
   ) -> None:
       """Insert into audit_log. Mirrors PostgresResourceStore._create_audit_log."""
       import json
       with conn.cursor() as cur:
           cur.execute(
               "INSERT INTO audit_log (entity_type, entity_id, action, changes, changed_by, "
               "changed_at, ip_address, user_agent) "
               "VALUES (%s, %s, %s, %s::jsonb, %s, NOW(), %s, %s)",
               (entity_type, entity_id, action,
                json.dumps(changes) if changes is not None else None,
                changed_by, ip_address, user_agent),
           )

3. Create okta_agent_proxy/storage/repositories/resource_repo.py implementing each resource method that exists in PostgresResourceStore. Critical implementation notes:
   - Use `psycopg.sql.SQL` and `Identifier` only when interpolating identifiers; never f-string SQL with user input.
   - Encryption logic for sensitive fields stays IDENTICAL to PostgresResourceStore — copy verbatim, encrypt to (cipher, iv, tag) byte triplets stored in BYTEA columns.
   - For each method, write the SQL inline. Use `dict_row` factory (already configured in DatabasePool) so SELECTs return dicts.
   - Wrap multi-statement operations in explicit `with conn.transaction():` blocks.
   - Audit log writes go in the same transaction as the change.

   Method signatures must match PostgresResourceStore exactly so the rest of the application is unchanged.

4. Create okta_agent_proxy/storage/psycopg_store.py — a new top-level store class implementing ResourceConfigStore by composing repositories:

   class PsycopgResourceStore(ResourceConfigStore):
       def __init__(self, pool: DatabasePool, encryption_service):
           self._pool = pool
           self._encryption = encryption_service
           self._resources = ResourceRepository(pool, encryption_service)
           # AgentRepository, DcrRepository, etc. added in P05–P07

       def get_all_resources(self):
           return self._resources.list_all()
       def get_resource(self, name):
           return self._resources.get_by_name(name)
       def create_resource(self, name, config, user="admin", ip_address=None, user_agent=None):
           return self._resources.create(name, config, user, ip_address, user_agent)
       # ... resource methods only for now

       # Stubs for non-resource methods that delegate to the legacy store via composition.
       # Set in P05–P07.

5. Update okta_agent_proxy/database.py — modify get_config_store() to read STORAGE_BACKEND env var:

   def get_config_store(database_url=None, encryption_service=None, cache_service=None):
       global _config_store
       if _config_store is not None:
           return _config_store

       backend = os.getenv("STORAGE_BACKEND", "sqlalchemy").lower()
       if encryption_service is None:
           encryption_service = get_encryption_service()

       if backend == "psycopg":
           from okta_agent_proxy.storage.pool import DatabasePool
           from okta_agent_proxy.storage.credentials import get_credential_provider
           from okta_agent_proxy.storage.psycopg_store import PsycopgResourceStore
           pool = DatabasePool(get_credential_provider())
           pg_store = PsycopgResourceStore(pool, encryption_service)
           logger.info("Using STORAGE_BACKEND=psycopg (psycopg3, no SQLAlchemy)")
       elif backend == "sqlalchemy":
           if database_url is None:
               database_url = os.getenv("DATABASE_URL")
           if not database_url:
               raise RuntimeError("DATABASE_URL required for STORAGE_BACKEND=sqlalchemy")
           init_database(database_url)
           pg_store = PostgresResourceStore(database_url=database_url, encryption_service=encryption_service)
           logger.warning(
               "Using STORAGE_BACKEND=sqlalchemy (legacy). Will be removed in DB migration P07."
           )
       else:
           raise RuntimeError(f"Unknown STORAGE_BACKEND: {backend}")

       if cache_service is not None:
           from okta_agent_proxy.storage.cached_store import CachedResourceStore
           _config_store = CachedResourceStore(pg_store, cache_service=cache_service, ttl_seconds=300, encryption_service=encryption_service)
       else:
           _config_store = pg_store
       return _config_store

6. Add a parametrized test suite. In tests/conftest.py, add a fixture:

   @pytest.fixture(params=["sqlalchemy", "psycopg"])
   def both_backends(request, monkeypatch, postgres_url):
       monkeypatch.setenv("STORAGE_BACKEND", request.param)
       monkeypatch.setenv("DATABASE_URL", postgres_url)
       from okta_agent_proxy import database
       database.reset_config_store()
       yield request.param
       database.reset_config_store()

   Then update the existing resource tests in tests/test_postgres_repository.py to use this fixture for the resource methods only (P05+ extend coverage). Keep old tests passing on both backends.

7. Run the full suite under both backends:
   STORAGE_BACKEND=sqlalchemy pytest tests/test_postgres_repository.py -k resource -v
   STORAGE_BACKEND=psycopg pytest tests/test_postgres_repository.py -k resource -v
   Both must pass identically.

   Then: pytest tests/ -x -q (default backend, full suite green).

Commit: "P04: psycopg3 resource repository behind STORAGE_BACKEND flag; tests parametrized"
```

**Expected Output:** Resource methods runnable on either backend. Tests parametrized. Full suite still green on default `STORAGE_BACKEND=sqlalchemy`.

---

### Prompt P05: Agent + DCR repositories

**Context:** Migrate the agent CRUD methods, agent lookups (`get_agent`, `get_agent_by_name`, `get_agent_by_cimd_client_id`, `get_agent_by_client_id`, `create_cimd_agent`, `get_all_agents`, `create_agent`, `update_agent`, `delete_agent`, `enable_agent`, `disable_agent`, `get_agent_audit_log`, `list_agent_resources`) and the DCR registration methods. Largest single slice.

**Prompt:**

```
Migrate the agent and DCR repository methods to psycopg3.

Read first:
- okta_agent_proxy/storage/postgres.py lines ~475-1210 (agent methods + DCR methods; `get_agent_by_cimd_client_id` at :553, `create_cimd_agent` at :642, agent CRUD at ~:800-1000, DCR methods thereafter)
- okta_agent_proxy/storage/repositories/_base.py (created in P04)
- okta_agent_proxy/storage/psycopg_store.py (created in P04)
- tests/test_postgres_repository.py (agent and dcr test sections)

Execute the following:

1. Create okta_agent_proxy/storage/repositories/agent_repo.py implementing every agent method from PostgresResourceStore. Critical:
   - Encryption is identical: client_secret_encrypted/iv/tag, private_key_encrypted/iv/tag.
   - JSON columns (scopes) stored as TEXT with json.dumps/json.loads.
   - get_all_agents must return the list with optional enabled_only filter, same shape as existing.
   - create_cimd_agent flow generates client_id internally — preserve verbatim.

2. Create okta_agent_proxy/storage/repositories/dcr_repo.py for create_dcr_registration, get_dcr_registration, list_dcr_registrations, revoke_dcr_registration, update_dcr_registration_linked_agent.

3. Update okta_agent_proxy/storage/psycopg_store.py to:
   - Instantiate AgentRepository and DcrRepository in __init__
   - Implement all agent and DCR methods on PsycopgResourceStore by delegation
   - Methods not yet migrated (gateway_config, audit log queries, agent_connection_resource_linkage) raise NotImplementedError("migrated in P06")

4. Extend the parametrized test fixture from P04 to cover all agent and DCR tests in tests/test_postgres_repository.py.

5. Critical correctness checks — write at least these new tests (and ensure they pass on both backends):
   - test_agent_create_with_encrypted_client_secret_round_trip
   - test_agent_create_with_encrypted_private_key_round_trip
   - test_agent_update_preserves_unmodified_encrypted_fields
   - test_agent_update_re_encrypts_on_change_with_new_iv (verify iv differs after update)
   - test_get_agent_by_cimd_client_id_case_sensitivity
   - test_dcr_registration_lifecycle_create_revoke_list
   - test_list_agent_resources_returns_resource_names

6. Run:
   STORAGE_BACKEND=sqlalchemy pytest tests/test_postgres_repository.py -v
   STORAGE_BACKEND=psycopg pytest tests/test_postgres_repository.py -v
   pytest tests/ -x -q

Commit: "P05: agent + DCR repositories on psycopg3; both backends pass full repo suite"
```

**Expected Output:** Agent and DCR methods on PsycopgResourceStore. ~30 new tests pass on both backends.

---

### Prompt P06: Audit log, gateway config, linkage repositories

**Context:** Final batch of methods: `get_audit_log`, `get_gateway_config`, `get_gateway_config_entry`, `set_gateway_config`, `delete_gateway_config`, plus the AgentConnectionResourceLinkage cache and the OktaSyncStateModel queries. After this prompt, `PsycopgResourceStore` is feature-complete.

**Prompt:**

```
Migrate the remaining storage methods to psycopg3 and complete PsycopgResourceStore.

Read first:
- okta_agent_proxy/storage/postgres.py lines 1211-1717 (gateway_config methods at :1211-1330, then a second module-level class `ResourceStore` at :1333 with `load_cache()` at :1353 — this is the in-memory cache for AgentConnectionResourceLinkage rows; it is NOT nested inside PostgresResourceStore. Module alias `ResourceMapStore = ResourceStore` at :1716.)
- okta_agent_proxy/storage/models.py (AgentConnectionResourceLinkage at :541, GatewayConfig at :624, OktaSyncStateModel at :603 — for column lists. Note there is NO `ResourceMapModel`; the doc name was aspirational — the real SQLAlchemy model is `AgentConnectionResourceLinkage`, and `Resource` lives in `okta_agent_proxy/resources/models.py`.)

Execute the following:

1. Create okta_agent_proxy/storage/repositories/audit_repo.py with get_audit_log(resource_name=None, limit=100) and get_agent_audit_log(agent_id, limit=100). Both return list[dict].

2. Create okta_agent_proxy/storage/repositories/config_repo.py with get_gateway_config(key), get_gateway_config_entry(key), set_gateway_config(...), delete_gateway_config(...). Preserve the JSON-string-in-TEXT storage convention used today.

3. Create okta_agent_proxy/storage/repositories/linkage_repo.py wrapping the agent_connection_resource_linkage table. Port the module-level `ResourceStore` class from postgres.py (starts at :1333, `load_cache()` at :1353) — it loads the linkage rows into the `_cache_by_connection_id` and `_cache_by_name` dicts. Use psycopg directly; same load/refresh semantics. Preserve the `ResourceMapStore = ResourceStore` module alias so `okta_agent_proxy/app.py:170` keeps working until P07.

4. Create okta_agent_proxy/storage/repositories/sync_state_repo.py for OktaSyncStateModel reads/writes (get_latest, record_sync, etc.).

5. Update PsycopgResourceStore to wire all four new repositories. Remove every NotImplementedError stub. Confirm the class now implements 100% of ResourceConfigStore.

6. Extend test fixture coverage — every test in tests/test_postgres_repository.py must run under both backends.

7. Run the full repository suite under both backends:
   STORAGE_BACKEND=sqlalchemy pytest tests/test_postgres_repository.py -v --tb=short
   STORAGE_BACKEND=psycopg pytest tests/test_postgres_repository.py -v --tb=short
   pytest tests/ -x -q

Commit: "P06: audit/config/linkage/sync_state repositories complete; PsycopgResourceStore is feature-complete"
```

**Expected Output:** Every test in `tests/test_postgres_repository.py` passes on both backends. PsycopgResourceStore has zero NotImplementedError.

---

### Prompt P07: Flip default, delete SQLAlchemy, remove Alembic

**Context:** This is the deletion prompt. Switch `STORAGE_BACKEND` default to `psycopg`, delete `okta_agent_proxy/storage/postgres.py`, `okta_agent_proxy/storage/models.py`, the entire `alembic/` directory, the `psycopg2-binary`, `sqlalchemy`, and `alembic` lines from `requirements.txt`, and the SQLAlchemy fallback path in `database.py`.

**Prompt:**

```
Remove SQLAlchemy and Alembic entirely from the codebase. This is the prompt that eliminates the CWE-121 finding.

Read first:
- requirements.txt (the # Scheduled for removal block from P01)
- okta_agent_proxy/database.py (the if backend == "sqlalchemy" branch)
- okta_agent_proxy/app.py:165-185 (imports `from okta_agent_proxy.database import get_engine` and `from sqlalchemy.orm import sessionmaker as _sa_sessionmaker` — must be replaced with a psycopg-backed ResourceStore constructor)
- tests/conftest.py (session-scoped `test_engine` fixture using SQLite + SQLAlchemy — must be replaced with a psycopg Postgres fixture)
- tests/test_postgres_repository.py, tests/test_resource_map_models.py, tests/test_okta_syncer.py, tests/test_linkage_model.py, tests/test_app_lifecycle.py (all import sqlalchemy — must be rewritten or retired in this prompt)
- alembic/ directory contents
- scripts/check_no_new_sqlalchemy_imports.sh (the allowlist must shrink to empty)

Pre-flight check — these MUST hold before proceeding:
  STORAGE_BACKEND=psycopg pytest tests/ -x -q
  → must pass green. If anything fails, fix in this prompt first; do not proceed to deletion until green.

Execute the following:

1. Update okta_agent_proxy/database.py:
   - Remove the entire `if backend == "sqlalchemy":` branch.
   - Remove the `init_database`, `get_engine`, `get_db`, `_engine`, `_SessionLocal` globals and their helpers.
   - Default STORAGE_BACKEND is now psycopg unconditionally; the env var is honored only for diagnostic logging.
   - Imports: remove `from sqlalchemy import create_engine` and `from sqlalchemy.orm import sessionmaker, Session`.

1b. Update okta_agent_proxy/app.py (lines ~165-185 — the `_resource_store = ResourceStore(_rm_session_factory)` bootstrap):
   - Replace `from okta_agent_proxy.database import get_engine` + `from sqlalchemy.orm import sessionmaker as _sa_sessionmaker` with a psycopg-backed construction path. The new `ResourceStore` (ported in P06) takes the `DatabasePool` from `get_config_store()` rather than a SQLAlchemy session factory.

2. Delete files:
   - rm okta_agent_proxy/storage/postgres.py
   - rm okta_agent_proxy/storage/models.py
   - rm -rf alembic/
   - rm alembic.ini

3. Update okta_agent_proxy/storage/__init__.py — remove any imports of PostgresResourceStore or models.

3b. Rewrite the SQLAlchemy-backed test files to use the psycopg fixture introduced in P02/P04:
   - tests/conftest.py — replace `test_engine` (SQLite) with an ephemeral Postgres fixture (Docker-based or pytest-postgresql); replace `postgres_store` so it returns a `PsycopgResourceStore` seeded via the migration runner.
   - tests/test_resource_map_models.py, tests/test_okta_syncer.py, tests/test_linkage_model.py, tests/test_app_lifecycle.py — rewrite to use the new fixture. These tests currently assert on SQLAlchemy model shapes; replace with psycopg row-dict assertions or Pydantic model assertions from `storage/types.py`.
   - tests/test_postgres_repository.py — drop the SQLAlchemy imports (only `from sqlalchemy.exc import IntegrityError` remains; replace with `psycopg.errors.UniqueViolation` etc.). Drop the `params=["sqlalchemy", "psycopg"]` from the parametrized fixture.

4. Update requirements.txt:
   - Remove the entire "# ---- Scheduled for removal..." comment block.
   - Remove the lines: sqlalchemy>=2.0.0, psycopg2-binary>=2.9.9, alembic>=1.13.0
   - Verify psycopg[binary]>=3.2.0 and psycopg-pool>=3.2.0 are present.

5. Update scripts/check_no_new_sqlalchemy_imports.sh:
   ALLOWED=""  # No files may import sqlalchemy anymore.
   The check now flags ANY sqlalchemy import as a violation.

6. Search the codebase for any remaining SQLAlchemy references:
   grep -rn "sqlalchemy\|alembic\|create_engine\|sessionmaker" okta_agent_proxy/ tests/ scripts/ docs/ --include="*.py" --include="*.md" --include="*.sh"
   - Code references: must be zero. Fix any stragglers.
   - Doc references in docs/ and CLAUDE.md: rewrite to refer to the new migration runner. Don't leave stale instructions about `alembic upgrade head`.

7. Update Dockerfile if it references alembic anywhere (the existing `run_migrations.sh` already calls the new runner from P03; verify nothing else hardcodes alembic).

8. Update tests/test_postgres_repository.py — remove the `params=["sqlalchemy", "psycopg"]` from the `both_backends` fixture; it's now a single backend. Rename fixture if desired.

9. Run the full suite once more — should remain green:
   pytest tests/ -x -q

10. Verify greenlet is gone from a fresh build. Prefer the automated
    check, which runs import probes + a pipdeptree graph audit inside
    the built image and exits non-zero on any regression:

        docker build -t okta-mcp-adapter:p07-test .
        ./scripts/verify_image_clean.sh okta-mcp-adapter:p07-test
        # or via pytest:
        OKTA_ADAPTER_IMAGE=okta-mcp-adapter:p07-test \
            pytest tests/test_image_supply_chain.py -v

    Manual fallback for environments without the script:
        docker run --rm okta-mcp-adapter:p07-test pip show greenlet 2>&1 | head -3
        # Expected: "WARNING: Package(s) not found: greenlet"
        docker run --rm okta-mcp-adapter:p07-test pip show sqlalchemy alembic
        # Expected: both report "not found".

11. Update CHANGELOG.md with an entry under the next release:
    - Removed: SQLAlchemy, Alembic, psycopg2-binary, greenlet (transitive)
    - Added: psycopg3, raw SQL migration runner
    - Resolves: CWE-121 supply-chain finding in greenlet/TStackState.cpp:259
    - Breaking: STORAGE_BACKEND env var is no longer accepted; psycopg3 is the only backend.

Commit: "P07: remove SQLAlchemy, Alembic, psycopg2; CWE-121 (greenlet) finding eliminated"
```

**Expected Output:** Full SQLAlchemy/Alembic/greenlet removal. Container image confirmed clean of all three packages. Suite green on the lone backend.

---

## Phase 3: Lifecycle Hardening

---

### Prompt P08: Remove runtime DDL; add schema-version guard

**Context:** Today the application creates schema on startup. This prompt makes the application fail-fast if the schema is not at the expected version. Operators must run the migration runner separately. This is the change the customers explicitly asked for.

**Prompt:**

```
Stop the application from creating database schema at runtime. Add a fail-fast schema version check.

Read first:
- okta_agent_proxy/storage/psycopg_store.py (current __init__ — ensure no Base.metadata.create_all equivalent; should already be the case post-P07)
- okta_agent_proxy/storage/migrate.py (P03 — has get_current_version helper)
- okta_agent_proxy/storage/constants.py (MIN_SCHEMA_VERSION)
- okta_agent_proxy/app.py (startup sequence — `get_config_store(cache_service=cache_service)` is called at line 112; the ResourceStore bootstrap follows at ~:165)
- okta_agent_proxy/audit/events.py (has DB_SCHEMA_VERSION_CHECKED, DB_SCHEMA_VERSION_MISMATCH from P02)

Execute the following:

1. Create okta_agent_proxy/storage/schema_check.py:

   import logging
   from typing import Optional
   import psycopg
   from okta_agent_proxy.storage.constants import (
       SCHEMA_MIGRATIONS_TABLE, MIN_SCHEMA_VERSION,
   )

   logger = logging.getLogger(__name__)

   class SchemaNotInitializedError(RuntimeError):
       """Raised when the database schema has not been initialized."""

   class SchemaVersionMismatchError(RuntimeError):
       """Raised when the applied schema version is below the minimum required."""

   def verify_schema(pool) -> str:
       """Verify the database schema is at MIN_SCHEMA_VERSION or higher.

       Returns the current applied version on success.
       Raises SchemaNotInitializedError or SchemaVersionMismatchError on failure.
       Both errors carry an explicit message naming the migration command to run.
       """
       try:
           with pool.connection() as conn:
               with conn.cursor() as cur:
                   # Does the schema_migrations table exist?
                   cur.execute(
                       "SELECT to_regclass(%s)", (SCHEMA_MIGRATIONS_TABLE,)
                   )
                   if cur.fetchone()[0] is None:
                       raise SchemaNotInitializedError(
                           f"Database schema is not initialized — table '{SCHEMA_MIGRATIONS_TABLE}' does not exist.\n"
                           f"Run the migration runner against your database BEFORE starting the adapter:\n"
                           f"    python -m okta_agent_proxy.storage.migrate upgrade --conninfo \"$DATABASE_URL\"\n"
                           f"Or with Docker: ./run_migrations.sh\n"
                           f"This adapter intentionally does not create database schema at runtime.\n"
                           f"See docs/OPERATIONS.md § Database Bootstrap."
                       )
                   cur.execute(
                       f"SELECT MAX(version) FROM {SCHEMA_MIGRATIONS_TABLE}"
                   )
                   row = cur.fetchone()
                   current = row[0] if row else None
                   if current is None or current < MIN_SCHEMA_VERSION:
                       raise SchemaVersionMismatchError(
                           f"Database schema version is {current!r} but this build requires {MIN_SCHEMA_VERSION!r} or higher.\n"
                           f"Run pending migrations:\n"
                           f"    python -m okta_agent_proxy.storage.migrate upgrade --conninfo \"$DATABASE_URL\"\n"
                       )
                   logger.info("✓ Database schema verified — current version: %s", current)
                   return current
       except (SchemaNotInitializedError, SchemaVersionMismatchError):
           raise
       except psycopg.Error as e:
           raise RuntimeError(
               f"Failed to verify database schema: {e}\n"
               f"Check that DATABASE_URL is correct and the database is reachable."
           ) from e

2. Update okta_agent_proxy/storage/psycopg_store.py — confirm the constructor does NO DDL, no CREATE TABLE, nothing equivalent to create_all. If any such call is present, remove it.

3. Update okta_agent_proxy/database.py get_config_store() — call verify_schema(pool) immediately after building the pool, BEFORE constructing PsycopgResourceStore. Emit the audit events DB_SCHEMA_VERSION_CHECKED on success, DB_SCHEMA_VERSION_MISMATCH on failure (use emit_audit_event from okta_agent_proxy.audit).

4. Update okta_agent_proxy/app.py (around line 112) — wrap the `get_config_store(cache_service=cache_service)` call in a try/except. On SchemaNotInitializedError or SchemaVersionMismatchError, log the error message verbatim (it's user-facing) and sys.exit(1). Do not let FastAPI start.

5. Update docs/OPERATIONS.md — add a top-level "Database Bootstrap" section that documents the operator workflow:
   - Customer DBA creates the database and the two roles (owner + app) — see P09 for SQL.
   - Customer DBA (or CI pipeline) runs `okta-adapter-migrate upgrade` as the owner role.
   - Container image starts with the app role, never has DDL grants, fails fast if schema is missing.
   Include a copy-pasteable example for both psql and the runner.

6. Tests in tests/test_schema_check.py:
   - test_verify_schema_success_returns_current_version
   - test_verify_schema_missing_table_raises_not_initialized
   - test_verify_schema_old_version_raises_mismatch (insert a version < MIN, expect SchemaVersionMismatchError)
   - test_verify_schema_unreachable_db_raises_runtime_error
   - test_app_startup_exits_when_schema_missing (subprocess test or via TestClient context-manager)

7. Run pytest tests/test_schema_check.py -v
   Run pytest tests/ -x -q

Commit: "P08: remove runtime DDL; fail-fast schema version check"
```

**Expected Output:** Adapter no longer creates schema at startup. Clear, actionable error if migrations have not been run. Audit events emitted.

---

### Prompt P09: Two-role bootstrap SQL and operations runbook

**Context:** Provide the SQL the customer DBA runs to set up two least-privilege roles. Document the workflow.

**Prompt:**

```
Add the two-role bootstrap SQL and the operator runbook for least-privilege deployment.

Read first:
- okta_agent_proxy/storage/constants.py (DEFAULT_OWNER_ROLE, DEFAULT_APP_ROLE, DEFAULT_DB_NAME)
- deploy/migrations/sql/001__initial_schema.up.sql (knows the table list)
- docs/OPERATIONS.md (Database Bootstrap section from P08)

Execute the following:

1. Create deploy/migrations/sql/bootstrap_roles.sql — runs ONCE per database, BEFORE any migrations:

   -- ===========================================================================
   -- Two-role bootstrap for the Okta MCP Adapter database.
   --
   -- Run this ONCE as a Postgres superuser (typically rds_superuser on AWS,
   -- or the postgres role on a self-hosted cluster) BEFORE running migrations.
   --
   -- Customize the role names if your shop uses different naming conventions —
   -- the adapter reads DB_OWNER_ROLE and DB_APP_ROLE env vars.
   -- ===========================================================================

   -- Configurable identifiers. Override with psql -v before running.
   \set ON_ERROR_STOP on
   \set owner_role  `echo "${DB_OWNER_ROLE:-okta_adapter_owner}"`
   \set app_role    `echo "${DB_APP_ROLE:-okta_adapter_app}"`
   \set db_name     `echo "${DB_NAME:-gateway_db}"`

   -- Role 1: schema owner. Used ONLY by the migration runner.
   -- Has DDL on the database; should not be used by the running application.
   DO $$ BEGIN
     IF NOT EXISTS (SELECT FROM pg_roles WHERE rolname = :'owner_role') THEN
       EXECUTE format('CREATE ROLE %I LOGIN', :'owner_role');
     END IF;
   END $$;

   -- Role 2: application runtime. DML only, no DDL.
   DO $$ BEGIN
     IF NOT EXISTS (SELECT FROM pg_roles WHERE rolname = :'app_role') THEN
       EXECUTE format('CREATE ROLE %I LOGIN', :'app_role');
     END IF;
   END $$;

   -- Owner gets full DDL on the database.
   GRANT ALL PRIVILEGES ON DATABASE :"db_name" TO :"owner_role";

   -- App role: connect to the DB and use the public schema.
   GRANT CONNECT ON DATABASE :"db_name" TO :"app_role";
   GRANT USAGE ON SCHEMA public TO :"app_role";

   -- Default privileges: any future tables created by the owner are auto-granted to app.
   ALTER DEFAULT PRIVILEGES FOR ROLE :"owner_role" IN SCHEMA public
     GRANT SELECT, INSERT, UPDATE, DELETE ON TABLES TO :"app_role";
   ALTER DEFAULT PRIVILEGES FOR ROLE :"owner_role" IN SCHEMA public
     GRANT USAGE, SELECT ON SEQUENCES TO :"app_role";

   -- Idempotent grant for any existing tables (in case migrations have already run).
   GRANT SELECT, INSERT, UPDATE, DELETE ON ALL TABLES IN SCHEMA public TO :"app_role";
   GRANT USAGE, SELECT ON ALL SEQUENCES IN SCHEMA public TO :"app_role";

   -- App role explicitly does NOT get CREATE on the schema.
   REVOKE CREATE ON SCHEMA public FROM :"app_role";

   \echo 'Bootstrap complete.'
   \echo 'Owner role:' :owner_role
   \echo 'App role:  ' :app_role

2. Add a deploy/migrations/sql/README.md with the operator workflow:

   # Database Bootstrap

   ## One-time setup (run as DBA / superuser)

   1. Create the database:
      ```bash
      createdb gateway_db
      ```

   2. Create the two roles and grant privileges:
      ```bash
      DB_OWNER_ROLE=okta_adapter_owner \
      DB_APP_ROLE=okta_adapter_app \
      DB_NAME=gateway_db \
      psql -d gateway_db -f deploy/migrations/sql/bootstrap_roles.sql
      ```

   3. Set passwords (or skip if using AWS RDS IAM / Azure Entra / Vault — see P10–P12):
      ```sql
      ALTER ROLE okta_adapter_owner PASSWORD '<rotate-me>';
      ALTER ROLE okta_adapter_app   PASSWORD '<rotate-me>';
      ```

   ## Per-deployment (run by CI/CD or DBA)

   Apply pending migrations using the **owner** role:
   ```bash
   DATABASE_URL=postgresql://okta_adapter_owner:<pwd>@host/gateway_db?sslmode=require \
     python -m okta_agent_proxy.storage.migrate upgrade
   ```

   ## Application runtime

   The adapter container runs as the **app** role only:
   ```bash
   DATABASE_URL=postgresql://okta_adapter_app:<pwd>@host/gateway_db?sslmode=require
   ```

   The adapter will NOT create or modify schema. If the app role is granted DDL by accident, that's a misconfiguration — revoke it.

3. Update okta_agent_proxy/storage/credentials.py — extend StaticUrlCredentialProvider so it logs a warning if the parsed username matches DEFAULT_OWNER_ROLE or its equivalent (the application should run as app, not owner).

4. Add tests/test_bootstrap_roles.py:
   - test_bootstrap_roles_idempotent (run script twice, second run is a no-op)
   - test_app_role_cannot_create_table (connect as app, attempt CREATE TABLE, expect insufficient privilege)
   - test_app_role_can_select_insert_update_delete (full DML works)
   - test_owner_role_can_create_table_and_app_inherits_privileges (default privileges work)

5. Run pytest tests/test_bootstrap_roles.py -v
   Run pytest tests/ -x -q

Commit: "P09: two-role bootstrap SQL with default privileges; operator runbook"
```

**Expected Output:** `bootstrap_roles.sql` script. Documented operator workflow. Tests verify least-privilege.

---

## Phase 4: Credential Providers

---

### Prompt P10: AWS RDS IAM credential provider

**Context:** Implement `RdsIamCredentialProvider` so AWS deployments can drop the static password entirely. The provider calls `rds.generate_db_auth_token()` (boto3) on each `get_credential()` call; tokens are valid for 15 minutes.

**Prompt:**

```
Implement the AWS RDS IAM database credential provider.

Read first:
- okta_agent_proxy/storage/credentials.py (DatabaseCredentialProvider, get_credential_provider — created in P02)
- okta_agent_proxy/storage/pool.py (DatabasePool — uses ttl_seconds for max_lifetime)

Execute the following:

1. Add to requirements.txt:
   boto3>=1.34.0

   (boto3 may already be present for other reasons; if so, ensure version constraint.)

2. Create okta_agent_proxy/storage/credentials_rds.py:

   import logging
   import os
   from typing import Optional
   import boto3
   from .credentials import DatabaseCredential, DatabaseCredentialProvider

   logger = logging.getLogger(__name__)

   class RdsIamCredentialProvider(DatabaseCredentialProvider):
       """AWS RDS IAM database authentication.
       Token TTL is 15 minutes; pool max_lifetime is set accordingly.

       Required env vars:
           DB_HOST          - RDS endpoint (no port)
           DB_PORT          - default 5432
           DB_NAME          - database name
           DB_USERNAME      - IAM-enabled DB user (must have rds_iam role granted)
           AWS_REGION       - region of the RDS instance
           DB_SSLROOTCERT   - path to RDS CA bundle (default /opt/rds-ca/global-bundle.pem)
       """
       name = "rds_iam"

       def __init__(self):
           self._host = os.environ["DB_HOST"]
           self._port = int(os.environ.get("DB_PORT", "5432"))
           self._dbname = os.environ["DB_NAME"]
           self._username = os.environ["DB_USERNAME"]
           self._region = os.environ.get("AWS_REGION") or os.environ["AWS_DEFAULT_REGION"]
           self._sslrootcert = os.environ.get(
               "DB_SSLROOTCERT", "/opt/rds-ca/global-bundle.pem"
           )
           self._client = boto3.client("rds", region_name=self._region)

       def get_credential(self) -> DatabaseCredential:
           token = self._client.generate_db_auth_token(
               DBHostname=self._host,
               Port=self._port,
               DBUsername=self._username,
               Region=self._region,
           )
           logger.debug("Generated RDS IAM auth token (15-min TTL)")
           return DatabaseCredential(
               username=self._username,
               password=token,
               host=self._host,
               port=self._port,
               dbname=self._dbname,
               sslmode="verify-full",
               sslrootcert=self._sslrootcert,
               ttl_seconds=900,  # 15 minutes
           )

       def supports_rotation(self) -> bool:
           return True

3. Update okta_agent_proxy/storage/credentials.py get_credential_provider():
   if kind == "rds_iam":
       from .credentials_rds import RdsIamCredentialProvider
       return RdsIamCredentialProvider()

4. Update okta_agent_proxy/storage/pool.py — when supports_rotation() is True, the pool's `_build_conninfo` callback must be passed to ConnectionPool so each new connection gets a fresh token. psycopg_pool's ConnectionPool accepts a `conninfo` callable variant via the `conninfo` factory pattern OR the `reconnect_failed` hook. Confirm against psycopg_pool 3.2 docs and pick the simplest correct path.

   The cleanest approach: subclass-style. Set `_pool.conninfo_factory = self._build_conninfo` and ensure DatabasePool refreshes conninfo on each new connection (overriding the configure callback if needed).

5. Add Dockerfile change to ship the RDS CA bundle:
   # In the runtime stage, after apt-get install of curl:
   RUN curl -fsSL -o /opt/rds-ca/global-bundle.pem \
       https://truststore.pki.rds.amazonaws.com/global/global-bundle.pem \
       || mkdir -p /opt/rds-ca

   Wrap with INSTALL_RDS_CA build arg defaulting to true; non-AWS deployments can pass --build-arg INSTALL_RDS_CA=false.

6. Tests in tests/test_credentials_rds.py — these are mocked because real RDS IAM testing requires AWS credentials:
   - test_rds_provider_calls_generate_db_auth_token (mock boto3 client, assert called with right args)
   - test_rds_provider_returns_credential_with_15min_ttl
   - test_rds_provider_supports_rotation_true
   - test_rds_provider_uses_verify_full_sslmode
   - test_get_credential_returns_fresh_token_each_call (call get_credential twice, assert two distinct tokens)
   - test_pool_max_lifetime_respects_credential_ttl (open pool with rotating provider, assert max_lifetime ≈ 720s = 80% of 900)
   - test_missing_env_vars_raises_clear_error

7. Update docs/OPERATIONS.md with an "AWS RDS IAM" section: how to enable rds_iam on the RDS instance, how to grant rds_iam to the role, the IAM policy the ECS task role needs (rds-db:connect resource ARN), and the env vars to set.

8. Run pytest tests/test_credentials_rds.py -v
   Run pytest tests/ -x -q

Commit: "P10: AWS RDS IAM credential provider; pool refreshes conninfo on rotation"
```

**Expected Output:** RDS IAM provider implemented and tested. Pool correctly recycles connections at 80% of token TTL.

---

### Prompt P11: Azure Entra ID (Microsoft Entra) credential provider

**Context:** Implement `AzureEntraCredentialProvider` for Azure Postgres Flexible Server with Entra ID authentication. The provider uses `DefaultAzureCredential` to get an Azure AD token and uses it as the database password. Tokens are valid ~1 hour.

**Prompt:**

```
Implement the Azure Entra ID database credential provider for Azure Database for PostgreSQL.

Read first:
- okta_agent_proxy/storage/credentials.py
- okta_agent_proxy/storage/credentials_rds.py (P10 — same pattern)
- okta_agent_proxy/storage/pool.py

Execute the following:

1. Add to requirements.txt:
   azure-identity>=1.15.0

2. Create okta_agent_proxy/storage/credentials_azure.py:

   import logging
   import os
   from azure.identity import DefaultAzureCredential
   from .credentials import DatabaseCredential, DatabaseCredentialProvider

   logger = logging.getLogger(__name__)

   AZURE_POSTGRES_SCOPE = "https://ossrdbms-aad.database.windows.net/.default"

   class AzureEntraCredentialProvider(DatabaseCredentialProvider):
       """Azure Postgres Flexible Server with Entra ID authentication.
       Tokens are typically valid for ~1 hour.

       Required env vars:
           DB_HOST       - <server>.postgres.database.azure.com
           DB_PORT       - default 5432
           DB_NAME       - database name
           DB_USERNAME   - Entra principal username (e.g. user@tenant.onmicrosoft.com,
                          or the managed identity's display name)

       Authentication: uses DefaultAzureCredential, which respects:
           - Managed Identity (preferred in Azure Container Apps / AKS)
           - AZURE_CLIENT_ID / AZURE_CLIENT_SECRET / AZURE_TENANT_ID (service principal)
           - Azure CLI (developer machines)
       """
       name = "azure_entra"

       def __init__(self):
           self._host = os.environ["DB_HOST"]
           self._port = int(os.environ.get("DB_PORT", "5432"))
           self._dbname = os.environ["DB_NAME"]
           self._username = os.environ["DB_USERNAME"]
           self._credential = DefaultAzureCredential()

       def get_credential(self) -> DatabaseCredential:
           token_obj = self._credential.get_token(AZURE_POSTGRES_SCOPE)
           # token_obj.expires_on is an absolute Unix timestamp.
           import time
           ttl = max(int(token_obj.expires_on - time.time()), 60)
           logger.debug("Acquired Entra ID token for Postgres (ttl=%ds)", ttl)
           return DatabaseCredential(
               username=self._username,
               password=token_obj.token,
               host=self._host,
               port=self._port,
               dbname=self._dbname,
               sslmode="require",  # Azure Postgres requires SSL by default
               sslrootcert=None,
               ttl_seconds=ttl,
           )

       def supports_rotation(self) -> bool:
           return True

3. Update get_credential_provider():
   if kind == "azure_entra":
       from .credentials_azure import AzureEntraCredentialProvider
       return AzureEntraCredentialProvider()

4. Tests in tests/test_credentials_azure.py:
   - test_azure_provider_uses_correct_scope
   - test_azure_provider_returns_token_as_password
   - test_azure_provider_ttl_derived_from_token_expiry
   - test_azure_provider_supports_rotation_true
   - test_azure_provider_sslmode_require
   - test_azure_provider_get_credential_called_twice_returns_fresh_token
   - test_missing_env_vars_raises_clear_error

   All mocked via patching DefaultAzureCredential.

5. Update docs/OPERATIONS.md with an "Azure Entra ID" section:
   - Enable Microsoft Entra authentication on the Postgres Flexible Server
   - Add the managed identity (or service principal) as an Entra admin OR a regular DB user
   - Grant the role privileges via psql while connected with another Entra admin
   - Env vars to set in the Container App

6. Run pytest tests/test_credentials_azure.py -v
   Run pytest tests/ -x -q

Commit: "P11: Azure Entra ID database credential provider"
```

**Expected Output:** Azure Entra provider implemented and tested.

---

### Prompt P12: HashiCorp Vault dynamic database credentials

**Context:** Implement `VaultDbCredentialProvider` using Vault's database secrets engine. Vault generates a unique short-lived database role on each request. The TTL is configured in Vault and returned in the response.

**Prompt:**

```
Implement the HashiCorp Vault database credential provider using the database secrets engine.

Read first:
- okta_agent_proxy/storage/credentials.py
- okta_agent_proxy/storage/credentials_rds.py
- okta_agent_proxy/storage/credentials_azure.py

Execute the following:

1. Add to requirements.txt:
   hvac>=2.1.0

2. Create okta_agent_proxy/storage/credentials_vault.py:

   import logging
   import os
   import threading
   import time
   from typing import Optional
   import hvac
   from .credentials import DatabaseCredential, DatabaseCredentialProvider

   logger = logging.getLogger(__name__)

   class VaultDbCredentialProvider(DatabaseCredentialProvider):
       """HashiCorp Vault database secrets engine — dynamic credentials.

       Required env vars:
           DB_HOST            - Postgres host
           DB_PORT            - default 5432
           DB_NAME            - database name
           VAULT_ADDR         - https://vault.example.com:8200
           VAULT_DB_MOUNT     - mount path (default 'database')
           VAULT_DB_ROLE      - configured role name (e.g. 'okta-adapter-app')

       Authentication (one of):
           VAULT_TOKEN                 - static token (dev only)
           VAULT_K8S_AUTH_PATH +
             VAULT_K8S_ROLE +
             K8S_SA_TOKEN_PATH         - Kubernetes auth (default in K8s)
           VAULT_APPROLE_ROLE_ID +
             VAULT_APPROLE_SECRET_ID   - AppRole auth

       Credential caching: returns the same credential until ~80% of its lease has elapsed,
       then requests a new one. This avoids hammering Vault on every connection.
       """
       name = "vault"

       def __init__(self):
           self._host = os.environ["DB_HOST"]
           self._port = int(os.environ.get("DB_PORT", "5432"))
           self._dbname = os.environ["DB_NAME"]
           self._mount = os.environ.get("VAULT_DB_MOUNT", "database")
           self._role = os.environ["VAULT_DB_ROLE"]
           self._client = self._build_client()
           self._lock = threading.Lock()
           self._cached: Optional[DatabaseCredential] = None
           self._cached_until: float = 0.0

       def _build_client(self) -> hvac.Client:
           addr = os.environ["VAULT_ADDR"]
           c = hvac.Client(url=addr)
           if os.environ.get("VAULT_TOKEN"):
               c.token = os.environ["VAULT_TOKEN"]
           elif os.environ.get("VAULT_K8S_ROLE"):
               sa_token_path = os.environ.get(
                   "K8S_SA_TOKEN_PATH",
                   "/var/run/secrets/kubernetes.io/serviceaccount/token",
               )
               with open(sa_token_path) as f:
                   sa_token = f.read().strip()
               c.auth.kubernetes.login(
                   role=os.environ["VAULT_K8S_ROLE"],
                   jwt=sa_token,
                   mount_point=os.environ.get("VAULT_K8S_AUTH_PATH", "kubernetes"),
               )
           elif os.environ.get("VAULT_APPROLE_ROLE_ID"):
               c.auth.approle.login(
                   role_id=os.environ["VAULT_APPROLE_ROLE_ID"],
                   secret_id=os.environ["VAULT_APPROLE_SECRET_ID"],
               )
           else:
               raise RuntimeError(
                   "Vault credential provider: no auth method configured. "
                   "Set one of VAULT_TOKEN, VAULT_K8S_ROLE, VAULT_APPROLE_ROLE_ID."
               )
           if not c.is_authenticated():
               raise RuntimeError("Vault credential provider: authentication failed")
           return c

       def _request_new_credential(self) -> DatabaseCredential:
           resp = self._client.secrets.database.generate_credentials(
               name=self._role, mount_point=self._mount
           )
           data = resp["data"]
           lease_duration = int(resp.get("lease_duration", 3600))
           logger.info(
               "Vault issued DB credential username=%s lease=%ds",
               data["username"], lease_duration,
           )
           return DatabaseCredential(
               username=data["username"],
               password=data["password"],
               host=self._host,
               port=self._port,
               dbname=self._dbname,
               sslmode=os.environ.get("DB_SSLMODE", "require"),
               sslrootcert=os.environ.get("DB_SSLROOTCERT"),
               ttl_seconds=lease_duration,
           )

       def get_credential(self) -> DatabaseCredential:
           now = time.monotonic()
           with self._lock:
               if self._cached and now < self._cached_until:
                   return self._cached
               cred = self._request_new_credential()
               self._cached = cred
               # Refresh at 80% of lease
               self._cached_until = now + (cred.ttl_seconds * 0.8)
               return cred

       def supports_rotation(self) -> bool:
           return True

3. Update get_credential_provider():
   if kind == "vault":
       from .credentials_vault import VaultDbCredentialProvider
       return VaultDbCredentialProvider()

4. Tests in tests/test_credentials_vault.py (mock hvac.Client):
   - test_vault_provider_uses_token_auth_when_set
   - test_vault_provider_uses_k8s_auth_when_role_set
   - test_vault_provider_uses_approle_auth_when_role_id_set
   - test_vault_provider_no_auth_raises_clear_error
   - test_generate_credentials_called_with_role_and_mount
   - test_credential_cached_until_80_percent_lease
   - test_credential_refreshed_after_lease_window
   - test_supports_rotation_true

5. Update docs/OPERATIONS.md with a "HashiCorp Vault" section. Include:
   - The Vault role configuration (creation_statements that grant the same DML privileges as the static app role).
   - The DB connection-config Vault needs.
   - All three auth-method env-var sets with examples.
   - Note: in production, prefer Kubernetes auth or AppRole; never use VAULT_TOKEN outside dev.

6. Run pytest tests/test_credentials_vault.py -v
   Run pytest tests/ -x -q

Commit: "P12: HashiCorp Vault dynamic DB credential provider with caching"
```

**Expected Output:** Vault provider with caching, three auth methods, tests passing.

---

## Phase 5: Deploy Targets

These two prompts update the AWS ECS Terraform and the Azure ACA Bicep + `acasetup.sh` so the new deployments use IAM/Entra by default and run a one-shot migration job before the adapter starts.

---

### Prompt P13: AWS ECS Terraform — RDS IAM, two roles, migration task

**Context:** Update `deploy/aws-ecs/main.tf` so the RDS instance has IAM authentication enabled, the ECS task role can call `rds-db:connect`, the adapter task uses `DB_CREDENTIAL_PROVIDER=rds_iam`, and a separate one-shot ECS task runs migrations as the owner role before each deploy.

**Prompt:**

```
Update the AWS ECS Terraform deployment to use RDS IAM authentication, two database roles, and a pre-deploy migration task.

Read first:
- deploy/aws-ecs/main.tf (current RDS provisioning at line ~564, secrets at ~680, adapter task definition)
- deploy/aws-ecs/variables.tf
- deploy/aws-ecs/iam/ (existing IAM JSON)
- deploy/aws-ecs/deploy-adapter.sh
- deploy/aws-ecs/buildspec.yml
- okta_agent_proxy/storage/credentials_rds.py (P10)
- deploy/migrations/sql/bootstrap_roles.sql (P09)

Execute the following:

1. Update the aws_db_instance resource in main.tf:
   - Add iam_database_authentication_enabled = true
   - Keep the random_password for the master user (still needed for break-glass admin access)
   - Add a comment block above the resource explaining that the master password is for emergencies only; the application uses RDS IAM

2. Add new Terraform resources for the two-role bootstrap:

   # IAM-enabled DB roles. Created by a Lambda or ECS task that runs once after RDS is up.
   # We use a null_resource + local-exec calling psql via the bastion or a CodeBuild job.
   # Simplest correct path: use an ECS one-shot task that runs the bootstrap_roles.sql + migrations.

   resource "aws_iam_role" "db_owner" {
     name               = "${local.project_name}-db-owner-task"
     assume_role_policy = data.aws_iam_policy_document.ecs_task_assume.json
   }

   data "aws_iam_policy_document" "db_owner_iam_connect" {
     statement {
       actions = ["rds-db:connect"]
       # Owner connects with master credentials, not IAM, BUT we still want the
       # task role to be discoverable for audit. Grant rds-db:connect to the owner DB user
       # so the owner role itself is also IAM-eligible.
       resources = [
         "arn:aws:rds-db:${var.aws_region}:${data.aws_caller_identity.current.account_id}:dbuser:${aws_db_instance.this.resource_id}/${var.db_owner_role}"
       ]
     }
   }

   resource "aws_iam_role" "adapter_task" {
     # may already exist — extend its policy
   }

   # Add to the adapter task role:
   data "aws_iam_policy_document" "adapter_rds_connect" {
     statement {
       actions   = ["rds-db:connect"]
       resources = [
         "arn:aws:rds-db:${var.aws_region}:${data.aws_caller_identity.current.account_id}:dbuser:${aws_db_instance.this.resource_id}/${var.db_app_role}"
       ]
     }
   }

3. Add new variables to variables.tf:
   variable "db_owner_role" {
     description = "Database role used for migrations (DDL). IAM-enabled."
     default     = "okta_adapter_owner"
   }
   variable "db_app_role" {
     description = "Database role used by the adapter at runtime (DML only). IAM-enabled."
     default     = "okta_adapter_app"
   }
   variable "use_rds_iam" {
     description = "If true, use RDS IAM authentication instead of static passwords."
     type        = bool
     default     = true
   }

4. Replace the DATABASE_URL Secrets Manager value when use_rds_iam is true:
   - When use_rds_iam = true, the adapter task definition gets these env vars (no password in DATABASE_URL):
       DB_CREDENTIAL_PROVIDER = "rds_iam"
       DB_HOST                = aws_db_instance.this.address
       DB_PORT                = "5432"
       DB_NAME                = aws_db_instance.this.db_name
       DB_USERNAME            = var.db_app_role
       AWS_REGION             = var.aws_region
       DB_SSLROOTCERT         = "/opt/rds-ca/global-bundle.pem"
   - When use_rds_iam = false (legacy), keep the existing DATABASE_URL secret.

5. Add a one-shot migration task definition. It runs:
   bootstrap_roles.sql (idempotent) then `okta-adapter-migrate upgrade`.

   resource "aws_ecs_task_definition" "migrate" {
     family                   = "${local.project_name}-migrate"
     requires_compatibilities = ["FARGATE"]
     cpu                      = "256"
     memory                   = "512"
     network_mode             = "awsvpc"
     task_role_arn            = aws_iam_role.db_owner.arn
     execution_role_arn       = aws_iam_role.ecs_execution.arn
     container_definitions = jsonencode([{
       name  = "migrate"
       image = "${var.adapter_ecr_repo_url}:${var.image_tag}"
       command = [
         "/bin/sh", "-c",
         "psql \"$BOOTSTRAP_URL\" -f /app/deploy/migrations/sql/bootstrap_roles.sql && python -m okta_agent_proxy.storage.migrate upgrade --conninfo \"$DATABASE_URL\""
       ]
       environment = [
         { name = "DB_OWNER_ROLE", value = var.db_owner_role },
         { name = "DB_APP_ROLE",   value = var.db_app_role },
         { name = "DB_NAME",       value = aws_db_instance.this.db_name },
       ]
       secrets = [
         # BOOTSTRAP_URL = master credentials for one-time role creation
         { name = "BOOTSTRAP_URL", valueFrom = "${aws_secretsmanager_secret.db_master.arn}:URL::" },
         # DATABASE_URL = owner role for migrations (after first bootstrap)
         { name = "DATABASE_URL", valueFrom = "${aws_secretsmanager_secret.db_owner_url.arn}:URL::" },
       ]
       logConfiguration = {
         logDriver = "awslogs"
         options = {
           awslogs-group         = aws_cloudwatch_log_group.adapter.name
           awslogs-region        = var.aws_region
           awslogs-stream-prefix = "migrate"
         }
       }
     }])
   }

   For first deploy: BOOTSTRAP_URL holds master creds; subsequent deploys use the owner DATABASE_URL.

6. Update deploy.sh / deploy-adapter.sh:
   - Add a `--migrate` step that runs the migrate task and waits for it to complete BEFORE updating the adapter service.
   - Use `aws ecs run-task ... --launch-type FARGATE` and poll task status until STOPPED, then check exit code.
   - Fail the deploy if migration exits non-zero.

7. Update Dockerfile: ensure psql is in the runtime image (apt-get install postgresql-client). The migrate task uses it for bootstrap_roles.sql.

8. Add a Terraform output:
   output "migrate_task_definition_arn" {
     value = aws_ecs_task_definition.migrate.arn
   }

9. Update deploy/aws-ecs/README.md:
   - New section "RDS IAM Authentication" explaining the default behavior.
   - New section "Migration Task" explaining the pre-deploy migration step.
   - Document `--migrate` flag and how to run migrations independently.
   - Document how to disable RDS IAM (use_rds_iam=false) if a customer needs the legacy static-password path.

10. terraform fmt and terraform validate must pass on the updated module.

Commit: "P13: AWS ECS — RDS IAM auth, two-role bootstrap, one-shot migrate task"
```

**Expected Output:** Updated Terraform module with IAM auth as default, separate migrate task, two roles. `terraform validate` passes.

---

### Prompt P14: Azure ACA Bicep + scripts/deploy.sh — Entra auth, two roles, migration job

**Context:** Update `deploy/azure-aca/bicep/main.bicep` + `bicep/modules/database.bicep` + `bicep/modules/identity.bicep` + `bicep/modules/apps.bicep` so the Postgres Flexible Server has Entra authentication enabled, and update `scripts/deploy.sh` (the real deploy wrapper — `acasetup.sh` is a 62-line deprecated shim that `exec`s into it) so Phase 3a sets up the two roles and Phase 3c runs a migration job (as a Container Apps Job, not a long-running app).

**Prompt:**

```
Update the Azure Container Apps deployment to use Entra ID authentication, two database roles, and a pre-deploy migration job.

Read first:
- deploy/azure-aca/bicep/main.bicep (top-level wrapper; Postgres params at :84-107 `useExistingPostgres`/`postgresAdminUser`/`postgresAdminPassword`/`postgresDatabaseName`/`postgresSkuName`, database module wired at :348-357, output `postgresServerFqdn` at :488)
- deploy/azure-aca/bicep/modules/database.bicep (the actual Postgres Flexible Server resource lives here)
- deploy/azure-aca/bicep/modules/identity.bicep (user-assigned managed identities)
- deploy/azure-aca/bicep/modules/apps.bicep (Container Apps; adapter app env vars + `database-url` secret live here, NOT in main.bicep)
- deploy/azure-aca/scripts/deploy.sh (the REAL wrapper — Phase 3a creates infra, 3b az acr build, 3c deploys apps). Note: `deploy/azure-aca/acasetup.sh` is a deprecated compatibility shim that `exec`s `scripts/deploy.sh`; do NOT edit acasetup.sh.
- deploy/azure-aca/shell-lib/ (common.sh, azure-helpers.sh, bicep-helpers.sh)
- deploy/azure-aca/scripts/deploy-adapter.sh
- okta_agent_proxy/storage/credentials_azure.py (P11)

Execute the following:

1. Update bicep/modules/database.bicep (the Postgres Flexible Server resource):
   - Keep the master password creation (break-glass).
   - After Postgres is created, enable Microsoft Entra authentication via the server's `authConfig` property (set `activeDirectoryAuth: 'Enabled'` and `passwordAuth: 'Enabled'`), plus an `Microsoft.DBforPostgreSQL/flexibleServers/administrators` child resource for the Entra admin group.
   - Expose new params `entraAdminObjectId`, `entraAdminPrincipalName`, `entraAdminType` (default `Group`). Plumb them through from `bicep/main.bicep`.

1b. Update bicep/modules/identity.bicep (or add a new module `identities.bicep`):
   - Create TWO user-assigned managed identities:
       - `${prefix}-adapter-app`   → used by the adapter Container App at runtime (app role)
       - `${prefix}-adapter-owner` → used by the migrate Container Apps Job (owner role)
   - Output principalId and clientId for each so main.bicep can wire them into apps + job + the role-bootstrap step.

1c. Add a role-bootstrap step in scripts/deploy.sh between Phase 3a (infra) and Phase 3c (apps):
   - After infra is up, connect to Postgres AS the master admin using the break-glass password in state.
   - Run deploy/migrations/sql/bootstrap_roles.sql with DB_OWNER_ROLE=okta_adapter_owner / DB_APP_ROLE=okta_adapter_app / DB_NAME=gateway_db substituted in. Use `psql` via the sidecar container approach already used elsewhere in the wizard (Postgres is behind a private endpoint; see shell-lib/azure-helpers.sh for the existing ACI-based psql invocation pattern).
   - Then connect AS the Entra admin (via `az login` / service principal used by the wizard) and create the managed identity DB users + grant them the two app roles:
       SELECT * FROM pgaadauth_create_principal_with_oid(
         '${ADAPTER_APP_IDENTITY_NAME}',   '${ADAPTER_APP_IDENTITY_OBJECT_ID}',   'service', false, false);
       SELECT * FROM pgaadauth_create_principal_with_oid(
         '${ADAPTER_OWNER_IDENTITY_NAME}', '${ADAPTER_OWNER_IDENTITY_OBJECT_ID}', 'service', false, false);
       GRANT okta_adapter_app   TO "${ADAPTER_APP_IDENTITY_NAME}";
       GRANT okta_adapter_owner TO "${ADAPTER_OWNER_IDENTITY_NAME}";

3. Update bicep/main.bicep and bicep/modules/apps.bicep:
   - Add input parameters: `adapterAppIdentityResourceId`, `adapterAppIdentityClientId`, `adapterOwnerIdentityResourceId`, `adapterOwnerIdentityClientId`, `dbHost` (pipe through from database module output), `dbName`, `entraAuthEnabled` (new bool, default true).
   - In apps.bicep, attach the APP identity to the adapter Container App:
       identity: {
         type: 'UserAssigned'
         userAssignedIdentities: { '${adapterAppIdentityResourceId}': {} }
       }
   - When `entraAuthEnabled = true`, DO NOT use the existing `database-url` secret. Instead set env vars on the adapter container:
       DB_CREDENTIAL_PROVIDER = 'azure_entra'
       DB_HOST                = dbHost
       DB_PORT                = '5432'
       DB_NAME                = dbName
       DB_USERNAME            = '${prefix}-adapter-app'
       AZURE_CLIENT_ID        = adapterAppIdentityClientId
   - When `entraAuthEnabled = false`, keep the existing `database-url` secret path for backward compat.

4. Add a Container Apps Job for migrations (in main.bicep or a new modules/migrate-job.bicep):
   resource migrateJob 'Microsoft.App/jobs@2024-03-01' = {
     name: '${prefix}-migrate'
     location: location
     identity: { type: 'UserAssigned', userAssignedIdentities: { '${managedIdentityResourceId}': {} } }
     properties: {
       environmentId: containerAppEnvironmentId
       configuration: {
         triggerType: 'Manual'
         replicaTimeout: 600
         manualTriggerConfig: { parallelism: 1, replicaCompletionCount: 1 }
       }
       template: {
         containers: [{
           name: 'migrate'
           image: adapterImage
           env: [
             { name: 'DB_CREDENTIAL_PROVIDER', value: 'azure_entra' }
             { name: 'DB_HOST',     value: dbHost }
             { name: 'DB_PORT',     value: '5432' }
             { name: 'DB_NAME',     value: dbName }
             { name: 'DB_USERNAME', value: dbOwnerUsername }  // owner identity, not app
             { name: 'AZURE_CLIENT_ID', value: ownerManagedIdentityClientId }
           ]
           command: ['/bin/sh', '-c']
           args: ['python -m okta_agent_proxy.storage.migrate upgrade']
         }]
       }
     }
   }

   Note: this requires a SECOND user-assigned identity for the owner role, separate from the app identity. Add it in acasetup.sh Phase 1.7 alongside the app identity.

5. Update scripts/deploy.sh Phase 3c — after deploying the Container Apps (apps.bicep) but BEFORE Phase 5 (smoke-test.sh), trigger the migrate job:
   az containerapp job start -g "$AZURE_RG" -n "${PROJECT}-migrate"
   # Poll for completion
   while true; do
     STATUS=$(az containerapp job execution list -g "$AZURE_RG" -n "${PROJECT}-migrate" --query "[0].properties.status" -o tsv)
     case "$STATUS" in
       Succeeded) echo "✓ Migrations applied"; break ;;
       Failed)    echo "✗ Migrations failed"; az containerapp job execution show ...; exit 1 ;;
       *)         sleep 10 ;;
     esac
   done

6. Add a new section to deploy/azure-aca/README.md:
   - "Entra Authentication" — default behavior, what the operator needs (Entra group, two managed identities)
   - "Migration Job" — the manual-trigger Container Apps Job
   - "Disabling Entra Auth" — how to fall back to static password (set entraAuthEnabled=false in .env)

7. Run shellcheck on the modified scripts. Fix any new findings.
   Run bicep lint deploy/azure-aca/bicep/main.bicep — no errors.

8. Smoke test (manual, document the steps):
   - Deploy a fresh stack with `./acasetup.sh` end-to-end.
   - Verify migrate job appears in `az containerapp job list`.
   - Verify adapter Container App has the user-assigned identity attached.
   - Verify adapter logs show "DatabasePool opened (provider=azure_entra ...)".
   - Verify adapter logs show "✓ Database schema verified — current version: 003".

Commit: "P14: Azure ACA — Entra auth, two managed identities, Container Apps Job for migrations"
```

**Expected Output:** Azure ACA stack deploys cleanly with Entra auth as default. Migration runs as a separate job before the adapter starts.

---

## Post-Migration Verification Checklist

After all 14 prompts have been applied and committed, verify:

1. **CWE-121 finding gone:**
   - `pip show greenlet` in a fresh container reports "not found"
   - SCA tool re-scan shows the TStackState.cpp:259 finding is no longer present

2. **No SQLAlchemy / Alembic in runtime image:**
   - `pip show sqlalchemy alembic psycopg2-binary` all report "not found"
   - `docker image inspect` shows reduced image size (~20–40MB smaller depending on base)

3. **No runtime DDL:**
   - Start adapter against an empty database — must fail with the explicit "schema not initialized" error message
   - Start adapter against a database with old schema (manually delete a row from schema_migrations) — must fail with version mismatch

4. **Two-role separation verified:**
   - `psql` as the app role: `CREATE TABLE x()` returns "permission denied"
   - `psql` as the app role: SELECT/INSERT/UPDATE/DELETE on existing tables succeeds
   - Application logs show connection username = app role, never owner role

5. **Each credential provider works end-to-end:**
   - Static (default): existing test deployments continue to work unchanged
   - RDS IAM: ECS deployment with `use_rds_iam=true` connects, rotates connections every ~12 minutes
   - Azure Entra: ACA deployment with `entraAuthEnabled=true` connects via managed identity
   - Vault: K8s deployment with `DB_CREDENTIAL_PROVIDER=vault` issues fresh creds, refreshes at 80% lease

6. **Migration runner is the only path to schema changes:**
   - `okta-adapter-migrate status` returns the expected current_version
   - `okta-adapter-migrate upgrade` is idempotent (second run applies nothing)
   - Modifying a migration file after it's been applied causes the next `upgrade` to fail with checksum mismatch

7. **All 1,950+ tests pass:**
   - `pytest tests/ -v` is green
   - No tests are skipped or marked xfail

8. **Documentation is consistent:**
   - `docs/OPERATIONS.md` documents the bootstrap workflow
   - `CHANGELOG.md` has the breaking-change entry
   - `CLAUDE.md` references the new migration runner, not Alembic
   - No stale references to `alembic upgrade head` anywhere in `docs/`, `deploy/`, or `examples/`

---

## Rollback Plan

Each phase is independently committable and revertable. If problems are found in production:

- **P10–P12 (credential providers):** Set `DB_CREDENTIAL_PROVIDER=static` and provide `DATABASE_URL` to fall back to the legacy path. No schema or code rollback needed.
- **P08 (schema check):** Comment out the `verify_schema(pool)` call in `database.py` to restore old behavior. Schema_migrations table is still populated correctly by P03 runner.
- **P07 (SQLAlchemy removal):** This is the high-risk prompt. Tag the commit immediately before P07 as `pre-sqlalchemy-removal`. If issues are found within the first week of production rollout, revert to that tag, fix forward, redo P07 in a follow-up release.
- **P03 (migration runner):** The runner's `schema_migrations` table is independent of Alembic's `alembic_version` table. They can coexist temporarily — P03 only adds the new table, does not remove the old one. P07 is the prompt that drops `alembic_version` (handle in the deletion step there).

The migration is intentionally staged so SQLAlchemy and the new psycopg3 path coexist for prompts P02–P06. Production rollout can ride a single release where `STORAGE_BACKEND=psycopg` is the default, leaving the SQLAlchemy fallback in place for one release before P07 actually deletes the code in the following release. Coordinate the two releases with whichever customer is most exposure-sensitive.

---

*End of DB_MIGRATION_PROMPTS.md*
