# Standalone Pre-Consent Flow — Implementation Prompts

## Context for all prompts

You are implementing a **standalone pre-consent flow** for the Okta MCP Adapter. This feature lets a user click a link (e.g., from an email or the Admin UI) to re-verify STS-managed backend consents **without initiating a fresh OAuth flow from their MCP client** (VS Code, Claude Code, etc.).

### The scenario

1. A user has already authenticated their agent via the normal client-initiated OAuth flow.
2. Later, an admin adds a new STS-managed connection to that agent.
3. The user needs to grant consent at the downstream IdP, but their client has no way to re-trigger the adapter's OAuth flow.
4. The user clicks `https://<adapter>/oauth/pre-consent?agent_id=<id>`, authenticates with Okta (piggybacking on the **agent's own Okta app**), and lands on the existing consent interstitial. When done, they see a "you're all set, close this tab" confirmation — no gateway code is issued, no redirect to a client occurs.

### Key design decisions (already agreed)

- **Piggyback on the agent's Okta app.** The pre-consent flow uses the same `client_id` / `client_secret` as the normal relay flow for that agent. This guarantees the resulting `id_token` has the correct `aud`/issuer for downstream STS token exchanges, reuses Okta's per-app consent cache, and keeps audit coherent under a single Okta client identity.
- **Use the same scopes the agent is registered with.** Read from `agent_config["scopes"]` (a list), space-joined when building the Okta authorize URL. This ensures scope parity with the normal flow.
- **No user-to-agent ownership check.** Okta app assignment is the authoritative gate — if the user isn't assigned to the agent's Okta app, authentication fails before the callback runs. Do not add a redundant `sub`/`owner_user_id` check.
- **Dispatch in `/oauth/callback`.** A new `is_preconsent_state()` predicate on `ConfidentialRelay` lets the existing callback handler branch at the top. No new Okta redirect URI needed.
- **New `mode` field on `ConsentTransaction`.** Two values: `"oauth_return"` (existing behavior) and `"standalone"` (new). Default is `"oauth_return"` so all existing callers remain unchanged.
- **Audit events must include `ip_address` and `user_agent` from day one** — this is consistent with the P0 audit gap fix and is cheap to do correctly on new code paths.

### Rules that apply to every prompt

- All 397+ existing tests must pass after each prompt.
- Each prompt is idempotent — running it twice should leave the code in the same state as running it once.
- Every change to an auth, request-handling, or token-exchange path must add or extend `AuditEventType` entries in `okta_agent_proxy/audit/events.py` and emit the events via `emit_audit_event()` at success/failure points.
- Do not modify unrelated code. If you spot a bug, note it in a comment but do not fix it as part of these prompts.
- Feature gating is not needed for this flow — it is purely additive and has no impact on existing behavior unless the new route is hit.

### Verified facts about the codebase (from source review)

- `storage.get_agent(agent_id, enabled_only=True)` returns a dict with decrypted `client_id`, `client_secret`, and `scopes` (a list).
- Agent Okta credentials live at `agent_config["client_id"]` and `agent_config["client_secret"]` (see `app.py:1090–1091, 1151–1152`).
- `confidential_relay._sessions_by_state` is an in-memory `dict[str, RelaySession]` keyed by an opaque random token (`secrets.token_urlsafe(32)`). No signing.
- `GatewayCodeManager` is accessed via `confidential_relay._code_manager` and is **not** used by the standalone flow — standalone consent never issues a gateway code.
- Existing STS audit events in `audit/events.py`: `STS_CONSENT_TX_CREATED`, `STS_CONSENT_TX_COMPLETED`, `STS_CONSENT_TX_EXPIRED`, `STS_CONSENT_TX_SKIPPED`, `STS_CONSENT_CHECK_*`, `STS_CONSENT_RECHECK`.
- The consent interstitial HTML is built inline in `app.py` via `_build_consent_interstitial_html(tx_id)` at line ~1543.
- `oauth_consent_complete` at `app.py:1754` is where the oauth_return → gateway code → client redirect happens.

---

## Prompt 1 — `ConfidentialRelay` pre-consent extensions

### Goal

Add standalone pre-consent session handling to `ConfidentialRelay` in `okta_agent_proxy/auth/confidential_relay.py`. This prompt adds data structures and methods only; no routes are wired up yet.

### Changes

**1. Add a new dataclass `PreConsentSession`** (below the existing `RelaySession` dataclass, around line 90):

```python
@dataclasses.dataclass
class PreConsentSession:
    """Session state for a standalone pre-consent flow.

    Unlike RelaySession, this has no 'original client' to return to — the
    user initiated from a link, not from an MCP client. Tokens obtained
    during the Okta exchange are handed directly to ConsentTransactionStore
    and are not retained here.
    """
    agent_id: str
    relay_state: str
    code_verifier: str
    created_at: datetime
    relay_client_id: str
    relay_client_secret: str
    scopes: str  # space-delimited, as sent to Okta
    target_resource: Optional[str] = None
    ttl_seconds: int = 300

    @property
    def is_expired(self) -> bool:
        elapsed = (datetime.now(timezone.utc) - self.created_at).total_seconds()
        return elapsed > self.ttl_seconds
```

**2. Add a parallel in-memory store in `ConfidentialRelay.__init__`** (right after the existing `self._sessions_by_state = {}` at line 119):

```python
# Parallel store for standalone pre-consent flows.
# Keyed by relay_state, same as the normal relay flow, but handled
# via a separate dispatch path in /oauth/callback.
self._preconsent_sessions_by_state: dict[str, PreConsentSession] = {}
```

**3. Add `is_preconsent_state()` predicate** on `ConfidentialRelay` (place it near `_redirect_uri_allowed`):

```python
def is_preconsent_state(self, state: str) -> bool:
    """Return True if the given state belongs to a standalone pre-consent session.

    Used by /oauth/callback to dispatch to the pre-consent handler instead of
    the normal CIMD relay handler.
    """
    return state in self._preconsent_sessions_by_state
```

**4. Add `start_preconsent_authorization()` method**:

```python
async def start_preconsent_authorization(
    self,
    agent_id: str,
    relay_client_id: str,
    relay_client_secret: str,
    scopes: str,
    target_resource: Optional[str] = None,
) -> str:
    """Start a standalone pre-consent authorization flow.

    Unlike start_authorization, this does not involve a CIMD client — the
    user is initiating directly from a link. The resulting id_token will be
    handed off to ConsentTransactionStore for STS verification, not returned
    to any MCP client.

    Args:
        agent_id: The agent whose Okta app we're piggybacking on.
        relay_client_id: The agent's Okta client_id (from agent_config).
        relay_client_secret: The agent's Okta client_secret (from agent_config).
        scopes: Space-delimited scope string, matching the agent's registered scopes.
        target_resource: Optional RFC 8707 resource indicator for path-scoped re-verification.

    Returns:
        The Okta authorization URL to redirect the user to.

    Raises:
        RelayError: If relay_client_id is empty.
    """
    if not relay_client_id:
        raise RelayError(
            "No relay credentials: agent must have client_id and client_secret "
            "configured in the database"
        )

    relay_state = secrets.token_urlsafe(32)

    # PKCE for the relay-to-Okta leg
    relay_verifier = secrets.token_urlsafe(64)
    digest = hashlib.sha256(relay_verifier.encode("ascii")).digest()
    relay_challenge = base64.urlsafe_b64encode(digest).rstrip(b"=").decode("ascii")

    session = PreConsentSession(
        agent_id=agent_id,
        relay_state=relay_state,
        code_verifier=relay_verifier,
        created_at=datetime.now(timezone.utc),
        relay_client_id=relay_client_id,
        relay_client_secret=relay_client_secret,
        scopes=scopes,
        target_resource=target_resource,
    )
    self._preconsent_sessions_by_state[relay_state] = session

    params = {
        "client_id": relay_client_id,
        "redirect_uri": self._callback_url,
        "response_type": "code",
        "state": relay_state,
        "scope": scopes,
        "code_challenge": relay_challenge,
        "code_challenge_method": "S256",
    }

    okta_url = f"{self._authorize_url}?{urlencode(params)}"
    logger.info(
        f"Relay: started pre-consent authorization for agent_id={agent_id} "
        f"(relay_state={relay_state[:8]}...)"
    )
    return okta_url
```

**5. Add `handle_preconsent_callback()` method**:

```python
async def handle_preconsent_callback(
    self, relay_state: str, authorization_code: str
) -> dict:
    """Exchange an Okta authorization code from a pre-consent flow.

    Returns just the id_token and agent context — no access_token, no
    refresh_token, no gateway code. The id_token is used as the subject_token
    for STS verification probes.

    Args:
        relay_state: The state parameter from the Okta callback.
        authorization_code: The authorization code from Okta.

    Returns:
        {
            "id_token": str,
            "agent_id": str,
            "target_resource": Optional[str],
        }

    Raises:
        RelayError: If the session is missing, expired, or the exchange fails.
    """
    session = self._preconsent_sessions_by_state.get(relay_state)
    if not session:
        raise RelayError(
            f"No pre-consent session found for state={relay_state[:8]}..."
        )

    if session.is_expired:
        del self._preconsent_sessions_by_state[relay_state]
        raise RelayError(
            f"Pre-consent session expired for state={relay_state[:8]}..."
        )

    # Exchange the code for tokens against Okta.
    # Build HTTP Basic credentials directly — never use httpx auth= for Okta
    # (it re-encodes the header and breaks the exchange).
    basic = base64.b64encode(
        f"{session.relay_client_id}:{session.relay_client_secret}".encode()
    ).decode()

    data = {
        "grant_type": "authorization_code",
        "code": authorization_code,
        "redirect_uri": self._callback_url,
        "code_verifier": session.code_verifier,
    }

    async with httpx.AsyncClient(transport=self._transport) as client:
        resp = await client.post(
            self._token_url,
            data=data,
            headers={
                "Authorization": f"Basic {basic}",
                "Content-Type": "application/x-www-form-urlencoded",
            },
            timeout=30.0,
        )

    if resp.status_code != 200:
        # Clean up the session on failure
        self._preconsent_sessions_by_state.pop(relay_state, None)
        raise RelayError(
            f"Pre-consent token exchange failed: {resp.status_code} {resp.text}"
        )

    tokens = resp.json()
    id_token = tokens.get("id_token")
    if not id_token:
        self._preconsent_sessions_by_state.pop(relay_state, None)
        raise RelayError("Pre-consent token exchange returned no id_token")

    result = {
        "id_token": id_token,
        "agent_id": session.agent_id,
        "target_resource": session.target_resource,
    }

    # Clean up the session — we have everything we need
    del self._preconsent_sessions_by_state[relay_state]

    logger.info(
        f"Relay: pre-consent exchange complete for agent_id={session.agent_id} "
        f"(relay_state={relay_state[:8]}...)"
    )
    return result
```

### Tests

Add a new test file `tests/test_confidential_relay_preconsent.py` with the following cases:

1. `test_start_preconsent_authorization_builds_okta_url` — calls `start_preconsent_authorization(...)`, asserts the returned URL contains `client_id=<agent_client_id>`, `scope=openid profile email`, `code_challenge_method=S256`, and a `state` value. Verifies the session was stored in `_preconsent_sessions_by_state`.
2. `test_start_preconsent_authorization_requires_client_id` — passing an empty `relay_client_id` raises `RelayError`.
3. `test_is_preconsent_state_true_for_preconsent_session` — after `start_preconsent_authorization`, `is_preconsent_state(state)` returns `True`.
4. `test_is_preconsent_state_false_for_relay_session` — after `start_authorization` (the normal flow), `is_preconsent_state(state)` returns `False`.
5. `test_is_preconsent_state_false_for_unknown` — unknown state returns `False`.
6. `test_handle_preconsent_callback_success` — mock httpx transport returning `{"id_token": "...", "access_token": "..."}`, verify the returned dict has `id_token`, `agent_id`, `target_resource`, and that the session was removed from the store.
7. `test_handle_preconsent_callback_unknown_state` — raises `RelayError("No pre-consent session found")`.
8. `test_handle_preconsent_callback_expired` — manipulate `session.created_at` to be > 300 seconds old, verify `RelayError("Pre-consent session expired")` and the session is cleaned up.
9. `test_handle_preconsent_callback_token_exchange_failure` — mock httpx returning 401, verify `RelayError` and session cleanup.
10. `test_handle_preconsent_callback_missing_id_token` — mock httpx returning 200 with `{"access_token": "..."}` (no id_token), verify `RelayError` and session cleanup.
11. `test_preconsent_and_relay_sessions_are_isolated` — creates both a normal relay session and a pre-consent session; verifies neither appears in the other's store.

### Verification

```bash
pytest tests/test_confidential_relay_preconsent.py -v
pytest tests/ -x  # all existing tests still pass
```

---

## Prompt 2 — `ConsentTransaction` mode field

### Goal

Add a `mode` field to `ConsentTransaction` in `okta_agent_proxy/auth/consent_transaction.py` so transactions can be marked as either `"oauth_return"` (existing behavior, default) or `"standalone"` (new pre-consent flow). All existing callers remain unchanged.

### Changes

**1. Add `mode` field to the `ConsentTransaction` dataclass** in `okta_agent_proxy/auth/consent_transaction.py`.

Use `Literal["oauth_return", "standalone"]` with default `"oauth_return"`. Place it near the top of the dataclass, after the transaction_id. Import `Literal` from `typing` if not already imported.

```python
from typing import Literal

@dataclasses.dataclass
class ConsentTransaction:
    transaction_id: str
    session_id: str
    mode: Literal["oauth_return", "standalone"] = "oauth_return"
    # ... existing fields below ...
```

**2. Update `ConsentTransactionStore.create()`** to accept an optional `mode` kwarg with default `"oauth_return"`, and pass it through when constructing the `ConsentTransaction`.

```python
def create(
    self,
    *,
    mode: Literal["oauth_return", "standalone"] = "oauth_return",
    # ... all existing kwargs unchanged ...
) -> ConsentTransaction:
    # ... existing body ...
    transaction = ConsentTransaction(
        transaction_id=...,
        session_id=...,
        mode=mode,
        # ... existing fields ...
    )
```

In `standalone` mode, the following fields should be allowed to be empty strings or `None`:
- `original_client_id`
- `original_redirect_uri`
- `original_state`
- `access_token`
- `refresh_token`
- `okta_expires_in`
- `relay_client_id`
- `relay_client_secret`

If any validation currently rejects empty values for these fields, weaken the validation so that `mode == "standalone"` transactions pass. Add a brief comment explaining why.

### Tests

Add to `tests/test_consent_transaction.py`:

1. `test_create_defaults_to_oauth_return_mode` — existing constructor call produces a transaction with `mode == "oauth_return"`.
2. `test_create_standalone_mode` — explicit `mode="standalone"` produces a transaction with `mode == "standalone"`.
3. `test_standalone_mode_allows_empty_oauth_return_fields` — passing empty strings for `original_client_id`, `original_redirect_uri`, etc., succeeds when `mode="standalone"`.
4. `test_oauth_return_mode_rejects_empty_required_fields` — if the existing store validates these fields for `oauth_return`, assert that behavior is preserved. If it doesn't validate them, skip this test.
5. `test_mode_field_round_trips_through_store` — create a transaction, retrieve it via whatever retrieval method the store exposes, verify `mode` is preserved.

### Verification

```bash
pytest tests/test_consent_transaction.py -v
pytest tests/ -x
```

---

## Prompt 3 — `/oauth/pre-consent` route and audit event

### Goal

Add the entry-point route `GET /oauth/pre-consent` that kicks off a standalone pre-consent flow. This prompt adds the route and its audit event only — the callback dispatcher (prompt 4) is not yet in place, so the flow will not be end-to-end testable after this prompt. That is expected.

### Changes

**1. Add `STS_PRECONSENT_INITIATED` to `AuditEventType`** in `okta_agent_proxy/audit/events.py`, grouped with the other STS consent events:

```python
STS_PRECONSENT_INITIATED = "sts.preconsent.initiated"
STS_PRECONSENT_AUTHENTICATED = "sts.preconsent.authenticated"
```

Add both values in this prompt even though `STS_PRECONSENT_AUTHENTICATED` is not emitted until prompt 4 — keeping the enum additions together avoids a second edit to the same file.

**2. Add the `oauth_pre_consent` route handler** in `okta_agent_proxy/app.py`, placed immediately above `oauth_callback`:

```python
async def oauth_pre_consent(request: Request):
    """Kick off a standalone pre-consent flow for a specific agent.

    The user clicks a link like /oauth/pre-consent?agent_id=<id> and is
    redirected to Okta to authenticate against the agent's own Okta app
    (piggyback). After authentication, /oauth/callback dispatches to the
    pre-consent handler, which creates a standalone consent transaction
    and drops the user on the normal consent interstitial.

    Query params:
        agent_id: Required. The agent whose STS connections we're verifying.
        resource: Optional. RFC 8707 resource indicator for path-scoped re-verification.
    """
    from starlette.responses import RedirectResponse

    agent_id = request.query_params.get("agent_id", "").strip()
    target_resource = request.query_params.get("resource") or None

    if not agent_id:
        return JSONResponse(
            {"error": "invalid_request", "error_description": "Missing agent_id"},
            status_code=400,
        )

    # Look up the agent config (includes decrypted Okta credentials)
    agent_config = storage.get_agent(agent_id, enabled_only=True)
    if not agent_config:
        return JSONResponse(
            {"error": "unknown_agent", "error_description": f"No enabled agent found for agent_id={agent_id}"},
            status_code=404,
        )

    relay_client_id = agent_config.get("client_id", "")
    relay_client_secret = agent_config.get("client_secret", "")
    if not relay_client_id or not relay_client_secret:
        return JSONResponse(
            {
                "error": "agent_not_configured",
                "error_description": "Agent has no Okta client credentials configured",
            },
            status_code=400,
        )

    # Use the agent's registered scopes (space-joined) for scope parity with the normal flow.
    # This ensures the resulting id_token has the same shape as one from a client-initiated flow,
    # which is important for downstream STS token exchange probes.
    scopes_list = agent_config.get("scopes", ["openid", "profile", "email"])
    if isinstance(scopes_list, str):
        scopes_str = scopes_list  # tolerate either format
    else:
        scopes_str = " ".join(scopes_list)

    await emit_audit_event(
        AuditEventType.STS_PRECONSENT_INITIATED,
        details={
            "agent_id": agent_id,
            "target_resource": target_resource,
            "ip_address": request.client.host if request.client else "",
            "user_agent": request.headers.get("user-agent", "")[:256],
        },
    )

    try:
        okta_url = await confidential_relay.start_preconsent_authorization(
            agent_id=agent_id,
            relay_client_id=relay_client_id,
            relay_client_secret=relay_client_secret,
            scopes=scopes_str,
            target_resource=target_resource,
        )
    except RelayError as e:
        logger.error(f"Pre-consent start error for agent_id={agent_id}: {e}")
        return JSONResponse(
            {"error": "relay_error", "error_description": str(e)},
            status_code=500,
        )

    logger.info(f"Pre-consent: redirecting user to Okta for agent_id={agent_id}")
    return RedirectResponse(url=okta_url, status_code=302)
```

**3. Register the route** in the route table (near the existing `/oauth/consent-*` routes, around line 2188):

```python
Route("/oauth/pre-consent", oauth_pre_consent, methods=["GET"]),
```

Place it **before** `/oauth/callback` in the route list so the ordering matches the user flow.

### Tests

Add to `tests/test_consent_interstitial_routes.py` (or create `tests/test_preconsent_route.py` if that file is getting crowded):

1. `test_pre_consent_missing_agent_id` — `GET /oauth/pre-consent` returns 400 with `error: invalid_request`.
2. `test_pre_consent_unknown_agent_id` — unknown `agent_id` returns 404 with `error: unknown_agent`.
3. `test_pre_consent_disabled_agent` — disabled agent returns 404 (because `get_agent` is called with `enabled_only=True`).
4. `test_pre_consent_agent_missing_okta_credentials` — agent config with empty `client_id` or `client_secret` returns 400 with `error: agent_not_configured`.
5. `test_pre_consent_happy_path_redirects_to_okta` — valid `agent_id` returns 302 to a URL containing:
   - the configured Okta authorize endpoint
   - `client_id=<agent_client_id>`
   - `response_type=code`
   - `scope` matching the joined agent scopes
   - `code_challenge_method=S256`
   - a `state` value present in `confidential_relay._preconsent_sessions_by_state`
6. `test_pre_consent_with_target_resource` — query param `?agent_id=X&resource=Y` stores `target_resource="Y"` on the session.
7. `test_pre_consent_scopes_list_format` — agent config with `scopes=["openid", "profile", "email"]` produces `scope=openid profile email` in the URL.
8. `test_pre_consent_scopes_string_format` — agent config with `scopes="openid profile"` (if any legacy code stores it this way) also works.
9. `test_pre_consent_emits_audit_event` — verifies `STS_PRECONSENT_INITIATED` is emitted with `agent_id`, `ip_address`, and `user_agent` fields populated.

### Verification

```bash
pytest tests/test_preconsent_route.py -v   # or whichever test file you chose
pytest tests/ -x
```

Note: after this prompt, manually hitting `/oauth/pre-consent?agent_id=known` will correctly redirect to Okta, but the subsequent `/oauth/callback` will fail because the dispatcher isn't in place yet. Prompt 4 fixes this.

---

## Prompt 4 — `/oauth/callback` dispatcher and pre-consent callback handler

### Goal

Wire the pre-consent flow into `/oauth/callback` by dispatching pre-consent `state` values to a new `_handle_preconsent_callback` helper. This completes the end-to-end flow from user-clicks-link to user-lands-on-interstitial.

### Changes

**1. Add dispatch at the top of `oauth_callback`** in `app.py` (around line 1382, immediately after the `code`/`state` presence check and before the `try:` block):

```python
async def oauth_callback(request: Request):
    """Handle the relay callback from Okta after CIMD client authorization."""
    code = request.query_params.get("code")
    state = request.query_params.get("state")

    if not code or not state:
        return JSONResponse(
            {"error": "invalid_request", "error_description": "Missing code or state parameter"},
            status_code=400,
        )

    # Dispatch: pre-consent sessions have their own handler path.
    # Normal CIMD relay flow falls through below.
    if confidential_relay.is_preconsent_state(state):
        return await _handle_preconsent_callback(request, code, state)

    try:
        # ... existing body unchanged ...
```

**2. Add the `_handle_preconsent_callback` helper function** in `app.py`, placed between `oauth_callback` and `oauth_consent_verify`:

```python
async def _handle_preconsent_callback(request: Request, code: str, state: str):
    """Handle the Okta callback for a standalone pre-consent flow.

    This is dispatched from oauth_callback when the state matches a
    PreConsentSession. Unlike the normal relay callback, there is no
    gateway code issuance and no return redirect to a client.
    """
    from starlette.responses import HTMLResponse, RedirectResponse
    import hashlib as _hashlib
    import asyncio

    try:
        result = await confidential_relay.handle_preconsent_callback(state, code)
    except RelayError as e:
        logger.error(f"Pre-consent callback error: {e}")
        return JSONResponse(
            {"error": "relay_error", "error_description": str(e)},
            status_code=400,
        )

    agent_id = result["agent_id"]
    id_token = result["id_token"]
    target_resource = result.get("target_resource")

    # Re-fetch the agent config — we need the full config for STS resource filtering
    agent_config = storage.get_agent(agent_id, enabled_only=True)
    if not agent_config:
        logger.error(f"Pre-consent callback: agent_id={agent_id} no longer exists or is disabled")
        return JSONResponse(
            {"error": "unknown_agent"},
            status_code=404,
        )

    await emit_audit_event(
        AuditEventType.STS_PRECONSENT_AUTHENTICATED,
        details={
            "agent_id": agent_id,
            "ip_address": request.client.host if request.client else "",
            "user_agent": request.headers.get("user-agent", "")[:256],
        },
    )

    # Filter STS resources by target_resource (same logic as the normal relay callback)
    sts_resources = consent_service.get_sts_resources(agent_id, agent_config)
    matching_resources = consent_service.filter_resources_by_target(
        sts_resources, target_resource
    )

    if not matching_resources:
        # Nothing to verify — render "all set" page directly
        logger.info(
            f"Pre-consent: no matching STS resources for agent_id={agent_id} "
            f"(target_resource={target_resource!r})"
        )
        return HTMLResponse(_build_preconsent_nothing_to_verify_html(agent_id))

    # Create a standalone consent transaction
    ua_hash = _hashlib.sha256(
        request.headers.get("user-agent", "").encode()
    ).hexdigest()[:16]

    transaction = consent_store.create(
        mode="standalone",
        id_token=id_token,
        agent_id=agent_id,
        agent_config=agent_config,
        target_resource=target_resource,
        ip_address=request.client.host if request.client else "",
        user_agent_hash=ua_hash,
        # OAuth-return fields are empty in standalone mode
        original_client_id="",
        original_redirect_uri="",
        original_state="",
        access_token="",
        refresh_token=None,
        okta_expires_in=None,
        relay_client_id="",
        relay_client_secret="",
    )

    await emit_audit_event(
        AuditEventType.STS_CONSENT_TX_CREATED,
        details={
            "transaction_id": transaction.transaction_id,
            "agent_id": agent_id,
            "client_id": "",  # no CIMD client in standalone mode
            "mode": "standalone",
            "sts_resource_count": len(matching_resources),
            "target_resource": target_resource,
        },
    )

    # Kick off async verification
    asyncio.create_task(consent_service.verify_all(transaction))

    # Redirect to the interstitial with the standalone session cookie
    response = RedirectResponse(
        url=f"/oauth/consent-verify?tx={transaction.transaction_id}",
        status_code=302,
    )
    response.set_cookie(
        "__okta_consent_session",
        value=transaction.session_id,
        httponly=True,
        secure=request.url.hostname not in ("localhost", "127.0.0.1"),
        samesite="lax",
        path="/oauth",
        max_age=600,
    )
    logger.info(
        f"Pre-consent: {len(matching_resources)} STS resources need verification "
        f"for agent_id={agent_id} (tx={transaction.transaction_id[:8]}...)"
    )
    return response
```

**3. Add a stub for `_build_preconsent_nothing_to_verify_html`** in `app.py`, placed near the other HTML builders. The full implementation lands in prompt 5; for this prompt, a minimal stub is sufficient so the code imports cleanly:

```python
def _build_preconsent_nothing_to_verify_html(agent_id: str) -> str:
    """Placeholder — full implementation in prompt 5."""
    return (
        "<!DOCTYPE html><html><head><title>All Set</title></head>"
        f"<body><h1>Nothing to authorize</h1>"
        f"<p>No STS-managed connections require verification for this agent. "
        f"You can close this tab and return to your client.</p></body></html>"
    )
```

**4. Extend the existing `STS_CONSENT_TX_CREATED` audit call** in the normal `oauth_callback` path (around line 1465) to include `mode: "oauth_return"` in its details payload. This is additive and won't break anything:

```python
await emit_audit_event(
    AuditEventType.STS_CONSENT_TX_CREATED,
    details={
        "transaction_id": transaction.transaction_id,
        "agent_id": agent_id,
        "client_id": original_client_id,
        "mode": "oauth_return",  # NEW
        "sts_resource_count": len(sts_resources),
        "target_resource": callback_result.get("target_resource"),
    },
)
```

### Tests

Add to `tests/test_preconsent_route.py` (continuing the file from prompt 3):

1. `test_callback_dispatches_preconsent_vs_relay` — create both a pre-consent session and a normal relay session; verify `/oauth/callback?code=X&state=<preconsent>` hits the pre-consent path, and `?state=<relay>` hits the normal path. (Use mocks or spies to verify the dispatch, not just the end-to-end result.)
2. `test_callback_unknown_state_falls_through_to_relay` — an unknown state that matches neither store falls through to the existing relay handler (which will then error out as today — this is a regression guard for the dispatch order).
3. `test_preconsent_callback_no_matching_resources` — agent with zero STS resources returns HTML containing "Nothing to authorize", no consent transaction is created.
4. `test_preconsent_callback_creates_standalone_transaction` — agent with STS resources creates a transaction with `mode == "standalone"`, empty OAuth-return fields, and populated `id_token` / `agent_id` / `agent_config`.
5. `test_preconsent_callback_sets_session_cookie_and_redirects` — response is 302 to `/oauth/consent-verify?tx=...`, sets `__okta_consent_session` cookie with `httponly`, `samesite=lax`, and `path=/oauth`.
6. `test_preconsent_callback_emits_authenticated_audit_event` — `STS_PRECONSENT_AUTHENTICATED` fires with `agent_id`, `ip_address`, `user_agent`.
7. `test_preconsent_callback_emits_tx_created_with_standalone_mode` — `STS_CONSENT_TX_CREATED` fires with `mode: "standalone"`.
8. `test_preconsent_callback_agent_deleted_between_init_and_callback` — if the agent is disabled or deleted between `/oauth/pre-consent` and `/oauth/callback`, returns 404 gracefully (do not crash).
9. `test_preconsent_callback_token_exchange_failure` — mock Okta returning 401 on the token exchange; verify the route returns 400 and no transaction is created.
10. `test_oauth_return_tx_created_includes_mode_field` — regression: the existing relay flow's `STS_CONSENT_TX_CREATED` event now includes `mode: "oauth_return"`.

### Verification

```bash
pytest tests/test_preconsent_route.py -v
pytest tests/test_consent_interstitial_e2e.py -v   # regression: existing e2e flow still works
pytest tests/ -x
```

After this prompt, the end-to-end flow works: hitting `/oauth/pre-consent?agent_id=known` → Okta login → `/oauth/callback` → standalone consent transaction → `/oauth/consent-verify` interstitial. However, clicking "Continue" on the interstitial will still run the oauth_return completion logic, which will fail because the OAuth return fields are empty. Prompt 5 fixes this.

---

## Prompt 5 — Interstitial mode awareness and standalone completion

### Goal

Make the consent interstitial and its completion handler mode-aware:
- The interstitial shows slightly different title/button copy in standalone mode.
- `oauth_consent_complete` branches on `tx.mode` — standalone mode renders an "all set" HTML page instead of issuing a gateway code and redirecting.
- Add two new HTML builders for the standalone success pages.

### Changes

**1. Add `is_standalone` parameter to `_build_consent_interstitial_html`** in `app.py` (line ~1543):

```python
def _build_consent_interstitial_html(tx_id: str, is_standalone: bool = False) -> str:
    """Build the consent verification interstitial HTML page.

    Args:
        tx_id: The consent transaction ID.
        is_standalone: If True, render copy for the standalone pre-consent flow
                       (no "return to client" affordance). If False (default),
                       render the normal oauth_return copy.
    """
    title = "Authorize New Connections" if is_standalone else "Verifying Access"
    subtitle = (
        "Grant access to the connections below. You can return to your client when done."
        if is_standalone
        else "We're verifying your access to the connections this agent needs."
    )
    continue_label = "Finish" if is_standalone else "Continue"

    return f"""<!DOCTYPE html>
<html>
<head>
<title>{title} — Okta MCP Adapter</title>
<style>
  /* ... existing styles ... */
</style>
</head>
<body>
  <h1>{title}</h1>
  <p class="subtitle">{subtitle}</p>
  <!-- ... existing markup, but the "Continue" button label uses {continue_label} ... -->
</body>
</html>"""
```

Keep the existing styles and markup intact — only the title, subtitle, and button label text change based on `is_standalone`. The polling JavaScript, status cards, re-check flow, and skip flow all work identically in both modes because the underlying verification machinery is identical.

**2. Update `oauth_consent_verify`** (line ~1508) to pass the mode flag:

```python
async def oauth_consent_verify(request: Request):
    # ... existing validation ...

    tx = consent_store.validate_session(...)
    if not tx:
        # ... existing error handling ...

    html = _build_consent_interstitial_html(
        tx_id,
        is_standalone=(tx.mode == "standalone"),
    )
    return HTMLResponse(html)
```

**3. Replace the stub `_build_preconsent_nothing_to_verify_html` from prompt 4** with a full implementation. Place it near the other HTML builders:

```python
def _build_preconsent_nothing_to_verify_html(agent_id: str) -> str:
    """Render the 'nothing to verify' page shown when a pre-consent flow
    finds no matching STS resources for the agent.
    """
    # Escape agent_id defensively since it comes from a query param
    from html import escape as _esc
    safe_agent_id = _esc(agent_id)

    return f"""<!DOCTYPE html>
<html>
<head>
<title>All Set — Okta MCP Adapter</title>
<style>
  body {{ font-family: -apple-system, BlinkMacSystemFont, sans-serif; max-width: 520px;
         margin: 60px auto; padding: 0 20px; color: #333; }}
  h1 {{ font-size: 1.4em; margin-bottom: 8px; }}
  .subtitle {{ color: #666; margin-bottom: 24px; }}
  .checkmark {{ color: #1a7f37; font-size: 3em; text-align: center; margin: 24px 0; }}
  .hint {{ color: #999; font-size: 0.9em; margin-top: 32px; }}
</style>
</head>
<body>
  <div class="checkmark">&#10003;</div>
  <h1>Nothing to authorize</h1>
  <p class="subtitle">
    No STS-managed connections require verification for this agent.
  </p>
  <p>You can close this tab and return to your client.</p>
  <p class="hint">Agent: {safe_agent_id}</p>
</body>
</html>"""
```

**4. Add `_build_preconsent_complete_html`** — rendered by `oauth_consent_complete` when `tx.mode == "standalone"`:

```python
def _build_preconsent_complete_html(verified: int, skipped: int, errors: int) -> str:
    """Render the standalone pre-consent completion page."""
    total = verified + skipped + errors
    summary_parts = []
    if verified:
        summary_parts.append(f"{verified} authorized")
    if skipped:
        summary_parts.append(f"{skipped} skipped")
    if errors:
        summary_parts.append(f"{errors} error{'s' if errors != 1 else ''}")
    summary = ", ".join(summary_parts) if summary_parts else "nothing to do"

    return f"""<!DOCTYPE html>
<html>
<head>
<title>All Set — Okta MCP Adapter</title>
<style>
  body {{ font-family: -apple-system, BlinkMacSystemFont, sans-serif; max-width: 520px;
         margin: 60px auto; padding: 0 20px; color: #333; }}
  h1 {{ font-size: 1.4em; margin-bottom: 8px; }}
  .subtitle {{ color: #666; margin-bottom: 24px; }}
  .checkmark {{ color: #1a7f37; font-size: 3em; text-align: center; margin: 24px 0; }}
  .summary {{ background: #f6f8fa; padding: 16px; border-radius: 6px;
              text-align: center; font-size: 1.05em; margin: 24px 0; }}
  .hint {{ color: #999; font-size: 0.9em; margin-top: 32px; }}
</style>
</head>
<body>
  <div class="checkmark">&#10003;</div>
  <h1>You're all set</h1>
  <p class="subtitle">Pre-consent verification complete.</p>
  <div class="summary">{summary} of {total} connection{'s' if total != 1 else ''}</div>
  <p>You can close this tab and return to your client.</p>
  <p class="hint">Any future calls from your agent will use the authorizations you just granted.</p>
</body>
</html>"""
```

**5. Branch `oauth_consent_complete` on `tx.mode`** (line ~1754). Insert the standalone branch immediately after the session validation block, before the existing gateway code issuance:

```python
async def oauth_consent_complete(request: Request):
    """Complete the consent flow — branches by transaction mode."""
    from starlette.responses import RedirectResponse as _Redirect, HTMLResponse

    form = await request.form()
    tx_id = form.get("tx", "")
    session_id = request.cookies.get("__okta_consent_session", "")

    if not tx_id or not session_id:
        return JSONResponse({"error": "invalid_request"}, status_code=400)

    import hashlib as _hashlib
    ua_hash = _hashlib.sha256(
        request.headers.get("user-agent", "").encode()
    ).hexdigest()[:16]

    tx = consent_store.validate_session(
        session_id=session_id,
        ip_address=request.client.host if request.client else "",
        user_agent_hash=ua_hash,
    )

    if not tx or tx.transaction_id != tx_id:
        return HTMLResponse(
            "<h1>Session Expired</h1><p>Your consent session has expired. "
            "Please restart the authorization flow.</p>",
            status_code=400,
        )

    # Branch by mode
    if tx.mode == "standalone":
        verified = sum(1 for c in tx.connections if c.status == "verified")
        skipped = sum(1 for c in tx.connections if c.status in ("skipped", "consent_required"))
        errors = sum(1 for c in tx.connections if c.status == "error")

        await emit_audit_event(
            AuditEventType.STS_CONSENT_TX_COMPLETED,
            details={
                "transaction_id": tx.transaction_id,
                "agent_id": tx.agent_id,
                "client_id": "",
                "mode": "standalone",
                "verified_count": verified,
                "skipped_count": skipped,
                "error_count": errors,
            },
        )

        consent_store.remove(tx.transaction_id)

        response = HTMLResponse(
            _build_preconsent_complete_html(verified, skipped, errors)
        )
        response.delete_cookie("__okta_consent_session", path="/oauth")
        logger.info(
            f"Pre-consent complete: agent_id={tx.agent_id} "
            f"(tx={tx.transaction_id[:8]}..., {verified}v/{skipped}s/{errors}e)"
        )
        return response

    # --- oauth_return mode (existing behavior) ---
    gateway_code = confidential_relay._code_manager.issue_code(
        client_id=tx.original_client_id,
        tokens={
            "access_token": tx.access_token,
            "id_token": tx.id_token,
            "refresh_token": tx.refresh_token,
            "expires_in": tx.okta_expires_in,
        },
        extra={
            "relay_client_id": tx.relay_client_id,
            "relay_client_secret": tx.relay_client_secret,
        },
    )

    redirect_params = {"code": gateway_code, "state": tx.original_state}
    redirect_url = f"{tx.original_redirect_uri}?{urlencode(redirect_params)}"

    await emit_audit_event(
        AuditEventType.STS_CONSENT_TX_COMPLETED,
        details={
            "transaction_id": tx.transaction_id,
            "agent_id": tx.agent_id,
            "client_id": tx.original_client_id,
            "mode": "oauth_return",  # NEW
            "verified_count": sum(1 for c in tx.connections if c.status == "verified"),
            "skipped_count": sum(1 for c in tx.connections if c.status in ("skipped", "consent_required")),
            "error_count": sum(1 for c in tx.connections if c.status == "error"),
        },
    )

    consent_store.remove(tx.transaction_id)

    response = _Redirect(url=redirect_url, status_code=302)
    response.delete_cookie("__okta_consent_session", path="/oauth")

    logger.info(
        f"Consent complete: redirecting {tx.original_client_id} "
        f"(tx={tx.transaction_id[:8]}...)"
    )
    return response
```

### Tests

Add to `tests/test_preconsent_route.py`:

1. `test_interstitial_standalone_title` — creates a standalone transaction, GETs `/oauth/consent-verify?tx=...`, verifies response body contains "Authorize New Connections" and "Finish".
2. `test_interstitial_oauth_return_title` — regression: existing flow still shows "Verifying Access" and "Continue".
3. `test_consent_complete_standalone_returns_html` — completing a standalone transaction returns HTML response, not a 302 redirect.
4. `test_consent_complete_standalone_renders_summary` — response body contains "You're all set" and the verified/skipped/error counts.
5. `test_consent_complete_standalone_deletes_cookie` — response deletes `__okta_consent_session` cookie.
6. `test_consent_complete_standalone_no_gateway_code_issued` — after completion, `confidential_relay._code_manager._sessions_by_code` is unchanged (no new code was added).
7. `test_consent_complete_standalone_emits_audit_with_mode` — `STS_CONSENT_TX_COMPLETED` fires with `mode: "standalone"` and the count fields.
8. `test_consent_complete_oauth_return_still_redirects` — regression: existing flow still issues a gateway code and returns a 302 to `original_redirect_uri`.
9. `test_consent_complete_oauth_return_audit_includes_mode` — regression: `STS_CONSENT_TX_COMPLETED` for oauth_return flow now also includes `mode: "oauth_return"`.
10. `test_preconsent_nothing_to_verify_renders_safely` — `_build_preconsent_nothing_to_verify_html` escapes the `agent_id` (pass in `agent_id="<script>alert(1)</script>"` and verify the raw string is not in the output).
11. `test_preconsent_complete_html_singular_plural` — calls `_build_preconsent_complete_html` with `(1, 0, 0)`, `(2, 0, 0)`, `(1, 0, 1)` and verifies correct singular/plural forms.

### Verification

```bash
pytest tests/test_preconsent_route.py -v
pytest tests/test_consent_interstitial_page.py -v
pytest tests/test_consent_interstitial_callback.py -v
pytest tests/test_consent_interstitial_e2e.py -v
pytest tests/ -x
```

After this prompt, the standalone pre-consent flow is **fully functional end-to-end** from a backend perspective. Prompt 6 adds the Admin UI convenience button.

---

## Prompt 6 — Admin UI "Copy pre-consent link" button

### Goal

Add a user-facing way to generate pre-consent links from the Admin UI. Pure frontend change — no backend work.

### Changes

**1. Locate the agent detail page** in the Next.js Admin UI. Based on the Radix + Tailwind conventions used elsewhere, look for a component along the lines of `admin-ui/src/app/agents/[agentId]/page.tsx` or `admin-ui/components/agents/AgentDetail.tsx` — use whatever the existing convention is.

**2. Add a "Pre-Consent Link" section** to the agent detail page, below any existing "Okta Connection" or "Credentials" section. The section should contain:

- **A read-only text field** showing the full URL: `${gatewayBaseUrl}/oauth/pre-consent?agent_id=${agentId}` where `gatewayBaseUrl` comes from the existing environment/config mechanism the Admin UI already uses (likely `NEXT_PUBLIC_GATEWAY_BASE_URL` or equivalent).
- **A "Copy link" button** that copies the URL to the clipboard via `navigator.clipboard.writeText()` and shows a brief toast/tooltip confirmation ("Copied!").
- **A short helper text** explaining what the link does: *"Send this link to a user to let them re-verify STS-managed connections without restarting their MCP client. The user will authenticate against this agent's Okta app and land on the consent interstitial."*

**3. (Optional, if easy) Add a per-resource variant.** If the agent detail page already lists its resources, add a small "Copy link" icon button next to each STS-type resource that copies `${gatewayBaseUrl}/oauth/pre-consent?agent_id=${agentId}&resource=${resourceId}`. Skip this if it would require significant restructuring of the resource list component.

**4. Update documentation**. In the existing Admin UI README or an `ADMIN_UI_GUIDE.md`, add a short section titled "Pre-Consent Links" that explains:
- What the feature is (one paragraph from the context section of this file).
- The URL format, so admins can construct links outside the UI for email templates, Slack bots, automation, etc.
- The required query param (`agent_id`) and the optional one (`resource`).
- A note that the user clicking the link must be assigned to the agent's Okta app, otherwise Okta will deny authentication.

### Tests

If the Admin UI has a Jest/Vitest test suite, add a minimal test:

1. `test_agent_detail_renders_preconsent_link` — renders the agent detail page with a mock agent, asserts the pre-consent URL is present in the DOM with the correct `agent_id`.
2. `test_copy_button_calls_clipboard_api` — mocks `navigator.clipboard.writeText`, clicks the button, verifies the mock was called with the expected URL.

If there is no existing test suite for the Admin UI, skip the tests and rely on manual verification.

### Manual verification

1. Start the adapter and Admin UI locally (`docker-compose up`).
2. Navigate to an agent detail page.
3. Confirm the pre-consent link is displayed with the correct URL.
4. Click "Copy link", paste into a browser, verify redirect to Okta.
5. Complete the Okta login and confirm landing on the interstitial.
6. Complete verification and confirm landing on the "You're all set" page.

### Verification

```bash
cd admin-ui && npm test   # if tests exist
pytest tests/ -x          # backend regression check
```

---

## Post-implementation checklist

After all six prompts are complete, verify the following manually end-to-end:

1. **Happy path with STS resources:** User clicks pre-consent link → Okta login → consent interstitial lists STS connections → user clicks through each `interaction_uri` → polling shows them turn green → user clicks "Finish" → "You're all set" page.
2. **Happy path with no STS resources:** User clicks pre-consent link → Okta login → "Nothing to authorize" page directly (no interstitial shown).
3. **Path-scoped re-verification:** User clicks `?agent_id=X&resource=Y` link → only resource Y is probed → completion page shows just that one.
4. **Regression — normal client flow:** VS Code / Claude Code OAuth flow still works end-to-end, existing tests pass, `STS_CONSENT_TX_CREATED` / `STS_CONSENT_TX_COMPLETED` audit events now include `mode: "oauth_return"`.
5. **Audit SIEM query:** Confirm SIEM dashboards can filter by `mode` to distinguish standalone vs oauth_return traffic.
6. **Unknown agent:** `?agent_id=nonexistent` returns 404 with a reasonable error message.
7. **User not assigned to agent's Okta app:** Okta itself rejects the authentication with its standard error page. Adapter never sees the callback. (This is the implicit identity check.)

## Open questions intentionally deferred

- **Email/Slack integration for sending pre-consent links.** Not in scope. The Admin UI provides copyable links; delivery is a follow-up feature.
- **Redis migration of `_preconsent_sessions_by_state`.** Currently in-memory, same as `_sessions_by_state`. Both will migrate together when the Redis caching workstream lands.
- **Rate limiting on `/oauth/pre-consent`.** Out of scope for this change set. Consider adding IP-based rate limiting in a follow-up if the endpoint becomes a target for enumeration attempts. (Note: even without rate limiting, the endpoint only leaks the existence of an agent by `agent_id`, which is not considered sensitive — agent IDs are not secrets.)
