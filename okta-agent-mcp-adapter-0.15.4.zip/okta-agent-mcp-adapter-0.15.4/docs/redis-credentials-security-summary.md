# Redis Credential Architecture — Security Summary

## What changed

The adapter no longer requires a long-lived shared secret to
authenticate to Redis. Production deployments use cloud-native
identity:

- AWS: ElastiCache IAM (15-min SigV4 tokens, minted per-connection)
- Azure: Entra Managed Identity (~1-hr Entra tokens)

The static-password path is gated by `ALLOW_STATIC_REDIS_PASSWORD`
and exists only for local development. Production manifests do
not contain this flag.

## Evidence

1. **Codebase**: All credential acquisition flows through the
   `RedisCredentialProvider` abstraction at
   `okta_agent_proxy/cache/redis_credentials.py`. Search for
   "REDIS_PASSWORD" — it appears only in:
   - The static provider (gated)
   - Docker Compose dev configs
   - Tests that exercise the static path
   No production code path consumes `REDIS_PASSWORD` directly.

2. **AWS deployment**: `terraform plan` against
   `deploy/aws-ecs/` shows zero secret-manager entries for
   Redis. The IAM role attached to the ECS task has only
   `elasticache:Connect` permission scoped to the cache and
   user. No password rotation procedure required.

3. **Azure deployment**: `az redis access-policy-assignment list`
   on the deployed cache shows the UAMI granted Data Owner. The
   Container App env contains no Redis credential. Access keys
   are not retrieved (`acasetup.sh` no longer calls
   `az redis list-keys`).

4. **Audit stream**: Every credential mint emits a structured
   audit event (`redis.credential.minted`) with the IAM principal
   or UAMI Object ID. Filter the audit log by event type to see
   per-process credential lifecycle. Preflight events are tagged
   `preflight: true` in the details for separate accounting.

5. **Startup preflight**: The adapter mints a credential at startup
   before accepting traffic. A misconfigured IAM role, missing Entra
   grant, or unreachable IMDS surfaces immediately at `/health`
   (status 503) rather than as 5xx errors to user requests after
   rolling deploy completes. Kubernetes readiness probes gate on
   this. Audit event: `redis.credential.refresh.failed` with
   `preflight: true`.

6. **Audit-stream observability**: Every credential lifecycle event
   flows through the existing audit pipeline to Splunk HEC or Loki
   (configured in Phase 1 via `AUDIT_SINKS=webhook`). Events carry
   pre-computed `expires_in_seconds` so SIEM alert rules don't need
   to parse ISO timestamps. The four signals customers asked for
   (mint rate by provider, refresh outcome, time-to-expiry,
   preflight status) are all queryable from the audit log without
   a separate metrics endpoint to secure.

## Open considerations

- **Local development** still uses static passwords with the
  gate flag. This is restricted to the developer's own machine
  — no production reach.
- **Self-hosted Redis** customers should use `mtls` or `vault`
  providers (Phase 3) rather than the static path.
- **Conditional Access** policies on the workload identity
  apply transitively to Redis access — useful for customers who
  want CA-based revocation.
- **No /metrics endpoint** — observability flows through the
  audit stream the customer already controls. There is no
  second access-control surface to manage. Customers wanting
  a synchronous health signal use `/health`, which already
  carries the credential preflight result.

## References

- Implementation prompts: `REDIS_CREDS_PHASE2_PROMPTS.md`
- Code: `okta_agent_proxy/cache/redis_credential_providers/`
- Audit fields: `okta_agent_proxy/cache/redis_provider.py` (search for `_emit_mint_audit`, `_emit_refresh_audit`)
- Preflight + health: `app.py` (search for `_redis_credential_preflight`)
