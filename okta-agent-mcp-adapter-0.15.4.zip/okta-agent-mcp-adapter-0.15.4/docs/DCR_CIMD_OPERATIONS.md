# DCR & CIMD Operations Guide

This guide covers enabling, testing, and managing Dynamic Client Registration (DCR) and Client ID Metadata Document (CIMD) flows in the Okta MCP Adapter.

## CIMD (Client ID Metadata Document)

CIMD allows MCP clients to identify themselves using a URL-based `client_id` that points to a JSON metadata document. The adapter fetches, validates, and evaluates a trust policy before allowing access.

### Enabling CIMD

CIMD support is always enabled. The trust policy controls which domains are accepted.

**Required environment variables:**

```bash
# Relay app credentials (required for CIMD OAuth flows)
RELAY_OKTA_CLIENT_ID=0oa_your_relay_app_id
RELAY_OKTA_CLIENT_SECRET=your_relay_secret

# Gateway base URL (used in redirect URIs)
GATEWAY_BASE_URL=https://your-gateway.example.com
```

**Optional trust policy configuration:**

```bash
# Comma-separated list of trusted domains (default: allow all)
CIMD_TRUSTED_DOMAINS=company.com,partner.example.com

# Trust mode: "allowlist" or "open" (default: open)
CIMD_TRUST_MODE=allowlist
```

### Testing CIMD with a Mock Document

1. Create a test CIMD document at `http://localhost:9999/oauth/client-metadata.json`:

```json
{
  "client_id": "http://localhost:9999/oauth/client-metadata.json",
  "client_name": "Test MCP Client",
  "redirect_uris": ["http://localhost:9999/callback"],
  "grant_types": ["authorization_code", "refresh_token"],
  "response_types": ["code"],
  "token_endpoint_auth_method": "none",
  "scope": "openid offline_access mcp:read"
}
```

2. Use the `client_id` URL in OAuth flows:

```bash
# Initiate authorization
curl "http://localhost:8000/oauth/authorize?\
client_id=http://localhost:9999/oauth/client-metadata.json&\
redirect_uri=http://localhost:9999/callback&\
response_type=code&\
scope=openid+offline_access"
```

### Example: CIMD Flow from VS Code

1. Configure the MCP server in VS Code settings:
   ```json
   {
     "mcp.servers": {
       "okta-gateway": {
         "url": "http://localhost:8000",
         "clientId": "https://your-client.example.com/oauth/client-metadata.json"
       }
     }
   }
   ```

2. VS Code initiates OAuth authorization with the URL-based `client_id`
3. Gateway fetches the CIMD document, validates it, checks trust policy
4. If trusted, the Confidential Relay starts an OAuth flow via the relay app
5. User authenticates with Okta, callback returns tokens
6. VS Code receives tokens and begins MCP communication

## DCR (Dynamic Client Registration)

DCR allows MCP clients to self-register via RFC 7591. The adapter creates agent records and optionally provisions Okta OIDC applications.

### Enabling DCR

```bash
# Enable DCR (default: true)
DCR_ENABLED=true

# Provision mode: "virtual" (default) or "okta_app"
DCR_PROVISION_OKTA_APP=false

# Auto-enable registered agents (default: true)
DCR_AUTO_ENABLE_AGENT=true

# Default resource access for new registrations
DCR_DEFAULT_BACKEND_ACCESS=hr-system,finance

# IP allowlist (optional, comma-separated CIDRs)
# DCR_IP_ALLOWLIST=10.0.0.0/8,192.168.0.0/16

# Require initial access token (optional)
# DCR_INITIAL_ACCESS_TOKEN=secret-token
```

For Okta-provisioned mode, also set:

```bash
DCR_PROVISION_OKTA_APP=true
OKTA_API_TOKEN=your-ssws-admin-token
OKTA_DOMAIN=dev-XXXXX.okta.com
```

### Testing DCR with curl

```bash
# Register a new client
curl -X POST http://localhost:8000/.well-known/oauth/registration \
  -H "Content-Type: application/json" \
  -d '{
    "client_name": "My MCP Client",
    "redirect_uris": ["http://localhost:9999/callback"],
    "grant_types": ["authorization_code"],
    "response_types": ["code"],
    "token_endpoint_auth_method": "client_secret_basic"
  }'

# Response:
# {
#   "client_id": "dcr_abc123...",
#   "client_secret": "...",
#   "client_name": "My MCP Client",
#   ...
# }
```

### Example: DCR Flow from Claude Code

```bash
# Register with Claude Code using DCR
claude mcp add okta-gateway http://localhost:8000 \
  --client-id "auto" \
  --scope "openid offline_access"

# Claude Code will:
# 1. Discover the registration endpoint from /.well-known/oauth-authorization-server
# 2. POST to /.well-known/oauth/registration
# 3. Receive client_id and client_secret
# 4. Use those credentials for OAuth authorization
```

### Managing DCR Registrations via Admin API

```bash
# Obtain an Okta access token — see docs/OPERATIONS.md § Admin API Authentication.
# (v0.15.x+: the adapter accepts only Okta OAuth tokens, no username/password.)
export OKTA_ADMIN_TOKEN="<paste token from Admin UI>"

# List registrations
curl -s http://localhost:8000/api/admin/dcr/registrations \
  -H "Authorization: Bearer $OKTA_ADMIN_TOKEN" | jq

# Get a specific registration
curl -s http://localhost:8000/api/admin/dcr/registrations/dcr_abc123 \
  -H "Authorization: Bearer \$OKTA_ADMIN_TOKEN" | jq

# Revoke a registration
curl -X POST http://localhost:8000/api/admin/dcr/registrations/dcr_abc123/revoke \
  -H "Authorization: Bearer \$OKTA_ADMIN_TOKEN"

# View DCR policy
curl -s http://localhost:8000/api/admin/dcr/policy \
  -H "Authorization: Bearer \$OKTA_ADMIN_TOKEN" | jq
```

## Troubleshooting

### CIMD Errors

| Error | Cause | Fix |
|-------|-------|-----|
| `CIMD fetch failed` | Cannot reach the client_id URL | Verify the URL is accessible from the gateway |
| `CIMD policy rejected` | Domain not in trust allowlist | Add domain to `CIMD_TRUSTED_DOMAINS` |
| `SSRF protection blocked` | URL resolves to private IP | The gateway blocks requests to private networks by default |
| `client_id mismatch` | CIMD `client_id` field doesn't match the URL | The `client_id` in the document must exactly match the URL used to fetch it |
| `Missing relay credentials` | `RELAY_OKTA_CLIENT_ID` not set | Configure relay app credentials |

### DCR Errors

| Error | Cause | Fix |
|-------|-------|-----|
| `DCR disabled` | `DCR_ENABLED=false` | Set `DCR_ENABLED=true` |
| `invalid_client_metadata` | Policy rejected the request | Check `DCR_IP_ALLOWLIST`, required fields |
| `server_error (Okta)` | Okta app provisioning failed | Check `OKTA_API_TOKEN` permissions |
| `Rate limited` | Too many registrations | Configure `DCR_RATE_LIMIT` |
| `Already registered` | Duplicate `client_name` | Use a unique name or revoke the existing registration |

### General

- Enable `LOG_LEVEL=DEBUG` to see detailed CIMD/DCR flow logs
- Check structured logs for events: `dcr_registration`, `cimd_resolution`
- Admin API at `/api/admin/dcr/registrations` shows all registrations with status
