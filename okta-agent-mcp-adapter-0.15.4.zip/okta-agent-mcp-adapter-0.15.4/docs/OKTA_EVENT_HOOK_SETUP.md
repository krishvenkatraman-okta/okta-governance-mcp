# Okta Event Hook Setup

Okta Event Hooks deliver real-time webhook notifications when AI Agent principals
change. This keeps the adapter's local agent records in sync without polling.

## Step 1: Ensure Adapter Is Publicly Reachable

Okta Event Hooks require an HTTPS URL. For local development, use ngrok:

```bash
ngrok http 8000
# Note the https://xxxx.ngrok.io URL
```

For production, the adapter must be accessible from the internet over HTTPS.

## Step 2: Create Event Hook in Okta

1. Navigate to **Workflow > Event Hooks** in the Okta Admin Console
2. Click **Create Event Hook**
3. Configure:
   - **Name:** `MCP Adapter Agent Sync`
   - **URL:** `https://your-adapter.example.com/api/hooks/okta/events`
   - **Authentication field:** `Authorization`
   - **Authentication secret:** A strong random value (this is the shared key)
4. Subscribe to events:
   - AI Agent lifecycle events (activate, deactivate, delete)
   - AI Agent connection events (create, update, delete)
   - Application lifecycle events (if monitoring linked apps)
5. Click **Save**
6. Okta sends a GET with `x-okta-verification-challenge` header to verify the endpoint
7. The adapter echoes the challenge back and the hook becomes **Active**

## Step 3: Set Environment Variable

```bash
# Must match EXACTLY what you entered as the authentication secret in Okta
# Okta sends it as: Authorization: <your-value>
OKTA_EVENT_HOOK_SECRET=<your-value>
```

Add this to your `.env` file or Docker Compose environment.

## How It Works

When an AI Agent is created, activated, deactivated, or has its connections
updated in Okta, the Event Hook sends a POST to `/api/hooks/okta/events`.

The adapter:
1. Validates the shared key (Authorization header)
2. Extracts AI Agent IDs from the event targets
3. Calls `sync_agent_from_event()` for each affected agent
4. The sync uses the adapter's service app credentials (private_key_jwt)
   to re-fetch agent details and update the local record

## Authentication

Event Hook uses shared key authentication (not admin JWT or Okta OAuth):
- The payload contains only event metadata (event type, target IDs)
- No user PII or credentials are transmitted
- The adapter re-fetches full data from Okta via authenticated API calls

## Not Required for Basic Operation

Event hooks enable real-time sync but are **NOT** required. Without them:
- Manual sync via Admin UI buttons works (Sync per agent, Sync All)
- Manual sync via Admin API works (POST /api/admin/okta/sync/*)
- The adapter just won't auto-update when Okta changes occur

## Testing

Use the included simulator script:

```bash
# Simulate verification handshake
python ops_scripts/simulate_okta_event_hook.py --verify

# Simulate agent activation event
python ops_scripts/simulate_okta_event_hook.py \
  --event agent.activate \
  --agent-id agtXXXXXX \
  --secret "your-shared-key"

# See all options
python ops_scripts/simulate_okta_event_hook.py --help
```

## Troubleshooting

**Hook stays in "Unverified" state:**
- Ensure the adapter is reachable from the internet (HTTPS required)
- Check adapter logs for the verification GET request
- Verify the URL path is exactly `/api/hooks/okta/events`

**Events received but sync fails:**
- Check that `OKTA_SERVICE_CLIENT_ID` is set (needed for service auth)
- Check that the agent exists in the adapter's store (imported first)
- Enable `LOG_LEVEL=DEBUG` to see sync details

**401 Unauthorized:**
- `OKTA_EVENT_HOOK_SECRET` must match the secret configured in Okta exactly
- The value is compared as-is (case-sensitive, no trimming)
