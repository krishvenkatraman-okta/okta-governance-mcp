# Resource Setup Guide

## Overview

The adapter starts with an empty database. Resources must be registered via the Admin API or Admin UI before agents can route tool calls to them. This guide walks through starting the example resource servers and registering them with the adapter.

## Prerequisites

- The adapter stack is running (`./setup.sh` completed successfully)
- You have an Okta access token for the Admin UI OIDC app. See
  [docs/OPERATIONS.md § Admin API Authentication](OPERATIONS.md#admin-api-authentication)
  for how to obtain one (password login was removed in v0.15.x):

```bash
export OKTA_ADMIN_TOKEN="<paste token from Admin UI>"
```

## Starting the Example Resources

The example resource servers are defined in a separate Docker Compose overlay. Start them alongside the core stack:

```bash
docker compose -f docker-compose.yml -f docker-compose.examples.yml up -d
```

This starts:

| Service | Container | Port | Auth Method |
|---------|-----------|------|-------------|
| HR MCP Server | `hr-mcp-server` | 8001 | Pre-Shared Key (PSK) |
| Deploy MCP Server | `deploy-mcp-server` | 8005 | Bearer passthrough (demo) / okta-cross-app (production) |

## Registering the HR System Resource

The HR resource uses pre-shared key authentication. The adapter adds an `X-API-Key` header to every proxied request.

```bash
curl -s -X POST http://localhost:8000/api/admin/backends \
  -H "Authorization: Bearer \$OKTA_ADMIN_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "name": "hr-system",
    "url": "http://hr-mcp-server:8001",
    "paths": ["/hr"],
    "auth_method": "pre-shared-key",
    "auth_config": {
      "header_name": "X-API-Key",
      "key": "demo-psk-secret-do-not-use-in-prod"
    },
    "description": "HR System MCP resource (employee data)",
    "timeout_seconds": 30,
    "enabled": true
  }' | python3 -m json.tool
```

The `key` value must match the `HR_PSK_SECRET` environment variable in `docker-compose.examples.yml` (default: `demo-psk-secret-do-not-use-in-prod`). If you changed it in your `.env`, use that value instead.

Verify the resource was created:

```bash
curl -s http://localhost:8000/api/admin/backends/hr-system \
  -H "Authorization: Bearer \$OKTA_ADMIN_TOKEN" | python3 -m json.tool
```

## Registering the Deploy Server Resource

The deploy server defaults to **bearer passthrough** mode for demos (auth disabled on the server side). In this mode, the adapter forwards the user's Okta token directly without any token exchange.

```bash
curl -s -X POST http://localhost:8000/api/admin/backends \
  -H "Authorization: Bearer \$OKTA_ADMIN_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "name": "deploy-server",
    "url": "http://deploy-mcp-server:8005",
    "paths": ["/deploy"],
    "auth_method": "bearer-passthrough",
    "auth_config": {},
    "description": "Deployment operations MCP resource",
    "timeout_seconds": 30,
    "enabled": true
  }' | python3 -m json.tool
```

> **Production note:** For real Cross-App Access (XAA), change `auth_method` to `okta-cross-app` and provide the target authorization server details in `auth_config`. See `examples/05-deploy-server/README.md` for full XAA setup instructions.

Verify:

```bash
curl -s http://localhost:8000/api/admin/backends/deploy-server \
  -H "Authorization: Bearer \$OKTA_ADMIN_TOKEN" | python3 -m json.tool
```

## Registering an Agent

Agents need a `backend_access` list that controls which resources they can reach. Create one via the Admin API:

```bash
curl -s -X POST http://localhost:8000/api/admin/agents \
  -H "Authorization: Bearer \$OKTA_ADMIN_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "agent_id": "my-agent",
    "agent_name": "My Agent",
    "client_id": "<your-okta-client-id>",
    "backend_access": ["hr-system", "deploy-server"],
    "enabled": true
  }' | python3 -m json.tool
```

Replace `<your-okta-client-id>` with the client ID of the OIDC application you created in Okta for this agent.

> **Alternatively**, import agents directly from your Okta org using the Admin UI's **Okta Import** feature (requires OAuth for Okta scopes on the Admin UI app).

## Using the Admin UI

All of the above can also be done through the Admin UI at `http://localhost:3001`:

1. Log in with your admin credentials
2. Navigate to **Backends** and click **Add Backend** to register each resource
3. Navigate to **Agents** and click **Add Agent** to create an agent (or use **Okta Import** to import from your Okta org)

## Verifying End-to-End

Once resources and an agent are registered, test the full pipeline with an Okta access token:

```bash
curl -X POST http://localhost:8000/hr \
  -H "Authorization: Bearer <okta_access_token>" \
  -H "X-MCP-Agent: my-agent" \
  -H "Content-Type: application/json" \
  -d '{"jsonrpc":"2.0","id":"1","method":"tools/list","params":{}}'
```

A successful response returns the HR resource's tool catalog:

```json
{
  "jsonrpc": "2.0",
  "id": "1",
  "result": {
    "tools": [
      {"name": "health_check", "description": "..."},
      {"name": "get_employee", "description": "..."},
      {"name": "search_employees", "description": "..."},
      {"name": "get_org_chart", "description": "..."},
      {"name": "get_leave_balance", "description": "..."},
      {"name": "submit_leave_request", "description": "..."}
    ]
  }
}
```

If using the unified endpoint (`POST /`), tools are namespaced with the resource name (e.g., `hr-system__get_employee`).
