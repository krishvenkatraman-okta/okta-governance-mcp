#!/usr/bin/env bash
# Apply pending SQL migrations for the Okta MCP Adapter.
#
# Replaces the prior `alembic upgrade head` invocation (DB migration prompt P03).
# Uses the in-tree runner at okta_agent_proxy/storage/migrate.py.
#
# Usage:
#   ./run_migrations.sh                       # docker-compose mode (default; matches legacy behavior)
#   MIGRATION_MODE=local ./run_migrations.sh  # run against $DATABASE_URL from the host

set -euo pipefail

MODE="${MIGRATION_MODE:-docker}"

if [[ "$MODE" == "docker" ]]; then
    echo "Running migrations inside okta-agent-mcp-adapter container..."
    exec docker-compose exec -T okta-agent-mcp-adapter sh -c \
        "cd /app && python -m okta_agent_proxy.storage.migrate upgrade --migrations-dir deploy/migrations/sql $*"
else
    exec python -m okta_agent_proxy.storage.migrate upgrade \
        --migrations-dir deploy/migrations/sql "$@"
fi
