"""
Target MCP Metadata Discovery Client

Implements RFC 9728 Protected Resource Metadata discovery.

Supports two patterns for ID-JAG cross-app access:

1. Static Pattern (configured):
   Gateway has pre-configured auth server details
   Faster, simpler, no discovery needed

2. Dynamic Pattern (discovered):
   Gateway queries target's /.well-known/mcp-protected-resource endpoint
   Extracts authorization server details dynamically
   More flexible, works with any compliant target
"""

import asyncio
import concurrent.futures
import logging
import httpx
from typing import Optional, Dict, Any
from datetime import datetime, timedelta
from cachetools import TTLCache

from okta_agent_proxy.cache.serializers import serialize_json, deserialize_json

logger = logging.getLogger(__name__)

# Fallback cache for when no CacheService is provided
# Key: target_url, TTL: 3600 seconds (1 hour)
_metadata_cache: TTLCache = TTLCache(maxsize=1000, ttl=3600)

_METADATA_KEY_PREFIX = "metadata:"
_METADATA_TTL = 7200  # 2 hours — metadata is slow-changing


class MetadataDiscoveryClient:
    """
    Discovers Protected Resource Metadata from target MCP servers.

    Per RFC 9728:
    https://datatracker.ietf.org/doc/html/draft-ietf-oauth-protected-resource-metadata-00

    Endpoint: https://target-mcp.example.com/.well-known/mcp-protected-resource
    """

    def __init__(self, timeout: float = 10.0, cache_service=None):
        """
        Initialize discovery client.

        Args:
            timeout: HTTP request timeout in seconds
            cache_service: Optional CacheService for shared/distributed caching
        """
        self.timeout = timeout
        self._cache_service = cache_service
        logger.info("MetadataDiscoveryClient initialized")
    
    async def discover_metadata(
        self,
        target_url: str,
        force_refresh: bool = False
    ) -> Optional[Dict[str, Any]]:
        """
        Discover protected resource metadata from target MCP server.
        
        Queries: https://target_url/.well-known/mcp-protected-resource
        
        Args:
            target_url: Base URL of target MCP server (e.g., https://example.com)
            force_refresh: Skip cache and fetch fresh metadata
            
        Returns:
            Metadata dict with authorization_servers, scopes, etc.
            Returns None if discovery fails
        """
        # Normalize URL
        target_url = target_url.rstrip("/")

        # Check cache first
        if not force_refresh:
            cached = self._get_cached(target_url)
            if cached is not None:
                logger.debug(f"Using cached metadata for {target_url}")
                return cached

        # Build well-known URL
        well_known_url = f"{target_url}/.well-known/mcp-protected-resource"

        try:
            logger.debug(f"Discovering metadata from {well_known_url}")

            async with httpx.AsyncClient() as client:
                response = await client.get(
                    well_known_url,
                    timeout=self.timeout,
                    headers={"Accept": "application/json"}
                )
                response.raise_for_status()

                metadata = response.json()
                logger.debug(f"Discovered metadata for {target_url}: {metadata}")

                # Cache the metadata
                self._set_cached(target_url, metadata)

                return metadata
        
        except httpx.HTTPStatusError as e:
            logger.warning(
                f"HTTP error discovering metadata for {target_url}: "
                f"{e.response.status_code} - {e.response.text}"
            )
            return None
        
        except httpx.RequestError as e:
            logger.warning(f"Network error discovering metadata for {target_url}: {e}")
            return None
        
        except Exception as e:
            logger.warning(
                f"Error discovering metadata for {target_url}: {e}",
                exc_info=True
            )
            return None
    
    async def extract_auth_server_details(
        self,
        target_url: str,
        force_refresh: bool = False
    ) -> Optional[Dict[str, str]]:
        """
        Extract authorization server details from discovered metadata.
        
        Looks for:
        - authorization_servers (array of issuer URLs)
        - authorization_server_metadata (dict with token_endpoint, etc.)
        
        Returns mapping that can be used for ID-JAG exchange.
        
        Args:
            target_url: Base URL of target MCP server
            force_refresh: Skip cache and fetch fresh metadata
            
        Returns:
            Dict with keys: target_authorization_server, target_token_endpoint
            Returns None if extraction fails
        """
        metadata = await self.discover_metadata(target_url, force_refresh)
        
        if not metadata:
            logger.error(f"Could not discover metadata for {target_url}")
            return None
        
        try:
            # Extract authorization server details
            auth_servers = metadata.get("authorization_servers", [])
            auth_server_metadata = metadata.get("authorization_server_metadata", {})
            
            if not auth_servers:
                logger.error(f"No authorization_servers in metadata for {target_url}")
                return None
            
            # Use first authorization server
            target_authorization_server = auth_servers[0]
            
            # Extract token endpoint
            token_endpoint = auth_server_metadata.get("token_endpoint")
            
            if not token_endpoint:
                # Build from issuer if not provided
                if target_authorization_server:
                    token_endpoint = f"{target_authorization_server}/oauth2/v1/token"
            
            result = {
                "target_authorization_server": target_authorization_server,
                "target_token_endpoint": token_endpoint,
                "full_metadata": metadata
            }
            
            logger.info(
                f"Extracted auth server details for {target_url}: "
                f"{target_authorization_server}"
            )
            
            return result
        
        except Exception as e:
            logger.error(
                f"Error extracting auth server details from metadata: {e}",
                exc_info=True
            )
            return None
    
    def clear_cache(self, target_url: Optional[str] = None):
        """
        Clear cached metadata.

        Args:
            target_url: Clear cache for specific URL, or None to clear all
        """
        if target_url:
            target_url = target_url.rstrip("/")
            if target_url in _metadata_cache:
                del _metadata_cache[target_url]
            if self._cache_service:
                try:
                    self._run_async(self._cache_service.delete(self._service_key(target_url)))
                except Exception:
                    pass
            logger.debug(f"Cleared cache for {target_url}")
        else:
            _metadata_cache.clear()
            if self._cache_service:
                try:
                    self._run_async(self._cache_service.clear_prefix(_METADATA_KEY_PREFIX))
                except Exception:
                    pass
            logger.debug("Cleared all metadata cache")

    # ------------------------------------------------------------------
    # CacheService helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _service_key(target_url: str) -> str:
        return f"{_METADATA_KEY_PREFIX}{target_url}"

    @staticmethod
    def _run_async(coro):
        try:
            loop = asyncio.get_running_loop()
        except RuntimeError:
            loop = None
        if loop and loop.is_running():
            with concurrent.futures.ThreadPoolExecutor() as pool:
                return pool.submit(asyncio.run, coro).result()
        else:
            return asyncio.run(coro)

    def _get_cached(self, target_url: str) -> Optional[Dict[str, Any]]:
        """Check local TTLCache first, then CacheService."""
        if target_url in _metadata_cache:
            return _metadata_cache[target_url]

        if self._cache_service:
            try:
                raw = self._run_async(self._cache_service.get(self._service_key(target_url)))
                if raw is not None:
                    data = deserialize_json(raw)
                    # Promote to local cache
                    _metadata_cache[target_url] = data
                    return data
            except Exception as e:
                logger.warning(f"CacheService read failed for metadata {target_url}: {e}")

        return None

    def _set_cached(self, target_url: str, metadata: Dict[str, Any]) -> None:
        """Write to both local TTLCache and CacheService."""
        _metadata_cache[target_url] = metadata

        if self._cache_service:
            try:
                raw = serialize_json(metadata)
                self._run_async(self._cache_service.set(
                    self._service_key(target_url), raw, ttl_seconds=_METADATA_TTL
                ))
            except Exception as e:
                logger.warning(f"CacheService write failed for metadata {target_url}: {e}")


# Global discovery client instance
_discovery_client: Optional[MetadataDiscoveryClient] = None


def get_discovery_client(cache_service=None) -> MetadataDiscoveryClient:
    """Get or create global discovery client instance."""
    global _discovery_client
    if _discovery_client is None:
        _discovery_client = MetadataDiscoveryClient(cache_service=cache_service)
    return _discovery_client

