"""
Configuration cache for agent and resource lookups.

Provides read-through caching with CacheService for the hottest PostgreSQL queries.
Data changes only via Admin API, which triggers invalidation.

Key patterns:
  agent:{agent_id}           — single agent by ID
  agent_name:{agent_name}    — secondary index by name
  all_agents                 — full agent list
  resource:{name}            — single resource by name
  all_resources              — full resource list
  route_table                — resource routing table
"""

import logging
from typing import Optional, List, Dict, Any

from okta_agent_proxy.cache.serializers import (
    serialize_json,
    deserialize_json,
    serialize_encrypted,
    deserialize_encrypted,
)

logger = logging.getLogger(__name__)


class ConfigCache:
    """Read-through cache for agent and resource configuration."""

    def __init__(self, cache_service, ttl_seconds: int = 300, encryption_service=None):
        """
        Args:
            cache_service: CacheService instance for L1/L2 caching.
            ttl_seconds: Cache TTL in seconds (default 5 minutes).
            encryption_service: Optional EncryptionService for encrypting
                agent data that contains secrets (private_key, client_secret).
        """
        self._svc = cache_service
        self._ttl = ttl_seconds
        self._enc = encryption_service

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _serialize_agent(self, data: dict) -> str:
        if self._enc:
            return serialize_encrypted(data, self._enc)
        return serialize_json(data)

    def _deserialize_agent(self, raw: str) -> dict:
        if self._enc:
            return deserialize_encrypted(raw, self._enc)
        return deserialize_json(raw)

    # ------------------------------------------------------------------
    # Agent methods
    # ------------------------------------------------------------------

    async def get_agent(self, agent_id: str) -> Optional[dict]:
        try:
            raw = await self._svc.get(f"agent:{agent_id}")
            if raw is not None:
                return self._deserialize_agent(raw)
        except Exception as e:
            logger.warning(f"ConfigCache get_agent failed: {e}")
        return None

    async def set_agent(self, agent_id: str, data: dict) -> None:
        try:
            serialized = self._serialize_agent(data)
            await self._svc.set(f"agent:{agent_id}", serialized, ttl_seconds=self._ttl)
            # Secondary index by name
            agent_name = data.get("agent_name") or data.get("agent_id")
            if agent_name:
                await self._svc.set(f"agent_name:{agent_name}", serialized, ttl_seconds=self._ttl)
        except Exception as e:
            logger.warning(f"ConfigCache set_agent failed: {e}")

    async def invalidate_agent(self, agent_id: str, agent_name: str = None) -> None:
        try:
            await self._svc.delete(f"agent:{agent_id}")
            if agent_name:
                await self._svc.delete(f"agent_name:{agent_name}")
            # Also bust the all-agents list
            await self._svc.delete("all_agents")
        except Exception as e:
            logger.warning(f"ConfigCache invalidate_agent failed: {e}")

    async def get_agent_by_name(self, agent_name: str) -> Optional[dict]:
        try:
            raw = await self._svc.get(f"agent_name:{agent_name}")
            if raw is not None:
                return self._deserialize_agent(raw)
        except Exception as e:
            logger.warning(f"ConfigCache get_agent_by_name failed: {e}")
        return None

    async def get_all_agents(self) -> Optional[list]:
        try:
            raw = await self._svc.get("all_agents")
            if raw is not None:
                return self._deserialize_agent(raw)
        except Exception as e:
            logger.warning(f"ConfigCache get_all_agents failed: {e}")
        return None

    async def set_all_agents(self, data: list) -> None:
        try:
            serialized = self._serialize_agent(data)
            await self._svc.set("all_agents", serialized, ttl_seconds=self._ttl)
        except Exception as e:
            logger.warning(f"ConfigCache set_all_agents failed: {e}")

    async def invalidate_all_agents(self) -> None:
        try:
            await self._svc.delete("all_agents")
        except Exception as e:
            logger.warning(f"ConfigCache invalidate_all_agents failed: {e}")

    # ------------------------------------------------------------------
    # Resource methods
    # ------------------------------------------------------------------

    async def get_resource(self, name: str) -> Optional[dict]:
        try:
            raw = await self._svc.get(f"resource:{name}")
            if raw is not None:
                return deserialize_json(raw)
        except Exception as e:
            logger.warning(f"ConfigCache get_resource failed: {e}")
        return None

    async def set_resource(self, name: str, data: dict) -> None:
        try:
            await self._svc.set(f"resource:{name}", serialize_json(data), ttl_seconds=self._ttl)
        except Exception as e:
            logger.warning(f"ConfigCache set_resource failed: {e}")

    async def invalidate_resource(self, name: str) -> None:
        try:
            await self._svc.delete(f"resource:{name}")
            await self._svc.delete("all_resources")
        except Exception as e:
            logger.warning(f"ConfigCache invalidate_resource failed: {e}")

    async def get_all_resources(self) -> Optional[list]:
        try:
            raw = await self._svc.get("all_resources")
            if raw is not None:
                return deserialize_json(raw)
        except Exception as e:
            logger.warning(f"ConfigCache get_all_resources failed: {e}")
        return None

    async def set_all_resources(self, data: list) -> None:
        try:
            await self._svc.set("all_resources", serialize_json(data), ttl_seconds=self._ttl)
        except Exception as e:
            logger.warning(f"ConfigCache set_all_resources failed: {e}")

    async def invalidate_all_resources(self) -> None:
        try:
            await self._svc.delete("all_resources")
        except Exception as e:
            logger.warning(f"ConfigCache invalidate_all_resources failed: {e}")

    async def invalidate_route_table(self) -> None:
        try:
            await self._svc.delete("route_table")
        except Exception as e:
            logger.warning(f"ConfigCache invalidate_route_table failed: {e}")
