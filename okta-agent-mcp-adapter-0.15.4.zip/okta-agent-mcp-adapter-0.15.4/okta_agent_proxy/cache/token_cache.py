"""
Token cache implementation using cachetools
Stores resource tokens with automatic TTL expiration

Supports two modes:
- Standalone: uses cachetools.TTLCache directly (backward compatible)
- CacheService: delegates to shared CacheService with optional encryption
"""

import asyncio
import logging
from typing import Optional
from cachetools import TTLCache

logger = logging.getLogger(__name__)

# Key prefix for tokens stored via CacheService
_TOKEN_PREFIX = "token:"


class TokenCache:
    """
    In-memory token cache with TTL (Time To Live) expiration.

    Keys are formatted as: {user_id}:{resource_name}:{auth_server}
    Values are resource JWT tokens that auto-expire after ttl_seconds.
    """

    def __init__(
        self,
        max_size: int = 50000,
        ttl_seconds: int = 3600,
        cache_service: Optional["CacheService"] = None,
        encryption_service: Optional["EncryptionService"] = None,
    ):
        """
        Initialize token cache.

        Args:
            max_size: Maximum number of tokens to cache
            ttl_seconds: Time to live for cached tokens (default 1 hour)
            cache_service: Optional CacheService for shared/distributed caching
            encryption_service: Optional EncryptionService for encrypting tokens in cache
        """
        self.cache = TTLCache(maxsize=max_size, ttl=ttl_seconds)
        self.max_size = max_size
        self.ttl_seconds = ttl_seconds
        self._cache_service = cache_service
        self._encryption_service = encryption_service

        if cache_service and not encryption_service:
            logger.warning(
                "TokenCache: cache_service provided without encryption_service — "
                "tokens will be stored unencrypted in the cache store"
            )

        mode = "CacheService" if cache_service else "standalone"
        encrypted = "encrypted" if (cache_service and encryption_service) else "plaintext"
        logger.info(
            f"TokenCache initialized: max_size={max_size}, ttl={ttl_seconds}s, "
            f"mode={mode}, storage={encrypted}"
        )

    @staticmethod
    def _make_key(user_id: str, resource_name: str, auth_server: str = "") -> str:
        """
        Generate cache key from components (legacy — no agent scoping).

        Args:
            user_id: User identifier (from token 'sub' claim)
            resource_name: Resource (MCP server) name
            auth_server: Authorization server ID (optional)

        Returns:
            Cache key string
        """
        if auth_server:
            return f"{user_id}:{resource_name}:{auth_server}"
        return f"{user_id}:{resource_name}"

    @staticmethod
    def _build_cache_key(
        user_id: str,
        resource_name: str,
        agent_id: str | None = None,
        connection_id: str | None = None,
    ) -> str:
        """Build connection-scoped cache key.

        Format: {user_id}:{agent_id}:{connection_id}:{resource_name}
        Falls back to {user_id}:{resource_name} for local resources.
        """
        parts = [user_id]
        if agent_id:
            parts.append(agent_id)
        if connection_id:
            parts.append(connection_id)
        parts.append(resource_name)
        return ":".join(parts)

    def _service_key(self, key: str) -> str:
        """Build the CacheService key with token prefix."""
        return f"{_TOKEN_PREFIX}{key}"

    def _serialize(self, value) -> str:
        """Serialize a value for storage in CacheService."""
        from okta_agent_proxy.cache.serializers import serialize_json
        raw = serialize_json(value) if not isinstance(value, str) else value
        if self._encryption_service:
            from okta_agent_proxy.cache.serializers import serialize_encrypted
            return serialize_encrypted(value, self._encryption_service)
        return raw

    @staticmethod
    def _restore_datetimes(result):
        """Restore ISO-format datetime strings back to datetime objects."""
        if isinstance(result, dict) and "expires_at" in result:
            from datetime import datetime as _dt
            try:
                result["expires_at"] = _dt.fromisoformat(result["expires_at"])
            except (ValueError, TypeError):
                pass
        return result

    def _deserialize(self, value: str):
        """Deserialize a value from CacheService."""
        if self._encryption_service:
            from okta_agent_proxy.cache.serializers import deserialize_encrypted
            return self._restore_datetimes(deserialize_encrypted(value, self._encryption_service))
        import json
        try:
            return self._restore_datetimes(json.loads(value))
        except (json.JSONDecodeError, TypeError):
            return value

    def _run_async(self, coro):
        """Run an async coroutine from sync context."""
        try:
            loop = asyncio.get_running_loop()
        except RuntimeError:
            loop = None

        if loop and loop.is_running():
            # We're inside an async context — create a task and use a future
            import concurrent.futures
            with concurrent.futures.ThreadPoolExecutor() as pool:
                return pool.submit(asyncio.run, coro).result()
        else:
            return asyncio.run(coro)

    def get(
        self,
        user_id: str,
        resource_name: str,
        auth_server: str = "",
        agent_id: str | None = None,
        connection_id: str | None = None,
    ) -> Optional[str]:
        """
        Get cached resource token.

        Returns None if not found or expired (TTLCache auto-removes expired).

        Args:
            user_id: User identifier
            resource_name: Resource name
            auth_server: Authorization server ID (optional, legacy)
            agent_id: Agent ID for connection-scoped isolation (optional)
            connection_id: Okta connection ID for isolation (optional)

        Returns:
            Cached token string or None
        """
        if agent_id or connection_id:
            key = self._build_cache_key(user_id, resource_name, agent_id, connection_id)
        else:
            key = self._make_key(user_id, resource_name, auth_server)

        if self._cache_service:
            try:
                raw = self._run_async(self._cache_service.get(self._service_key(key)))
                if raw is not None:
                    logger.debug(
                        "[TOKEN-CACHE] Hit (service) for user=%s agent=%s connection=%s resource=%s",
                        user_id, agent_id, connection_id, resource_name,
                    )
                    return self._deserialize(raw)
                logger.debug(
                    "[TOKEN-CACHE] Miss (service) for user=%s agent=%s connection=%s resource=%s",
                    user_id, agent_id, connection_id, resource_name,
                )
                return None
            except Exception as e:
                logger.warning(f"CacheService get failed, falling back to local: {e}")

        token = self.cache.get(key)
        logger.debug(
            "[TOKEN-CACHE] %s for user=%s agent=%s connection=%s resource=%s",
            "Hit" if token else "Miss", user_id, agent_id, connection_id, resource_name,
        )
        return token

    def set(
        self,
        user_id: str,
        resource_name: str,
        token: str,
        auth_server: str = "",
        ttl_seconds: Optional[int] = None,
        agent_id: str | None = None,
        connection_id: str | None = None,
    ) -> None:
        """
        Cache a resource token.

        Args:
            user_id: User identifier
            resource_name: Resource name
            token: Resource JWT token to cache
            auth_server: Authorization server ID (optional, legacy)
            ttl_seconds: Custom TTL for this token (uses default if not provided)
            agent_id: Agent ID for connection-scoped isolation (optional)
            connection_id: Okta connection ID for isolation (optional)
        """
        if agent_id or connection_id:
            key = self._build_cache_key(user_id, resource_name, agent_id, connection_id)
        else:
            key = self._make_key(user_id, resource_name, auth_server)

        if self._cache_service:
            try:
                serialized = self._serialize(token)
                ttl = ttl_seconds if ttl_seconds is not None else self.ttl_seconds
                self._run_async(
                    self._cache_service.set(self._service_key(key), serialized, ttl_seconds=ttl)
                )
                logger.info(
                    "[TOKEN-CACHE] Cached (service) user=%s agent=%s connection=%s resource=%s (TTL: %ds)",
                    user_id, agent_id, connection_id, resource_name, ttl,
                )
                return
            except Exception as e:
                logger.warning(f"CacheService set failed, falling back to local: {e}")

        self.cache[key] = token
        logger.info(
            "[TOKEN-CACHE] Cached user=%s agent=%s connection=%s resource=%s (TTL: %ds)",
            user_id, agent_id, connection_id, resource_name, self.ttl_seconds,
        )

    def invalidate(
        self,
        user_id: str,
        resource_name: str = "",
        auth_server: str = "",
        agent_id: str | None = None,
        connection_id: str | None = None,
    ) -> None:
        """
        Invalidate cached tokens for a user.

        Args:
            user_id: User identifier
            resource_name: Optional - specific resource to invalidate
            auth_server: Optional - specific auth server to invalidate
            agent_id: Agent ID for connection-scoped isolation (optional)
            connection_id: Okta connection ID for isolation (optional)
        """
        if resource_name:
            if agent_id or connection_id:
                key = self._build_cache_key(user_id, resource_name, agent_id, connection_id)
            else:
                key = self._make_key(user_id, resource_name, auth_server)
            if self._cache_service:
                try:
                    self._run_async(self._cache_service.delete(self._service_key(key)))
                    logger.info(
                        "[TOKEN-CACHE] Invalidated (service) user=%s agent=%s connection=%s resource=%s",
                        user_id, agent_id, connection_id, resource_name,
                    )
                    return
                except Exception as e:
                    logger.warning(f"CacheService delete failed, falling back to local: {e}")

            if key in self.cache:
                del self.cache[key]
                logger.info(
                    "[TOKEN-CACHE] Invalidated user=%s agent=%s connection=%s resource=%s",
                    user_id, agent_id, connection_id, resource_name,
                )
        else:
            if self._cache_service:
                try:
                    prefix = f"{_TOKEN_PREFIX}{user_id}"
                    count = self._run_async(self._cache_service.clear_prefix(prefix))
                    logger.info(f"All tokens invalidated (service) for user: {user_id} ({count} tokens)")
                    return
                except Exception as e:
                    logger.warning(f"CacheService clear_prefix failed, falling back to local: {e}")

            keys_to_delete = [k for k in self.cache.keys() if k.startswith(user_id)]
            for key in keys_to_delete:
                del self.cache[key]
            logger.info(f"All tokens invalidated for user: {user_id} ({len(keys_to_delete)} tokens)")

    def invalidate_all_for_user(self, user_id: str) -> None:
        """Sync convenience wrapper. Prefer ainvalidate_all_for_user
        from async call-sites (it does not block on the thread-pool
        fallback used by _run_async under a running loop).
        """
        self._invalidate_user_id_family(user_id)
        self._invalidate_sts_family(user_id)

    async def ainvalidate_all_for_user(self, user_id: str) -> None:
        """Async variant — awaits CacheService directly.

        Orchestrator (auth/global_logout.py) calls this.
        """
        await self._ainvalidate_user_id_family(user_id)
        await self._ainvalidate_sts_family(user_id)

    # ---- Helpers for invalidate_all_for_user / ainvalidate_all_for_user ----

    def _invalidate_user_id_family(self, user_id: str) -> None:
        """Clear ID-JAG / connection-scoped keys for a user (sync)."""
        self.invalidate(user_id)

    async def _ainvalidate_user_id_family(self, user_id: str) -> None:
        """Clear ID-JAG / connection-scoped keys for a user (async)."""
        if self._cache_service:
            try:
                prefix = f"{_TOKEN_PREFIX}{user_id}"
                count = await self._cache_service.clear_prefix(prefix)
                logger.info(
                    f"All tokens invalidated (service) for user: {user_id} ({count} tokens)"
                )
            except Exception as e:
                logger.warning(f"CacheService clear_prefix failed, falling back to local: {e}")
        keys_to_delete = [
            k for k in list(self.cache.keys())
            if isinstance(k, str) and k.startswith(user_id)
        ]
        for key in keys_to_delete:
            self.cache.pop(key, None)
        if keys_to_delete:
            logger.info(
                f"All tokens invalidated (local) for user: {user_id} ({len(keys_to_delete)} tokens)"
            )

    @staticmethod
    def _sts_prefix_for_user(user_id: str) -> str:
        import hashlib
        user_hash = hashlib.sha256(user_id.encode()).hexdigest()[:12]
        return f"sts:{user_hash}:"

    def _invalidate_sts_family(self, user_id: str) -> None:
        """Clear sts:<user_hash>:* entries (sync)."""
        sts_prefix = self._sts_prefix_for_user(user_id)
        if self._cache_service:
            try:
                self._run_async(
                    self._cache_service.clear_prefix(f"{_TOKEN_PREFIX}{sts_prefix}")
                )
                logger.info(
                    f"[TOKEN-CACHE] STS sweep (service) for prefix={sts_prefix}"
                )
            except Exception as e:
                logger.warning(
                    f"CacheService STS clear_prefix failed, falling back to local: {e}"
                )
        local_keys = [k for k in list(self.cache.keys())
                      if isinstance(k, str) and k.startswith(sts_prefix)]
        for k in local_keys:
            self.cache.pop(k, None)
        if local_keys:
            logger.info(
                f"[TOKEN-CACHE] STS swept {len(local_keys)} local entries "
                f"for prefix={sts_prefix}"
            )

    async def _ainvalidate_sts_family(self, user_id: str) -> None:
        """Clear sts:<user_hash>:* entries (async)."""
        sts_prefix = self._sts_prefix_for_user(user_id)
        if self._cache_service:
            try:
                await self._cache_service.clear_prefix(f"{_TOKEN_PREFIX}{sts_prefix}")
                logger.info(
                    f"[TOKEN-CACHE] STS sweep (service) for prefix={sts_prefix}"
                )
            except Exception as e:
                logger.warning(
                    f"CacheService STS clear_prefix failed, falling back to local: {e}"
                )
        local_keys = [k for k in list(self.cache.keys())
                      if isinstance(k, str) and k.startswith(sts_prefix)]
        for k in local_keys:
            self.cache.pop(k, None)
        if local_keys:
            logger.info(
                f"[TOKEN-CACHE] STS swept {len(local_keys)} local entries "
                f"for prefix={sts_prefix}"
            )

    def stats(self) -> dict:
        """
        Get cache statistics.

        Returns:
            Dictionary with cache stats
        """
        return {
            "current_size": len(self.cache),
            "max_size": self.max_size,
            "usage_percent": (len(self.cache) / self.max_size) * 100,
            "ttl_seconds": self.ttl_seconds
        }

    # ---- STS token cache methods ----

    @staticmethod
    def _make_sts_key(user_id: str, resource_indicator: str) -> str:
        """Generate cache key for STS tokens.

        Uses a hash-based namespace to avoid overly long keys from ORN values.
        Format: sts:{user_sub_hash}:{resource_indicator_hash}
        """
        import hashlib
        user_hash = hashlib.sha256(user_id.encode()).hexdigest()[:12]
        ri_hash = hashlib.sha256(resource_indicator.encode()).hexdigest()[:12]
        return f"sts:{user_hash}:{ri_hash}"

    def get_sts_token(self, user_id: str, resource_indicator: str) -> Optional[str]:
        """Get cached STS ISV access token.

        Args:
            user_id: User identifier (from token 'sub' claim)
            resource_indicator: resourceIndicator ORN from the Managed Connection

        Returns:
            Cached access token string or None
        """
        key = self._make_sts_key(user_id, resource_indicator)

        if self._cache_service:
            try:
                raw = self._run_async(self._cache_service.get(self._service_key(key)))
                if raw is not None:
                    logger.debug(f"STS Cache HIT (service): {key}")
                    return self._deserialize(raw)
                logger.debug(f"STS Cache MISS (service): {key}")
                return None
            except Exception as e:
                logger.warning(f"CacheService get failed for STS token, falling back to local: {e}")

        token = self.cache.get(key)
        if token:
            logger.debug(f"STS Cache HIT: {key}")
        else:
            logger.debug(f"STS Cache MISS: {key}")
        return token

    def set_sts_token(
        self, user_id: str, resource_indicator: str, token: str, expires_in: int = 28800
    ) -> None:
        """Cache an STS ISV access token.

        TTL is min(expires_in - 60, 28800) to ensure refresh before expiry.

        Args:
            user_id: User identifier
            resource_indicator: resourceIndicator ORN from the Managed Connection
            token: ISV access token to cache
            expires_in: Token lifetime in seconds (from exchange response)
        """
        key = self._make_sts_key(user_id, resource_indicator)
        ttl = min(max(expires_in - 60, 60), 28800)

        if self._cache_service:
            try:
                serialized = self._serialize(token)
                self._run_async(
                    self._cache_service.set(self._service_key(key), serialized, ttl_seconds=ttl)
                )
                logger.info(f"STS token cached (service): {key} (TTL: {ttl}s)")
                return
            except Exception as e:
                logger.warning(f"CacheService set failed for STS token, falling back to local: {e}")

        self.cache[key] = token
        logger.info(f"STS token cached: {key} (TTL: {ttl}s)")

    def invalidate_sts_token(self, user_id: str, resource_indicator: str) -> None:
        """Invalidate a cached STS token."""
        key = self._make_sts_key(user_id, resource_indicator)
        if self._cache_service:
            try:
                self._run_async(self._cache_service.delete(self._service_key(key)))
                logger.info(f"STS token invalidated (service): {key}")
                return
            except Exception as e:
                logger.warning(f"CacheService delete failed for STS token: {e}")

        if key in self.cache:
            del self.cache[key]
            logger.info(f"STS token invalidated: {key}")

    def clear(self) -> None:
        """Clear all cached tokens."""
        if self._cache_service:
            try:
                self._run_async(self._cache_service.clear_prefix(_TOKEN_PREFIX))
                logger.info("Token cache cleared (service)")
                return
            except Exception as e:
                logger.warning(f"CacheService clear failed, falling back to local: {e}")

        self.cache.clear()
        logger.info("Token cache cleared")
