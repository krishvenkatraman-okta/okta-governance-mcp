"""
Redis cache provider backed by redis.asyncio.

Supports connection pooling, key prefixing, and graceful failure handling.

The Redis client is created lazily on first async call to ensure it binds
to the correct event loop. When called from a different event loop (e.g.
CachedResourceStore._run_async spawning a thread with asyncio.run), a
separate per-loop client is created automatically to avoid "Future
attached to a different loop" errors.
"""

import asyncio
import datetime
import logging
from typing import TYPE_CHECKING, Optional

from .base import CacheProvider

if TYPE_CHECKING:
    from .redis_credentials import RedisCredentialProvider

logger = logging.getLogger(__name__)


class RedisCacheProvider(CacheProvider):
    """Redis-backed cache provider with connection pooling and graceful degradation."""

    def __init__(
        self,
        redis_url: str,
        key_prefix: str = "okta-mcp:",
        default_ttl: int = 3600,
        ssl: bool = False,
        credential_provider: Optional["RedisCredentialProvider"] = None,
    ):
        self._key_prefix = key_prefix
        self._default_ttl = default_ttl
        self._redis_url = redis_url
        self._ssl = ssl
        self._credential_provider = credential_provider
        # Map from event loop id → Redis client, so each loop gets its own
        self._clients: dict[int, object] = {}
        self._minted_loops: set[int] = set()
        self._refresh_tasks: dict[int, asyncio.Task] = {}
        self._init_failed = False
        logger.info(f"RedisCacheProvider configured: url={redis_url}, prefix={key_prefix}, ssl={ssl}, url_is_rediss={redis_url.startswith('rediss://')}")

    async def _get_redis(self):
        """Lazily create a Redis client bound to the current event loop.

        Each distinct event loop gets its own client instance, preventing
        "Future attached to a different loop" errors when sync-to-async
        bridges (like CachedResourceStore._run_async) run coroutines on
        a temporary loop in a worker thread.
        """
        if self._init_failed:
            return None

        loop = asyncio.get_running_loop()
        loop_id = id(loop)

        client = self._clients.get(loop_id)
        if client is not None:
            return client

        try:
            import redis.asyncio as aioredis

            kwargs = {
                "decode_responses": True,
                "max_connections": 20,
            }
            # For SSL: use rediss:// URL scheme (redis-py handles SSL internally).
            # Only add ssl_cert_reqs to skip Azure's self-signed cert verification.
            url = self._redis_url
            if self._ssl and not url.startswith("rediss://"):
                # Upgrade redis:// to rediss:// so redis-py uses SSLConnection
                url = url.replace("redis://", "rediss://", 1)
            if url.startswith("rediss://"):
                # Azure Cache for Redis: skip cert hostname verification
                kwargs["ssl_cert_reqs"] = "none"

            creds = None
            if self._credential_provider is not None:
                # Provider mode — strip any embedded credentials from the URL and
                # supply username/password as connection kwargs. This ensures the
                # provider is the single source of truth.
                creds = await self._credential_provider.get_credentials()
                if creds.username:
                    kwargs["username"] = creds.username
                if creds.password:
                    kwargs["password"] = creds.password
                if creds.ssl_context is not None:
                    kwargs["ssl"] = True
                    # redis-py honors ssl_certfile/ssl_keyfile/ssl_ca_certs;
                    # full mTLS wiring lands in Phase 3. For now, we only need
                    # to support static (no SSLContext) — record this is a no-op.
                url = self._strip_url_credentials(url)
                if loop_id not in self._minted_loops:
                    self._minted_loops.add(loop_id)
                    await self._emit_mint_audit(creds)

            client = aioredis.from_url(url, **kwargs)
            self._clients[loop_id] = client

            # Schedule a refresh task if credentials expire and we don't already
            # have one for this loop.
            if (
                self._credential_provider is not None
                and creds is not None
                and creds.is_expiring()
                and loop_id not in self._refresh_tasks
            ):
                self._refresh_tasks[loop_id] = asyncio.create_task(
                    self._scheduled_refresh(loop_id, creds, self._credential_provider),
                    name=f"redis-cred-refresh-loop-{loop_id}",
                )
            if len(self._clients) == 1:
                logger.info(f"RedisCacheProvider connected: url={self._redis_url}")
            else:
                logger.debug(
                    f"RedisCacheProvider created secondary client for loop {loop_id}"
                )
            return client
        except Exception as e:
            logger.warning(f"Failed to initialize Redis connection: {e}")
            self._init_failed = True
            return None

    @staticmethod
    def _strip_url_credentials(url: str) -> str:
        """Remove any embedded user:pass@ from a redis(s):// URL."""
        from urllib.parse import urlparse, urlunparse

        parsed = urlparse(url)
        if parsed.username or parsed.password:
            netloc = parsed.hostname or ""
            if parsed.port:
                netloc = f"{netloc}:{parsed.port}"
            parsed = parsed._replace(netloc=netloc)
            return urlunparse(parsed)
        return url

    async def _scheduled_refresh(self, loop_id, initial_creds, provider):
        """Sleep until refresh-safety-window before expiry, then close the
        cached client so the next _get_redis() rebuilds with fresh
        credentials.

        If the provider's get_credentials raises during refresh, audit
        the failure and let the existing client run until the cached
        token actually expires; the next get/set will fail with NOAUTH
        and trigger a normal reconnect attempt.
        """
        try:
            window = provider.refresh_safety_window()
            now = datetime.datetime.now(datetime.timezone.utc)
            refresh_at = initial_creds.expires_at - window
            sleep_seconds = max(1.0, (refresh_at - now).total_seconds())
            logger.debug(
                "[redis-creds] scheduled refresh for loop %s in %ss "
                "(expires_at=%s, window=%s)",
                loop_id, sleep_seconds,
                initial_creds.expires_at.isoformat(), window,
            )
            await asyncio.sleep(sleep_seconds)

            # Close the cached client so the next _get_redis() call rebuilds.
            # We do NOT pre-mint here — the provider will be called again
            # synchronously inside _get_redis() and the new client built
            # with fresh credentials.
            client = self._clients.pop(loop_id, None)
            self._minted_loops.discard(loop_id)
            self._refresh_tasks.pop(loop_id, None)
            if client is not None:
                try:
                    await client.aclose()
                except Exception as e:
                    logger.warning(
                        "[redis-creds] error closing client during refresh: %s", e
                    )

            # Peek the new credential's expiry/principal for the audit event so
            # SIEM consumers can compute time-to-expiry without joining events.
            new_expires_at = None
            new_principal = None
            try:
                peek = await provider.get_credentials()
                new_expires_at = peek.expires_at
                new_principal = peek.principal
            except Exception:
                # Don't fail the refresh on a peek failure — the next
                # _get_redis() will surface the real error if it persists.
                pass
            await self._emit_refresh_audit(
                provider,
                success=True,
                new_expires_at=new_expires_at,
                new_principal=new_principal,
            )
        except asyncio.CancelledError:
            raise
        except Exception as e:
            logger.error(
                "[redis-creds] scheduled refresh failed for loop %s: %s",
                loop_id, e,
            )
            await self._emit_refresh_audit(provider, success=False, error=str(e))
            self._refresh_tasks.pop(loop_id, None)

    async def _emit_refresh_audit(
        self,
        provider,
        success: bool,
        error: Optional[str] = None,
        new_expires_at: Optional[datetime.datetime] = None,
        new_principal: Optional[str] = None,
    ):
        try:
            from okta_agent_proxy.audit import emit_audit_event
            from okta_agent_proxy.audit.events import AuditEventType, AuditSeverity

            event_type = (
                AuditEventType.REDIS_CREDENTIAL_REFRESH_SUCCESS if success
                else AuditEventType.REDIS_CREDENTIAL_REFRESH_FAILED
            )
            severity = AuditSeverity.INFO if success else AuditSeverity.WARNING
            details = {"provider": provider.name}
            if error:
                details["error"] = error
            if new_expires_at is not None:
                # Normalize tz-naive to UTC so SIEM consumers get an absolute
                # timestamp and our delta math below is correct.
                if new_expires_at.tzinfo is None:
                    new_expires_at = new_expires_at.replace(
                        tzinfo=datetime.timezone.utc
                    )
                details["expires_at"] = new_expires_at.isoformat()
                now = datetime.datetime.now(datetime.timezone.utc)
                details["expires_in_seconds"] = (new_expires_at - now).total_seconds()
            if new_principal is not None:
                details["principal"] = new_principal
            await emit_audit_event(
                event_type, severity,
                resource_name="redis", details=details,
                outcome="success" if success else "failure",
            )
        except Exception as e:
            logger.warning(f"[redis-creds] refresh audit emission failed: {e}")

    async def _emit_mint_audit(self, creds):
        try:
            from okta_agent_proxy.audit import emit_audit_event
            from okta_agent_proxy.audit.events import AuditEventType, AuditSeverity

            details = {
                "provider": self._credential_provider.name,
                "principal": creds.principal,
                "expires_at": creds.expires_at.isoformat() if creds.expires_at else None,
                "username_set": creds.username is not None,
            }
            # Pre-computed seconds-until-expiry for SIEM alerting. Absent when
            # the provider issues non-expiring credentials (e.g. static).
            if creds.expires_at is not None:
                expires_at = creds.expires_at
                if expires_at.tzinfo is None:
                    expires_at = expires_at.replace(tzinfo=datetime.timezone.utc)
                now = datetime.datetime.now(datetime.timezone.utc)
                details["expires_in_seconds"] = (expires_at - now).total_seconds()

            await emit_audit_event(
                AuditEventType.REDIS_CREDENTIAL_MINTED,
                AuditSeverity.INFO,
                resource_name="redis",
                details=details,
                outcome="success",
            )
        except Exception as e:
            logger.warning(f"[redis-creds] mint audit emission failed: {e}")

    def _prefixed(self, key: str) -> str:
        return f"{self._key_prefix}{key}"

    async def get(self, key: str) -> Optional[str]:
        client = await self._get_redis()
        if client is None:
            return None
        try:
            return await client.get(self._prefixed(key))
        except Exception as e:
            logger.warning(f"Redis GET failed for {key}: {e}")
            return None

    async def set(self, key: str, value: str, ttl_seconds: Optional[int] = None) -> None:
        client = await self._get_redis()
        if client is None:
            return
        try:
            ttl = ttl_seconds if ttl_seconds is not None else self._default_ttl
            await client.set(self._prefixed(key), value, ex=int(ttl))
        except Exception as e:
            logger.warning(f"Redis SET failed for {key}: {e}")

    async def delete(self, key: str) -> None:
        client = await self._get_redis()
        if client is None:
            return
        try:
            await client.delete(self._prefixed(key))
        except Exception as e:
            logger.warning(f"Redis DELETE failed for {key}: {e}")

    async def exists(self, key: str) -> bool:
        client = await self._get_redis()
        if client is None:
            return False
        try:
            return bool(await client.exists(self._prefixed(key)))
        except Exception as e:
            logger.warning(f"Redis EXISTS failed for {key}: {e}")
            return False

    async def clear_prefix(self, prefix: str) -> int:
        client = await self._get_redis()
        if client is None:
            return 0
        try:
            pattern = f"{self._key_prefix}{prefix}*"
            count = 0
            async for key in client.scan_iter(match=pattern, count=100):
                await client.delete(key)
                count += 1
            return count
        except Exception as e:
            logger.warning(f"Redis CLEAR_PREFIX failed for {prefix}: {e}")
            return 0

    async def health_check(self) -> bool:
        client = await self._get_redis()
        if client is None:
            return False
        try:
            return await client.ping()
        except Exception:
            return False

    def close(self) -> None:
        """Cancel pending refresh tasks and close all cached clients.

        Sync for CacheProvider.close() compatibility. Client aclose is
        scheduled on the running loop where possible; otherwise best-effort.
        """
        for task in list(self._refresh_tasks.values()):
            if not task.done():
                task.cancel()
        self._refresh_tasks.clear()
        for client in list(self._clients.values()):
            try:
                loop = asyncio.get_event_loop()
                if loop.is_running():
                    loop.create_task(client.aclose())
                else:
                    loop.run_until_complete(client.aclose())
            except Exception:
                pass
        self._clients.clear()
        self._minted_loops.clear()
