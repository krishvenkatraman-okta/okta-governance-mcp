"""
In-memory cache provider backed by cachetools.TTLCache.

Default/fallback provider for single-node deployments.
"""

import logging
import time
from typing import Optional

from cachetools import TTLCache

from .base import CacheProvider

logger = logging.getLogger(__name__)


class MemoryCacheProvider(CacheProvider):
    """In-memory cache with TTL expiration using cachetools."""

    def __init__(self, max_size: int = 10000, default_ttl: int = 3600):
        self._max_size = max_size
        self._default_ttl = default_ttl
        self._cache: TTLCache = TTLCache(maxsize=max_size, ttl=default_ttl)
        # Track per-key expiry for custom TTLs
        self._expiry: dict[str, float] = {}
        logger.info(f"MemoryCacheProvider initialized: max_size={max_size}, ttl={default_ttl}s")

    async def get(self, key: str) -> Optional[str]:
        # Check custom expiry first
        if key in self._expiry and time.monotonic() > self._expiry[key]:
            self._cache.pop(key, None)
            del self._expiry[key]
            return None
        value = self._cache.get(key)
        return value

    async def set(self, key: str, value: str, ttl_seconds: Optional[int] = None) -> None:
        self._cache[key] = value
        if ttl_seconds is not None and ttl_seconds != self._default_ttl:
            self._expiry[key] = time.monotonic() + ttl_seconds
        elif key in self._expiry:
            del self._expiry[key]

    async def delete(self, key: str) -> None:
        self._cache.pop(key, None)
        self._expiry.pop(key, None)

    async def exists(self, key: str) -> bool:
        if key in self._expiry and time.monotonic() > self._expiry[key]:
            self._cache.pop(key, None)
            del self._expiry[key]
            return False
        return key in self._cache

    async def clear_prefix(self, prefix: str) -> int:
        keys = [k for k in list(self._cache.keys()) if k.startswith(prefix)]
        for k in keys:
            self._cache.pop(k, None)
            self._expiry.pop(k, None)
        return len(keys)

    async def health_check(self) -> bool:
        return True

    def close(self) -> None:
        self._cache.clear()
        self._expiry.clear()
