"""
Cache event bus for cross-container invalidation via Redis pub/sub.

When Redis is the L2 backend, admin write operations publish invalidation
events so that other gateway containers can refresh their in-memory state.
For non-Redis deployments this is a no-op (single container doesn't need sync).

Pub/sub message envelope
------------------------
All user-scoped invalidation channels use a standard JSON envelope::

    {"v": 1, "key": "<identifier>", "user_sub": "<optional>"}

- ``v``: Envelope version (always 1 for now).
- ``key``: Primary identifier — depends on channel:
    - ``user_token_invalidate``: SHA-256 hash of the access_token.
    - ``relay_session_invalidate``: The relay_state string.
    - ``consent_tx_invalidate``: The transaction_id (UUID4).
    - ``user_logout``: The user_sub (Okta ``sub`` claim).
- ``user_sub``: Optional metadata; present when the publisher knows it.

Config-scoped channels (route/agent/tool_catalog/dcr_patterns) continue
to use free-form string messages as before.
"""

import asyncio
import json
import logging
from typing import Callable, Dict, Optional

logger = logging.getLogger(__name__)

# Predefined channels — config-scoped
CHANNEL_ROUTE_INVALIDATE = "route_invalidate"
CHANNEL_AGENT_INVALIDATE = "agent_invalidate"
CHANNEL_TOOL_CATALOG_INVALIDATE = "tool_catalog_invalidate"
CHANNEL_DCR_PATTERNS_INVALIDATE = "dcr_patterns_invalidate"

# Predefined channels — user-scoped (added in P5)
CHANNEL_USER_TOKEN_INVALIDATE = "user_token_invalidate"
CHANNEL_RELAY_SESSION_INVALIDATE = "relay_session_invalidate"
CHANNEL_CONSENT_TX_INVALIDATE = "consent_tx_invalidate"
CHANNEL_USER_LOGOUT = "user_logout"

ALL_CHANNELS = [
    CHANNEL_ROUTE_INVALIDATE,
    CHANNEL_AGENT_INVALIDATE,
    CHANNEL_TOOL_CATALOG_INVALIDATE,
    CHANNEL_DCR_PATTERNS_INVALIDATE,
    CHANNEL_USER_TOKEN_INVALIDATE,
    CHANNEL_RELAY_SESSION_INVALIDATE,
    CHANNEL_CONSENT_TX_INVALIDATE,
    CHANNEL_USER_LOGOUT,
]


class CacheEventBus:
    """
    Pub/sub event bus backed by Redis when available.

    If the CacheService L2 provider is not Redis, all operations are silent no-ops.
    """

    def __init__(self, cache_service):
        self._cache_service = cache_service
        self._redis = None
        self._redis_checked = False
        self._callbacks: Dict[str, list] = {}
        self._listener_task: Optional[asyncio.Task] = None
        self._pubsub = None
        self._has_redis_l2 = self._check_redis_l2()

        if self._has_redis_l2:
            logger.info("CacheEventBus initialized with Redis pub/sub (lazy connect)")
        else:
            logger.info("CacheEventBus initialized (no-op mode, no Redis)")

    def _check_redis_l2(self) -> bool:
        """Check if the L2 cache provider is Redis-backed."""
        from okta_agent_proxy.cache.redis_provider import RedisCacheProvider
        return isinstance(self._cache_service.l2, RedisCacheProvider)

    async def _ensure_redis(self):
        """Lazily obtain a Redis client on the running event loop."""
        if self._redis is not None:
            return self._redis
        if self._redis_checked or not self._has_redis_l2:
            return None

        self._redis_checked = True
        from okta_agent_proxy.cache.redis_provider import RedisCacheProvider
        l2 = self._cache_service.l2
        if isinstance(l2, RedisCacheProvider):
            # Use the provider's lazy init to get a loop-bound client
            client = await l2._get_redis()
            if client is not None:
                self._redis = client
                logger.info("CacheEventBus connected to Redis")
        return self._redis

    @property
    def is_active(self) -> bool:
        """True if backed by Redis and able to publish/subscribe."""
        return self._has_redis_l2 or self._redis is not None

    async def publish(self, channel: str, message: str) -> None:
        """Publish a message to a channel. No-op without Redis."""
        redis = await self._ensure_redis()
        # Fall back to directly injected _redis (e.g. tests)
        if not redis:
            redis = self._redis
        if not redis:
            return
        try:
            await redis.publish(channel, message)
            logger.debug(f"Published to {channel}: {message}")
        except Exception as e:
            logger.warning(f"Failed to publish to {channel}: {e}")

    async def subscribe(self, channel: str, callback: Callable) -> None:
        """Register a callback for a channel. No-op without Redis."""
        if channel not in self._callbacks:
            self._callbacks[channel] = []
        self._callbacks[channel].append(callback)
        logger.debug(f"Registered callback for channel {channel}")

    async def start_listener(self) -> None:
        """Start background task that listens on all subscribed channels."""
        redis = await self._ensure_redis() or self._redis
        if not redis or not self._callbacks:
            return

        try:
            self._pubsub = redis.pubsub()
            await self._pubsub.subscribe(*self._callbacks.keys())
            self._listener_task = asyncio.create_task(self._listen_loop())
            logger.info(f"Pub/sub listener started on channels: {list(self._callbacks.keys())}")
        except Exception as e:
            logger.warning(f"Failed to start pub/sub listener: {e}")

    async def stop_listener(self) -> None:
        """Cancel the background listener task."""
        if self._listener_task and not self._listener_task.done():
            self._listener_task.cancel()
            try:
                await self._listener_task
            except asyncio.CancelledError:
                pass
            self._listener_task = None

        if self._pubsub:
            try:
                await self._pubsub.unsubscribe()
                await self._pubsub.aclose()
            except Exception:
                pass
            self._pubsub = None

        logger.info("Pub/sub listener stopped")

    async def _listen_loop(self) -> None:
        """Internal loop that reads messages and dispatches to callbacks."""
        try:
            async for raw_message in self._pubsub.listen():
                if raw_message["type"] != "message":
                    continue

                channel = raw_message["channel"]
                # redis.asyncio may return bytes or str depending on decode_responses
                if isinstance(channel, bytes):
                    channel = channel.decode("utf-8")
                data = raw_message["data"]
                if isinstance(data, bytes):
                    data = data.decode("utf-8")

                callbacks = self._callbacks.get(channel, [])
                for cb in callbacks:
                    try:
                        result = cb(data)
                        if asyncio.iscoroutine(result):
                            await result
                    except Exception as e:
                        logger.warning(f"Callback error on {channel}: {e}")
        except asyncio.CancelledError:
            raise
        except Exception as e:
            logger.warning(f"Pub/sub listener error: {e}")
