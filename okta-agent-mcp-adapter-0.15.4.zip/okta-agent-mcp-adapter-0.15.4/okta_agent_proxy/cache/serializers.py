"""
Serialization helpers for cache values.

Supports JSON serialization with datetime handling and optional AES-256-GCM encryption.
"""

import base64
import json
from datetime import datetime, date
from typing import Any, Type, TypeVar

T = TypeVar("T")


class _DateTimeEncoder(json.JSONEncoder):
    def default(self, obj: Any) -> Any:
        if isinstance(obj, datetime):
            return obj.isoformat()
        if isinstance(obj, date):
            return obj.isoformat()
        return super().default(obj)


def serialize_json(value: Any) -> str:
    """JSON serialize with datetime handling."""
    return json.dumps(value, cls=_DateTimeEncoder)


def deserialize_json(value: str, expected_type: Type[T] = dict) -> T:
    """JSON deserialize. Returns parsed value cast to expected_type."""
    return json.loads(value)


def serialize_encrypted(value: Any, encryption_service: Any) -> str:
    """JSON serialize then AES-256-GCM encrypt, return base64 string."""
    plaintext = serialize_json(value)
    ciphertext, iv, tag = encryption_service.encrypt(plaintext)
    # Pack as iv + tag + ciphertext and base64 encode
    packed = iv + tag + ciphertext
    return base64.b64encode(packed).decode("ascii")


def deserialize_encrypted(value: str, encryption_service: Any) -> Any:
    """Reverse of serialize_encrypted: base64 decode, decrypt, JSON parse."""
    packed = base64.b64decode(value)
    iv = packed[:12]
    tag = packed[12:28]
    ciphertext = packed[28:]
    plaintext = encryption_service.decrypt(ciphertext, iv, tag)
    return json.loads(plaintext)
