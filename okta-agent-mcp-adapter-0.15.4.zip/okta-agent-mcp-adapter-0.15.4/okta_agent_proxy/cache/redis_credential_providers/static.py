"""Static-password Redis credential provider — DEV ONLY.

Preserves the current REDIS_PASSWORD behaviour for local development with
Docker Compose. Refuses to start unless ALLOW_STATIC_REDIS_PASSWORD=true is
explicitly set.

This module is gated because static, long-lived Redis passwords fail
customer security review. The gate itself is the deliverable evidence:
production deployments will not have ALLOW_STATIC_REDIS_PASSWORD set,
and any startup that reaches this code path will emit a
CRITICAL-severity REDIS_STATIC_PASSWORD_USED audit event.
"""

import logging
import os
from typing import Optional

from okta_agent_proxy.cache.redis_credentials import (
    CredentialUnavailableError,
    RedisCredentialProvider,
    RedisCredentials,
)

logger = logging.getLogger(__name__)

GATE_ENV = "ALLOW_STATIC_REDIS_PASSWORD"
PASSWORD_ENV = "REDIS_PASSWORD"
USERNAME_ENV = "REDIS_USERNAME"


class StaticPasswordProvider(RedisCredentialProvider):
    name = "static"

    def __init__(self, username: Optional[str], password: Optional[str]):
        self._username = username
        self._password = password
        self._audit_emitted = False

    @classmethod
    def from_env(cls) -> "StaticPasswordProvider":
        """Construct from environment, enforcing the gate.

        Raises:
            CredentialUnavailableError: if ALLOW_STATIC_REDIS_PASSWORD is not
                exactly the string 'true' (case-insensitive). The error message
                names the supported alternative providers.
        """
        gate = os.environ.get(cls._gate_env_name(), "").strip().lower()
        if gate != "true":
            raise CredentialUnavailableError(
                f"REDIS_AUTH_MODE=static requires {cls._gate_env_name()}=true. "
                f"Static Redis passwords are not permitted in production. "
                f"Set REDIS_AUTH_MODE=aws-iam, azure-entra, mtls, or vault for "
                f"production deployments."
            )
        username = os.environ.get(USERNAME_ENV) or None
        password = os.environ.get(PASSWORD_ENV) or None
        if not password:
            logger.warning(
                "[redis-creds:static] %s is empty — connecting without AUTH. "
                "This is acceptable only for local dev Redis with no requirepass.",
                PASSWORD_ENV,
            )
        return cls(username=username, password=password)

    @staticmethod
    def _gate_env_name() -> str:
        return GATE_ENV

    async def get_credentials(self) -> RedisCredentials:
        if not self._audit_emitted:
            self._audit_emitted = True
            self._log_loud_warning()
            await self._emit_static_used_audit()
        return RedisCredentials(
            username=self._username,
            password=self._password,
            expires_at=None,
            ssl_context=None,
            principal="static",
        )

    def _log_loud_warning(self):
        bar = "=" * 72
        logger.warning(bar)
        logger.warning("REDIS AUTH: USING STATIC PASSWORD MODE — NOT FOR PRODUCTION")
        logger.warning("Set REDIS_AUTH_MODE=aws-iam | azure-entra | mtls | vault")
        logger.warning("for production.")
        logger.warning(bar)

    async def _emit_static_used_audit(self):
        try:
            from okta_agent_proxy.audit import emit_audit_event
            from okta_agent_proxy.audit.events import AuditEventType, AuditSeverity

            await emit_audit_event(
                AuditEventType.REDIS_STATIC_PASSWORD_USED,
                AuditSeverity.CRITICAL,
                resource_name="redis",
                details={
                    "provider": self.name,
                    "username_set": self._username is not None,
                    "password_set": self._password is not None,
                },
                outcome="warning",
            )
        except Exception as e:
            logger.warning(
                "[redis-creds:static] could not emit REDIS_STATIC_PASSWORD_USED audit event: %s",
                e,
            )
