"""AWS ElastiCache IAM credential provider.

Mints a SigV4-signed pre-signed URL whose query string acts as the Redis
AUTH password. Tokens are valid for 15 minutes (AWS-imposed maximum for
elasticache:Connect). The Redis username is the IAM-enabled ElastiCache
user ID — NOT the IAM role/principal name.

Mint cost is purely local (no network round-trip; SigV4 signing happens
in-process), so we re-mint on every reconnect rather than caching the
token. The 2.5-minute refresh safety window provides headroom for clock
skew and slow client reconnects.

Required IAM permissions on the ECS task role / EC2 instance role / EKS
service account:

    {
      "Effect": "Allow",
      "Action": "elasticache:Connect",
      "Resource": [
        "arn:aws:elasticache:<region>:<account>:serverlesscache:<cache-name>",
        "arn:aws:elasticache:<region>:<account>:user:<user-id>"
      ]
    }

For a self-designed (non-serverless) cluster, the resource ARN is
`arn:aws:elasticache:<region>:<account>:replicationgroup:<group-id>`.
"""

import datetime
import logging
import os
from typing import Optional
from urllib.parse import urlencode, urlparse

from botocore.auth import SigV4QueryAuth
from botocore.awsrequest import AWSRequest
from botocore.session import Session

from okta_agent_proxy.cache.redis_credentials import (
    CredentialUnavailableError,
    RedisCredentialProvider,
    RedisCredentials,
)

logger = logging.getLogger(__name__)

USER_ID_ENV = "REDIS_AWS_USER_ID"
CACHE_NAME_ENV = "REDIS_AWS_CACHE_NAME"
REGION_ENV = "AWS_REGION"
SERVERLESS_ENV = "REDIS_AWS_SERVERLESS"

TOKEN_LIFETIME_SECONDS = 900  # 15 minutes (AWS max for elasticache:Connect)
ACTION = "connect"
SERVICE = "elasticache"


class AwsIamElastiCacheProvider(RedisCredentialProvider):
    name = "aws-iam"

    def __init__(
        self,
        user_id: str,
        cache_name: str,
        region: str,
        is_serverless: bool = True,
        session: Optional[Session] = None,
    ):
        if not user_id:
            raise ValueError("user_id is required for aws-iam provider")
        if not cache_name:
            raise ValueError("cache_name is required for aws-iam provider")
        if not region:
            raise ValueError("region is required for aws-iam provider")
        self._user_id = user_id
        self._cache_name = cache_name
        self._region = region
        self._is_serverless = is_serverless
        self._session = session or Session()

    @classmethod
    def from_env(cls) -> "AwsIamElastiCacheProvider":
        """Construct from environment.

        Required: REDIS_AWS_USER_ID, REDIS_AWS_CACHE_NAME, AWS_REGION.
        Optional: REDIS_AWS_SERVERLESS (default 'true').
        """
        user_id = os.environ.get(USER_ID_ENV, "").strip()
        cache_name = os.environ.get(CACHE_NAME_ENV, "").strip()
        region = os.environ.get(REGION_ENV, "").strip()
        if not user_id or not cache_name or not region:
            raise CredentialUnavailableError(
                f"REDIS_AUTH_MODE=aws-iam requires {USER_ID_ENV}, "
                f"{CACHE_NAME_ENV}, and {REGION_ENV} to be set."
            )
        is_serverless = (
            os.environ.get(SERVERLESS_ENV, "true").strip().lower() == "true"
        )
        return cls(
            user_id=user_id,
            cache_name=cache_name,
            region=region,
            is_serverless=is_serverless,
        )

    async def get_credentials(self) -> RedisCredentials:
        """Mint a fresh SigV4 pre-signed URL token.

        This is a synchronous boto3 call wrapped in async. Mint cost is
        local — there is no network round-trip — so the call returns
        in microseconds. We do not run it in a thread executor.
        """
        try:
            creds = self._session.get_credentials()
            if creds is None:
                raise CredentialUnavailableError(
                    "AWS credential chain returned no credentials. "
                    "Ensure the ECS task role, EC2 instance role, EKS service "
                    "account, or AWS_ACCESS_KEY_ID/AWS_SECRET_ACCESS_KEY env "
                    "vars are configured."
                )
            frozen = creds.get_frozen_credentials()

            # Build the canonical pre-sign URL. The format AWS expects for
            # ElastiCache IAM auth:
            #   <cache-name>/?Action=connect&User=<user-id>
            # We sign this as a GET, then strip the scheme+host from the
            # signed URL — the remainder (path + signed query string) is
            # the AUTH token.
            query = {"Action": ACTION, "User": self._user_id}
            url = f"http://{self._cache_name}/?{urlencode(query)}"
            request = AWSRequest(method="GET", url=url)
            # ElastiCache caps X-Amz-Expires at 900s and rejects longer-lived
            # tokens as "invalid username-password pair or user is disabled".
            # botocore's SigV4QueryAuth defaults to 3600s, so we MUST pass
            # expires= explicitly here.
            signer = SigV4QueryAuth(
                frozen, SERVICE, self._region, expires=TOKEN_LIFETIME_SECONDS
            )
            signer.add_auth(request)
            signed_url = request.url

            # Token = signed_url with scheme:// stripped. Redis AUTH sees
            # "<cache-name>/?..." — the cache name path + signed query.
            parsed = urlparse(signed_url)
            token = f"{parsed.netloc}{parsed.path}?{parsed.query}"

            # frozen.access_key is the IAM access key id (usable for audit),
            # NOT a secret — secret_key and token are not logged.
            principal = f"arn:aws:iam::*:role/{frozen.access_key}"

            return RedisCredentials(
                username=self._user_id,
                password=token,
                expires_at=datetime.datetime.now(datetime.timezone.utc)
                + datetime.timedelta(seconds=TOKEN_LIFETIME_SECONDS),
                ssl_context=None,
                principal=principal,
            )
        except CredentialUnavailableError:
            raise
        except Exception as e:
            raise CredentialUnavailableError(
                f"Failed to mint AWS IAM token for ElastiCache: {e}"
            ) from e

    def refresh_safety_window(self) -> datetime.timedelta:
        # 2.5 minutes — about 17% of the 15-min lifetime. Provides headroom
        # for clock skew and slow client reconnects.
        return datetime.timedelta(minutes=2, seconds=30)
