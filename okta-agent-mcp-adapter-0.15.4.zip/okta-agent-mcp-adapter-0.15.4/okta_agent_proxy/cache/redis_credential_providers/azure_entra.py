"""Azure Entra ID credential provider for Azure Managed Redis and
Azure Cache for Redis Standard/Premium tiers with Entra enabled.

Acquires an access token from Entra ID via the Azure Identity SDK
(DefaultAzureCredential or a more constrained ManagedIdentityCredential).
The token is presented as the Redis AUTH password; the username is the
Object ID (oid claim) of the calling identity.

Token lifetime is whatever Entra issues — typically ~1 hour for managed
identities, sometimes shorter under Conditional Access policies. The
5-minute refresh safety window matches Microsoft's published guidance
for Azure Managed Redis (refresh at least 3 minutes before expiry; we
use 5 for clock skew margin).

Note: Azure Cache for Redis BASIC tier does NOT support Entra ID. This
provider only works against Standard/Premium tiers with Entra explicitly
enabled, OR against Azure Managed Redis (where Entra is the default).
"""

import datetime
import logging
import os
from typing import Optional

import jwt  # PyJWT
from azure.core.exceptions import ClientAuthenticationError
from azure.identity.aio import DefaultAzureCredential, ManagedIdentityCredential

from okta_agent_proxy.cache.redis_credentials import (
    CredentialUnavailableError,
    RedisCredentialProvider,
    RedisCredentials,
)

logger = logging.getLogger(__name__)

USE_MSI_ENV = "REDIS_AZURE_USE_MSI"
PRINCIPAL_OID_ENV = "REDIS_AZURE_PRINCIPAL_OID"
CLIENT_ID_ENV = "REDIS_AZURE_CLIENT_ID"

REDIS_SCOPE = "https://redis.azure.com/.default"
REFRESH_WINDOW_MINUTES = 5


class EntraManagedIdentityProvider(RedisCredentialProvider):
    name = "azure-entra"

    def __init__(
        self,
        use_msi: bool = True,
        client_id: Optional[str] = None,
        principal_oid: Optional[str] = None,
    ):
        if use_msi:
            # ManagedIdentityCredential is more constrained than
            # DefaultAzureCredential — fails fast in container apps if
            # IMDS isn't reachable, rather than falling through to
            # developer creds and silently using the wrong identity.
            kwargs = {}
            if client_id:
                kwargs["client_id"] = client_id
            self._cred = ManagedIdentityCredential(**kwargs)
        else:
            self._cred = DefaultAzureCredential()
        self._principal_oid = principal_oid

    @classmethod
    def from_env(cls) -> "EntraManagedIdentityProvider":
        use_msi_str = os.environ.get(USE_MSI_ENV, "true").strip().lower()
        use_msi = use_msi_str == "true"
        client_id = os.environ.get(CLIENT_ID_ENV, "").strip() or None
        principal_oid = os.environ.get(PRINCIPAL_OID_ENV, "").strip() or None
        return cls(
            use_msi=use_msi,
            client_id=client_id,
            principal_oid=principal_oid,
        )

    async def get_credentials(self) -> RedisCredentials:
        try:
            token = await self._cred.get_token(REDIS_SCOPE)
        except ClientAuthenticationError as e:
            raise CredentialUnavailableError(
                f"Entra credential acquisition failed: {e}"
            ) from e
        except Exception as e:
            raise CredentialUnavailableError(
                f"Unexpected error acquiring Entra token: {e}"
            ) from e

        # Extract Object ID from the access token if not already cached.
        # The `oid` claim is stable for the lifetime of the identity.
        if self._principal_oid is None:
            try:
                # Decode without signature verification — Azure Managed Redis
                # is the verifying party for this token, not the adapter.
                claims = jwt.decode(
                    token.token,
                    options={"verify_signature": False, "verify_aud": False},
                )
                self._principal_oid = (
                    claims.get("oid") or claims.get("appid") or claims.get("sub")
                )
                if not self._principal_oid:
                    raise CredentialUnavailableError(
                        "Entra access token has no oid/appid/sub claim — "
                        "cannot use as Redis AUTH username"
                    )
            except jwt.PyJWTError as e:
                raise CredentialUnavailableError(
                    f"Could not decode Entra access token: {e}"
                ) from e

        expires_at = datetime.datetime.fromtimestamp(
            token.expires_on, tz=datetime.timezone.utc
        )

        return RedisCredentials(
            username=self._principal_oid,
            password=token.token,
            expires_at=expires_at,
            ssl_context=None,
            principal=self._principal_oid,
        )

    def refresh_safety_window(self) -> datetime.timedelta:
        return datetime.timedelta(minutes=REFRESH_WINDOW_MINUTES)

    async def health_check(self) -> bool:
        try:
            await self.get_credentials()
            return True
        except Exception:
            return False
