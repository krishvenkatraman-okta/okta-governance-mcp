"""Redis credential provider implementations.

Each provider produces fresh connection credentials on demand and declares
when those credentials will expire. The cache code never sees a string
password directly — it asks the provider via get_credentials().

See docs/redis-credentials.md for the full design rationale and
customer-review crib sheet.
"""
