"""
Abstract base class for cache providers.

Defines the interface that all cache providers (memory, Redis, etc.) must implement.
"""

from abc import ABC, abstractmethod
from typing import Optional

from pydantic import BaseModel


class CacheProviderConfig(BaseModel):
    """Configuration for cache provider selection and defaults."""

    provider: str = "memory"
    key_prefix: str = "okta-mcp:"
    default_ttl: int = 3600


class CacheProvider(ABC):
    """Abstract base class for pluggable cache providers."""

    @abstractmethod
    async def get(self, key: str) -> Optional[str]:
        """Get a value by key. Returns None if not found or expired."""
        ...

    @abstractmethod
    async def set(self, key: str, value: str, ttl_seconds: Optional[int] = None) -> None:
        """Set a key-value pair with optional TTL."""
        ...

    @abstractmethod
    async def delete(self, key: str) -> None:
        """Delete a key."""
        ...

    @abstractmethod
    async def exists(self, key: str) -> bool:
        """Check if a key exists and is not expired."""
        ...

    @abstractmethod
    async def clear_prefix(self, prefix: str) -> int:
        """Delete all keys matching the given prefix. Returns count of deleted keys."""
        ...

    @abstractmethod
    async def health_check(self) -> bool:
        """Check if the cache provider is healthy and reachable."""
        ...

    def close(self) -> None:
        """Clean up resources. Override if the provider needs cleanup."""
        pass
