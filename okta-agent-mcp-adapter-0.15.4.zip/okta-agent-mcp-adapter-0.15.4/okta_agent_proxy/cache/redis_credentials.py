"""Abstract Redis credential provider contract.

The provider seam decouples the Redis connection layer from any specific
credential source. Implementations live in cache/redis_credential_providers/
and are selected at startup by the REDIS_AUTH_MODE environment variable.

Phase 1 of the implementation only includes the abstract base, the
RedisCredentials named tuple, the factory entry point, and the
StaticPasswordProvider (gated). Cloud and dynamic providers ship in
subsequent phases.
"""

import datetime
import ssl
from abc import ABC, abstractmethod
from typing import NamedTuple, Optional


class RedisCredentials(NamedTuple):
    username: Optional[str]
    password: Optional[str]
    expires_at: Optional[datetime.datetime]
    ssl_context: Optional[ssl.SSLContext]
    principal: str

    def is_expiring(self) -> bool:
        """True when the credential has a known expiration."""
        return self.expires_at is not None


class CredentialUnavailableError(RuntimeError):
    """Raised when the provider cannot mint a credential (e.g. AWS creds chain empty,
    Entra IMDS unreachable, static gate not enabled). Adapter startup must fail."""


class RedisCredentialProvider(ABC):
    """Abstract base. Implementations live in redis_credential_providers/."""

    name: str = "abstract"

    @abstractmethod
    async def get_credentials(self) -> RedisCredentials:
        """Mint or fetch fresh credentials. Called on every Redis client
        construction — initial connect, reconnect after error, and the
        scheduled refresh ahead of expiry.

        Raises:
            CredentialUnavailableError: if the provider cannot produce a credential.
        """
        ...

    def refresh_safety_window(self) -> datetime.timedelta:
        """How far before expiry to refresh. Default is 60 seconds; subclasses
        with provider-specific guidance (AWS IAM = 2.5 min, Entra = 5 min)
        override this."""
        return datetime.timedelta(seconds=60)

    async def health_check(self) -> bool:
        """Returns True when the provider can mint credentials. Default
        implementation calls get_credentials() and treats success as healthy."""
        try:
            await self.get_credentials()
            return True
        except Exception:
            return False


def get_redis_credential_provider() -> RedisCredentialProvider:
    """Factory. Reads REDIS_AUTH_MODE from os.environ, instantiates the matching
    provider, and returns it.

    Phase 2 supports 'static', 'aws-iam', and 'azure-entra'. Phase 3 will add
    'mtls' and 'vault'. Unknown modes raise ValueError listing the supported
    modes.

    Defaults to 'static' for backward compatibility, but the static provider itself
    refuses to start unless ALLOW_STATIC_REDIS_PASSWORD=true (see P02).

    The per-branch import pattern keeps boto3 / azure-identity out of process
    memory when those providers are not selected.
    """
    import os

    mode = os.environ.get("REDIS_AUTH_MODE", "static").lower().strip()

    if mode == "static":
        from okta_agent_proxy.cache.redis_credential_providers.static import (
            StaticPasswordProvider,
        )

        return StaticPasswordProvider.from_env()

    if mode == "aws-iam":
        from okta_agent_proxy.cache.redis_credential_providers.aws_iam import (
            AwsIamElastiCacheProvider,
        )

        return AwsIamElastiCacheProvider.from_env()

    if mode == "azure-entra":
        from okta_agent_proxy.cache.redis_credential_providers.azure_entra import (
            EntraManagedIdentityProvider,
        )

        return EntraManagedIdentityProvider.from_env()

    raise ValueError(
        f"Unsupported REDIS_AUTH_MODE: {mode!r}. "
        f"Supported: static, aws-iam, azure-entra. "
        f"Phase 3 will add: mtls, vault."
    )
