"""
Two-tier cache service (L1 in-memory + L2 configurable resource provider).

L1 is always a small, fast MemoryCacheProvider with short TTL.
L2 is the configured provider (Redis for multi-node, or memory for single-node).
"""

import logging
import os
from typing import Optional

from .base import CacheProvider, CacheProviderConfig
from .memory_provider import MemoryCacheProvider

logger = logging.getLogger(__name__)

L1_MAX_SIZE = 1000
L1_TTL = 30


class CacheService:
    """Two-tier caching: L1 (fast local) + L2 (shared provider)."""

    def __init__(self, l2_provider: CacheProvider):
        self._l1 = MemoryCacheProvider(max_size=L1_MAX_SIZE, default_ttl=L1_TTL)
        self._l2 = l2_provider
        logger.info(f"CacheService initialized: L1=memory(ttl={L1_TTL}s), L2={type(l2_provider).__name__}")

    @property
    def l1(self) -> MemoryCacheProvider:
        return self._l1

    @property
    def l2(self) -> CacheProvider:
        return self._l2

    async def get(self, key: str) -> Optional[str]:
        # Check L1
        value = await self._l1.get(key)
        if value is not None:
            return value
        # Check L2
        value = await self._l2.get(key)
        if value is not None:
            # Promote to L1
            await self._l1.set(key, value)
        return value

    async def set(self, key: str, value: str, ttl_seconds: Optional[int] = None) -> None:
        await self._l1.set(key, value)
        await self._l2.set(key, value, ttl_seconds=ttl_seconds)

    async def delete(self, key: str) -> None:
        await self._l1.delete(key)
        await self._l2.delete(key)

    async def exists(self, key: str) -> bool:
        if await self._l1.exists(key):
            return True
        return await self._l2.exists(key)

    async def clear_prefix(self, prefix: str) -> int:
        c1 = await self._l1.clear_prefix(prefix)
        c2 = await self._l2.clear_prefix(prefix)
        return max(c1, c2)

    async def health_check(self) -> bool:
        l2_ok = await self._l2.health_check()
        return l2_ok

    @property
    def is_redis_backed(self) -> bool:
        """True when the L2 provider is Redis (shared state across pods)."""
        from okta_agent_proxy.cache.redis_provider import RedisCacheProvider
        return isinstance(self._l2, RedisCacheProvider)

    def close(self) -> None:
        self._l1.close()
        self._l2.close()

    @classmethod
    def create(cls, config: CacheProviderConfig, credential_provider=None) -> "CacheService":
        if config.provider == "redis":
            from .redis_provider import RedisCacheProvider

            redis_url = os.getenv("REDIS_URL", "redis://localhost:6379")
            l2 = RedisCacheProvider(
                redis_url=redis_url,
                key_prefix=config.key_prefix,
                default_ttl=config.default_ttl,
                ssl=os.getenv("REDIS_TLS_ENABLED", "false").lower() == "true",
                credential_provider=credential_provider,
            )
        else:
            l2 = MemoryCacheProvider(max_size=10000, default_ttl=config.default_ttl)
        return cls(l2_provider=l2)

    @classmethod
    def create_from_env(cls, credential_provider=None) -> "CacheService":
        provider = os.getenv("CACHE_PROVIDER", "memory").lower()
        redis_url = os.getenv("REDIS_URL")

        if provider == "redis" or redis_url:
            from .redis_credentials import get_redis_credential_provider
            from .redis_provider import RedisCacheProvider

            url = redis_url or "redis://localhost:6379"
            key_prefix = os.getenv("REDIS_KEY_PREFIX", "okta-mcp:")
            ssl = os.getenv("REDIS_TLS_ENABLED", "false").lower() == "true"

            # Note: from_env() may raise CredentialUnavailableError if the
            # gate is not set for static mode. We deliberately let that
            # propagate to fail-fast at startup rather than silently
            # falling back to memory.
            credential_provider = credential_provider or get_redis_credential_provider()

            l2 = RedisCacheProvider(
                redis_url=url,
                key_prefix=key_prefix,
                default_ttl=3600,
                ssl=ssl,
                credential_provider=credential_provider,
            )
        else:
            l2 = MemoryCacheProvider(max_size=10000, default_ttl=3600)

        return cls(l2_provider=l2)


def get_encryption_service_or_none():
    """Convenience helper: returns the env-derived EncryptionService, or None.

    Useful for callers that want to opt into encryption when available
    without crashing if ENCRYPTION_KEY is not set.  Does NOT cache — the
    underlying ``get_encryption_service()`` already manages its own
    singleton.
    """
    try:
        from okta_agent_proxy.crypto.encryption import get_encryption_service
        return get_encryption_service()
    except Exception:
        return None
