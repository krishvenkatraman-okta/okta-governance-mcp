"""
Admin API Middleware

Protects admin endpoints by validating Okta OAuth access tokens issued to the
Admin UI OIDC app. The legacy username/password JWT fallback was removed in
v0.15.x — only Okta-signed access tokens are accepted.
"""

import logging
from typing import Optional, Callable
from starlette.requests import Request
from starlette.responses import JSONResponse
from functools import wraps
from okta_agent_proxy.admin.auth import verify_okta_token
from okta_agent_proxy.audit.context import client_id_var, user_id_var

logger = logging.getLogger(__name__)


def extract_admin_token(request: Request) -> Optional[str]:
    """
    Extract admin token from Authorization header.
    
    Args:
        request: Starlette request
    
    Returns:
        Token string or None
    """
    auth_header = request.headers.get("authorization", "")
    
    if not auth_header.startswith("Bearer "):
        return None
    
    return auth_header[7:]  # Remove "Bearer " prefix


async def require_admin_token(request: Request) -> Optional[dict]:
    """
    Validate the Okta OAuth access token on the request.

    Args:
        request: Starlette request

    Returns:
        Token payload if valid, None otherwise
    """
    token = extract_admin_token(request)

    if not token:
        logger.warning(f"Missing admin token: {request.method} {request.url.path}")
        return None

    okta_payload = await verify_okta_token(token)
    if okta_payload:
        logger.debug(f"Okta OAuth token verified for user: {okta_payload.get('username')}")
        return okta_payload

    logger.warning(f"Okta token verification failed: {request.method} {request.url.path}")
    return None


def admin_required(func: Callable):
    """
    Decorator to require admin token for route handlers.
    
    Usage:
        @app.post("/api/admin/agents")
        @admin_required
        async def create_agent(request: Request):
            ...
    """
    @wraps(func)
    async def wrapper(request: Request, *args, **kwargs):
        payload = await require_admin_token(request)
        
        if not payload:
            logger.warning(f"Unauthorized admin request: {request.method} {request.url.path}")
            return JSONResponse(
                {
                    "error": "unauthorized",
                    "message": "Missing or invalid admin token"
                },
                status_code=401
            )
        
        # Enrich audit context with admin principal
        username = payload.get("username")
        user_id_var.set(username)
        if payload.get("principal_type") == "service_app":
            client_id_var.set(payload.get("cid"))

        # Log admin action
        logger.info(f"Admin action by {username}: {request.method} {request.url.path}")

        # Add payload to request for use in handler
        request.state.admin_payload = payload
        
        return await func(request, *args, **kwargs)
    
    return wrapper
