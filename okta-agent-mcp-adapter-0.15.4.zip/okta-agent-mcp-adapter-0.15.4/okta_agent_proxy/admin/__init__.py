"""
Admin API Module

Provides secure admin endpoints for managing agents and resources.
Authentication is Okta-OAuth-only (see admin.auth.verify_okta_token).
"""

from okta_agent_proxy.admin.auth import verify_okta_token, AdminAuthError
from okta_agent_proxy.admin.middleware import require_admin_token, admin_required, extract_admin_token
from okta_agent_proxy.admin import routes

__all__ = [
    "verify_okta_token",
    "AdminAuthError",
    "require_admin_token",
    "admin_required",
    "extract_admin_token",
    "routes",
]
