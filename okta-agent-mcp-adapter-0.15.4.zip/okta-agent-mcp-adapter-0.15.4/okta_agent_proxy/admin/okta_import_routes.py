"""
Admin API routes for Okta AI Agent import and sync.

All endpoints require an Okta OAuth token (not legacy JWT) with
AI Agent management scopes. The admin's Okta token is forwarded to
the Okta Management APIs so the gateway never needs its own admin API token.
"""

import json
import logging
import os
from dataclasses import asdict
from typing import Any, Dict, Optional

import httpx
from starlette.requests import Request
from starlette.responses import JSONResponse

from okta_agent_proxy.admin.middleware import admin_required, extract_admin_token
from okta_agent_proxy.audit import emit_audit_event, AuditEventType, AuditSeverity
from okta_agent_proxy.auth.okta_agent_import import OktaAgentImport
from okta_agent_proxy.auth.okta_ai_agent_client import OktaAIAgentClient
from okta_agent_proxy.auth.okta_service_auth import OktaServiceAuth
from okta_agent_proxy.auth.scope_filter import filter_as_scopes
from okta_agent_proxy.database import get_store

logger = logging.getLogger(__name__)

REQUIRED_SCOPES = {"okta.aiAgents.read", "okta.aiAgents.manage", "okta.apps.read"}

# ---------------------------------------------------------------------------
# Lazy singletons
# ---------------------------------------------------------------------------

_service_auth: Optional[OktaServiceAuth] = None
_client: Optional[OktaAIAgentClient] = None
_importer: Optional[OktaAgentImport] = None


def _get_service_auth() -> OktaServiceAuth:
    global _service_auth
    if _service_auth is None:
        _service_auth = OktaServiceAuth()
    return _service_auth


def _get_client() -> OktaAIAgentClient:
    global _client
    if _client is None:
        _client = OktaAIAgentClient(service_auth=_get_service_auth())
    return _client


def _get_importer() -> OktaAgentImport:
    global _importer
    if _importer is None:
        _importer = OktaAgentImport(client=_get_client(), store=get_store())
    return _importer


# ---------------------------------------------------------------------------
# Guards
# ---------------------------------------------------------------------------

def _check_okta_auth(request: Request) -> Optional[JSONResponse]:
    """Return 403 if the token is not an Okta OAuth token, else None."""
    payload = getattr(request.state, "admin_payload", {})
    if payload.get("token_type") != "okta_oauth":
        return JSONResponse(
            {
                "error": "okta_auth_required",
                "message": "This endpoint requires an Okta OAuth token (Admin UI login), not a legacy JWT",
            },
            status_code=403,
        )
    return None


async def _check_scopes(request: Request) -> Optional[JSONResponse]:
    """Pre-check that the token has AI Agent management scopes.

    Uses a lightweight scope probe via the AI Agent list endpoint.
    """
    okta_token = extract_admin_token(request)
    if not okta_token:
        return JSONResponse(
            {"error": "missing_token", "message": "No bearer token found"},
            status_code=401,
        )

    result = await _get_client().check_token_scopes(okta_token)
    if not result.get("has_ai_agent_scopes"):
        return JSONResponse(
            {
                "error": "insufficient_scopes",
                "message": result.get("error", "Token lacks required Okta API scopes"),
                "required_scopes": sorted(REQUIRED_SCOPES),
            },
            status_code=403,
        )
    return None


async def _guard(request: Request) -> Optional[JSONResponse]:
    """Run all guards: auth type, scope check."""
    err = _check_okta_auth(request)
    if err:
        return err
    err = await _check_scopes(request)
    if err:
        return err
    return None


# ---------------------------------------------------------------------------
# Import endpoints
# ---------------------------------------------------------------------------

@admin_required
async def list_importable_agents(request: Request):
    """GET /api/admin/okta/agents — List importable agents from Okta."""
    err = await _guard(request)
    if err:
        return err

    okta_token = extract_admin_token(request)
    try:
        agents = await _get_importer().list_importable_agents(okta_token)
        return JSONResponse({"agents": [asdict(a) for a in agents]})
    except Exception as e:
        logger.error(f"list_importable_agents error: {e}")
        return JSONResponse(
            {"error": "okta_unreachable", "message": str(e)}, status_code=502
        )


@admin_required
async def get_agent_detail(request: Request):
    """GET /api/admin/okta/agents/{okta_agent_id} — Agent detail + connection matching."""
    err = await _guard(request)
    if err:
        return err

    okta_agent_id = request.path_params["okta_agent_id"]
    okta_token = extract_admin_token(request)
    client = _get_client()

    try:
        agent = await client.get_agent(okta_agent_id, okta_token)
        if not agent:
            return JSONResponse(
                {"error": "not_found", "message": f"Agent {okta_agent_id} not found"},
                status_code=404,
            )

        connections = await client.get_agent_connections(okta_agent_id, okta_token)

        # Resolve linked app
        app_id = agent.get("appId") or agent.get("app_id")
        linked_app = None
        if app_id:
            linked_app = await client.get_linked_app(app_id, okta_token)

        # Match connections to adapter resources
        store = get_store()
        all_resources = store.get_all_resources()
        connection_matches = []
        for conn in connections:
            match_info = {"connection": conn, "matched_resource": None}
            if conn.get("type") == "IDENTITY_ASSERTION_CUSTOM_AS":
                props = conn.get("properties", conn)
                auth_server_id = props.get("authorizationServerId") or props.get(
                    "authorization_server_id", ""
                )
                if auth_server_id:
                    for resource in all_resources:
                        auth_config = resource.get("auth_config", {})
                        if isinstance(auth_config, str):
                            try:
                                auth_config = json.loads(auth_config)
                            except Exception:
                                continue
                        target = auth_config.get("target_authorization_server", "")
                        if auth_server_id in str(target):
                            match_info["matched_resource"] = resource.get("name")
                            break
            connection_matches.append(match_info)

        return JSONResponse({
            "agent": agent,
            "connections": connection_matches,
            "linked_app": {
                "app_id": app_id,
                "client_id": (
                    linked_app.get("credentials", {}).get("oauthClient", {}).get("client_id")
                    if linked_app else None
                ),
                "label": linked_app.get("label") if linked_app else None,
            } if app_id else None,
        })
    except Exception as e:
        logger.error(f"get_agent_detail error: {e}")
        return JSONResponse(
            {"error": "okta_unreachable", "message": str(e)}, status_code=502
        )


@admin_required
async def import_agent(request: Request):
    """POST /api/admin/okta/agents/{okta_agent_id}/import — Import agent."""
    err = await _guard(request)
    if err:
        return err

    okta_agent_id = request.path_params["okta_agent_id"]
    okta_token = extract_admin_token(request)

    # Optional body params
    body = {}
    try:
        body = await request.json()
    except Exception:
        pass

    try:
        result = await _get_importer().import_agent(
            okta_agent_id,
            okta_token,
            resource_mapping=body.get("resource_mapping"),
            agent_name_override=body.get("agent_name"),
        )

        # Run a live Okta sync so `managed_connection_scopes` and
        # `managed_connection_scope_condition` get materialized for ALLOW_ALL
        # connections. Without this, an imported agent's resources carry empty
        # scopes until the admin clicks Sync Agents — which breaks ID-JAG.
        if result.success:
            from okta_agent_proxy.app import get_resource_syncer

            syncer = get_resource_syncer()
            if syncer:
                try:
                    await syncer.sync_single_agent(
                        okta_agent_id, okta_token=okta_token, publish=True
                    )
                except Exception as e:
                    logger.warning(
                        "Post-import sync failed for %s: %s", okta_agent_id, e,
                    )

        status = 200 if result.success else 400
        return JSONResponse(asdict(result), status_code=status)
    except Exception as e:
        logger.error(f"import_agent error: {e}")
        return JSONResponse(
            {"error": "okta_unreachable", "message": str(e)}, status_code=502
        )


@admin_required
async def bulk_import_agents(request: Request):
    """POST /api/admin/okta/agents/bulk-import — Bulk import agents."""
    err = await _guard(request)
    if err:
        return err

    okta_token = extract_admin_token(request)

    try:
        body = await request.json()
    except Exception:
        return JSONResponse(
            {"error": "invalid_body", "message": "Request body must be JSON with 'agent_ids' list"},
            status_code=400,
        )

    agent_ids = body.get("agent_ids", [])
    if not agent_ids or not isinstance(agent_ids, list):
        return JSONResponse(
            {"error": "invalid_body", "message": "'agent_ids' must be a non-empty list"},
            status_code=400,
        )

    try:
        results = await _get_importer().bulk_import(agent_ids, okta_token)

        # Full sync after bulk import so every imported agent's resources get
        # their managed_connection_scopes materialized in one pass (covers
        # ALLOW_ALL expansion).
        if any(r.success for r in results):
            from okta_agent_proxy.app import get_resource_syncer

            syncer = get_resource_syncer()
            if syncer:
                try:
                    await syncer.sync(okta_token=okta_token, publish=True)
                except Exception as e:
                    logger.warning("Post-bulk-import sync failed: %s", e)

        return JSONResponse({
            "results": [asdict(r) for r in results],
            "imported": sum(1 for r in results if r.success),
            "failed": sum(1 for r in results if not r.success),
        })
    except Exception as e:
        logger.error(f"bulk_import error: {e}")
        return JSONResponse(
            {"error": "okta_unreachable", "message": str(e)}, status_code=502
        )


# ---------------------------------------------------------------------------
# Sync endpoints
# ---------------------------------------------------------------------------

@admin_required
async def sync_agent(request: Request):
    """POST /api/admin/okta/agents/{okta_agent_id}/sync — Sync single imported agent."""
    err = await _guard(request)
    if err:
        return err

    okta_agent_id = request.path_params["okta_agent_id"]
    okta_token = extract_admin_token(request)

    try:
        result = await _get_importer().sync_agent(okta_agent_id, okta_token)

        # Trigger OktaConnectionSyncer to rebuild ResolvedResource objects
        from okta_agent_proxy.app import get_resource_syncer

        syncer = get_resource_syncer()
        if syncer and result.success:
            try:
                await syncer.sync_single_agent(
                    okta_agent_id, okta_token=okta_token, publish=True
                )
            except Exception as e:
                logger.error(f"Connection sync after single agent sync failed: {e}")

        status = 200 if result.success else 400
        return JSONResponse(asdict(result), status_code=status)
    except Exception as e:
        logger.error(f"sync_agent error: {e}")
        return JSONResponse(
            {"error": "okta_unreachable", "message": str(e)}, status_code=502
        )


@admin_required
async def sync_all_agents(request: Request):
    """POST /api/admin/okta/sync/agents — Sync ALL imported agents."""
    err = await _guard(request)
    if err:
        return err

    okta_token = extract_admin_token(request)
    store = get_store()

    # Find all okta-import agents
    all_agents = store.get_all_agents(enabled_only=False)
    import_agents = [
        a for a in all_agents if a.get("registration_source") == "okta-import"
    ]

    if not import_agents:
        return JSONResponse({
            "results": [],
            "synced": 0,
            "failed": 0,
            "unchanged": 0,
        })

    await emit_audit_event(
        AuditEventType.OKTA_SYNC_STARTED,
        details={"agent_count": len(import_agents)},
    )

    importer = _get_importer()
    results = []
    for agent in import_agents:
        okta_id = agent.get("okta_ai_agent_id")
        if not okta_id:
            continue
        try:
            result = await importer.sync_agent(okta_id, okta_token)
            results.append(asdict(result))
        except Exception as e:
            results.append({
                "success": False,
                "agent_name": agent.get("agent_name", ""),
                "okta_agent_id": okta_id,
                "message": str(e),
                "resources_linked": [],
                "warnings": [],
            })

    synced = sum(1 for r in results if r["success"])
    failed = sum(1 for r in results if not r["success"])

    # Trigger OktaConnectionSyncer to build ResolvedResource objects
    from okta_agent_proxy.app import get_resource_syncer

    connection_sync_result = None
    syncer = get_resource_syncer()
    if syncer:
        try:
            connection_sync_result = await syncer.sync(okta_token=okta_token, publish=True)
        except Exception as e:
            logger.error(f"Connection sync after agent sync failed: {e}")

    await emit_audit_event(
        AuditEventType.OKTA_SYNC_COMPLETED,
        details={"synced": synced, "failed": failed},
    )

    response = {
        "results": results,
        "synced": synced,
        "failed": failed,
        "unchanged": 0,
    }
    if connection_sync_result:
        response["connection_sync"] = {
            "resources_resolved": connection_sync_result.total,
            "unresolved": len(connection_sync_result.unresolved),
        }
    return JSONResponse(response)


async def _fetch_as_scopes_supported(issuer_url: str) -> Optional[list[str]]:
    """GET {issuer_url}/.well-known/openid-configuration → scopes_supported.

    Public endpoint, no auth. Returns None on any failure so callers can leave
    existing scopes untouched rather than failing the whole sync.
    """
    url = f"{issuer_url.rstrip('/')}/.well-known/openid-configuration"
    try:
        async with httpx.AsyncClient(timeout=10.0) as http:
            resp = await http.get(url)
            if resp.status_code != 200:
                logger.warning(
                    "AS metadata fetch returned %s for %s", resp.status_code, url,
                )
                return None
            data = resp.json()
            scopes = data.get("scopes_supported")
            if not isinstance(scopes, list):
                return None
            cleaned = [s for s in scopes if isinstance(s, str)]
            logger.info(
                "AS metadata %s advertises %d scopes: %s",
                issuer_url, len(cleaned), sorted(cleaned),
            )
            return cleaned
    except Exception as exc:
        logger.warning(
            "AS metadata fetch failed for %s: %s: %s",
            issuer_url, type(exc).__name__, exc,
        )
        return None


@admin_required
async def sync_all_resources(request: Request):
    """POST /api/admin/okta/sync/resources — Delegates to the live syncer.

    In the collapsed model, each (agent, connection) pair is its own
    row and per-connection scope state is materialized directly by the
    syncer. This endpoint triggers a sync scoped to the adapter's
    configured ``OKTA_AI_AGENT_ID``.
    """
    err = await _guard(request)
    if err:
        return err

    okta_ai_agent_id = os.getenv("OKTA_AI_AGENT_ID", "")
    if not okta_ai_agent_id:
        return JSONResponse(
            {"error": "not_configured", "message": "OKTA_AI_AGENT_ID not set"},
            status_code=400,
        )

    okta_token = extract_admin_token(request)

    from okta_agent_proxy.app import get_resource_syncer

    syncer = get_resource_syncer()
    if syncer is None:
        return JSONResponse(
            {"error": "not_configured", "message": "Resource syncer not initialized"},
            status_code=503,
        )

    try:
        result = await syncer.sync_single_agent(
            okta_ai_agent_id, okta_token=okta_token
        )
    except Exception as e:
        logger.error(f"sync_all_resources: sync failed: {e}")
        return JSONResponse(
            {"error": "sync_failed", "message": str(e)}, status_code=502
        )

    return JSONResponse({
        "resources_updated": sorted(set(result.added) | set(result.modified)),
        "unchanged": [],
        "added": result.added,
        "removed": result.removed,
        "modified": result.modified,
        "unresolved": result.unresolved,
        "total": result.total,
    })


@admin_required
async def create_agent_connection(request: Request):
    """POST /api/admin/okta/agents/{okta_agent_id}/connections — Create a connection on an Okta AI agent."""
    err = await _guard(request)
    if err:
        return err

    okta_agent_id = request.path_params["okta_agent_id"]
    okta_token = extract_admin_token(request)

    try:
        body = await request.json()
    except Exception:
        return JSONResponse(
            {"error": "invalid_body", "message": "Request body must be valid JSON"},
            status_code=400,
        )

    if not body.get("connectionType"):
        return JSONResponse(
            {"error": "invalid_body", "message": "'connectionType' is required"},
            status_code=400,
        )

    try:
        result = await _get_client().create_connection(okta_agent_id, body, okta_token)
        if result is None:
            return JSONResponse(
                {"error": "create_failed", "message": "Okta API returned an error"},
                status_code=502,
            )
        return JSONResponse(result, status_code=201)
    except Exception as e:
        logger.error(f"create_agent_connection error: {e}")
        return JSONResponse(
            {"error": "okta_unreachable", "message": str(e)}, status_code=502
        )


@admin_required
async def list_potential_connections(request: Request):
    """GET /api/admin/okta/potential-connections?type=...&match=... — List potential connections."""
    err = await _guard(request)
    if err:
        return err

    okta_token = extract_admin_token(request)
    connection_type = request.query_params.get("type") or request.query_params.get("connectionType")
    match = request.query_params.get("match")

    if not connection_type:
        return JSONResponse(
            {"error": "invalid_params", "message": "'type' query parameter is required (e.g., IDENTITY_ASSERTION_CUSTOM_AS)"},
            status_code=400,
        )

    try:
        results = await _get_client().list_potential_connections(connection_type, match=match, okta_token=okta_token)
        return JSONResponse({"potential_connections": results})
    except Exception as e:
        logger.error(f"list_potential_connections error: {e}")
        return JSONResponse(
            {"error": "okta_unreachable", "message": str(e)}, status_code=502
        )


@admin_required
async def sync_all(request: Request):
    """POST /api/admin/okta/sync/all — Sync everything (agents + resources)."""
    err = await _guard(request)
    if err:
        return err

    # Reuse the individual sync handlers by calling them directly
    # But we need to pass through the guard check only once
    okta_token = extract_admin_token(request)
    store = get_store()
    importer = _get_importer()

    # --- Agent sync ---
    all_agents = store.get_all_agents(enabled_only=False)
    import_agents = [
        a for a in all_agents if a.get("registration_source") == "okta-import"
    ]
    agent_results = []
    for agent in import_agents:
        okta_id = agent.get("okta_ai_agent_id")
        if not okta_id:
            continue
        try:
            result = await importer.sync_agent(okta_id, okta_token)
            agent_results.append(asdict(result))
        except Exception as e:
            agent_results.append({
                "success": False,
                "agent_name": agent.get("agent_name", ""),
                "okta_agent_id": okta_id,
                "message": str(e),
                "resources_linked": [],
                "warnings": [],
            })

    # --- Resource sync via OktaConnectionSyncer ---
    from okta_agent_proxy.app import get_resource_syncer

    resources_updated = []
    resources_unchanged = []
    syncer = get_resource_syncer()
    if syncer:
        try:
            conn_result = await syncer.sync(okta_token=okta_token, publish=True)
            resources_updated = conn_result.added + conn_result.modified
            resources_unchanged = [
                r for r in (conn_result.removed or [])
            ] if conn_result.removed else []
        except Exception as e:
            logger.error(f"sync_all resource sync error: {e}")

    synced = sum(1 for r in agent_results if r["success"])
    failed = sum(1 for r in agent_results if not r["success"])

    return JSONResponse({
        "agents": {
            "results": agent_results,
            "synced": synced,
            "failed": failed,
            "unchanged": 0,
        },
        "resources": {
            "resources_updated": resources_updated,
            "unchanged": resources_unchanged,
        },
    })
