"""Admin API routes for credential automation.

Endpoints for fetching client secrets and generating/registering key pairs.
The admin user's Okta OIDC token is extracted from the request and passed
through to the Okta Management APIs.
"""

import logging

from starlette.requests import Request
from starlette.responses import JSONResponse

from okta_agent_proxy.admin.middleware import admin_required, extract_admin_token
from okta_agent_proxy.okta_admin.exceptions import (
    OktaAdminAuthError,
    OktaAdminForbiddenError,
    OktaAdminNotFoundError,
    OktaAdminAPIError,
)
from okta_agent_proxy.cache.pubsub import CHANNEL_AGENT_INVALIDATE

logger = logging.getLogger(__name__)

# Module-level service reference, set by wire_credential_routes()
_credential_service = None


def wire_credential_routes(service):
    """Set the credential automation service for route handlers."""
    global _credential_service
    _credential_service = service


def _get_service():
    if _credential_service is None:
        raise RuntimeError("Credential automation service not initialized")
    return _credential_service


async def _publish_event(channel: str, message: str) -> None:
    """Publish a cache invalidation event via the event bus (best-effort)."""
    try:
        from okta_agent_proxy.app import get_event_bus
        bus = get_event_bus()
        await bus.publish(channel, message)
    except Exception as e:
        logger.debug("Pub/sub publish skipped: %s", e)


@admin_required
async def fetch_secret(request: Request):
    """POST /api/admin/agents/{agent_id}/credentials/fetch-secret"""
    agent_id = request.path_params.get("agent_id", "").strip()
    admin_token = extract_admin_token(request)

    if not admin_token:
        return JSONResponse(
            {"error": "unauthorized", "message": "Missing admin token"},
            status_code=401,
        )

    try:
        result = await _get_service().fetch_client_secret(agent_id, admin_token)
        if result.get("status") == "error":
            msg = result["message"]
            if "not found" in msg:
                return JSONResponse({"error": "not_found", "message": msg}, status_code=404)
            return JSONResponse({"error": "invalid_request", "message": msg}, status_code=400)
        await _publish_event(CHANNEL_AGENT_INVALIDATE, agent_id)
        return JSONResponse(result)

    except OktaAdminAuthError as e:
        return JSONResponse(
            {"error": "okta_auth_error", "message": e.message},
            status_code=401,
        )
    except OktaAdminForbiddenError:
        return JSONResponse(
            {"error": "okta_forbidden", "message": "Your Okta admin role needs okta.apps.manage scope"},
            status_code=403,
        )
    except OktaAdminNotFoundError as e:
        return JSONResponse(
            {"error": "not_found", "message": e.message},
            status_code=404,
        )
    except OktaAdminAPIError as e:
        logger.error("Okta API error during fetch-secret for %s: %s", agent_id, e.message)
        return JSONResponse(
            {"error": "okta_api_error", "message": e.message},
            status_code=502,
        )
    except Exception as e:
        logger.error("Error fetching secret for %s: %s", agent_id, e, exc_info=True)
        return JSONResponse(
            {"error": "server_error", "message": "Failed to fetch client secret"},
            status_code=500,
        )


@admin_required
async def generate_keypair(request: Request):
    """POST /api/admin/agents/{agent_id}/credentials/generate-keypair"""
    agent_id = request.path_params.get("agent_id", "").strip()
    admin_token = extract_admin_token(request)

    if not admin_token:
        return JSONResponse(
            {"error": "unauthorized", "message": "Missing admin token"},
            status_code=401,
        )

    try:
        result = await _get_service().generate_key_pair(agent_id, admin_token)
        if result.get("status") == "error":
            msg = result["message"]
            if "not found" in msg:
                return JSONResponse({"error": "not_found", "message": msg}, status_code=404)
            return JSONResponse({"error": "invalid_request", "message": msg}, status_code=400)
        await _publish_event(CHANNEL_AGENT_INVALIDATE, agent_id)
        return JSONResponse(result)

    except OktaAdminAuthError as e:
        return JSONResponse(
            {"error": "okta_auth_error", "message": e.message},
            status_code=401,
        )
    except OktaAdminForbiddenError:
        return JSONResponse(
            {"error": "okta_forbidden", "message": "Your Okta admin role needs okta.aiAgents.manage scope"},
            status_code=403,
        )
    except OktaAdminNotFoundError as e:
        return JSONResponse(
            {"error": "not_found", "message": e.message},
            status_code=404,
        )
    except OktaAdminAPIError as e:
        logger.error("Okta API error during generate-keypair for %s: %s", agent_id, e.message)
        return JSONResponse(
            {"error": "okta_api_error", "message": e.message},
            status_code=502,
        )
    except Exception as e:
        logger.error("Error generating keypair for %s: %s", agent_id, e, exc_info=True)
        return JSONResponse(
            {"error": "server_error", "message": "Failed to generate key pair"},
            status_code=500,
        )


@admin_required
async def credential_status(request: Request):
    """GET /api/admin/agents/{agent_id}/credentials/status"""
    agent_id = request.path_params.get("agent_id", "").strip()
    admin_token = extract_admin_token(request)

    if not admin_token:
        return JSONResponse(
            {"error": "unauthorized", "message": "Missing admin token"},
            status_code=401,
        )

    try:
        result = await _get_service().get_credential_status(agent_id, admin_token)
        if result.get("status") == "error":
            msg = result["message"]
            if "not found" in msg:
                return JSONResponse({"error": "not_found", "message": msg}, status_code=404)
            return JSONResponse({"error": "invalid_request", "message": msg}, status_code=400)
        return JSONResponse(result)

    except Exception as e:
        logger.error("Error getting credential status for %s: %s", agent_id, e, exc_info=True)
        return JSONResponse(
            {"error": "server_error", "message": "Failed to get credential status"},
            status_code=500,
        )
