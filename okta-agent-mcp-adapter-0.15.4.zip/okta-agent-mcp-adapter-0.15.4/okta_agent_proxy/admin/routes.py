"""
Admin API Routes

Provides endpoints for managing agents and resources using the repository layer.
All routes require authentication via JWT token (see admin/auth.py).
"""

import logging
import json
import os
import uuid
from typing import Dict, Any, Optional
from starlette.responses import JSONResponse, Response
from starlette.requests import Request

from okta_agent_proxy.admin.middleware import admin_required, extract_admin_token
from okta_agent_proxy.storage.base import ResourceConfigStore
from okta_agent_proxy.database import get_store
from okta_agent_proxy.auth.user_token_store import get_user_token_store
from okta_agent_proxy.auth.global_logout import GlobalLogoutHandler
from okta_agent_proxy.audit import emit_audit_event, AuditEventType, AuditSeverity
from okta_agent_proxy.okta_admin.client import OktaAPIClient
from okta_agent_proxy.okta_admin.exceptions import (
    OktaAdminAuthError,
    OktaAdminForbiddenError,
    OktaAdminNotFoundError,
)
from okta_agent_proxy.cache.pubsub import (
    CHANNEL_ROUTE_INVALIDATE,
    CHANNEL_AGENT_INVALIDATE,
    CHANNEL_TOOL_CATALOG_INVALIDATE,
)

logger = logging.getLogger(__name__)


async def _publish_event(channel: str, message: str) -> None:
    """Publish a cache invalidation event via the event bus (best-effort)."""
    try:
        from okta_agent_proxy.app import get_event_bus
        bus = get_event_bus()
        await bus.publish(channel, message)
    except Exception as e:
        logger.debug(f"Pub/sub publish skipped: {e}")


async def _publish_scoped_tool_invalidation(agent_id: str | None = None) -> None:
    """Publish a tool catalog invalidation with optional agent scoping."""
    if agent_id:
        import json as _json
        payload = _json.dumps({"agent_id": agent_id})
    else:
        payload = "all"
    await _publish_event(CHANNEL_TOOL_CATALOG_INVALIDATE, payload)


# ============================================================================
# Agent Routes
# ============================================================================

@admin_required
async def list_agents(request: Request):
    """
    List all agents.

    GET /api/admin/agents

    Returns:
        {"agents": [{"agent_name": "...", "agent_id": "...", ...}, ...]}
    """
    try:
        store: ResourceConfigStore = get_store()
        agents = store.get_all_agents(enabled_only=False)

        logger.info(f"Listed {len(agents)} agents")
        return JSONResponse({"agents": agents})

    except Exception as e:
        logger.error(f"Error listing agents: {e}", exc_info=True)
        return JSONResponse(
            {
                "error": "server_error",
                "message": "Failed to list agents"
            },
            status_code=500
        )


@admin_required
async def get_agent(request: Request):
    """
    Get a specific agent.

    GET /api/admin/agents/{agent_id}

    Returns:
        {"agent_name": "...", "agent_id": "...", ...}
    """
    try:
        agent_id = request.path_params.get("agent_id", "").strip()

        if not agent_id:
            return JSONResponse(
                {
                    "error": "invalid_input",
                    "message": "Agent ID is required"
                },
                status_code=400
            )

        store: ResourceConfigStore = get_store()
        agent = store.get_agent(agent_id, enabled_only=False)

        if not agent:
            return JSONResponse(
                {
                    "error": "not_found",
                    "message": f"Agent '{agent_id}' not found"
                },
                status_code=404
            )

        logger.info(f"Retrieved agent: {agent_id}")
        return JSONResponse(agent)

    except Exception as e:
        logger.error(f"Error getting agent: {e}", exc_info=True)
        return JSONResponse(
            {
                "error": "server_error",
                "message": "Failed to get agent"
            },
            status_code=500
        )


@admin_required
async def create_agent(request: Request):
    """
    Create a new agent.

    POST /api/admin/agents
    Body: {
        "agent_id": "...",
        "agent_name": "...",  # Optional, defaults to agent_id
        "client_id": "...",
        "client_secret": "...",  # Optional
        "private_key": "...",
        "scopes": ["mcp:read"],  # Optional
        "enabled": true  # Optional
    }

    Returns:
        201: {"agent_name": "...", "agent_id": "...", ...}
        400: {"error": "invalid_input", "message": "..."}
    """
    try:
        body = await request.json()
        agent_id = body.get("agent_id", "").strip()

        if not agent_id:
            return JSONResponse(
                {
                    "error": "invalid_input",
                    "message": "agent_id is required"
                },
                status_code=400
            )

        # Validate required fields
        required_fields = ["client_id", "private_key"]
        for field in required_fields:
            if field not in body:
                return JSONResponse(
                    {
                        "error": "invalid_input",
                        "message": f"Missing required field: {field}"
                    },
                    status_code=400
                )

        # Validate cimd_client_id if provided
        cimd_client_id = body.get("cimd_client_id", "").strip() if body.get("cimd_client_id") else ""
        if cimd_client_id:
            if not (cimd_client_id.startswith("https://") or cimd_client_id.startswith("http://localhost")):
                return JSONResponse(
                    {
                        "error": "invalid_input",
                        "message": "cimd_client_id must start with https:// or http://localhost"
                    },
                    status_code=400
                )

        # Get authenticated user from request state
        user = getattr(request.state, 'admin_user', 'admin')

        store: ResourceConfigStore = get_store()

        # Check if agent already exists
        existing = store.get_agent(agent_id, enabled_only=False)
        if existing:
            return JSONResponse(
                {
                    "error": "already_exists",
                    "message": f"Agent '{agent_id}' already exists"
                },
                status_code=409
            )

        # Extract request metadata for audit
        ip_address = request.client.host if request.client else None
        user_agent_str = request.headers.get("user-agent")

        # Create agent
        success = store.create_agent(agent_id, body, user=user,
                                     ip_address=ip_address, user_agent=user_agent_str)

        if not success:
            return JSONResponse(
                {
                    "error": "creation_failed",
                    "message": f"Failed to create agent '{agent_id}'"
                },
                status_code=500
            )

        # Retrieve created agent
        created_agent = store.get_agent(agent_id, enabled_only=False)

        await emit_audit_event(
            AuditEventType.CONFIG_AGENT_CREATED,
            details={
                "agent_id": agent_id,
                "source": body.get("registration_source", "manual"),
            },
        )

        # Publish invalidation events for cross-container sync
        await _publish_event(CHANNEL_AGENT_INVALIDATE, agent_id)
        await _publish_event(CHANNEL_TOOL_CATALOG_INVALIDATE, agent_id)

        logger.info(f"Created agent: {agent_id} by {user}")
        return JSONResponse(created_agent, status_code=201)

    except ValueError as e:
        logger.warning(f"Invalid agent creation: {e}")
        return JSONResponse(
            {
                "error": "invalid_input",
                "message": str(e)
            },
            status_code=400
        )
    except Exception as e:
        logger.error(f"Error creating agent: {e}", exc_info=True)
        return JSONResponse(
            {
                "error": "server_error",
                "message": "Failed to create agent"
            },
            status_code=500
        )


@admin_required
async def update_agent(request: Request):
    """
    Update an existing agent.

    PUT /api/admin/agents/{agent_id}
    Body: {
        "client_id": "...",  # Optional
        "client_secret": "...",  # Optional
        "private_key": "...",  # Optional
        "scopes": [...],  # Optional
        "enabled": true  # Optional
    }

    Returns:
        200: {"agent_name": "...", "agent_id": "...", ...}
        404: {"error": "not_found", "message": "..."}
    """
    try:
        agent_id = request.path_params.get("agent_id", "").strip()
        body = await request.json()

        if not agent_id:
            return JSONResponse(
                {
                    "error": "invalid_input",
                    "message": "Agent ID is required"
                },
                status_code=400
            )

        # Validate cimd_client_id if provided
        if "cimd_client_id" in body and body["cimd_client_id"]:
            cimd_val = body["cimd_client_id"].strip()
            if not (cimd_val.startswith("https://") or cimd_val.startswith("http://localhost")):
                return JSONResponse(
                    {
                        "error": "invalid_input",
                        "message": "cimd_client_id must start with https:// or http://localhost"
                    },
                    status_code=400
                )

        # Get authenticated user from request state
        user = getattr(request.state, 'admin_user', 'admin')

        store: ResourceConfigStore = get_store()

        # Check if agent exists
        existing = store.get_agent(agent_id, enabled_only=False)
        if not existing:
            return JSONResponse(
                {
                    "error": "not_found",
                    "message": f"Agent '{agent_id}' not found"
                },
                status_code=404
            )

        # Extract request metadata for audit
        ip_address = request.client.host if request.client else None
        user_agent_str = request.headers.get("user-agent")

        # Update agent
        success = store.update_agent(agent_id, body, user=user,
                                     ip_address=ip_address, user_agent=user_agent_str)

        if not success:
            return JSONResponse(
                {
                    "error": "update_failed",
                    "message": f"Failed to update agent '{agent_id}'"
                },
                status_code=500
            )

        # Retrieve updated agent
        updated_agent = store.get_agent(agent_id, enabled_only=False)

        await emit_audit_event(
            AuditEventType.CONFIG_AGENT_UPDATED,
            details={"agent_id": agent_id, "user": user},
        )

        # Publish invalidation events for cross-container sync
        await _publish_event(CHANNEL_AGENT_INVALIDATE, agent_id)
        await _publish_event(CHANNEL_TOOL_CATALOG_INVALIDATE, agent_id)

        logger.info(f"Updated agent: {agent_id} by {user}")
        return JSONResponse(updated_agent)

    except ValueError as e:
        logger.warning(f"Invalid agent update: {e}")
        return JSONResponse(
            {
                "error": "not_found",
                "message": str(e)
            },
            status_code=404
        )
    except Exception as e:
        logger.error(f"Error updating agent: {e}", exc_info=True)
        return JSONResponse(
            {
                "error": "server_error",
                "message": "Failed to update agent"
            },
            status_code=500
        )


@admin_required
async def delete_agent(request: Request):
    """
    Delete an agent.

    DELETE /api/admin/agents/{agent_id}

    Returns:
        200: {"message": "Agent '...' deleted"}
        404: {"error": "not_found", "message": "..."}
    """
    try:
        agent_id = request.path_params.get("agent_id", "").strip()

        if not agent_id:
            return JSONResponse(
                {
                    "error": "invalid_input",
                    "message": "Agent ID is required"
                },
                status_code=400
            )

        # Get authenticated user from request state
        user = getattr(request.state, 'admin_user', 'admin')

        store: ResourceConfigStore = get_store()

        # Check if agent exists
        existing = store.get_agent(agent_id, enabled_only=False)
        if not existing:
            return JSONResponse(
                {
                    "error": "not_found",
                    "message": f"Agent '{agent_id}' not found"
                },
                status_code=404
            )

        # Extract request metadata for audit
        ip_address = request.client.host if request.client else None
        user_agent_str = request.headers.get("user-agent")

        # Delete agent
        success = store.delete_agent(agent_id, user=user,
                                     ip_address=ip_address, user_agent=user_agent_str)

        if not success:
            return JSONResponse(
                {
                    "error": "deletion_failed",
                    "message": f"Failed to delete agent '{agent_id}'"
                },
                status_code=500
            )

        await emit_audit_event(
            AuditEventType.CONFIG_AGENT_DELETED,
            severity=AuditSeverity.WARNING,
            details={"agent_id": agent_id, "user": user},
        )

        # Publish invalidation events for cross-container sync
        await _publish_event(CHANNEL_AGENT_INVALIDATE, agent_id)
        await _publish_event(CHANNEL_TOOL_CATALOG_INVALIDATE, agent_id)

        logger.info(f"Deleted agent: {agent_id} by {user}")
        return JSONResponse({"message": f"Agent '{agent_id}' deleted"})

    except ValueError as e:
        logger.warning(f"Invalid agent deletion: {e}")
        return JSONResponse(
            {
                "error": "not_found",
                "message": str(e)
            },
            status_code=404
        )
    except Exception as e:
        logger.error(f"Error deleting agent: {e}", exc_info=True)
        return JSONResponse(
            {
                "error": "server_error",
                "message": "Failed to delete agent"
            },
            status_code=500
        )


# ============================================================================
# Resource Map CRUD Routes (Okta-native resource architecture)
# ============================================================================

async def _publish_rm_event(channel: str, message: str) -> None:
    """Publish a Resource Map cache invalidation event (best-effort)."""
    try:
        from okta_agent_proxy.app import get_resource_map_event_bus
        bus = get_resource_map_event_bus()
        if bus:
            await bus.publish(channel, message)
    except Exception as e:
        logger.debug(f"Resource Map pub/sub publish skipped: {e}")


@admin_required
async def list_resources(request: Request):
    """List all resources.

    GET /api/admin/resources
    """
    try:
        from okta_agent_proxy.app import get_resource_store
        rm_store = get_resource_store()
        if not rm_store:
            return JSONResponse(
                {"error": "not_configured", "message": "Resource store not initialized"},
                status_code=503,
            )

        return JSONResponse({"resources": rm_store.admin_list()})

    except Exception as e:
        logger.error(f"Error listing resources: {e}", exc_info=True)
        return JSONResponse(
            {"error": "server_error", "message": "Failed to list resources"},
            status_code=500,
        )


@admin_required
async def get_resource(request: Request):
    """Get a single resource by name.

    GET /api/admin/resources/{name}
    """
    try:
        name = request.path_params.get("name", "").strip()
        if not name:
            return JSONResponse(
                {"error": "invalid_input", "message": "Resource name is required"},
                status_code=400,
            )

        from okta_agent_proxy.app import get_resource_store
        rm_store = get_resource_store()
        if not rm_store:
            return JSONResponse(
                {"error": "not_configured", "message": "Resource store not initialized"},
                status_code=503,
            )

        row = rm_store.admin_get(name)
        if not row:
            return JSONResponse(
                {"error": "not_found", "message": f"Resource '{name}' not found"},
                status_code=404,
            )
        return JSONResponse(row)

    except Exception as e:
        logger.error(f"Error getting resource: {e}", exc_info=True)
        return JSONResponse(
            {"error": "server_error", "message": "Failed to get resource"},
            status_code=500,
        )


@admin_required
async def update_resource(request: Request):
    """Update admin-editable fields on a resource.

    PUT /api/admin/resources/{name}
    Body may include: url, name, type, description, paths, config, tags,
    auth_config, timeout_seconds, enabled.

    Sync-owned fields (scopes, scope_condition, connection_type,
    auth_method, metadata, agent_id, connection_id,
    connection_resource_id) are rejected — those are owned by the Okta
    syncer.
    """
    try:
        name = request.path_params.get("name", "").strip()
        if not name:
            return JSONResponse(
                {"error": "invalid_input", "message": "Resource name is required"},
                status_code=400,
            )

        body = await request.json()

        for key in (
            "id", "resource_id", "agent_id", "connection_id",
            "connection_type", "connection_resource_id", "scopes",
            "scope_condition", "auth_method", "metadata",
        ):
            body.pop(key, None)

        from okta_agent_proxy.app import get_resource_store
        rm_store = get_resource_store()
        if not rm_store:
            return JSONResponse(
                {"error": "not_configured", "message": "Resource store not initialized"},
                status_code=503,
            )

        user = getattr(request.state, "admin_user", "admin")
        try:
            updated = rm_store.update_editable(name, body, user=user)
        except ValueError as ve:
            return JSONResponse(
                {"error": "invalid_input", "message": str(ve)},
                status_code=400,
            )
        if updated is None:
            return JSONResponse(
                {"error": "not_found", "message": f"Resource '{name}' not found"},
                status_code=404,
            )

        rm_store.load_cache()

        from okta_agent_proxy.resources.event_bus import CHANNEL_RESOURCE_CHANGED
        await _publish_rm_event(CHANNEL_RESOURCE_CHANGED, f"updated:{updated['name']}")

        await emit_audit_event(
            AuditEventType.CONFIG_RESOURCE_UPDATED,
            details={"name": updated["name"]},
        )

        logger.info(f"Updated resource: {updated['name']}")
        return JSONResponse(updated)

    except Exception as e:
        logger.error(f"Error updating resource: {e}", exc_info=True)
        return JSONResponse(
            {"error": "server_error", "message": "Failed to update resource"},
            status_code=500,
        )


@admin_required
async def delete_resource(request: Request):
    """Delete a resource row by name.

    DELETE /api/admin/resources/{name}
    """
    try:
        name = request.path_params.get("name", "").strip()
        if not name:
            return JSONResponse(
                {"error": "invalid_input", "message": "Resource name is required"},
                status_code=400,
            )

        from okta_agent_proxy.app import get_resource_store
        rm_store = get_resource_store()
        if not rm_store:
            return JSONResponse(
                {"error": "not_configured", "message": "Resource store not initialized"},
                status_code=503,
            )

        user = getattr(request.state, "admin_user", "admin")
        deleted = rm_store.delete_by_name(name, user=user)
        if not deleted:
            return JSONResponse(
                {"error": "not_found", "message": f"Resource '{name}' not found"},
                status_code=404,
            )

        rm_store.load_cache()

        from okta_agent_proxy.resources.event_bus import CHANNEL_RESOURCE_CHANGED
        await _publish_rm_event(CHANNEL_RESOURCE_CHANGED, f"deleted:{name}")

        await emit_audit_event(
            AuditEventType.CONFIG_RESOURCE_DELETED,
            severity=AuditSeverity.WARNING,
            details={"name": name},
        )

        logger.info(f"Deleted resource: {name}")
        return Response(status_code=204)

    except Exception as e:
        logger.error(f"Error deleting resource: {e}", exc_info=True)
        return JSONResponse(
            {"error": "server_error", "message": f"Failed to delete resource: {str(e)}"},
            status_code=500,
        )


# ============================================================================
# Connection Sync Routes
# ============================================================================

@admin_required
async def sync_connections(request: Request):
    """
    Trigger an Okta Managed Connections sync.

    POST /api/admin/connections/sync

    Uses the admin's Okta access token to call the Okta API, so no
    pre-configured OKTA_SERVICE_TOKEN is required for UI-triggered syncs.
    """
    try:
        from okta_agent_proxy.app import get_resource_syncer
        from okta_agent_proxy.admin.middleware import extract_admin_token
        syncer = get_resource_syncer()
        if not syncer:
            return JSONResponse(
                {"error": "not_configured", "message": "Syncer not initialized"},
                status_code=503,
            )

        # Forward the admin's Okta token for the API call
        okta_token = extract_admin_token(request)
        result = await syncer.sync(okta_token=okta_token)
        await emit_audit_event(
            AuditEventType.OKTA_SYNC_COMPLETED,
            details={
                "trigger": "manual",
                "added": result.added,
                "removed": result.removed,
                "unresolved": result.unresolved,
                "total": result.total,
            },
        )
        return JSONResponse({
            "added": result.added,
            "removed": result.removed,
            "modified": result.modified,
            "unresolved": result.unresolved,
            "total": result.total,
            "synced_at": result.synced_at.isoformat(),
        })
    except Exception as e:
        logger.error(f"Error syncing connections: {e}", exc_info=True)
        return JSONResponse(
            {"error": "server_error", "message": "Failed to sync connections"},
            status_code=500,
        )


@admin_required
async def connection_status(request: Request):
    """
    Get current sync status.

    GET /api/admin/connections/status
    """
    try:
        from okta_agent_proxy.app import get_resource_syncer, get_resource_store
        syncer = get_resource_syncer()
        rm_store = get_resource_store()

        status = syncer.get_sync_status() if syncer else {"status": "not_configured"}
        db_state = rm_store.get_latest_sync_state() if rm_store else None

        return JSONResponse({
            "syncer": status,
            "last_persisted_state": db_state,
        })
    except Exception as e:
        logger.error(f"Error getting connection status: {e}", exc_info=True)
        return JSONResponse(
            {"error": "server_error", "message": "Failed to get connection status"},
            status_code=500,
        )


# ============================================================================
# Agent Connection & Resource Linkage Routes
# ============================================================================

# In-memory cache for authorization server display names (rarely changes)
_as_name_cache: Dict[str, str] = {}


@admin_required
async def get_agent_connections(request: Request):
    """
    Get full agent detail with Okta connections and resource linkage.

    GET /api/admin/agents/{agent_id}/connections

    Returns connections for this agent with linked_resource info for each.
    """
    try:
        agent_id = request.path_params.get("agent_id", "").strip()
        if not agent_id:
            return JSONResponse(
                {"error": "invalid_input", "message": "Agent ID is required"},
                status_code=400,
            )

        store = get_store()
        agent = store.get_agent(agent_id, enabled_only=False)
        if not agent:
            return JSONResponse(
                {"error": "not_found", "message": f"Agent '{agent_id}' not found"},
                status_code=404,
            )

        okta_ai_agent_id = agent.get("okta_ai_agent_id")
        if not okta_ai_agent_id:
            return JSONResponse({
                "agent": agent,
                "okta_agent": None,
                "connections": [],
                "linked_app": None,
                "stats": {
                    "total_connections": 0,
                    "linked_count": 0,
                    "unlinked_count": 0,
                    "total_tools": 0,
                },
                "note": "Agent was not imported from Okta — no connections available",
            })

        # Fetch connections from Okta using admin's token
        from okta_agent_proxy.admin.middleware import extract_admin_token
        from okta_agent_proxy.admin.okta_import_routes import _get_client
        from okta_agent_proxy.resources.utils import (
            extract_resource_id,
            parse_connection_type,
        )

        okta_token = extract_admin_token(request)
        client = _get_client()

        okta_agent = await client.get_agent(okta_ai_agent_id, okta_token)
        connections_raw = await client.get_agent_connections(okta_ai_agent_id, okta_token)

        # Handle the {data: [...]} envelope format
        if isinstance(connections_raw, dict):
            connections_raw = (
                connections_raw.get("data")
                or connections_raw.get("connections")
                or connections_raw.get("items")
                or []
            )

        # Resolve linked app
        app_id = None
        linked_app = None
        if okta_agent:
            app_id = okta_agent.get("appId") or okta_agent.get("app_id")
            if app_id:
                linked_app_data = await client.get_linked_app(app_id, okta_token)
                if linked_app_data:
                    linked_app = {
                        "app_id": app_id,
                        "client_id": (
                            linked_app_data.get("credentials", {})
                            .get("oauthClient", {})
                            .get("client_id")
                        ),
                        "label": linked_app_data.get("label"),
                    }

        # Get Resource Map store and syncer for resource lookups
        from okta_agent_proxy.app import get_resource_store, get_resource_syncer
        rm_store = get_resource_store()
        syncer = get_resource_syncer()

        connections_out = []
        fully_linked_count = 0
        partially_linked_count = 0
        unlinked_count = 0
        inactive_count = 0
        total_resources = 0
        total_tools = 0

        for conn in connections_raw:
            conn_type = parse_connection_type(conn)
            connection_id = conn.get("id", "")
            status = conn.get("status", "ACTIVE")
            scopes = conn.get("scopes", [])
            scope_condition = conn.get("scopeCondition") or conn.get("scope_condition")
            resource_indicator = conn.get("resourceIndicator", "")

            # Extract resource_id
            resource_id = ""
            if conn_type:
                resource_id = extract_resource_id(conn, conn_type) or ""

            # Determine display name
            display_name = conn.get("name") or conn.get("label") or ""
            if not display_name and conn_type and conn_type.value == "IDENTITY_ASSERTION_CUSTOM_AS":
                display_name = await _get_as_display_name(
                    resource_id, okta_token, client
                )
            if not display_name:
                display_name = f"Connection {connection_id[:8]}" if connection_id else resource_id

            # Look up the single (agent, connection) resource row.
            resource_row = None
            if rm_store and status == "ACTIVE":
                resource_row = rm_store.get_by_agent_connection(
                    agent_id, connection_id
                )
                if resource_row:
                    total_resources += 1

            # Track stats
            if status != "ACTIVE":
                inactive_count += 1
            elif resource_row and resource_row.get("enabled"):
                fully_linked_count += 1
            else:
                unlinked_count += 1

            connections_out.append({
                "connection_id": connection_id,
                "connection_type": conn_type.value if conn_type else "UNKNOWN",
                "display_name": display_name,
                "resource_id": resource_id,
                "resource_indicator": resource_indicator,
                "scopes": scopes,
                "scope_condition": scope_condition,
                "status": status,
                "resource": resource_row,
            })

        total_connections = len(connections_out)

        try:
            from okta_agent_proxy.app import get_unified_handler
            catalog = await get_unified_handler().get_cached_catalog(agent_id)
            if catalog:
                total_tools = len(catalog.get("tools", []))
        except Exception as e:
            logger.debug(f"Tool catalog lookup skipped for {agent_id}: {e}")

        return JSONResponse({
            "agent": agent,
            "okta_agent": okta_agent,
            "connections": connections_out,
            "linked_app": linked_app,
            "stats": {
                "total_connections": total_connections,
                "fully_linked_count": fully_linked_count,
                "partially_linked_count": partially_linked_count,
                "unlinked_count": unlinked_count,
                "inactive_count": inactive_count,
                "total_resources": total_resources,
                "total_tools": total_tools,
            },
        })

    except Exception as e:
        logger.error(f"Error getting agent connections: {e}", exc_info=True)
        return JSONResponse(
            {"error": "server_error", "message": f"Failed to get agent connections: {e}"},
            status_code=500,
        )


@admin_required
async def get_agent_tools(request: Request):
    """
    Return the cached tool catalog for an agent, grouped by resource name.

    GET /api/admin/agents/{agent_id}/tools

    Reads the tool catalog populated by the unified MCP handler when an MCP
    client issues tools/list. Does not trigger fresh discovery — if the cache
    is empty, returns an empty resources list with cached=false.
    """
    try:
        agent_id = request.path_params.get("agent_id", "").strip()
        if not agent_id:
            return JSONResponse(
                {"error": "invalid_input", "message": "Agent ID is required"},
                status_code=400,
            )

        store = get_store()
        agent = store.get_agent(agent_id, enabled_only=False)
        if not agent:
            return JSONResponse(
                {"error": "not_found", "message": f"Agent '{agent_id}' not found"},
                status_code=404,
            )

        from okta_agent_proxy.app import get_unified_handler
        from okta_agent_proxy.mcp.unified_handler import NAMESPACE_SEPARATOR

        catalog = await get_unified_handler().get_cached_catalog(agent_id)
        if not catalog:
            return JSONResponse({
                "agent_id": agent_id,
                "cached": False,
                "total_tools": 0,
                "resources": [],
            })

        grouped: Dict[str, list] = {}
        for tool in catalog.get("tools", []):
            namespaced = tool.get("name", "")
            if NAMESPACE_SEPARATOR in namespaced:
                resource_name, original_name = namespaced.split(NAMESPACE_SEPARATOR, 1)
            else:
                # Defensive: non-namespaced entries still shown under "unknown"
                resource_name, original_name = "unknown", namespaced
            entry = {**tool, "name": original_name}
            grouped.setdefault(resource_name, []).append(entry)

        resources = [
            {
                "resource_name": name,
                "tool_count": len(tools),
                "tools": tools,
            }
            for name, tools in sorted(grouped.items())
        ]

        return JSONResponse({
            "agent_id": agent_id,
            "cached": True,
            "total_tools": len(catalog.get("tools", [])),
            "resources": resources,
        })

    except Exception as e:
        logger.error(f"Error getting agent tools: {e}", exc_info=True)
        return JSONResponse(
            {"error": "server_error", "message": f"Failed to get agent tools: {e}"},
            status_code=500,
        )


async def _get_as_display_name(
    resource_id: str, okta_token: str | None, client
) -> str:
    """Get authorization server display name, with in-memory caching."""
    if not resource_id or not okta_token:
        return ""
    if resource_id in _as_name_cache:
        return _as_name_cache[resource_id]
    try:
        okta_domain = os.getenv("OKTA_DOMAIN", "")
        if not okta_domain:
            return ""
        if not okta_domain.startswith("http"):
            okta_domain = f"https://{okta_domain}"
        import httpx
        async with httpx.AsyncClient(timeout=10.0) as http:
            headers = {"Authorization": f"Bearer {okta_token}", "Accept": "application/json"}
            resp = await http.get(
                f"{okta_domain}/api/v1/authorizationServers/{resource_id}",
                headers=headers,
            )
            if resp.status_code == 200:
                name = resp.json().get("name", "")
                if name:
                    _as_name_cache[resource_id] = name
                    return name
    except Exception as e:
        logger.debug(f"Failed to fetch AS name for {resource_id}: {e}")
    return ""



# ============================================================================
# Audit Log Routes
# ============================================================================

@admin_required
async def get_audit_log(request: Request):
    """
    Get audit log entries.

    GET /api/admin/audit?entity_type=&entity_id=&limit=100

    Returns:
        {"audit_log": [...]}
    """
    try:
        store: ResourceConfigStore = get_store()
        entity_type = request.query_params.get("entity_type")
        entity_id = request.query_params.get("entity_id")
        limit = int(request.query_params.get("limit", "100"))

        # Use resource_name filter for resource-type queries
        resource_name = None
        if entity_type == "resource" and entity_id:
            resource_name = entity_id

        entries = store.get_audit_log(resource_name=resource_name, limit=limit)

        # If entity_type filter is set (and not already handled by resource_name),
        # filter in-memory for agent-type queries
        if entity_type and entity_type != "resource":
            entries = [e for e in entries if e.get("entity_type") == entity_type]
            if entity_id:
                entries = [e for e in entries if e.get("entity_id") == entity_id]

        return JSONResponse({"audit_log": entries})

    except Exception as e:
        logger.error(f"Error getting audit log: {e}", exc_info=True)
        return JSONResponse(
            {"error": "server_error", "message": "Failed to get audit log"},
            status_code=500,
        )


@admin_required
async def get_agent_audit_log(request: Request):
    """
    Get audit log entries for a specific agent.

    GET /api/admin/agents/{agent_id}/audit?limit=100

    Returns:
        {"audit_log": [...]}
    """
    try:
        agent_id = request.path_params.get("agent_id", "").strip()
        limit = int(request.query_params.get("limit", "100"))

        if not agent_id:
            return JSONResponse(
                {"error": "invalid_input", "message": "Agent ID is required"},
                status_code=400,
            )

        store: ResourceConfigStore = get_store()
        entries = store.get_agent_audit_log(agent_id, limit=limit)
        return JSONResponse({"audit_log": entries})

    except Exception as e:
        logger.error(f"Error getting agent audit log: {e}", exc_info=True)
        return JSONResponse(
            {"error": "server_error", "message": "Failed to get agent audit log"},
            status_code=500,
        )


@admin_required
async def get_resource_audit_log(request: Request):
    """
    Get audit log entries for a specific resource.

    GET /api/admin/resources/{name}/audit?limit=100

    Returns:
        {"audit_log": [...]}
    """
    try:
        name = request.path_params.get("name", "").strip()
        limit = int(request.query_params.get("limit", "100"))

        if not name:
            return JSONResponse(
                {"error": "invalid_input", "message": "Resource name is required"},
                status_code=400,
            )

        store: ResourceConfigStore = get_store()
        entries = store.get_audit_log(resource_name=name, limit=limit)
        return JSONResponse({"audit_log": entries})

    except Exception as e:
        logger.error(f"Error getting resource audit log: {e}", exc_info=True)
        return JSONResponse(
            {"error": "server_error", "message": "Failed to get resource audit log"},
            status_code=500,
        )


# ============================================================================
# Gateway Config (read-only public metadata for Admin UI)
# ============================================================================

@admin_required
async def get_public_config(request: Request):
    """
    GET /api/admin/config/public

    Returns gateway metadata the Admin UI needs to construct user-facing URLs
    (pre-consent links, OAuth callback targets, etc.). The gateway is the source
    of truth for its own public base URL — the Admin UI should fetch this rather
    than relying on build-time NEXT_PUBLIC_* variables.
    """
    gateway_base_url = os.getenv("GATEWAY_BASE_URL", "http://localhost:8000").rstrip("/")
    return JSONResponse({"gateway_base_url": gateway_base_url})


# ============================================================================
# Token Store Admin Routes
# ============================================================================

@admin_required
async def list_routes(request: Request):
    """
    GET /api/admin/routes

    Returns the complete routing table showing all path-to-resource mappings,
    including both canonical (auto-registered) and explicit (configured) routes.
    """
    from okta_agent_proxy.app import get_router
    router = get_router()

    if router is None:
        return JSONResponse({"error": "Router not initialized"}, status_code=503)

    routes = []
    for path, resource_name in sorted(router._path_to_resource.items()):
        resource_config = router.get_resource_config(resource_name)
        is_canonical = (path == f"/{resource_name}")
        routes.append({
            "path": path,
            "resource_name": resource_name,
            "resource_url": resource_config.url if resource_config else None,
            "route_type": "canonical" if is_canonical else "alias",
            "enabled": resource_config.enabled if resource_config else False,
        })

    resources_summary = []
    for name, config in router.list_resources().items():
        resources_summary.append({
            "name": name,
            "canonical_path": f"/{name}",
            "alias_paths": [p for p in config.paths if p != f"/{name}"],
            "unified_endpoint": True,
            "direct_endpoint": True,
            "enabled": config.enabled,
        })

    return JSONResponse({
        "routing_mode": "both",
        "total_routes": len(routes),
        "routes": routes,
        "resources": resources_summary,
    })


@admin_required
async def token_store_stats(request: Request):
    """
    Get token store statistics.

    GET /api/admin/token-store/stats

    Returns:
        {"total_entries": N, "encrypted": bool, "ttl_seconds": N, "max_size": N}
    """
    try:
        store = get_user_token_store()
        return JSONResponse(store.get_stats())
    except Exception as e:
        logger.error(f"Error getting token store stats: {e}", exc_info=True)
        return JSONResponse(
            {"error": "server_error", "message": "Failed to get token store stats"},
            status_code=500,
        )


@admin_required
async def token_store_delete_user(request: Request):
    """
    Remove all token store entries for a user.

    DELETE /api/admin/token-store/user/{user_sub}

    Returns:
        {"removed": count}
    """
    try:
        user_sub = request.path_params.get("user_sub", "").strip()
        if not user_sub:
            return JSONResponse(
                {"error": "invalid_input", "message": "user_sub is required"},
                status_code=400,
            )

        store = get_user_token_store()
        count = store.remove_by_user(user_sub)
        return JSONResponse({"removed": count})
    except Exception as e:
        logger.error(f"Error deleting token store entries: {e}", exc_info=True)
        return JSONResponse(
            {"error": "server_error", "message": "Failed to delete token store entries"},
            status_code=500,
        )


@admin_required
async def force_logout_user(request: Request):
    """POST /api/admin/users/force-logout — admin-initiated revocation.

    Body: one of
      {"email": "user@example.com"}
      {"sub":   "00u..."}

    Returns the GlobalLogoutHandler summary.
    """
    try:
        body = await request.json()
    except Exception:
        return JSONResponse(
            {"error": "invalid_input", "message": "Request body must be JSON."},
            status_code=400,
        )

    email = (body.get("email") or "").strip()
    sub = (body.get("sub") or "").strip()

    if bool(email) == bool(sub):
        return JSONResponse(
            {
                "error": "invalid_input",
                "message": "Provide exactly one of 'email' or 'sub'.",
            },
            status_code=400,
        )

    admin_user = getattr(request.state, "admin_user", "admin")
    admin_token = extract_admin_token(request)
    correlation_id = uuid.uuid4().hex

    resolved_sub = sub
    resolved_email: Optional[str] = email or None

    if email:
        try:
            okta_client = OktaAPIClient()
            user = await okta_client.get_user_by_login(email, token=admin_token)
            resolved_sub = user["id"]
            resolved_email = user.get("profile", {}).get("email", email)
        except OktaAdminNotFoundError:
            return JSONResponse(
                {"error": "user_not_found", "message": f"No Okta user for '{email}'."},
                status_code=404,
            )
        except OktaAdminForbiddenError as exc:
            return JSONResponse(
                {"error": "forbidden", "message": str(exc)},
                status_code=403,
            )
        except OktaAdminAuthError as exc:
            return JSONResponse(
                {"error": "unauthorized", "message": str(exc)},
                status_code=401,
            )

    try:
        summary = await GlobalLogoutHandler().revoke_user(resolved_sub, correlation_id)
    except Exception as exc:
        logger.exception("Admin force-logout failed for sub=%s", resolved_sub)
        return JSONResponse(
            {"error": "server_error", "message": f"{type(exc).__name__}: {exc}"},
            status_code=500,
        )

    await emit_audit_event(
        AuditEventType.ADMIN_FORCE_LOGOUT,
        severity=AuditSeverity.INFO,
        details={
            "actor": admin_user,
            "target_sub": resolved_sub,
            "target_email": resolved_email,
            "correlation_id": correlation_id,
            "tokens_revoked": summary["tokens_revoked"],
            "cache_swept": summary["cache_swept"],
            "sessions_terminated": summary["sessions_terminated"],
            "sessions_failed": summary["sessions_failed"],
        },
    )

    return JSONResponse(summary, status_code=200)


# ============================================================================
# Resource Isolation Status
# ============================================================================


@admin_required
async def get_resource_isolation_status(request: Request):
    """
    GET /api/admin/resources/isolation-status

    Returns a report of all resolved resources and their agent-scoped isolation keys.
    Useful for verifying that multi-agent resource isolation is correctly configured.
    """
    try:
        from okta_agent_proxy.app import get_resource_syncer
        syncer = get_resource_syncer()
        if not syncer:
            return JSONResponse(
                {"error": "syncer_not_available", "message": "OktaConnectionSyncer is not configured"},
                status_code=503,
            )

        all_resources = syncer.get_all_resolved_resources_raw()
        isolation_report = []
        for key, resource in all_resources.items():
            isolation_report.append({
                "resource_name": resource.name,
                "agent_id": resource.agent_id,
                "agent_name": resource.agent_name,
                "connection_id": resource.connection_id,
                "isolation_key": resource.isolation_key,
                "scopes": resource.scopes,
                "auth_method": resource.auth_method,
                "enabled": resource.enabled,
            })

        # Group by resource name to find multi-agent resources
        by_resource: dict = {}
        for entry in isolation_report:
            by_resource.setdefault(entry["resource_name"], []).append(entry)

        multi_agent = {name: entries for name, entries in by_resource.items() if len(entries) > 1}

        return JSONResponse({
            "total_resolved_resources": len(isolation_report),
            "resources_with_multiple_agents": len(multi_agent),
            "isolation_entries": isolation_report,
            "multi_agent_resources": multi_agent,
        })
    except Exception as e:
        logger.error(f"Error getting isolation status: {e}", exc_info=True)
        return JSONResponse(
            {"error": "server_error", "message": "Failed to get isolation status"},
            status_code=500,
        )
