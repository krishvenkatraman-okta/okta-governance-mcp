"""
Okta Event Hook receiver — handles real-time AI Agent lifecycle events.

Okta Event Hooks deliver webhook notifications when AI Agent principals
are created, updated, activated, or deactivated. The adapter uses these
to keep its local agent records in sync without polling.

Authentication: Shared key via Authorization header (OKTA_EVENT_HOOK_SECRET).
The payload contains only event metadata (event type, target IDs) — no PII.
The adapter re-fetches full data from Okta via authenticated API calls.

Endpoints (registered WITHOUT @admin_required — shared key auth instead):
  GET  /api/hooks/okta/events  — Okta verification handshake
  POST /api/hooks/okta/events  — Event delivery
"""

import logging
import os
from typing import Optional

from starlette.requests import Request
from starlette.responses import JSONResponse

from okta_agent_proxy.auth.okta_agent_import import OktaAgentImport
from okta_agent_proxy.auth.okta_ai_agent_client import OktaAIAgentClient
from okta_agent_proxy.auth.okta_service_auth import OktaServiceAuth
from okta_agent_proxy.database import get_store

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Lazy singletons (separate from okta_import_routes to avoid coupling)
# ---------------------------------------------------------------------------

_service_auth: Optional[OktaServiceAuth] = None
_client: Optional[OktaAIAgentClient] = None
_importer: Optional[OktaAgentImport] = None


def _get_service_auth() -> OktaServiceAuth:
    global _service_auth
    if _service_auth is None:
        _service_auth = OktaServiceAuth()
    return _service_auth


def _get_client() -> OktaAIAgentClient:
    global _client
    if _client is None:
        _client = OktaAIAgentClient(service_auth=_get_service_auth())
    return _client


def _get_import_service() -> OktaAgentImport:
    global _importer
    if _importer is None:
        _importer = OktaAgentImport(client=_get_client(), store=get_store())
    return _importer


# ---------------------------------------------------------------------------
# Verification (GET — one-time Okta handshake)
# ---------------------------------------------------------------------------

async def okta_event_hook_verify(request: Request):
    """GET /api/hooks/okta/events — Okta verification challenge response.

    When creating an Event Hook, Okta sends a GET with
    x-okta-verification-challenge header. We echo it back as JSON.
    """
    challenge = request.headers.get("x-okta-verification-challenge", "")
    if not challenge:
        return JSONResponse(
            {"error": "missing_challenge"},
            status_code=400,
        )
    return JSONResponse({"verification": challenge})


# ---------------------------------------------------------------------------
# Event Handler (POST)
# ---------------------------------------------------------------------------

async def okta_event_hook_receive(request: Request):
    """POST /api/hooks/okta/events — Receive and process Okta events.

    Validates shared key, parses events, triggers sync for AI Agent targets.
    Returns 200 quickly — Okta expects a fast response.
    """
    # 1. Validate shared key
    auth_header = request.headers.get("authorization", "")
    expected = os.getenv("OKTA_EVENT_HOOK_SECRET", "")
    if not expected:
        logger.error("OKTA_EVENT_HOOK_SECRET not configured — rejecting hook")
        return JSONResponse(
            {"error": "not_configured"},
            status_code=503,
        )
    if auth_header != expected:
        logger.warning("Event hook auth failed — invalid shared key")
        return JSONResponse(
            {"error": "unauthorized"},
            status_code=401,
        )

    # 2. Parse events
    try:
        body = await request.json()
    except Exception:
        return JSONResponse(
            {"error": "invalid_body", "message": "Request body must be valid JSON"},
            status_code=400,
        )

    events = body.get("data", {}).get("events", [])

    # 3. Process each event
    results = []
    for event in events:
        result = await _process_event(event)
        results.append(result)

    # 4. Return 200 quickly (Okta expects fast response)
    return JSONResponse({"status": "received", "processed": len(results)})


# ---------------------------------------------------------------------------
# Event Processing
# ---------------------------------------------------------------------------

async def _process_event(event: dict) -> dict:
    """Process a single Okta event, syncing any AI Agent targets."""
    event_type = event.get("eventType", "")
    logger.info(f"Okta Event Hook: {event_type}")

    # Extract agent IDs from targets
    targets = event.get("target", [])
    agent_ids = []
    for target in targets:
        target_type = target.get("type", "")
        target_id = target.get("id", "")
        if target_id and (
            "ai-agent" in target_type.lower()
            or "ai_agent" in target_type.lower()
        ):
            agent_ids.append(target_id)

    if not agent_ids:
        return {
            "event_type": event_type,
            "action": "skipped",
            "reason": "no AI Agent targets",
        }

    # Sync each affected agent using service app auth (no user token)
    import_service = _get_import_service()
    for agent_id in agent_ids:
        try:
            result = await import_service.sync_agent_from_event(agent_id)
            logger.info(f"Event sync for {agent_id}: {result.message}")
        except Exception as e:
            logger.warning(f"Event sync failed for {agent_id}: {e}")

    return {
        "event_type": event_type,
        "action": "synced",
        "agent_ids": agent_ids,
    }
