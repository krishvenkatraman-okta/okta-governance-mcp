"""
Admin Authentication Module

Validates Okta OAuth access tokens for admin API access.

Two principal types are accepted, both issued by the Okta org authorization
server and validated against the same JWKS:

1. **Human users** — tokens minted by the Admin UI OIDC app via the
   authorization_code flow. These carry `sub` (user id), `email`, and
   optionally `preferred_username` / `name`.
2. **Service apps** — tokens minted by an Okta API Services Integration via
   `client_credentials` + `private_key_jwt`. These carry `cid` (client id)
   with `sub == cid` and no user-identity claims. Intended for unattended
   automation (CI/CD, integration tests). The service app's `cid` must be
   listed in `ADMIN_API_SERVICE_CLIENT_IDS` (comma-separated env) to be
   accepted; an unset/empty env var disables service-app auth entirely.

Audience pinning, baseline scope enforcement, and per-route scope gating are
tracked as follow-up hardening in reports/security-audit.md.
"""

import logging
import os
from typing import Optional, Dict, Any, Set

logger = logging.getLogger(__name__)


class AdminAuthError(Exception):
    """Raised when admin authentication fails"""
    pass


def _load_service_client_allowlist() -> Set[str]:
    """Read ADMIN_API_SERVICE_CLIENT_IDS into a set. Empty/unset disables."""
    raw = os.getenv("ADMIN_API_SERVICE_CLIENT_IDS", "")
    return {cid.strip() for cid in raw.split(",") if cid.strip()}


def _is_service_app_token(claims: Dict[str, Any]) -> bool:
    """Detect service-app tokens (client_credentials) via claim shape.

    Service-app tokens on the Okta org AS have `cid` set, `sub == cid`, and
    no user-identity claims. Human tokens always carry at least one of
    `email` / `preferred_username`.
    """
    if claims.get("email") or claims.get("preferred_username"):
        return False
    cid = claims.get("cid")
    if not cid:
        return False
    return claims.get("sub") == cid


async def verify_okta_token(token: str) -> Optional[Dict[str, Any]]:
    """
    Verify an Okta OAuth access token presented to the admin API.

    Accepts both human tokens (authorization_code from the Admin UI) and
    service-app tokens (client_credentials + private_key_jwt for CI/CD).
    Both token types share the org-AS issuer and JWKS.

    Args:
        token: Okta access token

    Returns:
        Admin payload dict if valid, None if invalid or not allowlisted.
    """
    try:
        # Import here to avoid circular dependency
        from okta_agent_proxy.auth.okta_validator import OktaTokenValidator

        # Get Okta domain from environment
        okta_domain = os.getenv("ADMIN_UI_OKTA_DOMAIN") or os.getenv("OKTA_DOMAIN")
        if not okta_domain:
            logger.error("OKTA_DOMAIN not configured for Admin API token validation")
            return None

        # Admin API uses org issuer (not custom authorization server).
        # Org issuer format: https://{domain}
        # Custom auth server format: https://{domain}/oauth2/{authServerId}
        org_issuer = f"https://{okta_domain.replace('https://', '')}"

        logger.debug(f"Validating admin token with org issuer: {org_issuer}")

        # Create validator instance for org issuer
        validator = OktaTokenValidator(
            issuer=org_issuer,
            okta_domain=okta_domain,
            allowed_audiences=[]  # TODO (security-audit.md): pin to ADMIN_UI_OKTA_CLIENT_ID
        )

        # Validate token (no specific scopes required for admin access today —
        # see reports/security-audit.md for planned group/scope enforcement)
        claims = await validator.validate_token(
            token=token,
            required_scopes=None
        )

        if not claims:
            logger.debug("Token validation returned None")
            return None

        if _is_service_app_token(claims):
            return _build_service_app_payload(claims)

        return _build_user_payload(claims)

    except Exception as e:
        logger.debug(f"Okta token validation failed: {e}")
        return None


def _build_user_payload(claims: Dict[str, Any]) -> Dict[str, Any]:
    """Project user-token claims into the admin payload shape."""
    user_info = {
        "sub": claims.get("sub"),
        "email": claims.get("email") or claims.get("preferred_username"),
        "username": claims.get("email") or claims.get("preferred_username") or claims.get("sub"),
        "name": claims.get("name"),
        "principal_type": "user",
        "role": "admin",  # All authenticated Okta users get admin access (see security-audit.md)
        "token_type": "okta_oauth",
        "exp": claims.get("exp"),
        "iat": claims.get("iat"),
    }
    logger.info(f"Validated Okta user token for: {user_info['username']}")
    return user_info


def _build_service_app_payload(claims: Dict[str, Any]) -> Optional[Dict[str, Any]]:
    """Project service-app claims into the admin payload shape.

    Returns None if the service app's `cid` is not allowlisted via
    ADMIN_API_SERVICE_CLIENT_IDS, so the caller can treat it the same as any
    other rejection.
    """
    cid = claims.get("cid")
    if not cid:
        # Defensive: _is_service_app_token already requires cid, but keep the
        # guard so any future caller that builds a service-app payload
        # directly cannot produce a payload with a None cid.
        logger.debug("Service-app token missing cid claim")
        return None

    allowlist = _load_service_client_allowlist()
    if not allowlist:
        logger.warning(
            "Service-app token rejected: ADMIN_API_SERVICE_CLIENT_IDS is not "
            "configured (cid=%s)",
            cid,
        )
        return None
    if cid not in allowlist:
        logger.warning("Service-app token rejected: cid %s not in allowlist", cid)
        return None

    scp = claims.get("scp") or []
    scopes = scp if isinstance(scp, list) else [s for s in str(scp).split() if s]

    payload = {
        "sub": cid,
        "email": None,
        "username": f"service_app:{cid}",
        "name": None,
        "cid": cid,
        "scopes": scopes,
        "principal_type": "service_app",
        "role": "admin",
        "token_type": "okta_oauth",  # keeps _check_okta_auth() in okta_import_routes happy
        "exp": claims.get("exp"),
        "iat": claims.get("iat"),
    }
    logger.info(f"Validated Okta service-app token for cid={cid}")
    return payload
