"""
Admin API Routes for DCR (Dynamic Client Registration) Management.

Provides endpoints for listing, inspecting, and revoking DCR registrations.
All routes require admin authentication.
"""

import json as _json
import logging
from datetime import datetime, timezone
from starlette.responses import JSONResponse
from starlette.requests import Request

from okta_agent_proxy.admin.middleware import admin_required
from okta_agent_proxy.audit import emit_audit_event, AuditEventType
from okta_agent_proxy.auth.dcr_policy import (
    DEFAULT_REDIRECT_PATTERNS,
    GATEWAY_CONFIG_KEY_REDIRECT_PATTERNS,
)
from okta_agent_proxy.auth.redirect_pattern_validator import (
    validate_redirect_patterns,
    RedirectPatternError,
)
from okta_agent_proxy.database import get_store

logger = logging.getLogger(__name__)


@admin_required
async def list_dcr_registrations(request: Request):
    """
    GET /api/admin/dcr/registrations

    List all DCR registrations with optional status filter and pagination.

    Query params:
        status: Filter by status (active, revoked)
        limit: Max results (default 100)
        offset: Pagination offset (default 0)
    """
    store = get_store()
    status = request.query_params.get("status")
    limit = int(request.query_params.get("limit", "100"))
    offset = int(request.query_params.get("offset", "0"))

    registrations = store.list_dcr_registrations(
        status=status, limit=limit, offset=offset
    )
    return JSONResponse({
        "registrations": registrations,
        "count": len(registrations),
        "limit": limit,
        "offset": offset,
    })


@admin_required
async def get_dcr_registration(request: Request):
    """
    GET /api/admin/dcr/registrations/{client_id}

    Get details for a specific DCR registration.
    """
    store = get_store()
    client_id = request.path_params["client_id"]

    registration = store.get_dcr_registration(client_id)
    if not registration:
        return JSONResponse(
            {"error": "not_found", "message": f"DCR registration '{client_id}' not found"},
            status_code=404,
        )
    return JSONResponse(registration)


@admin_required
async def revoke_dcr_registration(request: Request):
    """
    POST /api/admin/dcr/registrations/{client_id}/revoke

    Revoke a DCR registration: sets status='revoked', disables linked agent,
    and optionally deletes the Okta app.

    Body (optional):
        {"delete_okta_app": true}
    """
    client_id = request.path_params["client_id"]
    username = getattr(request.state, "admin_payload", {}).get("username", "admin")

    try:
        body = await request.json()
    except Exception:
        body = {}

    delete_okta_app = body.get("delete_okta_app", False)

    try:
        from okta_agent_proxy.app import get_dcr_handler
        handler = get_dcr_handler()
        if handler is None:
            return JSONResponse(
                {"error": "not_available", "message": "DCR handler not initialized"},
                status_code=503,
            )

        success, message = await handler.revoke_registration(
            client_id,
            delete_okta_app=delete_okta_app,
            user=username,
        )

        if not success:
            return JSONResponse(
                {"error": "revocation_failed", "message": message},
                status_code=404,
            )

        return JSONResponse({"status": "revoked", "message": message})

    except Exception as e:
        logger.error(f"DCR revocation error: {e}")
        return JSONResponse(
            {"error": "server_error", "message": str(e)},
            status_code=500,
        )


@admin_required
async def unlink_dcr_registration(request: Request):
    """
    POST /api/admin/dcr/registrations/{client_id}/unlink

    Unlink a DCR registration from its linked agent, restoring placeholder
    credentials on the DCR agent record.
    """
    client_id = request.path_params["client_id"]
    username = getattr(request.state, "admin_payload", {}).get("username", "admin")

    try:
        from okta_agent_proxy.app import get_dcr_handler
        handler = get_dcr_handler()
        if handler is None:
            return JSONResponse(
                {"error": "not_available", "message": "DCR handler not initialized"},
                status_code=503,
            )

        success, message = await handler.unlink_agent(client_id, user=username)

        if not success:
            return JSONResponse(
                {"error": "unlink_failed", "message": message},
                status_code=404,
            )

        return JSONResponse({"status": "unlinked", "message": message})

    except Exception as e:
        logger.error(f"DCR unlink error: {e}")
        return JSONResponse(
            {"error": "server_error", "message": str(e)},
            status_code=500,
        )


@admin_required
async def update_dcr_selectable(request: Request):
    """
    PUT /api/admin/agents/{agent_id}/dcr-selectable

    Update the dcr_selectable flag on an agent record.

    Body:
        {"dcr_selectable": true|false}
    """
    agent_id = request.path_params["agent_id"]
    username = getattr(request.state, "admin_payload", {}).get("username", "admin")

    try:
        body = await request.json()
    except Exception:
        return JSONResponse(
            {"error": "invalid_request", "message": "Request body must be JSON"},
            status_code=400,
        )

    if "dcr_selectable" not in body:
        return JSONResponse(
            {"error": "invalid_request", "message": "dcr_selectable field is required"},
            status_code=400,
        )

    store = get_store()
    agent = store.get_agent(agent_id, enabled_only=False)
    if not agent:
        return JSONResponse(
            {"error": "not_found", "message": f"Agent '{agent_id}' not found"},
            status_code=404,
        )

    new_value = bool(body["dcr_selectable"])
    store.update_agent(agent_id, {"dcr_selectable": new_value}, user=username)

    await emit_audit_event(
        AuditEventType.CONFIG_AGENT_UPDATED,
        details={
            "agent_id": agent_id,
            "dcr_selectable": new_value,
            "user": username,
        },
    )

    return JSONResponse({
        "agent_id": agent_id,
        "dcr_selectable": new_value,
    })


@admin_required
async def get_dcr_policy(request: Request):
    """
    GET /api/admin/dcr/policy

    Return current DCR policy settings.
    """
    import os
    return JSONResponse({
        "enabled": os.getenv("DCR_ENABLED", "false").lower() == "true",
        "provision_okta_app": os.getenv("DCR_PROVISION_OKTA_APP", "false").lower() == "true",
        "auto_enable_agent": os.getenv("DCR_AUTO_ENABLE_AGENT", "false").lower() == "true",
        "max_registrations_per_hour": int(os.getenv("DCR_MAX_REGISTRATIONS_PER_HOUR", "10")),
        "require_initial_access_token": os.getenv(
            "DCR_REQUIRE_INITIAL_ACCESS_TOKEN", "false"
        ).lower() == "true",
        "allowed_redirect_patterns": [
            p.strip() for p in os.getenv(
                "DCR_ALLOWED_REDIRECT_PATTERNS",
                "http://localhost:*/callback,http://127.0.0.1:*/callback"
            ).split(",") if p.strip()
        ],
        "allowed_grant_types": [
            g.strip() for g in os.getenv(
                "DCR_ALLOWED_GRANT_TYPES", "authorization_code,refresh_token"
            ).split(",") if g.strip()
        ],
        "default_resource_access": [
            b.strip() for b in os.getenv(
                "DCR_DEFAULT_BACKEND_ACCESS", ""
            ).split(",") if b.strip()
        ],
    })


@admin_required
async def get_dcr_redirect_patterns(request: Request):
    """
    GET /api/admin/dcr/policy/redirect-patterns

    Return current DCR redirect patterns with metadata.
    """
    store = get_store()
    entry = store.get_gateway_config_entry(GATEWAY_CONFIG_KEY_REDIRECT_PATTERNS)

    if entry is not None:
        return JSONResponse({
            "patterns": entry["value"],
            "source": "database",
            "updated_at": entry["updated_at"],
            "updated_by": entry["updated_by"],
        })

    return JSONResponse({
        "patterns": list(DEFAULT_REDIRECT_PATTERNS),
        "source": "default",
        "updated_at": None,
        "updated_by": None,
    })


@admin_required
async def update_dcr_redirect_patterns(request: Request):
    """
    PUT /api/admin/dcr/policy/redirect-patterns

    Update DCR redirect patterns. Validates, persists, invalidates caches,
    and publishes cross-worker invalidation event.
    """
    # Parse body
    try:
        body = await request.json()
    except Exception:
        return JSONResponse(
            {"error": "invalid_request", "message": "Request body must be valid JSON"},
            status_code=400,
        )

    patterns = body.get("patterns")
    if not isinstance(patterns, list):
        return JSONResponse(
            {"error": "invalid_request", "message": "'patterns' must be a list of strings"},
            status_code=400,
        )

    if len(patterns) > 50:
        return JSONResponse(
            {"error": "invalid_request", "message": "At most 50 patterns are allowed"},
            status_code=400,
        )

    # Validate all patterns
    try:
        normalized_patterns = validate_redirect_patterns(patterns)
    except RedirectPatternError as exc:
        return JSONResponse(
            {"error": "invalid_pattern", "message": str(exc), "patterns": patterns},
            status_code=400,
        )

    # Extract request context
    username = getattr(request.state, "admin_payload", {}).get("username", "admin")
    ip_address = request.client.host if request.client else None
    user_agent = request.headers.get("user-agent")

    # Persist
    store = get_store()
    store.set_gateway_config(
        GATEWAY_CONFIG_KEY_REDIRECT_PATTERNS,
        normalized_patterns,
        user=username,
        description="Admin-managed DCR allowed redirect URI patterns",
        ip_address=ip_address,
        user_agent=user_agent,
    )

    # Invalidate local worker's L1 cache immediately
    from okta_agent_proxy.app import get_dcr_policy
    get_dcr_policy().invalidate_pattern_cache()

    # Publish cross-worker invalidation event
    try:
        from okta_agent_proxy.app import get_event_bus
        from okta_agent_proxy.cache.pubsub import CHANNEL_DCR_PATTERNS_INVALIDATE
        payload = _json.dumps({
            "user": username,
            "ts": datetime.now(timezone.utc).isoformat(),
            "pattern_count": len(normalized_patterns),
        })
        await get_event_bus().publish(CHANNEL_DCR_PATTERNS_INVALIDATE, payload)
    except Exception as e:
        logger.warning(f"Failed to publish DCR pattern invalidation event: {e}")

    # Emit audit event
    await emit_audit_event(
        AuditEventType.DCR_REDIRECT_PATTERNS_UPDATED,
        details={
            "user": username,
            "pattern_count": len(normalized_patterns),
            "patterns": normalized_patterns,
            "ip_address": ip_address,
        },
    )

    # Return updated state
    entry = store.get_gateway_config_entry(GATEWAY_CONFIG_KEY_REDIRECT_PATTERNS)
    return JSONResponse({
        "patterns": normalized_patterns,
        "source": "database",
        "updated_at": entry["updated_at"] if entry else None,
        "updated_by": entry["updated_by"] if entry else username,
    })
