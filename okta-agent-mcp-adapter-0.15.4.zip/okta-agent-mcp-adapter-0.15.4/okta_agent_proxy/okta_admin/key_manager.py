"""RSA key pair generation and registration with Okta AI Agents.

Generates RSA key pairs locally and registers public keys via the
Okta Workload Principals API. Private keys are returned to the caller
for encrypted storage — they are NEVER sent to Okta.
"""

import base64
import logging
import uuid

from cryptography.hazmat.primitives.asymmetric import rsa, padding, utils
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric.rsa import (
    RSAPrivateKey,
    RSAPublicKey,
    RSAPrivateNumbers,
    RSAPublicNumbers,
)

from okta_agent_proxy.okta_admin.client import OktaAPIClient

logger = logging.getLogger(__name__)


def _int_to_base64url(n: int) -> str:
    """Encode an integer as unpadded base64url."""
    byte_length = (n.bit_length() + 7) // 8
    raw = n.to_bytes(byte_length, byteorder="big")
    return base64.urlsafe_b64encode(raw).rstrip(b"=").decode("ascii")


def _base64url_to_int(s: str) -> int:
    """Decode an unpadded base64url string to an integer."""
    # Add padding
    padded = s + "=" * (4 - len(s) % 4) if len(s) % 4 else s
    raw = base64.urlsafe_b64decode(padded)
    return int.from_bytes(raw, byteorder="big")


class AgentKeyManager:
    """Generates RSA key pairs and registers public keys with Okta AI Agents."""

    def __init__(self, api_client: OktaAPIClient):
        self.api_client = api_client

    def generate_key_pair(self, key_size: int = 2048) -> tuple[dict, dict]:
        """Generate an RSA key pair and return (public_jwk, private_jwk).

        This is a LOCAL operation — no Okta API call, no token needed.
        """
        private_key = rsa.generate_private_key(
            public_exponent=65537,
            key_size=key_size,
        )

        kid = str(uuid.uuid4())
        priv_numbers = private_key.private_numbers()
        pub_numbers = priv_numbers.public_numbers

        public_jwk = {
            "kty": "RSA",
            "kid": kid,
            "use": "sig",
            "alg": "RS256",
            "n": _int_to_base64url(pub_numbers.n),
            "e": _int_to_base64url(pub_numbers.e),
        }

        private_jwk = {
            "kty": "RSA",
            "kid": kid,
            "use": "sig",
            "alg": "RS256",
            "n": _int_to_base64url(pub_numbers.n),
            "e": _int_to_base64url(pub_numbers.e),
            "d": _int_to_base64url(priv_numbers.d),
            "p": _int_to_base64url(priv_numbers.p),
            "q": _int_to_base64url(priv_numbers.q),
            "dp": _int_to_base64url(priv_numbers.dmp1),
            "dq": _int_to_base64url(priv_numbers.dmq1),
            "qi": _int_to_base64url(priv_numbers.iqmp),
        }

        return public_jwk, private_jwk

    async def register_public_key(
        self, agent_id: str, public_jwk: dict, token: str
    ) -> dict:
        """Register a public JWK with an Okta AI Agent.

        POST /workload-principals/api/v1/ai-agents/{agent_id}/credentials/jwks
        Only the PUBLIC key is sent. Never send private key material.
        """
        response = await self.api_client.post(
            f"/workload-principals/api/v1/ai-agents/{agent_id}/credentials/jwks",
            token,
            json=public_jwk,
        )
        return response.json()

    async def list_agent_keys(self, agent_id: str, token: str) -> list[dict]:
        """List registered public JWKs for an Okta AI Agent.

        GET /workload-principals/api/v1/ai-agents/{agent_id}/credentials/jwks
        Returns the keys array (unwraps {"keys": [...]} if present).
        """
        response = await self.api_client.get(
            f"/workload-principals/api/v1/ai-agents/{agent_id}/credentials/jwks",
            token,
        )
        data = response.json()
        if isinstance(data, dict) and "keys" in data:
            return data["keys"]
        if isinstance(data, list):
            return data
        return []

    async def generate_and_register(
        self, agent_id: str, token: str, key_size: int = 2048
    ) -> tuple[dict, dict]:
        """Generate a key pair, register the public key with Okta, return both.

        The PRIVATE key is returned to the caller for encrypted storage.
        It NEVER goes to Okta.
        """
        public_jwk, private_jwk = self.generate_key_pair(key_size=key_size)
        await self.register_public_key(agent_id, public_jwk, token)
        logger.info(
            "Generated and registered RSA-%d key for agent %s, kid=%s",
            key_size,
            agent_id,
            public_jwk["kid"],
        )
        return public_jwk, private_jwk

    def validate_key_pair(self, public_jwk: dict, private_jwk: dict) -> bool:
        """Validate that a public/private JWK pair is consistent.

        Checks kid match, component match, and sign/verify round-trip.
        This is a LOCAL operation — no token needed.
        """
        # Check kid match
        if public_jwk.get("kid") != private_jwk.get("kid"):
            return False

        # Check public components match
        if public_jwk.get("n") != private_jwk.get("n"):
            return False
        if public_jwk.get("e") != private_jwk.get("e"):
            return False

        # Sign/verify round-trip
        try:
            private_key = self._jwk_to_private_key(private_jwk)
            public_key = self._jwk_to_public_key(public_jwk)

            test_data = b"key-pair-validation-test"
            signature = private_key.sign(
                test_data,
                padding.PKCS1v15(),
                hashes.SHA256(),
            )
            public_key.verify(
                signature,
                test_data,
                padding.PKCS1v15(),
                hashes.SHA256(),
            )
            return True
        except Exception:
            return False

    @staticmethod
    def _jwk_to_private_key(jwk: dict) -> RSAPrivateKey:
        """Reconstruct an RSA private key from a JWK dict."""
        pub_numbers = RSAPublicNumbers(
            e=_base64url_to_int(jwk["e"]),
            n=_base64url_to_int(jwk["n"]),
        )
        priv_numbers = RSAPrivateNumbers(
            p=_base64url_to_int(jwk["p"]),
            q=_base64url_to_int(jwk["q"]),
            d=_base64url_to_int(jwk["d"]),
            dmp1=_base64url_to_int(jwk["dp"]),
            dmq1=_base64url_to_int(jwk["dq"]),
            iqmp=_base64url_to_int(jwk["qi"]),
            public_numbers=pub_numbers,
        )
        return priv_numbers.private_key()

    @staticmethod
    def _jwk_to_public_key(jwk: dict) -> RSAPublicKey:
        """Reconstruct an RSA public key from a JWK dict."""
        pub_numbers = RSAPublicNumbers(
            e=_base64url_to_int(jwk["e"]),
            n=_base64url_to_int(jwk["n"]),
        )
        return pub_numbers.public_key()
