"""Stateless HTTP client for the Okta Management API.

This client forwards an admin user's Bearer token to Okta.
It never stores, caches, or generates tokens itself.
"""

import os
import logging

import httpx

from okta_agent_proxy.okta_admin.exceptions import (
    OktaAdminAuthError,
    OktaAdminForbiddenError,
    OktaAdminNotFoundError,
    OktaAdminRateLimitError,
    OktaAdminAPIError,
)

logger = logging.getLogger(__name__)


class OktaAPIClient:
    """Stateless proxy client for the Okta Management API.

    Receives a Bearer token from the caller and forwards it to Okta.
    Does NOT cache tokens or manage credentials.
    """

    def __init__(self, okta_domain: str | None = None):
        domain = (okta_domain or os.environ.get("OKTA_DOMAIN", "")).rstrip("/")
        if not domain:
            raise ValueError("okta_domain must be provided or set via OKTA_DOMAIN env var")
        if not domain.startswith("https://") and not domain.startswith("http://"):
            domain = f"https://{domain}"
        self.okta_domain = domain
        self._client = httpx.AsyncClient(timeout=30.0)

    async def _request(
        self,
        method: str,
        path: str,
        token: str,
        json: dict | None = None,
    ) -> httpx.Response:
        """Make an authenticated request to the Okta Management API."""
        url = f"{self.okta_domain}{path}"
        headers = {
            "Authorization": f"Bearer {token}",
            "Content-Type": "application/json",
            "Accept": "application/json",
        }

        logger.debug("Okta API %s %s", method, path)

        response = await self._client.request(
            method=method,
            url=url,
            headers=headers,
            json=json,
        )

        if response.status_code == 401:
            raise OktaAdminAuthError(
                "Admin token expired or invalid. Please re-authenticate."
            )

        if response.status_code == 403:
            raise OktaAdminForbiddenError(
                "Insufficient Okta permissions. Ensure your admin role "
                "has the required scopes (okta.apps.manage, okta.aiAgents.manage)."
            )

        if response.status_code == 404:
            raise OktaAdminNotFoundError(f"Resource not found: {path}")

        if response.status_code == 429:
            logger.warning("Okta rate limit hit for %s %s", method, path)
            raise OktaAdminRateLimitError("Okta API rate limit exceeded. Please retry later.")

        if response.status_code >= 400:
            try:
                body = response.json()
            except Exception:
                body = {}
            error_desc = body.get("errorSummary", body.get("error_description", response.text))
            raise OktaAdminAPIError(
                message=f"Okta API error {response.status_code}: {error_desc}",
                status_code=response.status_code,
                error_description=error_desc,
            )

        return response

    async def get(self, path: str, token: str) -> httpx.Response:
        """GET request to the Okta Management API."""
        return await self._request("GET", path, token)

    async def get_user_by_login(self, login: str, token: str) -> dict:
        """Look up an Okta user by login (email) or by Okta user id.

        Returns the raw Okta user object. Caller extracts `.id` as the
        immutable sub used by GlobalLogoutHandler.

        Requires the caller's access token to carry the `okta.users.read`
        scope. Raises OktaAdminForbiddenError (403) if missing, or
        OktaAdminNotFoundError (404) if the user does not exist.
        """
        response = await self._request(
            method="GET",
            path=f"/api/v1/users/{login}",
            token=token,
        )
        response.raise_for_status()
        return response.json()

    async def post(self, path: str, token: str, json: dict | None = None) -> httpx.Response:
        """POST request to the Okta Management API."""
        return await self._request("POST", path, token, json=json)

    async def close(self) -> None:
        """Close the underlying httpx client."""
        await self._client.aclose()
