"""Credential automation orchestrator.

Combines the secret fetcher, key manager, and config store to provide
high-level credential provisioning operations for the Admin API.
"""

import json
import logging

from okta_agent_proxy.okta_admin.client import OktaAPIClient
from okta_agent_proxy.okta_admin.exceptions import (
    OktaAdminAPIError,
    OktaAdminAuthError,
    OktaAdminForbiddenError,
)
from okta_agent_proxy.okta_admin.key_manager import AgentKeyManager
from okta_agent_proxy.okta_admin.secret_fetcher import ClientSecretFetcher

logger = logging.getLogger(__name__)


class CredentialAutomationService:
    """Orchestrates credential fetch/generate and persists results to the config store."""

    def __init__(self, api_client: OktaAPIClient, config_store):
        self.secret_fetcher = ClientSecretFetcher(api_client)
        self.key_manager = AgentKeyManager(api_client)
        self.config_store = config_store

    def _get_agent_or_none(self, agent_id: str) -> dict | None:
        return self.config_store.get_agent(agent_id, enabled_only=False)

    async def fetch_client_secret(self, agent_id: str, admin_token: str) -> dict:
        """Fetch or generate a client secret from Okta and store it encrypted."""
        agent = self._get_agent_or_none(agent_id)
        if not agent:
            return {"status": "error", "message": f"Agent '{agent_id}' not found"}

        okta_agent_id = agent.get("okta_ai_agent_id")
        if not okta_agent_id:
            return {
                "status": "error",
                "message": "Agent has no linked Okta AI Agent ID. Configure okta_agent_id first.",
            }

        app_id = await self.secret_fetcher.get_agent_linked_app_id(
            okta_agent_id, admin_token
        )

        secret_value, source = await self.secret_fetcher.fetch_or_generate_secret(
            app_id, admin_token
        )

        # Store encrypts internally via update_agent
        self.config_store.update_agent(
            agent_id, {"client_secret": secret_value}, user="credential-automation"
        )

        logger.info(
            "Client secret %s for agent %s (app %s)",
            source,
            agent_id,
            app_id,
        )

        return {"status": "success", "source": source, "app_id": app_id}

    async def generate_key_pair(self, agent_id: str, admin_token: str) -> dict:
        """Generate an RSA key pair, register public key with Okta, store private key."""
        agent = self._get_agent_or_none(agent_id)
        if not agent:
            return {"status": "error", "message": f"Agent '{agent_id}' not found"}

        okta_agent_id = agent.get("okta_ai_agent_id")
        if not okta_agent_id:
            return {
                "status": "error",
                "message": "Agent has no linked Okta AI Agent ID. Configure okta_agent_id first.",
            }

        public_jwk, private_jwk = await self.key_manager.generate_and_register(
            okta_agent_id, admin_token
        )

        # Store encrypts internally via update_agent
        self.config_store.update_agent(
            agent_id,
            {"private_key": json.dumps(private_jwk)},
            user="credential-automation",
        )

        logger.info(
            "Key pair generated for agent %s, kid=%s",
            agent_id,
            public_jwk["kid"],
        )

        return {
            "status": "success",
            "kid": public_jwk["kid"],
            "agent_id": agent_id,
        }

    async def get_credential_status(self, agent_id: str, admin_token: str) -> dict:
        """Check credential presence for an agent (never returns actual secrets)."""
        agent = self._get_agent_or_none(agent_id)
        if not agent:
            return {"status": "error", "message": f"Agent '{agent_id}' not found"}

        has_secret = bool(agent.get("client_secret"))
        has_key = bool(agent.get("private_key"))
        okta_agent_id = agent.get("okta_ai_agent_id")

        registered_keys = []
        if okta_agent_id:
            try:
                keys = await self.key_manager.list_agent_keys(
                    okta_agent_id, admin_token
                )
                registered_keys = [
                    {"kid": k.get("kid"), "alg": k.get("alg")} for k in keys
                ]
            except OktaAdminForbiddenError:
                logger.debug(
                    "Token lacks scope to list keys for agent %s", agent_id
                )
            except (OktaAdminAuthError, OktaAdminAPIError) as e:
                logger.debug("Could not list keys for agent %s: %s", agent_id, e)

        return {
            "has_client_secret": has_secret,
            "has_private_key": has_key,
            "registered_keys": registered_keys,
            "okta_agent_id": okta_agent_id,
        }
