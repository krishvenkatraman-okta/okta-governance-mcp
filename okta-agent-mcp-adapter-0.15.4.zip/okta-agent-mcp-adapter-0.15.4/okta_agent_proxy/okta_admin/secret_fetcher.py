"""Client secret fetcher for Okta apps via the Management API.

Retrieves or generates client secrets using the admin user's access token.
Never stores or caches secrets — pure pass-through to Okta.
"""

import logging

from okta_agent_proxy.okta_admin.client import OktaAPIClient
from okta_agent_proxy.okta_admin.exceptions import (
    OktaAdminAPIError,
    OktaAdminNotFoundError,
)

logger = logging.getLogger(__name__)

OKTA_MAX_SECRETS = 2


class ClientSecretFetcher:
    """Fetches or generates client secrets from Okta apps."""

    def __init__(self, api_client: OktaAPIClient):
        self.api_client = api_client

    async def list_app_secrets(self, app_id: str, token: str) -> list[dict]:
        """List active client secrets for an Okta app.

        GET /api/v1/apps/{app_id}/credentials/secrets
        Returns only ACTIVE secrets.
        """
        response = await self.api_client.get(
            f"/api/v1/apps/{app_id}/credentials/secrets", token
        )
        secrets = response.json()
        return [s for s in secrets if s.get("status") == "ACTIVE"]

    async def generate_app_secret(self, app_id: str, token: str) -> dict:
        """Generate a new client secret for an Okta app.

        POST /api/v1/apps/{app_id}/credentials/secrets
        Okta auto-generates the secret value.
        """
        try:
            response = await self.api_client.post(
                f"/api/v1/apps/{app_id}/credentials/secrets", token, json={}
            )
        except OktaAdminAPIError as e:
            if e.status_code == 400:
                raise OktaAdminAPIError(
                    message=(
                        f"App already has the maximum of {OKTA_MAX_SECRETS} secrets. "
                        "Deactivate one in the Okta Admin Console before generating a new secret."
                    ),
                    status_code=e.status_code,
                    error_description=e.error_description,
                )
            raise
        logger.info("Generated new client secret for app %s", app_id)
        return response.json()

    async def fetch_or_generate_secret(
        self, app_id: str, token: str
    ) -> tuple[str, str]:
        """Return (client_secret, source) for an app.

        Tries existing active secrets first; generates if none exist.
        source is "fetched_existing" or "generated_new".
        """
        active_secrets = await self.list_app_secrets(app_id, token)
        if active_secrets:
            # Pick the most recently created active secret
            most_recent = sorted(
                active_secrets, key=lambda s: s.get("created", ""), reverse=True
            )[0]
            logger.info(
                "Using existing active secret for app %s (id=%s)",
                app_id,
                most_recent.get("id", "unknown"),
            )
            return most_recent["client_secret"], "fetched_existing"

        new_secret = await self.generate_app_secret(app_id, token)
        return new_secret["client_secret"], "generated_new"

    async def get_app_by_name(self, app_name: str, token: str) -> dict | None:
        """Resolve an app name to an app object.

        GET /api/v1/apps?q={app_name}
        Returns the first matching app or None.
        """
        response = await self.api_client.get(
            f"/api/v1/apps?q={app_name}", token
        )
        apps = response.json()
        if apps:
            return apps[0]
        return None

    async def get_agent_linked_app_id(self, agent_id: str, token: str) -> str:
        """Get the linked OAuth app ID for an Okta AI Agent.

        GET /workload-principals/api/v1/ai-agents/{agent_id}
        Extracts client_id from credentials.oauthClient or falls back to appId.
        """
        response = await self.api_client.get(
            f"/workload-principals/api/v1/ai-agents/{agent_id}", token
        )
        agent_data = response.json()

        # Try credentials.oauthClient.client_id first
        credentials = agent_data.get("credentials", {})
        oauth_client = credentials.get("oauthClient", {})
        client_id = oauth_client.get("client_id")
        if client_id:
            return client_id

        # Fall back to appId
        app_id = agent_data.get("appId")
        if app_id:
            return app_id

        raise OktaAdminAPIError(
            message=f"AI Agent {agent_id} has no linked OAuth app",
            status_code=200,
            error_description="No credentials.oauthClient.client_id or appId in agent response",
        )
