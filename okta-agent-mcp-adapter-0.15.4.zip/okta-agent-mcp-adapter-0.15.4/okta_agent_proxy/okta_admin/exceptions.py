"""Exception hierarchy for Okta Management API operations."""


class OktaAdminError(Exception):
    """Base exception for Okta Admin API errors."""

    def __init__(self, message: str):
        self.message = message
        super().__init__(message)


class OktaAdminAuthError(OktaAdminError):
    """Raised on 401 responses — admin token expired or invalid."""
    pass


class OktaAdminForbiddenError(OktaAdminError):
    """Raised on 403 responses — insufficient scopes or admin role."""
    pass


class OktaAdminRateLimitError(OktaAdminError):
    """Raised on 429 responses — Okta rate limit exceeded."""
    pass


class OktaAdminNotFoundError(OktaAdminError):
    """Raised on 404 responses — requested resource not found."""
    pass


class OktaAdminAPIError(OktaAdminError):
    """Raised on other 4xx/5xx API errors."""

    def __init__(self, message: str, status_code: int, error_description: str = ""):
        self.status_code = status_code
        self.error_description = error_description
        super().__init__(message)
