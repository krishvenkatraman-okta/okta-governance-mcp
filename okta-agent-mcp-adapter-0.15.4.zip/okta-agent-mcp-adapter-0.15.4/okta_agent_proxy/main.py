"""
Okta Agent Proxy - Main entry point

A transparent proxy gateway for Model Context Protocol servers with Okta authentication.
Supports multiple resource MCP servers and path-based routing.

The gateway acts as a transparent proxy, forwarding all MCP protocol requests
to the resource while handling authentication and session management.

Usage:
    # HTTP transport (uses production ASGI app from app.py)
    python -m okta_agent_proxy.main http

    # stdio transport (uses FastMCP for pipe communication)
    python -m okta_agent_proxy.main stdio
"""

import os
import logging
import sys
from typing import Optional, Dict, Any

from fastmcp import FastMCP

from okta_agent_proxy.config import load_config
from okta_agent_proxy.middleware import setup_logging

# Setup logging
setup_logging()
logger = logging.getLogger(__name__)

# Load configuration
config = load_config()

# Create FastMCP server for stdio transport only
# HTTP transport uses the production ASGI app from app.py
mcp = FastMCP(name=config.name)


# ============================================================================
# MCP Protocol Utilities (stdio mode only)
# ============================================================================

def get_gateway_icon():
    """
    Get gateway icon for MCP initialization response.
    Per MCP spec 2025-11-25: icons property provides visual identifiers.
    Returns an SVG data URI for the Okta Agent Proxy icon.
    """
    return {
        "src": "data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 100 100'%3E%3Ccircle cx='50' cy='50' r='45' fill='%23003366'/%3E%3Ctext x='50' y='60' text-anchor='middle' font-size='40' fill='white' font-family='Arial'%3EOA%3C/text%3E%3C/svg%3E",
        "mimeType": "image/svg+xml",
        "theme": "light"
    }


# ============================================================================
# OAuth Discovery Resources (stdio mode only)
# ============================================================================

@mcp.resource(uri="mcp://oauth-protected-resource")
def protected_resource_metadata_resource() -> str:
    """
    Protected Resource Metadata endpoint (RFC9728).

    Clients discover this endpoint to learn:
    1. Where the authorization server is (Okta)
    2. What documentation is available
    3. Metadata about the protected resource

    This resource is accessible at: /.well-known/oauth-protected-resource
    """
    import json

    metadata = {
        "authorization_servers": [config.gateway.gateway_base_url],
        "scopes_supported": ["openid", "offline_access"],
        "bearer_methods_supported": ["header"]
    }
    return json.dumps(metadata, indent=2)


# ============================================================================
# Resource Tools (stdio mode only)
# ============================================================================

@mcp.tool(name="resource_tools_list")
async def resource_tools_list() -> Dict[str, Any]:
    """
    List available resource tools and services.

    PROTECTED BY OAUTH: Requires valid Okta bearer token.
    Clients must authenticate via mcp://oauth-protected-resource endpoint first.
    """
    logger.info("resource_tools_list called")

    # Return info about available resources
    return {
        "status": "success",
        "resources": {
            "employees": {
                "url": "https://okta-sample-employee-mcp-server.onrender.com/mcp",
                "description": "Employee information database",
                "available_tools": [
                    "list_employees",
                    "search_employees"
                ]
            }
        },
        "note": "Resource tools are protected by OAuth. Your bearer token is automatically included in requests."
    }


@mcp.tool(name="dcr_discovery")
async def dcr_discovery(agent: Optional[str] = None) -> Dict[str, Any]:
    """
    Dynamic Client Registration (DCR) discovery endpoint.

    Returns protected resource metadata with client registration info for the specified agent.
    If no agent is specified, returns available agents.

    Args:
        agent: Agent name (e.g., "claude-code", "cursor") - optional

    Returns:
        Protected resource metadata with agent client registration details
    """
    from okta_agent_proxy.database import get_config_store

    store = get_config_store()

    if not agent:
        # Return list of available agents
        available_agents = {}
        for agent_data in store.get_all_agents(enabled_only=False):
            agent_id = agent_data.get("agent_id")
            available_agents[agent_id] = {
                "agent_id": agent_id,
                "client_id": agent_data.get("client_id"),
                "enabled": agent_data.get("enabled", True),
                "description": f"Agent: {agent_id}"
            }
        return {
            "status": "available_agents",
            "agents": available_agents
        }

    # Return metadata for specific agent
    agent_config = None
    for agent_data in store.get_all_agents(enabled_only=False):
        if agent_data.get("agent_id") == agent:
            agent_config = agent_data
            break

    if not agent_config:
        return {
            "error": "agent_not_found",
            "message": f"Agent '{agent}' not found in configuration",
            "available_agents": [a.get("agent_id") for a in store.get_all_agents(enabled_only=False)]
        }

    # Add agent-specific client registration info
    metadata = {
        "authorization_servers": [config.gateway.gateway_base_url],
        "scopes_supported": ["openid", "offline_access"],
        "bearer_methods_supported": ["header"],
        "client_registration": {
            "agent_name": agent,
            "agent_id": agent_config.get("agent_id"),
            "client_id": agent_config.get("client_id"),
            "client_name": f"Okta Agent Proxy - {agent}",
            "redirect_uris": ["http://localhost:*/callback", "http://127.0.0.1:*/callback"],
            "response_types": ["code", "id_token", "token"],
            "grant_types": ["authorization_code", "refresh_token"],
            "token_endpoint_auth_method": "client_secret_basic",
            "scopes_requested": ["openid", "profile", "email", "offline_access"]
        }
    }

    return {
        "status": "success",
        "agent": agent,
        "protected_resource_metadata": metadata
    }


# ============================================================================
# Entry Point
# ============================================================================

def run(
    host: str = None,
    port: int = None,
    transport: str = "http"
) -> None:
    """
    Run the MCP gateway server.

    Args:
        host: Server host (default from config)
        port: Server port (default from config)
        transport: Transport type ("http" or "stdio")
    """
    gateway_settings = config.gateway

    if host is None:
        host = os.getenv("GATEWAY_HOST", gateway_settings.gateway_base_url.split("://")[1].split(":")[0] if "://" in gateway_settings.gateway_base_url else "0.0.0.0")

    if port is None:
        port = int(os.getenv("GATEWAY_PORT", gateway_settings.gateway_port))

    logger.info("=" * 80)
    logger.info(f"{config.name} v{config.version}")
    logger.info("=" * 80)
    logger.info(f"Gateway listening on port {port}")
    logger.info(f"Listening on {host}:{port}")
    logger.info(f"Transport: {transport}")
    logger.info("=" * 80)

    if transport == "http":
        # Use production ASGI app from app.py
        # This eliminates ~900 lines of duplication
        import uvicorn
        from okta_agent_proxy.app import app

        logger.info("Starting HTTP server (using production ASGI app)")
        logger.info("All HTTP endpoints, OAuth flows, and MCP proxying handled by app.py")

        # Suppress noisy access logs from load balancer probes and OAuth
        # discovery polling. Must use a named filter class + log_config dict
        # because uvicorn.run() reconfigures loggers on startup, wiping any
        # pre-attached filters.
        _NOISY_PATHS = (
            "/health",
            "/.well-known/oauth-protected-resource",
        )

        class HealthCheckFilter(logging.Filter):
            def filter(self, record: logging.LogRecord) -> bool:
                msg = record.getMessage()
                return not any(p in msg for p in _NOISY_PATHS)

        # Register the filter class so uvicorn's dictConfig can reference it
        _health_filter_class = HealthCheckFilter

        uvicorn.run(
            app,
            host=host,
            port=port,
            log_config={
                "version": 1,
                "disable_existing_loggers": False,
                "filters": {
                    "health_check": {
                        "()": lambda: _health_filter_class(),
                    },
                },
                "formatters": {
                    "default": {
                        "fmt": "%(levelprefix)s %(message)s",
                        "use_colors": None,
                    },
                    "access": {
                        "fmt": '%(levelprefix)s %(client_addr)s - "%(request_line)s" %(status_code)s',
                        "use_colors": None,
                    },
                },
                "handlers": {
                    "default": {
                        "formatter": "default",
                        "class": "logging.StreamHandler",
                        "stream": "ext://sys.stderr",
                    },
                    "access": {
                        "formatter": "access",
                        "class": "logging.StreamHandler",
                        "stream": "ext://sys.stdout",
                        "filters": ["health_check"],
                    },
                },
                "loggers": {
                    "uvicorn": {"handlers": ["default"], "level": "INFO", "propagate": False},
                    "uvicorn.error": {"level": "INFO"},
                    "uvicorn.access": {"handlers": ["access"], "level": "INFO", "propagate": False},
                },
            },
        )
    else:
        # Use FastMCP for stdio transport (pipe communication)
        logger.info("Starting stdio transport (using FastMCP)")
        logger.info("MCP tools and resources available for pipe-based clients")

        mcp.run(
            transport=transport,
            host=host,
            port=port
        )


if __name__ == "__main__":
    # CLI entry point: python -m okta_agent_proxy.main [http|stdio]
    transport = "http" if "http" in sys.argv else "stdio"
    run(transport=transport)
