"""
Encryption utilities for sensitive configuration data.

Uses AES-256-GCM (Galois/Counter Mode) for authenticated encryption.
Supports key rotation via key_id tracking.

Security Notes:
- AES-256-GCM provides both confidentiality and authenticity
- Random 12-byte IV per encryption operation (NIST recommended)
- 16-byte authentication tag prevents tampering
- Key must be 32 bytes (256 bits) for AES-256
"""

import os
import base64
import logging
from typing import Tuple, Optional
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC
from cryptography.hazmat.backends import default_backend

logger = logging.getLogger(__name__)


class EncryptionError(Exception):
    """Raised when encryption/decryption operations fail."""
    pass


class EncryptionService:
    """
    Handles encryption and decryption of sensitive configuration data.

    Key Management:
    - Primary encryption key from environment: ENCRYPTION_KEY (base64-encoded 32-byte key)
    - Alternatively, derive from ENCRYPTION_PASSWORD using PBKDF2
    - key_id tracks which key encrypted the data (supports rotation)

    Usage:
        >>> service = EncryptionService()
        >>> ciphertext, iv, tag = service.encrypt("secret_value")
        >>> plaintext = service.decrypt(ciphertext, iv, tag)
    """

    def __init__(self, key: Optional[bytes] = None, key_id: str = "primary"):
        """
        Initialize encryption service.

        Args:
            key: 32-byte encryption key (if None, loads from environment)
            key_id: Identifier for this key (for rotation support)

        Raises:
            ValueError: If key is not 32 bytes
            EncryptionError: If no key source is available in environment
        """
        self.key_id = key_id

        if key is None:
            key = self._load_key_from_env()

        if len(key) != 32:
            raise ValueError("Encryption key must be exactly 32 bytes for AES-256")

        self.aesgcm = AESGCM(key)
        logger.info(f"Encryption service initialized with key_id: {self.key_id}")

    def _load_key_from_env(self) -> bytes:
        """
        Load encryption key from environment variables.

        Priority:
        1. ENCRYPTION_KEY (base64-encoded 32-byte key) - preferred for production
        2. ENCRYPTION_PASSWORD (derive key using PBKDF2) - convenient for development

        Returns:
            32-byte encryption key

        Raises:
            EncryptionError: If no key source is available
        """
        # Option 1: Direct key (production)
        key_b64 = os.getenv("ENCRYPTION_KEY")
        if key_b64:
            try:
                key = base64.b64decode(key_b64)
                if len(key) == 32:
                    logger.info("Loaded encryption key from ENCRYPTION_KEY")
                    return key
                else:
                    raise ValueError(f"ENCRYPTION_KEY must be 32 bytes, got {len(key)}")
            except Exception as e:
                raise EncryptionError(f"Invalid ENCRYPTION_KEY: {e}")

        # Option 2: Derive from password (development/testing)
        password = os.getenv("ENCRYPTION_PASSWORD")
        if password:
            salt = os.getenv("ENCRYPTION_SALT", "okta-mcp-gateway-salt").encode()
            iterations = int(os.getenv("ENCRYPTION_KDF_ITERATIONS", "100000"))

            kdf = PBKDF2HMAC(
                algorithm=hashes.SHA256(),
                length=32,
                salt=salt,
                iterations=iterations,
                backend=default_backend()
            )
            key = kdf.derive(password.encode())
            logger.info(f"Derived encryption key from ENCRYPTION_PASSWORD (PBKDF2, {iterations} iterations)")
            logger.warning("ENCRYPTION_PASSWORD is not recommended for production - use ENCRYPTION_KEY instead")
            return key

        # No key source available
        raise EncryptionError(
            "No encryption key configured. Set either:\n"
            "  - ENCRYPTION_KEY (base64-encoded 32-byte key), or\n"
            "  - ENCRYPTION_PASSWORD (will derive key using PBKDF2)\n"
            "Generate a key with: python ops_scripts/generate_encryption_key.py"
        )

    def encrypt(self, plaintext: str) -> Tuple[bytes, bytes, bytes]:
        """
        Encrypt plaintext using AES-256-GCM.

        Args:
            plaintext: String to encrypt

        Returns:
            Tuple of (ciphertext, iv, tag)
            - ciphertext: Encrypted data
            - iv: 12-byte initialization vector
            - tag: 16-byte authentication tag

        Raises:
            EncryptionError: If encryption fails
        """
        if not plaintext:
            raise ValueError("Cannot encrypt empty plaintext")

        try:
            # Generate random 12-byte IV (recommended for GCM)
            iv = os.urandom(12)

            # Encrypt with associated data (key_id for rotation support)
            associated_data = self.key_id.encode()
            ciphertext_and_tag = self.aesgcm.encrypt(iv, plaintext.encode('utf-8'), associated_data)

            # GCM returns ciphertext + 16-byte tag
            ciphertext = ciphertext_and_tag[:-16]
            tag = ciphertext_and_tag[-16:]

            logger.debug(f"Encrypted {len(plaintext)} bytes → {len(ciphertext)} bytes (key_id: {self.key_id})")
            return ciphertext, iv, tag

        except Exception as e:
            logger.error(f"Encryption failed: {e}")
            raise EncryptionError(f"Encryption failed: {e}")

    def decrypt(self, ciphertext: bytes, iv: bytes, tag: bytes) -> str:
        """
        Decrypt ciphertext using AES-256-GCM.

        Args:
            ciphertext: Encrypted data
            iv: Initialization vector (12 bytes)
            tag: Authentication tag (16 bytes)

        Returns:
            Decrypted plaintext string

        Raises:
            EncryptionError: If decryption fails or authentication fails
        """
        if not ciphertext or not iv or not tag:
            raise ValueError("Ciphertext, IV, and tag must all be provided")

        try:
            # Reconstruct ciphertext + tag
            ciphertext_and_tag = ciphertext + tag

            # Decrypt with associated data
            associated_data = self.key_id.encode()
            plaintext_bytes = self.aesgcm.decrypt(iv, ciphertext_and_tag, associated_data)

            plaintext = plaintext_bytes.decode('utf-8')
            logger.debug(f"Decrypted {len(ciphertext)} bytes → {len(plaintext)} bytes (key_id: {self.key_id})")
            return plaintext

        except Exception as e:
            logger.error(f"Decryption failed: {e}")
            raise EncryptionError(
                f"Decryption failed (key may be incorrect or data corrupted): {e}"
            )

    @staticmethod
    def generate_key() -> str:
        """
        Generate a new random 32-byte key for AES-256.

        Returns:
            Base64-encoded key suitable for ENCRYPTION_KEY environment variable

        Usage:
            >>> key = EncryptionService.generate_key()
            >>> print(f"ENCRYPTION_KEY={key}")
        """
        key = os.urandom(32)
        key_b64 = base64.b64encode(key).decode('ascii')
        return key_b64


# Global encryption service instance (lazy-loaded)
_encryption_service: Optional[EncryptionService] = None


def get_encryption_service() -> EncryptionService:
    """
    Get or create the global encryption service instance.

    This function implements the singleton pattern for the encryption service.
    The service is created once and reused for all encryption/decryption operations.

    Returns:
        EncryptionService instance

    Raises:
        EncryptionError: If encryption key is not configured

    Note:
        In production, ensure ENCRYPTION_KEY is set before calling this function.
        In testing, set ENCRYPTION_PASSWORD or provide a test key.
    """
    global _encryption_service
    if _encryption_service is None:
        _encryption_service = EncryptionService()
    return _encryption_service


def encrypt_field(plaintext: str) -> Tuple[bytes, bytes, bytes]:
    """
    Convenience function to encrypt a field using the global encryption service.

    Args:
        plaintext: String to encrypt

    Returns:
        Tuple of (ciphertext, iv, tag)

    Usage:
        >>> ciphertext, iv, tag = encrypt_field("my_secret")
    """
    service = get_encryption_service()
    return service.encrypt(plaintext)


def decrypt_field(ciphertext: bytes, iv: bytes, tag: bytes) -> str:
    """
    Convenience function to decrypt a field using the global encryption service.

    Args:
        ciphertext: Encrypted data
        iv: Initialization vector
        tag: Authentication tag

    Returns:
        Decrypted plaintext string

    Usage:
        >>> plaintext = decrypt_field(ciphertext, iv, tag)
    """
    service = get_encryption_service()
    return service.decrypt(ciphertext, iv, tag)
