"""Audit event definitions for the Okta MCP Adapter."""

import json
import os
from dataclasses import dataclass, field
from datetime import datetime, timezone
from enum import Enum
from typing import Any, Dict, Optional


class AuditEventType(str, Enum):
    MCP_TOOL_CALL = "mcp.tool.call"
    MCP_TOOL_LIST = "mcp.tool.list"
    MCP_SESSION_CREATED = "mcp.session.created"
    MCP_SESSION_TERMINATED = "mcp.session.terminated"
    AUTH_JWT_VALIDATED = "auth.jwt.validated"
    AUTH_JWT_REJECTED = "auth.jwt.rejected"
    AUTHZ_ACCESS_GRANTED = "authz.access.granted"
    AUTHZ_ACCESS_DENIED = "authz.access.denied"
    TOKEN_EXCHANGE_SUCCESS = "token.exchange.success"
    TOKEN_EXCHANGE_FAILURE = "token.exchange.failure"
    TOKEN_CACHE_HIT = "token.cache.hit"
    TOKEN_CACHE_MISS = "token.cache.miss"
    ADMIN_LOGIN = "admin.login"
    ADMIN_LOGIN_FAILURE = "admin.login.failure"
    ADMIN_CONFIG_CHANGE = "admin.config.change"
    ADMIN_FORCE_LOGOUT = "admin.user.force_logout"
    CONFIG_AGENT_CREATED = "config.agent.created"
    CONFIG_AGENT_UPDATED = "config.agent.updated"
    CONFIG_AGENT_DELETED = "config.agent.deleted"
    CONFIG_RESOURCE_CREATED = "config.resource.created"
    CONFIG_RESOURCE_UPDATED = "config.resource.updated"
    CONFIG_RESOURCE_DELETED = "config.resource.deleted"
    CONFIG_RESOURCE_LINKED = "config.resource.linked"
    CONFIG_RESOURCE_UNLINKED = "config.resource.unlinked"
    CONFIG_RESOURCE_ENABLED = "config.resource.enabled"
    CONFIG_RESOURCE_DISABLED = "config.resource.disabled"
    # Okta sync events
    OKTA_SYNC_STARTED = "okta.sync.started"
    OKTA_SYNC_COMPLETED = "okta.sync.completed"
    OKTA_SYNC_FAILED = "okta.sync.failed"
    # Agent import events
    AGENT_IMPORT_STARTED = "agent.import.started"
    AGENT_IMPORT_COMPLETED = "agent.import.completed"
    AGENT_IMPORT_FAILED = "agent.import.failed"
    AGENT_SYNC_COMPLETED = "agent.sync.completed"
    # DCR / CIMD / AI Agent events
    DCR_REGISTRATION = "dcr.registration"
    DCR_REVOCATION = "dcr.revocation"
    DCR_REGISTRATION_REJECTED = "dcr.registration.rejected"
    DCR_AGENT_LINKED = "dcr.agent.linked"
    DCR_AGENT_UNLINKED = "dcr.agent.unlinked"
    DCR_AGENT_SELECTION_SHOWN = "dcr.agent.selection.shown"
    DCR_AGENT_SELECTION_FAILED = "dcr.agent.selection.failed"
    DCR_AUTHORIZE_RELAYED = "dcr.authorize.relayed"
    DCR_AUTHORIZE_RELAY_FAILED = "dcr.authorize.relay.failed"
    OAUTH_DISCOVERY_SERVED = "oauth.discovery.served"
    OAUTH_JWKS_PROXY_HIT = "oauth.jwks.proxy.hit"
    OAUTH_JWKS_PROXY_MISS = "oauth.jwks.proxy.miss"
    OAUTH_AUTHORIZE_RELAYED = "oauth.authorize.relayed"
    OAUTH_AUTHORIZE_RELAY_FAILED = "oauth.authorize.relay.failed"
    # Custom-scope absorption (adapter splits OIDC vs custom on /oauth/authorize,
    # stashes custom scopes locally, rebinds at proxy time for Leg 1 of ID-JAG)
    OAUTH_CUSTOM_SCOPES_STASHED = "oauth.custom_scopes.stashed"
    OAUTH_CUSTOM_SCOPES_RECOVERED = "oauth.custom_scopes.recovered"
    TOKEN_CUSTOM_SCOPES_BOUND = "token.custom_scopes.bound"
    DCR_TOKEN_EXCHANGE_SUCCESS = "dcr.token.exchange.success"
    DCR_TOKEN_EXCHANGE_FAILURE = "dcr.token.exchange.failure"
    CIMD_RESOLUTION = "cimd.resolution"
    XAA_TOKEN_EXCHANGE = "xaa.token.exchange"
    # Vault secret / OPA exchange events
    VAULT_SECRET_EXCHANGE_SUCCESS = "vault.secret.exchange.success"
    VAULT_SECRET_EXCHANGE_FAILURE = "vault.secret.exchange.failure"
    VAULT_SECRET_CACHE_HIT = "vault.secret.cache.hit"
    STS_SERVICE_ACCOUNT_EXCHANGE_SUCCESS = "sts.service_account.exchange.success"
    STS_SERVICE_ACCOUNT_EXCHANGE_FAILURE = "sts.service_account.exchange.failure"
    STS_SERVICE_ACCOUNT_CACHE_HIT = "sts.service_account.cache.hit"
    AI_AGENT_PROMOTED = "ai.agent.promoted"
    MANAGED_CONNECTIONS_SYNCED = "managed.connections.synced"
    # STS Consent Interstitial events
    STS_CONSENT_TX_CREATED = "sts.consent.tx.created"
    STS_CONSENT_TX_COMPLETED = "sts.consent.tx.completed"
    STS_CONSENT_TX_EXPIRED = "sts.consent.tx.expired"
    STS_CONSENT_TX_SKIPPED = "sts.consent.tx.skipped"
    STS_CONSENT_CHECK_SUCCESS = "sts.consent.check.success"
    STS_CONSENT_CHECK_REQUIRED = "sts.consent.check.required"
    STS_CONSENT_CHECK_ERROR = "sts.consent.check.error"
    STS_CONSENT_RECHECK = "sts.consent.recheck"
    STS_PRECONSENT_INITIATED = "sts.preconsent.initiated"
    STS_PRECONSENT_AUTHENTICATED = "sts.preconsent.authenticated"
    DCR_REDIRECT_PATTERNS_UPDATED = "dcr.redirect_patterns.updated"
    # User token store events
    USER_TOKEN_STORE_WRITE = "user.token.store.write"
    USER_TOKEN_STORE_REMOVE = "user.token.store.remove"
    # Port configuration events
    CONFIG_PORT_VALIDATION_WARNING = "config.port.validation_warning"
    # Database lifecycle events (P02–P09)
    DB_POOL_OPENED = "db.pool.opened"
    DB_POOL_CLOSED = "db.pool.closed"
    DB_CREDENTIAL_ROTATED = "db.credential.rotated"
    DB_SCHEMA_VERSION_CHECKED = "db.schema.version_checked"
    DB_SCHEMA_VERSION_MISMATCH = "db.schema.version_mismatch"
    DB_MIGRATION_APPLIED = "db.migration.applied"
    DB_MIGRATION_FAILED = "db.migration.failed"
    # --- Redis credential lifecycle (Phase 1+) ---
    REDIS_CREDENTIAL_MINTED = "redis.credential.minted"
    REDIS_CREDENTIAL_REFRESH_SUCCESS = "redis.credential.refresh.success"
    REDIS_CREDENTIAL_REFRESH_FAILED = "redis.credential.refresh.failed"
    REDIS_AUTH_FAILURE = "redis.auth.failure"
    REDIS_STATIC_PASSWORD_USED = "redis.static_password.used"
    # Global logout events (Okta ITP Universal Logout)
    GLOBAL_LOGOUT_REQUESTED = "global_logout.requested"
    GLOBAL_LOGOUT_AUTH_FAILED = "global_logout.auth.failed"
    GLOBAL_LOGOUT_SUBJECT_INVALID = "global_logout.subject.invalid"
    GLOBAL_LOGOUT_SUBJECT_NOT_FOUND = "global_logout.subject.not_found"
    GLOBAL_LOGOUT_COMPLETED = "global_logout.completed"
    GLOBAL_LOGOUT_BACKEND_SESSION_TERMINATED = "global_logout.backend_session.terminated"
    GLOBAL_LOGOUT_BACKEND_SESSION_FAILED = "global_logout.backend_session.failed"


class AuditSeverity(str, Enum):
    INFO = "info"
    WARNING = "warning"
    CRITICAL = "critical"


_SEVERITY_ID = {
    AuditSeverity.INFO: 1,
    AuditSeverity.WARNING: 2,
    AuditSeverity.CRITICAL: 3,
}


@dataclass(frozen=True)
class AuditEvent:
    event_type: AuditEventType
    severity: AuditSeverity
    correlation_id: str
    timestamp: datetime = field(default_factory=lambda: datetime.now(timezone.utc))
    agent_id: Optional[str] = None
    user_id: Optional[str] = None
    client_id: Optional[str] = None
    resource_name: Optional[str] = None
    ip_address: Optional[str] = None
    user_agent: Optional[str] = None
    details: Dict[str, Any] = field(default_factory=dict)
    outcome: str = "success"

    def to_dict(self) -> Dict[str, Any]:
        actor = {}
        for key in ("agent_id", "user_id", "client_id", "ip_address", "user_agent"):
            val = getattr(self, key)
            if val is not None:
                actor[key] = val

        result: Dict[str, Any] = {
            "schema_version": "1.0",
            "event_type": self.event_type.value,
            "severity": self.severity.value,
            "severity_id": _SEVERITY_ID[self.severity],
            "time": self.timestamp.isoformat(),
            "correlation_id": self.correlation_id,
            "source": {
                "service": "okta-mcp-adapter",
                "version": "1.0.0",
                "instance_id": os.environ.get("INSTANCE_ID", "unknown"),
            },
            "actor": actor,
            "details": self.details,
            "outcome": self.outcome,
        }
        return result

    def to_json(self) -> str:
        return json.dumps(self.to_dict(), ensure_ascii=False, sort_keys=False)
