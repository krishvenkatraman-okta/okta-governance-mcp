"""Abstract base class for audit event sinks."""

from abc import ABC, abstractmethod
from typing import List

from okta_agent_proxy.audit.events import AuditEvent


class AuditSink(ABC):
    """Base class for audit event output destinations."""

    @abstractmethod
    async def write(self, event: AuditEvent) -> None: ...

    async def write_batch(self, events: List[AuditEvent]) -> None:
        for event in events:
            await self.write(event)

    async def flush(self) -> None:
        pass

    async def close(self) -> None:
        pass

    @property
    @abstractmethod
    def name(self) -> str: ...
