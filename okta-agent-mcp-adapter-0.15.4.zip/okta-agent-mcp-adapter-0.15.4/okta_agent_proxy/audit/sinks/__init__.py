"""Audit event sinks."""

from okta_agent_proxy.audit.sinks.base import AuditSink
from okta_agent_proxy.audit.sinks.stdout import StdoutSink
from okta_agent_proxy.audit.sinks.file import FileSink
from okta_agent_proxy.audit.sinks.webhook import WebhookSink

__all__ = ["AuditSink", "StdoutSink", "FileSink", "WebhookSink"]
