"""Stdout audit sink — primary SIEM integration point via container log shippers."""

from okta_agent_proxy.audit.events import AuditEvent
from okta_agent_proxy.audit.sinks.base import AuditSink


class StdoutSink(AuditSink):
    """Writes audit events as JSON lines to stdout."""

    async def write(self, event: AuditEvent) -> None:
        print(event.to_json())

    @property
    def name(self) -> str:
        return "stdout"
