"""File-based audit sink with log rotation."""

import logging
from logging.handlers import RotatingFileHandler

from okta_agent_proxy.audit.events import AuditEvent
from okta_agent_proxy.audit.sinks.base import AuditSink


class FileSink(AuditSink):
    """Writes audit events as JSONL to a rotating file."""

    def __init__(
        self,
        file_path: str,
        max_bytes: int = 100 * 1024 * 1024,
        backup_count: int = 5,
    ) -> None:
        self._handler = RotatingFileHandler(
            file_path, maxBytes=max_bytes, backupCount=backup_count
        )
        self._handler.setFormatter(logging.Formatter("%(message)s"))

    async def write(self, event: AuditEvent) -> None:
        record = logging.LogRecord(
            name="audit", level=logging.INFO, pathname="", lineno=0,
            msg=event.to_json(), args=(), exc_info=None,
        )
        self._handler.emit(record)

    async def flush(self) -> None:
        self._handler.flush()

    async def close(self) -> None:
        self._handler.close()

    @property
    def name(self) -> str:
        return "file"
