"""Webhook audit sink for SIEM integration (Splunk HEC, Datadog, generic)."""

import asyncio
import logging
import time
from typing import List, Optional

import httpx

from okta_agent_proxy.audit.events import AuditEvent
from okta_agent_proxy.audit.sinks.base import AuditSink

logger = logging.getLogger(__name__)


class WebhookSink(AuditSink):
    """Sends audit events to an HTTP endpoint in batched NDJSON (Splunk HEC) format.

    Features:
    - Batches events up to ``batch_size`` before flushing
    - Periodic flush every ``flush_interval_ms`` even if batch is not full
    - Retry with exponential backoff on transient failures
    - Non-blocking: callers are never delayed by HTTP round-trips
    """

    def __init__(
        self,
        url: str,
        token: str = "",
        batch_size: int = 100,
        flush_interval_ms: int = 1000,
        timeout_ms: int = 5000,
        retry_max: int = 3,
    ) -> None:
        self._url = url
        self._token = token
        self._batch_size = batch_size
        self._flush_interval = flush_interval_ms / 1000.0
        self._timeout = timeout_ms / 1000.0
        self._retry_max = retry_max

        self._buffer: List[AuditEvent] = []
        self._lock = asyncio.Lock()
        self._flush_task: Optional[asyncio.Task] = None
        self._client: Optional[httpx.AsyncClient] = None
        self._running = False

    # ------------------------------------------------------------------
    # Lifecycle
    # ------------------------------------------------------------------

    async def _ensure_client(self) -> httpx.AsyncClient:
        if self._client is None or self._client.is_closed:
            headers: dict[str, str] = {"Content-Type": "application/x-ndjson"}
            if self._token:
                headers["Authorization"] = f"Splunk {self._token}"
            self._client = httpx.AsyncClient(headers=headers, timeout=self._timeout)
        return self._client

    async def _start_flush_loop(self) -> None:
        self._running = True
        while self._running:
            await asyncio.sleep(self._flush_interval)
            await self.flush()

    async def start(self) -> None:
        """Start the periodic flush background task."""
        if self._flush_task is None or self._flush_task.done():
            self._flush_task = asyncio.create_task(self._start_flush_loop())

    # ------------------------------------------------------------------
    # AuditSink interface
    # ------------------------------------------------------------------

    async def write(self, event: AuditEvent) -> None:
        batch = None
        async with self._lock:
            self._buffer.append(event)
            if len(self._buffer) >= self._batch_size:
                batch = self._buffer[:]
                self._buffer.clear()
        if batch:
            await self._send_batch(batch)

    async def write_batch(self, events: List[AuditEvent]) -> None:
        batch = None
        async with self._lock:
            self._buffer.extend(events)
            if len(self._buffer) >= self._batch_size:
                batch = self._buffer[:]
                self._buffer.clear()
        if batch:
            await self._send_batch(batch)

    async def flush(self) -> None:
        async with self._lock:
            if not self._buffer:
                return
            batch = self._buffer[:]
            self._buffer.clear()
        await self._send_batch(batch)

    async def close(self) -> None:
        self._running = False
        if self._flush_task and not self._flush_task.done():
            self._flush_task.cancel()
            try:
                await self._flush_task
            except asyncio.CancelledError:
                pass
        await self.flush()
        if self._client and not self._client.is_closed:
            await self._client.aclose()

    @property
    def name(self) -> str:
        return "webhook"

    # ------------------------------------------------------------------
    # Internal
    # ------------------------------------------------------------------

    def _format_ndjson(self, events: List[AuditEvent]) -> str:
        """Format events as Splunk HEC NDJSON: one ``{"event": ...}`` per line."""
        lines: list[str] = []
        for event in events:
            d = event.to_dict()
            # Splunk HEC envelope
            import json
            envelope = {
                "event": d,
                "time": event.timestamp.timestamp(),
                "sourcetype": "okta:mcp:audit",
            }
            lines.append(json.dumps(envelope, ensure_ascii=False))
        return "\n".join(lines)

    async def _send_batch(self, events: List[AuditEvent]) -> None:
        """Send a batch of events with retry and exponential backoff."""
        body = self._format_ndjson(events)
        client = await self._ensure_client()
        last_exc: Optional[Exception] = None

        for attempt in range(self._retry_max):
            try:
                resp = await client.post(self._url, content=body)
                if resp.status_code < 300:
                    return
                if resp.status_code < 500:
                    # Client error — don't retry
                    logger.error(
                        "Webhook sink received %d from %s: %s",
                        resp.status_code, self._url, resp.text[:200],
                    )
                    return
                # Server error — retry
                logger.warning(
                    "Webhook sink received %d (attempt %d/%d)",
                    resp.status_code, attempt + 1, self._retry_max,
                )
            except (httpx.HTTPError, OSError) as exc:
                last_exc = exc
                logger.warning(
                    "Webhook sink error (attempt %d/%d): %s",
                    attempt + 1, self._retry_max, exc,
                )

            if attempt < self._retry_max - 1:
                backoff = 0.5 * (2 ** attempt)
                await asyncio.sleep(backoff)

        logger.error(
            "Webhook sink gave up after %d attempts (%d events dropped). Last error: %s",
            self._retry_max, len(events), last_exc,
        )
