"""Request-scoped audit context using contextvars."""

from contextvars import ContextVar
from typing import Any, Dict, Optional

from okta_agent_proxy.audit.events import AuditEvent, AuditEventType, AuditSeverity

correlation_id_var: ContextVar[str] = ContextVar("correlation_id", default="")
agent_id_var: ContextVar[Optional[str]] = ContextVar("agent_id", default=None)
user_id_var: ContextVar[Optional[str]] = ContextVar("user_id", default=None)
client_id_var: ContextVar[Optional[str]] = ContextVar("client_id", default=None)
ip_address_var: ContextVar[Optional[str]] = ContextVar("ip_address", default=None)
user_agent_var: ContextVar[Optional[str]] = ContextVar("user_agent", default=None)


def get_correlation_id() -> str:
    return correlation_id_var.get()


def set_request_context(
    correlation_id: str,
    agent_id: Optional[str] = None,
    user_id: Optional[str] = None,
    client_id: Optional[str] = None,
    ip_address: Optional[str] = None,
    user_agent: Optional[str] = None,
) -> None:
    correlation_id_var.set(correlation_id)
    agent_id_var.set(agent_id)
    user_id_var.set(user_id)
    client_id_var.set(client_id)
    ip_address_var.set(ip_address)
    user_agent_var.set(user_agent)


def clear_request_context() -> None:
    correlation_id_var.set("")
    agent_id_var.set(None)
    user_id_var.set(None)
    client_id_var.set(None)
    ip_address_var.set(None)
    user_agent_var.set(None)


def get_request_context() -> Dict[str, Any]:
    return {
        "correlation_id": correlation_id_var.get(),
        "agent_id": agent_id_var.get(),
        "user_id": user_id_var.get(),
        "client_id": client_id_var.get(),
        "ip_address": ip_address_var.get(),
        "user_agent": user_agent_var.get(),
    }


def create_audit_event(
    event_type: AuditEventType,
    severity: AuditSeverity = AuditSeverity.INFO,
    resource_name: Optional[str] = None,
    details: Optional[Dict[str, Any]] = None,
    outcome: str = "success",
) -> AuditEvent:
    return AuditEvent(
        event_type=event_type,
        severity=severity,
        correlation_id=correlation_id_var.get(),
        agent_id=agent_id_var.get(),
        user_id=user_id_var.get(),
        client_id=client_id_var.get(),
        resource_name=resource_name,
        ip_address=ip_address_var.get(),
        user_agent=user_agent_var.get(),
        details=details if details is not None else {},
        outcome=outcome,
    )
