"""Audit event system for the Okta MCP Adapter."""

import logging
import os
from typing import Optional

from okta_agent_proxy.audit.events import AuditEvent, AuditEventType, AuditSeverity
from okta_agent_proxy.audit.context import create_audit_event
from okta_agent_proxy.audit.emitter import AuditEventEmitter
from okta_agent_proxy.audit.sinks import AuditSink, StdoutSink, FileSink, WebhookSink

logger = logging.getLogger(__name__)

_emitter: Optional[AuditEventEmitter] = None


async def init_audit_emitter() -> AuditEventEmitter:
    """Create, start, and store the global audit emitter based on env config."""
    global _emitter

    enabled = os.getenv("AUDIT_ENABLED", "true").lower() == "true"
    sinks_list: list[AuditSink] = []

    if enabled:
        sink_names = [s.strip() for s in os.getenv("AUDIT_SINKS", "stdout").split(",")]
        for sink_name in sink_names:
            if sink_name == "stdout":
                sinks_list.append(StdoutSink())
            elif sink_name == "file":
                path = os.getenv("AUDIT_FILE_PATH", "/app/logs/audit.jsonl")
                sinks_list.append(FileSink(file_path=path))
            elif sink_name == "webhook":
                wh_url = os.getenv("AUDIT_WEBHOOK_URL", "")
                if not wh_url:
                    logger.warning("AUDIT_WEBHOOK_URL not set; skipping webhook sink")
                    continue
                wh_token = os.getenv("AUDIT_WEBHOOK_TOKEN", "")
                wh_batch = int(os.getenv("AUDIT_WEBHOOK_BATCH_SIZE", "100"))
                wh_flush = int(os.getenv("AUDIT_WEBHOOK_FLUSH_INTERVAL_MS", "1000"))
                wh_timeout = int(os.getenv("AUDIT_WEBHOOK_TIMEOUT_MS", "5000"))
                wh_retry = int(os.getenv("AUDIT_WEBHOOK_RETRY_MAX", "3"))
                sink = WebhookSink(
                    url=wh_url,
                    token=wh_token,
                    batch_size=wh_batch,
                    flush_interval_ms=wh_flush,
                    timeout_ms=wh_timeout,
                    retry_max=wh_retry,
                )
                sinks_list.append(sink)
            else:
                logger.warning("Unknown audit sink: %s", sink_name)

    # Start any sinks that have their own background tasks
    for sink in sinks_list:
        if hasattr(sink, "start"):
            await sink.start()

    emitter = AuditEventEmitter(sinks=sinks_list)
    await emitter.start()
    _emitter = emitter
    return emitter


def get_audit_emitter() -> Optional[AuditEventEmitter]:
    """Return the global audit emitter, or None if not yet initialized."""
    return _emitter


async def emit_audit_event(
    event_type: AuditEventType,
    severity: AuditSeverity = AuditSeverity.INFO,
    resource_name: str | None = None,
    details: dict | None = None,
    outcome: str = "success",
) -> None:
    """Convenience one-liner: create an audit event from context and emit it."""
    emitter = get_audit_emitter()
    if emitter:
        event = create_audit_event(event_type, severity, resource_name, details, outcome)
        await emitter.emit(event)


async def shutdown_audit_emitter() -> None:
    """Stop the global audit emitter if it exists."""
    global _emitter
    if _emitter is not None:
        await _emitter.stop()
        _emitter = None


__all__ = [
    "AuditEvent",
    "AuditEventType",
    "AuditSeverity",
    "AuditSink",
    "StdoutSink",
    "FileSink",
    "WebhookSink",
    "AuditEventEmitter",
    "create_audit_event",
    "get_audit_emitter",
    "init_audit_emitter",
    "emit_audit_event",
    "shutdown_audit_emitter",
]
