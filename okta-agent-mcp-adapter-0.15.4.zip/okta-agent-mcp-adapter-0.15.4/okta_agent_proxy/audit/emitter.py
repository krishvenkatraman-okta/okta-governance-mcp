"""Async audit event emitter with buffered drain loop."""

import asyncio
import logging
from typing import List, Optional

from okta_agent_proxy.audit.events import AuditEvent
from okta_agent_proxy.audit.sinks.base import AuditSink

logger = logging.getLogger(__name__)


class AuditEventEmitter:
    """Queues audit events and drains them to configured sinks in the background."""

    def __init__(
        self,
        sinks: List[AuditSink],
        buffer_size: int = 10000,
        flush_interval: float = 1.0,
    ) -> None:
        self._sinks = sinks
        self._queue: asyncio.Queue[Optional[AuditEvent]] = asyncio.Queue(maxsize=buffer_size)
        self._flush_interval = flush_interval
        self._running = False
        self._drain_task: Optional[asyncio.Task] = None

    @property
    def sinks(self) -> List[AuditSink]:
        return self._sinks

    async def start(self) -> None:
        self._running = True
        self._drain_task = asyncio.create_task(self._drain_loop())

    async def stop(self) -> None:
        self._running = False
        try:
            self._queue.put_nowait(None)
        except asyncio.QueueFull:
            pass
        if self._drain_task is not None:
            try:
                await asyncio.wait_for(self._drain_task, timeout=5.0)
            except asyncio.TimeoutError:
                logger.warning("Audit drain task did not finish within 5s, cancelling")
                self._drain_task.cancel()
        for sink in self._sinks:
            try:
                await sink.flush()
            except Exception as e:
                logger.warning("Error flushing sink %s: %s", sink.name, e)
            try:
                await sink.close()
            except Exception as e:
                logger.warning("Error closing sink %s: %s", sink.name, e)

    async def emit(self, event: AuditEvent) -> None:
        try:
            self._queue.put_nowait(event)
        except asyncio.QueueFull:
            logger.warning("Audit queue full, dropping event: %s", event.event_type.value)

    async def _drain_loop(self) -> None:
        while self._running:
            batch: List[AuditEvent] = []
            try:
                item = await asyncio.wait_for(self._queue.get(), timeout=self._flush_interval)
                if item is None:
                    break
                batch.append(item)
            except asyncio.TimeoutError:
                pass

            # Drain up to 99 more without waiting
            while len(batch) < 100:
                try:
                    item = self._queue.get_nowait()
                    if item is None:
                        self._running = False
                        break
                    batch.append(item)
                except asyncio.QueueEmpty:
                    break

            if batch:
                for sink in self._sinks:
                    try:
                        await sink.write_batch(batch)
                    except Exception as e:
                        logger.warning("Sink %s failed to write batch: %s", sink.name, e)

        # Drain remaining items after loop exits
        remaining: List[AuditEvent] = []
        while not self._queue.empty():
            try:
                item = self._queue.get_nowait()
                if item is not None:
                    remaining.append(item)
            except asyncio.QueueEmpty:
                break
        if remaining:
            for sink in self._sinks:
                try:
                    await sink.write_batch(remaining)
                except Exception as e:
                    logger.warning("Sink %s failed to write remaining batch: %s", sink.name, e)
