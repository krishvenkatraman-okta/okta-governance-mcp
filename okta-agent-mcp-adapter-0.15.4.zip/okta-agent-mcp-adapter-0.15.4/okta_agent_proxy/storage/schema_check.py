"""Fail-fast schema version check (DB migration prompt P08).

The adapter no longer creates database schema at runtime. Operators are
expected to run the migration runner (or an equivalent DBA-owned
pipeline) before starting the service. This module probes the database
at startup and refuses to continue if the schema is missing or behind
the minimum required version.
"""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING

import psycopg

from okta_agent_proxy.storage.constants import (
    MIN_SCHEMA_VERSION,
    SCHEMA_MIGRATIONS_TABLE,
)

if TYPE_CHECKING:
    from okta_agent_proxy.storage.pool import DatabasePool

logger = logging.getLogger(__name__)


class SchemaNotInitializedError(RuntimeError):
    """Raised when the ``schema_migrations`` table does not exist."""


class SchemaVersionMismatchError(RuntimeError):
    """Raised when the applied schema version is below ``MIN_SCHEMA_VERSION``."""


def _not_initialized_message() -> str:
    return (
        f"Database schema is not initialized — table "
        f"'{SCHEMA_MIGRATIONS_TABLE}' does not exist.\n"
        f"Run the migration runner against your database BEFORE starting "
        f"the adapter:\n"
        f"    python -m okta_agent_proxy.storage.migrate upgrade "
        f'--conninfo "$DATABASE_URL"\n'
        f"Or with Docker: ./run_migrations.sh\n"
        f"This adapter intentionally does not create database schema at "
        f"runtime.\n"
        f"See docs/OPERATIONS.md § Database Bootstrap."
    )


def _version_mismatch_message(current: str | None) -> str:
    return (
        f"Database schema version is {current!r} but this build requires "
        f"{MIN_SCHEMA_VERSION!r} or higher.\n"
        f"Run pending migrations:\n"
        f"    python -m okta_agent_proxy.storage.migrate upgrade "
        f'--conninfo "$DATABASE_URL"\n'
    )


def verify_schema(pool: "DatabasePool") -> str:
    """Verify the database schema is at ``MIN_SCHEMA_VERSION`` or higher.

    Args:
        pool: An open :class:`DatabasePool` to borrow a connection from.

    Returns:
        The current applied schema version on success.

    Raises:
        SchemaNotInitializedError: ``schema_migrations`` table missing.
        SchemaVersionMismatchError: Current version < ``MIN_SCHEMA_VERSION``.
        RuntimeError: Any other psycopg error reaching the database.
    """
    try:
        with pool.connection() as conn:
            with conn.cursor() as cur:
                cur.execute(
                    "SELECT to_regclass(%s)", (SCHEMA_MIGRATIONS_TABLE,)
                )
                row = cur.fetchone()
                regclass = _first_column(row)
                if regclass is None:
                    raise SchemaNotInitializedError(_not_initialized_message())

                cur.execute(
                    f"SELECT MAX(version) FROM {SCHEMA_MIGRATIONS_TABLE}"
                )
                row = cur.fetchone()
                current = _first_column(row)
                if current is None or current < MIN_SCHEMA_VERSION:
                    raise SchemaVersionMismatchError(
                        _version_mismatch_message(current)
                    )
                logger.info(
                    "✓ Database schema verified — current version: %s",
                    current,
                )
                return str(current)
    except (SchemaNotInitializedError, SchemaVersionMismatchError):
        raise
    except psycopg.Error as exc:
        raise RuntimeError(
            f"Failed to verify database schema: {exc}\n"
            f"Check that DATABASE_URL is correct and the database is "
            f"reachable."
        ) from exc


def _first_column(row):
    """Return the first column of a fetched row.

    The pool configures ``dict_row`` as the row factory, so ``fetchone()``
    yields a ``dict``; tests that swap in a plain cursor may return a
    tuple. Accept both shapes.
    """
    if row is None:
        return None
    if isinstance(row, dict):
        if not row:
            return None
        return next(iter(row.values()))
    return row[0]
