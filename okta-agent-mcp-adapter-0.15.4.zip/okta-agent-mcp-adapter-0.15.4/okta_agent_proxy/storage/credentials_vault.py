"""HashiCorp Vault dynamic database credential provider (P12).

Uses Vault's database secrets engine to issue short-lived, uniquely-named
Postgres roles. On each ``get_credential()`` Vault generates a fresh
username/password pair with a configurable lease. The provider caches
the issued credential until ~80% of its lease has elapsed so the pool
doesn't hammer Vault on every new connection.

Required env vars:
    DB_HOST            — Postgres host
    DB_PORT            — default 5432
    DB_NAME            — database name
    VAULT_ADDR         — e.g. ``https://vault.example.com:8200``
    VAULT_DB_MOUNT     — mount path of the database secrets engine
                         (default ``database``)
    VAULT_DB_ROLE      — configured Vault role name (e.g.
                         ``okta-adapter-app``)

Authentication (exactly one set must be present):
    VAULT_TOKEN                        — static token (dev only)
    VAULT_K8S_ROLE + (optional)
        VAULT_K8S_AUTH_PATH (default
            ``kubernetes``) + K8S_SA_TOKEN_PATH
        (default
            ``/var/run/secrets/kubernetes.io/serviceaccount/token``)
                                       — Kubernetes auth (preferred in K8s)
    VAULT_APPROLE_ROLE_ID +
        VAULT_APPROLE_SECRET_ID        — AppRole auth

Optional:
    DB_SSLMODE     — libpq sslmode (default ``require``)
    DB_SSLROOTCERT — path to CA bundle
"""

from __future__ import annotations

import logging
import os
import threading
import time
from typing import Optional

from .credentials import DatabaseCredential, DatabaseCredentialProvider

logger = logging.getLogger(__name__)


# Vault tokens / leases returned by the database engine come with a
# ``lease_duration`` field in the response. Fall back to one hour if the
# server omits it for any reason — matches Vault's typical default.
_DEFAULT_LEASE_SECONDS = 3600

# Refresh the cached credential at this fraction of its lease. Chosen to
# match the pool's 80% ``max_lifetime`` heuristic so the two never fight
# each other for ownership of "when to recycle".
_LEASE_REFRESH_FRACTION = 0.8

# Floor for TTL so a pathologically small lease can't make the cache
# window effectively zero and turn every get_credential() into a Vault
# round-trip.
_MIN_LEASE_SECONDS = 60

# Default Kubernetes service-account token path (projected by kubelet).
_DEFAULT_K8S_SA_TOKEN_PATH = (
    "/var/run/secrets/kubernetes.io/serviceaccount/token"
)


class VaultDbCredentialProvider(DatabaseCredentialProvider):
    """HashiCorp Vault database secrets engine provider.

    Each cache miss calls
    ``Client.secrets.database.generate_credentials(name=role, mount_point=mount)``
    which returns a unique username/password pair plus a lease duration.
    The credential is cached in memory until ~80% of the lease has
    elapsed, then the next ``get_credential()`` call fetches a fresh
    one.

    ``DatabasePool`` treats this provider as rotating
    (``supports_rotation() is True``) and sets ``max_lifetime`` to 80%
    of the reported lease so connections recycle in lock-step with the
    cache.
    """

    name = "vault"

    def __init__(
        self,
        *,
        hvac_client: Optional[object] = None,
    ):
        missing = [
            v for v in ("DB_HOST", "DB_NAME") if not os.environ.get(v)
        ]
        if not os.environ.get("VAULT_ADDR") and hvac_client is None:
            missing.append("VAULT_ADDR")
        if not os.environ.get("VAULT_DB_ROLE"):
            missing.append("VAULT_DB_ROLE")
        if missing:
            raise RuntimeError(
                "VaultDbCredentialProvider is missing required env vars: "
                f"{', '.join(missing)}. See docs/OPERATIONS.md § HashiCorp Vault."
            )

        self._host = os.environ["DB_HOST"]
        self._port = int(os.environ.get("DB_PORT", "5432"))
        self._dbname = os.environ["DB_NAME"]
        self._mount = os.environ.get("VAULT_DB_MOUNT", "database")
        self._role = os.environ["VAULT_DB_ROLE"]
        self._sslmode = os.environ.get("DB_SSLMODE", "require")
        self._sslrootcert = os.environ.get("DB_SSLROOTCERT")

        self._client = hvac_client if hvac_client is not None else self._build_client()

        self._lock = threading.Lock()
        self._cached: Optional[DatabaseCredential] = None
        self._cached_until: float = 0.0

    # ---- Vault auth wiring ------------------------------------------------

    def _build_client(self) -> object:
        """Construct and authenticate an ``hvac.Client``.

        The first auth method whose required env vars are set wins. The
        order — token, Kubernetes, AppRole — matches the Vault docs'
        recommended precedence for explicitness (a static token, when
        present, is always a deliberate dev override).
        """
        # Import hvac lazily so non-Vault deployments don't pay the
        # import cost and don't need the package installed at runtime.
        import hvac  # noqa: WPS433 — deliberate local import

        addr = os.environ["VAULT_ADDR"]
        client = hvac.Client(url=addr)

        if os.environ.get("VAULT_TOKEN"):
            client.token = os.environ["VAULT_TOKEN"]
        elif os.environ.get("VAULT_K8S_ROLE"):
            sa_token_path = os.environ.get(
                "K8S_SA_TOKEN_PATH", _DEFAULT_K8S_SA_TOKEN_PATH
            )
            with open(sa_token_path, "r", encoding="utf-8") as fh:
                sa_token = fh.read().strip()
            client.auth.kubernetes.login(
                role=os.environ["VAULT_K8S_ROLE"],
                jwt=sa_token,
                mount_point=os.environ.get("VAULT_K8S_AUTH_PATH", "kubernetes"),
            )
        elif os.environ.get("VAULT_APPROLE_ROLE_ID"):
            if not os.environ.get("VAULT_APPROLE_SECRET_ID"):
                raise RuntimeError(
                    "VaultDbCredentialProvider: VAULT_APPROLE_ROLE_ID is set "
                    "but VAULT_APPROLE_SECRET_ID is missing."
                )
            client.auth.approle.login(
                role_id=os.environ["VAULT_APPROLE_ROLE_ID"],
                secret_id=os.environ["VAULT_APPROLE_SECRET_ID"],
            )
        else:
            raise RuntimeError(
                "VaultDbCredentialProvider: no Vault auth method configured. "
                "Set one of VAULT_TOKEN, VAULT_K8S_ROLE, or "
                "VAULT_APPROLE_ROLE_ID. See docs/OPERATIONS.md § HashiCorp Vault."
            )

        if not client.is_authenticated():
            raise RuntimeError(
                "VaultDbCredentialProvider: Vault authentication succeeded at "
                "the transport layer but is_authenticated() returned False. "
                "Check the token's policies and Vault's audit log."
            )
        return client

    # ---- Credential issuance + caching -----------------------------------

    def _request_new_credential(self) -> DatabaseCredential:
        resp = self._client.secrets.database.generate_credentials(
            name=self._role, mount_point=self._mount
        )
        data = resp["data"]
        lease_duration = int(resp.get("lease_duration", _DEFAULT_LEASE_SECONDS))
        lease_duration = max(lease_duration, _MIN_LEASE_SECONDS)
        logger.info(
            "Vault issued DB credential (role=%s mount=%s username=%s lease=%ds)",
            self._role,
            self._mount,
            data["username"],
            lease_duration,
        )
        return DatabaseCredential(
            username=data["username"],
            password=data["password"],
            host=self._host,
            port=self._port,
            dbname=self._dbname,
            sslmode=self._sslmode,
            sslrootcert=self._sslrootcert,
            ttl_seconds=lease_duration,
        )

    def get_credential(self) -> DatabaseCredential:
        now = time.monotonic()
        with self._lock:
            if self._cached is not None and now < self._cached_until:
                return self._cached
            cred = self._request_new_credential()
            # ttl_seconds is always set by _request_new_credential (floored
            # at _MIN_LEASE_SECONDS), so the arithmetic below is safe.
            assert cred.ttl_seconds is not None
            self._cached = cred
            self._cached_until = now + (cred.ttl_seconds * _LEASE_REFRESH_FRACTION)
            return cred

    def supports_rotation(self) -> bool:
        return True
