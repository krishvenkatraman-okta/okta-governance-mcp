"""Azure Entra ID database credential provider (P11).

Acquires an Azure AD access token via ``DefaultAzureCredential`` and
returns it as the database password for Azure Database for PostgreSQL
(Flexible Server) configured with Microsoft Entra authentication.
``DatabasePool`` reads ``ttl_seconds`` from the returned credential and
recycles connections at ~80% of the TTL so tokens never expire
mid-query.

Required env vars:
    DB_HOST       — ``<server>.postgres.database.azure.com``
    DB_PORT       — default 5432
    DB_NAME       — database name
    DB_USERNAME   — Entra principal name mapped to a Postgres role
                    (user principal name, managed identity name, or
                    group name the current principal is a member of)

Optional:
    DB_SSLROOTCERT — path to the root CA bundle. When unset, psycopg
                     uses the system trust store, which is sufficient
                     for Azure's public CAs.

Authentication: ``DefaultAzureCredential`` walks a credential chain
that includes Managed Identity (preferred in Azure Container Apps /
AKS via ``AZURE_CLIENT_ID``), service principal
(``AZURE_CLIENT_ID``/``AZURE_CLIENT_SECRET``/``AZURE_TENANT_ID``), and
``az login`` for developer machines. No adapter-specific config is
required; the identity is inferred from the execution context.

Postgres-side setup — see ``docs/OPERATIONS.md`` § Azure Entra ID.
"""

from __future__ import annotations

import logging
import os
import time
from typing import Optional

from .credentials import DatabaseCredential, DatabaseCredentialProvider

logger = logging.getLogger(__name__)


# Scope for Azure Database for PostgreSQL (Flexible Server) Entra tokens.
# See: https://learn.microsoft.com/azure/postgresql/flexible-server/how-to-configure-sign-in-azure-ad-authentication
_AZURE_POSTGRES_SCOPE = "https://ossrdbms-aad.database.windows.net/.default"

# Floor for the reported TTL. Entra tokens are typically ~1 hour; this
# only guards against a clock-skew edge case where expires_on is in the
# immediate past.
_MIN_TTL_SECONDS = 60


class AzureEntraCredentialProvider(DatabaseCredentialProvider):
    """Azure Entra ID (Microsoft Entra) database authentication provider.

    Each ``get_credential()`` call acquires a fresh Entra access token
    via ``DefaultAzureCredential`` and returns it as the password.
    ``DatabasePool`` treats this provider as rotating
    (``supports_rotation() is True``) and sets the pool's
    ``max_lifetime`` to 80% of the reported token TTL.
    """

    name = "azure_entra"

    def __init__(
        self,
        *,
        azure_credential: Optional[object] = None,
    ):
        missing = [
            v for v in ("DB_HOST", "DB_NAME", "DB_USERNAME")
            if not os.environ.get(v)
        ]
        if missing:
            raise RuntimeError(
                "AzureEntraCredentialProvider is missing required env vars: "
                f"{', '.join(missing)}. See docs/OPERATIONS.md § Azure Entra ID."
            )

        self._host = os.environ["DB_HOST"]
        self._port = int(os.environ.get("DB_PORT", "5432"))
        self._dbname = os.environ["DB_NAME"]
        self._username = os.environ["DB_USERNAME"]
        self._sslrootcert = os.environ.get("DB_SSLROOTCERT")

        if azure_credential is not None:
            self._credential = azure_credential
        else:
            # Import azure-identity lazily so non-Azure deployments don't
            # pay the import cost and don't need the package installed.
            from azure.identity import DefaultAzureCredential  # noqa: WPS433

            self._credential = DefaultAzureCredential()

    def get_credential(self) -> DatabaseCredential:
        token_obj = self._credential.get_token(_AZURE_POSTGRES_SCOPE)
        ttl = max(int(token_obj.expires_on - time.time()), _MIN_TTL_SECONDS)
        logger.debug(
            "Acquired Entra ID token for Postgres (host=%s user=%s ttl=%ds)",
            self._host,
            self._username,
            ttl,
        )
        return DatabaseCredential(
            username=self._username,
            password=token_obj.token,
            host=self._host,
            port=self._port,
            dbname=self._dbname,
            # Azure Postgres Flexible Server requires SSL by default.
            sslmode="require",
            sslrootcert=self._sslrootcert,
            ttl_seconds=ttl,
        )

    def supports_rotation(self) -> bool:
        return True
