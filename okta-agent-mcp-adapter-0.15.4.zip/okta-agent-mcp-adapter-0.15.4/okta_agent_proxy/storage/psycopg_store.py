"""psycopg3-backed ``ResourceConfigStore``.

Composes per-slice repositories:

* :class:`ResourceRepository` — unified resource CRUD + L1 cache + linkage
  + sync-state surface. Admin-API callers use ``admin_*`` methods here;
  the syncer and router use the ``Resource``-object methods on the same
  instance via ``app.py``'s shared handle.
* :class:`AgentRepository` + :class:`DcrRepository`
* :class:`AuditRepository` + :class:`GatewayConfigRepository`

The optional ``legacy_store`` argument is retained as a no-op seam for
test fixtures that historically instantiated a parallel SQLAlchemy store.
"""

from __future__ import annotations

import logging
from typing import Any, Dict, List, Optional, cast

from okta_agent_proxy.crypto.encryption import EncryptionService
from okta_agent_proxy.storage.base import ResourceConfigStore
from okta_agent_proxy.storage.pool import DatabasePool
from okta_agent_proxy.storage.repositories.agent_repo import AgentRepository
from okta_agent_proxy.storage.repositories.audit_repo import AuditRepository
from okta_agent_proxy.storage.repositories.config_repo import (
    GatewayConfigRepository,
)
from okta_agent_proxy.storage.repositories.dcr_repo import DcrRepository
from okta_agent_proxy.storage.repositories.resource_repo import (
    ResourceRepository,
)

logger = logging.getLogger(__name__)


class PsycopgResourceStore(ResourceConfigStore):
    """psycopg3-backed store that composes slice-specific repositories."""

    def __init__(
        self,
        pool: DatabasePool,
        encryption_service: EncryptionService,
        legacy_store: Optional[ResourceConfigStore] = None,
    ):
        self._pool = pool
        self._encryption = encryption_service
        self._resources = ResourceRepository(pool, encryption_service)
        self._agents = AgentRepository(pool, encryption_service)
        self._dcr = DcrRepository(pool, encryption_service)
        self._audit = AuditRepository(pool, encryption_service)
        self._config = GatewayConfigRepository(pool, encryption_service)
        # ``_legacy`` is retained purely as a compatibility seam for tests
        # that still build the SQLAlchemy store alongside; nothing inside
        # this class reads from it post-P06.
        self._legacy = legacy_store

    # ------------------------------------------------------------------
    # Resource methods — native psycopg3
    # ------------------------------------------------------------------

    def get_all_resources(self) -> List[Dict[str, Any]]:
        return self._resources.admin_list()

    def get_resource(self, name: str) -> Optional[Dict[str, Any]]:
        return self._resources.admin_get(name)

    def update_resource(
        self,
        name: str,
        config: Dict[str, Any],
        user: str = "admin",
        ip_address: Optional[str] = None,
        user_agent: Optional[str] = None,
    ) -> bool:
        updated = self._resources.update_editable(
            name, config, user=user, ip_address=ip_address, user_agent=user_agent
        )
        return updated is not None

    def delete_resource(
        self,
        name: str,
        user: str = "admin",
        ip_address: Optional[str] = None,
        user_agent: Optional[str] = None,
    ) -> bool:
        return self._resources.delete_by_name(
            name, user=user, ip_address=ip_address, user_agent=user_agent
        )

    # ------------------------------------------------------------------
    # Audit log — native psycopg3 (P06)
    # ------------------------------------------------------------------

    def get_audit_log(
        self, resource_name: Optional[str] = None, limit: int = 100
    ) -> List[Dict[str, Any]]:
        return self._audit.get_audit_log(resource_name, limit)

    # ------------------------------------------------------------------
    # Agent methods — native psycopg3 (P05)
    # ------------------------------------------------------------------

    def get_agent(
        self, agent_id: str, enabled_only: bool = True
    ) -> Optional[Dict[str, Any]]:
        return self._agents.get(agent_id, enabled_only=enabled_only)

    def get_agent_by_name(
        self, agent_name: str, enabled_only: bool = True
    ) -> Optional[Dict[str, Any]]:
        return self._agents.get_by_name(agent_name, enabled_only=enabled_only)

    def get_agent_by_cimd_client_id(
        self, cimd_client_id: str, enabled_only: bool = True
    ) -> Optional[Dict[str, Any]]:
        return self._agents.get_by_cimd_client_id(
            cimd_client_id, enabled_only=enabled_only
        )

    def get_agent_by_client_id(
        self, client_id: str, enabled_only: bool = True
    ) -> Optional[Dict[str, Any]]:
        return self._agents.get_by_client_id(client_id, enabled_only=enabled_only)

    def get_all_agents(self, enabled_only: bool = True) -> List[Dict[str, Any]]:
        return self._agents.list_all(enabled_only=enabled_only)

    def create_agent(
        self,
        agent_id: str,
        config: Dict[str, Any],
        user: str = "admin",
        ip_address: Optional[str] = None,
        user_agent: Optional[str] = None,
    ) -> bool:
        return self._agents.create(
            agent_id, config, user=user, ip_address=ip_address, user_agent=user_agent
        )

    def create_cimd_agent(
        self,
        cimd_client_id: str,
        client_name: str,
        domain: str,
        backend_access: Optional[List[str]] = None,
        trust_level: str = "unknown",
    ) -> bool:
        return self._agents.create_cimd(
            cimd_client_id,
            client_name,
            domain,
            backend_access=backend_access,
            trust_level=trust_level,
        )

    def update_agent(
        self,
        agent_id: str,
        config: Dict[str, Any],
        user: str = "admin",
        ip_address: Optional[str] = None,
        user_agent: Optional[str] = None,
    ) -> bool:
        return self._agents.update(
            agent_id, config, user=user, ip_address=ip_address, user_agent=user_agent
        )

    def delete_agent(
        self,
        agent_id: str,
        user: str = "admin",
        ip_address: Optional[str] = None,
        user_agent: Optional[str] = None,
    ) -> bool:
        return self._agents.delete(
            agent_id, user=user, ip_address=ip_address, user_agent=user_agent
        )

    def enable_agent(
        self,
        agent_id: str,
        user: str = "admin",
        ip_address: Optional[str] = None,
        user_agent: Optional[str] = None,
    ) -> bool:
        return self._agents.set_enabled(
            agent_id, True, user=user, ip_address=ip_address, user_agent=user_agent
        )

    def disable_agent(
        self,
        agent_id: str,
        user: str = "admin",
        ip_address: Optional[str] = None,
        user_agent: Optional[str] = None,
    ) -> bool:
        return self._agents.set_enabled(
            agent_id, False, user=user, ip_address=ip_address, user_agent=user_agent
        )

    def get_agent_audit_log(
        self, agent_id: str, limit: int = 100
    ) -> List[Dict[str, Any]]:
        return self._audit.get_agent_audit_log(agent_id, limit)

    def list_agent_resources(self, agent_id: str) -> List[str]:
        """Return names of enabled resources for the given agent."""
        try:
            with self._pool.connection() as conn:
                with conn.cursor() as cur:
                    cur.execute(
                        "SELECT name FROM resources "
                        "WHERE agent_id = %s AND enabled = TRUE",
                        (agent_id,),
                    )
                    rows = cast(List[Dict[str, Any]], cur.fetchall())
            return [row["name"] for row in rows]
        except Exception as e:
            logger.error("Error listing agent resources: %s", e)
            return []

    # ------------------------------------------------------------------
    # DCR registration methods — native psycopg3 (P05)
    # ------------------------------------------------------------------

    def create_dcr_registration(
        self,
        *,
        client_id: str,
        client_name: str,
        agent_name: Optional[str] = None,
        okta_app_id: Optional[str] = None,
        redirect_uris: list,
        grant_types: list,
        provision_mode: str,
        source_ip: Optional[str] = None,
    ) -> Dict[str, Any]:
        return self._dcr.create(
            client_id=client_id,
            client_name=client_name,
            agent_name=agent_name,
            okta_app_id=okta_app_id,
            redirect_uris=redirect_uris,
            grant_types=grant_types,
            provision_mode=provision_mode,
            source_ip=source_ip,
        )

    def get_dcr_registration(self, client_id: str) -> Optional[Dict[str, Any]]:
        return self._dcr.get(client_id)

    def list_dcr_registrations(
        self,
        status: Optional[str] = None,
        limit: int = 100,
        offset: int = 0,
    ) -> List[Dict[str, Any]]:
        return self._dcr.list_all(status=status, limit=limit, offset=offset)

    def revoke_dcr_registration(
        self, client_id: str, user: str = "admin"
    ) -> bool:
        return self._dcr.revoke(client_id, user=user)

    def update_dcr_registration_linked_agent(
        self, client_id: str, linked_agent_name: Optional[str]
    ) -> bool:
        return self._dcr.update_linked_agent(client_id, linked_agent_name)

    # ------------------------------------------------------------------
    # Gateway config — native psycopg3 (P06)
    # ------------------------------------------------------------------

    def get_gateway_config(self, key: str) -> Optional[Any]:
        return self._config.get(key)

    def get_gateway_config_entry(self, key: str) -> Optional[Dict[str, Any]]:
        return self._config.get_entry(key)

    def set_gateway_config(
        self,
        key: str,
        value: Any,
        user: str = "admin",
        description: Optional[str] = None,
        ip_address: Optional[str] = None,
        user_agent: Optional[str] = None,
    ) -> None:
        self._config.set(
            key,
            value,
            user=user,
            description=description,
            ip_address=ip_address,
            user_agent=user_agent,
        )

    def delete_gateway_config(
        self,
        key: str,
        user: str = "admin",
        ip_address: Optional[str] = None,
        user_agent: Optional[str] = None,
    ) -> bool:
        return self._config.delete(
            key, user=user, ip_address=ip_address, user_agent=user_agent
        )
