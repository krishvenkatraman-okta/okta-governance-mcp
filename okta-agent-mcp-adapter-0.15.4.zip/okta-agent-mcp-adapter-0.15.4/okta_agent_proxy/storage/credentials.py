"""Database credential provider abstraction.

Introduced in DB migration prompt P02. Non-static providers (RDS IAM,
Azure Entra, Vault) land in prompts P10–P12; this module stubs them so the
connection-pool layer can be built against the final interface.
"""

from abc import ABC, abstractmethod
from dataclasses import dataclass
from typing import Optional
import logging
import os
import urllib.parse

from psycopg.conninfo import make_conninfo

from .constants import DEFAULT_OWNER_ROLE

logger = logging.getLogger(__name__)

# Gate for the static-password DB credential path. Mirrors
# ALLOW_STATIC_REDIS_PASSWORD on the cache side: production deployments must
# not set this, and the env var's absence is the grep-able evidence security
# reviewers use to confirm no baked-in DB password is in play.
GATE_ENV = "ALLOW_STATIC_DATABASE_PASSWORD"


@dataclass(frozen=True)
class DatabaseCredential:
    """A single set of database credentials.

    For rotating providers, a fresh instance is returned on each call to
    ``DatabaseCredentialProvider.get_credential()``. ``ttl_seconds`` tells the
    pool how long the credential is valid so connections recycle before expiry.
    """

    username: str
    password: str
    host: str
    port: int
    dbname: str
    sslmode: str = "prefer"
    sslrootcert: Optional[str] = None
    # TTL hint in seconds. Pool uses this to decide max connection age.
    # None = static credential, no rotation expected.
    ttl_seconds: Optional[int] = None

    def to_conninfo(self) -> str:
        """psycopg3 conninfo string (key=value form). Password is shell-safe quoted."""
        kwargs = {
            "user": self.username,
            "password": self.password,
            "host": self.host,
            "port": self.port,
            "dbname": self.dbname,
            "sslmode": self.sslmode,
        }
        if self.sslrootcert:
            kwargs["sslrootcert"] = self.sslrootcert
        return make_conninfo(**kwargs)

    def to_url(self) -> str:
        """Return libpq URL form for tools that require it (e.g., psql, migration runner)."""
        user = urllib.parse.quote(self.username, safe="")
        pwd = urllib.parse.quote(self.password, safe="")
        url = f"postgresql://{user}:{pwd}@{self.host}:{self.port}/{self.dbname}"
        params = [f"sslmode={urllib.parse.quote(self.sslmode, safe='')}"]
        if self.sslrootcert:
            params.append(f"sslrootcert={urllib.parse.quote(self.sslrootcert, safe='')}")
        return url + "?" + "&".join(params)


class DatabaseCredentialProvider(ABC):
    """Provider for database credentials. May return short-lived or static creds."""

    @abstractmethod
    def get_credential(self) -> DatabaseCredential: ...

    @property
    @abstractmethod
    def name(self) -> str: ...

    def supports_rotation(self) -> bool:
        """True if get_credential() may return a fresh password each call."""
        return False


class StaticUrlCredentialProvider(DatabaseCredentialProvider):
    """Parses DATABASE_URL once. Backward-compatible with current deployments."""

    name = "static_url"

    def __init__(self, database_url: Optional[str] = None):
        url = database_url or os.getenv("DATABASE_URL")
        if not url:
            raise RuntimeError(
                "DATABASE_URL not set; StaticUrlCredentialProvider requires it."
            )
        parsed = urllib.parse.urlparse(url)
        if parsed.scheme not in ("postgresql", "postgres"):
            raise RuntimeError(f"Unsupported scheme: {parsed.scheme}")

        qs = urllib.parse.parse_qs(parsed.query)
        sslmode = qs.get("sslmode", ["prefer"])[0]
        sslrootcert = qs.get("sslrootcert", [None])[0]

        self._cred = DatabaseCredential(
            username=urllib.parse.unquote(parsed.username or ""),
            password=urllib.parse.unquote(parsed.password or ""),
            host=parsed.hostname or "localhost",
            port=parsed.port or 5432,
            dbname=(parsed.path or "/").lstrip("/") or "postgres",
            sslmode=sslmode,
            sslrootcert=sslrootcert,
            ttl_seconds=None,
        )
        _warn_if_owner_role(self._cred.username)

    def get_credential(self) -> DatabaseCredential:
        return self._cred

    @classmethod
    def from_env(cls) -> "StaticUrlCredentialProvider":
        """Construct from DATABASE_URL, enforcing the ALLOW_STATIC_DATABASE_PASSWORD gate.

        Direct ``StaticUrlCredentialProvider(url)`` construction intentionally
        bypasses the gate so tests and programmatic callers can exercise the
        parser without setting the env var. The factory (and therefore the
        runtime startup path) always goes through ``from_env``.
        """
        gate = os.environ.get(GATE_ENV, "").strip().lower()
        if gate != "true":
            raise RuntimeError(
                f"DB_CREDENTIAL_PROVIDER=static requires {GATE_ENV}=true. "
                f"Static database passwords are not permitted in production. "
                f"Set DB_CREDENTIAL_PROVIDER=rds_iam, azure_entra, or vault "
                f"for production deployments. Set {GATE_ENV}=true explicitly "
                f"for local development / Docker Compose."
            )
        _log_static_password_warning()
        return cls()


def _log_static_password_warning() -> None:
    """Emit a loud startup warning when the static-password path is taken."""
    bar = "=" * 72
    logger.warning(bar)
    logger.warning("DB AUTH: USING STATIC PASSWORD MODE — NOT FOR PRODUCTION")
    logger.warning("Set DB_CREDENTIAL_PROVIDER=rds_iam | azure_entra | vault")
    logger.warning("for production.")
    logger.warning(bar)


def _warn_if_owner_role(username: str) -> None:
    """Log a warning if the runtime DB user looks like the migration owner role.

    The two-role model (P09) expects the adapter to run as the DML-only app
    role. If the operator accidentally configures DATABASE_URL with the owner
    role, the adapter will run with DDL privileges — functional, but a
    least-privilege regression worth flagging loudly at startup.
    """
    if not username:
        return
    owner_env = os.getenv("DB_OWNER_ROLE", DEFAULT_OWNER_ROLE)
    if username == owner_env or username == DEFAULT_OWNER_ROLE:
        logger.warning(
            "DATABASE_URL is configured with the migration owner role '%s'. "
            "The adapter should run as the DML-only app role (default: "
            "'%s'). Running as the owner role grants the runtime process DDL "
            "privileges, which defeats the two-role least-privilege model. "
            "See deploy/migrations/sql/README.md § Per-deployment vs Runtime.",
            username,
            os.getenv("DB_APP_ROLE", "okta_adapter_app"),
        )


def get_credential_provider() -> DatabaseCredentialProvider:
    """Factory. Selects provider via DB_CREDENTIAL_PROVIDER env var.

    Values: 'static' (default), 'rds_iam', 'azure_entra', 'vault'.
    ``rds_iam`` landed in P10, ``azure_entra`` in P11, ``vault`` in P12.
    """
    kind = os.getenv("DB_CREDENTIAL_PROVIDER", "static").lower()
    if kind == "static":
        return StaticUrlCredentialProvider.from_env()
    if kind == "rds_iam":
        from .credentials_rds import RdsIamCredentialProvider

        return RdsIamCredentialProvider()
    if kind == "azure_entra":
        from .credentials_azure import AzureEntraCredentialProvider

        return AzureEntraCredentialProvider()
    if kind == "vault":
        from .credentials_vault import VaultDbCredentialProvider

        return VaultDbCredentialProvider()
    raise RuntimeError(
        f"Unknown DB_CREDENTIAL_PROVIDER: '{kind}'. "
        f"Valid values: 'static', 'rds_iam', 'azure_entra', 'vault'."
    )
