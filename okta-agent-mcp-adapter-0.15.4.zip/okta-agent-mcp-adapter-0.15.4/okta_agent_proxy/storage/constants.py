"""Shared constants for the database storage / migration layer.

Introduced in DB migration prompt P01. Consumed by later prompts (P02+).
"""

SCHEMA_MIGRATIONS_TABLE = "schema_migrations"
MIN_SCHEMA_VERSION = "002"  # bumped as new migrations land

DEFAULT_OWNER_ROLE = "okta_adapter_owner"
DEFAULT_APP_ROLE = "okta_adapter_app"
DEFAULT_DB_NAME = "gateway_db"
