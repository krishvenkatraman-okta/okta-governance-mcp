"""DCR registration repository (P05).

Mirrors ``PostgresResourceStore`` DCR methods against the
``dcr_registrations`` table (RFC 7591 client records). Rows track both
real-Okta-app clients (``provision_mode='okta_app'``) and virtual/relay
clients (``provision_mode='virtual'``).
"""

from __future__ import annotations

import json
import logging
import uuid
from datetime import datetime
from typing import Any, Dict, List, Optional, cast

import psycopg

from ._base import RepositoryBase, write_audit_log

logger = logging.getLogger(__name__)

_Row = Dict[str, Any]


def _row_to_dict(row: _Row) -> Dict[str, Any]:
    redirect_uris = row.get("redirect_uris")
    if isinstance(redirect_uris, str):
        redirect_uris = json.loads(redirect_uris) if redirect_uris else []
    grant_types = row.get("grant_types")
    if isinstance(grant_types, str):
        grant_types = json.loads(grant_types) if grant_types else []

    created_at = row.get("created_at")
    revoked_at = row.get("revoked_at")
    return {
        "id": row.get("id"),
        "client_id": row.get("client_id"),
        "client_name": row.get("client_name"),
        "agent_name": row.get("agent_name"),
        "okta_app_id": row.get("okta_app_id"),
        "okta_ai_agent_id": row.get("okta_ai_agent_id"),
        "linked_agent_name": row.get("linked_agent_name"),
        "redirect_uris": redirect_uris,
        "grant_types": grant_types,
        "provision_mode": row.get("provision_mode"),
        "source_ip": row.get("source_ip"),
        "status": row.get("status"),
        "created_at": created_at.isoformat() if created_at else None,
        "revoked_at": revoked_at.isoformat() if revoked_at else None,
    }


class DcrRepository(RepositoryBase):
    """CRUD for the ``dcr_registrations`` table."""

    def create(
        self,
        *,
        client_id: str,
        client_name: str,
        agent_name: Optional[str],
        okta_app_id: Optional[str],
        redirect_uris: list,
        grant_types: list,
        provision_mode: str,
        source_ip: Optional[str] = None,
    ) -> Dict[str, Any]:
        reg_id = str(uuid.uuid4())
        try:
            with self._conn() as conn:
                with conn.transaction():
                    with conn.cursor() as cur:
                        try:
                            cur.execute(
                                "INSERT INTO dcr_registrations ("
                                "id, client_id, client_name, agent_name, "
                                "okta_app_id, redirect_uris, grant_types, "
                                "provision_mode, source_ip, status, created_at"
                                ") VALUES ("
                                "%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, NOW())",
                                (
                                    reg_id,
                                    client_id,
                                    client_name,
                                    agent_name,
                                    okta_app_id,
                                    json.dumps(redirect_uris),
                                    json.dumps(grant_types),
                                    provision_mode,
                                    source_ip,
                                    "active",
                                ),
                            )
                        except psycopg.errors.UniqueViolation:
                            logger.warning(
                                "DCR registration already exists: client_id=%s",
                                client_id,
                            )
                            raise
                        cur.execute(
                            "SELECT * FROM dcr_registrations WHERE id = %s",
                            (reg_id,),
                        )
                        row = cast(Optional[_Row], cur.fetchone())
            logger.info("DCR registration created: client_id=%s", client_id)
            return _row_to_dict(row) if row else {}
        except psycopg.errors.UniqueViolation:
            raise
        except Exception as e:
            logger.error("Error creating DCR registration: %s", e)
            raise

    def get(self, client_id: str) -> Optional[Dict[str, Any]]:
        try:
            with self._conn() as conn:
                with conn.cursor() as cur:
                    cur.execute(
                        "SELECT * FROM dcr_registrations WHERE client_id = %s",
                        (client_id,),
                    )
                    row = cast(Optional[_Row], cur.fetchone())
            return _row_to_dict(row) if row else None
        except Exception as e:
            logger.error("Error getting DCR registration: %s", e)
            return None

    def list_all(
        self,
        status: Optional[str] = None,
        limit: int = 100,
        offset: int = 0,
    ) -> List[Dict[str, Any]]:
        sql = "SELECT * FROM dcr_registrations"
        params: list = []
        if status is not None:
            sql += " WHERE status = %s"
            params.append(status)
        sql += " ORDER BY created_at DESC OFFSET %s LIMIT %s"
        params.extend([offset, limit])
        try:
            with self._conn() as conn:
                with conn.cursor() as cur:
                    cur.execute(sql, tuple(params))
                    rows = cast(List[_Row], cur.fetchall())
            return [_row_to_dict(r) for r in rows]
        except Exception as e:
            logger.error("Error listing DCR registrations: %s", e)
            return []

    def revoke(self, client_id: str, user: str = "admin") -> bool:
        try:
            with self._conn() as conn:
                with conn.transaction():
                    with conn.cursor() as cur:
                        cur.execute(
                            "SELECT 1 FROM dcr_registrations WHERE client_id = %s",
                            (client_id,),
                        )
                        if cur.fetchone() is None:
                            return False
                        cur.execute(
                            "UPDATE dcr_registrations SET status = %s, "
                            "revoked_at = %s WHERE client_id = %s",
                            ("revoked", datetime.utcnow(), client_id),
                        )
                        write_audit_log(
                            conn,
                            entity_type="dcr_registration",
                            entity_id=client_id,
                            action="revoked",
                            changes={"status": "revoked"},
                            changed_by=user,
                        )
            logger.info(
                "DCR registration revoked: client_id=%s by %s", client_id, user
            )
            return True
        except Exception as e:
            logger.error("Error revoking DCR registration: %s", e)
            return False

    def update_linked_agent(
        self, client_id: str, linked_agent_name: Optional[str]
    ) -> bool:
        try:
            with self._conn() as conn:
                with conn.transaction():
                    with conn.cursor() as cur:
                        cur.execute(
                            "SELECT 1 FROM dcr_registrations WHERE client_id = %s",
                            (client_id,),
                        )
                        if cur.fetchone() is None:
                            return False
                        cur.execute(
                            "UPDATE dcr_registrations SET linked_agent_name = %s "
                            "WHERE client_id = %s",
                            (linked_agent_name, client_id),
                        )
                        write_audit_log(
                            conn,
                            entity_type="dcr_registration",
                            entity_id=client_id,
                            action="linked" if linked_agent_name else "unlinked",
                            changes={"linked_agent_name": linked_agent_name},
                            changed_by="dcr-handler",
                        )
            return True
        except Exception as e:
            logger.error(
                "Error updating DCR linked agent for %s: %s", client_id, e
            )
            return False
