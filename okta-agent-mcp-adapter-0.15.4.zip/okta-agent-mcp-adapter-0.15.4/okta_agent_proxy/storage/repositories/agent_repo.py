"""Agent repository (P05) — psycopg3 implementation of agent CRUD.

Mirrors :class:`okta_agent_proxy.storage.postgres.PostgresResourceStore`
agent methods bit-for-bit: same columns, same encryption rules, same
audit behaviour. The SQLAlchemy-backed store continues to exist in
parallel until P07; both backends read and write the same ``agents``
table so tests that set up data through one backend can read it from
the other.
"""

from __future__ import annotations

import hashlib
import json
import logging
import re
from datetime import datetime
from typing import Any, Dict, List, Optional, cast

import psycopg

from okta_agent_proxy.crypto.encryption import EncryptionError

from ._base import RepositoryBase, write_audit_log

logger = logging.getLogger(__name__)

_Row = Dict[str, Any]


# Columns projected by ``SELECT *`` on the ``agents`` table. Kept as a
# module-level list so the row-to-dict translation stays in sync with the
# migration-defined schema even when new optional columns land.
_AGENT_COLUMNS = (
    "agent_name",
    "agent_id",
    "client_id",
    "client_secret_encrypted",
    "client_secret_iv",
    "client_secret_tag",
    "private_key_encrypted",
    "private_key_iv",
    "private_key_tag",
    "scopes",
    "enabled",
    "registration_source",
    "dcr_registration_id",
    "cimd_client_id_url",
    "okta_ai_agent_id",
    "principal_id",
    "dcr_selectable",
    "created_by",
    "created_at",
    "updated_by",
    "updated_at",
)


def _row_to_public_dict(row: _Row) -> Dict[str, Any]:
    """Translate an ``agents`` row into the public (secrets-excluded) shape.

    Matches the output of ``AgentModel.to_dict(include_secrets=False)``
    so admin API and cache consumers see an identical surface regardless
    of backend.
    """
    scopes_raw = row.get("scopes")
    scopes = (
        json.loads(scopes_raw) if isinstance(scopes_raw, str) and scopes_raw else (scopes_raw or [])
    )
    created_at = row.get("created_at")
    updated_at = row.get("updated_at")
    return {
        "agent_name": row.get("agent_name"),
        "agent_id": row.get("agent_id"),
        "client_id": row.get("client_id"),
        "scopes": scopes,
        "enabled": row.get("enabled"),
        "registration_source": row.get("registration_source") or "manual",
        "dcr_registration_id": row.get("dcr_registration_id"),
        "cimd_client_id_url": row.get("cimd_client_id_url"),
        "okta_ai_agent_id": row.get("okta_ai_agent_id"),
        "principal_id": row.get("principal_id"),
        "dcr_selectable": row.get("dcr_selectable") or False,
        "created_by": row.get("created_by"),
        "created_at": created_at.isoformat() if created_at else None,
        "updated_by": row.get("updated_by"),
        "updated_at": updated_at.isoformat() if updated_at else None,
    }


class AgentRepository(RepositoryBase):
    """CRUD for the ``agents`` table with AES-256-GCM credential fields."""

    # ------------------------------------------------------------------
    # Read helpers
    # ------------------------------------------------------------------

    def _decrypt_credentials(self, row: _Row, agent_dict: Dict[str, Any]) -> None:
        """Decrypt ``client_secret`` and ``private_key`` into ``agent_dict`` in place."""
        try:
            if row.get("client_secret_encrypted"):
                agent_dict["client_secret"] = self._encryption.decrypt(
                    bytes(row["client_secret_encrypted"]),
                    bytes(row["client_secret_iv"]),
                    bytes(row["client_secret_tag"]),
                )
            if row.get("private_key_encrypted"):
                agent_dict["private_key"] = self._encryption.decrypt(
                    bytes(row["private_key_encrypted"]),
                    bytes(row["private_key_iv"]),
                    bytes(row["private_key_tag"]),
                )
        except EncryptionError as e:
            logger.error(
                "Failed to decrypt agent %s credentials: %s",
                row.get("agent_id") or row.get("agent_name"),
                e,
            )

    def _fetch_one(self, where_sql: str, params: tuple, enabled_only: bool) -> Optional[Dict[str, Any]]:
        sql = "SELECT * FROM agents WHERE " + where_sql
        if enabled_only:
            sql += " AND enabled = TRUE"
        try:
            with self._conn() as conn:
                with conn.cursor() as cur:
                    cur.execute(sql, params)
                    row = cast(Optional[_Row], cur.fetchone())
            if row is None:
                return None
            agent_dict = _row_to_public_dict(row)
            self._decrypt_credentials(row, agent_dict)
            return agent_dict
        except Exception as e:
            logger.error("Error fetching agent (%s, %s): %s", where_sql, params, e)
            return None

    def get(self, agent_id: str, enabled_only: bool = True) -> Optional[Dict[str, Any]]:
        return self._fetch_one("agent_id = %s", (agent_id,), enabled_only)

    def get_by_name(self, agent_name: str, enabled_only: bool = True) -> Optional[Dict[str, Any]]:
        return self._fetch_one("agent_name = %s", (agent_name,), enabled_only)

    def get_by_cimd_client_id(
        self, cimd_client_id: str, enabled_only: bool = True
    ) -> Optional[Dict[str, Any]]:
        return self._fetch_one("cimd_client_id_url = %s", (cimd_client_id,), enabled_only)

    def get_by_client_id(
        self, client_id: str, enabled_only: bool = True
    ) -> Optional[Dict[str, Any]]:
        return self._fetch_one("client_id = %s", (client_id,), enabled_only)

    def list_all(self, enabled_only: bool = True) -> List[Dict[str, Any]]:
        sql = "SELECT * FROM agents"
        params: tuple = ()
        if enabled_only:
            sql += " WHERE enabled = TRUE"
        try:
            with self._conn() as conn:
                with conn.cursor() as cur:
                    cur.execute(sql, params)
                    rows = cast(List[_Row], cur.fetchall())
            result = []
            for row in rows:
                agent_dict = _row_to_public_dict(row)
                self._decrypt_credentials(row, agent_dict)
                result.append(agent_dict)
            return result
        except Exception as e:
            logger.error("Error getting all agents: %s", e)
            return []

    # ------------------------------------------------------------------
    # Write
    # ------------------------------------------------------------------

    def create(
        self,
        agent_id: str,
        config: Dict[str, Any],
        user: str = "admin",
        ip_address: Optional[str] = None,
        user_agent: Optional[str] = None,
    ) -> bool:
        client_id = config.get("client_id")
        if not client_id:
            raise KeyError("client_id")

        client_secret = config.get("client_secret")
        private_key = config.get("private_key")

        cs_enc = cs_iv = cs_tag = None
        if client_secret:
            cs_enc, cs_iv, cs_tag = self._encryption.encrypt(client_secret)

        pk_enc = pk_iv = pk_tag = None
        if private_key:
            pk_enc, pk_iv, pk_tag = self._encryption.encrypt(private_key)

        now = datetime.utcnow()
        try:
            with self._conn() as conn:
                with conn.transaction():
                    with conn.cursor() as cur:
                        cur.execute(
                            "SELECT 1 FROM agents WHERE agent_id = %s",
                            (agent_id,),
                        )
                        if cur.fetchone() is not None:
                            logger.warning("Agent %s already exists", agent_id)
                            return False
                        try:
                            cur.execute(
                                "INSERT INTO agents ("
                                "agent_name, agent_id, client_id, "
                                "client_secret_encrypted, client_secret_iv, client_secret_tag, "
                                "private_key_encrypted, private_key_iv, private_key_tag, "
                                "scopes, enabled, cimd_client_id_url, principal_id, "
                                "okta_ai_agent_id, registration_source, dcr_selectable, "
                                "created_by, created_at, updated_at"
                                ") VALUES ("
                                "%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, "
                                "%s, %s, %s, %s, %s, %s)",
                                (
                                    config.get("agent_name", agent_id),
                                    agent_id,
                                    client_id,
                                    cs_enc,
                                    cs_iv,
                                    cs_tag,
                                    pk_enc,
                                    pk_iv,
                                    pk_tag,
                                    json.dumps(config.get("scopes", ["mcp:read"])),
                                    config.get("enabled", True),
                                    config.get("cimd_client_id"),
                                    config.get("principal_id"),
                                    config.get("okta_ai_agent_id"),
                                    config.get("registration_source") or "manual",
                                    bool(config.get("dcr_selectable", False)),
                                    user,
                                    now,
                                    now,
                                ),
                            )
                        except psycopg.errors.UniqueViolation:
                            logger.warning(
                                "Agent %s already exists (unique violation)", agent_id
                            )
                            return False

                        write_audit_log(
                            conn,
                            entity_type="agent",
                            entity_id=agent_id,
                            action="created",
                            changes=config,
                            changed_by=user,
                            ip_address=ip_address,
                            user_agent=user_agent,
                        )
            logger.info("Agent %s created by %s", agent_id, user)
            return True
        except Exception as e:
            logger.error("Error creating agent %s: %s", agent_id, e)
            raise

    def create_cimd(
        self,
        cimd_client_id: str,
        client_name: str,
        domain: str,
        backend_access: Optional[List[str]] = None,
        trust_level: str = "unknown",
    ) -> bool:
        """Auto-provision a minimal agent record for a newly observed CIMD client.

        Matches ``PostgresResourceStore.create_cimd_agent`` — synthesizes
        an ``agent_name``/``agent_id`` from ``client_name`` plus a short
        hash of ``cimd_client_id`` and stores a PLACEHOLDER JWK. CIMD
        clients don't sign JWTs themselves; the real credentials come in
        later via the linked-agent resolution in
        :class:`ClientRegistry`.
        """
        sanitized = re.sub(r"[^a-z0-9]+", "-", client_name.lower()).strip("-")[:200]
        hash_suffix = hashlib.sha256(cimd_client_id.encode()).hexdigest()[:8]
        agent_name = f"{sanitized}-{hash_suffix}"
        agent_id = agent_name

        placeholder_jwk = json.dumps(
            {
                "kty": "RSA",
                "n": "PLACEHOLDER",
                "e": "AQAB",
                "d": "PLACEHOLDER",
                "kid": f"cimd-{hash_suffix}",
                "use": "sig",
                "alg": "RS256",
            }
        )

        pk_enc, pk_iv, pk_tag = self._encryption.encrypt(placeholder_jwk)
        now = datetime.utcnow()

        try:
            with self._conn() as conn:
                with conn.transaction():
                    with conn.cursor() as cur:
                        cur.execute(
                            "SELECT 1 FROM agents WHERE agent_id = %s",
                            (agent_id,),
                        )
                        if cur.fetchone() is not None:
                            return False
                        try:
                            cur.execute(
                                "INSERT INTO agents ("
                                "agent_name, agent_id, client_id, "
                                "private_key_encrypted, private_key_iv, private_key_tag, "
                                "scopes, enabled, registration_source, cimd_client_id_url, "
                                "created_by, created_at, updated_at"
                                ") VALUES ("
                                "%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)",
                                (
                                    agent_name,
                                    agent_id,
                                    cimd_client_id,
                                    pk_enc,
                                    pk_iv,
                                    pk_tag,
                                    json.dumps([]),
                                    True,
                                    "cimd",
                                    cimd_client_id,
                                    "cimd-auto-provision",
                                    now,
                                    now,
                                ),
                            )
                        except psycopg.errors.UniqueViolation:
                            return False

                        write_audit_log(
                            conn,
                            entity_type="agent",
                            entity_id=agent_id,
                            action="created",
                            changes={
                                "registration_source": "cimd",
                                "domain": domain,
                                "trust_level": trust_level,
                            },
                            changed_by="cimd-auto-provision",
                        )
            logger.info(
                "CIMD auto-provisioned agent %s (domain=%s, trust=%s)",
                agent_id,
                domain,
                trust_level,
            )
            return True
        except Exception as e:
            logger.error("Error creating CIMD agent for %s: %s", cimd_client_id, e)
            raise

    def update(
        self,
        agent_id: str,
        config: Dict[str, Any],
        user: str = "admin",
        ip_address: Optional[str] = None,
        user_agent: Optional[str] = None,
    ) -> bool:
        try:
            with self._conn() as conn:
                with conn.transaction():
                    with conn.cursor() as cur:
                        cur.execute(
                            "SELECT * FROM agents WHERE agent_id = %s",
                            (agent_id,),
                        )
                        row = cast(Optional[_Row], cur.fetchone())
                        if row is None:
                            logger.warning("Agent %s not found for update", agent_id)
                            return False

                        changes: Dict[str, Any] = {}
                        set_clauses: List[str] = []
                        params: List[Any] = []

                        if "client_id" in config and config["client_id"] != row["client_id"]:
                            changes["client_id"] = {
                                "old": row["client_id"],
                                "new": config["client_id"],
                            }
                            set_clauses.append("client_id = %s")
                            params.append(config["client_id"])

                        if "client_secret" in config:
                            enc, iv, tag = self._encryption.encrypt(config["client_secret"])
                            set_clauses.append(
                                "client_secret_encrypted = %s, "
                                "client_secret_iv = %s, "
                                "client_secret_tag = %s"
                            )
                            params.extend([enc, iv, tag])
                            changes["client_secret"] = "updated (encrypted)"

                        if "private_key" in config:
                            enc, iv, tag = self._encryption.encrypt(config["private_key"])
                            set_clauses.append(
                                "private_key_encrypted = %s, "
                                "private_key_iv = %s, "
                                "private_key_tag = %s"
                            )
                            params.extend([enc, iv, tag])
                            changes["private_key"] = "updated (encrypted)"

                        if "scopes" in config:
                            new_scopes = json.dumps(config["scopes"])
                            if new_scopes != row["scopes"]:
                                old_scopes = (
                                    json.loads(row["scopes"])
                                    if isinstance(row["scopes"], str) and row["scopes"]
                                    else row["scopes"]
                                )
                                changes["scopes"] = {
                                    "old": old_scopes,
                                    "new": config["scopes"],
                                }
                                set_clauses.append("scopes = %s")
                                params.append(new_scopes)

                        if "enabled" in config and bool(config["enabled"]) != bool(row["enabled"]):
                            changes["enabled"] = {
                                "old": row["enabled"],
                                "new": config["enabled"],
                            }
                            set_clauses.append("enabled = %s")
                            params.append(config["enabled"])

                        if "cimd_client_id" in config:
                            new_cimd = config["cimd_client_id"] or None
                            if new_cimd != row["cimd_client_id_url"]:
                                changes["cimd_client_id_url"] = {
                                    "old": row["cimd_client_id_url"],
                                    "new": new_cimd,
                                }
                                set_clauses.append("cimd_client_id_url = %s")
                                params.append(new_cimd)

                        if "principal_id" in config:
                            new_principal = config["principal_id"] or None
                            if new_principal != row["principal_id"]:
                                changes["principal_id"] = {
                                    "old": row["principal_id"],
                                    "new": new_principal,
                                }
                                set_clauses.append("principal_id = %s")
                                params.append(new_principal)

                        if "okta_ai_agent_id" in config:
                            new_okta_id = config["okta_ai_agent_id"] or None
                            if new_okta_id != row["okta_ai_agent_id"]:
                                changes["okta_ai_agent_id"] = {
                                    "old": row["okta_ai_agent_id"],
                                    "new": new_okta_id,
                                }
                                set_clauses.append("okta_ai_agent_id = %s")
                                params.append(new_okta_id)

                        if "registration_source" in config:
                            new_source = config["registration_source"] or "manual"
                            if new_source != (row["registration_source"] or "manual"):
                                changes["registration_source"] = {
                                    "old": row["registration_source"],
                                    "new": new_source,
                                }
                                set_clauses.append("registration_source = %s")
                                params.append(new_source)

                        if "dcr_selectable" in config:
                            new_val = bool(config["dcr_selectable"])
                            if new_val != bool(row["dcr_selectable"] or False):
                                changes["dcr_selectable"] = {
                                    "old": bool(row["dcr_selectable"] or False),
                                    "new": new_val,
                                }
                                set_clauses.append("dcr_selectable = %s")
                                params.append(new_val)

                        set_clauses.append("updated_by = %s")
                        params.append(user)
                        set_clauses.append("updated_at = %s")
                        params.append(datetime.utcnow())
                        params.append(agent_id)

                        cur.execute(
                            "UPDATE agents SET "
                            + ", ".join(set_clauses)
                            + " WHERE agent_id = %s",
                            tuple(params),
                        )

                        write_audit_log(
                            conn,
                            entity_type="agent",
                            entity_id=agent_id,
                            action="updated",
                            changes=changes,
                            changed_by=user,
                            ip_address=ip_address,
                            user_agent=user_agent,
                        )

            logger.info(
                "Agent %s updated by %s (%d changes)", agent_id, user, len(changes)
            )
            return True
        except Exception as e:
            logger.error("Error updating agent %s: %s", agent_id, e)
            raise

    def delete(
        self,
        agent_id: str,
        user: str = "admin",
        ip_address: Optional[str] = None,
        user_agent: Optional[str] = None,
    ) -> bool:
        try:
            with self._conn() as conn:
                with conn.transaction():
                    with conn.cursor() as cur:
                        cur.execute(
                            "SELECT * FROM agents WHERE agent_id = %s",
                            (agent_id,),
                        )
                        row = cast(Optional[_Row], cur.fetchone())
                        if row is None:
                            logger.warning(
                                "Agent %s not found for deletion", agent_id
                            )
                            return False
                        old_config = _row_to_public_dict(row)

                        cur.execute(
                            "DELETE FROM agents WHERE agent_id = %s",
                            (agent_id,),
                        )
                        write_audit_log(
                            conn,
                            entity_type="agent",
                            entity_id=agent_id,
                            action="deleted",
                            changes=old_config,
                            changed_by=user,
                            ip_address=ip_address,
                            user_agent=user_agent,
                        )
            logger.info("Agent %s deleted by %s", agent_id, user)
            return True
        except Exception as e:
            logger.error("Error deleting agent %s: %s", agent_id, e)
            raise

    def set_enabled(
        self,
        agent_id: str,
        enabled: bool,
        user: str = "admin",
        ip_address: Optional[str] = None,
        user_agent: Optional[str] = None,
    ) -> bool:
        action = "enabled" if enabled else "disabled"
        try:
            with self._conn() as conn:
                with conn.transaction():
                    with conn.cursor() as cur:
                        cur.execute(
                            "SELECT enabled FROM agents WHERE agent_id = %s",
                            (agent_id,),
                        )
                        row = cast(Optional[_Row], cur.fetchone())
                        if row is None:
                            return False
                        if bool(row["enabled"]) == enabled:
                            logger.debug("Agent %s already %s", agent_id, action)
                            return True
                        cur.execute(
                            "UPDATE agents SET enabled = %s, updated_by = %s, "
                            "updated_at = %s WHERE agent_id = %s",
                            (enabled, user, datetime.utcnow(), agent_id),
                        )
                        write_audit_log(
                            conn,
                            entity_type="agent",
                            entity_id=agent_id,
                            action=action,
                            changes={"enabled": enabled},
                            changed_by=user,
                            ip_address=ip_address,
                            user_agent=user_agent,
                        )
            logger.info("Agent %s %s by %s", agent_id, action, user)
            return True
        except Exception as e:
            logger.error(
                "Error toggling agent %s enabled=%s: %s", agent_id, enabled, e
            )
            raise

    # ------------------------------------------------------------------
    # Audit
    # ------------------------------------------------------------------

    def get_audit_log(self, agent_id: str, limit: int = 100) -> List[Dict[str, Any]]:
        try:
            with self._conn() as conn:
                with conn.cursor() as cur:
                    cur.execute(
                        "SELECT * FROM audit_log "
                        "WHERE entity_type = %s AND entity_id = %s "
                        "ORDER BY changed_at DESC LIMIT %s",
                        ("agent", agent_id, limit),
                    )
                    rows = cast(List[_Row], cur.fetchall())
            return [_audit_row_to_dict(r) for r in rows]
        except Exception as e:
            logger.error("Error getting agent audit log: %s", e)
            return []


def _audit_row_to_dict(row: _Row) -> Dict[str, Any]:
    changed_at = row.get("changed_at")
    changes = row.get("changes")
    if isinstance(changes, str) and changes:
        try:
            changes = json.loads(changes)
        except json.JSONDecodeError:
            pass
    return {
        "id": row.get("id"),
        "entity_type": row.get("entity_type"),
        "entity_id": row.get("entity_id"),
        "action": row.get("action"),
        "changes": changes,
        "changed_by": row.get("changed_by"),
        "changed_at": changed_at.isoformat() if changed_at else None,
        "ip_address": row.get("ip_address"),
        "user_agent": row.get("user_agent"),
    }
