"""Shared helpers for psycopg3 repositories (P04+).

Provides the ``RepositoryBase`` mix-in that holds the ``DatabasePool`` +
``EncryptionService`` pair, plus a module-level ``write_audit_log`` helper
that mirrors ``PostgresResourceStore._create_audit_log``. The helper is
kept module-level so that repositories can call it without needing a
reference back to the parent store.
"""

from __future__ import annotations

import json
import logging
import uuid
from contextlib import contextmanager
from typing import Any, Dict, Iterator, Optional

import psycopg

from okta_agent_proxy.storage.pool import DatabasePool

logger = logging.getLogger(__name__)


class RepositoryBase:
    """Common ``__init__`` + connection helper for repositories."""

    def __init__(self, pool: DatabasePool, encryption_service):
        self._pool = pool
        self._encryption = encryption_service

    @contextmanager
    def _conn(self) -> Iterator[psycopg.Connection]:
        with self._pool.connection() as conn:
            yield conn


def write_audit_log(
    conn: psycopg.Connection,
    *,
    entity_type: str,
    entity_id: str,
    action: str,
    changes: Optional[Dict[str, Any]],
    changed_by: str,
    ip_address: Optional[str] = None,
    user_agent: Optional[str] = None,
) -> None:
    """Insert a row into ``audit_log`` using the existing transaction.

    Mirrors the semantics of
    ``PostgresResourceStore._create_audit_log`` — audit failures are
    swallowed so they never break the primary operation. The caller is
    expected to manage the transaction around this call.
    """
    try:
        with conn.cursor() as cur:
            cur.execute(
                "INSERT INTO audit_log "
                "(id, entity_type, entity_id, action, changes, changed_by, "
                "changed_at, ip_address, user_agent) "
                "VALUES (%s, %s, %s, %s, %s, %s, NOW(), %s, %s)",
                (
                    str(uuid.uuid4()),
                    entity_type,
                    entity_id,
                    action,
                    json.dumps(changes) if changes is not None else None,
                    changed_by,
                    ip_address,
                    user_agent,
                ),
            )
    except Exception as e:  # pragma: no cover - audit failures never raise
        logger.error("Failed to write audit log (%s:%s %s): %s",
                     entity_type, entity_id, action, e)
