"""Gateway-config repository (P06) — psycopg3 port of the gateway_config table.

Mirrors ``PostgresResourceStore.get_gateway_config`` /
``get_gateway_config_entry`` / ``set_gateway_config`` / ``delete_gateway_config``
bit-for-bit: same JSON-in-TEXT encoding, same audit-log writes, same
None-distinguishes-missing-from-set semantics.
"""

from __future__ import annotations

import json
import logging
import uuid
from datetime import datetime
from typing import Any, Dict, Optional, cast

from ._base import RepositoryBase, write_audit_log

logger = logging.getLogger(__name__)

_Row = Dict[str, Any]


class GatewayConfigRepository(RepositoryBase):
    """CRUD for the ``gateway_config`` key/value table."""

    # ------------------------------------------------------------------
    # Read
    # ------------------------------------------------------------------

    def get(self, key: str) -> Optional[Any]:
        """Return the parsed JSON value for ``key``, or ``None`` if absent."""
        try:
            with self._conn() as conn:
                with conn.cursor() as cur:
                    cur.execute(
                        "SELECT config_value FROM gateway_config "
                        "WHERE config_key = %s",
                        (key,),
                    )
                    row = cast(Optional[_Row], cur.fetchone())
            if row is None:
                return None
            return json.loads(row["config_value"])
        except Exception as e:
            logger.error("Error getting gateway config '%s': %s", key, e)
            return None

    def get_entry(self, key: str) -> Optional[Dict[str, Any]]:
        """Return ``{value, updated_at, updated_by}`` or ``None``."""
        try:
            with self._conn() as conn:
                with conn.cursor() as cur:
                    cur.execute(
                        "SELECT config_value, updated_at, updated_by "
                        "FROM gateway_config WHERE config_key = %s",
                        (key,),
                    )
                    row = cast(Optional[_Row], cur.fetchone())
            if row is None:
                return None
            updated_at = row.get("updated_at")
            return {
                "value": json.loads(row["config_value"]),
                "updated_at": updated_at.isoformat() if updated_at else None,
                "updated_by": row.get("updated_by"),
            }
        except Exception as e:
            logger.error("Error getting gateway config entry '%s': %s", key, e)
            return None

    # ------------------------------------------------------------------
    # Write
    # ------------------------------------------------------------------

    def set(
        self,
        key: str,
        value: Any,
        user: str = "admin",
        description: Optional[str] = None,
        ip_address: Optional[str] = None,
        user_agent: Optional[str] = None,
    ) -> None:
        """Upsert ``key → value``. Writes an audit entry."""
        serialized = json.dumps(value)
        now = datetime.utcnow()
        try:
            with self._conn() as conn:
                with conn.transaction():
                    with conn.cursor() as cur:
                        cur.execute(
                            "SELECT id, description FROM gateway_config "
                            "WHERE config_key = %s",
                            (key,),
                        )
                        row = cast(Optional[_Row], cur.fetchone())
                        if row is None:
                            cur.execute(
                                "INSERT INTO gateway_config ("
                                "id, config_key, config_value, description, "
                                "updated_by, updated_at"
                                ") VALUES (%s, %s, %s, %s, %s, %s)",
                                (
                                    str(uuid.uuid4()),
                                    key,
                                    serialized,
                                    description,
                                    user,
                                    now,
                                ),
                            )
                        else:
                            # Preserve existing description if the caller
                            # didn't provide one (matches the legacy
                            # behaviour in ``PostgresResourceStore``).
                            new_description = (
                                description
                                if description is not None
                                else row.get("description")
                            )
                            cur.execute(
                                "UPDATE gateway_config SET "
                                "config_value = %s, description = %s, "
                                "updated_by = %s, updated_at = %s "
                                "WHERE config_key = %s",
                                (serialized, new_description, user, now, key),
                            )

                        snapshot = serialized
                        if len(snapshot) > 500:
                            snapshot = snapshot[:500] + "...(truncated)"
                        write_audit_log(
                            conn,
                            entity_type="gateway_config",
                            entity_id=f"gateway_config:{key}",
                            action="gateway_config.set",
                            changes={"value": snapshot},
                            changed_by=user,
                            ip_address=ip_address,
                            user_agent=user_agent,
                        )
        except Exception as e:
            logger.error("Error setting gateway config '%s': %s", key, e)
            raise

    def delete(
        self,
        key: str,
        user: str = "admin",
        ip_address: Optional[str] = None,
        user_agent: Optional[str] = None,
    ) -> bool:
        """Delete ``key``. Returns True if deleted, False if not found."""
        try:
            with self._conn() as conn:
                with conn.transaction():
                    with conn.cursor() as cur:
                        cur.execute(
                            "DELETE FROM gateway_config "
                            "WHERE config_key = %s",
                            (key,),
                        )
                        if cur.rowcount == 0:
                            return False
                        write_audit_log(
                            conn,
                            entity_type="gateway_config",
                            entity_id=f"gateway_config:{key}",
                            action="gateway_config.delete",
                            changes={"deleted_key": key},
                            changed_by=user,
                            ip_address=ip_address,
                            user_agent=user_agent,
                        )
            return True
        except Exception as e:
            logger.error("Error deleting gateway config '%s': %s", key, e)
            return False
