"""psycopg3 repository layer for the configuration store.

Repositories are introduced incrementally across DB migration prompts P04–P06.
Each repository wraps a single logical slice of the storage surface and uses
psycopg3 directly, with no SQLAlchemy dependency.
"""
