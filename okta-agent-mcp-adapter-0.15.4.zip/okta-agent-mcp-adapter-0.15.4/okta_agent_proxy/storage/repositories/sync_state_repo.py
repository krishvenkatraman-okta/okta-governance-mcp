"""Okta sync-state repository (P06) — psycopg3 port of ``okta_sync_state``.

Mirrors ``ResourceStore.save_sync_state`` / ``get_latest_sync_state`` in
``okta_agent_proxy.storage.postgres``: each call inserts a new row and
the most-recent row is the current state.
"""

from __future__ import annotations

import logging
from datetime import datetime
from typing import Any, Dict, Optional, cast

from ._base import RepositoryBase

logger = logging.getLogger(__name__)

_Row = Dict[str, Any]


class SyncStateRepository(RepositoryBase):
    """CRUD for the ``okta_sync_state`` append-only table."""

    def save(
        self,
        status: str,
        resources_count: Optional[int] = None,
        unresolved_count: int = 0,
        duration_ms: int = 0,
        backends_count: Optional[int] = None,
    ) -> None:
        """Persist a sync-state snapshot.

        Accepts both the modern ``resources_count`` and the legacy
        ``backends_count`` keyword (the latter is retained so callers
        migrating off the SQLAlchemy ``ResourceStore`` don't have to
        flip all call sites at once).
        """
        count = (
            resources_count
            if resources_count is not None
            else (backends_count or 0)
        )
        now = datetime.utcnow()
        try:
            with self._conn() as conn:
                with conn.transaction():
                    with conn.cursor() as cur:
                        cur.execute(
                            "INSERT INTO okta_sync_state ("
                            "last_sync_at, status, resources_count, "
                            "unresolved_count, sync_duration_ms"
                            ") VALUES (%s, %s, %s, %s, %s)",
                            (now, status, count, unresolved_count, duration_ms),
                        )
        except Exception:
            logger.exception("Error saving sync state")
            raise

    def get_latest(self) -> Optional[Dict[str, Any]]:
        """Return the most recent sync-state row, or ``None`` if none."""
        try:
            with self._conn() as conn:
                with conn.cursor() as cur:
                    cur.execute(
                        "SELECT last_sync_at, status, resources_count, "
                        "unresolved_count, sync_duration_ms "
                        "FROM okta_sync_state "
                        "ORDER BY id DESC LIMIT 1"
                    )
                    row = cast(Optional[_Row], cur.fetchone())
            if row is None:
                return None
            last_sync_at = row.get("last_sync_at")
            return {
                "last_sync_at": last_sync_at.isoformat()
                if last_sync_at
                else None,
                "status": row.get("status"),
                "resources_count": row.get("resources_count"),
                "unresolved_count": row.get("unresolved_count"),
                "sync_duration_ms": row.get("sync_duration_ms"),
            }
        except Exception:
            logger.exception("Error getting latest sync state")
            return None
