"""Resource repository — psycopg3 implementation.

Owns every database read/write against the collapsed ``resources`` table.
Each row represents one (agent, Okta Managed Connection) pair: provenance
and sync state come from Okta, routing and lifecycle come from the admin.

Public surface:

* **Sync-owned**: ``upsert_synced`` / ``update_sync_fields`` — invoked by
  the Okta syncer to materialize connection state. Never exposes sync
  columns to admin editing.
* **Admin-editable**: ``update_editable`` — invoked by admin routes to
  change ``url`` / ``name`` / ``type`` / ``description`` / ``paths`` /
  ``config`` / ``tags`` / ``enabled`` / ``timeout_seconds``.
* **Lookup**: ``get_all`` / ``get_by_name`` / ``get_by_id`` /
  ``get_by_agent_connection`` / ``get_by_connection_resource_id``. L1
  cache rebuilt via ``load_cache``.
* **Deletion**: ``delete_by_id`` / ``delete_by_name``. FK cascade from
  ``agents`` also clears per-agent rows.
* **Audit**: ``get_audit_log``.

Sync-state persistence is delegated to :class:`SyncStateRepository`.
"""

from __future__ import annotations

import json
import logging
from datetime import datetime
from typing import Any, Dict, List, Optional, cast

from ._base import RepositoryBase, write_audit_log

logger = logging.getLogger(__name__)

_Row = Dict[str, Any]


# ---------------------------------------------------------------------------
# Row → object translation
# ---------------------------------------------------------------------------


def _parse_json_field(value: Any, default):
    if isinstance(value, str):
        if not value:
            return default
        try:
            return json.loads(value)
        except json.JSONDecodeError:
            return default
    if value is None:
        return default
    return value


def _row_to_admin_dict(row: _Row) -> Dict[str, Any]:
    """Translate a ``resources`` row into the admin-API dict shape."""
    config = _parse_json_field(row.get("config"), {})
    tags = _parse_json_field(row.get("tags"), [])
    scopes = _parse_json_field(row.get("scopes"), [])
    paths = _parse_json_field(row.get("paths"), [])
    auth_config = _parse_json_field(row.get("auth_config"), {})
    metadata = _parse_json_field(row.get("metadata"), {})

    created_at = row.get("created_at")
    updated_at = row.get("updated_at")
    return {
        "id": row.get("id"),
        "agent_id": row.get("agent_id"),
        "connection_id": row.get("connection_id"),
        "name": row.get("name"),
        "type": row.get("type") or "mcp",
        "url": row.get("url") or "",
        "description": row.get("description") or "",
        "connection_type": row.get("connection_type"),
        "connection_resource_id": row.get("connection_resource_id"),
        "scopes": scopes if isinstance(scopes, list) else [],
        "scope_condition": row.get("scope_condition") or "ALLOW_ALL",
        "auth_method": row.get("auth_method"),
        "metadata": metadata if isinstance(metadata, dict) else {},
        "config": config if isinstance(config, dict) else {},
        "tags": tags if isinstance(tags, list) else [],
        "paths": paths if isinstance(paths, list) else [],
        "auth_config": auth_config if isinstance(auth_config, dict) else {},
        "timeout_seconds": row.get("timeout_seconds"),
        "enabled": row.get("enabled"),
        "created_by": row.get("created_by"),
        "created_at": created_at.isoformat() if created_at else None,
        "updated_by": row.get("updated_by"),
        "updated_at": updated_at.isoformat() if updated_at else None,
    }


def _row_to_resource(row: _Row):
    """Translate a ``resources`` row into a Resource object."""
    from okta_agent_proxy.resources.models import Resource

    config = _parse_json_field(row.get("config"), {})
    tags = _parse_json_field(row.get("tags"), [])
    scopes = _parse_json_field(row.get("scopes"), [])
    metadata = _parse_json_field(row.get("metadata"), {})

    enabled = row.get("enabled")
    return Resource(
        resource_id=row.get("connection_resource_id") or "",
        name=row["name"],
        mcp_url=row.get("url") or "",
        protocol=row.get("type") or "mcp",
        description=row.get("description") or "",
        config=config if isinstance(config, dict) else {},
        tags=tags if isinstance(tags, list) else [],
        enabled=enabled if enabled is not None else True,
        agent_id=row.get("agent_id") or "",
        connection_id=row.get("connection_id") or "",
        connection_type=row.get("connection_type") or "",
        auth_method=row.get("auth_method") or "",
        metadata=metadata if isinstance(metadata, dict) else {},
        scopes=scopes if isinstance(scopes, list) else [],
        scope_condition=row.get("scope_condition") or "ALLOW_ALL",
    )


def _audit_row_to_dict(row: _Row) -> Dict[str, Any]:
    changed_at = row.get("changed_at")
    changes = row.get("changes")
    if isinstance(changes, str) and changes:
        try:
            changes = json.loads(changes)
        except json.JSONDecodeError:
            pass
    return {
        "id": row.get("id"),
        "entity_type": row.get("entity_type"),
        "entity_id": row.get("entity_id"),
        "action": row.get("action"),
        "changes": changes,
        "changed_by": row.get("changed_by"),
        "changed_at": changed_at.isoformat() if changed_at else None,
        "ip_address": row.get("ip_address"),
        "user_agent": row.get("user_agent"),
    }


# ---------------------------------------------------------------------------
# Column sets
# ---------------------------------------------------------------------------

# Columns that the Okta syncer owns. Admin edits MUST NOT touch these.
_SYNC_OWNED_COLUMNS = {
    "connection_type",
    "connection_resource_id",
    "scopes",
    "scope_condition",
    "auth_method",
    "metadata",
}

# Columns the admin API may edit via ``update_editable``.
_EDITABLE_COLUMNS = {
    "name",
    "type",
    "url",
    "description",
    "paths",
    "config",
    "tags",
    "auth_config",
    "timeout_seconds",
    "enabled",
}

# Columns selected when rebuilding the cache.
_CACHE_SELECT = (
    "id, agent_id, connection_id, name, type, url, description, "
    "connection_type, connection_resource_id, scopes, scope_condition, "
    "auth_method, metadata, config, tags, paths, auth_config, "
    "timeout_seconds, enabled, created_by, created_at, updated_by, updated_at"
)


def _encode_for_column(column: str, value: Any) -> Any:
    """Serialize list/dict values for TEXT-typed columns; pass JSONB through."""
    if column == "paths":
        return json.dumps(value) if not isinstance(value, str) else value
    if column == "auth_config":
        return json.dumps(value) if not isinstance(value, str) else value
    if column in ("config", "tags", "scopes", "metadata"):
        # JSONB columns — psycopg encodes list/dict directly when using
        # json.dumps; keep the call explicit to match the rest of the
        # codebase's style.
        return json.dumps(value) if not isinstance(value, str) else value
    return value


# ---------------------------------------------------------------------------
# Repository
# ---------------------------------------------------------------------------


class ResourceRepository(RepositoryBase):
    """CRUD + L1 cache for the collapsed ``resources`` table."""

    def __init__(self, pool, encryption_service=None):
        super().__init__(pool, encryption_service)

        self._cache_by_name: Dict[str, Any] = {}
        self._cache_by_connection_id: Dict[str, List[Any]] = {}
        self._cache_by_connection_resource_id: Dict[str, List[Any]] = {}
        self._last_loaded: Optional[datetime] = None

        from .sync_state_repo import SyncStateRepository

        self._sync_state = SyncStateRepository(pool, encryption_service=None)

    # ==================================================================
    # Lookup / cache
    # ==================================================================

    def load_cache(self) -> int:
        """Populate the L1 caches. Returns row count."""
        with self._conn() as conn:
            with conn.cursor() as cur:
                cur.execute(f"SELECT {_CACHE_SELECT} FROM resources")
                rows = cast(List[_Row], cur.fetchall())

        self._cache_by_name = {}
        self._cache_by_connection_id = {}
        self._cache_by_connection_resource_id = {}
        for row in rows:
            entry = _row_to_resource(row)
            self._cache_by_name[row["name"]] = entry
            conn_id = row.get("connection_id") or ""
            if conn_id:
                self._cache_by_connection_id.setdefault(conn_id, []).append(entry)
            conn_res_id = row.get("connection_resource_id") or ""
            if conn_res_id:
                self._cache_by_connection_resource_id.setdefault(
                    conn_res_id, []
                ).append(entry)
        self._last_loaded = datetime.utcnow()
        return len(self._cache_by_name)

    def get_all(self) -> List[Any]:
        return list(self._cache_by_name.values())

    def get_by_name(self, name: str):
        return self._cache_by_name.get(name)

    def get_by_connection_id(self, connection_id: str) -> List[Any]:
        return self._cache_by_connection_id.get(connection_id, [])

    def get_by_connection_resource_id(self, connection_resource_id: str) -> List[Any]:
        return self._cache_by_connection_resource_id.get(
            connection_resource_id, []
        )

    # Backward-compat alias — callers that previously matched on
    # ``connection_resource_id`` (the Okta-extracted resource_id) continue
    # to work.
    get_by_id = get_by_connection_resource_id

    def get_by_agent_connection(
        self, agent_id: str, connection_id: str
    ) -> Optional[Dict[str, Any]]:
        """Return the admin-dict view for the (agent, connection) row, or None."""
        with self._conn() as conn:
            with conn.cursor() as cur:
                cur.execute(
                    f"SELECT {_CACHE_SELECT} FROM resources "
                    "WHERE agent_id = %s AND connection_id = %s",
                    (agent_id, connection_id),
                )
                row = cast(Optional[_Row], cur.fetchone())
        if row is None:
            return None
        return _row_to_admin_dict(row)

    def admin_list(self) -> List[Dict[str, Any]]:
        """Return all rows as admin-API dicts. Includes disabled rows."""
        try:
            with self._conn() as conn:
                with conn.cursor() as cur:
                    cur.execute(
                        f"SELECT {_CACHE_SELECT} FROM resources "
                        "ORDER BY agent_id, connection_id"
                    )
                    rows = cast(List[_Row], cur.fetchall())
            return [_row_to_admin_dict(r) for r in rows]
        except Exception as e:
            logger.error("Error listing resources: %s", e)
            return []

    def admin_get(self, name: str) -> Optional[Dict[str, Any]]:
        try:
            with self._conn() as conn:
                with conn.cursor() as cur:
                    cur.execute(
                        f"SELECT {_CACHE_SELECT} FROM resources WHERE name = %s",
                        (name,),
                    )
                    row = cast(Optional[_Row], cur.fetchone())
            if row is None:
                return None
            return _row_to_admin_dict(row)
        except Exception as e:
            logger.error("Error getting resource %s: %s", name, e)
            return None

    # ==================================================================
    # Sync-owned writes
    # ==================================================================

    def upsert_synced(
        self,
        *,
        agent_id: str,
        connection_id: str,
        name: str,
        connection_type: str,
        scopes: List[str],
        scope_condition: str,
        auth_method: Optional[str],
        metadata: Dict[str, Any],
        connection_resource_id: Optional[str] = None,
        user: str = "syncer",
    ) -> Dict[str, Any]:
        """Insert a new (agent, connection) row or update its sync-owned columns.

        Admin-editable fields keep their existing values on update. New
        rows are created with ``enabled=FALSE`` and empty ``url`` so the
        admin must flip them on before the router serves traffic.
        """
        now = datetime.utcnow()
        try:
            with self._conn() as conn:
                with conn.transaction():
                    with conn.cursor() as cur:
                        cur.execute(
                            "SELECT id FROM resources "
                            "WHERE agent_id = %s AND connection_id = %s",
                            (agent_id, connection_id),
                        )
                        existing = cast(Optional[_Row], cur.fetchone())

                        if existing is None:
                            cur.execute(
                                "INSERT INTO resources ("
                                "agent_id, connection_id, name, type, url, "
                                "description, connection_type, "
                                "connection_resource_id, scopes, "
                                "scope_condition, auth_method, metadata, "
                                "enabled, created_by, created_at, "
                                "updated_by, updated_at"
                                ") VALUES ("
                                "%s, %s, %s, 'mcp', '', '', %s, %s, %s, %s, "
                                "%s, %s, FALSE, %s, %s, %s, %s)",
                                (
                                    agent_id,
                                    connection_id,
                                    name,
                                    connection_type,
                                    connection_resource_id,
                                    json.dumps(scopes),
                                    scope_condition,
                                    auth_method,
                                    json.dumps(metadata),
                                    user,
                                    now,
                                    user,
                                    now,
                                ),
                            )
                            write_audit_log(
                                conn,
                                entity_type="resource",
                                entity_id=name,
                                action="synced_created",
                                changes={
                                    "agent_id": agent_id,
                                    "connection_id": connection_id,
                                    "connection_type": connection_type,
                                },
                                changed_by=user,
                            )
                        else:
                            cur.execute(
                                "UPDATE resources SET "
                                "connection_type = %s, "
                                "connection_resource_id = %s, "
                                "scopes = %s, "
                                "scope_condition = %s, "
                                "auth_method = %s, "
                                "metadata = %s, "
                                "updated_by = %s, "
                                "updated_at = %s "
                                "WHERE agent_id = %s AND connection_id = %s",
                                (
                                    connection_type,
                                    connection_resource_id,
                                    json.dumps(scopes),
                                    scope_condition,
                                    auth_method,
                                    json.dumps(metadata),
                                    user,
                                    now,
                                    agent_id,
                                    connection_id,
                                ),
                            )

                        cur.execute(
                            f"SELECT {_CACHE_SELECT} FROM resources "
                            "WHERE agent_id = %s AND connection_id = %s",
                            (agent_id, connection_id),
                        )
                        row = cast(_Row, cur.fetchone())
            return _row_to_admin_dict(row)
        except Exception:
            logger.exception(
                "Error upserting synced resource agent=%s connection=%s",
                agent_id, connection_id,
            )
            raise

    def update_sync_fields(
        self,
        *,
        agent_id: str,
        connection_id: str,
        scopes: Optional[List[str]] = None,
        scope_condition: Optional[str] = None,
        auth_method: Optional[str] = None,
        metadata: Optional[Dict[str, Any]] = None,
        connection_type: Optional[str] = None,
        connection_resource_id: Optional[str] = None,
        user: str = "syncer",
    ) -> bool:
        """Update only sync-owned columns for a (agent, connection) row."""
        updates: List[str] = []
        params: List[Any] = []
        if scopes is not None:
            updates.append("scopes = %s")
            params.append(json.dumps(scopes))
        if scope_condition is not None:
            updates.append("scope_condition = %s")
            params.append(scope_condition)
        if auth_method is not None:
            updates.append("auth_method = %s")
            params.append(auth_method)
        if metadata is not None:
            updates.append("metadata = %s")
            params.append(json.dumps(metadata))
        if connection_type is not None:
            updates.append("connection_type = %s")
            params.append(connection_type)
        if connection_resource_id is not None:
            updates.append("connection_resource_id = %s")
            params.append(connection_resource_id)
        if not updates:
            return False
        updates.extend(["updated_by = %s", "updated_at = %s"])
        params.extend([user, datetime.utcnow(), agent_id, connection_id])
        try:
            with self._conn() as conn:
                with conn.transaction():
                    with conn.cursor() as cur:
                        cur.execute(
                            "UPDATE resources SET "
                            + ", ".join(updates)
                            + " WHERE agent_id = %s AND connection_id = %s",
                            tuple(params),
                        )
                        return cur.rowcount > 0
        except Exception:
            logger.exception(
                "Error updating sync fields agent=%s connection=%s",
                agent_id, connection_id,
            )
            raise

    # ==================================================================
    # Admin-editable writes
    # ==================================================================

    def update_editable(
        self,
        name: str,
        updates: Dict[str, Any],
        user: str = "admin",
        ip_address: Optional[str] = None,
        user_agent: Optional[str] = None,
    ) -> Optional[Dict[str, Any]]:
        """Update admin-editable fields. Rejects sync-owned columns."""
        for key in updates:
            if key in _SYNC_OWNED_COLUMNS:
                raise ValueError(
                    f"'{key}' is sync-owned and cannot be edited via the admin API"
                )

        filtered: Dict[str, Any] = {
            k: v for k, v in updates.items() if k in _EDITABLE_COLUMNS
        }
        if not filtered:
            return self.admin_get(name)

        try:
            with self._conn() as conn:
                with conn.transaction():
                    with conn.cursor() as cur:
                        cur.execute(
                            f"SELECT {_CACHE_SELECT} FROM resources WHERE name = %s",
                            (name,),
                        )
                        row = cast(Optional[_Row], cur.fetchone())
                        if row is None:
                            return None

                        old = _row_to_admin_dict(row)
                        changes: Dict[str, Any] = {}
                        set_clauses: List[str] = []
                        params: List[Any] = []
                        for col, new_val in filtered.items():
                            old_val = old.get(col)
                            if new_val != old_val:
                                changes[col] = {"old": old_val, "new": new_val}
                                set_clauses.append(f"{col} = %s")
                                params.append(_encode_for_column(col, new_val))

                        if not set_clauses:
                            return old

                        set_clauses.append("updated_by = %s")
                        params.append(user)
                        set_clauses.append("updated_at = %s")
                        params.append(datetime.utcnow())
                        params.append(name)

                        cur.execute(
                            "UPDATE resources SET "
                            + ", ".join(set_clauses)
                            + " WHERE name = %s",
                            tuple(params),
                        )

                        write_audit_log(
                            conn,
                            entity_type="resource",
                            entity_id=name,
                            action="updated",
                            changes=changes,
                            changed_by=user,
                            ip_address=ip_address,
                            user_agent=user_agent,
                        )

                        # If name changed, return under new name
                        new_name = filtered.get("name", name)
                        cur.execute(
                            f"SELECT {_CACHE_SELECT} FROM resources WHERE name = %s",
                            (new_name,),
                        )
                        refreshed = cast(Optional[_Row], cur.fetchone())
            return _row_to_admin_dict(refreshed) if refreshed else None
        except Exception:
            logger.exception("Error updating resource %s", name)
            raise

    # ==================================================================
    # Deletion
    # ==================================================================

    def delete_by_id(
        self,
        row_id: int,
        user: str = "admin",
        ip_address: Optional[str] = None,
        user_agent: Optional[str] = None,
    ) -> bool:
        try:
            with self._conn() as conn:
                with conn.transaction():
                    with conn.cursor() as cur:
                        cur.execute(
                            f"SELECT {_CACHE_SELECT} FROM resources WHERE id = %s",
                            (row_id,),
                        )
                        row = cast(Optional[_Row], cur.fetchone())
                        if row is None:
                            return False
                        name = row["name"]
                        cur.execute(
                            "DELETE FROM resources WHERE id = %s", (row_id,)
                        )
                        write_audit_log(
                            conn,
                            entity_type="resource",
                            entity_id=name,
                            action="deleted",
                            changes=_row_to_admin_dict(row),
                            changed_by=user,
                            ip_address=ip_address,
                            user_agent=user_agent,
                        )
            return True
        except Exception:
            logger.exception("Error deleting resource id=%s", row_id)
            raise

    def delete_by_name(
        self,
        name: str,
        user: str = "admin",
        ip_address: Optional[str] = None,
        user_agent: Optional[str] = None,
    ) -> bool:
        try:
            with self._conn() as conn:
                with conn.transaction():
                    with conn.cursor() as cur:
                        cur.execute(
                            f"SELECT {_CACHE_SELECT} FROM resources WHERE name = %s",
                            (name,),
                        )
                        row = cast(Optional[_Row], cur.fetchone())
                        if row is None:
                            return False
                        cur.execute(
                            "DELETE FROM resources WHERE name = %s", (name,)
                        )
                        write_audit_log(
                            conn,
                            entity_type="resource",
                            entity_id=name,
                            action="deleted",
                            changes=_row_to_admin_dict(row),
                            changed_by=user,
                            ip_address=ip_address,
                            user_agent=user_agent,
                        )
            return True
        except Exception:
            logger.exception("Error deleting resource %s", name)
            raise

    def delete_for_agent_connection(
        self, agent_id: str, connection_id: str, user: str = "syncer"
    ) -> bool:
        try:
            with self._conn() as conn:
                with conn.transaction():
                    with conn.cursor() as cur:
                        cur.execute(
                            "DELETE FROM resources "
                            "WHERE agent_id = %s AND connection_id = %s",
                            (agent_id, connection_id),
                        )
                        return cur.rowcount > 0
        except Exception:
            logger.exception(
                "Error deleting resource for agent=%s connection=%s",
                agent_id, connection_id,
            )
            raise

    # ==================================================================
    # Audit log
    # ==================================================================

    def get_audit_log(
        self,
        resource_name: Optional[str] = None,
        limit: int = 100,
    ) -> List[Dict[str, Any]]:
        try:
            with self._conn() as conn:
                with conn.cursor() as cur:
                    if resource_name:
                        cur.execute(
                            "SELECT * FROM audit_log "
                            "WHERE entity_type = %s AND entity_id = %s "
                            "ORDER BY changed_at DESC LIMIT %s",
                            ("resource", resource_name, limit),
                        )
                    else:
                        cur.execute(
                            "SELECT * FROM audit_log ORDER BY changed_at DESC "
                            "LIMIT %s",
                            (limit,),
                        )
                    rows = cast(List[_Row], cur.fetchall())
            return [_audit_row_to_dict(r) for r in rows]
        except Exception as e:
            logger.error("Error getting audit log: %s", e)
            return []

    # ==================================================================
    # Sync state delegate
    # ==================================================================

    def save_sync_state(
        self,
        status,
        resources_count=None,
        unresolved_count=0,
        duration_ms=0,
        backends_count=None,
    ):
        self._sync_state.save(
            status=status,
            resources_count=resources_count,
            unresolved_count=unresolved_count,
            duration_ms=duration_ms,
            backends_count=backends_count,
        )

    def get_latest_sync_state(self) -> Optional[Dict[str, Any]]:
        return self._sync_state.get_latest()
