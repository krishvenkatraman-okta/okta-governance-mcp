"""Audit-log repository (P06) — canonical psycopg3 reader for ``audit_log``.

:class:`PostgresResourceStore` splits audit-log reads across two helpers
(``get_audit_log`` for resources, ``get_agent_audit_log`` for agents). P06
consolidates them into a single repository so every caller goes through
the same SQL path. :class:`PsycopgResourceStore` delegates to this class
for both methods; resource/agent repositories keep their existing read
helpers for backwards compatibility until P07 retires the duplicate code.
"""

from __future__ import annotations

import json
import logging
from typing import Any, Dict, List, Optional, cast

from ._base import RepositoryBase

logger = logging.getLogger(__name__)

_Row = Dict[str, Any]


def _row_to_dict(row: _Row) -> Dict[str, Any]:
    """Translate an ``audit_log`` row into the public dict shape."""
    changed_at = row.get("changed_at")
    changes = row.get("changes")
    if isinstance(changes, str) and changes:
        try:
            changes = json.loads(changes)
        except json.JSONDecodeError:
            pass
    return {
        "id": row.get("id"),
        "entity_type": row.get("entity_type"),
        "entity_id": row.get("entity_id"),
        "action": row.get("action"),
        "changes": changes,
        "changed_by": row.get("changed_by"),
        "changed_at": changed_at.isoformat() if changed_at else None,
        "ip_address": row.get("ip_address"),
        "user_agent": row.get("user_agent"),
    }


class AuditRepository(RepositoryBase):
    """Read-only access to the ``audit_log`` table."""

    def get_audit_log(
        self,
        resource_name: Optional[str] = None,
        limit: int = 100,
    ) -> List[Dict[str, Any]]:
        """Return audit-log entries, optionally filtered to a resource.

        When ``resource_name`` is provided the query filters
        ``entity_type='resource' AND entity_id=resource_name``; when
        omitted it returns every audit row regardless of entity type,
        most-recent first. Matches ``PostgresResourceStore.get_audit_log``.
        """
        try:
            with self._conn() as conn:
                with conn.cursor() as cur:
                    if resource_name:
                        cur.execute(
                            "SELECT * FROM audit_log "
                            "WHERE entity_type = %s AND entity_id = %s "
                            "ORDER BY changed_at DESC LIMIT %s",
                            ("resource", resource_name, limit),
                        )
                    else:
                        cur.execute(
                            "SELECT * FROM audit_log "
                            "ORDER BY changed_at DESC LIMIT %s",
                            (limit,),
                        )
                    rows = cast(List[_Row], cur.fetchall())
            return [_row_to_dict(r) for r in rows]
        except Exception as e:
            logger.error("Error getting audit log: %s", e)
            return []

    def get_agent_audit_log(
        self, agent_id: str, limit: int = 100
    ) -> List[Dict[str, Any]]:
        """Return audit-log entries for a specific agent."""
        try:
            with self._conn() as conn:
                with conn.cursor() as cur:
                    cur.execute(
                        "SELECT * FROM audit_log "
                        "WHERE entity_type = %s AND entity_id = %s "
                        "ORDER BY changed_at DESC LIMIT %s",
                        ("agent", agent_id, limit),
                    )
                    rows = cast(List[_Row], cur.fetchall())
            return [_row_to_dict(r) for r in rows]
        except Exception as e:
            logger.error("Error getting agent audit log: %s", e)
            return []
