"""psycopg3 connection pool wrapper.

Introduced in DB migration prompt P02. Wraps ``psycopg_pool.ConnectionPool``
and integrates with the credential-provider abstraction so rotating
providers (RDS IAM, Vault, Entra ID — added in P10–P12) can recycle
connections before their credential TTL expires.
"""

import logging
import threading
from typing import Optional

from psycopg import Connection
from psycopg.rows import dict_row
from psycopg_pool import ConnectionPool

from .credentials import DatabaseCredentialProvider

logger = logging.getLogger(__name__)


class DatabasePool:
    """psycopg3 connection pool with credential-provider integration.

    For static providers, behaves like a normal pool.
    For rotating providers (RDS IAM, Vault), the pool is configured with
    ``max_lifetime`` tied to the credential TTL so connections recycle
    naturally before the credential expires.
    """

    def __init__(
        self,
        credential_provider: DatabaseCredentialProvider,
        min_size: int = 1,
        max_size: int = 10,
        timeout: float = 30.0,
    ):
        self._provider = credential_provider
        self._lock = threading.Lock()
        self._pool: Optional[ConnectionPool] = None
        self._min_size = min_size
        self._max_size = max_size
        self._timeout = timeout
        self._open()

    def _build_conninfo(self) -> str:
        cred = self._provider.get_credential()
        return cred.to_conninfo()

    def _open(self):
        cred = self._provider.get_credential()
        # Connection max age: 80% of credential TTL (with 60s floor) so we
        # rotate cleanly before the credential expires. None TTL = no max age.
        max_lifetime = (
            max(int(cred.ttl_seconds * 0.8), 60) if cred.ttl_seconds else 3600.0
        )
        # Rotating providers (RDS IAM P10, Entra P11, Vault P12) hand out a
        # fresh password on every call. psycopg_pool 3.2+ accepts a callable
        # for ``conninfo`` and invokes it each time it opens a new physical
        # connection, so post-rotation reconnects pick up the new token.
        # Static providers pass the resolved string — no indirection needed.
        if self._provider.supports_rotation():
            conninfo = self._build_conninfo
        else:
            conninfo = self._build_conninfo()
        self._pool = ConnectionPool(
            conninfo=conninfo,
            min_size=self._min_size,
            max_size=self._max_size,
            timeout=self._timeout,
            max_lifetime=max_lifetime,
            configure=self._configure_connection,
            kwargs={"row_factory": dict_row},
            open=True,
        )
        logger.info(
            "DatabasePool opened (provider=%s, host=%s, max_lifetime=%ss, rotates=%s)",
            self._provider.name,
            cred.host,
            max_lifetime,
            self._provider.supports_rotation(),
        )

    def _configure_connection(self, conn: Connection):
        # Set application_name on each new connection so DBAs can identify sessions.
        # ``SET`` does not accept parameter placeholders; the value here is a
        # hardcoded constant, not user input. psycopg_pool requires the
        # connection to be returned in IDLE state, so commit the implicit
        # transaction opened by the SET.
        with conn.cursor() as cur:
            cur.execute("SET application_name TO 'okta-mcp-adapter'")
        conn.commit()

    def connection(self):
        """Context manager. Use with ``with pool.connection() as conn:``."""
        if not self._pool:
            raise RuntimeError("DatabasePool not initialized")
        return self._pool.connection()

    def close(self):
        with self._lock:
            if self._pool:
                self._pool.close()
                self._pool = None

    @property
    def provider_name(self) -> str:
        return self._provider.name
