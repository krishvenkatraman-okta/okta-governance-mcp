"""SQL migration runner — replaces Alembic.

Introduced in DB migration prompt P03.

Applies raw SQL files from ``deploy/migrations/sql/`` in version order and
tracks state in the ``schema_migrations`` table created by the bootstrap
migration. Dependency-free: no SQLAlchemy, no Alembic — just ``psycopg``.

Invoked from the CLI entry point ``okta-adapter-migrate`` (see pyproject.toml)
or directly via ``python -m okta_agent_proxy.storage.migrate``.
"""

from __future__ import annotations

import argparse
import hashlib
import logging
import os
import re
import sys
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, List, Optional

import psycopg

logger = logging.getLogger(__name__)

MIGRATION_PATTERN = re.compile(r"^(\d{3})__([a-z0-9_]+)\.up\.sql$")
BOOTSTRAP_VERSION = "000"


@dataclass(frozen=True)
class Migration:
    version: str
    name: str
    up_path: Path
    down_path: Optional[Path]
    checksum: str

    @classmethod
    def load(cls, up_path: Path) -> "Migration":
        m = MIGRATION_PATTERN.match(up_path.name)
        if not m:
            raise ValueError(f"Invalid migration filename: {up_path.name}")
        version, name = m.group(1), m.group(2)
        up_bytes = up_path.read_bytes()
        down_path = up_path.parent / f"{version}__{name}.down.sql"
        return cls(
            version=version,
            name=name,
            up_path=up_path,
            down_path=down_path if down_path.exists() else None,
            checksum=hashlib.sha256(up_bytes).hexdigest(),
        )


def discover_migrations(migrations_dir: Path) -> List[Migration]:
    """Return migrations sorted by version. Excludes the bootstrap file."""
    found: List[Migration] = []
    for p in sorted(migrations_dir.glob("*.up.sql")):
        if p.name.startswith(f"{BOOTSTRAP_VERSION}__"):
            continue
        found.append(Migration.load(p))
    return sorted(found, key=lambda m: m.version)


def ensure_bootstrap(conn: psycopg.Connection, migrations_dir: Path) -> None:
    """Create the schema_migrations table if missing. Idempotent."""
    bootstrap = migrations_dir / f"{BOOTSTRAP_VERSION}__bootstrap.up.sql"
    if not bootstrap.exists():
        raise FileNotFoundError(
            f"Bootstrap migration not found at {bootstrap}. "
            f"Pass --migrations-dir pointing at deploy/migrations/sql."
        )
    sql_text = bootstrap.read_text()
    with conn.cursor() as cur:
        cur.execute(sql_text)
    conn.commit()


def get_applied_versions(conn: psycopg.Connection) -> Dict[str, str]:
    """Return {version: checksum} of migrations already applied."""
    with conn.cursor() as cur:
        cur.execute(
            "SELECT version, checksum FROM schema_migrations ORDER BY version"
        )
        return {row[0]: row[1] for row in cur.fetchall()}


def get_current_version(conn: psycopg.Connection) -> Optional[str]:
    """Return the highest applied version, or None if none applied."""
    with conn.cursor() as cur:
        cur.execute("SELECT MAX(version) FROM schema_migrations")
        row = cur.fetchone()
        return row[0] if row else None


def apply_migration(
    conn: psycopg.Connection, migration: Migration, applied_by: str
) -> int:
    """Apply one migration in a transaction. Records to schema_migrations on success.

    Returns the execution duration in milliseconds.
    """
    logger.info("Applying migration %s — %s", migration.version, migration.name)
    sql_text = migration.up_path.read_text()
    start = time.monotonic()
    try:
        with conn.cursor() as cur:
            cur.execute(sql_text)
            execution_ms = int((time.monotonic() - start) * 1000)
            cur.execute(
                "INSERT INTO schema_migrations "
                "(version, applied_at, applied_by, checksum, execution_ms) "
                "VALUES (%s, NOW(), %s, %s, %s)",
                (
                    migration.version,
                    applied_by,
                    migration.checksum,
                    execution_ms,
                ),
            )
        conn.commit()
        logger.info(
            "✓ Migration %s applied in %dms", migration.version, execution_ms
        )
        return execution_ms
    except Exception:
        conn.rollback()
        logger.exception("Migration %s failed; rolled back", migration.version)
        raise


def _verify_checksums(
    applied: Dict[str, str], all_migrations: List[Migration]
) -> None:
    """Raise RuntimeError if an already-applied migration's file has changed."""
    for m in all_migrations:
        if m.version in applied and applied[m.version] != m.checksum:
            raise RuntimeError(
                f"Checksum mismatch for migration {m.version}: file has changed "
                f"after being applied. Migrations are immutable once applied — "
                f"roll forward with a new version instead."
            )


def upgrade(
    conninfo: str,
    migrations_dir: Path,
    applied_by: Optional[str] = None,
    target_version: Optional[str] = None,
) -> List[str]:
    """Apply all pending migrations (optionally up to target_version).

    Returns the list of versions applied during this invocation.
    """
    if applied_by is None:
        applied_by = os.getenv("USER", "migrate-runner")
    resolved_applied_by: str = applied_by
    with psycopg.connect(conninfo) as conn:
        ensure_bootstrap(conn, migrations_dir)
        all_migrations = discover_migrations(migrations_dir)
        applied = get_applied_versions(conn)
        _verify_checksums(applied, all_migrations)

        pending = [m for m in all_migrations if m.version not in applied]
        if target_version is not None:
            pending = [m for m in pending if m.version <= target_version]

        applied_versions: List[str] = []
        for m in pending:
            apply_migration(conn, m, resolved_applied_by)
            applied_versions.append(m.version)
        return applied_versions


def status(conninfo: str, migrations_dir: Path) -> dict:
    """Return {'current_version', 'applied', 'pending'}."""
    with psycopg.connect(conninfo) as conn:
        ensure_bootstrap(conn, migrations_dir)
        applied = get_applied_versions(conn)
        all_migrations = discover_migrations(migrations_dir)
        pending = [m.version for m in all_migrations if m.version not in applied]
        return {
            "current_version": max(applied.keys()) if applied else None,
            "applied": sorted(applied.keys()),
            "pending": pending,
        }


def main(argv: Optional[List[str]] = None) -> int:
    parser = argparse.ArgumentParser(
        description="Okta MCP Adapter SQL migration runner",
    )
    parser.add_argument("command", choices=["upgrade", "status", "version"])
    parser.add_argument("--migrations-dir", default="deploy/migrations/sql")
    parser.add_argument(
        "--target", default=None, help="Stop at this version (inclusive)"
    )
    parser.add_argument(
        "--conninfo",
        default=os.getenv("DATABASE_URL"),
        help="psycopg conninfo or libpq URL (default: DATABASE_URL env, "
        "else resolved via DB_CREDENTIAL_PROVIDER)",
    )
    parser.add_argument("--applied-by", default=None)
    args = parser.parse_args(argv)

    # When neither --conninfo nor DATABASE_URL is set, fall back to the
    # DB credential provider (P10–P12: rds_iam, azure_entra, vault). The
    # dedicated ECS/ACA migrate tasks rely on this path — they only set
    # DB_CREDENTIAL_PROVIDER + DB_HOST/DB_USERNAME/... env vars.
    if not args.conninfo and os.getenv("DB_CREDENTIAL_PROVIDER"):
        from okta_agent_proxy.storage.credentials import get_credential_provider

        try:
            args.conninfo = get_credential_provider().get_credential().to_url()
        except Exception as exc:
            print(
                f"ERROR: DB credential provider "
                f"'{os.getenv('DB_CREDENTIAL_PROVIDER')}' failed to mint "
                f"conninfo: {exc}",
                file=sys.stderr,
            )
            return 2

    if not args.conninfo:
        print(
            "ERROR: --conninfo or DATABASE_URL environment variable required",
            file=sys.stderr,
        )
        return 2

    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s %(levelname)s %(message)s",
    )
    migrations_dir = Path(args.migrations_dir).resolve()
    if not migrations_dir.is_dir():
        print(
            f"ERROR: migrations directory not found: {migrations_dir}",
            file=sys.stderr,
        )
        return 2

    if args.command == "upgrade":
        applied = upgrade(
            args.conninfo, migrations_dir, args.applied_by, args.target
        )
        print(f"Applied {len(applied)} migration(s): {applied}")
    elif args.command == "status":
        s = status(args.conninfo, migrations_dir)
        print(f"Current version: {s['current_version']}")
        print(f"Applied:         {s['applied']}")
        print(f"Pending:         {s['pending']}")
    elif args.command == "version":
        with psycopg.connect(args.conninfo) as conn:
            v = get_current_version(conn)
            print(v if v else "(none)")
    return 0


if __name__ == "__main__":
    sys.exit(main())
