"""
Abstract resource configuration store interface.

Allows multiple implementations (in-memory, PostgreSQL, etc.)

Note: resources are owned by the Okta syncer. ``create_resource`` /
``enable_resource`` / ``disable_resource`` are not on this interface —
rows are materialized by sync and admins edit routing metadata via
``update_resource``.
"""

from abc import ABC, abstractmethod
from typing import List, Dict, Any, Optional


class ResourceConfigStore(ABC):
    """
    Abstract base class for resource configuration storage.
    """

    @abstractmethod
    def get_all_resources(self) -> List[Dict[str, Any]]:
        """Return all resources as admin-API dicts."""

    @abstractmethod
    def get_resource(self, name: str) -> Optional[Dict[str, Any]]:
        """Return a single resource by name, or None."""

    @abstractmethod
    def update_resource(
        self,
        name: str,
        config: Dict[str, Any],
        user: str = "admin",
        ip_address: Optional[str] = None,
        user_agent: Optional[str] = None,
    ) -> bool:
        """Update admin-editable fields (url, name, type, description,
        paths, config, tags, enabled, timeout_seconds).

        Raises ValueError if any sync-owned field is included.
        """

    @abstractmethod
    def delete_resource(
        self,
        name: str,
        user: str = "admin",
        ip_address: Optional[str] = None,
        user_agent: Optional[str] = None,
    ) -> bool:
        """Delete a resource row. Returns True if deleted, False if absent."""

    @abstractmethod
    def get_audit_log(
        self, resource_name: Optional[str] = None, limit: int = 100
    ) -> List[Dict[str, Any]]:
        """Return audit log entries."""

    # Agent-related methods

    @abstractmethod
    def get_agent(
        self, agent_id: str, enabled_only: bool = True
    ) -> Optional[Dict[str, Any]]:
        """Return a single agent by agent_id."""

    @abstractmethod
    def get_agent_by_name(
        self, agent_name: str, enabled_only: bool = True
    ) -> Optional[Dict[str, Any]]:
        """Return a single agent by agent_name."""

    @abstractmethod
    def get_all_agents(self, enabled_only: bool = True) -> List[Dict[str, Any]]:
        """Return all agents."""

    @abstractmethod
    def create_agent(
        self,
        agent_id: str,
        config: Dict[str, Any],
        user: str = "admin",
        ip_address: Optional[str] = None,
        user_agent: Optional[str] = None,
    ) -> bool:
        """Create a new agent."""

    @abstractmethod
    def update_agent(
        self,
        agent_id: str,
        config: Dict[str, Any],
        user: str = "admin",
        ip_address: Optional[str] = None,
        user_agent: Optional[str] = None,
    ) -> bool:
        """Update an existing agent."""

    @abstractmethod
    def delete_agent(
        self,
        agent_id: str,
        user: str = "admin",
        ip_address: Optional[str] = None,
        user_agent: Optional[str] = None,
    ) -> bool:
        """Delete an agent (cascades to its per-connection resource rows)."""

    @abstractmethod
    def enable_agent(
        self,
        agent_id: str,
        user: str = "admin",
        ip_address: Optional[str] = None,
        user_agent: Optional[str] = None,
    ) -> bool:
        """Enable an agent."""

    @abstractmethod
    def disable_agent(
        self,
        agent_id: str,
        user: str = "admin",
        ip_address: Optional[str] = None,
        user_agent: Optional[str] = None,
    ) -> bool:
        """Disable an agent."""

    @abstractmethod
    def get_agent_audit_log(
        self, agent_id: str, limit: int = 100
    ) -> List[Dict[str, Any]]:
        """Return audit log entries for an agent."""

    @abstractmethod
    def list_agent_resources(self, agent_id: str) -> List[str]:
        """Return names of resources belonging to the agent."""

    # Gateway config methods

    @abstractmethod
    def get_gateway_config(self, key: str) -> Optional[Any]:
        """Return the parsed JSON value for key, or None if absent."""

    @abstractmethod
    def get_gateway_config_entry(self, key: str) -> Optional[Dict[str, Any]]:
        """Return a dict with value, updated_at, updated_by for key, or None."""

    @abstractmethod
    def set_gateway_config(
        self,
        key: str,
        value: Any,
        user: str = "admin",
        description: Optional[str] = None,
        ip_address: Optional[str] = None,
        user_agent: Optional[str] = None,
    ) -> None:
        """Upsert key → value (JSON-serialized). Writes an audit log entry."""

    @abstractmethod
    def delete_gateway_config(
        self,
        key: str,
        user: str = "admin",
        ip_address: Optional[str] = None,
        user_agent: Optional[str] = None,
    ) -> bool:
        """Delete key. Returns True if deleted. Writes an audit log entry."""


# Backward-compat alias
BackendConfigStore = ResourceConfigStore
