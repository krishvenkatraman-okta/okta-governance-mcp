"""Storage layer for resource configuration management (psycopg3)."""

from .base import ResourceConfigStore
from .cached_store import CachedResourceStore
from .psycopg_store import PsycopgResourceStore

# Backward-compat aliases
BackendConfigStore = ResourceConfigStore
CachedBackendStore = CachedResourceStore

__all__ = [
    "ResourceConfigStore",
    "PsycopgResourceStore",
    "CachedResourceStore",
    "BackendConfigStore",
    "CachedBackendStore",
]
