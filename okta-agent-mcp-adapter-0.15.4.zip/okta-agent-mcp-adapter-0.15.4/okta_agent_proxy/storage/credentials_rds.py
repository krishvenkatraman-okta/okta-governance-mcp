"""AWS RDS IAM database credential provider (P10).

Generates a short-lived (15-minute) IAM authentication token via
``rds.generate_db_auth_token`` and returns it as the database password.
``DatabasePool`` reads ``ttl_seconds`` from the returned credential and
recycles connections at ~80% of the TTL so tokens never expire mid-query.

Required env vars:
    DB_HOST        — RDS endpoint (no port)
    DB_PORT        — default 5432
    DB_NAME        — database name
    DB_USERNAME    — IAM-enabled DB user (the role must have ``rds_iam``
                     granted on the Postgres side)
    AWS_REGION     — region of the RDS instance (or AWS_DEFAULT_REGION)

Optional:
    DB_SSLROOTCERT — path to the RDS CA bundle. Defaults to
                     ``/opt/rds-ca/global-bundle.pem`` (installed into the
                     container image by the Dockerfile when
                     ``INSTALL_RDS_CA=true`` — the default).

IAM policy the ECS task role / EKS IRSA must include::

    {
      "Effect": "Allow",
      "Action": "rds-db:connect",
      "Resource": "arn:aws:rds-db:<region>:<account>:dbuser:<db-resource-id>/<db-username>"
    }
"""

from __future__ import annotations

import logging
import os
from typing import Optional

from .credentials import DatabaseCredential, DatabaseCredentialProvider

logger = logging.getLogger(__name__)


# Tokens issued by generate_db_auth_token are valid for 15 minutes.
# See: https://docs.aws.amazon.com/AmazonRDS/latest/UserGuide/UsingWithRDS.IAMDBAuth.Connecting.html
_RDS_IAM_TOKEN_TTL_SECONDS = 900

_DEFAULT_RDS_CA_PATH = "/opt/rds-ca/global-bundle.pem"


class RdsIamCredentialProvider(DatabaseCredentialProvider):
    """AWS RDS IAM database authentication provider.

    Each ``get_credential()`` call invokes ``rds.generate_db_auth_token``
    and returns a fresh credential. ``DatabasePool`` treats this provider
    as rotating (``supports_rotation() is True``) and sets the pool's
    ``max_lifetime`` to 80% of the 15-minute token TTL.
    """

    name = "rds_iam"

    def __init__(
        self,
        *,
        rds_client: Optional[object] = None,
    ):
        # Read required env vars eagerly so misconfiguration surfaces at
        # startup rather than at first DB connection.
        missing = [
            v
            for v in ("DB_HOST", "DB_NAME", "DB_USERNAME")
            if not os.environ.get(v)
        ]
        region = os.environ.get("AWS_REGION") or os.environ.get("AWS_DEFAULT_REGION")
        if not region:
            missing.append("AWS_REGION (or AWS_DEFAULT_REGION)")
        if missing:
            raise RuntimeError(
                "RdsIamCredentialProvider is missing required env vars: "
                f"{', '.join(missing)}. See docs/OPERATIONS.md § AWS RDS IAM."
            )

        self._host = os.environ["DB_HOST"]
        self._port = int(os.environ.get("DB_PORT", "5432"))
        self._dbname = os.environ["DB_NAME"]
        self._username = os.environ["DB_USERNAME"]
        self._region = region
        self._sslrootcert = os.environ.get("DB_SSLROOTCERT", _DEFAULT_RDS_CA_PATH)

        if rds_client is not None:
            self._client = rds_client
        else:
            # Import boto3 lazily so non-AWS deployments don't pay the
            # import cost and don't need boto3 installed at runtime.
            import boto3  # noqa: WPS433 — deliberate local import

            self._client = boto3.client("rds", region_name=self._region)

    def get_credential(self) -> DatabaseCredential:
        token = self._client.generate_db_auth_token(
            DBHostname=self._host,
            Port=self._port,
            DBUsername=self._username,
            Region=self._region,
        )
        logger.debug(
            "Generated RDS IAM auth token (host=%s user=%s ttl=%ds)",
            self._host,
            self._username,
            _RDS_IAM_TOKEN_TTL_SECONDS,
        )
        return DatabaseCredential(
            username=self._username,
            password=token,
            host=self._host,
            port=self._port,
            dbname=self._dbname,
            sslmode="verify-full",
            sslrootcert=self._sslrootcert,
            ttl_seconds=_RDS_IAM_TOKEN_TTL_SECONDS,
        )

    def supports_rotation(self) -> bool:
        return True
