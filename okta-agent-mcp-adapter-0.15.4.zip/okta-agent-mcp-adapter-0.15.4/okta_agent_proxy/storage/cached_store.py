"""
Cached wrapper around ResourceConfigStore.

Provides read-through caching for agent and resource configuration lookups
using the shared CacheService. Write operations delegate to the wrapped
store then invalidate relevant cache keys.

Agent data may contain decrypted secrets, so it is encrypted in the cache
when an EncryptionService is available.
"""

import asyncio
import logging
import concurrent.futures
from typing import List, Dict, Any, Optional

from okta_agent_proxy.storage.base import ResourceConfigStore
from okta_agent_proxy.cache.config_cache import ConfigCache

logger = logging.getLogger(__name__)


class CachedResourceStore(ResourceConfigStore):
    """
    Wraps an existing ResourceConfigStore with a ConfigCache.

    Read methods check cache first, fall through to the wrapped store
    on miss, then populate the cache. Write methods delegate to the
    wrapped store then invalidate relevant cache keys.
    """

    def __init__(
        self,
        store: ResourceConfigStore,
        cache_service,
        ttl_seconds: int = 300,
        encryption_service=None,
    ):
        self._store = store
        self._cache = ConfigCache(
            cache_service, ttl_seconds=ttl_seconds, encryption_service=encryption_service
        )
        logger.info(f"CachedResourceStore wrapping {type(store).__name__} (TTL={ttl_seconds}s)")

    # ------------------------------------------------------------------
    # Sync-to-async bridge (same pattern as TokenCache)
    # ------------------------------------------------------------------

    @staticmethod
    def _run_async(coro):
        """Run an async coroutine from sync context.

        When called from within a running event loop (e.g. a sync method
        invoked from an async handler), we run the coroutine in a new
        thread with its own event loop via asyncio.run. This is necessary
        because we cannot synchronously block on the running loop without
        deadlocking.

        The Redis provider handles this correctly by detecting cross-loop
        usage and creating a thread-local client (see _get_redis).
        """
        try:
            loop = asyncio.get_running_loop()
        except RuntimeError:
            loop = None

        if loop and loop.is_running():
            with concurrent.futures.ThreadPoolExecutor() as pool:
                return pool.submit(asyncio.run, coro).result()
        else:
            return asyncio.run(coro)

    # ------------------------------------------------------------------
    # Agent reads
    # ------------------------------------------------------------------

    def get_agent(self, agent_id: str, enabled_only: bool = True) -> Optional[Dict[str, Any]]:
        try:
            cached = self._run_async(self._cache.get_agent(agent_id))
            if cached is not None:
                if enabled_only and not cached.get("enabled", True):
                    return None
                return cached
        except Exception as e:
            logger.warning(f"Cache read failed for agent {agent_id}: {e}")

        result = self._store.get_agent(agent_id, enabled_only=enabled_only)
        if result is not None:
            try:
                self._run_async(self._cache.set_agent(agent_id, result))
            except Exception:
                pass
        return result

    def get_agent_by_name(self, agent_name: str, enabled_only: bool = True) -> Optional[Dict[str, Any]]:
        try:
            cached = self._run_async(self._cache.get_agent_by_name(agent_name))
            if cached is not None:
                if enabled_only and not cached.get("enabled", True):
                    return None
                return cached
        except Exception as e:
            logger.warning(f"Cache read failed for agent_name {agent_name}: {e}")

        result = self._store.get_agent_by_name(agent_name, enabled_only=enabled_only)
        if result is not None:
            agent_id = result.get("agent_id", agent_name)
            try:
                self._run_async(self._cache.set_agent(agent_id, result))
            except Exception:
                pass
        return result

    def get_all_agents(self, enabled_only: bool = True) -> List[Dict[str, Any]]:
        try:
            cached = self._run_async(self._cache.get_all_agents())
            if cached is not None:
                if enabled_only:
                    return [a for a in cached if a.get("enabled", True)]
                return cached
        except Exception as e:
            logger.warning(f"Cache read failed for all_agents: {e}")

        result = self._store.get_all_agents(enabled_only=enabled_only)
        if result is not None:
            try:
                # Cache the unfiltered list so both enabled_only=True/False work
                if not enabled_only:
                    self._run_async(self._cache.set_all_agents(result))
            except Exception:
                pass
        return result

    # ------------------------------------------------------------------
    # Agent writes
    # ------------------------------------------------------------------

    def create_agent(self, agent_id: str, config: Dict[str, Any], user: str = "admin",
                     ip_address: Optional[str] = None, user_agent: Optional[str] = None) -> bool:
        result = self._store.create_agent(agent_id, config, user,
                                          ip_address=ip_address, user_agent=user_agent)
        if result:
            agent_name = config.get("agent_name", agent_id)
            try:
                self._run_async(self._cache.invalidate_agent(agent_id, agent_name=agent_name))
            except Exception:
                pass
        return result

    def update_agent(self, agent_id: str, config: Dict[str, Any], user: str = "admin",
                     ip_address: Optional[str] = None, user_agent: Optional[str] = None) -> bool:
        # Get agent name before update for invalidation
        agent_name = None
        try:
            existing = self._store.get_agent(agent_id, enabled_only=False)
            if existing:
                agent_name = existing.get("agent_name", agent_id)
        except Exception:
            pass

        result = self._store.update_agent(agent_id, config, user,
                                          ip_address=ip_address, user_agent=user_agent)
        if result:
            try:
                self._run_async(self._cache.invalidate_agent(agent_id, agent_name=agent_name))
            except Exception:
                pass
        return result

    def delete_agent(self, agent_id: str, user: str = "admin",
                     ip_address: Optional[str] = None, user_agent: Optional[str] = None) -> bool:
        # Get agent name before deletion for invalidation
        agent_name = None
        try:
            existing = self._store.get_agent(agent_id, enabled_only=False)
            if existing:
                agent_name = existing.get("agent_name", agent_id)
        except Exception:
            pass

        result = self._store.delete_agent(agent_id, user,
                                          ip_address=ip_address, user_agent=user_agent)
        if result:
            try:
                self._run_async(self._cache.invalidate_agent(agent_id, agent_name=agent_name))
            except Exception:
                pass
        return result

    def enable_agent(self, agent_id: str, user: str = "admin",
                     ip_address: Optional[str] = None, user_agent: Optional[str] = None) -> bool:
        result = self._store.enable_agent(agent_id, user,
                                          ip_address=ip_address, user_agent=user_agent)
        if result:
            try:
                self._run_async(self._cache.invalidate_agent(agent_id))
                self._run_async(self._cache.invalidate_all_agents())
            except Exception:
                pass
        return result

    def disable_agent(self, agent_id: str, user: str = "admin",
                      ip_address: Optional[str] = None, user_agent: Optional[str] = None) -> bool:
        result = self._store.disable_agent(agent_id, user,
                                           ip_address=ip_address, user_agent=user_agent)
        if result:
            try:
                self._run_async(self._cache.invalidate_agent(agent_id))
                self._run_async(self._cache.invalidate_all_agents())
            except Exception:
                pass
        return result

    # ------------------------------------------------------------------
    # Resource reads
    # ------------------------------------------------------------------

    def get_resource(self, name: str) -> Optional[Dict[str, Any]]:
        try:
            cached = self._run_async(self._cache.get_resource(name))
            if cached is not None:
                return cached
        except Exception as e:
            logger.warning(f"Cache read failed for resource {name}: {e}")

        result = self._store.get_resource(name)
        if result is not None:
            try:
                self._run_async(self._cache.set_resource(name, result))
            except Exception:
                pass
        return result

    def get_all_resources(self) -> List[Dict[str, Any]]:
        try:
            cached = self._run_async(self._cache.get_all_resources())
            if cached is not None:
                return cached
        except Exception as e:
            logger.warning(f"Cache read failed for all_resources: {e}")

        result = self._store.get_all_resources()
        if result is not None:
            try:
                self._run_async(self._cache.set_all_resources(result))
            except Exception:
                pass
        return result

    # ------------------------------------------------------------------
    # Resource writes
    # ------------------------------------------------------------------

    def update_resource(self, name: str, config: Dict[str, Any], user: str = "admin",
                        ip_address: Optional[str] = None, user_agent: Optional[str] = None) -> bool:
        result = self._store.update_resource(name, config, user,
                                             ip_address=ip_address, user_agent=user_agent)
        if result:
            try:
                self._run_async(self._cache.invalidate_resource(name))
                self._run_async(self._cache.invalidate_route_table())
            except Exception:
                pass
        return result

    def delete_resource(self, name: str, user: str = "admin",
                        ip_address: Optional[str] = None, user_agent: Optional[str] = None) -> bool:
        result = self._store.delete_resource(name, user,
                                             ip_address=ip_address, user_agent=user_agent)
        if result:
            try:
                self._run_async(self._cache.invalidate_resource(name))
                self._run_async(self._cache.invalidate_route_table())
            except Exception:
                pass
        return result

    # ------------------------------------------------------------------
    # Pass-through methods (no caching benefit)
    # ------------------------------------------------------------------

    def get_audit_log(self, resource_name: Optional[str] = None, limit: int = 100) -> List[Dict[str, Any]]:
        return self._store.get_audit_log(resource_name, limit)

    def get_agent_audit_log(self, agent_id: str, limit: int = 100) -> List[Dict[str, Any]]:
        return self._store.get_agent_audit_log(agent_id, limit)

    def list_agent_resources(self, agent_id: str) -> List[str]:
        return self._store.list_agent_resources(agent_id)

    def get_agent_by_cimd_client_id(self, cimd_client_id: str, enabled_only: bool = True) -> Optional[Dict[str, Any]]:
        return self._store.get_agent_by_cimd_client_id(cimd_client_id, enabled_only=enabled_only)

    def get_agent_by_client_id(self, client_id: str, enabled_only: bool = True) -> Optional[Dict[str, Any]]:
        return self._store.get_agent_by_client_id(client_id, enabled_only=enabled_only)

    # ------------------------------------------------------------------
    # CIMD agent support
    # ------------------------------------------------------------------

    def create_cimd_agent(
        self,
        cimd_client_id: str,
        client_name: str,
        domain: str,
        backend_access: List[str] = None,
        trust_level: str = "unknown",
        **kwargs,
    ) -> bool:
        result = self._store.create_cimd_agent(
            cimd_client_id, client_name, domain, backend_access, trust_level
        )
        if result:
            try:
                self._run_async(self._cache.invalidate_all_agents())
            except Exception:
                pass
        return result

    # ------------------------------------------------------------------
    # DCR registration support
    # ------------------------------------------------------------------

    def create_dcr_registration(self, **kwargs) -> Dict[str, Any]:
        return self._store.create_dcr_registration(**kwargs)

    def get_dcr_registration(self, client_id: str) -> Optional[Dict[str, Any]]:
        return self._store.get_dcr_registration(client_id)

    def list_dcr_registrations(
        self, status: Optional[str] = None, limit: int = 100, offset: int = 0
    ) -> List[Dict[str, Any]]:
        return self._store.list_dcr_registrations(status=status, limit=limit, offset=offset)

    def revoke_dcr_registration(self, client_id: str, user: str = "admin") -> bool:
        return self._store.revoke_dcr_registration(client_id, user)

    def update_dcr_registration_linked_agent(
        self, client_id: str, linked_agent_name=None
    ) -> bool:
        return self._store.update_dcr_registration_linked_agent(client_id, linked_agent_name)

    # ------------------------------------------------------------------
    # Gateway config (pass-through, no caching)
    # ------------------------------------------------------------------

    def get_gateway_config(self, key):
        return self._store.get_gateway_config(key)

    def get_gateway_config_entry(self, key):
        return self._store.get_gateway_config_entry(key)

    def set_gateway_config(self, key, value, **kwargs):
        return self._store.set_gateway_config(key, value, **kwargs)

    def delete_gateway_config(self, key, **kwargs):
        return self._store.delete_gateway_config(key, **kwargs)


# Backward-compat alias
CachedBackendStore = CachedResourceStore
