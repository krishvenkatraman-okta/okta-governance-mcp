"""
Okta MCP Gateway - A proxy gateway for Model Context Protocol servers
with Okta-based authentication and authorization.
"""

__version__ = "0.15.4"
__author__ = "Okta"

