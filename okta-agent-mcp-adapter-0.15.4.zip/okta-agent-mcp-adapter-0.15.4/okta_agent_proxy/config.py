"""
Configuration management for MCP Gateway
"""

import os
import warnings
from typing import Dict, List, Optional
from urllib.parse import urlparse
from pydantic import AliasChoices, BaseModel, Field, field_validator
from pydantic_settings import BaseSettings
import yaml
from dotenv import load_dotenv

# Load .env file at module import time
load_dotenv()


_LOOPBACK_HOSTS = {"localhost", "127.0.0.1", "::1"}


def _is_loopback(host: str) -> bool:
    """Return True when host is a loopback address per RFC 6761 §6.3.

    Recognizes localhost, 127.0.0.1, ::1, and any subdomain of .localhost.
    Used by GATEWAY_BASE_URL validation to allow http:// without TLS for
    local development only. Plain LAN IPs and real hostnames fall through
    and are rejected unless they use https://.
    """
    if not host:
        return False
    host_lower = host.lower()
    if host_lower in _LOOPBACK_HOSTS:
        return True
    if host_lower.endswith(".localhost"):
        return True
    return False


class AgentConfig(BaseModel):
    """Agent (MCP client) configuration
    
    Two purposes:
    
    1. Frontend User Authentication:
       - client_id: OAuth client ID for user login flow
       - client_secret: OAuth client secret for user login flow
       - Returns: ID Token + Access Token for the user
    
    2. Cross-App Access (ID-JAG Exchange):
       - agent_id: Service account identifier (used as principal_id in JWT)
       - private_key: JWK format private key for signing JWT assertions
       - User's ID Token is exchanged for ID-JAG at org auth server
       - ID-JAG is then exchanged at target auth server for MCP access token
    
    Note: Scopes for token exchange come from resource.auth_config, not agent config.
          The ID-JAG token will contain scopes from the ID token + resource-requested scopes.
    """
    agent_id: str
    client_id: str  # OAuth client ID (for user authentication)
    client_secret: str  # OAuth client secret (for user authentication)
    private_key: str  # JWK private key (for JWT signing in ID-JAG exchange)
    principal_id: Optional[str] = None  # Okta AI Agent ID (e.g., "agtXXXXXXXX") for JWT bearer claims issuer/subject
    resource_access: List[str] = Field(default_factory=list)  # Deprecated — authorization via syncer


class ResourceAuthConfig(BaseModel):
    """Resource authentication configuration
    
    Supports THREE authentication methods:
    
    1. okta-cross-app (IETF ID-JAG Pattern)
       Per: https://www.ietf.org/archive/id/draft-ietf-oauth-identity-assertion-authz-grant-00.html
       
       Flow:
       - User authenticates with agent OAuth → gets ID token (org-level scopes)
       - ID token exchanged for ID-JAG at org auth server
       - ID-JAG exchanged at target auth server for MCP access token
       - Target auth server's authorization policies determine MCP token scopes
       
       NOTE: The proxy does NOT configure scopes. Scopes are determined by Okta's
             authorization policies at the target auth server during the exchange.
       
       TWO PATTERNS:
       
       A) Static Pattern (configured):
          Target auth server details pre-configured at gateway
          Faster, no discovery needed
          
          Config:
            id_jag_mode: static
            target_authorization_server: https://target-idp.okta.com/oauth2/ausscimnps4vnh9zE1d7
            target_audience: mcp_resource_server
       
       B) Dynamic Pattern (discovered):
          Gateway discovers auth server details from target's protected resource metadata
          More flexible, works with compliant targets
          
          Config:
            id_jag_mode: dynamic
    
    2. pre-shared-key (Static API Key)
       Static key configured at gateway
       Same key used for all requests
       Scopes not applicable
       
       Config:
         key: api_key_123
         header_name: X-API-Key  (optional, default: "X-API-Key")
    
    3. service-account (Basic Auth)
       Gateway authenticates as service account
       Uses Basic Auth (username:password)
       Scopes not applicable
       
       Config:
         username: service_account_id
         password: service_account_secret
    """
    # For okta-cross-app method
    id_jag_mode: Optional[str] = Field(default="static")  # "static" or "dynamic"
    target_authorization_server: Optional[str] = None
    target_token_endpoint: Optional[str] = None
    target_client_id: Optional[str] = None
    target_client_secret: Optional[str] = None
    target_audience: Optional[str] = None
    
    # XAA mode
    xaa_mode: str = "direct"

    # For pre-shared-key method
    key: Optional[str] = Field(default=None, validation_alias=AliasChoices("key", "api_key"))
    header_name: Optional[str] = Field(default="X-API-Key", validation_alias=AliasChoices("header_name", "api_key_header"))
    
    # For service-account method
    username: Optional[str] = None
    password: Optional[str] = None

    # For okta-sts method (STS_ACCESS_TOKEN brokered consent)
    resource_indicator: Optional[str] = None
    app_instance_name: Optional[str] = None
    app_instance_id: Optional[str] = None


class ResourceConfig(BaseModel):
    """Single resource (MCP server) configuration"""
    name: str
    url: str
    paths: List[str] = []  # Optional — resource is always reachable at /{name}
    description: str = ""
    timeout_seconds: int = 30
    auth_method: str = "okta-cross-app"  # "okta-cross-app", "pre-shared-key", or "service-account"
    auth_config: ResourceAuthConfig = Field(default_factory=ResourceAuthConfig)
    enabled: bool = True


# Backward-compat aliases
BackendAuthConfig = ResourceAuthConfig
BackendConfig = ResourceConfig


class CacheConfig(BaseModel):
    """Token cache configuration"""
    max_size: int = 50000
    ttl_seconds: int = 3600


class GatewaySettings(BaseSettings):
    """
    Gateway settings from environment variables.

    Configuration:
    - OKTA_DOMAIN: Required (for JWKS validation)
    - OKTA_ISSUER: Optional (derived from OKTA_DOMAIN if not set)
    - GATEWAY_BASE_URL: External URL clients use to reach the gateway.
      Behind an ALB the port in GATEWAY_BASE_URL may differ from GATEWAY_PORT.
    - GATEWAY_PORT: TCP port the gateway binds to inside the container (default 8000).

    Note: Agent and resource configurations are stored in PostgreSQL database,
    not in environment variables. Use the Admin API to manage agents and resources.
    """
    okta_domain: str = Field(alias="OKTA_DOMAIN")
    okta_client_secret: Optional[str] = Field(alias="OKTA_CLIENT_SECRET", default=None)
    okta_issuer: Optional[str] = Field(alias="OKTA_ISSUER", default=None)

    gateway_base_url: str = Field(alias="GATEWAY_BASE_URL", default="http://localhost:8000")
    gateway_port: int = Field(alias="GATEWAY_PORT", default=8000)

    @field_validator('gateway_base_url')
    @classmethod
    def validate_gateway_base_url(cls, v):
        if not isinstance(v, str) or not v:
            raise ValueError("GATEWAY_BASE_URL must be a non-empty string")

        parsed = urlparse(v)

        if not parsed.scheme or not parsed.netloc:
            raise ValueError(
                f"GATEWAY_BASE_URL must be an absolute URL with scheme and host; got {v!r}"
            )

        if parsed.scheme not in ("http", "https"):
            raise ValueError(
                f"GATEWAY_BASE_URL must use http:// or https://; got scheme {parsed.scheme!r}"
            )

        if parsed.scheme == "http" and not _is_loopback(parsed.hostname or ""):
            raise ValueError(
                f"GATEWAY_BASE_URL must use https:// or a loopback host; got {v!r}"
            )

        if v.endswith("/"):
            raise ValueError(
                f"GATEWAY_BASE_URL must not have a trailing slash; got {v!r}"
            )

        if parsed.path:
            raise ValueError(
                f"GATEWAY_BASE_URL must not contain a path component; got {v!r}"
            )

        if parsed.query:
            raise ValueError(
                f"GATEWAY_BASE_URL must not contain a query string; got {v!r}"
            )

        if parsed.fragment:
            raise ValueError(
                f"GATEWAY_BASE_URL must not contain a fragment; got {v!r}"
            )

        return v

    @field_validator('gateway_port')
    @classmethod
    def validate_port(cls, v):
        if not (1 <= v <= 65535):
            raise ValueError(
                f"GATEWAY_PORT must be between 1 and 65535, got {v}"
            )
        if v < 1024:
            warnings.warn(
                f"GATEWAY_PORT={v} is a privileged port. "
                f"Requires root or CAP_NET_BIND_SERVICE.",
                UserWarning,
                stacklevel=2
            )
        return v

    log_level: str = Field(alias="LOG_LEVEL", default="INFO")

    mcp_protocol_version: str = Field(alias="MCP_PROTOCOL_VERSION", default="2024-11-05")

    # Resource Map / Okta Managed Connections sync
    okta_ai_agent_id: str = Field(alias="OKTA_AI_AGENT_ID", default="")
    okta_service_token: str = Field(alias="OKTA_SERVICE_TOKEN", default="")
    okta_sync_interval_seconds: int = Field(alias="OKTA_SYNC_INTERVAL_SECONDS", default=300)
    okta_sync_stale_threshold: int = Field(alias="OKTA_SYNC_STALE_THRESHOLD", default=1800)
    cache_poll_interval_seconds: int = Field(alias="CACHE_POLL_INTERVAL_SECONDS", default=30)
    
    class Config:
        env_file = ".env"
        case_sensitive = False
        extra = "ignore"  # Ignore extra environment variables
    
    @property
    def issuer(self) -> str:
        """Get issuer URL (use provided value or derive from OKTA_DOMAIN)"""
        if self.okta_issuer:
            return self.okta_issuer
        return f"https://{self.okta_domain}"


class GatewayConfig(BaseModel):
    """Complete gateway configuration"""
    name: str = "Okta MCP Gateway"
    version: str = "1.0.0"
    description: str = "Okta-secured MCP proxy gateway"
    
    gateway: GatewaySettings
    cache: CacheConfig = Field(default_factory=CacheConfig)
    resources: Dict[str, ResourceConfig] = Field(default_factory=dict)
    agents: Dict[str, AgentConfig] = Field(default_factory=dict)

    @classmethod
    def from_yaml(cls, config_path: str, env_settings: Optional[GatewaySettings] = None) -> "GatewayConfig":
        """Load configuration from YAML file and environment"""
        with open(config_path, "r") as f:
            yaml_config = yaml.safe_load(f)
        
        # Use provided settings or load from environment
        if env_settings is None:
            env_settings = GatewaySettings()
        
        # Build resources config (supports "backends" key in YAML for legacy configs)
        resources_raw = yaml_config.get("resources", yaml_config.get("backends", {}))
        resources = {}
        for resource_name, resource_data in resources_raw.items():
            resources[resource_name] = ResourceConfig(
                name=resource_name,
                **resource_data
            )
        
        # Build agents config
        agents_raw = yaml_config.get("agents", {})
        agents = {}
        for agent_id, agent_data in agents_raw.items():
            # agent_data already has agent_id from YAML, so just pass it directly
            agents[agent_id] = AgentConfig(**agent_data)
        
        # Build cache config
        cache_raw = yaml_config.get("cache", {})
        cache_config = CacheConfig(**cache_raw.get("backend_tokens", {}))
        
        return cls(
            gateway=env_settings,
            cache=cache_config,
            resources=resources,
            agents=agents
        )


def load_config() -> GatewayConfig:
    """
    Load gateway configuration from environment variables.

    Returns GatewayConfig with settings from environment variables.
    Resource and agent configurations are loaded from PostgreSQL database
    via ResourceConfigStore, not from this function.
    """
    env_settings = GatewaySettings()

    return GatewayConfig(
        gateway=env_settings,
        cache=CacheConfig(),
        resources={},  # Loaded from PostgreSQL via ResourceConfigStore
        agents={}      # Loaded from PostgreSQL via ResourceConfigStore
    )

