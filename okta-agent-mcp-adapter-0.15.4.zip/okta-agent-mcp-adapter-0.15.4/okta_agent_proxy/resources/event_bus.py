"""
Cache event bus for cross-pod invalidation of Resource Map caches.

Channels:
  resource:changed   — Resource Map table was modified (CRUD)
  okta:sync          — Okta Managed Connections were re-synced

When Redis is available: uses Redis PUBLISH/SUBSCRIBE.
When Redis is unavailable: falls back to periodic polling.
Each pod subscribes on startup and reacts to events by
reloading its in-memory caches.
"""

import asyncio
import logging
from datetime import datetime
from typing import Callable, Optional

logger = logging.getLogger(__name__)

# Predefined channels
CHANNEL_RESOURCE_CHANGED = "resource:changed"
CHANNEL_OKTA_SYNC = "okta:sync"

ALL_CHANNELS = [CHANNEL_RESOURCE_CHANGED, CHANNEL_OKTA_SYNC]


class CacheEventBus:
    """
    Pub/sub event bus for cache invalidation across adapter pods.

    Channels:
      resource:changed   — Resource Map table was modified (CRUD)
      okta:sync          — Okta Managed Connections were re-synced

    When Redis is available: uses Redis PUBLISH/SUBSCRIBE.
    When Redis is unavailable: falls back to periodic polling.
    Each pod subscribes on startup and reacts to events by
    reloading its in-memory caches.
    """

    def __init__(
        self,
        redis_url: Optional[str] = None,
        poll_interval_resource: int = 30,
        poll_interval_okta: int = 300,
        credential_provider=None,
    ):
        self._redis_url = redis_url
        self._redis = None
        self._pubsub = None
        self._subscribers: dict[str, list[Callable]] = {}
        self._listener_task: Optional[asyncio.Task] = None
        self._poll_tasks: list[asyncio.Task] = []
        self._poll_interval_resource = poll_interval_resource
        self._poll_interval_okta = poll_interval_okta
        self._credential_provider = credential_provider
        self._use_redis = False
        self._started = False

    @property
    def use_redis(self) -> bool:
        """True if Redis pub/sub is active."""
        return self._use_redis

    @property
    def started(self) -> bool:
        """True if start() has been called successfully."""
        return self._started

    async def _build_redis_client(self):
        import redis.asyncio as aioredis

        kwargs = {"decode_responses": True}
        url = self._redis_url
        if url and url.startswith("rediss://"):
            kwargs["ssl_cert_reqs"] = "none"
        if self._credential_provider is not None:
            creds = await self._credential_provider.get_credentials()
            if creds.username:
                kwargs["username"] = creds.username
            if creds.password:
                kwargs["password"] = creds.password
            url = self._strip_url_credentials(url)
        return aioredis.from_url(url, **kwargs)

    @staticmethod
    def _strip_url_credentials(url: str) -> str:
        from urllib.parse import urlparse, urlunparse

        parsed = urlparse(url)
        if parsed.username or parsed.password:
            netloc = parsed.hostname or ""
            if parsed.port:
                netloc = f"{netloc}:{parsed.port}"
            parsed = parsed._replace(netloc=netloc)
            return urlunparse(parsed)
        return url

    async def start(self):
        """Connect to Redis if configured. Start listener or poll tasks."""
        if self._redis_url:
            try:
                self._redis = await self._build_redis_client()
                await self._redis.ping()
                self._use_redis = True
                self._pubsub = self._redis.pubsub()
                await self._pubsub.subscribe(
                    CHANNEL_RESOURCE_CHANGED, CHANNEL_OKTA_SYNC
                )
                self._listener_task = asyncio.create_task(self._redis_listener())
                logger.info("CacheEventBus: Redis pub/sub connected")
            except Exception as e:
                logger.warning(
                    f"CacheEventBus: Redis unavailable ({e}), falling back to polling"
                )
                self._use_redis = False
                self._redis = None
                self._pubsub = None

        if not self._use_redis:
            logger.info("CacheEventBus: using periodic polling")
            for channel, interval in [
                (CHANNEL_RESOURCE_CHANGED, self._poll_interval_resource),
                (CHANNEL_OKTA_SYNC, self._poll_interval_okta),
            ]:
                task = asyncio.create_task(self._poll_loop(channel, interval))
                self._poll_tasks.append(task)

        self._started = True

    async def stop(self):
        """Clean shutdown: cancel tasks, close Redis."""
        if self._listener_task and not self._listener_task.done():
            self._listener_task.cancel()
            try:
                await self._listener_task
            except asyncio.CancelledError:
                pass
            self._listener_task = None

        for task in self._poll_tasks:
            if not task.done():
                task.cancel()
                try:
                    await task
                except asyncio.CancelledError:
                    pass
        self._poll_tasks.clear()

        if self._pubsub:
            try:
                await self._pubsub.unsubscribe()
                await self._pubsub.close()
            except Exception:
                pass
            self._pubsub = None

        if self._redis:
            try:
                await self._redis.close()
            except Exception:
                pass
            self._redis = None

        self._use_redis = False
        self._started = False
        logger.info("CacheEventBus: stopped")

    async def publish(self, channel: str, message: str = ""):
        """Publish an invalidation event.

        If Redis available: PUBLISH to channel.
        If not: directly invoke local subscribers (single-pod mode).
        """
        msg = message or datetime.utcnow().isoformat()

        if self._use_redis and self._redis:
            try:
                await self._redis.publish(channel, msg)
                logger.debug(f"CacheEventBus: published to {channel}")
                return
            except Exception as e:
                logger.warning(
                    f"CacheEventBus: publish failed ({e}), invoking local subscribers"
                )

        await self._invoke_local(channel, msg)

    def subscribe(self, channel: str, callback: Callable):
        """Register a callback for a channel.

        Callback signature: async def handler(message: str)
        """
        if channel not in self._subscribers:
            self._subscribers[channel] = []
        self._subscribers[channel].append(callback)

    async def _redis_listener(self):
        """Background task: listen for Redis pub/sub messages."""
        try:
            async for message in self._pubsub.listen():
                if message["type"] == "message":
                    channel = message["channel"]
                    data = message["data"]
                    await self._invoke_local(channel, data)
        except asyncio.CancelledError:
            pass
        except Exception as e:
            logger.error(f"CacheEventBus: listener error: {e}")

    async def _invoke_local(self, channel: str, message: str):
        """Invoke all registered callbacks for a channel."""
        for callback in self._subscribers.get(channel, []):
            try:
                result = callback(message)
                if asyncio.iscoroutine(result):
                    await result
            except Exception as e:
                logger.error(f"CacheEventBus: callback error on {channel}: {e}")

    async def _poll_loop(self, channel: str, interval: int):
        """Fallback: periodically invoke subscribers (simulates events)."""
        try:
            while True:
                await asyncio.sleep(interval)
                await self._invoke_local(channel, "poll")
        except asyncio.CancelledError:
            pass
