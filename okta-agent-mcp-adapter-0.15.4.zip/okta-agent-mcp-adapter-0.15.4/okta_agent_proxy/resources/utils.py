"""
Shared utilities for parsing Okta Managed Connection data.
"""

from typing import Optional

from okta_agent_proxy.resources.models import OktaConnectionType


def parse_orn(orn: str) -> Optional[str]:
    """Extract authorization server ID from Okta Resource Name.

    Input:  orn:oktapreview:idp:00oabc:authorization_servers:ausvpuw0yn
    Output: ausvpuw0yn

    Format: orn:{partition}:idp:{org_id}:authorization_servers:{as_id}
    """
    parts = orn.split(":")
    if len(parts) >= 6 and parts[0] == "orn" and "authorization_servers" in parts:
        idx = parts.index("authorization_servers")
        if idx + 1 < len(parts):
            return parts[idx + 1]
    return None


def _extract_from_resource_indicator(
    resource_indicator: str, conn_type: OktaConnectionType
) -> Optional[str]:
    """Extract the resource identifier from a resourceIndicator ORN.

    resourceIndicator is the primary field for resource identification in
    the Okta AI Agent Connections API.

    Examples:
      IDENTITY_ASSERTION_CUSTOM_AS:
        orn:okta:idp:00o...:authorization_servers:aus5rb5mt2H3d1TJd0h7
        → aus5rb5mt2H3d1TJd0h7

      STS_VAULT_SECRET:
        orn:okta:pam:00o...:secrets:d2642f68-df50-4ba8-a898-6c0f82f89d8a
        → d2642f68-df50-4ba8-a898-6c0f82f89d8a

      STS_SERVICE_ACCOUNT:
        orn:okta:pam:00o...:apps:slack:0oa...:service_accounts:4923897d-...
        → 4923897d-...
    """
    if conn_type == OktaConnectionType.IDENTITY_ASSERTION_CUSTOM_AS:
        if "authorization_servers:" in resource_indicator:
            return resource_indicator.split("authorization_servers:")[-1]
    elif conn_type in (
        OktaConnectionType.STS_VAULT_SECRET, OktaConnectionType.SECRET
    ):
        if "secrets:" in resource_indicator:
            return resource_indicator.split("secrets:")[-1]
    elif conn_type in (
        OktaConnectionType.STS_SERVICE_ACCOUNT, OktaConnectionType.SERVICE_ACCOUNT
    ):
        if "service_accounts:" in resource_indicator:
            return resource_indicator.split("service_accounts:")[-1]
    elif conn_type == OktaConnectionType.STS_ACCESS_TOKEN:
        if "client-auth-settings:" in resource_indicator:
            return resource_indicator.split("client-auth-settings:")[-1]
    return None


def extract_resource_id(conn: dict, conn_type: OktaConnectionType) -> Optional[str]:
    """Extract the resource identifier from an Okta Managed Connection.

    PRIMARY: use the resourceIndicator field (full ORN).
    FALLBACK: legacy fields (orn, authorizationServer, etc.) for older API responses.
    """
    # PRIMARY: resourceIndicator
    resource_indicator = conn.get("resourceIndicator", "")
    if resource_indicator:
        result = _extract_from_resource_indicator(resource_indicator, conn_type)
        if result:
            return result

    # FALLBACK: legacy field-based extraction
    if conn_type == OktaConnectionType.IDENTITY_ASSERTION_CUSTOM_AS:
        orn = conn.get("orn", "") or conn.get("resourceOrn", "")
        if orn:
            parsed = parse_orn(orn)
            if parsed:
                return parsed

        as_obj = conn.get("authorizationServer")
        if isinstance(as_obj, dict):
            as_orn = as_obj.get("orn", "")
            if as_orn:
                parsed = parse_orn(as_orn)
                if parsed:
                    return parsed
            if as_obj.get("id"):
                return as_obj["id"]
            self_href = as_obj.get("_links", {}).get("self", {}).get("href", "")
            if "/authorizationServers/" in self_href:
                return self_href.split("/authorizationServers/")[-1]
        elif isinstance(as_obj, str):
            return as_obj

        return conn.get("authorizationServerId") or conn.get(
            "authorization_server_id"
        )
    elif conn_type in (
        OktaConnectionType.STS_VAULT_SECRET, OktaConnectionType.SECRET
    ):
        # Nested object: {"secret": {"orn": "orn:okta:pam:...:secrets:uuid"}}
        secret_obj = conn.get("secret")
        if isinstance(secret_obj, dict):
            secret_orn = secret_obj.get("orn", "")
            if secret_orn and "secrets:" in secret_orn:
                return secret_orn.split("secrets:")[-1]
            if secret_obj.get("id"):
                return secret_obj["id"]
        return conn.get("secretId") or conn.get("secret_id") or conn.get("id")
    elif conn_type in (
        OktaConnectionType.STS_SERVICE_ACCOUNT, OktaConnectionType.SERVICE_ACCOUNT
    ):
        # Nested object: {"serviceAccount": {"orn": "orn:okta:pam:...:service_accounts:uuid"}}
        sa_obj = conn.get("serviceAccount")
        if isinstance(sa_obj, dict):
            sa_orn = sa_obj.get("orn", "")
            if sa_orn and "service_accounts:" in sa_orn:
                return sa_orn.split("service_accounts:")[-1]
            if sa_obj.get("id"):
                return sa_obj["id"]
        return (
            conn.get("serviceAccountId")
            or conn.get("service_account_id")
            or conn.get("id")
        )
    elif conn_type == OktaConnectionType.STS_ACCESS_TOKEN:
        # Nested object: {"resource": {"appInstanceId": "0oa...", "orn": "orn:...:client-auth-settings:rsc..."}}
        resource_obj = conn.get("resource")
        if isinstance(resource_obj, dict):
            res_orn = resource_obj.get("orn", "")
            if res_orn and "client-auth-settings:" in res_orn:
                return res_orn.split("client-auth-settings:")[-1]
            if resource_obj.get("appInstanceId"):
                return resource_obj["appInstanceId"]
        return conn.get("id")
    return None


def extract_connection_metadata(conn: dict, conn_type: OktaConnectionType) -> dict:
    """Extract connection-type-specific metadata from nested Okta response objects.

    Returns a dict suitable for ResolvedResource.metadata.
    """
    metadata: dict = {}

    if conn_type == OktaConnectionType.IDENTITY_ASSERTION_CUSTOM_AS:
        as_obj = conn.get("authorizationServer")
        if isinstance(as_obj, dict):
            metadata["authorization_server_orn"] = as_obj.get("orn", "")
            if as_obj.get("issuerUrl"):
                metadata["issuer_url"] = as_obj["issuerUrl"]

    elif conn_type in (
        OktaConnectionType.STS_VAULT_SECRET, OktaConnectionType.SECRET
    ):
        secret_obj = conn.get("secret")
        if isinstance(secret_obj, dict):
            metadata["secret_orn"] = secret_obj.get("orn", "")
            if secret_obj.get("name"):
                metadata["secret_name"] = secret_obj["name"]
            if secret_obj.get("path"):
                metadata["secret_path"] = secret_obj["path"]

    elif conn_type in (
        OktaConnectionType.STS_SERVICE_ACCOUNT, OktaConnectionType.SERVICE_ACCOUNT
    ):
        sa_obj = conn.get("serviceAccount")
        if isinstance(sa_obj, dict):
            metadata["service_account_orn"] = sa_obj.get("orn", "")
            if sa_obj.get("name"):
                metadata["service_account_name"] = sa_obj["name"]
        app_obj = conn.get("app")
        if isinstance(app_obj, dict):
            metadata["app_orn"] = app_obj.get("orn", "")

    elif conn_type == OktaConnectionType.STS_ACCESS_TOKEN:
        resource_obj = conn.get("resource")
        if isinstance(resource_obj, dict):
            metadata["app_instance_id"] = resource_obj.get("appInstanceId")
            metadata["app_instance_name"] = resource_obj.get("appInstanceName")
            metadata["resource_orn"] = resource_obj.get("orn")
            metadata["resource_type"] = resource_obj.get("resourceType")
        metadata["resource_indicator"] = conn.get("resourceIndicator")

    return metadata


def parse_connection_type(conn: dict) -> Optional[OktaConnectionType]:
    """Parse the connection type from an Okta connection dict.

    Handles both 'type' and 'connectionType' field names.
    Returns None if the type is unrecognized.
    """
    conn_type_str = conn.get("type") or conn.get("connectionType", "")
    if not conn_type_str:
        return None
    try:
        return OktaConnectionType(conn_type_str)
    except ValueError:
        return None


def extract_resource_id_from_connection(
    conn: dict,
) -> tuple[Optional[str], Optional[OktaConnectionType]]:
    """Extract resource_id and connection type from an Okta connection dict.

    Convenience wrapper that combines parse_connection_type and
    extract_resource_id so callers don't need to handle both steps.

    Returns (resource_id, conn_type).  Either or both may be None.
    """
    conn_type = parse_connection_type(conn)
    if not conn_type:
        return None, None
    resource_id = extract_resource_id(conn, conn_type)
    return resource_id, conn_type
