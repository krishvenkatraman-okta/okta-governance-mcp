"""
Pydantic models for the Resources subsystem.

Defines:
- Resource: one row in the collapsed ``resources`` table (provenance +
  routing + sync state for a single (agent, Okta Managed Connection)).
- OktaConnectionType / OktaScopeCondition: Okta Managed Connection enums
- ResolvedResource: runtime view consumed by the request pipeline
- SyncResult: outcome of an Okta sync operation
"""

import re
from datetime import datetime
from enum import Enum
from typing import Optional

from pydantic import BaseModel, field_validator, model_validator


# ---------------------------------------------------------------------------
# Enums
# ---------------------------------------------------------------------------


class OktaConnectionType(str, Enum):
    """Okta Managed Connection types.

    Canonical values returned by the Okta AI Agent Connections API.
    Legacy aliases (SECRET, SERVICE_ACCOUNT) kept for backward compat
    with older API responses and existing resource data.
    """

    IDENTITY_ASSERTION_CUSTOM_AS = "IDENTITY_ASSERTION_CUSTOM_AS"
    STS_VAULT_SECRET = "STS_VAULT_SECRET"
    STS_SERVICE_ACCOUNT = "STS_SERVICE_ACCOUNT"
    STS_ACCESS_TOKEN = "STS_ACCESS_TOKEN"
    # Legacy aliases
    SECRET = "SECRET"
    SERVICE_ACCOUNT = "SERVICE_ACCOUNT"


class OktaScopeCondition(str, Enum):
    """Scope filtering policy for an Okta Managed Connection."""

    INCLUDE_ONLY = "INCLUDE_ONLY"
    EXCLUDE = "EXCLUDE"
    DISALLOW = "DISALLOW"
    ALLOW_ALL = "ALLOW_ALL"

    @classmethod
    def _missing_(cls, value):
        if isinstance(value, str) and value.upper() == "ALL_SCOPES":
            return cls.ALLOW_ALL
        return None


# Auto-derivation mapping: connection_type → auth_method
_CONNECTION_TYPE_TO_AUTH_METHOD = {
    OktaConnectionType.IDENTITY_ASSERTION_CUSTOM_AS: "okta-cross-app",
    OktaConnectionType.STS_VAULT_SECRET: "vault-secret",
    OktaConnectionType.STS_SERVICE_ACCOUNT: "sts-service-account",
    OktaConnectionType.STS_ACCESS_TOKEN: "okta-sts",
    # Legacy aliases
    OktaConnectionType.SECRET: "vault-secret",
    OktaConnectionType.SERVICE_ACCOUNT: "sts-service-account",
}


# ---------------------------------------------------------------------------
# Resource row
# ---------------------------------------------------------------------------


class Resource(BaseModel):
    """A single row in the ``resources`` table — one (agent, connection) pair.

    Provenance (``agent_id`` / ``connection_id``) and sync state
    (``connection_type`` / ``scopes`` / ``scope_condition`` /
    ``auth_method`` / ``metadata``) are written by the Okta syncer.
    Routing (``name`` / ``mcp_url`` / ``protocol`` / ``description``)
    and lifecycle (``enabled``) are admin-editable.
    """

    # Routing / identity
    name: str
    mcp_url: str = ""
    protocol: str = "mcp"
    description: str = ""
    config: dict = {}
    tags: list[str] = []
    enabled: bool = True

    # Provenance (set by syncer, never by admin)
    agent_id: str = ""
    connection_id: str = ""

    # Okta connection state (set by syncer)
    connection_type: str = ""
    auth_method: str = ""
    metadata: dict = {}
    scopes: list[str] = []
    scope_condition: str = "ALLOW_ALL"

    # DB id of the underlying ``resources`` row. Useful for the admin API
    # returning canonical handles even when ``name`` changes.
    resource_id: str = ""

    @field_validator("name")
    @classmethod
    def validate_name(cls, v: str) -> str:
        if not v or len(v) > 100:
            raise ValueError("name must be 1-100 characters")
        if not re.match(r"^[a-z]([a-z0-9-]*[a-z0-9])?$", v):
            raise ValueError(
                "name must be a valid slug: ^[a-z][a-z0-9-]*[a-z0-9]$ or a single lowercase char"
            )
        return v

    @field_validator("mcp_url")
    @classmethod
    def validate_url(cls, v: str) -> str:
        # Empty string is valid — sync creates stubs with url="" that the
        # admin fills in before enabling. Router skips disabled rows.
        if v and not (v.startswith("http://") or v.startswith("https://")):
            raise ValueError("mcp_url must start with http:// or https://")
        return v

    @field_validator("protocol")
    @classmethod
    def validate_type(cls, v: str) -> str:
        if v not in ("mcp", "a2a", "api"):
            raise ValueError("protocol must be 'mcp', 'a2a', or 'api'")
        return v

    # Alias properties used by older callers
    @property
    def url(self) -> str:
        return self.mcp_url

    @property
    def type(self) -> str:
        return self.protocol


# Backward compatibility alias
ResourceMapEntry = Resource


# ---------------------------------------------------------------------------
# Resolved view for the runtime pipeline
# ---------------------------------------------------------------------------


class ResolvedResource(BaseModel):
    """Runtime view of a :class:`Resource` row used by the request pipeline."""

    # From Resource
    resource_id: str = ""
    name: str
    mcp_url: str
    protocol: str = "mcp"
    description: str = ""
    config: dict = {}
    tags: list[str] = []
    enabled: bool = True

    # From Okta Managed Connection
    connection_id: str
    connection_type: OktaConnectionType
    auth_method: str = ""
    scopes: list[str] = []
    scope_condition: OktaScopeCondition = OktaScopeCondition.ALLOW_ALL

    # Optional connection metadata (e.g., secret ORN, app ORN, service account ORN)
    metadata: dict = {}

    # Connection-scoped identity fields (for agent+connection isolation)
    agent_id: Optional[str] = None
    agent_name: Optional[str] = None

    @property
    def isolation_key(self) -> str:
        """Unique key: {agent_id}:{connection_id}:{resource_name}."""
        parts = []
        if self.agent_id:
            parts.append(self.agent_id)
        if self.connection_id:
            parts.append(self.connection_id)
        parts.append(self.name)
        return ":".join(parts)

    @model_validator(mode="before")
    @classmethod
    def derive_auth_method(cls, values):
        """Auto-derive auth_method from connection_type if not set."""
        if isinstance(values, dict):
            conn_type = values.get("connection_type")
            auth = values.get("auth_method")
            if not auth and conn_type:
                if isinstance(conn_type, str):
                    conn_type = OktaConnectionType(conn_type)
                values["auth_method"] = _CONNECTION_TYPE_TO_AUTH_METHOD.get(
                    conn_type, ""
                )
        return values

    @property
    def url(self) -> str:
        return self.mcp_url

    @property
    def type(self) -> str:
        return self.protocol


# Backward compatibility alias
ResolvedBackend = ResolvedResource


class SyncResult(BaseModel):
    """Outcome of an Okta Managed Connections sync operation."""

    added: list[str] = []
    removed: list[str] = []
    modified: list[str] = []
    unresolved: list[str] = []
    total: int = 0
    synced_at: datetime
