"""
Okta Managed Connections syncer for the Resources subsystem.

Iterates over all imported agents (those with okta_ai_agent_id in the
database), fetches each agent's Managed Connections from the Okta API,
merges the union of all connections with the Resources L1 cache, and
produces ResolvedResource objects that the request pipeline consumes for
routing and authentication.

On sync completion, publishes to the CacheEventBus so all pods update.
"""

import logging
import time
from datetime import datetime
from typing import Optional

import httpx

from okta_agent_proxy.audit import emit_audit_event, AuditEventType, AuditSeverity
from okta_agent_proxy.auth.scope_filter import filter_as_scopes
from okta_agent_proxy.resources.event_bus import (
    CHANNEL_OKTA_SYNC,
    CHANNEL_RESOURCE_CHANGED,
    CacheEventBus,
)
from okta_agent_proxy.resources.models import (
    _CONNECTION_TYPE_TO_AUTH_METHOD,
    OktaConnectionType,
    OktaScopeCondition,
    ResolvedResource,
    SyncResult,
)
from okta_agent_proxy.resources.utils import (
    extract_connection_metadata,
    extract_resource_id,
    parse_connection_type,
    parse_orn,
)


def _slugify(raw: str, fallback: str = "resource") -> str:
    """Produce a Resource.name slug from a human-readable string."""
    import re as _re

    if not raw:
        raw = fallback
    cleaned = _re.sub(r"[^a-z0-9-]+", "-", raw.lower()).strip("-")
    if not cleaned:
        cleaned = fallback.lower()
    if not cleaned[0].isalpha():
        cleaned = f"r-{cleaned}"
    return cleaned[:100]


def _unique_slug(base: str, taken: set[str]) -> str:
    """Return ``base`` if unused, else ``base-2``, ``base-3``, …"""
    candidate = base
    i = 2
    while candidate in taken:
        candidate = f"{base}-{i}"
        i += 1
    return candidate
from okta_agent_proxy.storage.repositories.resource_repo import (
    ResourceRepository as ResourceStore,
)

logger = logging.getLogger(__name__)


class OktaConnectionSyncer:
    """
    Fetches Okta Managed Connections for all imported agents and merges
    them with the Resources to produce ResolvedResource objects.

    Each imported agent (with okta_ai_agent_id) has its own connections
    in Okta.  The syncer fetches connections for every such agent and
    produces a union of all resolved resources.

    Lifecycle:
      syncer = OktaConnectionSyncer(...)
      await syncer.start()        # creates HTTP client, subscribes to events
      result = await syncer.sync() # first sync
      ...
      await syncer.stop()         # cleanup
    """

    def __init__(
        self,
        okta_domain: str,
        api_token: str,
        resource_store: ResourceStore = None,
        event_bus: CacheEventBus = None,
        stale_threshold: int = 1800,
        # Backward-compat alias
        resource_map_store: ResourceStore = None,
    ):
        self._okta_domain = okta_domain.rstrip("/")
        if not self._okta_domain.startswith("http"):
            self._okta_domain = f"https://{self._okta_domain}"
        self._api_token = api_token
        self._store = resource_store or resource_map_store
        self._event_bus = event_bus
        self._stale_threshold = stale_threshold

        self._resources: dict[str, ResolvedResource] = {}
        self._unresolved: list[str] = []
        self._last_sync_at: Optional[datetime] = None
        self._last_sync_status: str = "never"
        self._http_client: Optional[httpx.AsyncClient] = None

        # Raw connection data from last Okta API call, kept for re-merge
        # Keyed by okta_ai_agent_id → list of connections
        self._last_connections: dict[str, list[dict]] = {}

        # Agent info from last sync, keyed by okta_ai_agent_id
        # Used by _re_merge to rebuild annotated connections
        self._last_agent_info: dict[str, dict] = {}

        # Flat list of raw connections from the most recent sync
        # (used by agent detail endpoint to show all connections)
        self._raw_connections: list[dict] = []

        # Per-sync cache of AS metadata -> filtered scopes_supported.
        # Populated in sync()/sync_single_agent() before _merge_connections runs so
        # ALLOW_ALL connections can materialize concrete scope lists. Keyed by
        # issuer_url. Reused by _re_merge with last-known values.
        self._as_scopes_cache: dict[str, list[str]] = {}

    # ------------------------------------------------------------------
    # Lifecycle
    # ------------------------------------------------------------------

    async def start(self):
        """Create HTTP client, hydrate from store, and subscribe to event bus channels."""
        self._http_client = httpx.AsyncClient(timeout=30.0)
        self._hydrate_from_store()
        self._event_bus.subscribe(CHANNEL_OKTA_SYNC, self._on_okta_sync_event)
        self._event_bus.subscribe(
            CHANNEL_RESOURCE_CHANGED, self._on_resource_changed
        )

    def _hydrate_from_store(self):
        """Load ResolvedResources from the resources table on startup.

        Each row is already (agent_id, connection_id, connection_type,
        scopes, scope_condition, metadata) — no inference needed.
        Disabled rows are skipped because the router won't serve them.
        """
        hydrated = 0
        for entry in self._store.get_all():
            if not entry.enabled:
                continue
            if not entry.connection_type:
                logger.info(
                    "Skipping hydration for '%s' — no connection_type",
                    entry.name,
                )
                continue
            try:
                conn_type = OktaConnectionType(entry.connection_type)
            except ValueError:
                logger.warning(
                    "Unknown connection_type '%s' in resource '%s'",
                    entry.connection_type, entry.name,
                )
                continue

            metadata = entry.metadata if isinstance(entry.metadata, dict) else {}

            # Derive effective resource_id for auth from metadata (falls
            # back to the stored connection_resource_id).
            effective_resource_id = entry.resource_id
            if conn_type == OktaConnectionType.IDENTITY_ASSERTION_CUSTOM_AS:
                as_orn = metadata.get("authorization_server_orn", "")
                if as_orn and "authorization_servers:" in as_orn:
                    effective_resource_id = as_orn.split("authorization_servers:")[-1]
            elif conn_type == OktaConnectionType.STS_ACCESS_TOKEN:
                ri = metadata.get("resource_indicator", "")
                if ri and "client-auth-settings:" in ri:
                    effective_resource_id = ri.split("client-auth-settings:")[-1]

            try:
                scope_condition = OktaScopeCondition(entry.scope_condition)
            except ValueError:
                scope_condition = OktaScopeCondition.ALLOW_ALL

            resolved = ResolvedResource(
                resource_id=effective_resource_id,
                name=entry.name,
                mcp_url=entry.mcp_url,
                protocol=entry.protocol,
                description=entry.description,
                config=entry.config,
                tags=entry.tags,
                enabled=entry.enabled,
                connection_id=entry.connection_id,
                connection_type=conn_type,
                auth_method=entry.auth_method or "",
                scopes=list(entry.scopes or []),
                scope_condition=scope_condition,
                metadata=metadata,
                agent_id=entry.agent_id or None,
            )
            self._resources[resolved.isolation_key] = resolved
            hydrated += 1
        if hydrated:
            logger.info("Hydrated %d resolved resources from store", hydrated)

    async def stop(self):
        """Close HTTP client."""
        if self._http_client:
            await self._http_client.aclose()
            self._http_client = None

    # ------------------------------------------------------------------
    # Sync
    # ------------------------------------------------------------------

    def _get_imported_agent_ids(self) -> list[str]:
        """Get okta_ai_agent_id values for all imported agents in the database."""
        agents = self._get_imported_agents()
        return [a["okta_ai_agent_id"] for a in agents]

    def _get_imported_agents(self) -> list[dict]:
        """Get imported agents (those with okta_ai_agent_id) from the database.

        Returns list of dicts with keys: okta_ai_agent_id, agent_id, agent_name.
        """
        try:
            from okta_agent_proxy.database import get_store
            store = get_store()
            all_agents = store.get_all_agents(enabled_only=False)
            return [
                {
                    "okta_ai_agent_id": a["okta_ai_agent_id"],
                    "agent_id": a.get("agent_id", ""),
                    "agent_name": a.get("agent_name", ""),
                }
                for a in all_agents
                if a.get("okta_ai_agent_id")
            ]
        except Exception as e:
            logger.error("Failed to get imported agents: %s", e)
            return []

    def _get_agent_info_by_okta_id(self, okta_ai_agent_id: str) -> Optional[dict]:
        """Get agent info for a single okta_ai_agent_id."""
        for agent in self._get_imported_agents():
            if agent["okta_ai_agent_id"] == okta_ai_agent_id:
                return agent
        return None

    async def sync(self, publish: bool = True, okta_token: str | None = None) -> SyncResult:
        """
        Core sync: for each imported agent, fetch its Okta connections,
        merge with Resources, produce ResolvedResources.

        1. Get all imported agents (those with okta_ai_agent_id)
        2. For each agent, call Okta Managed Connections API
        3. Parse each connection and extract resource_id
        4. Look up resource_id in ResourceStore L1 cache
        5. If found + ACTIVE: create ResolvedResource
        6. If not found: add to unresolved list
        7. Diff against previous resources
        8. Persist sync state
        9. If publish=True: publish okta:sync event

        Args:
            publish: Whether to publish sync event to event bus.
            okta_token: Optional admin Okta token to use instead of the
                pre-configured service token (for UI-triggered syncs).
        """
        start_ms = time.monotonic()

        imported_agents = self._get_imported_agents()
        agent_ids = [a["okta_ai_agent_id"] for a in imported_agents]
        # Build lookup from okta_ai_agent_id → agent info
        agent_info_by_okta_id = {
            a["okta_ai_agent_id"]: a for a in imported_agents
        }
        await emit_audit_event(
            AuditEventType.OKTA_SYNC_STARTED,
            details={"agent_count": len(agent_ids)},
        )
        if not agent_ids:
            logger.info("No imported agents with okta_ai_agent_id found — nothing to sync")
            self._last_sync_status = "success"
            self._last_sync_at = datetime.utcnow()
            return SyncResult(
                total=len(self._resources),
                unresolved=list(self._unresolved),
                synced_at=self._last_sync_at,
            )

        # Fetch connections for all agents
        all_connections: dict[str, list[dict]] = {}
        had_errors = False
        for agent_id in agent_ids:
            try:
                connections = await self._fetch_connections(
                    agent_id=agent_id, okta_token=okta_token
                )
                all_connections[agent_id] = connections
            except Exception as exc:
                logger.error(
                    "Okta Connections API error for agent %s: %s", agent_id, exc
                )
                had_errors = True
                # Keep last-known connections for this agent
                if agent_id in self._last_connections:
                    all_connections[agent_id] = self._last_connections[agent_id]

        if had_errors and not all_connections:
            # All agents failed — keep last-known-good state
            self._last_sync_status = "error"
            duration_ms = int((time.monotonic() - start_ms) * 1000)
            await emit_audit_event(
                AuditEventType.OKTA_SYNC_FAILED,
                severity=AuditSeverity.WARNING,
                details={"error": "all_agents_failed", "duration_ms": duration_ms},
                outcome="failure",
            )
            self._store.save_sync_state(
                "error",
                len(self._resources),
                len(self._unresolved),
                duration_ms,
            )
            return SyncResult(
                total=len(self._resources),
                unresolved=list(self._unresolved),
                synced_at=datetime.utcnow(),
            )

        self._last_connections = all_connections
        self._last_agent_info = agent_info_by_okta_id

        # Build annotated connections with agent context preserved
        annotated_connections: list[tuple[dict, dict]] = []  # (connection, agent_info)
        flat_connections = []
        for okta_agent_id, conns in all_connections.items():
            agent_info = agent_info_by_okta_id.get(okta_agent_id, {})
            for conn in conns:
                annotated_connections.append((conn, agent_info))
                flat_connections.append(conn)

        self._raw_connections = list(flat_connections)

        # Refresh AS scopes_supported cache for ALLOW_ALL connections so
        # _merge_connections can materialize concrete scope lists.
        self._as_scopes_cache = {}
        await self._prefetch_allow_all_scopes(flat_connections)

        new_resources, new_unresolved = self._merge_connections(
            flat_connections, annotated_connections=annotated_connections
        )

        # Diff (compare by isolation_key, report resource names)
        old_keys = set(self._resources.keys())
        new_keys = set(new_resources.keys())
        added_keys = new_keys - old_keys
        removed_keys = old_keys - new_keys
        modified_keys = {
            key
            for key in old_keys & new_keys
            if self._resources[key] != new_resources[key]
        }
        # Report by resource name (deduplicated)
        added = sorted({new_resources[k].name for k in added_keys})
        removed = sorted({self._resources[k].name for k in removed_keys})
        modified = sorted({new_resources[k].name for k in modified_keys})

        self._resources = new_resources
        self._unresolved = new_unresolved
        self._last_sync_at = datetime.utcnow()
        self._last_sync_status = "success" if not had_errors else "partial"

        duration_ms = int((time.monotonic() - start_ms) * 1000)
        self._store.save_sync_state(
            self._last_sync_status,
            len(self._resources),
            len(self._unresolved),
            duration_ms,
        )

        result = SyncResult(
            added=added,
            removed=removed,
            modified=modified,
            unresolved=new_unresolved,
            total=len(self._resources),
            synced_at=self._last_sync_at,
        )

        if publish:
            await self._event_bus.publish(CHANNEL_OKTA_SYNC, "sync-complete")

        logger.info(
            "Okta sync complete: %d agents, %d resources, %d unresolved, "
            "+%d -%d ~%d in %dms",
            len(agent_ids),
            result.total,
            len(result.unresolved),
            len(result.added),
            len(result.removed),
            len(result.modified),
            duration_ms,
        )
        await emit_audit_event(
            AuditEventType.OKTA_SYNC_COMPLETED,
            details={
                "resources_count": result.total,
                "unresolved_count": len(result.unresolved),
                "added": result.added,
                "removed": result.removed,
                "duration_ms": duration_ms,
            },
        )
        return result

    async def sync_single_agent(
        self,
        okta_ai_agent_id: str,
        okta_token: str | None = None,
        publish: bool = True,
    ) -> SyncResult:
        """Sync connections for a single agent without fetching all agents.

        More efficient than full sync() when only one agent changed —
        makes 1 Okta API call instead of N.
        Falls back to full sync() if no cached connection data exists.
        """
        start_ms = time.monotonic()

        # If no cached data from prior syncs, fall back to full sync
        if not self._last_connections and not self._resources:
            return await self.sync(okta_token=okta_token, publish=publish)

        # Look up agent info
        agent_info = self._get_agent_info_by_okta_id(okta_ai_agent_id)
        if not agent_info:
            logger.warning("sync_single_agent: agent %s not found in DB", okta_ai_agent_id)
            return SyncResult(
                total=len(self._resources),
                unresolved=list(self._unresolved),
                synced_at=datetime.utcnow(),
            )

        # Fetch connections for this one agent only
        try:
            connections = await self._fetch_connections(
                agent_id=okta_ai_agent_id, okta_token=okta_token
            )
        except Exception as exc:
            logger.error("sync_single_agent: fetch failed for %s: %s", okta_ai_agent_id, exc)
            # Keep last-known connections for this agent
            if okta_ai_agent_id not in self._last_connections:
                return SyncResult(
                    total=len(self._resources),
                    unresolved=list(self._unresolved),
                    synced_at=datetime.utcnow(),
                )
            connections = self._last_connections[okta_ai_agent_id]

        # Update cached data for this agent, preserve others
        self._last_connections[okta_ai_agent_id] = connections
        self._last_agent_info[okta_ai_agent_id] = agent_info

        # Rebuild full annotated connections from ALL cached agents
        annotated_connections: list[tuple[dict, dict]] = []
        flat_connections: list[dict] = []
        for oka_id, conns in self._last_connections.items():
            a_info = self._last_agent_info.get(oka_id, {})
            for conn in conns:
                annotated_connections.append((conn, a_info))
                flat_connections.append(conn)

        self._raw_connections = list(flat_connections)

        # Refresh AS scopes cache for just this agent's connections; retains
        # prior cache entries for other agents' ALs.
        await self._prefetch_allow_all_scopes(connections)

        new_resources, new_unresolved = self._merge_connections(
            flat_connections, annotated_connections=annotated_connections
        )

        # Diff — report only this agent's changes
        adapter_agent_id = agent_info.get("agent_id", "")
        old_keys = set(self._resources.keys())
        new_keys = set(new_resources.keys())
        added_keys = new_keys - old_keys
        removed_keys = old_keys - new_keys
        modified_keys = {
            k for k in old_keys & new_keys
            if self._resources[k] != new_resources[k]
        }

        def _is_this_agent(key: str) -> bool:
            return key.startswith(f"{adapter_agent_id}:") if adapter_agent_id else False

        added = sorted({new_resources[k].name for k in added_keys if _is_this_agent(k)})
        removed = sorted({self._resources[k].name for k in removed_keys if _is_this_agent(k)})
        modified = sorted({new_resources[k].name for k in modified_keys if _is_this_agent(k)})

        self._resources = new_resources
        self._unresolved = new_unresolved
        self._last_sync_at = datetime.utcnow()
        self._last_sync_status = "success"

        duration_ms = int((time.monotonic() - start_ms) * 1000)
        self._store.save_sync_state(
            self._last_sync_status,
            len(self._resources),
            len(self._unresolved),
            duration_ms,
        )

        result = SyncResult(
            added=added,
            removed=removed,
            modified=modified,
            unresolved=new_unresolved,
            total=len(self._resources),
            synced_at=self._last_sync_at,
        )

        if publish:
            await self._event_bus.publish(CHANNEL_OKTA_SYNC, "sync-complete")

        logger.info(
            "Single-agent sync for %s complete: %d resources, +%d -%d ~%d in %dms",
            okta_ai_agent_id, result.total,
            len(result.added), len(result.removed), len(result.modified),
            duration_ms,
        )
        return result

    # ------------------------------------------------------------------
    # Read accessors
    # ------------------------------------------------------------------

    def get_resource(self, name: str) -> Optional[ResolvedResource]:
        # Direct key lookup first (backward compat for name-keyed entries)
        if name in self._resources:
            return self._resources[name]
        # Scan by resource name for isolation-keyed entries
        for resource in self._resources.values():
            if resource.name == name:
                return resource
        return None

    def register_resolved_resource(self, resolved: ResolvedResource) -> None:
        """Register a single ResolvedResource directly (bypasses full Okta sync)."""
        self._resources[resolved.isolation_key] = resolved
        logger.info(
            "Registered resolved resource '%s' (connection=%s, type=%s, isolation_key=%s)",
            resolved.name, resolved.connection_id, resolved.connection_type.value,
            resolved.isolation_key,
        )

    def get_all_resources(self) -> list[ResolvedResource]:
        logger.warning(
            "[SYNCER] get_all_resources() called without agent scoping "
            "— migrate to get_resolved_resources_for_agent()."
        )
        return list(self._resources.values())

    def get_resolved_resources_for_agent(self, agent_id: str) -> dict[str, ResolvedResource]:
        """Return resources visible to a specific agent.

        Returns entries where agent_id matches OR agent_id is None (local resources).
        Keyed by resource name for pipeline compatibility.
        """
        result: dict[str, ResolvedResource] = {}
        for resource in self._resources.values():
            if resource.agent_id is None:
                result[resource.name] = resource
            elif resource.agent_id == agent_id:
                result[resource.name] = resource
        return result

    def get_all_resolved_resources_raw(self) -> dict[str, ResolvedResource]:
        """Return all resolved resources keyed by isolation_key for admin inspection."""
        return dict(self._resources)

    def get_unresolved(self) -> list[str]:
        return list(self._unresolved)

    def get_raw_connections(self) -> list[dict]:
        """Return raw connection dicts from the most recent sync."""
        return list(self._raw_connections)

    def is_stale(self) -> bool:
        if not self._last_sync_at:
            return True
        return (
            datetime.utcnow() - self._last_sync_at
        ).total_seconds() > self._stale_threshold

    def get_sync_status(self) -> dict:
        return {
            "last_sync_at": (
                self._last_sync_at.isoformat() if self._last_sync_at else None
            ),
            "status": self._last_sync_status,
            "is_stale": self.is_stale(),
            "resources_count": len(self._resources),
            "unresolved_count": len(self._unresolved),
        }

    # ------------------------------------------------------------------
    # Event handlers
    # ------------------------------------------------------------------

    async def _on_okta_sync_event(self, message: str):
        """Handler for okta:sync events from other pods.

        Only re-syncs if a service token is available for background sync.
        Without a service token, syncs can only be triggered from the Admin UI
        (which forwards the admin's Okta token).
        """
        if self._api_token:
            await self.sync(publish=False)
        else:
            # No service token — just re-merge with existing connection data
            await self._re_merge()

    async def _on_resource_changed(self, message: str):
        """Handler for resource:changed events.

        Re-merge existing Okta connections with updated Resources
        without calling the Okta API again.  Also hydrate any new
        resources that have connection info in their config.
        """
        self._store.load_cache()
        self._hydrate_from_store()
        await self._re_merge()

    async def _re_merge(self):
        """Re-merge last-fetched Okta connections with current Resources."""
        if not self._last_connections:
            return
        annotated_connections: list[tuple[dict, dict]] = []
        flat_connections = []
        for okta_agent_id, conns in self._last_connections.items():
            agent_info = self._last_agent_info.get(okta_agent_id, {})
            for conn in conns:
                annotated_connections.append((conn, agent_info))
                flat_connections.append(conn)
        new_resources, new_unresolved = self._merge_connections(
            flat_connections, annotated_connections=annotated_connections
        )
        self._resources = new_resources
        self._unresolved = new_unresolved

    # ------------------------------------------------------------------
    # Okta API
    # ------------------------------------------------------------------

    async def _fetch_as_supported_scopes(
        self, issuer_url: str
    ) -> Optional[list[str]]:
        """GET {issuer_url}/.well-known/openid-configuration → scopes_supported.

        The well-known endpoint is public on Okta auth servers, so no bearer
        token is attached. Any failure (network, non-200, missing key) returns
        None and the caller leaves the connection's scopes untouched.
        """
        if not self._http_client:
            return None
        url = f"{issuer_url.rstrip('/')}/.well-known/openid-configuration"
        try:
            resp = await self._http_client.get(url, timeout=10.0)
            if resp.status_code != 200:
                logger.warning(
                    "AS metadata fetch returned %s for %s", resp.status_code, url,
                )
                return None
            data = resp.json()
            scopes = data.get("scopes_supported")
            if not isinstance(scopes, list):
                logger.warning("AS metadata at %s missing scopes_supported", url)
                return None
            cleaned = [s for s in scopes if isinstance(s, str)]
            # Full list at INFO so admins can see what AS advertised when
            # debugging invalid_scope errors — and add offenders to
            # OKTA_SCOPE_BLOCKLIST if needed.
            logger.info(
                "AS metadata %s advertises %d scopes: %s",
                issuer_url, len(cleaned), sorted(cleaned),
            )
            return cleaned
        except Exception as exc:
            logger.warning(
                "AS metadata fetch failed for %s: %s: %s",
                issuer_url, type(exc).__name__, exc,
            )
            return None

    async def _prefetch_allow_all_scopes(self, connections: list[dict]) -> None:
        """For every ALLOW_ALL IDENTITY_ASSERTION_CUSTOM_AS connection, fetch
        and filter scopes_supported. Populates self._as_scopes_cache.

        Deduplicates by issuer_url so multiple resources targeting the same AS
        only trigger one HTTP call per sync run.
        """
        issuer_urls: set[str] = set()
        candidates = 0
        for conn in connections:
            conn_type = parse_connection_type(conn)
            if conn_type != OktaConnectionType.IDENTITY_ASSERTION_CUSTOM_AS:
                continue
            scope_cond_str = conn.get("scopeCondition") or conn.get("scope_condition")
            # Normalize through the enum so Okta's "ALL_SCOPES" wire value and
            # any other aliases map to the canonical ALLOW_ALL member.
            scope_condition = OktaScopeCondition.ALLOW_ALL
            if scope_cond_str:
                try:
                    scope_condition = OktaScopeCondition(scope_cond_str)
                except ValueError:
                    scope_condition = OktaScopeCondition.ALLOW_ALL
            if scope_condition != OktaScopeCondition.ALLOW_ALL:
                continue
            candidates += 1
            metadata = extract_connection_metadata(conn, conn_type)
            issuer_url = metadata.get("issuer_url")
            if not issuer_url:
                as_id = extract_resource_id(conn, conn_type)
                if as_id:
                    issuer_url = f"{self._okta_domain}/oauth2/{as_id}"
            if issuer_url:
                issuer_urls.add(issuer_url)
            else:
                logger.warning(
                    "ALLOW_ALL connection %s has no issuer_url and no resource_id "
                    "-- cannot materialize scopes_supported",
                    conn.get("id") or conn.get("name") or "?",
                )

        logger.info(
            "ALLOW_ALL prefetch: %d candidate connections, %d unique issuers",
            candidates, len(issuer_urls),
        )
        for issuer_url in issuer_urls:
            if issuer_url in self._as_scopes_cache:
                continue
            raw = await self._fetch_as_supported_scopes(issuer_url)
            if raw is not None:
                filtered = filter_as_scopes(raw)
                self._as_scopes_cache[issuer_url] = filtered
                dropped = sorted(set(raw) - set(filtered))
                logger.info(
                    "ALLOW_ALL materialized for %s: kept=%s dropped=%s "
                    "(adjust OKTA_SCOPE_BLOCKLIST to drop more)",
                    issuer_url, filtered, dropped,
                )

    async def _fetch_connections(
        self, agent_id: str, okta_token: str | None = None
    ) -> list[dict]:
        """Call Okta Managed Connections API for a specific agent.

        GET {okta_domain}/workload-principals/api/v1/ai-agents/{agent_id}/connections

        IMPORTANT: Pass Authorization header directly — never use httpx auth=
        parameter (causes encoding corruption with Okta).

        Args:
            agent_id: The Okta AI Agent ID to fetch connections for.
            okta_token: Optional admin Okta token to use instead of the
                pre-configured service token.
        """
        if not self._http_client:
            raise RuntimeError("Syncer not started — call start() first")

        token = okta_token or self._api_token
        if not token:
            raise RuntimeError(
                "No API token available. Either set OKTA_SERVICE_TOKEN for "
                "background sync, or trigger sync from the Admin UI (which "
                "forwards your Okta session token)."
            )

        url = (
            f"{self._okta_domain}/workload-principals/api/v1/"
            f"ai-agents/{agent_id}/connections"
        )
        headers = {
            "Authorization": f"Bearer {token}",
            "Accept": "application/json",
        }

        resp = await self._http_client.get(url, headers=headers)
        if resp.status_code != 200:
            logger.warning(
                "Okta Connections API %s for agent %s: %s",
                resp.status_code, agent_id, resp.text,
            )
            raise httpx.HTTPStatusError(
                f"Okta API returned {resp.status_code}",
                request=resp.request,
                response=resp,
            )

        data = resp.json()
        logger.info(
            "Okta Connections API response for agent %s: %d status, "
            "type=%s, keys=%s, len=%s",
            agent_id, resp.status_code,
            type(data).__name__,
            list(data.keys()) if isinstance(data, dict) else "N/A",
            len(data) if isinstance(data, (list, dict)) else "N/A",
        )
        if isinstance(data, list):
            return data
        # Okta wraps results in {"data": [...], "_links": {...}}
        # or {"connections": [...]} or {"items": [...]}
        connections = (
            data.get("data")
            or data.get("connections")
            or data.get("items")
            or []
        )
        if isinstance(connections, list):
            logger.info(
                "Parsed %d connections for agent %s", len(connections), agent_id
            )
            return connections
        return []

    # ------------------------------------------------------------------
    # Merge logic
    # ------------------------------------------------------------------

    def _merge_connections(
        self,
        connections: list[dict],
        annotated_connections: list[tuple[dict, dict]] | None = None,
    ) -> tuple[dict[str, ResolvedResource], list[str]]:
        """Upsert one row per (agent, connection) and build resolved resources.

        Each connection is materialized directly into the ``resources``
        table. New rows start disabled with ``url=""``; admins flip
        ``enabled`` and set ``url`` via the Admin UI once ready.
        """
        resources: dict[str, ResolvedResource] = {}
        unresolved: list[str] = []

        conn_agent_map: dict[int, dict] = {}
        if annotated_connections:
            for conn, agent_info in annotated_connections:
                conn_agent_map[id(conn)] = agent_info

        # Refresh cache once so slug-uniqueness checks see the latest rows.
        self._store.load_cache()

        for conn in connections:
            status = conn.get("status", "ACTIVE")
            if status != "ACTIVE":
                logger.info(
                    "Skipping connection %s: status=%s", conn.get("id"), status,
                )
                continue

            conn_type_str = conn.get("type") or conn.get("connectionType", "")
            try:
                conn_type = OktaConnectionType(conn_type_str)
            except ValueError:
                logger.warning(
                    "Unknown connection type: %s (conn keys: %s)",
                    conn_type_str, list(conn.keys()),
                )
                continue

            connection_id = conn.get("id", "")
            if not connection_id:
                logger.info("Skipping connection with no id: %s", conn)
                continue

            agent_info = conn_agent_map.get(id(conn), {})
            agent_id = agent_info.get("agent_id") or ""
            if not agent_id:
                logger.info(
                    "Skipping connection %s: no agent context", connection_id,
                )
                continue

            resource_id = self._extract_resource_id(conn, conn_type) or ""

            # Parse scope info. Okta returns `["*"]` for ALLOW_ALL connections
            # as a sentinel; strip it so the ALLOW_ALL expansion below can
            # replace it with the materialized scopes_supported list.
            scopes = [s for s in conn.get("scopes", []) if s != "*"]
            scope_cond_str = conn.get("scopeCondition") or conn.get(
                "scope_condition"
            )
            try:
                scope_condition = (
                    OktaScopeCondition(scope_cond_str)
                    if scope_cond_str
                    else OktaScopeCondition.ALLOW_ALL
                )
            except ValueError:
                scope_condition = OktaScopeCondition.ALLOW_ALL

            metadata = extract_connection_metadata(conn, conn_type)

            # ALLOW_ALL expansion for CUSTOM_AS connections.
            if (
                scope_condition == OktaScopeCondition.ALLOW_ALL
                and conn_type == OktaConnectionType.IDENTITY_ASSERTION_CUSTOM_AS
            ):
                issuer_url = metadata.get("issuer_url")
                if not issuer_url and resource_id:
                    issuer_url = f"{self._okta_domain}/oauth2/{resource_id}"
                cached = self._as_scopes_cache.get(issuer_url) if issuer_url else None
                if cached:
                    scopes = list(cached)
                    logger.info(
                        "ALLOW_ALL expanded for connection %s: %d scopes",
                        conn.get("name") or connection_id, len(scopes),
                    )

            # Ensure resource_indicator is in metadata for STS types.
            ri = conn.get("resourceIndicator", "")
            if ri and "resource_indicator" not in metadata:
                metadata["resource_indicator"] = ri

            auth_method = _CONNECTION_TYPE_TO_AUTH_METHOD.get(conn_type, "")

            # Upsert the DB row for this (agent, connection).
            existing_dict = self._store.get_by_agent_connection(
                agent_id, connection_id
            )

            if existing_dict is None:
                # New row — allocate a unique slug. Use connection name,
                # resource_id, or connection_id as base.
                base_name = conn.get("name") or conn.get("label") or resource_id or connection_id
                base_slug = _slugify(str(base_name))
                taken = set(self._store._cache_by_name.keys())
                slug = _unique_slug(base_slug, taken)
                try:
                    row = self._store.upsert_synced(
                        agent_id=agent_id,
                        connection_id=connection_id,
                        name=slug,
                        connection_type=conn_type.value,
                        scopes=scopes,
                        scope_condition=scope_condition.value,
                        auth_method=auth_method,
                        metadata=metadata,
                        connection_resource_id=resource_id or None,
                        user="syncer-live",
                    )
                    # Refresh cache entry so subsequent slugs see this name.
                    self._store.load_cache()
                except Exception as e:
                    logger.warning(
                        "Failed to upsert new row for agent=%s conn=%s: %s",
                        agent_id, connection_id, e,
                    )
                    if resource_id and resource_id not in unresolved:
                        unresolved.append(resource_id)
                    continue
                entry = self._store.get_by_name(row["name"])
                if entry is None:
                    logger.warning(
                        "Upsert succeeded but cache lookup failed for %s",
                        row.get("name"),
                    )
                    continue
            else:
                # Existing row — refresh sync-owned fields only.
                try:
                    self._store.update_sync_fields(
                        agent_id=agent_id,
                        connection_id=connection_id,
                        scopes=scopes,
                        scope_condition=scope_condition.value,
                        auth_method=auth_method,
                        metadata=metadata,
                        connection_type=conn_type.value,
                        connection_resource_id=resource_id or None,
                        user="syncer-live",
                    )
                    self._store.load_cache()
                except Exception as e:
                    logger.warning(
                        "Failed to update sync fields for agent=%s conn=%s: %s",
                        agent_id, connection_id, e,
                    )
                entry = self._store.get_by_name(existing_dict["name"])
                if entry is None:
                    continue

            # Skip disabled rows — router won't serve them and hydration
            # won't see them, but we still persisted the sync state.
            if not entry.enabled:
                logger.info(
                    "Resource %s synced but disabled — skipping resolve",
                    entry.name,
                )
                continue

            # Effective resource_id for auth: prefer the Okta-extracted
            # auth-server or resource-indicator ID over the raw DB column.
            effective_resource_id = resource_id or entry.resource_id
            if conn_type == OktaConnectionType.IDENTITY_ASSERTION_CUSTOM_AS:
                as_orn = metadata.get("authorization_server_orn", "")
                if as_orn and "authorization_servers:" in as_orn:
                    effective_resource_id = as_orn.split("authorization_servers:")[-1]
            elif conn_type == OktaConnectionType.STS_ACCESS_TOKEN:
                ri_meta = metadata.get("resource_indicator", "")
                if ri_meta and "client-auth-settings:" in ri_meta:
                    effective_resource_id = ri_meta.split("client-auth-settings:")[-1]

            resolved = ResolvedResource(
                resource_id=effective_resource_id,
                name=entry.name,
                mcp_url=entry.mcp_url,
                protocol=entry.protocol,
                description=entry.description,
                config=entry.config,
                tags=entry.tags,
                enabled=entry.enabled,
                connection_id=connection_id,
                connection_type=conn_type,
                auth_method=auth_method,
                scopes=scopes,
                scope_condition=scope_condition,
                metadata=metadata,
                agent_id=agent_id or None,
                agent_name=agent_info.get("agent_name") or None,
            )
            resources[resolved.isolation_key] = resolved

        return resources, unresolved

    @staticmethod
    def _extract_resource_id(
        conn: dict, conn_type: OktaConnectionType
    ) -> Optional[str]:
        """Extract the resource_id from a connection based on its type."""
        return extract_resource_id(conn, conn_type)

    @staticmethod
    def parse_orn(orn: str) -> Optional[str]:
        """Extract authorization server ID from Okta Resource Name."""
        return parse_orn(orn)
