"""
Resources: downstream endpoints the adapter proxies to.

- resources PostgreSQL table: stable address book (resource_id → name + url)
- Okta Managed Connections: per-agent access policy (synced from Okta API)
- L1 in-memory dict: hot-path cache, zero I/O per tool call
- CacheEventBus: Redis pub/sub for cross-pod invalidation

Admin UI has full CRUD on resources. Changes propagate to all
pods instantly via Redis pub/sub, with periodic poll fallback.

No YAML files. No file-based config. PostgreSQL is the sole source
of truth. On first deploy the table is empty — admin creates entries
via the UI, the API, or the Okta Import unresolved connections flow.
"""
