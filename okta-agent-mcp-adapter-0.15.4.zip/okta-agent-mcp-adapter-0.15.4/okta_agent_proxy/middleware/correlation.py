"""ASGI middleware that assigns a correlation ID to every HTTP request."""

import uuid
from typing import Any, Callable

from okta_agent_proxy.audit.context import set_request_context, clear_request_context


class CorrelationIdMiddleware:
    """Raw ASGI middleware that propagates X-Correlation-ID through context vars."""

    def __init__(self, app: Any) -> None:
        self.app = app

    async def __call__(self, scope: dict, receive: Callable, send: Callable) -> None:
        if scope["type"] != "http":
            await self.app(scope, receive, send)
            return

        # Extract correlation ID from request headers or generate one
        headers = dict(scope.get("headers", []))
        correlation_id = (
            headers.get(b"x-correlation-id", b"").decode("latin-1") or str(uuid.uuid4())
        )

        # Extract IP address from client
        client = scope.get("client")
        ip_address = client[0] if client else None

        # Extract User-Agent
        user_agent = headers.get(b"user-agent", b"").decode("latin-1") or None

        # Populate context vars for this request
        set_request_context(
            correlation_id=correlation_id,
            ip_address=ip_address,
            user_agent=user_agent,
        )

        # Store on scope state dict so downstream Starlette code can access it
        if "state" not in scope:
            scope["state"] = {}
        scope["state"]["correlation_id"] = correlation_id

        async def send_with_correlation(message: dict) -> None:
            if message["type"] == "http.response.start":
                headers_list = list(message.get("headers", []))
                headers_list.append((b"x-correlation-id", correlation_id.encode("latin-1")))
                message = {**message, "headers": headers_list}
            await send(message)

        try:
            await self.app(scope, receive, send_with_correlation)
        finally:
            clear_request_context()
