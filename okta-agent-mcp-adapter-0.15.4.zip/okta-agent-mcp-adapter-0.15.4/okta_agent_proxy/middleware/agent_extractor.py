"""
Agent extraction middleware for multi-agent support.

Extracts X-Agent-ID header from requests and validates agent configuration.
Used by ProxyHandler to support multi-agent routing.
"""

import logging
from typing import Optional, Tuple, Dict, Any

from okta_agent_proxy.storage import ResourceConfigStore

logger = logging.getLogger(__name__)


class AgentExtractor:
    """
    Extracts and validates agent information from requests.
    
    Responsibilities:
    - Extract X-Agent-ID from request headers
    - Load agent configuration from store
    - Validate agent is enabled
    - Return agent config for downstream use
    """
    
    def __init__(self, store: ResourceConfigStore):
        """
        Initialize agent extractor.

        Args:
            store: ResourceConfigStore instance for agent lookup
        """
        self.store = store
    
    def extract_agent_from_headers(
        self,
        headers: Dict[str, str]
    ) -> Tuple[Optional[str], Optional[Dict[str, Any]]]:
        """
        Extract agent ID from request headers and load agent config.
        
        Args:
            headers: Request headers dictionary
            
        Returns:
            Tuple of (agent_id, agent_config) or (None, None) if not found/disabled
        """
        # Try to get X-Agent-ID header (case-insensitive)
        agent_id = None
        for key, value in headers.items():
            if key.lower() == "x-agent-id":
                agent_id = value
                break
        
        if not agent_id:
            logger.debug("No X-Agent-ID header in request")
            return None, None
        
        # Load agent config from store
        agent_config = self.store.get_agent(agent_id, enabled_only=True)
        
        if not agent_config:
            logger.warning(f"Agent '{agent_id}' not found or disabled")
            return agent_id, None
        
        logger.debug(f"Extracted agent: {agent_id}")
        return agent_id, agent_config
    
    def get_agent_resource_access(self, agent_id: str) -> list:
        """
        Get list of resources an agent can access.

        Args:
            agent_id: Agent identifier

        Returns:
            List of resource names the agent can access
        """
        return self.store.list_agent_resources(agent_id)


def extract_agent_id_from_headers(headers: Dict[str, str]) -> Optional[str]:
    """
    Simple utility to extract agent ID from headers.
    
    Args:
        headers: Request headers dictionary
        
    Returns:
        Agent ID if present, None otherwise
    """
    for key, value in headers.items():
        if key.lower() == "x-agent-id":
            return value
    return None



