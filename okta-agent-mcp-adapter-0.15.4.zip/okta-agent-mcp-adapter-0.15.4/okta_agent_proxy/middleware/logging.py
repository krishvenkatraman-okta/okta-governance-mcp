"""
Structured logging setup for MCP Gateway.

Supports JSON (default) and text log formats, with automatic injection
of request-scoped context (correlation_id, agent_id, etc.) from contextvars.
"""

import logging
import os
from typing import Optional

from pythonjsonlogger import jsonlogger

from okta_agent_proxy.audit.context import (
    get_correlation_id,
    agent_id_var,
    user_id_var,
    client_id_var,
    ip_address_var,
)


class ContextFilter(logging.Filter):
    """Injects request-scoped context vars into every LogRecord."""

    def filter(self, record: logging.LogRecord) -> bool:
        record.correlation_id = get_correlation_id() or ""  # type: ignore[attr-defined]
        record.agent_id = agent_id_var.get() or ""  # type: ignore[attr-defined]
        record.user_id = user_id_var.get() or ""  # type: ignore[attr-defined]
        record.client_id = client_id_var.get() or ""  # type: ignore[attr-defined]
        record.ip_address = ip_address_var.get() or ""  # type: ignore[attr-defined]
        return True


def setup_logging(
    log_level: Optional[str] = None,
    log_format: Optional[str] = None,
) -> None:
    """
    Configure logging for the gateway.

    Args:
        log_level: Log level (DEBUG, INFO, WARNING, ERROR).
                   Falls back to LOG_LEVEL env var, then "INFO".
        log_format: "json" or "text".
                    Falls back to LOG_FORMAT env var, then "json".
    """
    if log_level is None:
        log_level = os.getenv("LOG_LEVEL", "INFO")
    if log_format is None:
        log_format = os.getenv("LOG_FORMAT", "json")

    root = logging.getLogger()
    root.setLevel(getattr(logging, log_level.upper()))

    # Remove existing handlers to allow reconfiguration
    root.handlers.clear()

    handler = logging.StreamHandler()

    if log_format == "json":
        formatter = jsonlogger.JsonFormatter(
            fmt="%(asctime)s %(levelname)s %(name)s %(message)s "
                "%(correlation_id)s %(agent_id)s %(user_id)s "
                "%(client_id)s %(ip_address)s",
            rename_fields={
                "asctime": "timestamp",
                "levelname": "level",
                "name": "logger",
            },
        )
        handler.setFormatter(formatter)
    else:
        formatter = logging.Formatter(
            "%(asctime)s - %(name)s - %(levelname)s - %(message)s"
        )
        handler.setFormatter(formatter)

    handler.addFilter(ContextFilter())
    root.addHandler(handler)

    # Suppress noisy loggers
    logging.getLogger("httpx").setLevel(logging.WARNING)
    logging.getLogger("asyncio").setLevel(logging.WARNING)

    root.info(f"Logging configured: level={log_level}, format={log_format}")
