"""
CIMD (Client ID Metadata Document) Fetcher.

Securely fetches and validates Client ID Metadata Documents from HTTPS URLs
provided by MCP clients. Implements SSRF protection, response validation,
and optional caching.

Security: This module makes outbound HTTP requests to untrusted URLs.
SSRF prevention is the primary security concern.
"""

import dataclasses
import hashlib
import ipaddress
import json
import logging
import os
import socket
from datetime import datetime, timezone
from typing import Optional
from urllib.parse import urlparse

import httpx

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Configuration defaults (overridable via env vars)
# ---------------------------------------------------------------------------
DEFAULT_CONNECT_TIMEOUT = 5
DEFAULT_READ_TIMEOUT = 10
DEFAULT_MAX_DOC_SIZE = 50 * 1024  # 50 KB
DEFAULT_MAX_REDIRECTS = 3
DEFAULT_CACHE_TTL = 86400  # 24 hours
NEGATIVE_CACHE_TTL = 300  # 5 minutes
USER_AGENT = "OktaMCPAdapter/1.0 CIMD-Fetcher"

VALID_AUTH_METHODS = {"none", "client_secret_basic", "client_secret_post", "private_key_jwt"}
ALLOWED_REDIRECT_SCHEMES = {"http", "https"}


# ---------------------------------------------------------------------------
# Error hierarchy
# ---------------------------------------------------------------------------
class CIMDError(Exception):
    """Base exception for CIMD operations."""
    pass


class CIMDSSRFError(CIMDError):
    """Raised when a URL resolves to a blocked IP address."""
    pass


class CIMDFetchError(CIMDError):
    """Raised on network failures, timeouts, or oversized responses."""
    pass


class CIMDValidationError(CIMDError):
    """Raised when the fetched document fails validation."""
    pass


# ---------------------------------------------------------------------------
# CIMDMetadata dataclass
# ---------------------------------------------------------------------------
@dataclasses.dataclass
class CIMDMetadata:
    client_id: str
    client_name: str
    redirect_uris: list[str]
    grant_types: list[str]
    response_types: list[str]
    token_endpoint_auth_method: str
    jwks_uri: Optional[str]
    logo_uri: Optional[str]
    client_uri: Optional[str]
    scope: Optional[str]
    domain: str
    fetched_at: datetime
    raw_json: dict


# ---------------------------------------------------------------------------
# SSRF-safe DNS resolution
# ---------------------------------------------------------------------------
_BLOCKED_NETWORKS = [
    ipaddress.ip_network("10.0.0.0/8"),
    ipaddress.ip_network("172.16.0.0/12"),
    ipaddress.ip_network("192.168.0.0/16"),
    ipaddress.ip_network("127.0.0.0/8"),
    ipaddress.ip_network("169.254.0.0/16"),
    ipaddress.ip_network("0.0.0.0/8"),
    # IPv6
    ipaddress.ip_network("::1/128"),
    ipaddress.ip_network("fe80::/10"),
    ipaddress.ip_network("ff00::/8"),  # multicast
    ipaddress.ip_network("::/128"),  # unspecified
]

_LOOPBACK_NETWORKS = [
    ipaddress.ip_network("127.0.0.0/8"),
    ipaddress.ip_network("::1/128"),
]


def _is_loopback(addr: ipaddress.IPv4Address | ipaddress.IPv6Address) -> bool:
    return any(addr in net for net in _LOOPBACK_NETWORKS)


def _is_blocked_ip(
    addr_str: str,
    allow_localhost: bool = False,
    allow_private_networks: bool = False,
) -> bool:
    """Check if an IP address is in a blocked range.

    Returns True if the address should be blocked.
    """
    try:
        addr = ipaddress.ip_address(addr_str)
    except ValueError:
        return True  # unparseable → block

    if allow_localhost and _is_loopback(addr):
        return False

    if allow_private_networks:
        return False

    for network in _BLOCKED_NETWORKS:
        if addr in network:
            return True

    return False


def _resolve_and_check(
    hostname: str,
    allow_localhost: bool = False,
    allow_private_networks: bool = False,
) -> list[str]:
    """Resolve hostname and verify all IPs are safe.

    Returns the list of resolved IP strings.
    Raises CIMDSSRFError if any resolved IP is blocked.
    """
    try:
        results = socket.getaddrinfo(hostname, None, socket.AF_UNSPEC, socket.SOCK_STREAM)
    except socket.gaierror as exc:
        raise CIMDFetchError(f"DNS resolution failed for {hostname}: {exc}")

    if not results:
        raise CIMDFetchError(f"No DNS results for {hostname}")

    ips: list[str] = []
    for family, _type, _proto, _canonname, sockaddr in results:
        ip = sockaddr[0]
        if _is_blocked_ip(ip, allow_localhost=allow_localhost, allow_private_networks=allow_private_networks):
            raise CIMDSSRFError(
                f"Blocked: {hostname} resolves to {ip} which is in a restricted IP range"
            )
        ips.append(ip)

    return ips


def _validate_url(url: str, allow_localhost: bool = False) -> urlparse:
    """Validate URL scheme and hostname. Returns parsed URL."""
    parsed = urlparse(url)

    if parsed.scheme == "https":
        pass  # always allowed
    elif parsed.scheme == "http":
        hostname = parsed.hostname or ""
        if allow_localhost and hostname in ("localhost", "127.0.0.1", "::1", "host.docker.internal"):
            pass  # http allowed for localhost/docker in dev mode
        else:
            raise CIMDFetchError(
                f"HTTP scheme not allowed for {url}. Use HTTPS or enable dev mode for localhost."
            )
    else:
        raise CIMDFetchError(f"Unsupported URL scheme: {parsed.scheme}")

    if not parsed.hostname:
        raise CIMDFetchError(f"No hostname in URL: {url}")

    return parsed


# ---------------------------------------------------------------------------
# CIMDFetcher
# ---------------------------------------------------------------------------
class CIMDFetcher:
    """Fetches and validates CIMD documents with SSRF protection and caching."""

    def __init__(
        self,
        cache_service=None,
        connect_timeout: Optional[float] = None,
        read_timeout: Optional[float] = None,
        max_doc_size: Optional[int] = None,
        max_redirects: Optional[int] = None,
        cache_ttl: Optional[int] = None,
        allow_localhost: Optional[bool] = None,
        allow_private_networks: Optional[bool] = None,
        transport: Optional[httpx.AsyncBaseTransport] = None,
    ):
        self._cache = cache_service
        self._connect_timeout = connect_timeout or float(
            os.getenv("CIMD_CONNECT_TIMEOUT", str(DEFAULT_CONNECT_TIMEOUT))
        )
        self._read_timeout = read_timeout or float(
            os.getenv("CIMD_READ_TIMEOUT", str(DEFAULT_READ_TIMEOUT))
        )
        self._max_doc_size = max_doc_size or int(
            os.getenv("CIMD_MAX_DOC_SIZE_BYTES", str(DEFAULT_MAX_DOC_SIZE))
        )
        self._max_redirects = max_redirects if max_redirects is not None else DEFAULT_MAX_REDIRECTS
        self._cache_ttl = cache_ttl or int(
            os.getenv("CIMD_CACHE_TTL_SECONDS", str(DEFAULT_CACHE_TTL))
        )
        self._transport = transport
        if allow_localhost is not None:
            self._allow_localhost = allow_localhost
        else:
            self._allow_localhost = os.getenv("CIMD_ALLOW_LOCALHOST", "false").lower() == "true"
        if allow_private_networks is not None:
            self._allow_private_networks = allow_private_networks
        else:
            self._allow_private_networks = os.getenv(
                "CIMD_ALLOW_PRIVATE_NETWORKS", "false"
            ).lower() == "true"
        self._tls_verify = os.getenv("CIMD_TLS_VERIFY", "true").lower() != "false"
        if not self._tls_verify:
            logger.warning("CIMD TLS verification disabled (CIMD_TLS_VERIFY=false) — do NOT use in production")

    # -- Cache helpers -------------------------------------------------------

    @staticmethod
    def _cache_key(url: str) -> str:
        url_hash = hashlib.sha256(url.encode()).hexdigest()
        return f"cimd:metadata:{url_hash}"

    async def _get_cached(self, url: str) -> Optional[dict]:
        if not self._cache:
            return None
        raw = await self._cache.get(self._cache_key(url))
        if raw is None:
            return None
        try:
            return json.loads(raw)
        except (json.JSONDecodeError, TypeError):
            return None

    async def _set_cached(self, url: str, data: dict, ttl: int) -> None:
        if not self._cache:
            return
        await self._cache.set(self._cache_key(url), json.dumps(data), ttl_seconds=ttl)

    async def invalidate(self, url: str) -> None:
        """Remove a cached CIMD document."""
        if self._cache:
            await self._cache.delete(self._cache_key(url))

    # -- Fetch ---------------------------------------------------------------

    async def _fetch_raw(self, url: str) -> str:
        """Fetch URL content with SSRF checks and redirect validation."""
        parsed = _validate_url(url, self._allow_localhost)
        _resolve_and_check(parsed.hostname, self._allow_localhost, self._allow_private_networks)

        redirect_count = 0
        current_url = url

        # We disable httpx's automatic redirect following so we can validate
        # each hop destination against SSRF rules.
        timeout = httpx.Timeout(
            connect=self._connect_timeout,
            read=self._read_timeout,
            write=5.0,
            pool=5.0,
        )

        client_kwargs = dict(
            timeout=timeout,
            follow_redirects=False,
            headers={"User-Agent": USER_AGENT},
            verify=self._tls_verify,
        )
        if self._transport is not None:
            client_kwargs["transport"] = self._transport

        try:
            async with httpx.AsyncClient(**client_kwargs) as client:
                while True:
                    response = await client.get(current_url)

                    if response.is_redirect:
                        redirect_count += 1
                        if redirect_count > self._max_redirects:
                            raise CIMDFetchError(
                                f"Too many redirects ({redirect_count}) fetching {url}"
                            )
                        location = response.headers.get("location", "")
                        if not location:
                            raise CIMDFetchError("Redirect with no Location header")

                        # Resolve relative redirects
                        redirect_parsed = urlparse(location)
                        if not redirect_parsed.scheme:
                            # Relative URL – resolve against current
                            from urllib.parse import urljoin
                            location = urljoin(current_url, location)
                            redirect_parsed = urlparse(location)

                        # Validate redirect destination
                        _validate_url(location, self._allow_localhost)
                        _resolve_and_check(redirect_parsed.hostname, self._allow_localhost, self._allow_private_networks)

                        current_url = location
                        continue

                    response.raise_for_status()

                    # Check content length
                    content_length = response.headers.get("content-length")
                    if content_length and int(content_length) > self._max_doc_size:
                        raise CIMDFetchError(
                            f"Response too large: {content_length} bytes "
                            f"(max {self._max_doc_size})"
                        )

                    body = response.text
                    if len(body.encode("utf-8")) > self._max_doc_size:
                        raise CIMDFetchError(
                            f"Response body too large: {len(body.encode('utf-8'))} bytes "
                            f"(max {self._max_doc_size})"
                        )

                    return body

        except CIMDError:
            raise
        except httpx.TimeoutException as exc:
            raise CIMDFetchError(f"Timeout fetching {url}: {exc}")
        except httpx.HTTPStatusError as exc:
            raise CIMDFetchError(f"HTTP {exc.response.status_code} fetching {url}")
        except httpx.HTTPError as exc:
            raise CIMDFetchError(f"HTTP error fetching {url}: {exc}")

    # -- Validation ----------------------------------------------------------

    @staticmethod
    def _validate_document(url: str, data: dict) -> CIMDMetadata:
        """Validate parsed JSON and return CIMDMetadata."""

        # Required fields
        client_id = data.get("client_id")
        if not isinstance(client_id, str) or not client_id:
            raise CIMDValidationError("Missing or invalid required field: client_id")

        client_name = data.get("client_name")
        if not isinstance(client_name, str) or not client_name:
            raise CIMDValidationError("Missing or invalid required field: client_name")

        redirect_uris = data.get("redirect_uris")
        if not isinstance(redirect_uris, list) or len(redirect_uris) == 0:
            raise CIMDValidationError("redirect_uris must be a non-empty list")

        # Validate redirect_uris
        for uri in redirect_uris:
            if not isinstance(uri, str):
                raise CIMDValidationError(f"Invalid redirect_uri: {uri}")
            uri_parsed = urlparse(uri)
            if uri_parsed.scheme not in ("http", "https"):
                raise CIMDValidationError(
                    f"Invalid redirect_uri scheme '{uri_parsed.scheme}': {uri}. "
                    "Only http and https are allowed."
                )

        # client_id must exactly match the fetch URL
        if client_id != url:
            raise CIMDValidationError(
                f"client_id mismatch: document contains '{client_id}' "
                f"but was fetched from '{url}'"
            )

        # Optional fields with defaults
        grant_types = data.get("grant_types", ["authorization_code"])
        response_types = data.get("response_types", ["code"])
        auth_method = data.get("token_endpoint_auth_method", "none")

        if auth_method not in VALID_AUTH_METHODS:
            raise CIMDValidationError(
                f"Invalid token_endpoint_auth_method: '{auth_method}'. "
                f"Must be one of: {', '.join(sorted(VALID_AUTH_METHODS))}"
            )

        jwks_uri = data.get("jwks_uri")
        if auth_method == "private_key_jwt" and not jwks_uri:
            raise CIMDValidationError(
                "jwks_uri is required when token_endpoint_auth_method is 'private_key_jwt'"
            )

        logo_uri = data.get("logo_uri")
        client_uri = data.get("client_uri")
        scope = data.get("scope")

        # Extract domain from client_id URL
        parsed = urlparse(client_id)
        domain = parsed.hostname or ""

        return CIMDMetadata(
            client_id=client_id,
            client_name=client_name,
            redirect_uris=redirect_uris,
            grant_types=grant_types,
            response_types=response_types,
            token_endpoint_auth_method=auth_method,
            jwks_uri=jwks_uri,
            logo_uri=logo_uri,
            client_uri=client_uri,
            scope=scope,
            domain=domain,
            fetched_at=datetime.now(timezone.utc),
            raw_json=data,
        )

    # -- Public API ----------------------------------------------------------

    async def fetch_and_validate(self, url: str) -> CIMDMetadata:
        """Fetch a CIMD document, validate it, and return CIMDMetadata.

        Uses cache if available. On failure, caches the negative result
        for 5 minutes to prevent retry storms.
        """
        # Check cache
        cached = await self._get_cached(url)
        if cached is not None:
            if cached.get("__negative_cache"):
                raise CIMDFetchError(f"Previously failed to fetch {url} (cached negative result)")
            # Reconstruct from cached data
            return self._validate_document(url, cached["raw_json"])

        # Fetch
        try:
            body = await self._fetch_raw(url)
        except CIMDError:
            # Cache negative result
            await self._set_cached(url, {"__negative_cache": True}, ttl=NEGATIVE_CACHE_TTL)
            raise

        # Parse JSON
        try:
            data = json.loads(body)
        except (json.JSONDecodeError, ValueError) as exc:
            await self._set_cached(url, {"__negative_cache": True}, ttl=NEGATIVE_CACHE_TTL)
            raise CIMDValidationError(f"Invalid JSON in CIMD document from {url}: {exc}")

        if not isinstance(data, dict):
            raise CIMDValidationError(f"CIMD document must be a JSON object, got {type(data).__name__}")

        # Validate
        metadata = self._validate_document(url, data)

        # Cache positive result
        await self._set_cached(url, {"raw_json": data}, ttl=self._cache_ttl)

        logger.info(f"Fetched and validated CIMD for {metadata.domain} (client_id={url})")
        return metadata
