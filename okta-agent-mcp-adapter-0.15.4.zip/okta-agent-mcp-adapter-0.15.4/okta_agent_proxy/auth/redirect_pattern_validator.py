"""
Redirect-pattern syntax validator for DCR allowed-redirect-patterns.

Validates pattern syntax only — does NOT perform fnmatch-style matching.
The runtime matcher in DCRPolicy handles actual URI-to-pattern matching.

Three pattern families are supported:
  A) http/https web URIs (with optional wildcard in leftmost host label)
  B) http loopback URIs (localhost, 127.0.0.1, [::1])
  C) Private-use URI schemes (RFC 8252 §7.1 recommends reverse-DNS, but
     single-word schemes used by real-world native apps like cursor://,
     vscode://, and windsurf:// are also accepted; network-protocol and
     code-execution schemes are blocked via DANGEROUS_SCHEMES)
"""

import re
from urllib.parse import urlparse

DANGEROUS_SCHEMES = frozenset({
    "javascript", "data", "file", "vbscript", "about", "blob",
    "ftp", "ftps", "gopher", "telnet", "ssh",
    "ws", "wss", "mailto", "tel", "sms",
    "ldap", "ldaps",
})

LOOPBACK_HOSTS = frozenset({"localhost", "127.0.0.1", "::1"})

_DNS_LABEL_RE = re.compile(r"^[a-z0-9]([a-z0-9-]*[a-z0-9])?$", re.IGNORECASE)

_SCHEME_RE = re.compile(r"^[a-z][a-z0-9.+\-]*$")

_PATH_SEGMENT_RE = re.compile(r"^[A-Za-z0-9._~:@!$&'()+,;=%-]+$")


class RedirectPatternError(ValueError):
    """A redirect pattern failed syntax validation."""


def validate_redirect_pattern(pattern: str) -> None:
    """Raise RedirectPatternError with a human-readable message if invalid.

    Returns None on success. Pure function — no I/O.
    """
    # --- Common Rule 1: type, length, no whitespace, no control chars ---
    if not isinstance(pattern, str):
        raise RedirectPatternError("pattern must be a string")
    if len(pattern) == 0:
        raise RedirectPatternError("pattern must not be empty (length 0)")
    if len(pattern) > 512:
        raise RedirectPatternError(
            f"pattern must not exceed 512 characters (got {len(pattern)})"
        )
    for i, ch in enumerate(pattern):
        if ch.isspace():
            raise RedirectPatternError(
                f"pattern contains whitespace at index {i}"
            )
        if ord(ch) < 0x20 or ord(ch) == 0x7F:
            raise RedirectPatternError(
                f"pattern contains control character at index {i} "
                f"(ord {ord(ch):#x})"
            )

    # --- Common Rule 2: parse ---
    parsed = urlparse(pattern)

    # --- Common Rule 3: no query or fragment ---
    if parsed.query or "?" in pattern:
        raise RedirectPatternError(
            "query strings and fragments are not allowed in redirect patterns"
        )
    if parsed.fragment or "#" in pattern:
        raise RedirectPatternError(
            "query strings and fragments are not allowed in redirect patterns"
        )

    # --- Common Rule 4: scheme must be present and lowercase ---
    scheme = parsed.scheme
    if not scheme:
        # urlparse rejects '*' in scheme position — give a better message
        if ":" in pattern:
            raw_candidate = pattern[:pattern.index(":")]
            if "*" in raw_candidate:
                raise RedirectPatternError(
                    f"wildcard '*' is not allowed in the scheme '{raw_candidate}'"
                )
        raise RedirectPatternError(
            "pattern must be an absolute URI with a scheme "
            "(e.g. 'https://example.com/cb')"
        )
    if scheme != scheme.lower():
        raise RedirectPatternError(
            f"scheme '{scheme}' must be lowercase; use '{scheme.lower()}'"
        )
    # urlparse lowercases the scheme automatically, so also check the raw input
    colon_idx = pattern.index(":")
    raw_scheme = pattern[:colon_idx]
    if raw_scheme != raw_scheme.lower():
        raise RedirectPatternError(
            f"scheme '{raw_scheme}' must be lowercase; use '{raw_scheme.lower()}'"
        )
    scheme = raw_scheme

    # --- Common Rule 5: dangerous scheme deny list ---
    if scheme in DANGEROUS_SCHEMES:
        raise RedirectPatternError(
            f"scheme '{scheme}' is not allowed (dangerous scheme)"
        )

    # --- Family detection ---
    hostname = parsed.hostname  # lowercased, brackets stripped for IPv6
    if scheme in ("http", "https") and hostname in LOOPBACK_HOSTS:
        _validate_family_b(pattern, parsed, scheme, hostname)
    elif scheme in ("http", "https"):
        _validate_family_a(pattern, parsed, scheme, hostname)
    else:
        _validate_family_c(pattern, parsed, scheme)


def _extract_port_str(parsed) -> str | None:
    """Extract the raw port string from netloc (supports '*' port)."""
    netloc = parsed.netloc
    if not netloc:
        return None
    # Handle bracketed IPv6: [::1]:port
    if "[" in netloc:
        bracket_close = netloc.rfind("]")
        after = netloc[bracket_close + 1:]
        if after.startswith(":"):
            return after[1:]
        return None
    # Regular host:port
    if ":" in netloc:
        return netloc.rsplit(":", 1)[1]
    return None


def _validate_port(port_str: str | None) -> None:
    """Validate port if present: digits or literal '*'."""
    if port_str is None:
        return
    if port_str == "*":
        return
    if port_str.isdigit():
        return
    raise RedirectPatternError(
        f"port '{port_str}' must be a number or the literal '*'"
    )


def _validate_path(path: str) -> None:
    """Validate path per PATH_RULES (P1-P4)."""
    if not path:
        return
    segments = path.split("/")
    # Leading slash produces an empty first segment — that's fine.
    # Trailing slash produces an empty last segment — also fine.
    for i, seg in enumerate(segments):
        if seg == "":
            # Allow empty first segment (leading slash)
            if i == 0:
                continue
            # Allow empty last segment (trailing slash)
            if i == len(segments) - 1:
                continue
            raise RedirectPatternError(
                "path segment '' is empty; consecutive slashes are not permitted"
            )
        if seg == "*":
            continue
        if not _PATH_SEGMENT_RE.match(seg):
            if "*" in seg:
                raise RedirectPatternError(
                    f"path segment '{seg}' contains an embedded wildcard; "
                    "use '*' as the entire segment"
                )
            raise RedirectPatternError(
                f"path segment '{seg}' contains invalid characters"
            )


def _validate_family_a(pattern: str, parsed, scheme: str, hostname: str | None) -> None:
    """Validate Family A: http/https web patterns."""
    # A1: host must be non-empty
    if not hostname:
        raise RedirectPatternError(
            "host must not be empty for http/https patterns"
        )

    host_lower = hostname.lower()

    # A2: must contain at least one dot
    if "." not in host_lower:
        raise RedirectPatternError(
            f"host must contain at least one dot (got '{hostname}')"
        )

    # A3: split into labels
    labels = host_lower.split(".")
    if len(labels) < 2:
        raise RedirectPatternError(
            f"host must have at least two labels (got '{hostname}')"
        )

    # Remove empty trailing label from trailing dot before validation
    # (but we'll reject trailing dots in A5 anyway via empty interior label check)

    # A4: leftmost label — either exactly '*' or valid DNS label
    leftmost = labels[0]
    if leftmost != "*":
        if "*" in leftmost:
            raise RedirectPatternError(
                f"host label '{leftmost}' is not a valid wildcard; "
                "use '*' as the entire leftmost label"
            )
        if not _DNS_LABEL_RE.match(leftmost):
            raise RedirectPatternError(
                f"host label '{leftmost}' is not a valid DNS label"
            )

    # A4b: if leftmost is wildcard, need >= 3 labels to prevent *.tld
    if leftmost == "*" and len(labels) < 3:
        raise RedirectPatternError(
            f"wildcard pattern must have at least two labels after '*' "
            f"(e.g. '*.example.com'), but the rightmost label '{labels[-1]}' "
            f"is just a TLD"
        )

    # A5: non-leftmost labels must be valid DNS labels, no wildcards, no empty
    for idx, label in enumerate(labels[1:], start=1):
        if not label:
            raise RedirectPatternError(
                f"host contains an empty label at position {idx} "
                "(check for consecutive dots, trailing dot, or leading dot)"
            )
        if "*" in label:
            raise RedirectPatternError(
                f"wildcard '*' is only allowed in the leftmost host label, "
                f"but found in label '{label}' at position {idx}"
            )
        if not _DNS_LABEL_RE.match(label):
            raise RedirectPatternError(
                f"host label '{label}' at position {idx} is not a valid DNS label"
            )

    # A6: rightmost label (TLD) must be alphabetic, length >= 2
    tld = labels[-1]
    if tld == "*":
        raise RedirectPatternError(
            "rightmost label (TLD) must not be a wildcard"
        )
    if not tld.isalpha():
        raise RedirectPatternError(
            f"rightmost label (TLD) '{tld}' must be alphabetic only"
        )
    if len(tld) < 2:
        raise RedirectPatternError(
            f"rightmost label (TLD) '{tld}' must be at least 2 characters"
        )

    # A7: port
    port_str = _extract_port_str(parsed)
    _validate_port(port_str)

    # A8: path
    _validate_path(parsed.path)


def _validate_family_b(pattern: str, parsed, scheme: str, hostname: str | None) -> None:
    """Validate Family B: loopback patterns."""
    # B1: scheme must be exactly 'http'
    if scheme != "http":
        raise RedirectPatternError(
            f"Family B loopback patterns must use the http scheme "
            f"(got '{scheme}'); per RFC 8252 §8.3, loopback redirects use "
            f"http because the redirect never leaves the device"
        )

    # B2: host already verified as loopback by family detection

    # B3: port
    port_str = _extract_port_str(parsed)
    _validate_port(port_str)

    # B4: path
    _validate_path(parsed.path)


def _validate_family_c(pattern: str, parsed, scheme: str) -> None:
    """Validate Family C: private-use URI schemes (RFC 8252 §7.1)."""
    # C1: scheme must match RFC 3986 grammar, lowercase only
    if not _SCHEME_RE.match(scheme):
        raise RedirectPatternError(
            f"scheme '{scheme}' is not a valid URI scheme; "
            "must match [a-z][a-z0-9.+-]* (lowercase only)"
        )

    # C2: no wildcards in scheme
    if "*" in scheme:
        raise RedirectPatternError(
            f"wildcard '*' is not allowed in the scheme '{scheme}'"
        )

    # C3: if authority present, must not be '*' or contain wildcards
    netloc = parsed.netloc
    if netloc:
        if netloc == "*" or "*" in netloc:
            raise RedirectPatternError(
                f"authority '{netloc}' must not contain wildcards in "
                "private-use scheme patterns"
            )

    # C4: must have non-empty path or scheme-specific part after colon
    colon_idx = pattern.index(":")
    after_colon = pattern[colon_idx + 1:]
    if not after_colon:
        raise RedirectPatternError(
            "private-use scheme pattern must have a non-empty path after "
            f"'{scheme}:'"
        )

    # C5: path rules
    _validate_path(parsed.path)


def validate_redirect_patterns(patterns: list[str]) -> list[str]:
    """Validate and normalize a list of redirect patterns.

    Strips whitespace from each entry, drops empty strings, deduplicates
    while preserving order, then validates each pattern.

    Returns the normalized list. Raises RedirectPatternError on the first
    invalid entry, with the offending pattern and 0-based index in the
    message.
    """
    # Normalize: strip whitespace, drop empty
    stripped = [p.strip() for p in patterns]
    non_empty = [p for p in stripped if p]

    # Deduplicate preserving order
    seen: set[str] = set()
    unique: list[str] = []
    for p in non_empty:
        if p not in seen:
            seen.add(p)
            unique.append(p)

    # Validate each
    for idx, p in enumerate(unique):
        try:
            validate_redirect_pattern(p)
        except RedirectPatternError as e:
            raise RedirectPatternError(
                f"pattern[{idx}] {p!r}: {e}"
            ) from e

    return unique
