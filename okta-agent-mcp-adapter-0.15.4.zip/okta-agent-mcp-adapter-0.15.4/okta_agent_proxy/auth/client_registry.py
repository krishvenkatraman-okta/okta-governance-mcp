"""
Client Registry — central dispatcher for resolving any client_id
to normalized client metadata.

Resolution order:
1. Pre-registered agent (from config store, by client_id match)
2. Pre-registered agent matched by CIMD URL (cimd_client_id_url field)
3. CIMD URL (fetch, validate, evaluate trust policy, auto-provision)
4. DCR registration (future — P4)
5. None
"""

import dataclasses
import logging
from typing import Optional
from urllib.parse import urlparse

from .cimd_fetcher import CIMDFetcher, CIMDMetadata, CIMDError
from .cimd_policy import CIMDTrustPolicy

logger = logging.getLogger(__name__)


@dataclasses.dataclass
class ClientInfo:
    client_id: str
    client_name: str
    registration_source: str  # "manual", "cimd", "dcr"
    redirect_uris: list[str]
    grant_types: list[str]
    response_types: list[str]
    token_endpoint_auth_method: str
    jwks_uri: Optional[str]
    scope: Optional[str]
    trust_level: Optional[str]  # For CIMD: "trusted", "unknown"
    agent_config: Optional[dict]  # For pre-registered: full agent record
    cimd_metadata: Optional[CIMDMetadata]  # For CIMD: the validated metadata
    resource_access: list[str] = dataclasses.field(default_factory=list)


class ClientRegistry:
    """Resolves client_id strings to normalized ClientInfo."""

    def __init__(self, store, cimd_fetcher: CIMDFetcher, cimd_policy: CIMDTrustPolicy,
                 ai_agent_promoter=None, cache_service=None):
        self._store = store
        self._fetcher = cimd_fetcher
        self._policy = cimd_policy
        self._ai_agent_promoter = ai_agent_promoter
        self._cache_service = cache_service
        # In-memory fallback only used when no shared cache is available
        self._promoted_cimd_local: set = set()

    async def resolve(self, client_id: str) -> Optional[ClientInfo]:
        """Resolve a client_id to ClientInfo.

        Resolution order:
        1. Pre-registered agent (store lookup by Okta client_id)
        2. Pre-registered agent matched by CIMD URL (cimd_client_id_url field)
        3. CIMD URL (fetch metadata, auto-provision if enabled)
        4. DCR registration (future)
        """
        # 1. Pre-registered agent (by Okta client_id — for non-CIMD agents)
        info = self._resolve_manual(client_id)
        if info is not None:
            return info

        # 2. Pre-registered agent matched by CIMD URL
        if self._is_cimd_url(client_id):
            info = self._resolve_by_cimd_url(client_id)
            if info is not None:
                return info

        # 3. CIMD URL (fetch metadata, auto-provision if enabled)
        if self._is_cimd_url(client_id):
            info = await self._resolve_cimd(client_id)
            if info is not None:
                return info

        # 4. DCR (future — P4)
        info = self._resolve_dcr(client_id)
        if info is not None:
            return info

        return None

    def _resolve_manual(self, client_id: str) -> Optional[ClientInfo]:
        """Look up a pre-registered agent by client_id.

        Skips CIMD-style URL client_ids — those must be resolved through
        the CIMD path to get proper metadata and relay handling.
        """
        if self._is_cimd_url(client_id):
            return None

        try:
            agents = self._store.get_all_agents(enabled_only=True)
        except Exception as e:
            logger.error(f"Error querying agents: {e}")
            return None

        for agent in agents:
            if agent.get("client_id") == client_id:
                return ClientInfo(
                    client_id=client_id,
                    client_name=agent.get("agent_name", agent.get("agent_id", "")),
                    registration_source="manual",
                    redirect_uris=[],
                    grant_types=["authorization_code"],
                    response_types=["code"],
                    token_endpoint_auth_method="client_secret_basic",
                    jwks_uri=None,
                    scope=None,
                    trust_level=None,
                    agent_config=agent,
                    cimd_metadata=None,
                    resource_access=agent.get("resource_access", []),
                )

        return None

    def _resolve_by_cimd_url(self, cimd_url: str) -> Optional[ClientInfo]:
        """Look up a pre-registered agent by its cimd_client_id_url field.

        This is the bridge between CIMD URLs and Okta agent configurations.
        If an admin has pre-registered an agent with cimd_client_id matching
        this URL, return that agent's full config (with real Okta credentials).
        """
        try:
            agent = self._store.get_agent_by_cimd_client_id(cimd_url)
        except AttributeError:
            # Method doesn't exist on this store implementation — skip
            return None
        except Exception as e:
            logger.warning(f"CIMD URL agent lookup failed for {cimd_url}: {e}")
            return None

        if not agent:
            return None

        agent_id = agent.get("agent_id", "")
        okta_client_id = agent.get("client_id", "")
        logger.info(
            f"[CIMD-MATCH] CIMD client {cimd_url} matched to agent "
            f"'{agent_id}' (client_id={okta_client_id})"
        )

        return ClientInfo(
            client_id=cimd_url,
            client_name=agent.get("agent_name", agent_id),
            registration_source="cimd-matched",
            redirect_uris=[],
            grant_types=["authorization_code"],
            response_types=["code"],
            token_endpoint_auth_method="client_secret_basic",
            jwks_uri=None,
            scope=None,
            trust_level="pre-registered",
            agent_config=agent,
            cimd_metadata=None,
            resource_access=agent.get("resource_access", []),
        )

    @staticmethod
    def _is_cimd_url(client_id: str) -> bool:
        """Check if client_id looks like a CIMD URL."""
        if client_id.startswith("https://"):
            return True
        if client_id.startswith("http://localhost") or client_id.startswith("http://127.0.0.1"):
            return True
        if client_id.startswith("http://host.docker.internal"):
            return True
        return False

    async def _resolve_cimd(self, client_id: str) -> Optional[ClientInfo]:
        """Fetch, validate, and evaluate CIMD trust policy."""
        try:
            metadata = await self._fetcher.fetch_and_validate(client_id)
        except CIMDError as e:
            logger.warning(f"CIMD fetch failed for {client_id}: {e}")
            return None

        result = await self._policy.evaluate(metadata)
        if not result.allowed:
            logger.warning(
                f"CIMD policy rejected {client_id}: {result.reason}"
            )
            return None

        # Auto-provision a persistent agent record if enabled
        agent_config = None
        resource_access = result.resource_access

        if self._policy.auto_provision_agent:
            try:
                created = self._store.create_cimd_agent(
                    cimd_client_id=client_id,
                    client_name=metadata.client_name,
                    domain=result.domain,
                    trust_level=result.trust_level.value,
                )
                if created:
                    logger.info(f"CIMD auto-provisioned agent for {client_id}")
            except Exception as exc:
                logger.warning(f"CIMD auto-provision failed for {client_id}: {exc}")

            # Look up the agent record (just created or previously provisioned)
            try:
                agent_config = self._store.get_agent_by_client_id(client_id)
                if agent_config:
                    resource_access = agent_config.get("resource_access", resource_access)
            except Exception as exc:
                logger.debug(f"CIMD agent lookup failed for {client_id}: {exc}")

        info = ClientInfo(
            client_id=client_id,
            client_name=metadata.client_name,
            registration_source="cimd",
            redirect_uris=metadata.redirect_uris,
            grant_types=metadata.grant_types,
            response_types=metadata.response_types,
            token_endpoint_auth_method=metadata.token_endpoint_auth_method,
            jwks_uri=metadata.jwks_uri,
            scope=metadata.scope,
            trust_level=result.trust_level.value.lower(),
            agent_config=agent_config,
            cimd_metadata=metadata,
            resource_access=resource_access,
        )

        # Structured audit log for SIEM
        parsed = urlparse(client_id)
        logger.info(
            "cimd_resolution",
            extra={
                "event": "cimd_resolution",
                "client_id_url": client_id,
                "domain": parsed.netloc,
                "trust_level": info.trust_level,
                "client_name": metadata.client_name,
            },
        )

        # Trigger AI Agent promotion for first-time trusted CIMD clients.
        # Uses shared cache (Redis) so multiple gateway instances don't
        # create duplicate AI Agent records in Okta.
        if (
            self._ai_agent_promoter is not None
            and info.trust_level == "trusted"
        ):
            already_promoted = await self._check_promoted(client_id)
            if not already_promoted:
                await self._mark_promoted(client_id)
                try:
                    import asyncio
                    asyncio.create_task(
                        self._ai_agent_promoter.promote_to_okta(
                            agent_name=f"cimd-{metadata.client_name}",
                            client_name=metadata.client_name,
                        )
                    )
                except Exception as exc:
                    logger.debug("CIMD AI Agent promotion trigger failed: %s", exc)

        return info

    async def _check_promoted(self, client_id: str) -> bool:
        """Check if a CIMD client has already been promoted (across all instances)."""
        cache_key = f"cimd_promoted:{client_id}"
        if self._cache_service is not None:
            try:
                val = await self._cache_service.get(cache_key)
                if val is not None:
                    return True
            except Exception:
                pass
        return client_id in self._promoted_cimd_local

    async def _mark_promoted(self, client_id: str):
        """Mark a CIMD client as promoted in shared cache and local fallback."""
        cache_key = f"cimd_promoted:{client_id}"
        self._promoted_cimd_local.add(client_id)
        if self._cache_service is not None:
            try:
                # TTL of 24h — promotions are rare and idempotent after first success
                await self._cache_service.set(cache_key, "1", ttl_seconds=86400)
            except Exception:
                pass

    def _resolve_dcr(self, client_id: str) -> Optional[ClientInfo]:
        """Look up a DCR registration by client_id and populate agent config."""
        try:
            registration = self._store.get_dcr_registration(client_id)
        except AttributeError:
            # Method doesn't exist on this store implementation — skip
            return None
        except Exception as e:
            logger.debug(f"DCR lookup error for {client_id}: {e}")
            return None

        if not registration or registration.get("status") != "active":
            return None

        # If linked to an imported agent, use that agent's config (with real
        # Okta credentials) so the relay can authenticate to Okta.
        # No separate DCR agent record exists — all credentials come from
        # the linked agent.
        agent_config = None
        resource_access = []
        linked_agent_name = registration.get("linked_agent_name")
        if linked_agent_name:
            try:
                agent_config = self._store.get_agent(
                    linked_agent_name, enabled_only=False
                )
                if agent_config:
                    resource_access = agent_config.get("resource_access", [])
            except Exception as e:
                logger.debug(f"DCR linked agent lookup failed for {linked_agent_name}: {e}")

        return ClientInfo(
            client_id=client_id,
            client_name=registration.get("client_name", ""),
            registration_source="dcr",
            redirect_uris=registration.get("redirect_uris", []),
            grant_types=registration.get("grant_types", ["authorization_code"]),
            response_types=registration.get("response_types", ["code"]),
            token_endpoint_auth_method=registration.get(
                "token_endpoint_auth_method", "none"
            ),
            jwks_uri=registration.get("jwks_uri"),
            scope=registration.get("scope"),
            trust_level=None,
            agent_config=agent_config,
            cimd_metadata=None,
            resource_access=resource_access,
        )
