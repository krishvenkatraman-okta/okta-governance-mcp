"""
CIMD Trust Policy.

Evaluates validated CIMDMetadata objects against configurable domain-based
trust rules. Determines whether a CIMD client should be accepted, and at
what trust level.
"""

import dataclasses
import enum
import fnmatch
import logging
import os
from urllib.parse import urlparse

from .cimd_fetcher import CIMDMetadata

logger = logging.getLogger(__name__)

DEFAULT_REDIRECT_PATTERNS = "http://localhost:*/callback,http://127.0.0.1:*/callback"


class TrustLevel(enum.Enum):
    TRUSTED = "TRUSTED"
    UNKNOWN = "UNKNOWN"
    BLOCKED = "BLOCKED"


@dataclasses.dataclass
class CIMDTrustResult:
    allowed: bool
    trust_level: TrustLevel
    domain: str
    reason: str
    redirect_uris_valid: bool
    resource_access: list[str] = dataclasses.field(default_factory=list)


class CIMDTrustPolicy:
    """Evaluates CIMDMetadata against configurable trust rules."""

    def __init__(
        self,
        enabled: bool | None = None,
        trusted_domains: list[str] | None = None,
        blocked_domains: list[str] | None = None,
        require_https: bool | None = None,
        allowed_redirect_patterns: list[str] | None = None,
    ):
        if enabled is not None:
            self._enabled = enabled
        else:
            self._enabled = os.getenv("CIMD_ENABLED", "true").lower() == "true"

        if trusted_domains is not None:
            self._trusted_domains = set(trusted_domains)
        else:
            raw = os.getenv("CIMD_TRUSTED_DOMAINS", "")
            self._trusted_domains = {d.strip() for d in raw.split(",") if d.strip()}

        if blocked_domains is not None:
            self._blocked_domains = set(blocked_domains)
        else:
            raw = os.getenv("CIMD_BLOCKED_DOMAINS", "")
            self._blocked_domains = {d.strip() for d in raw.split(",") if d.strip()}

        if require_https is not None:
            self._require_https = require_https
        else:
            self._require_https = os.getenv("CIMD_REQUIRE_HTTPS", "true").lower() == "true"

        if allowed_redirect_patterns is not None:
            self._redirect_patterns = allowed_redirect_patterns
        else:
            raw = os.getenv("CIMD_ALLOWED_REDIRECT_PATTERNS", DEFAULT_REDIRECT_PATTERNS)
            self._redirect_patterns = [p.strip() for p in raw.split(",") if p.strip()]

    @property
    def auto_provision_agent(self) -> bool:
        """Whether to auto-provision an agent record for CIMD clients."""
        return os.getenv("CIMD_AUTO_PROVISION_AGENT", "false").lower() == "true"

    async def evaluate(self, metadata: CIMDMetadata) -> CIMDTrustResult:
        """Evaluate a validated CIMDMetadata object against trust rules."""

        # 1. Master switch
        if not self._enabled:
            return self._result(
                allowed=False,
                trust_level=TrustLevel.BLOCKED,
                domain=metadata.domain,
                reason="CIMD disabled",
                redirect_uris_valid=False,
            )

        # 2. Extract domain
        domain = metadata.domain
        parsed = urlparse(metadata.client_id)

        # 3. Blocked domains
        if domain in self._blocked_domains:
            return self._result(
                allowed=False,
                trust_level=TrustLevel.BLOCKED,
                domain=domain,
                reason="domain blocked",
                redirect_uris_valid=False,
            )

        # 4. HTTPS requirement
        if self._require_https and parsed.scheme == "http":
            hostname = parsed.hostname or ""
            if hostname not in ("localhost", "127.0.0.1", "::1"):
                return self._result(
                    allowed=False,
                    trust_level=TrustLevel.BLOCKED,
                    domain=domain,
                    reason="HTTP scheme not allowed (CIMD_REQUIRE_HTTPS=true)",
                    redirect_uris_valid=False,
                )

        # 5. Redirect URI validation
        redirect_uris_valid = self._check_redirect_uris(metadata.redirect_uris)
        if not redirect_uris_valid:
            return self._result(
                allowed=False,
                trust_level=TrustLevel.UNKNOWN,
                domain=domain,
                reason="no redirect_uris match allowed patterns",
                redirect_uris_valid=False,
            )

        # 6. Trusted domain
        if domain in self._trusted_domains:
            return self._result(
                allowed=True,
                trust_level=TrustLevel.TRUSTED,
                domain=domain,
                reason="domain is trusted",
                redirect_uris_valid=True,
                resource_access=self._parse_csv_env("CIMD_TRUSTED_BACKEND_ACCESS"),
            )

        # 7. Unknown domain — allowed by default
        return self._result(
            allowed=True,
            trust_level=TrustLevel.UNKNOWN,
            domain=domain,
            reason="domain not in trusted or blocked lists",
            redirect_uris_valid=True,
            resource_access=self._parse_csv_env("CIMD_UNKNOWN_BACKEND_ACCESS"),
        )

    def _check_redirect_uris(self, redirect_uris: list[str]) -> bool:
        """Check if at least one redirect URI matches an allowed pattern."""
        for uri in redirect_uris:
            for pattern in self._redirect_patterns:
                if fnmatch.fnmatch(uri, pattern):
                    return True
        return False

    @staticmethod
    def _parse_csv_env(var_name: str) -> list[str]:
        """Read an env var, split on commas, strip whitespace, filter empties."""
        raw = os.getenv(var_name, "")
        return [v.strip() for v in raw.split(",") if v.strip()]

    @staticmethod
    def _result(
        allowed: bool,
        trust_level: TrustLevel,
        domain: str,
        reason: str,
        redirect_uris_valid: bool,
        resource_access: list[str] | None = None,
    ) -> CIMDTrustResult:
        result = CIMDTrustResult(
            allowed=allowed,
            trust_level=trust_level,
            domain=domain,
            reason=reason,
            redirect_uris_valid=redirect_uris_valid,
            resource_access=resource_access or [],
        )
        if trust_level == TrustLevel.BLOCKED or not allowed:
            logger.warning(
                f"CIMD policy: domain={domain} trust={trust_level.value} "
                f"allowed={allowed} reason={reason}"
            )
        else:
            logger.info(
                f"CIMD policy: domain={domain} trust={trust_level.value} "
                f"allowed={allowed} reason={reason}"
            )
        return result
