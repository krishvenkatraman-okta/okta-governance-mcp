"""
Okta Service App Authentication (private_key_jwt)

Authenticates the adapter to Okta via private_key_jwt (client_credentials + JWT assertion).
Used for event-triggered operations where no admin user session is available.
Uses the adapter's own signing key registered with its Okta AI Agent record.

Flow (RFC 7523):
1. Build JWT: iss=client_id, sub=client_id, aud={OKTA_DOMAIN}/oauth2/v1/token, exp=now+60
2. Sign with adapter's private key (RS256, kid from JWK)
3. POST to {OKTA_DOMAIN}/oauth2/v1/token:
   grant_type=client_credentials
   client_id={OKTA_SERVICE_CLIENT_ID}
   client_assertion_type=urn:ietf:params:oauth:client-assertion-type:jwt-bearer
   client_assertion={signed_jwt}
   scope={scopes}
4. Cache token until ~60 seconds before expiry
"""

import asyncio
import json
import logging
import os
import time
import uuid
from typing import List, Optional

try:
    from jose import jwt
except ImportError:
    jwt = None

try:
    import httpx
except ImportError:
    httpx = None

logger = logging.getLogger(__name__)

DEFAULT_SCOPES = [
    "okta.aiAgents.read",
    "okta.aiAgents.manage",
    "okta.apps.read",
    "okta.authorizationServers.read",
]


class OktaServiceAuth:
    """Authenticates the adapter to Okta via private_key_jwt (client_credentials + JWT assertion).

    Used for event-triggered operations where no admin user session is available.
    Uses the adapter's own signing key registered with its Okta AI Agent record.
    """

    def __init__(self):
        self._client_id = os.getenv("OKTA_SERVICE_CLIENT_ID", "")
        self._domain = os.getenv("OKTA_DOMAIN", "").strip()
        self._signing_key = None
        self._cached_token: Optional[str] = None
        self._token_expiry: float = 0
        self._lock = asyncio.Lock()

    def _get_token_endpoint(self) -> str:
        """Build the Okta token endpoint URL."""
        domain = self._domain
        if domain.startswith("https://"):
            return f"{domain}/oauth2/v1/token"
        elif domain.startswith("http://"):
            return f"{domain}/oauth2/v1/token"
        else:
            return f"https://{domain}/oauth2/v1/token"

    def _load_signing_key(self) -> Optional[dict]:
        """Load adapter's private key from ADAPTER_SIGNING_KEY env var.

        Same key used for ID-JAG and CIMD identity.
        Falls back to auto-generated key from auth/adapter_cimd.py.
        """
        if self._signing_key is not None:
            return self._signing_key

        raw = os.getenv("ADAPTER_SIGNING_KEY", "").strip()
        if raw:
            try:
                if raw.startswith("{"):
                    self._signing_key = json.loads(raw)
                    logger.info(
                        f"Service auth signing key loaded from ADAPTER_SIGNING_KEY "
                        f"(kid={self._signing_key.get('kid')})"
                    )
                    return self._signing_key
                else:
                    # Could be a file path — delegate to adapter_cimd's loader
                    from okta_agent_proxy.auth.adapter_cimd import _load_signing_key

                    self._signing_key = _load_signing_key(raw)
                    logger.info(
                        f"Service auth signing key loaded from file "
                        f"(kid={self._signing_key.get('kid')})"
                    )
                    return self._signing_key
            except Exception as e:
                logger.warning(f"Failed to load ADAPTER_SIGNING_KEY: {e}")

        # Fallback: use AdapterCIMDServer's key (auto-generated if needed)
        try:
            from okta_agent_proxy.auth.adapter_cimd import AdapterCIMDServer

            adapter = AdapterCIMDServer()
            self._signing_key = adapter._private_jwk
            logger.info(
                f"Service auth using adapter CIMD signing key "
                f"(kid={self._signing_key.get('kid')})"
            )
            return self._signing_key
        except Exception as e:
            logger.warning(f"Failed to load adapter CIMD signing key: {e}")
            return None

    def _generate_jwt_assertion(self, scopes: List[str]) -> Optional[str]:
        """Generate JWT assertion per RFC 7523.

        Claims:
            iss: client_id
            sub: client_id
            aud: {OKTA_DOMAIN}/oauth2/v1/token
            jti: unique ID
            iat: now
            exp: now + 60
        """
        if not jwt:
            logger.warning("python-jose not installed, cannot generate JWT assertion")
            return None

        key = self._load_signing_key()
        if not key:
            logger.warning("No signing key available for JWT assertion")
            return None

        token_endpoint = self._get_token_endpoint()
        now = int(time.time())

        claims = {
            "iss": self._client_id,
            "sub": self._client_id,
            "aud": token_endpoint,
            "jti": str(uuid.uuid4()),
            "iat": now,
            "exp": now + 60,
        }

        kid = key.get("kid")
        headers = {}
        if kid:
            headers["kid"] = kid

        return jwt.encode(claims, key, algorithm="RS256", headers=headers)

    async def get_access_token(self, scopes: Optional[List[str]] = None) -> Optional[str]:
        """Get a short-lived access token via client_credentials + JWT assertion.

        Returns None if not configured or on failure (logs warning, never raises).
        """
        if not self._client_id:
            logger.debug("OKTA_SERVICE_CLIENT_ID not set, service auth disabled")
            return None

        if not self._domain:
            logger.warning("OKTA_DOMAIN not set, cannot authenticate service app")
            return None

        async with self._lock:
            # Return cached token if still valid
            if self._cached_token and time.time() < self._token_expiry:
                return self._cached_token

            resolved_scopes = scopes or DEFAULT_SCOPES
            assertion = self._generate_jwt_assertion(resolved_scopes)
            if not assertion:
                return None

            if not httpx:
                logger.warning("httpx not installed, cannot request service token")
                return None

            token_endpoint = self._get_token_endpoint()
            data = {
                "grant_type": "client_credentials",
                "client_id": self._client_id,
                "client_assertion_type": "urn:ietf:params:oauth:client-assertion-type:jwt-bearer",
                "client_assertion": assertion,
                "scope": " ".join(resolved_scopes),
            }

            try:
                async with httpx.AsyncClient() as client:
                    response = await client.post(
                        token_endpoint,
                        data=data,
                        headers={"Content-Type": "application/x-www-form-urlencoded"},
                    )

                if response.status_code != 200:
                    logger.warning(
                        f"Service token request failed: {response.status_code} {response.text}"
                    )
                    return None

                token_data = response.json()
                access_token = token_data.get("access_token")
                expires_in = token_data.get("expires_in", 3600)

                # Cache with 60-second safety margin
                self._cached_token = access_token
                self._token_expiry = time.time() + max(expires_in - 60, 0)

                logger.info(
                    f"Service token acquired (expires_in={expires_in}s, "
                    f"scopes={' '.join(resolved_scopes)})"
                )
                return access_token

            except Exception as e:
                logger.warning(f"Service token request error: {e}")
                return None
