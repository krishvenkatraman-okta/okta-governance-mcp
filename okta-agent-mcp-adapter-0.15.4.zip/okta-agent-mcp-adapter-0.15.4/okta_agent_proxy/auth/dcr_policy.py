"""
DCR (Dynamic Client Registration) Policy Engine.

Validates RFC 7591 registration requests against configurable rules
including rate limiting, redirect URI patterns, grant types, and
application types.

Configuration is read from environment variables with constructor
overrides for testing. When a config store is provided, allowed redirect
patterns are loaded from gateway_config with L1 caching and pub/sub
invalidation for multi-worker deployments.
"""

import dataclasses
import fnmatch
import json as _json
import logging
import os
import time
from typing import Any, Optional
from urllib.parse import urlparse

logger = logging.getLogger(__name__)

# Baseline scopes that the adapter always accepts on DCR registration.
# At registration time this is unioned with any scopes configured on the
# Okta Managed Connections of registered resources, so DCR clients can
# self-register with custom scopes (e.g. "bedrock:InvokeAgent") that the
# gateway will honor end-to-end via the ID-JAG Leg-1 scope parameter.
SUPPORTED_SCOPES = {"openid", "profile", "email", "offline_access"}


def _runtime_resource_scopes() -> set[str]:
    """Return the union of scopes configured on all resolved resources.

    Lazily imports the syncer to avoid a circular import at module load.
    Returns an empty set on any failure so DCR registration still proceeds
    with the baseline SUPPORTED_SCOPES.
    """
    try:
        from okta_agent_proxy.app import get_resource_syncer
        syncer = get_resource_syncer()
    except Exception:
        return set()
    if not syncer:
        return set()
    try:
        resources = syncer.get_all_resolved_resources_raw().values()
    except Exception:
        return set()
    collected: set[str] = set()
    for res in resources:
        for scope in (getattr(res, "scopes", None) or []):
            if scope:
                collected.add(scope)
    return collected

DEFAULT_REDIRECT_PATTERNS = [
    "http://localhost:*/callback",
    "http://127.0.0.1:*/callback",
]

GATEWAY_CONFIG_KEY_REDIRECT_PATTERNS = "dcr.allowed_redirect_patterns"
DEFAULT_PATTERN_CACHE_TTL_SECONDS = 300.0  # 5 min safety-net


@dataclasses.dataclass
class DCRPolicyResult:
    """Result of a DCR policy evaluation."""
    allowed: bool
    reason: str
    sanitized_body: Optional[dict]  # Request body with defaults applied and invalid fields removed


class DCRPolicy:
    """Validates RFC 7591 registration requests against configurable rules."""

    def __init__(
        self,
        *,
        enabled: Optional[bool] = None,
        provision_okta_app: Optional[bool] = None,
        allowed_redirect_patterns: Optional[list[str]] = None,
        allowed_grant_types: Optional[list[str]] = None,
        allowed_app_types: Optional[list[str]] = None,
        max_registrations_per_hour: Optional[int] = None,
        require_initial_access_token: Optional[bool] = None,
        initial_access_token: Optional[str] = None,
        auto_enable_agent: Optional[bool] = None,
        default_resource_access: Optional[list[str]] = None,
        registration_counter=None,
        store=None,
        event_bus=None,
        pattern_cache_ttl_seconds: float = DEFAULT_PATTERN_CACHE_TTL_SECONDS,
    ):
        self._enabled = (
            enabled if enabled is not None
            else os.getenv("DCR_ENABLED", "false").lower() == "true"
        )
        self._provision_okta_app = (
            provision_okta_app if provision_okta_app is not None
            else os.getenv("DCR_PROVISION_OKTA_APP", "false").lower() == "true"
        )
        self._allowed_redirect_patterns = (
            allowed_redirect_patterns if allowed_redirect_patterns is not None
            else [p.strip() for p in os.getenv(
                "DCR_ALLOWED_REDIRECT_PATTERNS",
                ",".join(DEFAULT_REDIRECT_PATTERNS)
            ).split(",") if p.strip()]
        )
        self._allowed_grant_types = set(
            allowed_grant_types if allowed_grant_types is not None
            else [g.strip() for g in os.getenv(
                "DCR_ALLOWED_GRANT_TYPES", "authorization_code,refresh_token"
            ).split(",") if g.strip()]
        )
        self._allowed_app_types = set(
            allowed_app_types if allowed_app_types is not None
            else [a.strip() for a in os.getenv(
                "DCR_ALLOWED_APP_TYPES", "web,native"
            ).split(",") if a.strip()]
        )
        self._max_registrations_per_hour = (
            max_registrations_per_hour if max_registrations_per_hour is not None
            else int(os.getenv("DCR_MAX_REGISTRATIONS_PER_HOUR", "10"))
        )
        self._require_initial_access_token = (
            require_initial_access_token if require_initial_access_token is not None
            else os.getenv("DCR_REQUIRE_INITIAL_ACCESS_TOKEN", "false").lower() == "true"
        )
        self._initial_access_token = (
            initial_access_token if initial_access_token is not None
            else os.getenv("DCR_INITIAL_ACCESS_TOKEN", "")
        )
        self._auto_enable_agent = (
            auto_enable_agent if auto_enable_agent is not None
            else os.getenv("DCR_AUTO_ENABLE_AGENT", "false").lower() == "true"
        )
        self._default_resource_access = (
            default_resource_access if default_resource_access is not None
            else [b.strip() for b in os.getenv(
                "DCR_DEFAULT_BACKEND_ACCESS", ""
            ).split(",") if b.strip()]
        )
        # Callable(source_ip) -> int : returns registration count in last hour
        self._registration_counter = registration_counter

        # Dynamic pattern loading from gateway_config
        self._store = store
        self._event_bus = event_bus
        self._pattern_cache_ttl = pattern_cache_ttl_seconds
        self._cached_patterns: Optional[list[str]] = None
        self._cached_patterns_expires_at: float = 0.0
        self._pubsub_registered: bool = False

    @property
    def provision_okta_app(self) -> bool:
        return self._provision_okta_app

    @property
    def auto_enable_agent(self) -> bool:
        return self._auto_enable_agent

    @property
    def default_resource_access(self) -> list[str]:
        return list(self._default_resource_access)

    def _get_active_patterns(self) -> list[str]:
        """Return the current allowed patterns list.

        Precedence:
          1. If store is None -> use env-derived self._allowed_redirect_patterns
          2. If L1 cache fresh -> return cached list.
          3. Otherwise load from store, validate, cache.
        """
        if self._store is None:
            return self._allowed_redirect_patterns

        # Check L1 cache
        now = time.monotonic()
        if self._cached_patterns is not None and now < self._cached_patterns_expires_at:
            return self._cached_patterns

        # Load from store
        try:
            stored = self._store.get_gateway_config(GATEWAY_CONFIG_KEY_REDIRECT_PATTERNS)
        except Exception as e:
            logger.warning(f"DCRPolicy: failed to read patterns from store: {e}")
            # Fall back to env-derived patterns if store read fails
            return self._allowed_redirect_patterns

        if stored is None:
            # Seed from env var on first start
            if self._allowed_redirect_patterns:
                try:
                    self._store.set_gateway_config(
                        GATEWAY_CONFIG_KEY_REDIRECT_PATTERNS,
                        list(self._allowed_redirect_patterns),
                        user="system:seed",
                        description="Seeded from DCR_ALLOWED_REDIRECT_PATTERNS env var on first start",
                    )
                    logger.info("DCRPolicy: seeded redirect patterns to gateway_config from env")
                except Exception as e:
                    logger.warning(f"DCRPolicy: failed to seed patterns to store: {e}")
            validated = list(self._allowed_redirect_patterns)
        else:
            # Validate each pattern from the store
            from okta_agent_proxy.auth.redirect_pattern_validator import (
                validate_redirect_pattern,
                RedirectPatternError,
            )
            validated = []
            if isinstance(stored, list):
                for pattern in stored:
                    if not isinstance(pattern, str):
                        logger.warning(f"DCRPolicy: dropping non-string pattern: {pattern!r}")
                        continue
                    try:
                        validate_redirect_pattern(pattern)
                        validated.append(pattern)
                    except RedirectPatternError as e:
                        logger.warning(f"DCRPolicy: dropping invalid stored pattern {pattern!r}: {e}")
            else:
                logger.warning(f"DCRPolicy: stored patterns is not a list, ignoring: {type(stored)}")

        # Populate L1 cache
        self._cached_patterns = validated
        self._cached_patterns_expires_at = now + self._pattern_cache_ttl

        return validated

    def invalidate_pattern_cache(self) -> None:
        """Clear the L1 pattern cache, forcing a re-read from the store on next access."""
        self._cached_patterns = None
        self._cached_patterns_expires_at = 0.0
        logger.debug("DCRPolicy: L1 pattern cache invalidated")

    async def register_pubsub_subscriber(self) -> None:
        """Register this instance's invalidation handler on the event bus.

        Must be called during app startup AFTER DCRPolicy is constructed
        and BEFORE event_bus.start_listener() is called.

        Idempotent: safe to call more than once.
        """
        if self._event_bus is None or self._pubsub_registered:
            return
        from okta_agent_proxy.cache.pubsub import CHANNEL_DCR_PATTERNS_INVALIDATE

        async def _on_invalidate(message: str) -> None:
            try:
                payload = _json.loads(message) if message else {}
                logger.info(
                    "DCRPolicy: received pattern invalidation event "
                    f"(user={payload.get('user')}, ts={payload.get('ts')})"
                )
            except Exception:
                logger.info("DCRPolicy: received pattern invalidation event")
            self.invalidate_pattern_cache()

        await self._event_bus.subscribe(
            CHANNEL_DCR_PATTERNS_INVALIDATE, _on_invalidate
        )
        self._pubsub_registered = True
        logger.info("DCRPolicy: subscribed to pattern invalidation channel")

    def _reject(self, reason: str) -> DCRPolicyResult:
        return DCRPolicyResult(allowed=False, reason=reason, sanitized_body=None)

    def _redirect_uri_matches_pattern(self, uri: str, pattern: str) -> bool:
        """Check if a redirect URI matches an allowed pattern using fnmatch."""
        return fnmatch.fnmatch(uri, pattern)

    def _validate_redirect_uri(self, uri: str) -> bool:
        """Check if a redirect URI matches any allowed pattern."""
        for pattern in self._get_active_patterns():
            if self._redirect_uri_matches_pattern(uri, pattern):
                return True
        return False

    async def validate(
        self,
        request_body: dict,
        source_ip: str,
        bearer_token: Optional[str] = None,
    ) -> DCRPolicyResult:
        """Validate a DCR request against policy rules.

        Args:
            request_body: The RFC 7591 registration request body.
            source_ip: Source IP of the request (for rate limiting).
            bearer_token: Optional initial access token.

        Returns:
            DCRPolicyResult with allowed status and sanitized body.
        """
        # Rule 1: DCR must be enabled
        if not self._enabled:
            return self._reject("Dynamic Client Registration is disabled")

        # Rule 2: Initial access token check
        if self._require_initial_access_token:
            if not bearer_token:
                return self._reject("Initial access token is required")
            if self._initial_access_token and bearer_token != self._initial_access_token:
                return self._reject("Invalid initial access token")

        # Rule 3: Rate limiting
        if self._registration_counter is not None:
            count = self._registration_counter(source_ip)
            if count >= self._max_registrations_per_hour:
                return self._reject(
                    f"Rate limit exceeded: {count} registrations in the last hour "
                    f"(max {self._max_registrations_per_hour})"
                )

        # Rule 4: client_name required
        client_name = request_body.get("client_name", "").strip()
        if not client_name:
            return self._reject("client_name is required")
        if len(client_name) > 255:
            return self._reject("client_name must be at most 255 characters")

        # Rule 5: redirect_uris validation
        redirect_uris = request_body.get("redirect_uris")
        if not redirect_uris or not isinstance(redirect_uris, list) or len(redirect_uris) == 0:
            return self._reject("redirect_uris is required and must be a non-empty list")

        for uri in redirect_uris:
            if not isinstance(uri, str) or not uri.strip():
                return self._reject("Each redirect_uri must be a non-empty string")
            if not self._validate_redirect_uri(uri):
                return self._reject(
                    f"redirect_uri '{uri}' does not match any allowed pattern"
                )

        # Rule 6: grant_types validation
        grant_types = request_body.get("grant_types", ["authorization_code"])
        if not isinstance(grant_types, list):
            grant_types = ["authorization_code"]
        for gt in grant_types:
            if gt not in self._allowed_grant_types:
                return self._reject(f"Unsupported grant_type: '{gt}'")

        # Rule 7: application_type validation
        application_type = request_body.get("application_type", "web")
        if application_type not in self._allowed_app_types:
            return self._reject(f"Unsupported application_type: '{application_type}'")

        # Rule 8: token_endpoint_auth_method defaults
        token_endpoint_auth_method = request_body.get("token_endpoint_auth_method")
        if not token_endpoint_auth_method:
            token_endpoint_auth_method = (
                "client_secret_basic" if application_type == "web" else "none"
            )

        # Rule 9: Scope intersection
        requested_scope = request_body.get("scope", "")
        if isinstance(requested_scope, str):
            requested_scopes = set(requested_scope.split()) if requested_scope else set()
        elif isinstance(requested_scope, list):
            requested_scopes = set(requested_scope)
        else:
            requested_scopes = set()

        # Effective allowed set = baseline OIDC scopes ∪ scopes configured on
        # any resolved resource's Okta Managed Connection. Any DCR-requested
        # scope not in that union is silently dropped.
        allowed_scopes = SUPPORTED_SCOPES | _runtime_resource_scopes()
        sanitized_scopes = requested_scopes & allowed_scopes if requested_scopes else set()
        scope_str = " ".join(sorted(sanitized_scopes)) if sanitized_scopes else ""

        # Build sanitized body
        sanitized_body = {
            "client_name": client_name,
            "redirect_uris": redirect_uris,
            "grant_types": grant_types,
            "application_type": application_type,
            "response_types": request_body.get("response_types", ["code"]),
            "token_endpoint_auth_method": token_endpoint_auth_method,
        }
        if scope_str:
            sanitized_body["scope"] = scope_str

        logger.info(f"DCR policy: approved registration for '{client_name}' from {source_ip}")
        return DCRPolicyResult(
            allowed=True,
            reason="Registration approved",
            sanitized_body=sanitized_body,
        )
