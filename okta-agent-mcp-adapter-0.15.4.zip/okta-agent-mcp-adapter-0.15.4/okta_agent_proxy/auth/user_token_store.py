"""
Server-side mapping of access_tokens to their associated OIDC tokens.

Key: SHA-256 hash of the access_token (never store raw access_tokens as keys)
Value: { id_token, refresh_token, user_sub, agent_id, stored_at, expires_in }

Used by the XAA pipeline to retrieve the id_token for ID-JAG exchanges.
Updated on every BFF token exchange (initial + refresh).

Supports two modes:
- Standalone: TTLCache only (backward compatible, single-pod)
- CacheService: TTLCache as L1 fast-path + CacheService as L2 backing store
"""

import asyncio
import hashlib
import json
import logging
import os
from datetime import datetime, timezone
from typing import Optional

from cachetools import TTLCache

from okta_agent_proxy.cache.serializers import (
    serialize_encrypted,
    deserialize_encrypted,
    serialize_json,
    deserialize_json,
)

logger = logging.getLogger(__name__)

# Key prefix for entries stored via CacheService
_USER_TOKEN_PREFIX = "user_token:"


class UserTokenStore:
    """Maps access_tokens -> { id_token, refresh_token, user_sub, agent_id }.

    Keys are SHA-256 hashes of access_tokens so raw tokens are never stored
    as cache keys.  Values are optionally encrypted at rest with AES-256-GCM.

    When a cache_service is provided, async methods (astore, alookup, etc.)
    additionally write/read from CacheService as an L2 backing store,
    enabling cross-pod consistency for horizontal scaling.
    """

    def __init__(
        self,
        encryption_service=None,
        default_ttl: int = None,
        max_size: int = None,
        cache_service=None,
        event_bus=None,
    ):
        if default_ttl is None:
            default_ttl = int(os.getenv("USER_TOKEN_STORE_TTL", "86400"))
        if max_size is None:
            max_size = int(os.getenv("USER_TOKEN_STORE_MAX_SIZE", "10000"))

        self._enc = encryption_service
        self._default_ttl = default_ttl
        self._max_size = max_size
        self._cache: TTLCache = TTLCache(maxsize=max_size, ttl=default_ttl)
        self._cache_service = cache_service
        self._event_bus = event_bus

        logger.info(
            f"[TOKEN-STORE] Initialized (encrypted={encryption_service is not None}, "
            f"ttl={default_ttl}s, max_size={max_size}, "
            f"cache_service={'wired' if cache_service else 'none'}, "
            f"event_bus={'wired' if event_bus else 'none'})"
        )

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _hash_token(token: str) -> str:
        """SHA-256 hash of the token -- used as the cache key."""
        return hashlib.sha256(token.encode()).hexdigest()

    def _service_key(self, token_hash: str) -> str:
        """Build the CacheService key with user_token prefix."""
        return f"{_USER_TOKEN_PREFIX}{token_hash}"

    def _serialize(self, data: dict) -> str:
        if self._enc:
            return serialize_encrypted(data, self._enc)
        return serialize_json(data)

    def _deserialize(self, raw: str) -> dict:
        if self._enc:
            return deserialize_encrypted(raw, self._enc)
        return deserialize_json(raw)

    def _emit_audit(self, event_type, user_sub: str = None, agent_id: str = None, **details):
        """Emit an audit event (non-blocking, swallows errors)."""
        try:
            from okta_agent_proxy.audit import emit_audit_event, AuditEventType, AuditSeverity
            evt = getattr(AuditEventType, event_type, None)
            if evt is None:
                return
            # emit_audit_event is async — fire and forget from sync context
            try:
                loop = asyncio.get_running_loop()
                loop.create_task(emit_audit_event(
                    event_type=evt,
                    severity=AuditSeverity.INFO,
                    user_id=user_sub,
                    agent_id=agent_id,
                    details=details,
                ))
            except RuntimeError:
                pass  # No event loop — skip audit in pure sync context
        except Exception:
            pass  # Never let audit break the store

    # ------------------------------------------------------------------
    # Public sync API (unchanged signatures)
    # ------------------------------------------------------------------

    def store(
        self,
        access_token: str,
        id_token: str,
        refresh_token: str,
        user_sub: str,
        agent_id: str,
        expires_in: Optional[int] = None,
    ) -> None:
        """Store a token mapping keyed by the access_token's SHA-256 hash."""
        key = self._hash_token(access_token)
        payload = {
            "id_token": id_token,
            "refresh_token": refresh_token,
            "user_sub": user_sub,
            "agent_id": agent_id,
            "stored_at": datetime.now(timezone.utc).isoformat(),
            "expires_in": expires_in,
        }
        self._cache[key] = self._serialize(payload)
        self._emit_audit("USER_TOKEN_STORE_WRITE", user_sub=user_sub, agent_id=agent_id)
        logger.info(f"[TOKEN-STORE] Stored token mapping for user={user_sub} agent={agent_id}")

    def lookup(self, access_token: str) -> Optional[dict]:
        """Look up the token mapping for the given access_token."""
        key = self._hash_token(access_token)
        raw = self._cache.get(key)
        if raw is not None:
            logger.debug(f"[TOKEN-STORE] Lookup hit for token_hash={key[:8]}...")
            return self._deserialize(raw)
        logger.debug(f"[TOKEN-STORE] Lookup miss for token_hash={key[:8]}...")
        return None

    def update(
        self,
        access_token: str,
        id_token: Optional[str] = None,
        refresh_token: Optional[str] = None,
    ) -> None:
        """Update an existing entry, preserving fields not provided."""
        key = self._hash_token(access_token)
        raw = self._cache.get(key)
        if raw is None:
            logger.warning(f"[TOKEN-STORE] Update called for missing token_hash={key[:8]}...")
            return

        entry = self._deserialize(raw)
        if id_token is not None:
            entry["id_token"] = id_token
        if refresh_token is not None:
            entry["refresh_token"] = refresh_token
        entry["stored_at"] = datetime.now(timezone.utc).isoformat()

        self._cache[key] = self._serialize(entry)
        logger.info(
            f"[TOKEN-STORE] Updated token mapping for "
            f"user={entry.get('user_sub')} agent={entry.get('agent_id')}"
        )

    def remove(self, access_token: str) -> None:
        """Remove the mapping for the given access_token."""
        key = self._hash_token(access_token)
        if self._cache.pop(key, None) is not None:
            self._emit_audit("USER_TOKEN_STORE_REMOVE")
            logger.info(f"[TOKEN-STORE] Removed token mapping for token_hash={key[:8]}...")

    def remove_by_user(self, user_sub: str) -> int:
        """Remove all entries for the given user_sub. Returns count removed."""
        keys_to_remove = []
        for key, raw in list(self._cache.items()):
            try:
                entry = self._deserialize(raw)
                if entry.get("user_sub") == user_sub:
                    keys_to_remove.append(key)
            except Exception:
                pass
        for key in keys_to_remove:
            self._cache.pop(key, None)
        if keys_to_remove:
            self._emit_audit("USER_TOKEN_STORE_REMOVE", user_sub=user_sub,
                             count=len(keys_to_remove))
            logger.info(
                f"[TOKEN-STORE] Removed {len(keys_to_remove)} entries for user={user_sub}"
            )
        return len(keys_to_remove)

    def get_stats(self) -> dict:
        """Return store statistics (no token values)."""
        return {
            "total_entries": len(self._cache),
            "encrypted": self._enc is not None,
            "ttl_seconds": self._default_ttl,
            "max_size": self._max_size,
            "cache_service": self._cache_service is not None,
        }

    # ------------------------------------------------------------------
    # Async API (L1 + optional L2 via CacheService)
    # ------------------------------------------------------------------

    async def astore(
        self,
        access_token: str,
        id_token: str,
        refresh_token: str,
        user_sub: str,
        agent_id: str,
        expires_in: Optional[int] = None,
    ) -> None:
        """Async store: writes to L1 TTLCache and (if wired) L2 CacheService."""
        key = self._hash_token(access_token)
        payload = {
            "id_token": id_token,
            "refresh_token": refresh_token,
            "user_sub": user_sub,
            "agent_id": agent_id,
            "stored_at": datetime.now(timezone.utc).isoformat(),
            "expires_in": expires_in,
        }
        serialized = self._serialize(payload)

        # L1
        self._cache[key] = serialized

        # L2
        if self._cache_service:
            try:
                await self._cache_service.set(
                    self._service_key(key), serialized, ttl_seconds=self._default_ttl
                )
            except Exception as e:
                logger.warning(f"[TOKEN-STORE] L2 write failed, L1-only: {e}")

        self._emit_audit("USER_TOKEN_STORE_WRITE", user_sub=user_sub, agent_id=agent_id)
        logger.info(f"[TOKEN-STORE] Stored token mapping for user={user_sub} agent={agent_id}")

    async def alookup(self, access_token: str) -> Optional[dict]:
        """Async lookup: checks L1 first, then L2 CacheService."""
        key = self._hash_token(access_token)

        # L1 check
        raw = self._cache.get(key)
        if raw is not None:
            logger.debug(f"[TOKEN-STORE] Lookup hit (L1) for token_hash={key[:8]}...")
            return self._deserialize(raw)

        # L2 check
        if self._cache_service:
            try:
                raw = await self._cache_service.get(self._service_key(key))
                if raw is not None:
                    # Promote to L1
                    self._cache[key] = raw
                    logger.debug(f"[TOKEN-STORE] Lookup hit (L2) for token_hash={key[:8]}...")
                    return self._deserialize(raw)
            except Exception as e:
                logger.warning(f"[TOKEN-STORE] L2 lookup failed, L1-only: {e}")

        logger.debug(f"[TOKEN-STORE] Lookup miss for token_hash={key[:8]}...")
        return None

    async def aupdate(
        self,
        access_token: str,
        id_token: Optional[str] = None,
        refresh_token: Optional[str] = None,
    ) -> None:
        """Async update: updates L1 and (if wired) L2 CacheService."""
        key = self._hash_token(access_token)

        # Try L1 first
        raw = self._cache.get(key)

        # If not in L1, try L2
        if raw is None and self._cache_service:
            try:
                raw = await self._cache_service.get(self._service_key(key))
            except Exception as e:
                logger.warning(f"[TOKEN-STORE] L2 lookup for update failed: {e}")

        if raw is None:
            logger.warning(f"[TOKEN-STORE] Update called for missing token_hash={key[:8]}...")
            return

        entry = self._deserialize(raw)
        if id_token is not None:
            entry["id_token"] = id_token
        if refresh_token is not None:
            entry["refresh_token"] = refresh_token
        entry["stored_at"] = datetime.now(timezone.utc).isoformat()

        serialized = self._serialize(entry)

        # L1
        self._cache[key] = serialized

        # L2
        if self._cache_service:
            try:
                await self._cache_service.set(
                    self._service_key(key), serialized, ttl_seconds=self._default_ttl
                )
            except Exception as e:
                logger.warning(f"[TOKEN-STORE] L2 update failed, L1-only: {e}")

        logger.info(
            f"[TOKEN-STORE] Updated token mapping for "
            f"user={entry.get('user_sub')} agent={entry.get('agent_id')}"
        )

    async def aremove(self, access_token: str) -> None:
        """Async remove: removes from L1 and (if wired) L2 CacheService."""
        key = self._hash_token(access_token)
        removed = self._cache.pop(key, None) is not None

        if self._cache_service:
            try:
                await self._cache_service.delete(self._service_key(key))
                removed = True
            except Exception as e:
                logger.warning(f"[TOKEN-STORE] L2 remove failed: {e}")

        if removed:
            self._emit_audit("USER_TOKEN_STORE_REMOVE")
            logger.info(f"[TOKEN-STORE] Removed token mapping for token_hash={key[:8]}...")
            # Publish cross-pod invalidation
            if self._event_bus:
                try:
                    from okta_agent_proxy.cache.pubsub import CHANNEL_USER_TOKEN_INVALIDATE
                    await self._event_bus.publish(
                        CHANNEL_USER_TOKEN_INVALIDATE,
                        json.dumps({"v": 1, "key": key}),
                    )
                except Exception as e:
                    logger.warning(f"[TOKEN-STORE] Pub/sub publish failed: {e}")

    async def aremove_by_user(self, user_sub: str) -> int:
        """Async remove all entries for a user.

        L1: iterates and matches by user_sub (same as sync).
        L2: calls clear_prefix on the entire user_token: namespace.
        NOTE: L2 clear_prefix removes ALL user_token entries, not just one
        user's, because CacheService doesn't support secondary index lookups.
        This is an acceptable trade-off — other pods will re-populate from
        the source of truth (Okta) on the next request. A per-user secondary
        index in L2 is deferred to a future prompt.
        """
        # L1 — selective removal
        keys_to_remove = []
        for key, raw in list(self._cache.items()):
            try:
                entry = self._deserialize(raw)
                if entry.get("user_sub") == user_sub:
                    keys_to_remove.append(key)
            except Exception:
                pass
        for key in keys_to_remove:
            self._cache.pop(key, None)

        # L2 — prefix clear (broad)
        if self._cache_service:
            try:
                await self._cache_service.clear_prefix(_USER_TOKEN_PREFIX)
            except Exception as e:
                logger.warning(f"[TOKEN-STORE] L2 clear_prefix failed: {e}")

        count = len(keys_to_remove)
        if count:
            self._emit_audit("USER_TOKEN_STORE_REMOVE", user_sub=user_sub, count=count)
            logger.info(
                f"[TOKEN-STORE] Removed {count} entries for user={user_sub}"
            )
            # Publish cross-pod invalidation for each removed key
            if self._event_bus:
                try:
                    from okta_agent_proxy.cache.pubsub import CHANNEL_USER_TOKEN_INVALIDATE
                    for key in keys_to_remove:
                        await self._event_bus.publish(
                            CHANNEL_USER_TOKEN_INVALIDATE,
                            json.dumps({"v": 1, "key": key, "user_sub": user_sub}),
                        )
                except Exception as e:
                    logger.warning(f"[TOKEN-STORE] Pub/sub publish failed: {e}")
        return count


# ------------------------------------------------------------------
# Singleton accessor
# ------------------------------------------------------------------

_store: Optional[UserTokenStore] = None


def get_user_token_store(cache_service=None, event_bus=None) -> UserTokenStore:
    """Get or create the global UserTokenStore instance.

    When cache_service is provided AND the singleton hasn't been built yet,
    it is passed into the constructor for L2 backing. If the singleton
    already exists, the existing instance is returned (with a warning if
    the caller passed a different cache_service).
    """
    global _store
    if _store is None:
        from okta_agent_proxy.crypto import get_encryption_service

        enc = None
        try:
            enc = get_encryption_service()
        except Exception:
            pass  # No encryption key configured -- store plaintext
        _store = UserTokenStore(
            encryption_service=enc,
            cache_service=cache_service,
            event_bus=event_bus,
        )
    elif cache_service is not None and _store._cache_service is not cache_service:
        logger.warning(
            "[TOKEN-STORE] Singleton already exists; ignoring new cache_service. "
            "Call get_user_token_store() before other modules to ensure wiring."
        )
    return _store


def reset_user_token_store() -> None:
    """Reset the singleton (for testing)."""
    global _store
    _store = None


def capture_token_mapping(access_token, id_token, refresh_token, client_id, expires_in):
    """Non-fatal capture of access_token -> id_token mapping for XAA.

    Called by the BFF token proxy after every successful Okta token exchange.
    Extracts user_sub from the id_token claims and stores the mapping.
    Never raises -- failures are logged and swallowed.

    When called from an async context (e.g. BFF handler), automatically
    schedules an L2 write via astore() for cross-pod visibility.
    """
    if not access_token or not id_token:
        return
    try:
        from jose import jwt as jose_jwt

        claims = jose_jwt.get_unverified_claims(id_token)
        user_sub = claims.get("sub", "unknown")

        store = get_user_token_store()

        # Always write to L1 synchronously so callers can lookup immediately
        store.store(
            access_token=access_token,
            id_token=id_token,
            refresh_token=refresh_token or "",
            user_sub=user_sub,
            agent_id=client_id or "unknown",
            expires_in=expires_in,
        )

        # If in async context and cache_service is wired, also schedule L2 write
        if store._cache_service:
            try:
                loop = asyncio.get_running_loop()
                loop.create_task(store.astore(
                    access_token=access_token,
                    id_token=id_token,
                    refresh_token=refresh_token or "",
                    user_sub=user_sub,
                    agent_id=client_id or "unknown",
                    expires_in=expires_in,
                ))
            except RuntimeError:
                pass  # No event loop — L1-only is fine
        logger.info(f"[BFF] Captured token mapping for user={user_sub} agent={client_id}")
    except Exception as e:
        logger.warning(f"[BFF] Failed to capture token mapping: {e}")
