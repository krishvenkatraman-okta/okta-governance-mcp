"""
Scope filtering utilities for ALLOW_ALL expansion.

When an Okta Managed Connection has `scopeCondition = ALLOW_ALL`, the syncer
fetches the target authorization server's `scopes_supported` and strips two
layers of noise before persisting the resolved list:

1. OIDC scopes (openid, profile, email, address, phone, offline_access) -- these
   belong to user login flows, not resource access.
2. Okta-internal scopes (`interclient_access`, `device_sso`) -- configurable via
   the `OKTA_SCOPE_BLOCKLIST` env var (comma-separated).

Okta's `scopes_supported` discovery field frequently advertises scopes that are
NOT granted to a given OIDC client/app (device_sso, interclient_access, and
sometimes the AS's `scopes_supported` list drifts from its access policy).
Those scopes pass Leg 1 of ID-JAG but fail Leg 2 (`invalid_scope: One or more
scopes are not configured for the authorization server resource`), so they
need to be filtered pre-persist. If a customer's AS advertises additional
Okta-internal scopes, they can add them to `OKTA_SCOPE_BLOCKLIST`.

Callers should prefer `filter_as_scopes()` over hand-rolled filtering so the
blocklist stays consistent between the syncer and the admin sync endpoint.
"""

import os

OIDC_SCOPES: frozenset[str] = frozenset(
    {"openid", "profile", "email", "address", "phone", "offline_access"}
)

_DEFAULT_BLOCKLIST = "interclient_access,device_sso"


def get_scope_blocklist() -> frozenset[str]:
    """Parse `OKTA_SCOPE_BLOCKLIST` env var.

    Comma-separated list; whitespace trimmed. Default:
    `interclient_access,device_sso`. Set to an empty string to disable the
    blocklist entirely.
    """
    raw = os.getenv("OKTA_SCOPE_BLOCKLIST", _DEFAULT_BLOCKLIST)
    return frozenset(s.strip() for s in raw.split(",") if s.strip())


def filter_as_scopes(scopes: list[str]) -> list[str]:
    """Remove OIDC and blocklisted scopes; preserve order; dedupe."""
    blocklist = get_scope_blocklist()
    seen: set[str] = set()
    out: list[str] = []
    for s in scopes or []:
        if s in OIDC_SCOPES or s in blocklist or s in seen:
            continue
        seen.add(s)
        out.append(s)
    return out
