"""
Agent authorization utilities for multi-agent support.

Authorization is determined by the syncer's resolved resources and
the Resource Map store.
"""

import logging
from typing import Dict, Any, List, Optional

from okta_agent_proxy.audit import emit_audit_event, AuditEventType, AuditSeverity

logger = logging.getLogger(__name__)


class AgentAuthorizationError(Exception):
    """Raised when agent is not authorized for a requested resource."""

    def __init__(self, agent_id: str, reason: str, details: Optional[Dict] = None):
        self.agent_id = agent_id
        self.reason = reason
        self.details = details or {}
        super().__init__(f"Agent {agent_id} not authorized: {reason}")


async def check_agent_can_access_resource(
    agent_id: str,
    agent_config: Dict[str, Any],
    resource_name: str
) -> bool:
    """
    Check if agent is authorized to access a resource.

    Authorization sources (checked in order):
    1. Okta Managed Connections syncer — if the syncer has resolved
       this resource from an Okta connection, the agent is authorized.
    2. Resource Map store — resource exists by name in the address book.

    Raises:
        AgentAuthorizationError: If not authorized
    """
    if not agent_config:
        await emit_audit_event(
            AuditEventType.AUTHZ_ACCESS_DENIED,
            severity=AuditSeverity.WARNING,
            resource_name=resource_name,
            details={"agent_id": agent_id, "reason": "agent_config_not_found"},
            outcome="failure",
        )
        raise AgentAuthorizationError(agent_id, "Agent configuration not found")

    # 1. Okta Managed Connections syncer — resource resolved from Okta connection
    try:
        from okta_agent_proxy.app import get_resource_syncer
        syncer = get_resource_syncer()
        if syncer:
            resolved = syncer.get_resource(resource_name)
            if resolved:
                logger.debug(
                    f"Agent {agent_id} authorized for resource {resource_name} "
                    f"(syncer: connection={resolved.connection_id})"
                )
                await emit_audit_event(
                    AuditEventType.AUTHZ_ACCESS_GRANTED,
                    resource_name=resource_name,
                    details={"agent_id": agent_id, "reason": "resolved_resource_match"},
                )
                return True
    except Exception as e:
        logger.debug(f"Syncer check failed for {resource_name}: {e}")

    # 2. Resource Map store — resource exists by name in the address book.
    try:
        from okta_agent_proxy.app import get_resource_store
        rm_store = get_resource_store()
        if rm_store:
            entry = rm_store.get_by_name(resource_name)
            if entry:
                logger.debug(
                    f"Agent {agent_id} authorized for resource {resource_name} "
                    f"(resource_store: resource_id={entry.resource_id})"
                )
                await emit_audit_event(
                    AuditEventType.AUTHZ_ACCESS_GRANTED,
                    resource_name=resource_name,
                    details={"agent_id": agent_id, "reason": "resource_store_match"},
                )
                return True
    except Exception as e:
        logger.debug(f"Resource Map check failed for {resource_name}: {e}")

    await emit_audit_event(
        AuditEventType.AUTHZ_ACCESS_DENIED,
        severity=AuditSeverity.WARNING,
        resource_name=resource_name,
        details={"agent_id": agent_id, "reason": "no_resolved_resource"},
        outcome="failure",
    )
    raise AgentAuthorizationError(
        agent_id,
        f"Not authorized to access resource '{resource_name}'",
        {"resource_requested": resource_name}
    )


def create_authorization_error_response(
    error: AgentAuthorizationError
) -> Dict[str, Any]:
    """Create a JSON-RPC error response for authorization failure."""
    return {
        "error": "authorization_denied",
        "message": error.reason,
        "agent_id": error.agent_id,
        "details": error.details
    }


def create_missing_agent_error_response(reason: str = "Agent not found") -> Dict[str, Any]:
    """Create a JSON-RPC error response for missing agent."""
    return {
        "error": "agent_not_found",
        "message": reason
    }


def create_invalid_agent_header_response() -> Dict[str, Any]:
    """Create a JSON-RPC error response for missing/invalid X-Agent-ID header."""
    return {
        "error": "agent_header_missing",
        "message": "X-Agent-ID header is required for multi-agent gateway"
    }


class AgentAuthorizationChecker:
    """
    Convenience class for checking multiple authorization conditions.

    Usage:
        checker = AgentAuthorizationChecker(agent_id, agent_config)
        try:
            await checker.check_resource_access(resource_name)
        except AgentAuthorizationError as e:
            return create_authorization_error_response(e)
    """

    def __init__(self, agent_id: str, agent_config: Dict[str, Any]):
        self.agent_id = agent_id
        self.agent_config = agent_config

    async def check_resource_access(self, resource_name: str) -> "AgentAuthorizationChecker":
        """Check resource access and raise if not authorized."""
        await check_agent_can_access_resource(self.agent_id, self.agent_config, resource_name)
        return self

