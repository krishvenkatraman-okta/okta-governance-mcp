"""
Global Logout Handler — orchestrates revocation in response to Okta
ITP Universal Logout calls.

This module is HTTP-agnostic. The Starlette route handler in
auth/global_logout_route.py validates the inbound signed JWT and
parses the iss_sub Subject Identifier, then calls
GlobalLogoutHandler.revoke_user(sub, correlation_id).

Revocation sequence:
  1. UserTokenStore.aremove_by_user(user_sub)
       -> drops L1 + L2 entries, emits pub/sub for cross-pod invalidation.
  2. TokenCache.ainvalidate_all_for_user(user_sub)
       -> drops cached backend tokens (ID-JAG and STS) via awaitable
          CacheService calls (no thread-pool fallback blocking).
  3. MCPSessionManager.terminate_all_for_user(user_sub)
       -> fires DELETE to each backend MCP server in parallel.

Step 3 errors do NOT fail the revocation overall — the user is already
cut off at Layer 2 once steps 1 and 2 complete.

Per Okta's dev guide for Universal Logout, an unrecognized subject
returns HTTP 204 (NOT 404) to prevent user-account enumeration. This
handler emits GLOBAL_LOGOUT_SUBJECT_NOT_FOUND when both tokens_revoked
and sessions_terminated are 0, but still returns successfully.
"""

import logging
from typing import Optional, Tuple

from okta_agent_proxy.audit import emit_audit_event
from okta_agent_proxy.audit.events import AuditEventType, AuditSeverity

logger = logging.getLogger(__name__)


class GlobalLogoutHandler:
    """Orchestrates user-scoped revocation across stores and sessions."""

    def __init__(
        self,
        token_store=None,
        token_cache=None,
        session_manager=None,
        relay=None,
        revocation_registry=None,
        unified_handler=None,
    ):
        """DI-friendly constructor. None args resolve to singletons
        on first use."""
        self._token_store = token_store
        self._token_cache = token_cache
        self._session_manager = session_manager
        self._relay = relay
        self._revocation_registry = revocation_registry
        self._unified_handler = unified_handler

    def _get_token_store(self):
        if self._token_store is not None:
            return self._token_store
        from okta_agent_proxy.auth.user_token_store import get_user_token_store
        return get_user_token_store()

    def _get_token_cache(self):
        if self._token_cache is not None:
            return self._token_cache
        from okta_agent_proxy import app as app_module
        return app_module.router.resource_token_cache

    def _get_session_manager(self):
        if self._session_manager is not None:
            return self._session_manager
        from okta_agent_proxy import app as app_module
        return app_module.proxy_handler.session_manager

    def _get_relay(self):
        if self._relay is not None:
            return self._relay
        # Only look up the relay if the app module is already loaded.
        # Forcing the import here would pull DB/Redis initialization into
        # test paths that don't need it (e.g. unit tests that mock the
        # other dependencies), slowing them by tens of seconds.
        import sys
        app_module = sys.modules.get("okta_agent_proxy.app")
        if app_module is None:
            return None
        return getattr(app_module, "confidential_relay", None)

    def _get_revocation_registry(self):
        if self._revocation_registry is not None:
            return self._revocation_registry
        from okta_agent_proxy.auth.revocation_registry import get_revocation_registry
        return get_revocation_registry()

    def _get_unified_handler(self):
        if self._unified_handler is not None:
            return self._unified_handler
        # Same sys.modules check as _get_relay — don't force app init.
        import sys
        app_module = sys.modules.get("okta_agent_proxy.app")
        if app_module is None:
            return None
        return getattr(app_module, "unified_handler", None)

    @staticmethod
    def parse_iss_sub_subject(subject) -> Tuple[str, str]:
        """Validate and unpack an RFC 9493 iss_sub Subject Identifier.

        Returns (iss, sub).

        Raises ValueError with a description safe to return as
        error_description (no PII beyond what was in the request).

        NOTE: Okta supports both 'iss_sub' and 'email' formats at
        config time. This adapter accepts ONLY 'iss_sub' because:
          - sub is immutable; email is mutable.
          - Token mappings in UserTokenStore are keyed by Okta's sub.
        Operators must select 'Issuer and Subject Identifier' in
        the Okta Logout app config, NOT 'Email Identifier'.
        """
        if not isinstance(subject, dict):
            raise ValueError("subject must be a JSON object")

        fmt = subject.get("format")
        if fmt is None:
            raise ValueError("subject is missing required 'format' field")
        if fmt != "iss_sub":
            raise ValueError(
                f"unsupported subject format {fmt!r}; only 'iss_sub' is accepted"
            )

        iss = subject.get("iss")
        sub = subject.get("sub")

        if not isinstance(iss, str) or not iss.strip():
            raise ValueError("subject is missing or has empty 'iss' field")
        if not isinstance(sub, str) or not sub.strip():
            raise ValueError("subject is missing or has empty 'sub' field")

        return iss, sub

    async def revoke_user(self, user_sub: str, correlation_id: str) -> dict:
        """Perform full revocation for a single user. Returns a summary.

        Summary shape:
          {
            "user_sub": str,
            "correlation_id": str,
            "tokens_revoked": int,
            "cache_swept": bool,
            "sessions_terminated": int,
            "sessions_failed": int,
            "backends": dict[resource_name -> bool],
          }

        On unrecoverable error in step 1 or step 2: emit
        GLOBAL_LOGOUT_COMPLETED with outcome="failure" and re-raise.
        Step 3 errors are absorbed (the user is already cut off).
        """
        summary = {
            "user_sub": user_sub,
            "correlation_id": correlation_id,
            "tokens_revoked": 0,
            "cache_swept": False,
            "sessions_terminated": 0,
            "sessions_failed": 0,
            "backends": {},
            "relay_tokens_revoked": 0,
            "sub_marked_revoked": False,
        }

        # Step 1: token store
        try:
            store = self._get_token_store()
            count = await store.aremove_by_user(user_sub)
            summary["tokens_revoked"] = count
        except Exception as exc:
            logger.exception(
                "[GLOBAL-LOGOUT] aremove_by_user failed for sub=%s", user_sub
            )
            await emit_audit_event(
                AuditEventType.GLOBAL_LOGOUT_COMPLETED,
                severity=AuditSeverity.WARNING,
                outcome="failure",
                details={
                    "step": "token_store",
                    "error": f"{type(exc).__name__}: {str(exc)[:180]}",
                    "user_sub": user_sub,
                },
            )
            raise

        # Step 2: token cache (async path — no thread-pool blocking)
        try:
            cache = self._get_token_cache()
            await cache.ainvalidate_all_for_user(user_sub)
            summary["cache_swept"] = True
        except Exception as exc:
            logger.exception(
                "[GLOBAL-LOGOUT] ainvalidate_all_for_user failed for sub=%s",
                user_sub,
            )
            await emit_audit_event(
                AuditEventType.GLOBAL_LOGOUT_COMPLETED,
                severity=AuditSeverity.WARNING,
                outcome="failure",
                details={
                    "step": "token_cache",
                    "error": f"{type(exc).__name__}: {str(exc)[:180]}",
                    "user_sub": user_sub,
                    "tokens_revoked": summary["tokens_revoked"],
                },
            )
            raise

        # Step 3: backend MCP sessions (best-effort)
        # 3a — path-based proxy sessions (ProxyHandler / MCPSessionManager).
        try:
            sm = self._get_session_manager()
            backends = await sm.terminate_all_for_user(user_sub)
            summary["backends"] = backends
            summary["sessions_terminated"] = sum(1 for v in backends.values() if v)
            summary["sessions_failed"] = sum(1 for v in backends.values() if not v)
        except Exception:
            logger.exception(
                "[GLOBAL-LOGOUT] terminate_all_for_user raised for sub=%s",
                user_sub,
            )
            # Do not re-raise — the user is already cut off

        # 3b — unified-endpoint sessions (UnifiedMCPHandler). Prior to this
        # the unified handler shared one backend session per resource_url
        # across every user, so there was nothing user-scoped to terminate.
        try:
            uh = self._get_unified_handler()
            if uh is not None and hasattr(uh, "terminate_all_for_user"):
                count = await uh.terminate_all_for_user(user_sub)
                summary["sessions_terminated"] += int(count or 0)
        except Exception:
            logger.exception(
                "[GLOBAL-LOGOUT] unified_handler.terminate_all_for_user raised for sub=%s",
                user_sub,
            )

        # Step 4: relay-tracked access tokens (CIMD + DCR)
        # Without this, relay.lookup_token() keeps short-circuiting auth in
        # UnifiedMCPHandler / ProxyHandler until the TTLCache expires.
        try:
            relay = self._get_relay()
            if relay is not None and hasattr(relay, "arevoke_by_user"):
                summary["relay_tokens_revoked"] = await relay.arevoke_by_user(user_sub)
        except Exception:
            logger.exception(
                "[GLOBAL-LOGOUT] relay.arevoke_by_user raised for sub=%s",
                user_sub,
            )

        # Step 5: mark the sub revoked so Okta-signed JWTs held by MCP clients
        # (VS Code, Cursor, etc.) are rejected at the hot path until they
        # expire naturally.
        try:
            registry = self._get_revocation_registry()
            if registry is not None:
                await registry.revoke(user_sub)
                summary["sub_marked_revoked"] = True
        except Exception:
            logger.exception(
                "[GLOBAL-LOGOUT] revocation registry write failed for sub=%s",
                user_sub,
            )

        # Final outcome event
        await emit_audit_event(
            AuditEventType.GLOBAL_LOGOUT_COMPLETED,
            severity=AuditSeverity.INFO,
            details={
                "user_sub": user_sub,
                "tokens_revoked": summary["tokens_revoked"],
                "cache_swept": summary["cache_swept"],
                "sessions_terminated": summary["sessions_terminated"],
                "sessions_failed": summary["sessions_failed"],
                "backends": summary["backends"],
                "relay_tokens_revoked": summary["relay_tokens_revoked"],
                "sub_marked_revoked": summary["sub_marked_revoked"],
            },
        )

        # Per Okta dev doc: do not 404 on unknown subject (enumeration
        # mitigation). We still record an audit event for ops visibility.
        if (
            summary["tokens_revoked"] == 0
            and summary["sessions_terminated"] == 0
            and summary["relay_tokens_revoked"] == 0
        ):
            await emit_audit_event(
                AuditEventType.GLOBAL_LOGOUT_SUBJECT_NOT_FOUND,
                severity=AuditSeverity.INFO,
                details={"user_sub": user_sub},
            )

        return summary


# ------------------------------------------------------------------
# Singleton accessor
# ------------------------------------------------------------------

_handler: Optional[GlobalLogoutHandler] = None


def get_global_logout_handler() -> GlobalLogoutHandler:
    global _handler
    if _handler is None:
        _handler = GlobalLogoutHandler()
    return _handler


def reset_global_logout_handler() -> None:
    """Test-only."""
    global _handler
    _handler = None
