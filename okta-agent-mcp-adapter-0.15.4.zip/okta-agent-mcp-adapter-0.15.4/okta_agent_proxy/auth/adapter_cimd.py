"""
Adapter CIMD Server — hosts the adapter's own Client Information Metadata
Document (CIMD) and JWKS endpoint.

This allows the adapter to present itself as a CIMD-identifiable OAuth client
when connecting to resource MCP servers that require CIMD-based client
identification.

Endpoints:
  GET /oauth/client-metadata.json  → CIMD document
  GET /oauth/jwks.json             → Public JWKS
  GET /oauth/backend-callback      → Resource OAuth callback (placeholder for P7)

Configuration:
  ADAPTER_CIMD_BASE_URL  — Public URL of the adapter (e.g. https://gateway.example.com)
  ADAPTER_SIGNING_KEY    — JWK private key (JSON string) or path to PEM file.
                           If not set, generates an RSA-2048 key pair at startup.
"""

import json
import logging
import os
import time
import uuid
from typing import Optional

from cryptography.hazmat.primitives.asymmetric import rsa
from cryptography.hazmat.primitives import serialization
from jose import jwt

logger = logging.getLogger(__name__)


def _int_to_base64url(n: int) -> str:
    """Convert a positive integer to a Base64url-encoded string (no padding)."""
    import base64
    byte_length = (n.bit_length() + 7) // 8
    raw = n.to_bytes(byte_length, byteorder="big")
    return base64.urlsafe_b64encode(raw).rstrip(b"=").decode("ascii")


def _generate_rsa_keypair() -> dict:
    """Generate an RSA-2048 key pair and return as a JWK dict with private components."""
    private_key = rsa.generate_private_key(public_exponent=65537, key_size=2048)
    private_numbers = private_key.private_numbers()
    public_numbers = private_numbers.public_numbers

    kid = f"adapter-{uuid.uuid4().hex[:8]}"
    return {
        "kty": "RSA",
        "use": "sig",
        "alg": "RS256",
        "kid": kid,
        "n": _int_to_base64url(public_numbers.n),
        "e": _int_to_base64url(public_numbers.e),
        "d": _int_to_base64url(private_numbers.d),
        "p": _int_to_base64url(private_numbers.p),
        "q": _int_to_base64url(private_numbers.q),
        "dp": _int_to_base64url(private_numbers.dmp1),
        "dq": _int_to_base64url(private_numbers.dmq1),
        "qi": _int_to_base64url(private_numbers.iqmp),
    }


def _load_signing_key(raw: str) -> dict:
    """Load a signing key from a JWK JSON string or PEM file path.

    Returns a JWK dict with private key components.
    """
    raw = raw.strip()

    # If it looks like JSON, parse as JWK
    if raw.startswith("{"):
        jwk = json.loads(raw)
        if "kty" not in jwk:
            raise ValueError("JWK must contain 'kty' field")
        if "kid" not in jwk:
            jwk["kid"] = f"adapter-{uuid.uuid4().hex[:8]}"
        return jwk

    # Otherwise treat as a file path to a PEM
    if os.path.isfile(raw):
        pem_data = open(raw, "rb").read()
        private_key = serialization.load_pem_private_key(pem_data, password=None)
        private_numbers = private_key.private_numbers()
        public_numbers = private_numbers.public_numbers
        kid = f"adapter-{uuid.uuid4().hex[:8]}"
        return {
            "kty": "RSA",
            "use": "sig",
            "alg": "RS256",
            "kid": kid,
            "n": _int_to_base64url(public_numbers.n),
            "e": _int_to_base64url(public_numbers.e),
            "d": _int_to_base64url(private_numbers.d),
            "p": _int_to_base64url(private_numbers.p),
            "q": _int_to_base64url(private_numbers.q),
            "dp": _int_to_base64url(private_numbers.dmp1),
            "dq": _int_to_base64url(private_numbers.dmq1),
            "qi": _int_to_base64url(private_numbers.iqmp),
        }

    raise ValueError(
        f"ADAPTER_SIGNING_KEY must be a JWK JSON string or a path to a PEM file, got: {raw[:40]}..."
    )


class AdapterCIMDServer:
    """Hosts the adapter's CIMD document and JWKS endpoint."""

    def __init__(self, base_url: Optional[str] = None, signing_key_raw: Optional[str] = None):
        self._base_url = (base_url or os.getenv("ADAPTER_CIMD_BASE_URL", "")).rstrip("/")
        if not self._base_url:
            self._base_url = os.getenv("GATEWAY_BASE_URL", "http://localhost:8000").rstrip("/")
            logger.info(
                f"ADAPTER_CIMD_BASE_URL not set, falling back to GATEWAY_BASE_URL: {self._base_url}"
            )

        raw_key = signing_key_raw or os.getenv("ADAPTER_SIGNING_KEY", "")
        if raw_key:
            self._private_jwk = _load_signing_key(raw_key)
            logger.info(f"Adapter signing key loaded (kid={self._private_jwk.get('kid')})")
        else:
            self._private_jwk = _generate_rsa_keypair()
            logger.warning(
                "ADAPTER_SIGNING_KEY not set — generated ephemeral RSA-2048 key pair. "
                "Set ADAPTER_SIGNING_KEY for production use."
            )

    @property
    def client_id(self) -> str:
        """The adapter's CIMD client_id (URL of the metadata document)."""
        return f"{self._base_url}/oauth/client-metadata.json"

    def get_client_metadata(self) -> dict:
        """Return the CIMD JSON document for this adapter."""
        return {
            "client_id": self.client_id,
            "client_name": "Okta MCP Adapter",
            "client_uri": self._base_url,
            "redirect_uris": [f"{self._base_url}/oauth/backend-callback"],
            "grant_types": ["authorization_code", "refresh_token"],
            "response_types": ["code"],
            "token_endpoint_auth_method": "private_key_jwt",
            "jwks_uri": f"{self._base_url}/oauth/jwks.json",
            "scope": "openid profile email offline_access mcp:read mcp:write",
        }

    def get_jwks(self) -> dict:
        """Return the public JWKS (no private key components)."""
        public_fields = {"kty", "use", "alg", "kid", "n", "e"}
        public_key = {k: v for k, v in self._private_jwk.items() if k in public_fields}
        return {"keys": [public_key]}

    def sign_client_assertion(self, audience: str) -> str:
        """Create a client_assertion JWT for private_key_jwt auth at a resource token endpoint.

        Args:
            audience: The resource's token endpoint URL.

        Returns:
            Signed JWT string.
        """
        now = int(time.time())
        claims = {
            "iss": self.client_id,
            "sub": self.client_id,
            "aud": audience,
            "jti": str(uuid.uuid4()),
            "iat": now,
            "exp": now + 300,
        }
        return jwt.encode(
            claims,
            self._private_jwk,
            algorithm="RS256",
            headers={"kid": self._private_jwk.get("kid")},
        )
