"""
Confidential Relay for CIMD clients.

Bridges CIMD clients to Okta by using the per-agent Okta OIDC credentials
stored in the agent's database record. Required because Okta does not
natively support URL-based client_ids.

Each CIMD-matched agent must have client_id and client_secret configured
in its database record. These credentials are passed per-request — there
are no global relay credentials.

Supports two modes:
- Standalone: in-process dicts only (backward compatible, single-pod)
- CacheService: local dicts as L1 + CacheService as L2 backing store

Flow:
1. CIMD client sends authorization request -> relay rewrites with agent's Okta credentials
2. Okta redirects back to gateway callback -> relay exchanges code using session credentials
3. Relay issues a gateway authorization code -> redirects back to CIMD client
4. CIMD client exchanges gateway code for tokens via relay
"""

import base64
import dataclasses
import hashlib
import json
import logging
import os
import secrets
from dataclasses import asdict
from datetime import datetime, timezone
from typing import Any, Dict, Optional
from urllib.parse import urlencode, urlparse

import httpx
from jose import jwt as jose_jwt

from .cimd_fetcher import CIMDMetadata
from .gateway_code_manager import (
    GatewayCodeManager,
    GatewayCodeNotFound,
    GatewayCodeExpired,
    GatewayCodeClientMismatch,
)
from okta_agent_proxy.cache.serializers import (
    serialize_encrypted,
    deserialize_encrypted,
    serialize_json,
    deserialize_json,
)

logger = logging.getLogger(__name__)

# Key prefixes for CacheService entries
_RELAY_STATE_PREFIX = "relay_state:"
_PRECONSENT_STATE_PREFIX = "relay_preconsent:"

# Track whether the unencrypted-Redis warning has been issued
_relay_unencrypted_warning_issued = False


# ---------------------------------------------------------------------------
# Errors
# ---------------------------------------------------------------------------
class RelayError(Exception):
    """Base error for confidential relay operations."""
    pass


class RelaySessionExpired(RelayError):
    """Raised when the relay session has expired."""
    pass


class RelayClientMismatch(RelayError):
    """Raised when client_id doesn't match the session's original client."""
    pass


# ---------------------------------------------------------------------------
# Session dataclass
# ---------------------------------------------------------------------------
@dataclasses.dataclass
class RelaySession:
    original_client_id: str
    original_redirect_uri: str
    original_state: str
    relay_state: str
    code_verifier: Optional[str]
    created_at: datetime
    # Per-agent Okta credentials for this session
    relay_client_id: str = ""
    relay_client_secret: str = ""
    # RFC 8707 Resource Indicator -- the specific protected resource
    # the client is requesting access to. None for multi-resource flows.
    target_resource: Optional[str] = None
    ttl_seconds: int = 300
    # Populated after callback
    access_token: Optional[str] = None
    id_token: Optional[str] = None
    refresh_token: Optional[str] = None
    expires_in: Optional[int] = None
    gateway_code: Optional[str] = None
    # Custom (non-OIDC) scopes the MCP client requested on /oauth/authorize.
    # These are NEVER sent to Okta's org AS (it rejects them) -- the adapter
    # absorbs them here and replays them on Leg 1 of the ID-JAG exchange.
    custom_scopes: list = dataclasses.field(default_factory=list)

    @property
    def is_expired(self) -> bool:
        elapsed = (datetime.now(timezone.utc) - self.created_at).total_seconds()
        return elapsed > self.ttl_seconds

    def to_dict(self) -> dict:
        """Serialize to a JSON-safe dict (datetime -> isoformat)."""
        d = asdict(self)
        d["created_at"] = self.created_at.isoformat()
        return d

    @classmethod
    def from_dict(cls, d: dict) -> "RelaySession":
        """Deserialize from a dict (isoformat -> datetime)."""
        d = dict(d)
        ca = d.get("created_at")
        if isinstance(ca, str):
            d["created_at"] = datetime.fromisoformat(ca)
        return cls(**d)


@dataclasses.dataclass
class PreConsentSession:
    """Session state for a standalone pre-consent flow.

    Unlike RelaySession, this has no 'original client' to return to -- the
    user initiated from a link, not from an MCP client. Tokens obtained
    during the Okta exchange are handed directly to ConsentTransactionStore
    and are not retained here.
    """
    agent_id: str
    relay_state: str
    code_verifier: str
    created_at: datetime
    relay_client_id: str
    relay_client_secret: str
    scopes: str  # space-delimited, as sent to Okta
    target_resource: Optional[str] = None
    ttl_seconds: int = 300

    @property
    def is_expired(self) -> bool:
        elapsed = (datetime.now(timezone.utc) - self.created_at).total_seconds()
        return elapsed > self.ttl_seconds

    def to_dict(self) -> dict:
        d = asdict(self)
        d["created_at"] = self.created_at.isoformat()
        return d

    @classmethod
    def from_dict(cls, d: dict) -> "PreConsentSession":
        d = dict(d)
        ca = d.get("created_at")
        if isinstance(ca, str):
            d["created_at"] = datetime.fromisoformat(ca)
        return cls(**d)


# ---------------------------------------------------------------------------
# ConfidentialRelay
# ---------------------------------------------------------------------------
class ConfidentialRelay:
    """Bridges CIMD clients to Okta using a relay OIDC application."""

    def __init__(
        self,
        gateway_base_url: Optional[str] = None,
        okta_domain: Optional[str] = None,
        okta_auth_server_id: Optional[str] = None,
        transport: Optional[httpx.AsyncBaseTransport] = None,
        cache_service=None,
        encryption_service=None,
        event_bus=None,
    ):
        self._gateway_base_url = (
            gateway_base_url or os.getenv("GATEWAY_BASE_URL", "http://localhost:8000")
        ).rstrip("/")
        self._okta_domain = okta_domain or os.getenv("OKTA_DOMAIN", "")
        # For ID-JAG/XAA to work, the relay MUST use the ORG auth server
        # so the id_token issuer matches what Okta's org-level token endpoint
        # expects during ID-JAG exchange. Defaults to "org".
        self._auth_server_id = okta_auth_server_id or os.getenv(
            "RELAY_OKTA_AUTH_SERVER_ID", "org"
        )
        self._use_org_auth_server = self._auth_server_id.lower() == "org"
        self._transport = transport

        self._cache_service = cache_service
        self._encryption_service = encryption_service
        self._event_bus = event_bus

        # Default TTL for relay state in L2 (env-configurable)
        self._relay_state_ttl = int(os.getenv("RELAY_STATE_TTL", "600"))

        # In-memory session store keyed by relay_state (L1)
        self._sessions_by_state: dict[str, RelaySession] = {}
        # Parallel store for standalone pre-consent flows (L1)
        self._preconsent_sessions_by_state: dict[str, PreConsentSession] = {}
        # Delegate gateway code + token tracking to GatewayCodeManager
        self._code_manager = GatewayCodeManager(
            cache_service=cache_service,
            encryption_service=encryption_service,
        )

    # ------------------------------------------------------------------
    # Serialization helpers
    # ------------------------------------------------------------------

    def _serialize(self, data: dict) -> str:
        if self._encryption_service:
            return serialize_encrypted(data, self._encryption_service)
        return serialize_json(data)

    def _deserialize(self, raw: str) -> dict:
        if self._encryption_service:
            return deserialize_encrypted(raw, self._encryption_service)
        return deserialize_json(raw)

    def _warn_unencrypted_redis(self):
        global _relay_unencrypted_warning_issued
        if _relay_unencrypted_warning_issued:
            return
        if not self._cache_service or self._encryption_service:
            return
        try:
            from okta_agent_proxy.cache.redis_provider import RedisCacheProvider
            if isinstance(self._cache_service.l2, RedisCacheProvider):
                logger.warning(
                    "ConfidentialRelay: writing relay state to Redis WITHOUT "
                    "encryption — relay_client_secret will be in plaintext. "
                    "Set ENCRYPTION_KEY to fix"
                )
                _relay_unencrypted_warning_issued = True
        except ImportError:
            pass

    # ------------------------------------------------------------------
    # Async state helpers (L1 + L2)
    # ------------------------------------------------------------------

    async def _store_relay_state(self, state: str, session: RelaySession) -> None:
        """Write relay session to L1 dict AND L2 CacheService."""
        self._sessions_by_state[state] = session
        if self._cache_service:
            self._warn_unencrypted_redis()
            try:
                payload = self._serialize(session.to_dict())
                await self._cache_service.set(
                    f"{_RELAY_STATE_PREFIX}{state}", payload,
                    ttl_seconds=self._relay_state_ttl,
                )
            except Exception as e:
                logger.warning(f"Relay: L2 state write failed, L1-only: {e}")

    async def _load_relay_state(self, state: str) -> Optional[RelaySession]:
        """Load relay session from L1, falling through to L2."""
        session = self._sessions_by_state.get(state)
        if session is not None:
            return session

        if self._cache_service:
            try:
                raw = await self._cache_service.get(f"{_RELAY_STATE_PREFIX}{state}")
                if raw is not None:
                    session = RelaySession.from_dict(self._deserialize(raw))
                    # Promote to L1
                    self._sessions_by_state[state] = session
                    return session
            except Exception as e:
                logger.warning(f"Relay: L2 state lookup failed: {e}")

        return None

    async def _delete_relay_state(self, state: str) -> None:
        """Delete relay session from L1 and L2."""
        self._sessions_by_state.pop(state, None)
        if self._cache_service:
            try:
                await self._cache_service.delete(f"{_RELAY_STATE_PREFIX}{state}")
            except Exception as e:
                logger.warning(f"Relay: L2 state delete failed: {e}")
        if self._event_bus:
            try:
                from okta_agent_proxy.cache.pubsub import CHANNEL_RELAY_SESSION_INVALIDATE
                await self._event_bus.publish(
                    CHANNEL_RELAY_SESSION_INVALIDATE,
                    json.dumps({"v": 1, "key": state}),
                )
            except Exception as e:
                logger.warning(f"Relay: pub/sub publish failed: {e}")

    async def _store_preconsent_state(self, state: str, session: PreConsentSession) -> None:
        self._preconsent_sessions_by_state[state] = session
        if self._cache_service:
            self._warn_unencrypted_redis()
            try:
                payload = self._serialize(session.to_dict())
                await self._cache_service.set(
                    f"{_PRECONSENT_STATE_PREFIX}{state}", payload,
                    ttl_seconds=self._relay_state_ttl,
                )
            except Exception as e:
                logger.warning(f"Relay: L2 preconsent write failed, L1-only: {e}")

    async def _load_preconsent_state(self, state: str) -> Optional[PreConsentSession]:
        session = self._preconsent_sessions_by_state.get(state)
        if session is not None:
            return session

        if self._cache_service:
            try:
                raw = await self._cache_service.get(f"{_PRECONSENT_STATE_PREFIX}{state}")
                if raw is not None:
                    session = PreConsentSession.from_dict(self._deserialize(raw))
                    self._preconsent_sessions_by_state[state] = session
                    return session
            except Exception as e:
                logger.warning(f"Relay: L2 preconsent lookup failed: {e}")

        return None

    async def _delete_preconsent_state(self, state: str) -> None:
        self._preconsent_sessions_by_state.pop(state, None)
        if self._cache_service:
            try:
                await self._cache_service.delete(f"{_PRECONSENT_STATE_PREFIX}{state}")
            except Exception as e:
                logger.warning(f"Relay: L2 preconsent delete failed: {e}")
        if self._event_bus:
            try:
                from okta_agent_proxy.cache.pubsub import CHANNEL_RELAY_SESSION_INVALIDATE
                await self._event_bus.publish(
                    CHANNEL_RELAY_SESSION_INVALIDATE,
                    json.dumps({"v": 1, "key": state}),
                )
            except Exception as e:
                logger.warning(f"Relay: pub/sub publish failed: {e}")

    # ------------------------------------------------------------------
    # Backward-compat properties
    # ------------------------------------------------------------------

    @property
    def _sessions_by_code(self) -> dict:
        """Backward-compatible access to the code manager's code store."""
        return self._code_manager._sessions_by_code

    @property
    def _sessions_by_token(self):
        """Backward-compatible access to the code manager's token store."""
        return self._code_manager._sessions_by_token

    @property
    def _authorize_url(self) -> str:
        if self._use_org_auth_server:
            return f"https://{self._okta_domain}/oauth2/v1/authorize"
        return f"https://{self._okta_domain}/oauth2/{self._auth_server_id}/v1/authorize"

    @property
    def _token_url(self) -> str:
        if self._use_org_auth_server:
            return f"https://{self._okta_domain}/oauth2/v1/token"
        return f"https://{self._okta_domain}/oauth2/{self._auth_server_id}/v1/token"

    @property
    def _callback_url(self) -> str:
        return f"{self._gateway_base_url}/oauth/callback"

    def is_preconsent_state(self, state: str) -> bool:
        """Return True if the given state belongs to a standalone pre-consent session.

        Used by /oauth/callback to dispatch to the pre-consent handler instead of
        the normal CIMD relay handler. Checks L1 only (sync).
        """
        return state in self._preconsent_sessions_by_state

    async def ais_preconsent_state(self, state: str) -> bool:
        """Async variant: checks L1 then L2 for pre-consent state."""
        if state in self._preconsent_sessions_by_state:
            return True
        if self._cache_service:
            try:
                return await self._cache_service.exists(
                    f"{_PRECONSENT_STATE_PREFIX}{state}"
                )
            except Exception:
                pass
        return False

    # -- Helpers -------------------------------------------------------------

    @staticmethod
    def _redirect_uri_allowed(redirect_uri: str, registered_uris: list[str]) -> bool:
        """Check if redirect_uri is allowed per the registered list.

        Implements RFC 8252 Section 7.3: for loopback redirects (127.0.0.1,
        localhost, [::1]), the port is ignored during matching. This allows
        native clients like VS Code that use dynamic ports.
        """
        # Exact match first
        if redirect_uri in registered_uris:
            return True

        # RFC 8252 loopback matching -- ignore port
        parsed = urlparse(redirect_uri)
        hostname = parsed.hostname or ""
        if hostname in ("127.0.0.1", "localhost", "::1"):
            for registered in registered_uris:
                reg_parsed = urlparse(registered)
                reg_hostname = reg_parsed.hostname or ""
                if reg_hostname in ("127.0.0.1", "localhost", "::1"):
                    # Match scheme, hostname, and path -- ignore port
                    if (parsed.scheme == reg_parsed.scheme
                            and parsed.path == reg_parsed.path):
                        return True

        return False

    # -- Authorization -------------------------------------------------------

    async def start_authorization(
        self,
        cimd_metadata: CIMDMetadata,
        auth_params: dict,
        relay_client_id: str = "",
        relay_client_secret: str = "",
        custom_scopes: Optional[list] = None,
    ) -> str:
        """Start the relay authorization flow.

        Args:
            cimd_metadata: Validated CIMD document for the client.
            auth_params: Original authorization request parameters:
                redirect_uri, state, code_verifier, code_challenge,
                code_challenge_method, scope.
            relay_client_id: The agent's Okta client_id for this session.
            relay_client_secret: The agent's Okta client_secret for this session.

        Returns:
            The Okta authorization URL to redirect the user to.

        Raises:
            RelayError: If redirect_uri is not in the CIMD metadata.
            RelayError: If relay_client_id is empty.
        """
        if not relay_client_id:
            raise RelayError(
                "No relay credentials: agent must have client_id and client_secret "
                "configured in the database"
            )
        redirect_uri = auth_params.get("redirect_uri", "")
        if not self._redirect_uri_allowed(redirect_uri, cimd_metadata.redirect_uris):
            raise RelayError(
                f"redirect_uri '{redirect_uri}' is not in the client's registered redirect_uris"
            )

        relay_state = secrets.token_urlsafe(32)

        # Always generate relay-side PKCE for the relay-to-Okta leg.
        relay_verifier = secrets.token_urlsafe(64)
        digest = hashlib.sha256(relay_verifier.encode("ascii")).digest()
        relay_challenge = base64.urlsafe_b64encode(digest).rstrip(b"=").decode("ascii")

        session = RelaySession(
            original_client_id=cimd_metadata.client_id,
            original_redirect_uri=redirect_uri,
            original_state=auth_params.get("state", ""),
            relay_state=relay_state,
            code_verifier=relay_verifier,
            created_at=datetime.now(timezone.utc),
            relay_client_id=relay_client_id,
            relay_client_secret=relay_client_secret,
            target_resource=auth_params.get("resource") or None,
            custom_scopes=list(custom_scopes or []),
        )
        await self._store_relay_state(relay_state, session)

        # Build Okta authorization URL with agent's Okta credentials and relay PKCE
        params = {
            "client_id": relay_client_id,
            "redirect_uri": self._callback_url,
            "response_type": "code",
            "state": relay_state,
            "scope": auth_params.get("scope", "openid"),
            "code_challenge": relay_challenge,
            "code_challenge_method": "S256",
        }

        okta_url = f"{self._authorize_url}?{urlencode(params)}"
        logger.info(
            f"Relay: started authorization for {cimd_metadata.domain} "
            f"(relay_state={relay_state[:8]}...)"
        )
        return okta_url

    # -- Okta code exchange (shared) -----------------------------------------

    async def _exchange_okta_code(
        self, relay_state: str, authorization_code: str
    ) -> tuple[RelaySession, dict]:
        """Exchange an Okta authorization code for tokens.

        Shared logic used by both handle_callback and handle_callback_tokens_only.
        """
        session = await self._load_relay_state(relay_state)
        if session is None:
            raise RelayError(f"No relay session found for state={relay_state[:8]}...")

        if session.is_expired:
            await self._delete_relay_state(relay_state)
            raise RelaySessionExpired("Relay session has expired")

        # Exchange auth code at Okta token endpoint using session's agent credentials
        credentials = base64.b64encode(
            f"{session.relay_client_id}:{session.relay_client_secret}".encode()
        ).decode()

        token_data = {
            "grant_type": "authorization_code",
            "code": authorization_code,
            "redirect_uri": self._callback_url,
        }

        # Pass through PKCE verifier if present
        if session.code_verifier:
            token_data["code_verifier"] = session.code_verifier

        client_kwargs: dict = {}
        if self._transport is not None:
            client_kwargs["transport"] = self._transport

        async with httpx.AsyncClient(**client_kwargs) as client:
            response = await client.post(
                self._token_url,
                data=token_data,
                headers={
                    "Authorization": f"Basic {credentials}",
                    "Content-Type": "application/x-www-form-urlencoded",
                },
            )

        if response.status_code != 200:
            raise RelayError(
                f"Token exchange failed: HTTP {response.status_code} — {response.text}"
            )

        tokens = response.json()
        logger.info(
            f"Relay: Okta token response: expires_in={tokens.get('expires_in')}, "
            f"has_refresh={bool(tokens.get('refresh_token'))}, "
            f"has_id_token={bool(tokens.get('id_token'))}"
        )

        # Store tokens in session
        session.access_token = tokens.get("access_token")
        session.id_token = tokens.get("id_token")
        session.refresh_token = tokens.get("refresh_token")
        session.expires_in = tokens.get("expires_in")

        # Clean up state index (no longer needed)
        await self._delete_relay_state(relay_state)

        return session, tokens

    # -- Callback ------------------------------------------------------------

    async def handle_callback(
        self, relay_state: str, authorization_code: str
    ) -> tuple[str, str, str]:
        """Handle the Okta callback and exchange the authorization code.

        Returns:
            Tuple of (redirect_url, gateway_code, original_client_id).
        """
        session, _tokens = await self._exchange_okta_code(relay_state, authorization_code)

        # Issue gateway code via the code manager (async)
        gateway_code = await self._code_manager.aissue_code(
            client_id=session.original_client_id,
            tokens={
                "access_token": session.access_token,
                "id_token": session.id_token,
                "refresh_token": session.refresh_token,
                "expires_in": session.expires_in,
            },
            extra={
                "relay_client_id": session.relay_client_id,
                "relay_client_secret": session.relay_client_secret,
            },
        )
        session.gateway_code = gateway_code

        # Build redirect back to original client
        redirect_params = {"code": gateway_code, "state": session.original_state}
        redirect_url = f"{session.original_redirect_uri}?{urlencode(redirect_params)}"

        logger.info(
            f"Relay: callback handled for {session.original_client_id}, "
            f"issuing gateway code {gateway_code[:8]}..."
        )

        return redirect_url, gateway_code, session.original_client_id

    async def handle_callback_tokens_only(
        self, relay_state: str, authorization_code: str
    ) -> dict:
        """Exchange Okta code for tokens WITHOUT issuing a gateway code.

        Used by the consent interstitial flow, which needs the tokens
        for STS verification but defers gateway code issuance until
        all consents are verified.
        """
        session, _tokens = await self._exchange_okta_code(relay_state, authorization_code)

        return {
            "access_token": session.access_token,
            "id_token": session.id_token,
            "refresh_token": session.refresh_token,
            "expires_in": session.expires_in,
            "original_client_id": session.original_client_id,
            "original_redirect_uri": session.original_redirect_uri,
            "original_state": session.original_state,
            "relay_client_id": session.relay_client_id,
            "relay_client_secret": session.relay_client_secret,
            "target_resource": session.target_resource,
            "custom_scopes": list(session.custom_scopes or []),
        }

    # -- Code Exchange -------------------------------------------------------

    async def exchange_code(self, gateway_code: str, client_id: str) -> dict:
        """Exchange a gateway-issued code for tokens.

        Delegates to GatewayCodeManager's async API for cross-pod support.
        """
        try:
            return await self._code_manager.aexchange_code(gateway_code, client_id)
        except GatewayCodeNotFound:
            raise RelayError("No session found for gateway code")
        except GatewayCodeExpired:
            raise RelaySessionExpired("Relay session has expired")
        except GatewayCodeClientMismatch as e:
            raise RelayClientMismatch(str(e))

    def lookup_token(self, access_token: str) -> Optional[Dict[str, Any]]:
        """Look up identity info for a previously issued CIMD access token.

        Returns a dict with client_id, user_id, email, and custom_scopes
        extracted from the stored session, or None if the token is not tracked.

        Note: sync L1-only. For cross-pod lookup, use alookup_token.
        """
        info = self._code_manager.lookup_token(access_token)
        if info is None:
            return None

        result: Dict[str, Any] = {
            "client_id": info["client_id"],
            "custom_scopes": list(info.get("custom_scopes") or []),
        }

        # Decode the id_token (without verification -- it was already validated
        # when received from Okta) to extract user identity claims.
        id_token = info.get("id_token")
        if id_token:
            try:
                claims = jose_jwt.get_unverified_claims(id_token)
                result["user_id"] = claims.get("sub", "")
                result["email"] = claims.get("email", "")
                result["name"] = claims.get("name", "")
            except Exception as exc:
                logger.debug("Failed to decode id_token for CIMD lookup: %s", exc)

        return result

    async def alookup_token(self, access_token: str) -> Optional[Dict[str, Any]]:
        """Async lookup: checks L1 then L2 via GatewayCodeManager."""
        info = await self._code_manager.alookup_token(access_token)
        if info is None:
            return None

        result: Dict[str, Any] = {
            "client_id": info["client_id"],
            "custom_scopes": list(info.get("custom_scopes") or []),
        }

        id_token = info.get("id_token")
        if id_token:
            try:
                claims = jose_jwt.get_unverified_claims(id_token)
                result["user_id"] = claims.get("sub", "")
                result["email"] = claims.get("email", "")
                result["name"] = claims.get("name", "")
            except Exception as exc:
                logger.debug("Failed to decode id_token for CIMD lookup: %s", exc)

        return result

    def track_token(self, access_token: str, client_id: str, **kwargs) -> None:
        """Track a newly issued access token for a CIMD client (sync, L1 only)."""
        self._code_manager.track_token(access_token, client_id, **kwargs)

    async def atrack_token(self, access_token: str, client_id: str, **kwargs) -> None:
        """Track a newly issued access token (async, L1+L2)."""
        await self._code_manager.atrack_token(access_token, client_id, **kwargs)

    async def arevoke_by_user(self, user_sub: str) -> int:
        """Drop every relay-tracked access token (CIMD + DCR) for this user."""
        return await self._code_manager.arevoke_by_user(user_sub)

    async def refresh_token(
        self,
        refresh_token: str,
        client_id: str,
        scope: str = "",
        relay_client_id: str = "",
        relay_client_secret: str = "",
    ) -> dict:
        """Refresh tokens for a CIMD client using the agent's credentials."""
        # Resolve credentials + any previously stashed custom_scopes for this
        # client so they survive the refresh cycle. Cache miss falls through
        # gracefully: the proxy-time recovery will then fall back to
        # connection.scopes via apply_scope_condition.
        prior_custom_scopes: list = []
        if not relay_client_id:
            for _tok, info in self._sessions_by_token.items():
                if info.get("client_id") == client_id and info.get("relay_client_id"):
                    relay_client_id = info["relay_client_id"]
                    relay_client_secret = info.get("relay_client_secret", "")
                    prior_custom_scopes = list(info.get("custom_scopes") or [])
                    break
        else:
            # Credentials supplied explicitly -- still try to recover scopes.
            for _tok, info in self._sessions_by_token.items():
                if info.get("client_id") == client_id:
                    prior_custom_scopes = list(info.get("custom_scopes") or [])
                    break

        if not relay_client_id:
            raise RelayError(
                "No relay credentials available for token refresh: agent must have "
                "client_id and client_secret configured in the database"
            )

        credentials = base64.b64encode(
            f"{relay_client_id}:{relay_client_secret}".encode()
        ).decode()

        token_data = {
            "grant_type": "refresh_token",
            "refresh_token": refresh_token,
        }
        if scope:
            token_data["scope"] = scope

        client_kwargs: dict = {}
        if self._transport is not None:
            client_kwargs["transport"] = self._transport

        async with httpx.AsyncClient(**client_kwargs) as client:
            response = await client.post(
                self._token_url,
                data=token_data,
                headers={
                    "Authorization": f"Basic {credentials}",
                    "Content-Type": "application/x-www-form-urlencoded",
                },
            )

        if response.status_code != 200:
            raise RelayError(
                f"Token refresh failed: HTTP {response.status_code} — {response.text}"
            )

        tokens = response.json()

        # Track the new access token with full token set and credentials.
        # Forward any previously stashed custom_scopes so the scope binding
        # survives across refresh (best-effort -- cache miss falls through
        # to apply_scope_condition's connection.scopes default).
        new_access_token = tokens.get("access_token")
        if new_access_token:
            await self._code_manager.atrack_token(
                new_access_token,
                client_id,
                id_token=tokens.get("id_token"),
                refresh_token=tokens.get("refresh_token"),
                expires_in=tokens.get("expires_in"),
                relay_client_id=relay_client_id,
                relay_client_secret=relay_client_secret,
                custom_scopes=prior_custom_scopes,
            )

        result = {
            "access_token": new_access_token,
            "token_type": "Bearer",
        }
        if tokens.get("id_token"):
            result["id_token"] = tokens["id_token"]
        if tokens.get("refresh_token"):
            result["refresh_token"] = tokens["refresh_token"]
        if tokens.get("expires_in"):
            result["expires_in"] = tokens["expires_in"]

        logger.info(f"Relay: refreshed token for {client_id}")
        return result

    # -- Pre-consent flows ---------------------------------------------------

    async def start_preconsent_authorization(
        self,
        agent_id: str,
        relay_client_id: str,
        relay_client_secret: str,
        scopes: str,
        target_resource: Optional[str] = None,
    ) -> str:
        """Start a standalone pre-consent authorization flow."""
        if not relay_client_id:
            raise RelayError(
                "No relay credentials: agent must have client_id and client_secret "
                "configured in the database"
            )

        relay_state = secrets.token_urlsafe(32)

        # PKCE for the relay-to-Okta leg
        relay_verifier = secrets.token_urlsafe(64)
        digest = hashlib.sha256(relay_verifier.encode("ascii")).digest()
        relay_challenge = base64.urlsafe_b64encode(digest).rstrip(b"=").decode("ascii")

        session = PreConsentSession(
            agent_id=agent_id,
            relay_state=relay_state,
            code_verifier=relay_verifier,
            created_at=datetime.now(timezone.utc),
            relay_client_id=relay_client_id,
            relay_client_secret=relay_client_secret,
            scopes=scopes,
            target_resource=target_resource,
        )
        await self._store_preconsent_state(relay_state, session)

        params = {
            "client_id": relay_client_id,
            "redirect_uri": self._callback_url,
            "response_type": "code",
            "state": relay_state,
            "scope": scopes,
            "code_challenge": relay_challenge,
            "code_challenge_method": "S256",
        }

        okta_url = f"{self._authorize_url}?{urlencode(params)}"
        logger.info(
            f"Relay: started pre-consent authorization for agent_id={agent_id} "
            f"(relay_state={relay_state[:8]}...)"
        )
        return okta_url

    async def handle_preconsent_callback(
        self, relay_state: str, authorization_code: str
    ) -> dict:
        """Exchange an Okta authorization code from a pre-consent flow."""
        session = await self._load_preconsent_state(relay_state)
        if not session:
            raise RelayError(
                f"No pre-consent session found for state={relay_state[:8]}..."
            )

        if session.is_expired:
            await self._delete_preconsent_state(relay_state)
            raise RelayError(
                f"Pre-consent session expired for state={relay_state[:8]}..."
            )

        # Exchange the code for tokens against Okta.
        basic = base64.b64encode(
            f"{session.relay_client_id}:{session.relay_client_secret}".encode()
        ).decode()

        data = {
            "grant_type": "authorization_code",
            "code": authorization_code,
            "redirect_uri": self._callback_url,
            "code_verifier": session.code_verifier,
        }

        async with httpx.AsyncClient(transport=self._transport) as client:
            resp = await client.post(
                self._token_url,
                data=data,
                headers={
                    "Authorization": f"Basic {basic}",
                    "Content-Type": "application/x-www-form-urlencoded",
                },
                timeout=30.0,
            )

        if resp.status_code != 200:
            # Clean up the session on failure
            await self._delete_preconsent_state(relay_state)
            raise RelayError(
                f"Pre-consent token exchange failed: {resp.status_code} {resp.text}"
            )

        tokens = resp.json()
        id_token = tokens.get("id_token")
        if not id_token:
            await self._delete_preconsent_state(relay_state)
            raise RelayError("Pre-consent token exchange returned no id_token")

        result = {
            "id_token": id_token,
            "agent_id": session.agent_id,
            "target_resource": session.target_resource,
        }

        # Clean up the session -- we have everything we need
        await self._delete_preconsent_state(relay_state)

        logger.info(
            f"Relay: pre-consent exchange complete for agent_id={session.agent_id} "
            f"(relay_state={relay_state[:8]}...)"
        )
        return result
