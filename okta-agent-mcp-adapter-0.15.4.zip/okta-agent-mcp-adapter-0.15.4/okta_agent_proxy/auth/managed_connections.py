"""
DEPRECATED — replaced by okta_agent_proxy.resource_map.syncer.OktaConnectionSyncer.

This module is kept as a stub so existing imports do not break.
The ManagedConnectionsSync class is a no-op that logs a deprecation warning.
"""

import logging
import warnings
from datetime import datetime
from typing import Any, Dict, List, Optional

logger = logging.getLogger(__name__)

_DEPRECATION_MSG = (
    "ManagedConnectionsSync is deprecated. "
    "Use okta_agent_proxy.resource_map.syncer.OktaConnectionSyncer instead."
)


class ManagedConnectionsSyncResult:
    """Deprecated result container — kept for backward compatibility."""

    def __init__(self, **kwargs):
        self.authorization_servers: List[Dict[str, Any]] = kwargs.get("authorization_servers", [])
        self.secrets: List[Dict[str, Any]] = kwargs.get("secrets", [])
        self.service_accounts: List[Dict[str, Any]] = kwargs.get("service_accounts", [])
        self.synced_at: datetime = kwargs.get("synced_at", datetime.utcnow())


class ManagedConnectionsSync:
    """
    DEPRECATED — replaced by OktaConnectionSyncer.

    All methods are no-ops that return empty results.
    """

    def __init__(self, store=None, cache_service=None):
        warnings.warn(_DEPRECATION_MSG, DeprecationWarning, stacklevel=2)
        logger.warning(_DEPRECATION_MSG)

    async def sync(self) -> ManagedConnectionsSyncResult:
        return ManagedConnectionsSyncResult(synced_at=datetime.utcnow())

    def get_managed_scopes(self, resource_name: str) -> Optional[List[str]]:
        return None
