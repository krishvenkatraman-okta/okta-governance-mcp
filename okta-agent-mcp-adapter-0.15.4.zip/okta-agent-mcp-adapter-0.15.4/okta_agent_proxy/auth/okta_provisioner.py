"""
Okta Client Provisioner.

Creates and deletes OIDC applications via the Okta Management API
(/oauth2/v1/clients endpoint) for Dynamic Client Registration.
"""

import dataclasses
import logging
import os
import time
from typing import Optional

import httpx

logger = logging.getLogger(__name__)


class OktaProvisionerError(Exception):
    """Base error for Okta provisioner operations."""
    pass


class OktaProvisionerAuthError(OktaProvisionerError):
    """Raised when the Okta API returns 401 (bad token)."""
    pass


class OktaProvisionerForbiddenError(OktaProvisionerError):
    """Raised when the Okta API returns 403 (insufficient scope)."""
    pass


class OktaProvisionerRateLimitError(OktaProvisionerError):
    """Raised when the Okta API returns 429 (rate limit)."""
    pass


class OktaProvisionerValidationError(OktaProvisionerError):
    """Raised when the Okta API returns 400 (validation error)."""
    pass


@dataclasses.dataclass
class OktaAppResult:
    """Result of creating an OIDC application in Okta."""
    client_id: str
    client_secret: str
    client_id_issued_at: int
    client_secret_expires_at: int  # 0 = never
    okta_app_id: str


class OktaClientProvisioner:
    """Creates and deletes OIDC applications via the Okta Management API."""

    def __init__(
        self,
        *,
        okta_domain: Optional[str] = None,
        api_token: Optional[str] = None,
        transport: Optional[httpx.AsyncBaseTransport] = None,
    ):
        self._okta_domain = okta_domain or os.getenv("OKTA_DOMAIN", "")
        self._api_token = api_token or os.getenv("OKTA_API_TOKEN", "")
        self._transport = transport

    @property
    def _clients_url(self) -> str:
        return f"https://{self._okta_domain}/oauth2/v1/clients"

    def _headers(self) -> dict:
        return {
            "Authorization": f"SSWS {self._api_token}",
            "Content-Type": "application/json",
            "Accept": "application/json",
        }

    def _client_kwargs(self) -> dict:
        kwargs: dict = {}
        if self._transport is not None:
            kwargs["transport"] = self._transport
        return kwargs

    def _handle_error(self, response: httpx.Response, operation: str):
        """Raise appropriate error based on HTTP status code."""
        status = response.status_code
        try:
            detail = response.json()
        except Exception:
            detail = response.text

        if status == 400:
            raise OktaProvisionerValidationError(
                f"Okta {operation} validation error: {detail}"
            )
        elif status == 401:
            raise OktaProvisionerAuthError(
                f"Okta {operation} auth error (invalid SSWS token): {detail}"
            )
        elif status == 403:
            raise OktaProvisionerForbiddenError(
                f"Okta {operation} forbidden (insufficient scope): {detail}"
            )
        elif status == 429:
            raise OktaProvisionerRateLimitError(
                f"Okta {operation} rate limited: {detail}"
            )
        else:
            raise OktaProvisionerError(
                f"Okta {operation} failed: HTTP {status} — {detail}"
            )

    async def create_oidc_app(self, sanitized_body: dict) -> OktaAppResult:
        """Create an OIDC application in Okta via the Management API.

        Args:
            sanitized_body: Validated registration request from DCRPolicy.

        Returns:
            OktaAppResult with the new app's credentials.

        Raises:
            OktaProvisionerError: On any Okta API error.
        """
        # Build the Okta /oauth2/v1/clients request body
        okta_body = {
            "client_name": sanitized_body["client_name"],
            "application_type": sanitized_body.get("application_type", "web"),
            "redirect_uris": sanitized_body["redirect_uris"],
            "response_types": sanitized_body.get("response_types", ["code"]),
            "grant_types": sanitized_body.get("grant_types", ["authorization_code", "refresh_token"]),
            "token_endpoint_auth_method": sanitized_body.get(
                "token_endpoint_auth_method", "client_secret_basic"
            ),
            # CRITICAL: Apps created via /oauth2/v1/clients default to
            # consent_method=REQUIRED which forces a consent screen on every
            # login. TRUSTED skips the consent screen for first-party apps.
            "consent_method": "TRUSTED",
        }

        async with httpx.AsyncClient(**self._client_kwargs()) as client:
            response = await client.post(
                self._clients_url,
                json=okta_body,
                headers=self._headers(),
            )

        if response.status_code not in (200, 201):
            self._handle_error(response, "create_oidc_app")

        data = response.json()

        result = OktaAppResult(
            client_id=data["client_id"],
            client_secret=data.get("client_secret", ""),
            client_id_issued_at=data.get("client_id_issued_at", int(time.time())),
            client_secret_expires_at=data.get("client_secret_expires_at", 0),
            okta_app_id=data.get("client_id"),  # /oauth2/v1/clients uses client_id as ID
        )

        logger.info(
            f"Okta provisioner: created OIDC app '{sanitized_body['client_name']}' "
            f"(client_id={result.client_id})"
        )
        return result

    async def delete_oidc_app(self, client_id: str) -> bool:
        """Delete an OIDC application from Okta.

        Args:
            client_id: The client_id of the app to delete.

        Returns:
            True if deleted successfully.

        Raises:
            OktaProvisionerError: On any Okta API error.
        """
        url = f"{self._clients_url}/{client_id}"

        async with httpx.AsyncClient(**self._client_kwargs()) as client:
            response = await client.delete(url, headers=self._headers())

        if response.status_code in (200, 204):
            logger.info(f"Okta provisioner: deleted OIDC app {client_id}")
            return True

        self._handle_error(response, "delete_oidc_app")
        return False  # unreachable, but satisfies type checker
