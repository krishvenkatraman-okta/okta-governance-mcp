"""
Okta AI Agent Management API Client

Provides async methods for interacting with Okta's AI Agent APIs:
- List / get AI agents
- Retrieve agent credentials (JWKS) and connections
- Connection CRUD (create, get, update, delete, activate, deactivate)
- Potential connections discovery
- Public key management
- Agent lifecycle (register, activate, deactivate, delete)
- Look up linked OIDC apps
- Org info and token scope verification

Supports two authentication modes:
1. Admin-initiated: forwards the admin's own Okta access token (OAuth for Okta scopes)
2. Event-triggered: acquires a service app token via private_key_jwt (OktaServiceAuth)

IMPORTANT: Never use httpx auth= parameter for Okta token requests.
Always pass Authorization headers directly.
"""

import asyncio
import logging
import os
from typing import Dict, List, Optional

import httpx

from okta_agent_proxy.auth.okta_service_auth import OktaServiceAuth

logger = logging.getLogger(__name__)

_REQUEST_TIMEOUT = 15


class OktaAIAgentClient:
    """Client for Okta AI Agent Management APIs."""

    def __init__(self, service_auth: Optional[OktaServiceAuth] = None):
        self._service_auth = service_auth or OktaServiceAuth()
        domain = os.getenv("OKTA_DOMAIN", "").strip()
        if domain and not domain.startswith("http"):
            self._base_url = f"https://{domain}"
        else:
            self._base_url = domain.rstrip("/") if domain else ""

    async def _get_auth_headers(self, okta_token: Optional[str] = None) -> dict:
        """Build auth headers.

        - If okta_token provided: Bearer {okta_token} (admin-initiated)
        - Otherwise: service app token via private_key_jwt (event-triggered)
        """
        headers: Dict[str, str] = {
            "Accept": "application/json",
            "Content-Type": "application/json",
        }

        if okta_token:
            headers["Authorization"] = f"Bearer {okta_token}"
        else:
            token = await self._service_auth.get_access_token()
            if token:
                headers["Authorization"] = f"Bearer {token}"
            else:
                logger.warning("No auth available for Okta API call")

        agent_id = os.getenv("OKTA_AI_AGENT_ID", "")
        if agent_id:
            headers["X-Okta-Agent-Id"] = agent_id

        return headers

    # ------------------------------------------------------------------
    # AI Agent endpoints
    # ------------------------------------------------------------------

    async def list_agents(self, okta_token: Optional[str] = None) -> List[dict]:
        """List all AI agents, following Link-header pagination.

        GET {base_url}/workload-principals/api/v1/ai-agents
        """
        if not self._base_url:
            logger.warning("OKTA_DOMAIN not configured, cannot list agents")
            return []

        headers = await self._get_auth_headers(okta_token)
        agents: List[dict] = []
        url = f"{self._base_url}/workload-principals/api/v1/ai-agents"

        try:
            async with httpx.AsyncClient(timeout=_REQUEST_TIMEOUT) as client:
                while url:
                    response = await client.get(url, headers=headers)
                    if response.status_code != 200:
                        logger.warning(
                            f"list_agents failed: {response.status_code} {response.text}"
                        )
                        break

                    data = response.json()
                    if isinstance(data, list):
                        agents.extend(data)
                    elif isinstance(data, dict):
                        # Okta wraps results in {"data": [...], "_links": {...}}
                        items = (
                            data.get("data")
                            or data.get("ai-agents")
                            or data.get("aiAgents")
                            or []
                        )
                        if isinstance(items, list) and items:
                            agents.extend(items)
                        elif not items:
                            # Single-object response (no wrapper)
                            if "id" in data:
                                agents.append(data)

                    # Follow pagination via Link header or _links.next in body
                    url = self._parse_next_link(response.headers.get("Link"))
                    if not url and isinstance(data, dict):
                        links = data.get("_links", {})
                        next_link = links.get("next", {})
                        if isinstance(next_link, dict):
                            url = next_link.get("href")
        except Exception as e:
            logger.warning(f"list_agents error: {e}")

        return agents

    async def get_agent(
        self, agent_id: str, okta_token: Optional[str] = None
    ) -> Optional[dict]:
        """Get a single AI agent by ID.

        GET {base_url}/workload-principals/api/v1/ai-agents/{agent_id}
        Returns None on 404.
        """
        if not self._base_url:
            logger.warning("OKTA_DOMAIN not configured, cannot get agent")
            return None

        headers = await self._get_auth_headers(okta_token)
        url = f"{self._base_url}/workload-principals/api/v1/ai-agents/{agent_id}"

        try:
            async with httpx.AsyncClient(timeout=_REQUEST_TIMEOUT) as client:
                response = await client.get(url, headers=headers)
                if response.status_code == 404:
                    return None
                if response.status_code != 200:
                    logger.warning(
                        f"get_agent({agent_id}) failed: {response.status_code} {response.text}"
                    )
                    return None
                return response.json()
        except Exception as e:
            logger.warning(f"get_agent({agent_id}) error: {e}")
            return None

    async def get_agent_credentials(
        self, agent_id: str, okta_token: Optional[str] = None
    ) -> List[dict]:
        """Get agent credentials (JWKS).

        GET {base_url}/workload-principals/api/v1/ai-agents/{agent_id}/credentials/jwks
        """
        if not self._base_url:
            return []

        headers = await self._get_auth_headers(okta_token)
        url = (
            f"{self._base_url}/workload-principals/api/v1/ai-agents/"
            f"{agent_id}/credentials/jwks"
        )

        try:
            async with httpx.AsyncClient(timeout=_REQUEST_TIMEOUT) as client:
                response = await client.get(url, headers=headers)
                if response.status_code != 200:
                    logger.warning(
                        f"get_agent_credentials({agent_id}) failed: "
                        f"{response.status_code} {response.text}"
                    )
                    return []
                data = response.json()
                if isinstance(data, list):
                    return data
                return data.get("keys", [])
        except Exception as e:
            logger.warning(f"get_agent_credentials({agent_id}) error: {e}")
            return []

    async def get_agent_connections(
        self, agent_id: str, okta_token: Optional[str] = None
    ) -> List[dict]:
        """Get agent connections (linked auth servers / resources).

        GET {base_url}/workload-principals/api/v1/ai-agents/{agent_id}/connections
        """
        if not self._base_url:
            return []

        headers = await self._get_auth_headers(okta_token)
        url = (
            f"{self._base_url}/workload-principals/api/v1/ai-agents/"
            f"{agent_id}/connections"
        )

        try:
            async with httpx.AsyncClient(timeout=_REQUEST_TIMEOUT) as client:
                response = await client.get(url, headers=headers)
                if response.status_code != 200:
                    logger.warning(
                        f"get_agent_connections({agent_id}) failed: "
                        f"{response.status_code} {response.text}"
                    )
                    return []
                data = response.json()
                if isinstance(data, list):
                    return data
                # Okta wraps results: {"data": [...], "_links": {...}}
                if isinstance(data, dict):
                    items = (
                        data.get("data")
                        or data.get("connections")
                        or data.get("items")
                    )
                    if isinstance(items, list):
                        return items
                return []
        except Exception as e:
            logger.warning(f"get_agent_connections({agent_id}) error: {e}")
            return []

    # ------------------------------------------------------------------
    # App / Org endpoints
    # ------------------------------------------------------------------

    async def get_linked_app(
        self, app_id: str, okta_token: Optional[str] = None
    ) -> Optional[dict]:
        """Get an Okta application by ID.

        GET {base_url}/api/v1/apps/{app_id}
        """
        if not self._base_url:
            return None

        headers = await self._get_auth_headers(okta_token)
        url = f"{self._base_url}/api/v1/apps/{app_id}"

        try:
            async with httpx.AsyncClient(timeout=_REQUEST_TIMEOUT) as client:
                response = await client.get(url, headers=headers)
                if response.status_code == 404:
                    return None
                if response.status_code != 200:
                    logger.warning(
                        f"get_linked_app({app_id}) failed: "
                        f"{response.status_code} {response.text}"
                    )
                    return None
                return response.json()
        except Exception as e:
            logger.warning(f"get_linked_app({app_id}) error: {e}")
            return None

    async def get_org_info(self, okta_token: Optional[str] = None) -> dict:
        """Get Okta organization info.

        GET {base_url}/.well-known/okta-organization
        """
        if not self._base_url:
            return {}

        headers = await self._get_auth_headers(okta_token)
        url = f"{self._base_url}/.well-known/okta-organization"

        try:
            async with httpx.AsyncClient(timeout=_REQUEST_TIMEOUT) as client:
                response = await client.get(url, headers=headers)
                if response.status_code != 200:
                    logger.warning(
                        f"get_org_info failed: {response.status_code} {response.text}"
                    )
                    return {}
                return response.json()
        except Exception as e:
            logger.warning(f"get_org_info error: {e}")
            return {}

    # ------------------------------------------------------------------
    # Token scope check
    # ------------------------------------------------------------------

    async def check_token_scopes(self, okta_token: str) -> dict:
        """Verify whether the token has AI Agent management scopes.

        Tries GET .../ai-agents?limit=1.
        200 → {"has_ai_agent_scopes": True}
        403 → {"has_ai_agent_scopes": False, "error": "Token lacks okta.aiAgents.read scope"}
        401 → {"has_ai_agent_scopes": False, "error": "Token expired or invalid"}
        """
        if not self._base_url:
            return {
                "has_ai_agent_scopes": False,
                "error": "OKTA_DOMAIN not configured",
            }

        headers = await self._get_auth_headers(okta_token)
        url = f"{self._base_url}/workload-principals/api/v1/ai-agents?limit=1"

        try:
            async with httpx.AsyncClient(timeout=_REQUEST_TIMEOUT) as client:
                response = await client.get(url, headers=headers)

            if response.status_code == 200:
                return {"has_ai_agent_scopes": True}
            elif response.status_code == 403:
                return {
                    "has_ai_agent_scopes": False,
                    "error": "Token lacks okta.aiAgents.read scope",
                }
            elif response.status_code == 401:
                return {
                    "has_ai_agent_scopes": False,
                    "error": "Token expired or invalid",
                }
            else:
                return {
                    "has_ai_agent_scopes": False,
                    "error": f"Unexpected status {response.status_code}",
                }
        except Exception as e:
            logger.warning(f"check_token_scopes error: {e}")
            return {"has_ai_agent_scopes": False, "error": str(e)}

    # ------------------------------------------------------------------
    # Connection CRUD
    # ------------------------------------------------------------------

    async def create_connection(
        self,
        agent_id: str,
        connection_payload: dict,
        okta_token: Optional[str] = None,
    ) -> Optional[dict]:
        """Create a connection on an AI agent.

        POST {base_url}/workload-principals/api/v1/ai-agents/{agent_id}/connections

        Args:
            agent_id: Okta AI Agent ID.
            connection_payload: Connection body (varies by connectionType).
            okta_token: Optional admin Okta access token.

        Returns:
            Created connection dict (201) or None on error.
        """
        if not self._base_url:
            logger.warning("OKTA_DOMAIN not configured")
            return None

        headers = await self._get_auth_headers(okta_token)
        url = (
            f"{self._base_url}/workload-principals/api/v1/ai-agents/"
            f"{agent_id}/connections"
        )

        try:
            async with httpx.AsyncClient(timeout=_REQUEST_TIMEOUT) as client:
                response = await client.post(url, headers=headers, json=connection_payload)
                if response.status_code in (200, 201):
                    return response.json()
                logger.warning(
                    f"create_connection({agent_id}) failed: "
                    f"{response.status_code} {response.text}"
                )
                return None
        except Exception as e:
            logger.warning(f"create_connection({agent_id}) error: {e}")
            return None

    async def get_connection(
        self,
        agent_id: str,
        connection_id: str,
        okta_token: Optional[str] = None,
    ) -> Optional[dict]:
        """Get a single connection by ID.

        GET .../ai-agents/{agent_id}/connections/{connection_id}
        """
        if not self._base_url:
            return None

        headers = await self._get_auth_headers(okta_token)
        url = (
            f"{self._base_url}/workload-principals/api/v1/ai-agents/"
            f"{agent_id}/connections/{connection_id}"
        )

        try:
            async with httpx.AsyncClient(timeout=_REQUEST_TIMEOUT) as client:
                response = await client.get(url, headers=headers)
                if response.status_code == 404:
                    return None
                if response.status_code != 200:
                    logger.warning(
                        f"get_connection({agent_id}, {connection_id}) failed: "
                        f"{response.status_code} {response.text}"
                    )
                    return None
                return response.json()
        except Exception as e:
            logger.warning(f"get_connection({agent_id}, {connection_id}) error: {e}")
            return None

    async def update_connection(
        self,
        agent_id: str,
        connection_id: str,
        patch_payload: dict,
        okta_token: Optional[str] = None,
    ) -> Optional[dict]:
        """Patch a connection (IDENTITY_ASSERTION_CUSTOM_AS only).

        PATCH .../ai-agents/{agent_id}/connections/{connection_id}

        patch_payload examples:
          {"scopeCondition": "INCLUDE_ONLY", "scopes": ["read_data"]}
          {"resourceIndicator": "https://example.com/api"}
          {"resourceIndicator": null}
        """
        if not self._base_url:
            return None

        headers = await self._get_auth_headers(okta_token)
        url = (
            f"{self._base_url}/workload-principals/api/v1/ai-agents/"
            f"{agent_id}/connections/{connection_id}"
        )

        try:
            async with httpx.AsyncClient(timeout=_REQUEST_TIMEOUT) as client:
                response = await client.patch(url, headers=headers, json=patch_payload)
                if response.status_code in (200, 204):
                    if response.status_code == 204:
                        return {}
                    return response.json()
                logger.warning(
                    f"update_connection({agent_id}, {connection_id}) failed: "
                    f"{response.status_code} {response.text}"
                )
                return None
        except Exception as e:
            logger.warning(f"update_connection({agent_id}, {connection_id}) error: {e}")
            return None

    async def delete_connection(
        self,
        agent_id: str,
        connection_id: str,
        okta_token: Optional[str] = None,
    ) -> bool:
        """Delete a connection.

        DELETE .../ai-agents/{agent_id}/connections/{connection_id}

        Returns:
            True on 204, False on error.
        """
        if not self._base_url:
            return False

        headers = await self._get_auth_headers(okta_token)
        url = (
            f"{self._base_url}/workload-principals/api/v1/ai-agents/"
            f"{agent_id}/connections/{connection_id}"
        )

        try:
            async with httpx.AsyncClient(timeout=_REQUEST_TIMEOUT) as client:
                response = await client.delete(url, headers=headers)
                if response.status_code == 204:
                    return True
                logger.warning(
                    f"delete_connection({agent_id}, {connection_id}) failed: "
                    f"{response.status_code} {response.text}"
                )
                return False
        except Exception as e:
            logger.warning(f"delete_connection({agent_id}, {connection_id}) error: {e}")
            return False

    async def activate_connection(
        self,
        agent_id: str,
        connection_id: str,
        okta_token: Optional[str] = None,
    ) -> Optional[dict]:
        """Activate a connection.

        POST .../connections/{connection_id}/lifecycle/activate
        """
        if not self._base_url:
            return None

        headers = await self._get_auth_headers(okta_token)
        url = (
            f"{self._base_url}/workload-principals/api/v1/ai-agents/"
            f"{agent_id}/connections/{connection_id}/lifecycle/activate"
        )

        try:
            async with httpx.AsyncClient(timeout=_REQUEST_TIMEOUT) as client:
                response = await client.post(url, headers=headers)
                if response.status_code in (200, 204):
                    if response.status_code == 204:
                        return {}
                    return response.json()
                logger.warning(
                    f"activate_connection({agent_id}, {connection_id}) failed: "
                    f"{response.status_code} {response.text}"
                )
                return None
        except Exception as e:
            logger.warning(f"activate_connection({agent_id}, {connection_id}) error: {e}")
            return None

    async def deactivate_connection(
        self,
        agent_id: str,
        connection_id: str,
        okta_token: Optional[str] = None,
    ) -> Optional[dict]:
        """Deactivate a connection.

        POST .../connections/{connection_id}/lifecycle/deactivate
        """
        if not self._base_url:
            return None

        headers = await self._get_auth_headers(okta_token)
        url = (
            f"{self._base_url}/workload-principals/api/v1/ai-agents/"
            f"{agent_id}/connections/{connection_id}/lifecycle/deactivate"
        )

        try:
            async with httpx.AsyncClient(timeout=_REQUEST_TIMEOUT) as client:
                response = await client.post(url, headers=headers)
                if response.status_code in (200, 204):
                    if response.status_code == 204:
                        return {}
                    return response.json()
                logger.warning(
                    f"deactivate_connection({agent_id}, {connection_id}) failed: "
                    f"{response.status_code} {response.text}"
                )
                return None
        except Exception as e:
            logger.warning(f"deactivate_connection({agent_id}, {connection_id}) error: {e}")
            return None

    # ------------------------------------------------------------------
    # Potential Connections
    # ------------------------------------------------------------------

    async def list_potential_connections(
        self,
        connection_type: str,
        match: Optional[str] = None,
        okta_token: Optional[str] = None,
    ) -> List[dict]:
        """List potential connections of a given type.

        GET {base_url}/workload-principals/api/v1/potential-connections
            ?filter=connectionType eq "{connection_type}"
            &match={match}  (optional, 3-50 chars, fuzzy search)

        Args:
            connection_type: IDENTITY_ASSERTION_CUSTOM_AS | STS_VAULT_SECRET | STS_SERVICE_ACCOUNT
            match: Optional fuzzy search string (3-50 chars).
            okta_token: Optional admin Okta access token.

        Returns:
            List of potential connection dicts.
        """
        if not self._base_url:
            return []

        headers = await self._get_auth_headers(okta_token)
        params = {
            "filter": f'connectionType eq "{connection_type}"',
        }
        if match:
            params["match"] = match

        url = f"{self._base_url}/workload-principals/api/v1/potential-connections"

        try:
            async with httpx.AsyncClient(timeout=_REQUEST_TIMEOUT) as client:
                response = await client.get(url, headers=headers, params=params)
                if response.status_code != 200:
                    logger.warning(
                        f"list_potential_connections({connection_type}) failed: "
                        f"{response.status_code} {response.text}"
                    )
                    return []
                data = response.json()
                if isinstance(data, list):
                    return data
                if isinstance(data, dict):
                    return (
                        data.get("data")
                        or data.get("potentialConnections")
                        or data.get("items")
                        or []
                    )
                return []
        except Exception as e:
            logger.warning(f"list_potential_connections({connection_type}) error: {e}")
            return []

    # ------------------------------------------------------------------
    # Public Key Management
    # ------------------------------------------------------------------

    async def add_public_key(
        self,
        agent_id: str,
        jwk_public_key: dict,
        okta_token: Optional[str] = None,
    ) -> Optional[dict]:
        """Add a public key (JWK) to an agent's credentials.

        POST .../ai-agents/{agent_id}/credentials/jwks

        Args:
            agent_id: Okta AI Agent ID.
            jwk_public_key: JWK dict with public key components.
            okta_token: Optional admin Okta access token.

        Returns:
            Created key dict or None on error.
        """
        if not self._base_url:
            return None

        headers = await self._get_auth_headers(okta_token)
        url = (
            f"{self._base_url}/workload-principals/api/v1/ai-agents/"
            f"{agent_id}/credentials/jwks"
        )

        try:
            async with httpx.AsyncClient(timeout=_REQUEST_TIMEOUT) as client:
                response = await client.post(url, headers=headers, json=jwk_public_key)
                if response.status_code in (200, 201):
                    return response.json()
                logger.warning(
                    f"add_public_key({agent_id}) failed: "
                    f"{response.status_code} {response.text}"
                )
                return None
        except Exception as e:
            logger.warning(f"add_public_key({agent_id}) error: {e}")
            return None

    async def delete_public_key(
        self,
        agent_id: str,
        key_id: str,
        okta_token: Optional[str] = None,
    ) -> bool:
        """Delete a public key from an agent's credentials.

        DELETE .../ai-agents/{agent_id}/credentials/jwks/{key_id}

        Returns:
            True on 204, False on error.
        """
        if not self._base_url:
            return False

        headers = await self._get_auth_headers(okta_token)
        url = (
            f"{self._base_url}/workload-principals/api/v1/ai-agents/"
            f"{agent_id}/credentials/jwks/{key_id}"
        )

        try:
            async with httpx.AsyncClient(timeout=_REQUEST_TIMEOUT) as client:
                response = await client.delete(url, headers=headers)
                if response.status_code == 204:
                    return True
                logger.warning(
                    f"delete_public_key({agent_id}, {key_id}) failed: "
                    f"{response.status_code} {response.text}"
                )
                return False
        except Exception as e:
            logger.warning(f"delete_public_key({agent_id}, {key_id}) error: {e}")
            return False

    # ------------------------------------------------------------------
    # Agent Lifecycle (async operations)
    # ------------------------------------------------------------------

    async def register_agent(
        self,
        app_id: str,
        name: str,
        description: Optional[str] = None,
        okta_token: Optional[str] = None,
    ) -> Optional[dict]:
        """Register a new AI agent (async operation).

        POST {base_url}/workload-principals/api/v1/ai-agents → 202 Accepted
        Polls the operation until COMPLETED.

        Args:
            app_id: Okta OIDC app ID to link.
            name: Agent display name.
            description: Optional description.
            okta_token: Optional admin Okta access token.

        Returns:
            Agent dict on success, None on failure.
        """
        if not self._base_url:
            return None

        headers = await self._get_auth_headers(okta_token)
        url = f"{self._base_url}/workload-principals/api/v1/ai-agents"

        payload: Dict[str, str] = {"appId": app_id, "name": name}
        if description:
            payload["description"] = description

        try:
            async with httpx.AsyncClient(timeout=_REQUEST_TIMEOUT) as client:
                response = await client.post(url, headers=headers, json=payload)

                if response.status_code == 202:
                    data = response.json()
                    operation_id = data.get("operationId") or data.get("id")
                    if operation_id:
                        result = await self.poll_operation(operation_id, okta_token=okta_token)
                        return result
                    logger.warning(f"register_agent: 202 but no operationId in response")
                    return data
                elif response.status_code in (200, 201):
                    return response.json()
                else:
                    logger.warning(
                        f"register_agent failed: {response.status_code} {response.text}"
                    )
                    return None
        except Exception as e:
            logger.warning(f"register_agent error: {e}")
            return None

    async def activate_agent(
        self, agent_id: str, okta_token: Optional[str] = None
    ) -> Optional[dict]:
        """Activate an AI agent.

        POST .../ai-agents/{agent_id}/lifecycle/activate
        """
        return await self._agent_lifecycle(agent_id, "activate", okta_token)

    async def deactivate_agent(
        self, agent_id: str, okta_token: Optional[str] = None
    ) -> Optional[dict]:
        """Deactivate an AI agent.

        POST .../ai-agents/{agent_id}/lifecycle/deactivate
        """
        return await self._agent_lifecycle(agent_id, "deactivate", okta_token)

    async def delete_agent_resource(
        self, agent_id: str, okta_token: Optional[str] = None
    ) -> bool:
        """Delete an AI agent.

        DELETE .../ai-agents/{agent_id}

        Returns True on 204/200.
        """
        if not self._base_url:
            return False

        headers = await self._get_auth_headers(okta_token)
        url = f"{self._base_url}/workload-principals/api/v1/ai-agents/{agent_id}"

        try:
            async with httpx.AsyncClient(timeout=_REQUEST_TIMEOUT) as client:
                response = await client.delete(url, headers=headers)
                if response.status_code in (200, 204):
                    return True
                logger.warning(
                    f"delete_agent_resource({agent_id}) failed: "
                    f"{response.status_code} {response.text}"
                )
                return False
        except Exception as e:
            logger.warning(f"delete_agent_resource({agent_id}) error: {e}")
            return False

    async def _agent_lifecycle(
        self, agent_id: str, action: str, okta_token: Optional[str] = None
    ) -> Optional[dict]:
        """Execute an agent lifecycle action (activate/deactivate)."""
        if not self._base_url:
            return None

        headers = await self._get_auth_headers(okta_token)
        url = (
            f"{self._base_url}/workload-principals/api/v1/ai-agents/"
            f"{agent_id}/lifecycle/{action}"
        )

        try:
            async with httpx.AsyncClient(timeout=_REQUEST_TIMEOUT) as client:
                response = await client.post(url, headers=headers)
                if response.status_code in (200, 204):
                    if response.status_code == 204:
                        return {}
                    return response.json()
                logger.warning(
                    f"{action}_agent({agent_id}) failed: "
                    f"{response.status_code} {response.text}"
                )
                return None
        except Exception as e:
            logger.warning(f"{action}_agent({agent_id}) error: {e}")
            return None

    # ------------------------------------------------------------------
    # Operation Polling
    # ------------------------------------------------------------------

    async def poll_operation(
        self,
        operation_id: str,
        okta_token: Optional[str] = None,
        max_wait: int = 30,
        poll_interval: int = 2,
    ) -> Optional[dict]:
        """Poll an async operation until COMPLETED or FAILED.

        GET {base_url}/workload-principals/api/v1/operations/{operation_id}

        Args:
            operation_id: Operation ID from a 202 response.
            okta_token: Optional admin Okta access token.
            max_wait: Maximum seconds to wait before raising TimeoutError.
            poll_interval: Seconds between polls.

        Returns:
            The operation result (typically the created resource).

        Raises:
            TimeoutError: If the operation doesn't complete within max_wait.
            RuntimeError: If the operation reaches FAILED status.
        """
        if not self._base_url:
            raise RuntimeError("OKTA_DOMAIN not configured")

        headers = await self._get_auth_headers(okta_token)
        url = (
            f"{self._base_url}/workload-principals/api/v1/operations/"
            f"{operation_id}"
        )

        elapsed = 0
        while elapsed < max_wait:
            try:
                async with httpx.AsyncClient(timeout=_REQUEST_TIMEOUT) as client:
                    response = await client.get(url, headers=headers)

                if response.status_code != 200:
                    logger.warning(
                        f"poll_operation({operation_id}) failed: "
                        f"{response.status_code} {response.text}"
                    )
                    return None

                data = response.json()
                status = data.get("status", "").upper()

                if status == "COMPLETED":
                    logger.info(f"Operation {operation_id} completed")
                    return data.get("result") or data
                elif status == "FAILED":
                    error = data.get("error") or data.get("reason") or "Unknown error"
                    raise RuntimeError(
                        f"Operation {operation_id} failed: {error}"
                    )

            except (RuntimeError, TimeoutError):
                raise
            except Exception as e:
                logger.warning(f"poll_operation({operation_id}) error: {e}")

            await asyncio.sleep(poll_interval)
            elapsed += poll_interval

        raise TimeoutError(
            f"Operation {operation_id} did not complete within {max_wait}s"
        )

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _parse_next_link(link_header: Optional[str]) -> Optional[str]:
        """Parse RFC 5988 Link header for rel="next" URL."""
        if not link_header:
            return None
        for part in link_header.split(","):
            part = part.strip()
            if 'rel="next"' in part:
                # Extract URL between < and >
                start = part.find("<")
                end = part.find(">")
                if start != -1 and end != -1:
                    return part[start + 1 : end]
        return None
