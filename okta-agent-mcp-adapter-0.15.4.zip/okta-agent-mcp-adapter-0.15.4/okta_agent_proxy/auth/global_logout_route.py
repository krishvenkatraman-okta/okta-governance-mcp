"""
Starlette route handler for /oauth/global-token-revocation.

Implements the Global Token Revocation endpoint
(draft-parecki-oauth-global-token-revocation) so Okta Identity
Threat Protection (ITP) Universal Logout can revoke a user's
tokens and sessions on the adapter.

JWT format (per Okta dev guide, see
https://developer.okta.com/docs/guides/oin-universal-logout-overview/):

  Header:
    typ = "global-token-revocation+jwt"
    alg = signing algorithm (RS256)
    kid = key id from Okta JWKS

  Payload:
    jti = unique identifier
    iss = the issuer of user tokens (the adapter's authorization server)
    sub = client_id of the calling Okta OIDC app (each Agent record
          in the adapter is linked to its own Okta OIDC app — which
          may be shared across agents or unique per agent; the
          adapter auto-maintains an allowlist of trusted client_ids
          sourced from the agents table)
    aud = the revocation endpoint URL (no query/fragment)
    exp = 5 min in the future
    nbf = 5 min in the past
    iat = current timestamp

The adapter currently uses the Okta org authorization server, so
settings.issuer == https://{OKTA_DOMAIN} and the JWKS URL is
https://{OKTA_DOMAIN}/oauth2/v1/keys. The existing OktaTokenValidator
already fetches and caches that JWKS — we reuse it.

The body subject.iss must match settings.issuer (same value).

Subject identifier format: 'iss_sub' ONLY. 'email' format is rejected
with 400 unsupported_subject_format.

Response codes:
  204 No Content — revocation accepted (also when subject not found,
                   per Okta dev guide on enumeration mitigation).
  400 Bad Request — malformed body or unsupported subject format.
  401 Unauthorized — JWT missing, expired, typ wrong, or sig invalid.
  429 Too Many Requests — rate limit exceeded.

Rate limiter: cachetools.TTLCache-backed, bounded size + idle
eviction. Per-replica counters.

Context handling: CorrelationIdMiddleware already populates the
correlation_id / ip_address / user_agent context vars. We snapshot
that context at handler entry and reapply it inside the scheduled
background task so audit events emitted by the bg task carry IP/UA.

Audit-event flow:
  GLOBAL_LOGOUT_REQUESTED (always, top of handler)
  GLOBAL_LOGOUT_AUTH_FAILED (on JWT failure)
  GLOBAL_LOGOUT_SUBJECT_INVALID (on subject parse / iss mismatch)
  GLOBAL_LOGOUT_COMPLETED (from background task, success or failure)
  GLOBAL_LOGOUT_BACKEND_SESSION_TERMINATED / _FAILED (from sm fan-out)
  GLOBAL_LOGOUT_SUBJECT_NOT_FOUND (when nothing to revoke)
"""

GLOBAL_LOGOUT_PATH = "/oauth/global-token-revocation"

import asyncio
import logging
import os
import time
import uuid
import cachetools
from jose import jwt as jose_jwt, JWTError
from starlette.requests import Request
from starlette.responses import JSONResponse, Response

from okta_agent_proxy.audit import emit_audit_event
from okta_agent_proxy.audit.events import AuditEventType, AuditSeverity
from okta_agent_proxy.audit.context import (
    get_correlation_id,
    get_request_context,
    set_request_context,
)
from okta_agent_proxy.auth.global_logout import get_global_logout_handler
from okta_agent_proxy.auth.okta_validator import get_validator
from okta_agent_proxy.config import GatewaySettings

logger = logging.getLogger(__name__)


# ------------------------------------------------------------------
# Constants from Okta spec
# ------------------------------------------------------------------

EXPECTED_TYP = "global-token-revocation+jwt"


# ------------------------------------------------------------------
# Rate limiter (cachetools.TTLCache — bounded size + idle eviction)
# ------------------------------------------------------------------

_RATE_LIMIT_MAX = int(os.environ.get("GLOBAL_LOGOUT_RATE_LIMIT_PER_MIN", "100"))
_RATE_LIMIT_WINDOW = 60.0
_RATE_LIMIT_MAX_IPS = int(os.environ.get("GLOBAL_LOGOUT_RATE_LIMIT_MAX_IPS", "4096"))
# TTL 2x the window so hot IPs are never evicted mid-window; cold IPs age out.
_rate_limit_state: cachetools.TTLCache = cachetools.TTLCache(
    maxsize=_RATE_LIMIT_MAX_IPS, ttl=_RATE_LIMIT_WINDOW * 2
)


def _check_rate_limit(ip: str) -> bool:
    """True if allowed. Per-replica, bounded in memory."""
    now = time.monotonic()
    bucket = _rate_limit_state.get(ip)
    if bucket is None:
        bucket = []
        _rate_limit_state[ip] = bucket  # inserts + resets TTL
    cutoff = now - _RATE_LIMIT_WINDOW
    bucket[:] = [t for t in bucket if t > cutoff]
    if len(bucket) >= _RATE_LIMIT_MAX:
        return False
    bucket.append(now)
    # Re-set to refresh TTL on access (TTLCache refreshes on __setitem__, not get)
    _rate_limit_state[ip] = bucket
    return True


def _reset_rate_limiter() -> None:
    """Test-only."""
    _rate_limit_state.clear()


# ---- Agent client_id allowlist (for JWT sub validation) ----
_ALLOWLIST_TTL_SECONDS = int(
    os.environ.get("GLOBAL_LOGOUT_ALLOWLIST_TTL_SECONDS", "3600")
)
_allowlist_cache: dict = {
    "set": frozenset(),
    "fetched_at": 0.0,
    "loaded": False,
}
_allowlist_lock = asyncio.Lock()


async def _load_agent_client_id_allowlist() -> frozenset:
    """Build the allowlist from the agents table. Includes
    disabled agents (their tokens are still in flight)."""
    from okta_agent_proxy.database import get_store
    store = get_store()
    agents = store.get_all_agents(enabled_only=False)
    client_ids = {
        a.get("client_id") for a in agents
        if isinstance(a.get("client_id"), str) and a.get("client_id")
    }
    return frozenset(client_ids)


async def _get_agent_client_id_allowlist() -> frozenset:
    """Return the cached allowlist, refreshing from DB if stale."""
    now = time.monotonic()
    cached = _allowlist_cache
    if (cached["loaded"]
            and (now - cached["fetched_at"]) < _ALLOWLIST_TTL_SECONDS):
        return cached["set"]

    async with _allowlist_lock:
        now = time.monotonic()
        if (_allowlist_cache["loaded"]
                and (now - _allowlist_cache["fetched_at"])
                     < _ALLOWLIST_TTL_SECONDS):
            return _allowlist_cache["set"]
        try:
            client_ids = await _load_agent_client_id_allowlist()
        except Exception as exc:
            logger.warning(
                "[GLOBAL-LOGOUT] allowlist refresh failed; "
                "keeping previous value: %s", exc
            )
            # Return last known good value rather than empty set —
            # empty set would reject every legitimate call. If we
            # have no prior value (first load failed), return empty
            # which will cause 401 — that is the safer default.
            return _allowlist_cache["set"]
        _allowlist_cache["set"] = client_ids
        _allowlist_cache["fetched_at"] = time.monotonic()
        _allowlist_cache["loaded"] = True
        logger.info(
            "[GLOBAL-LOGOUT] allowlist refreshed: %d client_ids",
            len(client_ids),
        )
        return client_ids


def invalidate_agent_client_id_allowlist() -> None:
    """Force the next allowlist read to re-query the DB. Called
    by the CHANNEL_AGENT_INVALIDATE pub/sub subscriber and from
    local agent CRUD via the existing publish path."""
    _allowlist_cache["loaded"] = False
    # Don't clear the set itself — keep it as the last-known
    # value in case the next refresh fails (see _get_... fallback)
    _allowlist_cache["fetched_at"] = 0.0


def _reset_allowlist_cache() -> None:
    """Test-only: full reset including the cached set."""
    _allowlist_cache["set"] = frozenset()
    _allowlist_cache["fetched_at"] = 0.0
    _allowlist_cache["loaded"] = False


# ------------------------------------------------------------------
# JWT verification
# ------------------------------------------------------------------

def _expected_audience() -> str:
    """The aud claim Okta puts in the signed logout JWT.

    Default: GATEWAY_BASE_URL + GLOBAL_LOGOUT_PATH.
    Override via GLOBAL_LOGOUT_AUDIENCE env var if Okta is configured
    with a non-default value.
    """
    override = os.environ.get("GLOBAL_LOGOUT_AUDIENCE")
    if override:
        return override
    settings = GatewaySettings()
    return f"{settings.gateway_base_url}{GLOBAL_LOGOUT_PATH}"


async def _verify_logout_jwt(token: str) -> dict:
    """Verify Okta-signed logout JWT. Returns claims or raises ValueError.

    Per Okta dev guide for Universal Logout, validates:
      - typ header == "global-token-revocation+jwt"
      - alg == RS256
      - signature against settings.issuer's JWKS (org JWKS)
      - iss == settings.issuer
      - aud == GATEWAY_BASE_URL + path (or override)
      - exp not expired
      - nbf not before (with small leeway)
      - sub must be a registered agent's Okta app client_id
          (auto-maintained from the agents table — both enabled
          and disabled agents are trusted; only deleted agents
          are rejected).
    """
    if not token:
        raise ValueError("empty token")

    # 1. Header check (typ — non-standard, python-jose doesn't verify it)
    try:
        header = jose_jwt.get_unverified_header(token)
    except JWTError as exc:
        raise ValueError(f"malformed_jwt: {exc}") from exc

    typ = header.get("typ")
    if typ != EXPECTED_TYP:
        raise ValueError(
            f"unexpected_typ: got {typ!r}, expected {EXPECTED_TYP!r}"
        )

    # 2. Signature + standard claims via the existing OktaTokenValidator
    settings = GatewaySettings()
    validator = get_validator()
    jwks = await validator.fetch_jwks()
    expected_iss = settings.issuer
    expected_aud = _expected_audience()

    try:
        claims = jose_jwt.decode(
            token,
            key=jwks,
            algorithms=["RS256"],
            issuer=expected_iss,
            audience=expected_aud,
            options={
                "verify_signature": True,
                "verify_iss": True,
                "verify_aud": True,
                "verify_exp": True,
                "require_exp": True,
                # python-jose verifies nbf when present; explicit for clarity
                "verify_nbf": True,
            },
        )
    except JWTError as exc:
        raise ValueError(f"jwt_verification_failed: {exc}") from exc

    # 3. JWT sub must be a registered agent's client_id
    actual_sub = claims.get("sub")
    allowlist = await _get_agent_client_id_allowlist()
    if not actual_sub or actual_sub not in allowlist:
        raise ValueError(
            f"sub_not_in_allowlist: client_id {actual_sub!r} is not "
            f"a registered agent's Okta app client_id"
        )

    return claims


# ------------------------------------------------------------------
# Route handler
# ------------------------------------------------------------------

def _bad_request(code: str, description: str) -> JSONResponse:
    return JSONResponse(
        {"error": code, "error_description": description},
        status_code=400,
    )


async def global_token_revocation(request: Request) -> Response:
    """POST /oauth/global-token-revocation — Okta ITP Universal Logout."""
    # CorrelationIdMiddleware already populated correlation_id / ip / ua.
    # Only generate one if we're running without the middleware (e.g., in
    # unit tests that mount this handler directly on a bare Starlette app).
    correlation_id = get_correlation_id() or str(uuid.uuid4())

    ip = request.client.host if request.client else "unknown"

    if not _check_rate_limit(ip):
        return JSONResponse(
            {"error": "rate_limit_exceeded"},
            status_code=429,
        )

    # REQUESTED — ip is already on the audit event via contextvars from
    # the middleware (ip_address). We emit with an empty details dict to
    # avoid duplicating ip in the payload.
    await emit_audit_event(
        AuditEventType.GLOBAL_LOGOUT_REQUESTED,
        severity=AuditSeverity.INFO,
    )

    # 1. JWT auth
    auth_header = request.headers.get("authorization", "")
    if not auth_header.lower().startswith("bearer "):
        await emit_audit_event(
            AuditEventType.GLOBAL_LOGOUT_AUTH_FAILED,
            severity=AuditSeverity.WARNING,
            outcome="failure",
            details={"reason": "missing_bearer"},
        )
        return JSONResponse(
            {"error": "invalid_client",
             "error_description": "Missing or malformed Authorization header"},
            status_code=401,
        )

    jwt_token = auth_header.split(" ", 1)[1].strip()

    try:
        await _verify_logout_jwt(jwt_token)
    except Exception as exc:
        await emit_audit_event(
            AuditEventType.GLOBAL_LOGOUT_AUTH_FAILED,
            severity=AuditSeverity.WARNING,
            outcome="failure",
            details={"reason": str(exc)[:200]},
        )
        return JSONResponse(
            {"error": "invalid_client",
             "error_description": "JWT verification failed"},
            status_code=401,
        )

    # 2. Body
    try:
        body = await request.json()
    except Exception:
        return _bad_request(
            "malformed_body", "Request body is not valid JSON"
        )

    if not isinstance(body, dict) or "subject" not in body:
        return _bad_request(
            "missing_subject",
            "Request body must contain a 'subject' field"
        )

    subject = body["subject"]

    # 3. Subject parse (iss_sub only)
    handler = get_global_logout_handler()
    try:
        sub_iss, sub_sub = handler.parse_iss_sub_subject(subject)
    except ValueError as exc:
        # Helpful hint when client tried email format
        if isinstance(subject, dict):
            fmt = subject.get("format")
            if fmt and fmt != "iss_sub":
                await emit_audit_event(
                    AuditEventType.GLOBAL_LOGOUT_SUBJECT_INVALID,
                    severity=AuditSeverity.WARNING,
                    outcome="failure",
                    details={"reason": "unsupported_format",
                             "format": str(fmt)[:50]},
                )
                return _bad_request(
                    "unsupported_subject_format",
                    "Adapter only supports subject format 'iss_sub'. "
                    "Configure the Okta Universal Logout integration "
                    "with Subject format type = 'Issuer and Subject "
                    "Identifier'."
                )

        await emit_audit_event(
            AuditEventType.GLOBAL_LOGOUT_SUBJECT_INVALID,
            severity=AuditSeverity.WARNING,
            outcome="failure",
            details={"reason": str(exc)[:200]},
        )
        return _bad_request("invalid_subject", str(exc))

    # 4. Subject.iss must match the adapter's configured issuer.
    # Per RFC 9493, iss_sub identifies a user by (iss, sub) where iss is
    # the AS that issued the sub. Adapter token mappings are keyed by
    # Okta's sub from the configured issuer (settings.issuer).
    # Currently the adapter uses the org AS, so settings.issuer is the
    # org base URL — same value used for the JWT iss check above.
    settings = GatewaySettings()
    expected_iss = settings.issuer
    if sub_iss != expected_iss:
        await emit_audit_event(
            AuditEventType.GLOBAL_LOGOUT_SUBJECT_INVALID,
            severity=AuditSeverity.WARNING,
            outcome="failure",
            details={"reason": "iss_mismatch",
                     "subject_iss": sub_iss[:200],
                     "expected_iss": expected_iss[:200]},
        )
        return _bad_request(
            "invalid_subject",
            "Subject iss does not match the configured token issuer"
        )

    # 5. Schedule revocation as background task. Snapshot the full
    # request context so the bg task's audit events carry the same
    # correlation_id, ip, user_agent.
    ctx_snapshot = get_request_context()
    asyncio.create_task(_run_revocation(sub_sub, ctx_snapshot))

    return Response(status_code=204)


async def _run_revocation(user_sub: str, ctx_snapshot: dict) -> None:
    """Background task. Re-establishes full request context (cleared by
    CorrelationIdMiddleware in its finally block after the response is
    sent)."""
    set_request_context(**ctx_snapshot)
    handler = get_global_logout_handler()
    try:
        await handler.revoke_user(user_sub, ctx_snapshot.get("correlation_id", ""))
    except Exception:
        logger.exception(
            "[GLOBAL-LOGOUT] background task failed for sub=%s (corr=%s)",
            user_sub,
            ctx_snapshot.get("correlation_id", ""),
        )
