"""
Okta Cross-App Access (ID-JAG) Manager

Enables secure token exchange for MCP access using the official okta-client-python SDK.
Implements the CrossAppAccessFlow pattern:
1. flow.start() — Exchange ID token for ID-JAG token (SDK handles both steps)
2. flow.resume() — Exchange ID-JAG for resource access token

This module provides clean abstractions for the ID-JAG pattern using the
official Okta SDK's CrossAppAccessFlow.
"""

import logging
import os
import json
from typing import Dict, Any, Optional

try:
    from jose import jwt
except ImportError:
    jwt = None

from okta_client.authfoundation import (
    OAuth2Client, OAuth2ClientConfiguration, LocalKeyProvider
)
from okta_client.authfoundation.oauth2.jwt_bearer_claims import JWTBearerClaims
from okta_client.authfoundation.oauth2.client_authorization import ClientAssertionAuthorization
from okta_client.oauth2auth import CrossAppAccessFlow, CrossAppAccessTarget

# Lazy import to avoid circular dependency — imported at module level so it
# can be patched cleanly in tests.
from okta_agent_proxy.auth.adapter_cimd import AdapterCIMDServer  # noqa: E402

logger = logging.getLogger(__name__)


class OktaCrossAppAccessManager:
    """
    Manages ID-JAG token exchange for MCP server access using the official
    okta-client-python SDK's CrossAppAccessFlow.

    Usage:
        manager = OktaCrossAppAccessManager(...)
        mcp_token = await manager.exchange_id_token_to_mcp_token(user_id_token, resource_name, ...)
        is_valid = await manager.verify_mcp_token(mcp_token, resource_name, ...)
    """

    def __init__(
        self,
        agent_id: str,
        client_id: str,
        agent_private_key,
        okta_domain: str = None,
        target_auth_server_id: str = None,
        principal_id: str = None,
    ):
        """
        Initialize the Cross-App Access Manager.

        All agent credentials (agent_id, client_id, private_key, principal_id)
        come from the database agent configuration, passed as parameters by the
        caller (ResourceRouter).  The only env var used on the primary path is
        OKTA_DOMAIN (gateway-wide setting).

        When the agent has no private key (None or PLACEHOLDER), we fall back to
        gateway-level shared credentials from env vars (OKTA_AI_AGENT_*) or
        the adapter CIMD signing key.

        Args:
            agent_id: Agent identifier (from DB agent config)
            client_id: Okta OAuth app client ID (from DB agent config)
            agent_private_key: Private key in JWK JSON string (from DB agent config).
                If None/PLACEHOLDER, falls back to gateway-level credentials.
            okta_domain: Okta domain (defaults to OKTA_DOMAIN env var)
            target_auth_server_id: Target authorization server ID (from resource config)
            principal_id: Okta AI Agent ID (e.g., "agtXXXX") for issuer/subject in
                JWT bearer claims.  Required — raises ValueError if not provided.
        """
        # Okta domain — gateway-wide setting, env var fallback is appropriate
        raw_domain = okta_domain or os.getenv("OKTA_DOMAIN", "").strip()
        if not raw_domain:
            raise ValueError("OKTA_DOMAIN environment variable or parameter is required")

        # Normalize domain — SDK expects HTTPS URL
        if raw_domain.startswith("http://"):
            self.okta_domain = raw_domain.replace("http://", "https://")
        elif raw_domain.startswith("https://"):
            self.okta_domain = raw_domain
        else:
            self.okta_domain = f"https://{raw_domain}"

        # Agent credentials — all from DB agent config, no env var fallbacks
        self.agent_id = agent_id
        self.client_id = client_id
        self.target_auth_server_id = target_auth_server_id
        if not principal_id:
            raise ValueError(
                f"principal_id is required for ID-JAG token exchange (agent_id={agent_id}). "
                f"Import the agent from Okta to set the principal_id automatically."
            )
        self.principal_id = principal_id

        logger.debug(
            f"[XAA] Init: agent_id={self.agent_id}, client_id={self.client_id}, "
            f"principal_id={self.principal_id}, target_auth_server_id={self.target_auth_server_id}"
        )

        # Detect placeholder private keys (agents without their own Okta credentials)
        self._using_gateway_key = False
        _is_placeholder = self._is_placeholder_key(agent_private_key)
        agent_private_key_str = agent_private_key

        if _is_placeholder:
            # Agent has no real key — fall back to gateway-level shared credentials.
            # These env vars represent the gateway's own Okta AI Agent identity,
            # shared across all agents that lack their own keys.
            agent_private_key_str = self._resolve_gateway_credentials()
        else:
            logger.info(
                f"[XAA] Agent has own private key — using agent-specific credentials "
                f"(client_id={self.client_id}, agent_id={self.agent_id})"
            )

        if not self.agent_id or not self.client_id or not agent_private_key_str:
            logger.warning(f"Agent credentials not fully configured. ID-JAG exchange will be disabled. agent_id={self.agent_id}, client_id={self.client_id}, has_key={bool(agent_private_key_str)}")
            self._oauth2_client = None
            self._flow_cache = {}
            return

        try:
            # Parse private key — this comes from DB agent_config, NOT env vars
            # (unless _resolve_gateway_credentials() was triggered above for placeholder keys)
            if isinstance(agent_private_key_str, str) and agent_private_key_str.startswith("{"):
                self.agent_private_key = json.loads(agent_private_key_str)
            else:
                self.agent_private_key = agent_private_key_str

            logger.debug(f"[ID-JAG] Agent private key type: {type(self.agent_private_key)}, has kty: {'kty' in self.agent_private_key if isinstance(self.agent_private_key, dict) else 'N/A'}")

            # Create key provider from agent's DB-stored private JWK
            self._key_provider = LocalKeyProvider(
                key=self.agent_private_key,
                algorithm=self.agent_private_key.get("alg", "RS256") if isinstance(self.agent_private_key, dict) else "RS256",
                key_id=self.agent_private_key.get("kid") if isinstance(self.agent_private_key, dict) else None,
            )

            # Create JWT bearer claims
            # issuer and subject = principalId (from DB agent config, e.g., "wlpXXXX")
            self._jwt_claims = JWTBearerClaims(
                issuer=self.principal_id,
                subject=self.principal_id,
                audience=f"{self.okta_domain}/oauth2/v1/token",
                expires_in=300,
            )

            # Create OAuth2 client configuration with JWT bearer assertion auth
            # client_id is NOT passed here — the SDK derives it from the assertion claims
            self._client_config = OAuth2ClientConfiguration(
                issuer=self.okta_domain,
                client_authorization=ClientAssertionAuthorization(
                    assertion_claims=self._jwt_claims,
                    key_provider=self._key_provider,
                ),
            )

            # Create the OAuth2 client
            self._oauth2_client = OAuth2Client(configuration=self._client_config)

            logger.info(f"OAuth2Client created for ID-JAG exchange (okta_domain={self.okta_domain}, principal_id={self.principal_id}, agent_id={self.agent_id})")

            # Cache for CrossAppAccessFlow instances per resource
            self._flow_cache = {}

        except Exception as e:
            logger.error(f"Failed to initialize OktaCrossAppAccessManager: {e}", exc_info=True)
            raise

    @staticmethod
    def _is_placeholder_key(key) -> bool:
        """Check if a private key is missing or a placeholder value."""
        if not key:
            return True
        if isinstance(key, str):
            if key == "PLACEHOLDER" or "PLACEHOLDER" in key:
                return True
        if isinstance(key, dict) and key.get("n") == "PLACEHOLDER":
            return True
        return False

    def _resolve_gateway_credentials(self) -> Optional[str]:
        """
        Resolve gateway-level shared credentials for agents without their own keys.

        Tries two sources in order:
        1. Okta AI Agent env vars (OKTA_AI_AGENT_PRIVATE_KEY, _CLIENT_ID, _ID)
        2. Adapter CIMD signing key + relay app (legacy fallback)

        When gateway credentials are used, agent_id, client_id, and principal_id
        are overridden to match the gateway identity.
        """
        # Try 1: Okta AI Agent credentials (from Universal Directory)
        ai_agent_key = os.getenv("OKTA_AI_AGENT_PRIVATE_KEY")
        ai_agent_client_id = os.getenv("OKTA_AI_AGENT_CLIENT_ID")
        ai_agent_id = os.getenv("OKTA_AI_AGENT_ID")

        if ai_agent_key and ai_agent_client_id and ai_agent_id:
            self.client_id = ai_agent_client_id
            self.agent_id = ai_agent_id
            self.principal_id = ai_agent_id
            self._using_gateway_key = True
            logger.info(
                f"[XAA] Agent has no private key — using Okta AI Agent credentials "
                f"(client_id={self.client_id}, agent_id={self.agent_id})"
            )
            return ai_agent_key

        # Try 2: Fallback — adapter CIMD signing key
        try:
            adapter = AdapterCIMDServer()
            if ai_agent_id:
                self.agent_id = ai_agent_id
            self._using_gateway_key = True
            logger.info(
                f"[XAA] Agent has no private key — using adapter signing key (legacy) "
                f"(client_id={self.client_id}, agent_id={self.agent_id})"
            )
            return json.dumps(adapter._private_jwk)
        except Exception as e:
            logger.debug(f"[XAA] Could not fall back to gateway signing key: {e}")

        return None

    def _get_or_create_flow(self, resource_name: str, target_auth_server_id: str) -> Optional[CrossAppAccessFlow]:
        """
        Get or create a CrossAppAccessFlow for a resource.

        Each flow instance is single-use (start + resume). After use, the caller
        must delete the cache entry so a fresh flow is created next time.

        Args:
            resource_name: Name of the resource (e.g., "employees", "finance")
            target_auth_server_id: Authorization server ID at the target

        Returns:
            CrossAppAccessFlow instance or None if not configured
        """
        if not self._oauth2_client:
            return None

        cache_key = f"{self.agent_id or 'default'}:{resource_name}:{target_auth_server_id}"

        if cache_key not in self._flow_cache:
            try:
                # Extract auth server ID if it's a full URL
                auth_server_id = target_auth_server_id
                if auth_server_id and auth_server_id.startswith("https://"):
                    auth_server_id = auth_server_id.split("/oauth2/")[-1]

                target = CrossAppAccessTarget(
                    issuer=f"{self.okta_domain}/oauth2/{auth_server_id}"
                )
                flow = CrossAppAccessFlow(
                    client=self._oauth2_client,
                    target=target,
                )
                self._flow_cache[cache_key] = flow
                logger.info(f"CrossAppAccessFlow created for {resource_name} (auth_server: {auth_server_id})")
            except Exception as e:
                logger.error(f"Failed to create CrossAppAccessFlow for {resource_name}: {e}")
                return None

        return self._flow_cache[cache_key]

    @staticmethod
    def apply_scope_condition(
        requested_scopes: Optional[list],
        connection_scopes: Optional[list] = None,
        scope_condition: Optional[str] = None,
    ) -> list:
        """Apply scope condition policy from ResolvedResource.

        Args:
            requested_scopes: Scopes the caller wants (e.g. from user access token).
            connection_scopes: Scopes configured on the Okta Managed Connection.
            scope_condition: One of ALLOW_ALL, INCLUDE_ONLY, DISALLOW, EXCLUDE (or None).

        Returns:
            Final list of scopes to request in the token exchange. An empty list
            means "omit the scope parameter on the wire" and let the AS decide
            based on app default scopes (RFC 8693 §2.1).
        """
        requested = [s for s in (requested_scopes or []) if s]
        configured = [s for s in (connection_scopes or []) if s]

        condition = scope_condition or "ALLOW_ALL"

        if condition == "ALLOW_ALL":
            # No filtering: union of caller request and connection configuration.
            return sorted(set(requested) | set(configured))

        if condition == "INCLUDE_ONLY":
            # Restrict to the configured list. If caller requested anything,
            # narrow to the intersection; otherwise use the full configured list.
            if requested:
                return sorted(set(requested) & set(configured))
            return list(configured)

        if condition in ("DISALLOW", "EXCLUDE"):
            # Configured list is a block list. Subtract it from whatever the
            # caller requested; if the caller requested nothing, there's no
            # meaningful result to produce — return empty.
            blocked = set(configured)
            return [s for s in requested if s not in blocked]

        logger.warning(
            "Unknown scope_condition %r — returning empty scope list",
            scope_condition,
        )
        return []

    async def exchange_id_token_to_mcp_token(
        self,
        user_id_token: str,
        resource_name: str,
        target_auth_server_id: str,
        scopes: Optional[list] = None,
        resource_scopes: Optional[list] = None,
        scope_condition: Optional[str] = None,
    ) -> Optional[Dict[str, Any]]:
        """
        Exchange user's ID token for MCP access token using CrossAppAccessFlow.

        Uses the official okta-client-python SDK:
        1. flow.start() — Exchange ID token for ID-JAG (SDK handles both steps)
        2. flow.resume() — Exchange ID-JAG for resource-specific token

        Args:
            user_id_token: User's ID token from Okta
            resource_name: Name of the target MCP server resource
            target_auth_server_id: Authorization server ID at the target MCP server
            scopes: Optional scopes to request (default: ["mcp:read"])
            resource_scopes: Scopes from ResolvedResource (Okta Managed Connection)
            scope_condition: Scope condition from ResolvedResource

        Returns:
            Dict with access_token, expires_in, token_type, scope, or None if failed
        """
        if not self._oauth2_client:
            logger.error("OAuth2Client not configured — ID-JAG exchange disabled")
            return None

        try:
            # Apply scope condition from Resource Map / Okta Managed Connection.
            # Okta's token exchange endpoint rejects with `invalid_scope: No
            # scopes were requested` when the scope parameter is absent, so we
            # can't omit it. If the computed set is empty we fail fast with a
            # clear error instead of sending a sentinel that the target AS will
            # also reject (e.g. `openid` fails Leg 1 on a resource AS).
            scopes = self.apply_scope_condition(scopes, resource_scopes, scope_condition)
            if not scopes:
                logger.error(
                    "[ID-JAG] No scopes computed for %s. "
                    "resource.scopes=%s scope_condition=%s caller_requested_empty=True. "
                    "For ALLOW_ALL connections, run 'Sync Agents' from the Admin UI so "
                    "the adapter materializes scopes_supported from the target AS. "
                    "If the AS advertises Okta-internal scopes that the OIDC client "
                    "isn't granted, add them to OKTA_SCOPE_BLOCKLIST (current default "
                    "filters interclient_access and device_sso).",
                    resource_name, resource_scopes, scope_condition,
                )
                return None

            scope_str = " ".join(scopes)
            logger.debug(f"[ID-JAG] Starting token exchange for {resource_name} with scopes: {scope_str}")

            # Log source token payload for debugging
            try:
                if jwt:
                    token_payload = jwt.get_unverified_claims(user_id_token)
                    logger.info(f"[ID-JAG] Source Token - aud={token_payload.get('aud')}, cid={token_payload.get('cid')}, sub={token_payload.get('sub')}")
            except Exception as e:
                logger.debug(f"[ID-JAG] Could not decode token payload: {e}")

            logger.info(f"[ID-JAG] Config: oktaDomain={self.okta_domain}, principalId={self.principal_id}, authServerId={target_auth_server_id or 'default'}")

            # Create flow for this resource
            flow = self._get_or_create_flow(resource_name, target_auth_server_id)
            if not flow:
                logger.error(f"Failed to create CrossAppAccessFlow for {resource_name}")
                return None

            cache_key = f"{self.agent_id or 'default'}:{resource_name}:{target_auth_server_id}"

            # STEP 1+2: Exchange ID token for ID-JAG (SDK handles both steps).
            # Okta requires a non-empty scope; the fallback above guarantees one.
            try:
                logger.info(f"[ID-JAG STEP 1+2] Starting CrossAppAccessFlow for {resource_name}")
                start_result = await flow.start(token=user_id_token, scope=scopes)

                # The ID-JAG token is available at flow.context.id_jag_token
                id_jag_token = flow.context.id_jag_token
                logger.info(f"[ID-JAG] STEP 1+2 SUCCESS: ID-JAG expires_in={id_jag_token.expires_in}s")
            except Exception as e:
                logger.error(f"[ID-JAG] STEP 1+2 FAILED (flow.start): {str(e)}", exc_info=True)
                try:
                    if hasattr(e, 'response') and hasattr(e.response, 'text'):
                        logger.error(f"[ID-JAG] Okta error response: {e.response.text}")
                except Exception:
                    pass
                # Flow is consumed on error — remove from cache
                self._flow_cache.pop(cache_key, None)
                return None

            # STEP 3: Exchange ID-JAG for resource-specific token
            try:
                logger.info(f"[ID-JAG STEP 3] Resuming flow — exchanging ID-JAG for resource token at {resource_name}")
                exchange_result = await flow.resume()
                logger.info(f"[ID-JAG] STEP 3 SUCCESS: access_token expires_in={exchange_result.expires_in}s, scope={getattr(exchange_result, 'scope', 'N/A')}")
            except Exception as e:
                error_msg = str(e)
                if "timeout" in error_msg.lower():
                    logger.error(f"[ID-JAG] STEP 3 TIMEOUT: Okta server not responding")
                else:
                    logger.error(f"[ID-JAG] STEP 3 FAILED (flow.resume): {error_msg}", exc_info=True)
                try:
                    if hasattr(e, 'response_data'):
                        logger.error(f"[ID-JAG] STEP 3 Okta error body: {e.response_data}")
                except Exception:
                    pass
                # Flow is consumed — remove from cache
                self._flow_cache.pop(cache_key, None)
                return None

            # Flow is consumed after resume() — remove from cache so a fresh one is created
            self._flow_cache.pop(cache_key, None)

            result_scope = getattr(exchange_result, "scope", scope_str)

            # Structured audit log for SIEM
            logger.info(
                "xaa_token_exchange",
                extra={
                    "event": "xaa_token_exchange",
                    "agent_id": self.agent_id,
                    "resource_name": resource_name,
                    "scopes_requested": scope_str,
                    "scopes_granted": result_scope,
                    "using_gateway_key": self._using_gateway_key,
                    "expires_in": exchange_result.expires_in,
                },
            )

            return {
                "access_token": exchange_result.access_token,
                "token_type": getattr(exchange_result, "token_type", "Bearer"),
                "expires_in": exchange_result.expires_in,
                "scope": result_scope,
            }

        except Exception as e:
            logger.error(f"[ID-JAG] Unexpected error: {str(e)}", exc_info=True)
            return None

    async def verify_mcp_token(
        self,
        token: str,
        resource_name: str,
        target_auth_server_id: str,
        audience: str = None
    ) -> Optional[Dict[str, Any]]:
        """
        Verify MCP access token validity using python-jose JWKS verification.

        Args:
            token: MCP access token to verify
            resource_name: Name of the target MCP server resource
            target_auth_server_id: Authorization server ID at the target
            audience: Expected audience for the token (optional)

        Returns:
            Dict with token claims if valid, None if invalid
        """
        if not jwt:
            logger.error("python-jose is required for token verification")
            return None

        try:
            import httpx

            # Fetch JWKS from the target auth server
            auth_server_id = target_auth_server_id
            if auth_server_id and auth_server_id.startswith("https://"):
                auth_server_id = auth_server_id.split("/oauth2/")[-1]

            jwks_url = f"{self.okta_domain}/oauth2/{auth_server_id}/v1/keys"
            logger.debug(f"[ID-JAG] Fetching JWKS from {jwks_url}")

            async with httpx.AsyncClient(timeout=10) as client:
                response = await client.get(jwks_url)
                if response.status_code != 200:
                    logger.error(f"[ID-JAG] JWKS fetch failed: {response.status_code}")
                    return None
                jwks = response.json()

            # Decode and verify the token
            issuer = f"{self.okta_domain}/oauth2/{auth_server_id}"
            options = {"verify_aud": bool(audience)}
            claims = jwt.decode(
                token,
                jwks,
                algorithms=["RS256"],
                audience=audience,
                issuer=issuer,
                options=options,
            )

            logger.info(f"[ID-JAG] Token verified: sub={claims.get('sub')}, scope={claims.get('scp')}")
            return {
                "valid": True,
                "sub": claims.get("sub"),
                "aud": claims.get("aud"),
                "iss": claims.get("iss"),
                "scope": claims.get("scp"),
                "exp": claims.get("exp"),
                "payload": claims,
            }

        except Exception as e:
            logger.error(f"[ID-JAG] Token verification failed: {e}")
            return None
