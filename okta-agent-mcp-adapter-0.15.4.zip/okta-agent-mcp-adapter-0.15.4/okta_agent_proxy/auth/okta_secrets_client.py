"""
DEPRECATED — vault secret and service account credential retrieval has been
migrated to OktaVaultSecretExchanger (auth/okta_vault_exchanger.py) which uses
the official okta-client-python SDK's TokenExchangeFlow.

This module is retained for backward compatibility. New code should use
OktaVaultSecretExchanger.exchange_vault_secret() and
OktaVaultSecretExchanger.exchange_service_account() instead.

---

Okta Secrets Client — retrieves vaulted secrets and service account credentials
from Okta Privileged Access via the AI Agent Connections API.

Supports two STS connection types:
- STS_VAULT_SECRET: Retrieves a secret value from Okta Privileged Access vault
- STS_SERVICE_ACCOUNT: Retrieves service account credentials (username/password)

Authentication follows the same dual-mode pattern as OktaAIAgentClient:
1. Admin-initiated: forwards the admin's Okta access token
2. Event-triggered: acquires a service app token via private_key_jwt

IMPORTANT: Never use httpx auth= parameter. Always pass Authorization headers directly.
"""

import logging
import os
import warnings
from typing import Dict, Optional

import httpx

from okta_agent_proxy.auth.okta_service_auth import OktaServiceAuth

logger = logging.getLogger(__name__)

_REQUEST_TIMEOUT = 15


class OktaSecretsClient:
    """Retrieves vaulted secrets and service account credentials
    from Okta Privileged Access via the AI Agent Connections API."""

    def __init__(self, service_auth: Optional[OktaServiceAuth] = None):
        self._service_auth = service_auth or OktaServiceAuth()
        domain = os.getenv("OKTA_DOMAIN", "").strip()
        if domain and not domain.startswith("http"):
            self._base_url = f"https://{domain}"
        else:
            self._base_url = domain.rstrip("/") if domain else ""

    async def _get_auth_headers(self, okta_token: Optional[str] = None) -> dict:
        """Build auth headers — same pattern as OktaAIAgentClient."""
        headers: Dict[str, str] = {
            "Accept": "application/json",
            "Content-Type": "application/json",
        }

        if okta_token:
            headers["Authorization"] = f"Bearer {okta_token}"
        else:
            token = await self._service_auth.get_access_token()
            if token:
                headers["Authorization"] = f"Bearer {token}"
            else:
                logger.warning("No auth available for Okta Secrets API call")

        return headers

    async def get_vault_secret(
        self,
        agent_id: str,
        connection_id: str,
        okta_token: Optional[str] = None,
    ) -> Optional[Dict]:
        """Retrieve a secret from an STS_VAULT_SECRET connection.

        .. deprecated::
            Use OktaVaultSecretExchanger.exchange_vault_secret() instead.

        POST {base}/workload-principals/api/v1/ai-agents/{agent_id}/connections/{connection_id}/secret

        Returns:
            {"value": "...", "name": "...", "path": "..."} or None on error.
        """
        warnings.warn(
            "OktaSecretsClient.get_vault_secret() is deprecated. "
            "Use OktaVaultSecretExchanger.exchange_vault_secret() instead.",
            DeprecationWarning,
            stacklevel=2,
        )
        if not self._base_url:
            logger.warning("OKTA_DOMAIN not configured, cannot retrieve vault secret")
            return None

        headers = await self._get_auth_headers(okta_token)
        url = (
            f"{self._base_url}/workload-principals/api/v1/ai-agents/"
            f"{agent_id}/connections/{connection_id}/secret"
        )

        try:
            async with httpx.AsyncClient(timeout=_REQUEST_TIMEOUT) as client:
                response = await client.post(url, headers=headers)
                if response.status_code in (200, 201):
                    data = response.json()
                    logger.info(
                        f"Vault secret retrieved for agent={agent_id} connection={connection_id}"
                    )
                    return data
                logger.warning(
                    f"get_vault_secret({agent_id}, {connection_id}) failed: "
                    f"{response.status_code} {response.text}"
                )
                return None
        except Exception as e:
            logger.warning(f"get_vault_secret({agent_id}, {connection_id}) error: {e}")
            return None

    async def get_service_account_credentials(
        self,
        agent_id: str,
        connection_id: str,
        okta_token: Optional[str] = None,
    ) -> Optional[Dict]:
        """Retrieve credentials from an STS_SERVICE_ACCOUNT connection.

        .. deprecated::
            Use OktaVaultSecretExchanger.exchange_service_account() instead.

        POST {base}/workload-principals/api/v1/ai-agents/{agent_id}/connections/{connection_id}/credentials

        Returns:
            {"username": "...", "password": "...", "app_name": "..."} or None on error.
        """
        warnings.warn(
            "OktaSecretsClient.get_service_account_credentials() is deprecated. "
            "Use OktaVaultSecretExchanger.exchange_service_account() instead.",
            DeprecationWarning,
            stacklevel=2,
        )
        if not self._base_url:
            logger.warning("OKTA_DOMAIN not configured, cannot retrieve service account credentials")
            return None

        headers = await self._get_auth_headers(okta_token)
        url = (
            f"{self._base_url}/workload-principals/api/v1/ai-agents/"
            f"{agent_id}/connections/{connection_id}/credentials"
        )

        try:
            async with httpx.AsyncClient(timeout=_REQUEST_TIMEOUT) as client:
                response = await client.post(url, headers=headers)
                if response.status_code in (200, 201):
                    data = response.json()
                    logger.info(
                        f"Service account credentials retrieved for agent={agent_id} "
                        f"connection={connection_id}"
                    )
                    return data
                logger.warning(
                    f"get_service_account_credentials({agent_id}, {connection_id}) failed: "
                    f"{response.status_code} {response.text}"
                )
                return None
        except Exception as e:
            logger.warning(
                f"get_service_account_credentials({agent_id}, {connection_id}) error: {e}"
            )
            return None
