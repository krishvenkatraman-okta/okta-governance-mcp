"""
Consent Verification Service.

Enumerates an agent's okta-sts resources and verifies STS consent
status for each, updating the ConsentTransaction in place.
"""

import logging
import time
from typing import Any, Dict, List, Optional

from jose import jwt as jose_jwt

from okta_agent_proxy.audit import emit_audit_event
from okta_agent_proxy.audit.events import AuditEventType, AuditSeverity
from okta_agent_proxy.auth.consent_transaction import (
    ConsentConnectionStatus,
    ConsentTransaction,
)

logger = logging.getLogger(__name__)


class ConsentVerificationService:
    """Verifies STS consent status for an agent's okta-sts resources."""

    def __init__(self, router, token_cache):
        self.router = router
        self.token_cache = token_cache

    def get_sts_resources(self, agent_id: str, agent_config: Dict) -> list:
        """Return all okta-sts resources visible to the agent."""
        result = []
        for name in self.router.list_resources():
            try:
                rc = self.router.resolve_resource(name, agent_id=agent_id)
            except Exception:
                continue
            if rc is None:
                continue
            if getattr(rc, "auth_method", "") == "okta-sts":
                result.append(rc)
        return result

    def filter_resources_by_target(self, resources: list, target_resource: Optional[str]) -> list:
        """Filter STS resources to those matching a target resource indicator.

        Match strategy (in order):
          1. Exact resource_indicator (ORN) match.
          2. Resource URL endswith the resource name (e.g. ".../hr" → "hr").
          3. Resource name exact match.

        Returns input list unchanged when target_resource is None.
        Returns empty list when target_resource is set but no match found.
        """
        if not target_resource:
            return resources

        target_lower = target_resource.lower().rstrip("/")
        matched = []

        for rc in resources:
            # Strategy 1: ORN match
            indicator = self._get_resource_indicator(rc)
            if indicator and indicator.lower() == target_lower:
                matched.append(rc)
                continue

            # Strategy 2: URL suffix match
            rc_name = (getattr(rc, "name", "") or "").lower()
            if rc_name and target_lower.endswith(f"/{rc_name}"):
                matched.append(rc)
                continue

            # Strategy 3: exact name match
            if rc_name and rc_name == target_lower:
                matched.append(rc)
                continue

        return matched

    async def verify_all(self, transaction: ConsentTransaction) -> None:
        """Enumerate STS resources and verify consent for each.

        If transaction.target_resource is set (RFC 8707), only the matching
        STS resource is verified. Otherwise all STS resources visible to the
        agent are verified (unified flow behavior).
        """
        all_resources = self.get_sts_resources(
            transaction.agent_id, transaction.agent_config
        )

        # Apply path scoping if target_resource was specified
        resources = self.filter_resources_by_target(
            all_resources, transaction.target_resource
        )

        if transaction.target_resource:
            logger.info(
                f"[Consent] Path-scoped verification for target_resource="
                f"{transaction.target_resource!r}: "
                f"{len(resources)}/{len(all_resources)} STS resources matched"
            )
        else:
            logger.info(
                f"[Consent] Multi-resource verification: "
                f"checking all {len(all_resources)} STS resources"
            )

        for rc in resources:
            conn = ConsentConnectionStatus(
                connection_id=getattr(rc, "connection_id", "") or "",
                resource_name=rc.name,
                provider=self._get_provider_name(rc),
                resource_indicator=self._get_resource_indicator(rc),
            )
            transaction.connections.append(conn)
            await self._check_one(conn, transaction)

        self._update_transaction_status(transaction)

        emit_audit_event(
            AuditEventType.STS_CONSENT_TX_CREATED,
            AuditSeverity.INFO,
            details={
                "transaction_id": transaction.transaction_id,
                "agent_id": transaction.agent_id,
                "connection_count": len(transaction.connections),
                "status": transaction.status,
                "target_resource": transaction.target_resource,
                "all_sts_count": len(all_resources),
            },
        )

    async def recheck_pending(self, transaction: ConsentTransaction) -> None:
        """Re-check connections that still require consent."""
        for conn in transaction.connections:
            if conn.status == "consent_required":
                conn.status = "checking"
                await self._check_one(conn, transaction)

        self._update_transaction_status(transaction)

        emit_audit_event(
            AuditEventType.STS_CONSENT_RECHECK,
            AuditSeverity.INFO,
            details={
                "transaction_id": transaction.transaction_id,
                "status": transaction.status,
            },
        )

    async def _check_one(
        self, conn: ConsentConnectionStatus, tx: ConsentTransaction
    ) -> None:
        """Check STS consent for a single connection."""
        from okta_agent_proxy.auth.okta_sts_exchanger import OktaSTSTokenExchanger
        from okta_agent_proxy.auth.resource_token_resolver import (
            ResourceTokenResolver,
        )

        try:
            creds = ResourceTokenResolver._extract_agent_credentials(tx.agent_config)
            exchanger = OktaSTSTokenExchanger(
                agent_id=creds.agent_id,
                client_id=creds.client_id,
                agent_private_key=creds.private_key,
                principal_id=creds.principal_id,
            )

            result = await exchanger.exchange(
                user_id_token=tx.id_token,
                resource_indicator=conn.resource_indicator,
                resource_name=conn.resource_name,
            )

            if result and result.get("status") == "success":
                conn.status = "verified"
                user_id = self._extract_user_id(tx.id_token)
                self.token_cache.set_sts_token(
                    user_id,
                    conn.resource_indicator,
                    result["access_token"],
                    result.get("expires_in", 28800),
                )
                emit_audit_event(
                    AuditEventType.STS_CONSENT_CHECK_SUCCESS,
                    AuditSeverity.INFO,
                    details={
                        "transaction_id": tx.transaction_id,
                        "connection_id": conn.connection_id,
                        "resource_name": conn.resource_name,
                    },
                )
            elif result and result.get("status") == "consent_required":
                conn.status = "consent_required"
                conn.interaction_uri = result.get("interaction_uri", "")
                emit_audit_event(
                    AuditEventType.STS_CONSENT_CHECK_REQUIRED,
                    AuditSeverity.INFO,
                    details={
                        "transaction_id": tx.transaction_id,
                        "connection_id": conn.connection_id,
                        "resource_name": conn.resource_name,
                        "interaction_uri": conn.interaction_uri,
                    },
                )
            else:
                conn.status = "error"
                conn.error_message = "Exchange returned no result"
                emit_audit_event(
                    AuditEventType.STS_CONSENT_CHECK_ERROR,
                    AuditSeverity.WARNING,
                    details={
                        "transaction_id": tx.transaction_id,
                        "connection_id": conn.connection_id,
                        "resource_name": conn.resource_name,
                        "error": conn.error_message,
                    },
                )
        except Exception as e:
            conn.status = "error"
            conn.error_message = str(e)
            emit_audit_event(
                AuditEventType.STS_CONSENT_CHECK_ERROR,
                AuditSeverity.WARNING,
                details={
                    "transaction_id": tx.transaction_id,
                    "connection_id": conn.connection_id,
                    "resource_name": conn.resource_name,
                    "error": str(e),
                },
            )

        conn.checked_at = time.time()

    @staticmethod
    def _update_transaction_status(tx: ConsentTransaction) -> None:
        if any(c.status == "consent_required" for c in tx.connections):
            tx.status = "consents_required"
        elif tx.all_resolved:
            tx.status = "complete"

    @staticmethod
    def _get_provider_name(resource) -> str:
        metadata = getattr(resource, "metadata", None)
        if isinstance(metadata, dict):
            return metadata.get("app_instance_name") or resource.name
        return resource.name

    @staticmethod
    def _get_resource_indicator(resource) -> str:
        metadata = getattr(resource, "metadata", None)
        if isinstance(metadata, dict):
            return (
                metadata.get("resource_indicator", "")
                or metadata.get("resource_orn", "")
            )
        return ""

    @staticmethod
    def _extract_user_id(id_token: str) -> str:
        try:
            claims = jose_jwt.get_unverified_claims(id_token)
            return claims.get("sub", "unknown")
        except Exception:
            return "unknown"
