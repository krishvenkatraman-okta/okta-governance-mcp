"""
Gateway Code Manager.

Manages the gateway authorization code lifecycle: issue, exchange, and
token tracking. Extracted from ConfidentialRelay for reuse by the
consent interstitial flow.

Supports two modes:
- Standalone: in-process dict/TTLCache only (backward compatible, single-pod)
- CacheService: local caches as L1 + CacheService as L2 backing store
"""

import logging
import secrets
from cachetools import TTLCache
from dataclasses import dataclass, field, asdict
from datetime import datetime, timezone
from typing import Any, Dict, Optional

from okta_agent_proxy.cache.serializers import (
    serialize_encrypted,
    deserialize_encrypted,
    serialize_json,
    deserialize_json,
)

logger = logging.getLogger(__name__)

# Key prefixes for CacheService entries
_CODE_PREFIX = "gateway_code:"
_TOKEN_PREFIX = "gateway_token:"

# Track whether the unencrypted-Redis warning has been issued
_unencrypted_warning_issued = False


# ---------------------------------------------------------------------------
# Errors
# ---------------------------------------------------------------------------
class GatewayCodeError(Exception):
    """Base error for gateway code operations."""


class GatewayCodeNotFound(GatewayCodeError):
    """No session found for the gateway code."""


class GatewayCodeExpired(GatewayCodeError):
    """Gateway code session has expired."""


class GatewayCodeClientMismatch(GatewayCodeError):
    """client_id does not match the session's original client."""


# ---------------------------------------------------------------------------
# Pending code session
# ---------------------------------------------------------------------------
@dataclass
class PendingCodeSession:
    gateway_code: str
    client_id: str
    access_token: Optional[str] = None
    id_token: Optional[str] = None
    refresh_token: Optional[str] = None
    expires_in: Optional[int] = None
    created_at: datetime = field(default_factory=lambda: datetime.now(timezone.utc))
    ttl_seconds: int = 300
    extra: Dict[str, Any] = field(default_factory=dict)

    @property
    def is_expired(self) -> bool:
        elapsed = (datetime.now(timezone.utc) - self.created_at).total_seconds()
        return elapsed > self.ttl_seconds

    def to_dict(self) -> dict:
        """Serialize to a JSON-safe dict (datetime → isoformat)."""
        d = asdict(self)
        d["created_at"] = self.created_at.isoformat()
        return d

    @classmethod
    def from_dict(cls, d: dict) -> "PendingCodeSession":
        """Deserialize from a dict (isoformat → datetime)."""
        d = dict(d)  # shallow copy
        ca = d.get("created_at")
        if isinstance(ca, str):
            d["created_at"] = datetime.fromisoformat(ca)
        return cls(**d)


# ---------------------------------------------------------------------------
# GatewayCodeManager
# ---------------------------------------------------------------------------
class GatewayCodeManager:
    """Manages gateway authorization codes and token tracking.

    When cache_service is provided, data is written to both local L1 caches
    and the shared L2 CacheService for cross-pod visibility.
    """

    def __init__(
        self,
        token_ttl: int = 3600,
        max_tokens: int = 10000,
        cache_service=None,
        encryption_service=None,
    ):
        self._sessions_by_code: Dict[str, PendingCodeSession] = {}
        self._sessions_by_token: TTLCache = TTLCache(maxsize=max_tokens, ttl=token_ttl)
        self._cache_service = cache_service
        self._encryption_service = encryption_service
        self._token_ttl = token_ttl

    # ------------------------------------------------------------------
    # Serialization helpers
    # ------------------------------------------------------------------

    def _serialize(self, data: dict) -> str:
        if self._encryption_service:
            return serialize_encrypted(data, self._encryption_service)
        return serialize_json(data)

    def _deserialize(self, raw: str) -> dict:
        if self._encryption_service:
            return deserialize_encrypted(raw, self._encryption_service)
        return deserialize_json(raw)

    def _warn_unencrypted_redis(self):
        """Log a one-time warning when writing to Redis without encryption."""
        global _unencrypted_warning_issued
        if _unencrypted_warning_issued:
            return
        if not self._cache_service or self._encryption_service:
            return
        try:
            from okta_agent_proxy.cache.redis_provider import RedisCacheProvider
            if isinstance(self._cache_service.l2, RedisCacheProvider):
                logger.warning(
                    "GatewayCodeManager: writing pending code to Redis WITHOUT "
                    "encryption — set ENCRYPTION_KEY to fix"
                )
                _unencrypted_warning_issued = True
        except ImportError:
            pass

    # ------------------------------------------------------------------
    # Async API (primary — used when cache_service is wired)
    # ------------------------------------------------------------------

    async def aissue_code(
        self,
        client_id: str,
        tokens: Dict[str, Any],
        ttl_seconds: int = 300,
        extra: Optional[Dict[str, Any]] = None,
    ) -> str:
        """Issue a gateway authorization code (async, L1+L2)."""
        code = secrets.token_hex(32)
        session = PendingCodeSession(
            gateway_code=code,
            client_id=client_id,
            access_token=tokens.get("access_token"),
            id_token=tokens.get("id_token"),
            refresh_token=tokens.get("refresh_token"),
            expires_in=tokens.get("expires_in"),
            ttl_seconds=ttl_seconds,
            extra=extra or {},
        )

        # L1
        self._sessions_by_code[code] = session

        # L2
        if self._cache_service:
            self._warn_unencrypted_redis()
            try:
                payload = self._serialize(session.to_dict())
                await self._cache_service.set(
                    f"{_CODE_PREFIX}{code}", payload, ttl_seconds=ttl_seconds
                )
            except Exception as e:
                logger.warning(f"GatewayCode: L2 write failed for code, L1-only: {e}")

        logger.info(f"GatewayCode: issued code {code[:8]}... for {client_id}")
        return code

    async def aexchange_code(self, code: str, client_id: str) -> dict:
        """Exchange a gateway code for tokens (async, single-use).

        Single-use semantics: L1 is popped atomically. When L2 is wired,
        we check whether L2 still has the code to prevent cross-pod
        double-exchange: if another pod already consumed the code via L2,
        L2 will be empty and we reject despite an L1 hit.
        """
        session = self._sessions_by_code.pop(code, None)

        if session is not None:
            if self._cache_service:
                # Cross-pod guard: if L2 no longer has the code, another pod
                # already consumed it — this L1 entry is stale.
                try:
                    l2_exists = await self._cache_service.exists(f"{_CODE_PREFIX}{code}")
                    if not l2_exists:
                        raise GatewayCodeNotFound(
                            "Gateway code already consumed by another pod"
                        )
                    await self._cache_service.delete(f"{_CODE_PREFIX}{code}")
                except GatewayCodeNotFound:
                    raise
                except Exception as e:
                    logger.warning(f"GatewayCode: L2 check/delete failed (best-effort): {e}")
        elif self._cache_service:
            # L1 miss — try L2
            try:
                raw = await self._cache_service.get(f"{_CODE_PREFIX}{code}")
                if raw is not None:
                    # Immediately delete from L2 before any further processing
                    try:
                        await self._cache_service.delete(f"{_CODE_PREFIX}{code}")
                    except Exception as e:
                        logger.warning(f"GatewayCode: L2 delete failed (best-effort): {e}")
                    session = PendingCodeSession.from_dict(self._deserialize(raw))
            except Exception as e:
                logger.warning(f"GatewayCode: L2 lookup failed: {e}")

        if session is None:
            raise GatewayCodeNotFound("No session found for gateway code")

        if session.is_expired:
            raise GatewayCodeExpired("Gateway code has expired")

        if session.client_id != client_id:
            raise GatewayCodeClientMismatch(
                f"client_id mismatch: expected '{session.client_id}', got '{client_id}'"
            )

        result: Dict[str, Any] = {
            "access_token": session.access_token,
            "id_token": session.id_token,
            "token_type": "Bearer",
        }
        if session.refresh_token:
            result["refresh_token"] = session.refresh_token
        if session.expires_in:
            result["expires_in"] = session.expires_in

        # Track issued access token
        if session.access_token:
            await self.atrack_token(
                session.access_token,
                session.client_id,
                id_token=session.id_token,
                refresh_token=session.refresh_token,
                expires_in=session.expires_in,
                **session.extra,
            )

        logger.info(f"GatewayCode: code exchanged for {client_id}")
        return result

    async def alookup_token(self, access_token: str) -> Optional[Dict[str, Any]]:
        """Look up info for a previously issued access token (async, L1→L2)."""
        # L1
        info = self._sessions_by_token.get(access_token)
        if info is not None:
            return info

        # L2
        if self._cache_service:
            try:
                raw = await self._cache_service.get(f"{_TOKEN_PREFIX}{access_token}")
                if raw is not None:
                    data = self._deserialize(raw)
                    # Restore datetime
                    if isinstance(data.get("created_at"), str):
                        data["created_at"] = datetime.fromisoformat(data["created_at"])
                    # Promote to L1
                    self._sessions_by_token[access_token] = data
                    return data
            except Exception as e:
                logger.warning(f"GatewayCode: L2 token lookup failed: {e}")

        return None

    async def atrack_token(self, access_token: str, client_id: str, **kwargs) -> None:
        """Track a token for later lookup (async, L1+L2)."""
        info = {
            "client_id": client_id,
            "created_at": datetime.now(timezone.utc),
            **kwargs,
        }
        # L1
        self._sessions_by_token[access_token] = info

        # L2
        if self._cache_service:
            try:
                # Serialize datetime for L2
                l2_info = dict(info)
                if isinstance(l2_info.get("created_at"), datetime):
                    l2_info["created_at"] = l2_info["created_at"].isoformat()
                payload = self._serialize(l2_info)
                await self._cache_service.set(
                    f"{_TOKEN_PREFIX}{access_token}", payload,
                    ttl_seconds=self._token_ttl,
                )
            except Exception as e:
                logger.warning(f"GatewayCode: L2 token write failed, L1-only: {e}")

    # ------------------------------------------------------------------
    # Sync API (backward compatibility — only for cache_service=None)
    # ------------------------------------------------------------------

    def issue_code(
        self,
        client_id: str,
        tokens: Dict[str, Any],
        ttl_seconds: int = 300,
        extra: Optional[Dict[str, Any]] = None,
    ) -> str:
        """Issue a gateway authorization code (sync, L1 only).

        Raises RuntimeError if cache_service is set — use aissue_code instead.
        """
        if self._cache_service:
            raise RuntimeError("sync API requires cache_service=None; use aissue_code")
        code = secrets.token_hex(32)
        session = PendingCodeSession(
            gateway_code=code,
            client_id=client_id,
            access_token=tokens.get("access_token"),
            id_token=tokens.get("id_token"),
            refresh_token=tokens.get("refresh_token"),
            expires_in=tokens.get("expires_in"),
            ttl_seconds=ttl_seconds,
            extra=extra or {},
        )
        self._sessions_by_code[code] = session
        logger.info(f"GatewayCode: issued code {code[:8]}... for {client_id}")
        return code

    def exchange_code(self, code: str, client_id: str) -> dict:
        """Exchange a gateway code for tokens (sync, one-time use).

        Raises RuntimeError if cache_service is set — use aexchange_code.
        """
        if self._cache_service:
            raise RuntimeError("sync API requires cache_service=None; use aexchange_code")
        session = self._sessions_by_code.get(code)
        if session is None:
            raise GatewayCodeNotFound("No session found for gateway code")

        if session.is_expired:
            del self._sessions_by_code[code]
            raise GatewayCodeExpired("Gateway code has expired")

        if session.client_id != client_id:
            raise GatewayCodeClientMismatch(
                f"client_id mismatch: expected '{session.client_id}', got '{client_id}'"
            )

        # One-time use
        del self._sessions_by_code[code]

        result: Dict[str, Any] = {
            "access_token": session.access_token,
            "id_token": session.id_token,
            "token_type": "Bearer",
        }
        if session.refresh_token:
            result["refresh_token"] = session.refresh_token
        if session.expires_in:
            result["expires_in"] = session.expires_in

        # Track issued access token for post-auth lookups
        if session.access_token:
            token_info: Dict[str, Any] = {
                "client_id": session.client_id,
                "created_at": session.created_at,
                "id_token": session.id_token,
                "refresh_token": session.refresh_token,
                "expires_in": session.expires_in,
            }
            token_info.update(session.extra)
            self._sessions_by_token[session.access_token] = token_info

        logger.info(f"GatewayCode: code exchanged for {client_id}")
        return result

    def lookup_token(self, access_token: str) -> Optional[Dict[str, Any]]:
        """Look up info for a previously issued access token (sync, L1 only)."""
        return self._sessions_by_token.get(access_token)

    def track_token(self, access_token: str, client_id: str, **kwargs) -> None:
        """Track a token for later lookup (sync, L1 only)."""
        self._sessions_by_token[access_token] = {
            "client_id": client_id,
            "created_at": datetime.now(timezone.utc),
            **kwargs,
        }

    # ------------------------------------------------------------------
    # Revocation
    # ------------------------------------------------------------------

    @staticmethod
    def _sub_from_info(info: Dict[str, Any]) -> Optional[str]:
        """Best-effort extraction of the user sub from a tracked token entry.

        Entries created by atrack_token / track_token may carry a sub directly
        (if wired by the caller) or an id_token we can decode.
        """
        if not info:
            return None
        sub = info.get("user_sub") or info.get("sub")
        if sub:
            return sub
        id_token = info.get("id_token")
        if not id_token:
            return None
        try:
            from jose import jwt as jose_jwt
            return jose_jwt.get_unverified_claims(id_token).get("sub")
        except Exception:
            return None

    async def arevoke_by_user(self, user_sub: str) -> int:
        """Drop every tracked access token that belongs to user_sub.

        Removes L1 entries and deletes the matching L2 keys. Also purges any
        pending authorization codes owned by the user.  Returns the count of
        access tokens removed.
        """
        # L1: _sessions_by_token
        to_remove_tokens = []
        for token, info in list(self._sessions_by_token.items()):
            if self._sub_from_info(info) == user_sub:
                to_remove_tokens.append(token)
        for token in to_remove_tokens:
            self._sessions_by_token.pop(token, None)

        # L1: _sessions_by_code (pending, not-yet-exchanged)
        to_remove_codes = []
        for code, session in list(self._sessions_by_code.items()):
            info = {
                "id_token": session.id_token,
                "refresh_token": session.refresh_token,
            }
            if self._sub_from_info(info) == user_sub:
                to_remove_codes.append(code)
        for code in to_remove_codes:
            self._sessions_by_code.pop(code, None)

        # L2: delete matching keys (best-effort; we only have the tokens we
        # knew about in L1 — a pod with its own L1 entry will purge on its
        # own, and unknown L2-only entries will expire naturally within
        # token_ttl).
        if self._cache_service:
            for token in to_remove_tokens:
                try:
                    await self._cache_service.delete(f"{_TOKEN_PREFIX}{token}")
                except Exception as e:
                    logger.warning(f"GatewayCode: L2 token delete failed for revoke: {e}")
            for code in to_remove_codes:
                try:
                    await self._cache_service.delete(f"{_CODE_PREFIX}{code}")
                except Exception as e:
                    logger.warning(f"GatewayCode: L2 code delete failed for revoke: {e}")

        if to_remove_tokens or to_remove_codes:
            logger.info(
                f"GatewayCode: revoked {len(to_remove_tokens)} tokens and "
                f"{len(to_remove_codes)} pending codes for sub={user_sub}"
            )
        return len(to_remove_tokens)

    def revoke_by_user(self, user_sub: str) -> int:
        """Sync variant: drops L1 entries only. Raises if cache_service is wired."""
        if self._cache_service:
            raise RuntimeError(
                "sync revoke_by_user requires cache_service=None; use arevoke_by_user"
            )
        to_remove_tokens = [
            t for t, info in list(self._sessions_by_token.items())
            if self._sub_from_info(info) == user_sub
        ]
        for token in to_remove_tokens:
            self._sessions_by_token.pop(token, None)
        to_remove_codes = [
            c for c, s in list(self._sessions_by_code.items())
            if self._sub_from_info({"id_token": s.id_token}) == user_sub
        ]
        for code in to_remove_codes:
            self._sessions_by_code.pop(code, None)
        return len(to_remove_tokens)
