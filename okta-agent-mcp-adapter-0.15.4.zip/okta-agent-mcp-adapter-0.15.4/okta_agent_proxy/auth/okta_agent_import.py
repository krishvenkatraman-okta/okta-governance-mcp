"""
Okta AI Agent Import — imports Okta AI Agent principals into the adapter
as gateway agent records with minimal stored state.

Stored per agent: agent_name (slugified), agent_id (=agent_name), client_id
(from linked app), okta_ai_agent_id, principal_id (=okta_ai_agent_id),
registration_source="okta-import", enabled (ACTIVE=true).

NOT stored: descriptions, owners, JWKs, full connection details.
"""

import asyncio
import json
import logging
import re
from dataclasses import dataclass, field
from typing import Dict, List, Optional

from okta_agent_proxy.audit import emit_audit_event, AuditEventType, AuditSeverity
from okta_agent_proxy.auth.okta_ai_agent_client import OktaAIAgentClient
from okta_agent_proxy.storage.base import ResourceConfigStore

logger = logging.getLogger(__name__)


@dataclass
class ImportableAgent:
    """An Okta AI Agent that can be imported into the adapter."""

    okta_agent_id: str
    name: str
    description: str
    status: str
    app_id: Optional[str]
    linked_app_client_id: Optional[str]
    connections_count: int
    already_imported: bool
    connections_by_type: Dict[str, int] = field(default_factory=dict)


@dataclass
class ImportResult:
    """Result of an agent import or sync operation."""

    success: bool
    agent_name: str
    okta_agent_id: str
    message: str
    resources_linked: List[str] = field(default_factory=list)
    warnings: List[str] = field(default_factory=list)


class OktaAgentImport:
    """Imports Okta AI Agent principals into the adapter's agent store."""

    def __init__(self, client: OktaAIAgentClient, store: ResourceConfigStore, resource_map_store=None):
        self._client = client
        self._store = store
        self._rm_store = resource_map_store

    # ------------------------------------------------------------------
    # list_importable_agents
    # ------------------------------------------------------------------

    async def list_importable_agents(
        self, okta_token: Optional[str] = None
    ) -> List[ImportableAgent]:
        """List Okta AI Agents with import status.

        Fetches all agents from Okta, then enriches each with connection count
        and linked app client_id via parallel lookups.
        """
        agents = await self._client.list_agents(okta_token)
        if not agents:
            return []

        # Build set of already-imported okta_ai_agent_ids
        imported_ids = self._get_imported_agent_ids()

        # Parallel lookups for connections and linked apps
        async def _enrich(agent: dict) -> ImportableAgent:
            agent_id = agent.get("id", "")
            app_id = agent.get("appId") or agent.get("app_id")
            # Okta nests name/description under "profile"
            profile = agent.get("profile", {})
            name = profile.get("name") or agent.get("name", "")
            description = profile.get("description") or agent.get("description", "")

            connections, linked_app = await asyncio.gather(
                self._client.get_agent_connections(agent_id, okta_token),
                self._client.get_linked_app(app_id, okta_token) if app_id else _noop(),
            )

            linked_client_id = None
            if linked_app and isinstance(linked_app, dict):
                creds = linked_app.get("credentials", {})
                oac = creds.get("oauthClient", {})
                linked_client_id = oac.get("client_id") or linked_app.get("client_id")

            # Count connections by type
            by_type: Dict[str, int] = {}
            for c in connections:
                ct = c.get("connectionType") or c.get("type", "UNKNOWN")
                by_type[ct] = by_type.get(ct, 0) + 1

            return ImportableAgent(
                okta_agent_id=agent_id,
                name=name,
                description=description,
                status=agent.get("status", ""),
                app_id=app_id,
                linked_app_client_id=linked_client_id,
                connections_count=len(connections),
                already_imported=agent_id in imported_ids,
                connections_by_type=by_type,
            )

        results = await asyncio.gather(*[_enrich(a) for a in agents])
        return list(results)

    # ------------------------------------------------------------------
    # import_agent
    # ------------------------------------------------------------------

    async def import_agent(
        self,
        okta_agent_id: str,
        okta_token: Optional[str] = None,
        resource_mapping: Optional[Dict[str, str]] = None,
        agent_name_override: Optional[str] = None,
    ) -> ImportResult:
        """Import a single Okta AI Agent into the adapter.

        Steps:
        1. Fetch agent details, linked app, and connections from Okta
        2. Match connections to resources via resource store
        3. Create or update agent record in the store
        """
        await emit_audit_event(
            AuditEventType.AGENT_IMPORT_STARTED,
            details={"okta_agent_id": okta_agent_id},
        )

        # Fetch agent
        agent = await self._client.get_agent(okta_agent_id, okta_token)
        if not agent:
            return ImportResult(
                success=False,
                agent_name="",
                okta_agent_id=okta_agent_id,
                message=f"Agent {okta_agent_id} not found in Okta",
            )

        profile = agent.get("profile", {})
        agent_name_raw = (
            agent_name_override
            or profile.get("name")
            or agent.get("name")
            or okta_agent_id
        )
        agent_name = self._slugify(agent_name_raw)
        warnings: List[str] = []

        # Fetch linked app for client_id
        app_id = agent.get("appId") or agent.get("app_id")
        client_id = None
        if app_id:
            linked_app = await self._client.get_linked_app(app_id, okta_token)
            if linked_app:
                creds = linked_app.get("credentials", {})
                oac = creds.get("oauthClient", {})
                client_id = oac.get("client_id") or linked_app.get("client_id")

        if not client_id:
            warnings.append("No linked OIDC app found — using okta_agent_id as client_id")
            client_id = okta_agent_id

        # Fetch connections and match to resources
        connections = await self._client.get_agent_connections(okta_agent_id, okta_token)
        resources_linked = self._match_connections_to_resources(
            connections, resource_mapping or {}
        )

        # Determine enabled status
        status = agent.get("status", "")
        enabled = status.upper() == "ACTIVE"
        if not enabled:
            warnings.append(f"Agent status is '{status}' — imported as disabled")

        warnings.append(
            "Private key not set — paste the JWK private key from "
            "Okta AI Agent config using the Configure button"
        )

        # Check if already exists (by okta_ai_agent_id)
        existing = self._find_agent_by_okta_id(okta_agent_id)

        config = {
            "agent_name": agent_name,
            "client_id": client_id,
            "scopes": ["mcp:read"],
            "enabled": enabled,
            "principal_id": okta_agent_id,
            "registration_source": "okta-import",
        }

        if existing:
            # Update — preserve agent_name, client_id, key from original import
            update_config = {
                "enabled": enabled,
            }
            self._store.update_agent(
                existing["agent_id"], update_config, user="okta-import"
            )
            # Also set okta_ai_agent_id if not yet set
            self._set_okta_ai_agent_id(existing["agent_id"], okta_agent_id)
            await emit_audit_event(
                AuditEventType.AGENT_IMPORT_COMPLETED,
                details={
                    "okta_agent_id": okta_agent_id,
                    "agent_id": existing["agent_name"],
                    "resources_linked": len(resources_linked),
                },
            )
            return ImportResult(
                success=True,
                agent_name=existing["agent_name"],
                okta_agent_id=okta_agent_id,
                message=f"Agent updated (already imported as '{existing['agent_name']}')",
                resources_linked=resources_linked,
                warnings=warnings,
            )

        # Create new agent
        try:
            created = self._store.create_agent(agent_name, config, user="okta-import")
        except Exception as e:
            await emit_audit_event(
                AuditEventType.AGENT_IMPORT_FAILED,
                severity=AuditSeverity.WARNING,
                details={"okta_agent_id": okta_agent_id, "error": str(e)},
                outcome="failure",
            )
            return ImportResult(
                success=False,
                agent_name=agent_name,
                okta_agent_id=okta_agent_id,
                message=f"Failed to create agent: {e}",
                warnings=warnings,
            )

        if not created:
            await emit_audit_event(
                AuditEventType.AGENT_IMPORT_FAILED,
                severity=AuditSeverity.WARNING,
                details={"okta_agent_id": okta_agent_id, "error": f"name '{agent_name}' may already exist"},
                outcome="failure",
            )
            return ImportResult(
                success=False,
                agent_name=agent_name,
                okta_agent_id=okta_agent_id,
                message=f"Agent creation failed (name '{agent_name}' may already exist)",
                warnings=warnings,
            )

        # Set okta_ai_agent_id on the newly created agent
        self._set_okta_ai_agent_id(agent_name, okta_agent_id)

        await emit_audit_event(
            AuditEventType.AGENT_IMPORT_COMPLETED,
            details={
                "okta_agent_id": okta_agent_id,
                "agent_id": agent_name,
                "resources_linked": len(resources_linked),
            },
        )
        return ImportResult(
            success=True,
            agent_name=agent_name,
            okta_agent_id=okta_agent_id,
            message=f"Agent '{agent_name}' imported successfully",
            resources_linked=resources_linked,
            warnings=warnings,
        )

    # ------------------------------------------------------------------
    # sync_agent
    # ------------------------------------------------------------------

    async def sync_agent(
        self, okta_agent_id: str, okta_token: Optional[str] = None
    ) -> ImportResult:
        """Sync an already-imported agent: update enabled status.

        Does NOT change agent_name, client_id, or signing key.
        """
        existing = self._find_agent_by_okta_id(okta_agent_id)
        if not existing:
            return ImportResult(
                success=False,
                agent_name="",
                okta_agent_id=okta_agent_id,
                message=f"Agent with okta_ai_agent_id={okta_agent_id} not found in store",
            )

        agent = await self._client.get_agent(okta_agent_id, okta_token)
        if not agent:
            return ImportResult(
                success=False,
                agent_name=existing["agent_name"],
                okta_agent_id=okta_agent_id,
                message=f"Agent {okta_agent_id} not found in Okta",
            )

        status = agent.get("status", "")
        enabled = status.upper() == "ACTIVE"
        warnings: List[str] = []
        if not enabled:
            warnings.append(f"Agent status is '{status}' — set to disabled")

        connections = await self._client.get_agent_connections(okta_agent_id, okta_token)
        resources_linked = self._match_connections_to_resources(connections, {})

        update_config = {
            "enabled": enabled,
        }
        self._store.update_agent(
            existing["agent_id"], update_config, user="okta-import-sync"
        )

        await emit_audit_event(
            AuditEventType.AGENT_SYNC_COMPLETED,
            details={
                "okta_agent_id": okta_agent_id,
                "agent_id": existing["agent_name"],
                "resources_linked": len(resources_linked),
            },
        )
        return ImportResult(
            success=True,
            agent_name=existing["agent_name"],
            okta_agent_id=okta_agent_id,
            message=f"Agent '{existing['agent_name']}' synced",
            resources_linked=resources_linked,
            warnings=warnings,
        )

    # ------------------------------------------------------------------
    # sync_agent_from_event
    # ------------------------------------------------------------------

    async def sync_agent_from_event(self, okta_agent_id: str) -> ImportResult:
        """Sync agent using service auth (no okta_token)."""
        return await self.sync_agent(okta_agent_id, okta_token=None)

    # ------------------------------------------------------------------
    # bulk_import
    # ------------------------------------------------------------------

    async def bulk_import(
        self,
        okta_agent_ids: List[str],
        okta_token: Optional[str] = None,
    ) -> List[ImportResult]:
        """Import multiple agents with concurrency limit."""
        sem = asyncio.Semaphore(5)

        async def _import_one(agent_id: str) -> ImportResult:
            async with sem:
                return await self.import_agent(agent_id, okta_token)

        return list(
            await asyncio.gather(*[_import_one(aid) for aid in okta_agent_ids])
        )

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    def _slugify(self, name: str) -> str:
        """Convert a display name to a URL-safe slug.

        "Demo AI Agent" → "demo-ai-agent"
        Appends -2, -3, etc. on collision.
        """
        slug = re.sub(r"[^a-z0-9]+", "-", name.lower()).strip("-")
        if not slug:
            slug = "agent"

        candidate = slug
        counter = 2
        while self._store.get_agent(candidate, enabled_only=False) is not None:
            candidate = f"{slug}-{counter}"
            counter += 1
        return candidate

    def _get_imported_agent_ids(self) -> set:
        """Return set of okta_ai_agent_id values already in the store."""
        all_agents = self._store.get_all_agents(enabled_only=False)
        return {
            a.get("okta_ai_agent_id")
            for a in all_agents
            if a.get("okta_ai_agent_id")
        }

    def _find_agent_by_okta_id(self, okta_agent_id: str) -> Optional[dict]:
        """Find an agent record by its okta_ai_agent_id."""
        all_agents = self._store.get_all_agents(enabled_only=False)
        for a in all_agents:
            if a.get("okta_ai_agent_id") == okta_agent_id:
                return a
        return None

    def _set_okta_ai_agent_id(self, agent_id: str, okta_agent_id: str) -> None:
        """Set okta_ai_agent_id and principal_id on an agent record."""
        try:
            self._store.update_agent(
                agent_id,
                {
                    "okta_ai_agent_id": okta_agent_id,
                    "principal_id": okta_agent_id,
                },
                user="okta-import",
            )
        except Exception as e:
            logger.warning(f"Failed to set okta_ai_agent_id on {agent_id}: {e}")

    def _match_connections_to_resources(
        self,
        connections: List[dict],
        resource_mapping: Dict[str, str],
    ) -> List[str]:
        """Match connections of all types to adapter resources.

        Handles all three production connection types:
        - IDENTITY_ASSERTION_CUSTOM_AS: match by authorizationServer ORN/ID
        - STS_VAULT_SECRET: match by secret ORN/ID
        - STS_SERVICE_ACCOUNT: match by serviceAccount ORN/ID

        Uses extract_resource_id_from_connection() for consistent parsing of
        nested objects (authorizationServer, secret, serviceAccount, app).

        resource_mapping overrides: {connection_name: resource_name}
        """
        from okta_agent_proxy.resources.utils import extract_resource_id_from_connection

        resources_linked: List[str] = []
        all_resources = self._store.get_all_resources()

        # Build resource_map-based lookup: resource_id → resource name(s)
        rm_store = self._rm_store
        if rm_store is None:
            try:
                from okta_agent_proxy.app import get_resource_store
                rm_store = get_resource_store()
            except Exception:
                pass

        for conn in connections:
            conn_type_str = conn.get("connectionType") or conn.get("type", "")
            conn_name = conn.get("name", "")

            # Explicit mapping takes priority
            if conn_name and conn_name in resource_mapping:
                mapped = resource_mapping[conn_name]
                if mapped not in resources_linked:
                    resources_linked.append(mapped)
                continue

            # Extract resource_id using shared utils (handles nested objects)
            resource_id, conn_type = extract_resource_id_from_connection(conn)

            if not resource_id:
                continue

            # Try resource_map store first (covers all connection types)
            if rm_store:
                entries = rm_store.get_by_id(resource_id)
                for entry in entries:
                    if entry.name not in resources_linked:
                        resources_linked.append(entry.name)
                if entries:
                    continue

            # Fallback: legacy auth_config matching for IDENTITY_ASSERTION_CUSTOM_AS
            if conn_type_str in ("IDENTITY_ASSERTION_CUSTOM_AS", "IDENTITY_ASSERTION_CUSTOM_AS"):
                for resource in all_resources:
                    auth_config = resource.get("auth_config", {})
                    if isinstance(auth_config, str):
                        try:
                            auth_config = json.loads(auth_config)
                        except Exception:
                            continue
                    target = auth_config.get("target_authorization_server", "")
                    if resource_id and resource_id in str(target):
                        rname = resource.get("name", "")
                        if rname and rname not in resources_linked:
                            resources_linked.append(rname)

        return resources_linked


async def _noop():
    """No-op coroutine for optional parallel lookups."""
    return None
