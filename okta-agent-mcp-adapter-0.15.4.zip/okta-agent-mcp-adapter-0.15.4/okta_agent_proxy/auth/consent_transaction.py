"""
Consent Transaction model and store.

Tracks the state of STS consent verification during the OAuth
authorization flow. Each transaction is bound to an httpOnly
session cookie and validated against IP/User-Agent.

Supports two modes:
- Standalone: In-process dicts only (backward compatible, single-pod)
- CacheService: In-process dicts as L1 fast-path + CacheService as L2
  backing store for cross-pod consistency in horizontal scaling.
"""

import json
import logging
import secrets
import time
import uuid
from dataclasses import dataclass, field
from typing import Any, Dict, List, Literal, Optional

from okta_agent_proxy.cache.serializers import (
    serialize_encrypted,
    deserialize_encrypted,
    serialize_json,
    deserialize_json,
)

logger = logging.getLogger(__name__)

# Key prefixes for CacheService L2 entries
_CONSENT_TX_PREFIX = "consent_tx:"
_CONSENT_SESSION_INDEX_PREFIX = "consent_session:"


# ---------------------------------------------------------------------------
# Connection-level consent status
# ---------------------------------------------------------------------------
@dataclass
class ConsentConnectionStatus:
    connection_id: str
    resource_name: str
    provider: str
    resource_indicator: str
    status: str = "pending"  # pending | checking | verified | consent_required | skipped | error
    interaction_uri: Optional[str] = None
    error_message: Optional[str] = None
    checked_at: Optional[float] = None  # epoch seconds (time.time())

    def to_dict(self) -> Dict[str, Any]:
        return {
            "connection_id": self.connection_id,
            "resource_name": self.resource_name,
            "provider": self.provider,
            "resource_indicator": self.resource_indicator,
            "status": self.status,
            "interaction_uri": self.interaction_uri,
            "error_message": self.error_message,
            "checked_at": self.checked_at,
        }

    @classmethod
    def from_dict(cls, d: Dict[str, Any]) -> "ConsentConnectionStatus":
        return cls(
            connection_id=d["connection_id"],
            resource_name=d["resource_name"],
            provider=d["provider"],
            resource_indicator=d["resource_indicator"],
            status=d.get("status", "pending"),
            interaction_uri=d.get("interaction_uri"),
            error_message=d.get("error_message"),
            checked_at=d.get("checked_at"),
        )


# ---------------------------------------------------------------------------
# Consent transaction
# ---------------------------------------------------------------------------
@dataclass
class ConsentTransaction:
    transaction_id: str
    session_id: str
    mode: Literal["oauth_return", "standalone"] = "oauth_return"
    original_redirect_uri: str = ""
    original_state: str = ""
    original_client_id: str = ""
    id_token: str = ""
    access_token: str = ""
    refresh_token: Optional[str] = None
    okta_expires_in: Optional[int] = None
    agent_id: str = ""
    agent_config: Dict[str, Any] = field(default_factory=dict)
    status: str = "verifying"  # verifying | consents_required | complete | expired | error
    connections: List[ConsentConnectionStatus] = field(default_factory=list)
    skip_requested: bool = False
    created_at: float = field(default_factory=time.time)
    relay_client_id: str = ""
    relay_client_secret: str = ""
    ip_address: str = ""
    user_agent_hash: str = ""
    ttl_seconds: int = 600
    # RFC 8707 Resource Indicator from the OAuth /authorize call.
    # When set, only this specific STS resource will be verified.
    # When None, all STS resources are verified (unified flow behavior).
    target_resource: Optional[str] = None

    @property
    def is_expired(self) -> bool:
        return (time.time() - self.created_at) > self.ttl_seconds

    @property
    def pending_consents(self) -> List[ConsentConnectionStatus]:
        return [c for c in self.connections if c.status == "consent_required"]

    @property
    def all_resolved(self) -> bool:
        return all(c.status in ("verified", "skipped", "error") for c in self.connections)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "transaction_id": self.transaction_id,
            "session_id": self.session_id,
            "mode": self.mode,
            "original_redirect_uri": self.original_redirect_uri,
            "original_state": self.original_state,
            "original_client_id": self.original_client_id,
            "id_token": self.id_token,
            "access_token": self.access_token,
            "refresh_token": self.refresh_token,
            "okta_expires_in": self.okta_expires_in,
            "agent_id": self.agent_id,
            "agent_config": self.agent_config,
            "status": self.status,
            "connections": [c.to_dict() for c in self.connections],
            "skip_requested": self.skip_requested,
            "created_at": self.created_at,
            "relay_client_id": self.relay_client_id,
            "relay_client_secret": self.relay_client_secret,
            "ip_address": self.ip_address,
            "user_agent_hash": self.user_agent_hash,
            "ttl_seconds": self.ttl_seconds,
            "target_resource": self.target_resource,
        }

    @classmethod
    def from_dict(cls, d: Dict[str, Any]) -> "ConsentTransaction":
        connections = [
            ConsentConnectionStatus.from_dict(c) for c in d.get("connections", [])
        ]
        return cls(
            transaction_id=d["transaction_id"],
            session_id=d["session_id"],
            mode=d.get("mode", "oauth_return"),
            original_redirect_uri=d.get("original_redirect_uri", ""),
            original_state=d.get("original_state", ""),
            original_client_id=d.get("original_client_id", ""),
            id_token=d.get("id_token", ""),
            access_token=d.get("access_token", ""),
            refresh_token=d.get("refresh_token"),
            okta_expires_in=d.get("okta_expires_in"),
            agent_id=d.get("agent_id", ""),
            agent_config=d.get("agent_config", {}),
            status=d.get("status", "verifying"),
            connections=connections,
            skip_requested=d.get("skip_requested", False),
            created_at=d.get("created_at", time.time()),
            relay_client_id=d.get("relay_client_id", ""),
            relay_client_secret=d.get("relay_client_secret", ""),
            ip_address=d.get("ip_address", ""),
            user_agent_hash=d.get("user_agent_hash", ""),
            ttl_seconds=d.get("ttl_seconds", 600),
            target_resource=d.get("target_resource"),
        )


# ---------------------------------------------------------------------------
# Store with optional CacheService L2 backing
# ---------------------------------------------------------------------------
class ConsentTransactionStore:
    """Store for consent transactions, indexed by ID and session.

    When cache_service is provided, async methods write/read from
    CacheService as an L2 backing store for cross-pod consistency.
    The in-process dicts remain as L1 fast-path.
    """

    def __init__(self, cache_service=None, encryption_service=None, event_bus=None):
        self._by_id: Dict[str, ConsentTransaction] = {}
        self._by_session: Dict[str, str] = {}  # session_id → transaction_id
        self._cache_service = cache_service
        self._enc = encryption_service
        self._event_bus = event_bus
        self._encryption_warned = False

        logger.info(
            "[CONSENT-STORE] Initialized (cache_service=%s, encrypted=%s, event_bus=%s)",
            "wired" if cache_service else "none",
            encryption_service is not None,
            "wired" if event_bus else "none",
        )

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _serialize(self, data: dict) -> str:
        if self._enc:
            return serialize_encrypted(data, self._enc)
        return serialize_json(data)

    def _deserialize(self, raw: str) -> dict:
        if self._enc:
            return deserialize_encrypted(raw, self._enc)
        return deserialize_json(raw)

    def _warn_no_encryption(self) -> None:
        """Log a one-time warning if L2 is active but encryption is missing."""
        if self._encryption_warned:
            return
        if self._cache_service and not self._enc:
            logger.warning(
                "[CONSENT-STORE] CacheService is wired but no encryption_service "
                "provided. Consent transactions containing tokens will be stored "
                "UNENCRYPTED in the L2 cache (Redis). Set ENCRYPTION_KEY to fix."
            )
            self._encryption_warned = True

    # ------------------------------------------------------------------
    # Sync API (L1 only — for unit tests and single-pod deployments)
    # ------------------------------------------------------------------

    def create(
        self,
        original_redirect_uri: str = "",
        original_state: str = "",
        original_client_id: str = "",
        id_token: str = "",
        access_token: str = "",
        refresh_token: Optional[str] = None,
        agent_id: str = "",
        agent_config: Optional[Dict[str, Any]] = None,
        ip_address: str = "",
        user_agent_hash: str = "",
        okta_expires_in: Optional[int] = None,
        relay_client_id: str = "",
        relay_client_secret: str = "",
        target_resource: Optional[str] = None,
        mode: Literal["oauth_return", "standalone"] = "oauth_return",
    ) -> ConsentTransaction:
        self._cleanup()

        transaction_id = str(uuid.uuid4())
        session_id = secrets.token_urlsafe(32)

        tx = ConsentTransaction(
            transaction_id=transaction_id,
            session_id=session_id,
            mode=mode,
            original_redirect_uri=original_redirect_uri,
            original_state=original_state,
            original_client_id=original_client_id,
            id_token=id_token,
            access_token=access_token,
            refresh_token=refresh_token,
            okta_expires_in=okta_expires_in,
            agent_id=agent_id,
            agent_config=agent_config or {},
            relay_client_id=relay_client_id,
            relay_client_secret=relay_client_secret,
            ip_address=ip_address,
            user_agent_hash=user_agent_hash,
            target_resource=target_resource,
        )

        self._by_id[transaction_id] = tx
        self._by_session[session_id] = transaction_id
        return tx

    def get_by_id(self, transaction_id: str) -> Optional[ConsentTransaction]:
        tx = self._by_id.get(transaction_id)
        if tx is None:
            return None
        if tx.is_expired:
            self.remove(transaction_id)
            return None
        return tx

    def get_by_session(self, session_id: str) -> Optional[ConsentTransaction]:
        tid = self._by_session.get(session_id)
        if tid is None:
            return None
        return self.get_by_id(tid)

    def validate_session(
        self, session_id: str, ip_address: str, user_agent_hash: str
    ) -> Optional[ConsentTransaction]:
        tx = self.get_by_session(session_id)
        if tx is None:
            return None

        if tx.ip_address and tx.ip_address != ip_address:
            logger.warning(
                "Consent session IP mismatch: expected %s, got %s (tx=%s)",
                tx.ip_address, ip_address, tx.transaction_id[:8],
            )
            return None

        if tx.user_agent_hash and tx.user_agent_hash != user_agent_hash:
            logger.warning(
                "Consent session UA mismatch (tx=%s)", tx.transaction_id[:8],
            )
            return None

        return tx

    def remove(self, transaction_id: str) -> None:
        tx = self._by_id.pop(transaction_id, None)
        if tx is not None:
            self._by_session.pop(tx.session_id, None)

    def _cleanup(self) -> None:
        expired = [tid for tid, tx in self._by_id.items() if tx.is_expired]
        for tid in expired:
            self.remove(tid)

    # ------------------------------------------------------------------
    # Async API (L1 + L2 for cross-pod consistency)
    # ------------------------------------------------------------------

    async def acreate(
        self,
        original_redirect_uri: str = "",
        original_state: str = "",
        original_client_id: str = "",
        id_token: str = "",
        access_token: str = "",
        refresh_token: Optional[str] = None,
        agent_id: str = "",
        agent_config: Optional[Dict[str, Any]] = None,
        ip_address: str = "",
        user_agent_hash: str = "",
        okta_expires_in: Optional[int] = None,
        relay_client_id: str = "",
        relay_client_secret: str = "",
        target_resource: Optional[str] = None,
        mode: Literal["oauth_return", "standalone"] = "oauth_return",
    ) -> ConsentTransaction:
        # Build via sync create (handles L1 + cleanup)
        tx = self.create(
            original_redirect_uri=original_redirect_uri,
            original_state=original_state,
            original_client_id=original_client_id,
            id_token=id_token,
            access_token=access_token,
            refresh_token=refresh_token,
            agent_id=agent_id,
            agent_config=agent_config,
            ip_address=ip_address,
            user_agent_hash=user_agent_hash,
            okta_expires_in=okta_expires_in,
            relay_client_id=relay_client_id,
            relay_client_secret=relay_client_secret,
            target_resource=target_resource,
            mode=mode,
        )

        # Write to L2
        if self._cache_service:
            self._warn_no_encryption()
            payload = self._serialize(tx.to_dict())
            await self._cache_service.set(
                f"{_CONSENT_TX_PREFIX}{tx.transaction_id}",
                payload,
                ttl_seconds=tx.ttl_seconds,
            )
            await self._cache_service.set(
                f"{_CONSENT_SESSION_INDEX_PREFIX}{tx.session_id}",
                tx.transaction_id,
                ttl_seconds=tx.ttl_seconds,
            )

        return tx

    async def aget_by_id(self, transaction_id: str) -> Optional[ConsentTransaction]:
        # L1 hit
        tx = self._by_id.get(transaction_id)
        if tx is not None:
            if tx.is_expired:
                await self.aremove(transaction_id)
                return None
            return tx

        # L2 fallback
        if self._cache_service:
            raw = await self._cache_service.get(f"{_CONSENT_TX_PREFIX}{transaction_id}")
            if raw is not None:
                data = self._deserialize(raw)
                tx = ConsentTransaction.from_dict(data)
                if tx.is_expired:
                    await self.aremove(transaction_id)
                    return None
                # Populate L1
                self._by_id[transaction_id] = tx
                self._by_session[tx.session_id] = transaction_id
                return tx

        return None

    async def aget_by_session(self, session_id: str) -> Optional[ConsentTransaction]:
        # L1 hit
        tid = self._by_session.get(session_id)
        if tid is not None:
            return await self.aget_by_id(tid)

        # L2 fallback: load session pointer
        if self._cache_service:
            tid = await self._cache_service.get(
                f"{_CONSENT_SESSION_INDEX_PREFIX}{session_id}"
            )
            if tid is not None:
                return await self.aget_by_id(tid)

        return None

    async def avalidate_session(
        self, session_id: str, ip_address: str, user_agent_hash: str
    ) -> Optional[ConsentTransaction]:
        tx = await self.aget_by_session(session_id)
        if tx is None:
            return None

        if tx.ip_address and tx.ip_address != ip_address:
            logger.warning(
                "Consent session IP mismatch: expected %s, got %s (tx=%s)",
                tx.ip_address, ip_address, tx.transaction_id[:8],
            )
            return None

        if tx.user_agent_hash and tx.user_agent_hash != user_agent_hash:
            logger.warning(
                "Consent session UA mismatch (tx=%s)", tx.transaction_id[:8],
            )
            return None

        return tx

    async def aremove(self, transaction_id: str) -> None:
        tx = self._by_id.pop(transaction_id, None)
        session_id = None
        if tx is not None:
            session_id = tx.session_id
            self._by_session.pop(session_id, None)

        if self._cache_service:
            await self._cache_service.delete(f"{_CONSENT_TX_PREFIX}{transaction_id}")
            if session_id:
                await self._cache_service.delete(
                    f"{_CONSENT_SESSION_INDEX_PREFIX}{session_id}"
                )

        if self._event_bus:
            try:
                from okta_agent_proxy.cache.pubsub import CHANNEL_CONSENT_TX_INVALIDATE
                await self._event_bus.publish(
                    CHANNEL_CONSENT_TX_INVALIDATE,
                    json.dumps({"v": 1, "key": transaction_id}),
                )
            except Exception as e:
                logger.warning(f"[CONSENT-STORE] Pub/sub publish failed: {e}")

    async def apersist(self, tx: ConsentTransaction) -> None:
        """Re-serialize and write the current tx state back to L1 and L2.

        Call this after any in-place mutation of a fetched ConsentTransaction
        (e.g. connection status changes) so the update is visible on other pods.
        """
        # Refresh L1
        self._by_id[tx.transaction_id] = tx
        self._by_session[tx.session_id] = tx.transaction_id

        # Write to L2
        if self._cache_service:
            payload = self._serialize(tx.to_dict())
            await self._cache_service.set(
                f"{_CONSENT_TX_PREFIX}{tx.transaction_id}",
                payload,
                ttl_seconds=tx.ttl_seconds,
            )
            await self._cache_service.set(
                f"{_CONSENT_SESSION_INDEX_PREFIX}{tx.session_id}",
                tx.transaction_id,
                ttl_seconds=tx.ttl_seconds,
            )
