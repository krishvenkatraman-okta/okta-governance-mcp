"""
Okta STS Token Exchanger — RFC 8693 token exchange for ISV access tokens.

Enables AI agents to obtain ISV access tokens (GitHub, Jira, Office 365)
brokered through Okta's Security Token Service. The exchange uses the Okta
ORG authorization server (/oauth2/v1/token), NOT a custom AS.

Two possible outcomes:
A) interaction_required — user has not consented at the ISV yet
B) access_token returned — user already consented, ISV token available
"""

import json
import logging
import os
import time
import uuid
from typing import Any, Dict, Optional

try:
    import httpx
except ImportError:
    httpx = None

try:
    from jose import jwt as jose_jwt
    from jose.backends import RSAKey
except ImportError:
    jose_jwt = None
    RSAKey = None

try:
    from okta_client.authfoundation import (
        OAuth2Client,
        OAuth2ClientConfiguration,
        LocalKeyProvider,
    )
    from okta_client.authfoundation.oauth2.jwt_bearer_claims import JWTBearerClaims
    from okta_client.authfoundation.oauth2.client_authorization import (
        ClientAssertionAuthorization,
    )
except ImportError:
    OAuth2Client = None
    OAuth2ClientConfiguration = None
    LocalKeyProvider = None
    JWTBearerClaims = None
    ClientAssertionAuthorization = None

# Lazy import to avoid circular dependency
from okta_agent_proxy.auth.adapter_cimd import AdapterCIMDServer  # noqa: E402

logger = logging.getLogger(__name__)

# RFC 8693 constants
GRANT_TYPE_TOKEN_EXCHANGE = "urn:ietf:params:oauth:grant-type:token-exchange"
REQUESTED_TOKEN_TYPE_STS = "urn:okta:params:oauth:token-type:oauth-sts"
SUBJECT_TOKEN_TYPE_ID_TOKEN = "urn:ietf:params:oauth:token-type:id_token"
CLIENT_ASSERTION_TYPE_JWT_BEARER = (
    "urn:ietf:params:oauth:client-assertion-type:jwt-bearer"
)


class OktaSTSTokenExchanger:
    """Exchanges user ID tokens for ISV access tokens via Okta STS.

    Uses RFC 8693 token exchange against the Okta ORG authorization server
    (/oauth2/v1/token) with a client_assertion (private_key_jwt).

    Usage:
        exchanger = OktaSTSTokenExchanger(...)
        result = await exchanger.exchange(user_id_token, resource_indicator)
    """

    def __init__(
        self,
        agent_id: str,
        client_id: str,
        agent_private_key,
        okta_domain: str = None,
        principal_id: str = None,
    ):
        """Initialize the STS Token Exchanger.

        Credential resolution follows the same pattern as OktaCrossAppAccessManager:
        agent credentials from DB, gateway fallback for placeholder keys.

        Args:
            agent_id: Agent identifier (from DB agent config)
            client_id: Okta OAuth app client ID (from DB agent config)
            agent_private_key: Private key in JWK JSON string (from DB).
                If None/PLACEHOLDER, falls back to gateway-level credentials.
            okta_domain: Okta domain (defaults to OKTA_DOMAIN env var)
            principal_id: Okta AI Agent ID for issuer/subject in JWT claims.
        """
        raw_domain = okta_domain or os.getenv("OKTA_DOMAIN", "").strip()
        if not raw_domain:
            raise ValueError(
                "OKTA_DOMAIN environment variable or parameter is required"
            )

        if raw_domain.startswith("http://"):
            self.okta_domain = raw_domain.replace("http://", "https://")
        elif raw_domain.startswith("https://"):
            self.okta_domain = raw_domain
        else:
            self.okta_domain = f"https://{raw_domain}"

        self.agent_id = agent_id
        self.client_id = client_id
        if not principal_id:
            raise ValueError(
                f"principal_id is required for STS token exchange "
                f"(agent_id={agent_id}). Import the agent from Okta to set "
                f"the principal_id automatically."
            )
        self.principal_id = principal_id
        self.token_endpoint = f"{self.okta_domain}/oauth2/v1/token"

        logger.debug(
            f"[STS] Init: agent_id={self.agent_id}, client_id={self.client_id}, "
            f"principal_id={self.principal_id}"
        )

        self._using_gateway_key = False
        _is_placeholder = self._is_placeholder_key(agent_private_key)
        agent_private_key_str = agent_private_key

        if _is_placeholder:
            agent_private_key_str = self._resolve_gateway_credentials()
        else:
            logger.info(
                f"[STS] Agent has own private key — using agent-specific "
                f"credentials (client_id={self.client_id})"
            )

        if not self.agent_id or not self.client_id or not agent_private_key_str:
            logger.warning(
                f"Agent credentials not fully configured. STS exchange disabled. "
                f"agent_id={self.agent_id}, client_id={self.client_id}, "
                f"has_key={bool(agent_private_key_str)}"
            )
            self._private_key = None
            self._oauth2_client = None
            return

        try:
            if isinstance(agent_private_key_str, str) and agent_private_key_str.startswith("{"):
                self._private_key = json.loads(agent_private_key_str)
            else:
                self._private_key = agent_private_key_str

            # Build SDK objects for client assertion (same pattern as XAA)
            if OAuth2Client and LocalKeyProvider:
                self._key_provider = LocalKeyProvider(
                    key=self._private_key,
                    algorithm=(
                        self._private_key.get("alg", "RS256")
                        if isinstance(self._private_key, dict)
                        else "RS256"
                    ),
                    key_id=(
                        self._private_key.get("kid")
                        if isinstance(self._private_key, dict)
                        else None
                    ),
                )
                self._jwt_claims = JWTBearerClaims(
                    issuer=self.principal_id,
                    subject=self.principal_id,
                    audience=self.token_endpoint,
                    expires_in=300,
                )
                self._client_config = OAuth2ClientConfiguration(
                    issuer=self.okta_domain,
                    client_authorization=ClientAssertionAuthorization(
                        assertion_claims=self._jwt_claims,
                        key_provider=self._key_provider,
                    ),
                )
                self._oauth2_client = OAuth2Client(
                    configuration=self._client_config
                )
            else:
                self._oauth2_client = None

            logger.info(
                f"[STS] OktaSTSTokenExchanger initialized "
                f"(okta_domain={self.okta_domain}, principal_id={self.principal_id})"
            )

        except Exception as e:
            logger.error(
                f"Failed to initialize OktaSTSTokenExchanger: {e}",
                exc_info=True,
            )
            raise

    @staticmethod
    def _is_placeholder_key(key) -> bool:
        """Check if a private key is missing or a placeholder value."""
        if not key:
            return True
        if isinstance(key, str):
            if key == "PLACEHOLDER" or "PLACEHOLDER" in key:
                return True
        if isinstance(key, dict) and key.get("n") == "PLACEHOLDER":
            return True
        return False

    def _resolve_gateway_credentials(self) -> Optional[str]:
        """Resolve gateway-level shared credentials for agents without their own keys.

        Tries two sources in order:
        1. Okta AI Agent env vars (OKTA_AI_AGENT_PRIVATE_KEY, _CLIENT_ID, _ID)
        2. Adapter CIMD signing key (legacy fallback)
        """
        ai_agent_key = os.getenv("OKTA_AI_AGENT_PRIVATE_KEY")
        ai_agent_client_id = os.getenv("OKTA_AI_AGENT_CLIENT_ID")
        ai_agent_id = os.getenv("OKTA_AI_AGENT_ID")

        if ai_agent_key and ai_agent_client_id and ai_agent_id:
            self.client_id = ai_agent_client_id
            self.agent_id = ai_agent_id
            self.principal_id = ai_agent_id
            self._using_gateway_key = True
            logger.info(
                f"[STS] Using Okta AI Agent gateway credentials "
                f"(client_id={self.client_id})"
            )
            return ai_agent_key

        try:
            adapter = AdapterCIMDServer()
            if ai_agent_id:
                self.agent_id = ai_agent_id
            self._using_gateway_key = True
            logger.info(
                f"[STS] Using adapter signing key (legacy) "
                f"(client_id={self.client_id})"
            )
            return json.dumps(adapter._private_jwk)
        except Exception as e:
            logger.debug(f"[STS] Could not fall back to gateway signing key: {e}")

        return None

    def build_client_assertion(self) -> str:
        """Build a signed JWT client assertion for the STS token exchange.

        Claims:
            iss: principal_id (Okta AI Agent ID)
            sub: principal_id
            aud: {okta_domain}/oauth2/v1/token (Org AS)
            exp: now + 300s
            iat: now
            jti: random UUID

        Returns:
            Signed JWT string (RS256)
        """
        if not self._private_key:
            raise ValueError("No private key available for client assertion")

        if not jose_jwt:
            raise ImportError(
                "python-jose is required for building client assertions. "
                "Install with: pip install python-jose[cryptography]"
            )

        now = int(time.time())
        claims = {
            "iss": self.principal_id,
            "sub": self.principal_id,
            "aud": self.token_endpoint,
            "exp": now + 300,
            "iat": now,
            "jti": str(uuid.uuid4()),
        }

        # python-jose accepts JWK dicts directly
        key_data = self._private_key
        if isinstance(key_data, str):
            key_data = json.loads(key_data)

        headers = {"alg": "RS256"}
        kid = key_data.get("kid") if isinstance(key_data, dict) else None
        if kid:
            headers["kid"] = kid

        return jose_jwt.encode(claims, key_data, algorithm="RS256", headers=headers)

    async def exchange(
        self,
        user_id_token: str,
        resource_indicator: str,
        resource_name: str = None,
    ) -> Optional[Dict[str, Any]]:
        """Exchange a user ID token for an ISV access token via Okta STS.

        Args:
            user_id_token: User's ID token from the linked Okta app
            resource_indicator: resourceIndicator ORN from the Managed Connection
            resource_name: Optional display name for logging/response

        Returns:
            Success: {"status": "success", "access_token": "...", "token_type": "Bearer",
                      "expires_in": 28800, "provider": resource_name}
            Consent: {"status": "consent_required", "interaction_uri": "https://...",
                      "provider": resource_name, "error_description": "..."}
            Error:   None
        """
        if not httpx:
            logger.error("[STS] httpx is required for STS token exchange")
            return None

        if not self._private_key:
            logger.error("[STS] No private key configured — STS exchange disabled")
            return None

        provider = resource_name or resource_indicator

        try:
            client_assertion = self.build_client_assertion()

            form_data = {
                "grant_type": GRANT_TYPE_TOKEN_EXCHANGE,
                "requested_token_type": REQUESTED_TOKEN_TYPE_STS,
                "subject_token": user_id_token,
                "subject_token_type": SUBJECT_TOKEN_TYPE_ID_TOKEN,
                "client_assertion_type": CLIENT_ASSERTION_TYPE_JWT_BEARER,
                "client_assertion": client_assertion,
                "resource": resource_indicator,
            }

            logger.info(
                f"[STS] Exchanging token for resource={provider}, "
                f"endpoint={self.token_endpoint}"
            )

            # IMPORTANT: Never use httpx auth= parameter — pass headers directly
            async with httpx.AsyncClient(timeout=30) as client:
                response = await client.post(
                    self.token_endpoint,
                    data=form_data,
                    headers={"Content-Type": "application/x-www-form-urlencoded"},
                )

            body = response.json()

            if response.status_code == 200 and "access_token" in body:
                expires_in = body.get("expires_in", 0)
                logger.info(
                    "sts_token_exchange",
                    extra={
                        "event": "sts_token_exchange",
                        "status": "success",
                        "agent_id": self.agent_id,
                        "resource_name": provider,
                        "using_gateway_key": self._using_gateway_key,
                        "expires_in": expires_in,
                    },
                )
                return {
                    "status": "success",
                    "access_token": body["access_token"],
                    "token_type": body.get("token_type", "Bearer"),
                    "expires_in": expires_in,
                    "provider": provider,
                }

            if response.status_code == 400 and body.get("error") == "interaction_required":
                interaction_uri = body.get("interaction_uri", "")
                error_desc = body.get("error_description", "")
                logger.info(
                    "sts_token_exchange",
                    extra={
                        "event": "sts_token_exchange",
                        "status": "consent_required",
                        "agent_id": self.agent_id,
                        "resource_name": provider,
                        "interaction_uri": interaction_uri,
                    },
                )
                return {
                    "status": "consent_required",
                    "interaction_uri": interaction_uri,
                    "provider": provider,
                    "error_description": error_desc,
                }

            # Unexpected error
            logger.error(
                f"[STS] Unexpected response: status={response.status_code}, "
                f"body={body}"
            )
            return None

        except Exception as e:
            logger.error(f"[STS] Token exchange failed: {e}", exc_info=True)
            return None
