"""
Resource Authentication Handlers

Supports six authentication patterns for target MCP servers:

1. okta-cross-app: ID-JAG (IETF draft)
   - Exchange enterprise token for resource-specific token
   - Each user gets unique resource token
   - Token cached per user+resource

2. pre-shared-key: Static API Key
   - Static key configured in gateway
   - Same key used for all requests
   - No token caching needed
   - Simple authentication

3. service-account: Service Account Credentials
   - Gateway authenticates as service account
   - Uses Basic Auth (username:password)
   - Same auth for all requests
   - No token caching needed

4. bearer-passthrough: Forward User Token
   - Passes the user's Okta Bearer token directly to the resource
   - No token exchange or caching needed
   - Useful when resource validates tokens independently or has auth disabled

5. vault-secret: Okta STS_VAULT_SECRET
   - Secret retrieved at runtime from Okta Privileged Access vault
   - Sent as Bearer token or custom header
   - Supports TTL-based refresh

6. sts-service-account: Okta STS_SERVICE_ACCOUNT
   - Credentials retrieved at runtime from Okta Privileged Access
   - Produces Basic Auth header from username/password
   - Supports TTL-based refresh
"""

import logging
from abc import ABC, abstractmethod
from typing import Optional, Dict, Any
import base64

logger = logging.getLogger(__name__)


class ResourceAuthHandler(ABC):
    """Abstract base class for resource authentication handlers"""
    
    @abstractmethod
    async def get_auth_headers(self) -> Dict[str, str]:
        """
        Get Authorization header(s) for resource request
        
        Returns:
            Dict with header name -> value
            e.g., {"Authorization": "Bearer token123"}
            or {"X-API-Key": "key123"}
        """
        pass
    
    @abstractmethod
    def requires_caching(self) -> bool:
        """
        Does this auth method require token caching?
        
        True for okta-cross-app (tokens expire)
        False for static keys/service accounts (always valid)
        """
        pass


class OktaCrossAppAuthHandler(ResourceAuthHandler):
    """
    Handler for Okta Cross-App Access (ID-JAG) authentication
    
    Step 1: Issue ID-JAG JWT from enterprise IdP
    Step 2: Exchange for access token at target auth server
    Token cached and reused until expiration
    """
    
    def __init__(self, access_token: str):
        """
        Initialize with already-exchanged access token
        
        Args:
            access_token: Token obtained from ID-JAG exchange
        """
        self.access_token = access_token
    
    async def get_auth_headers(self) -> Dict[str, str]:
        """
        Return Bearer token from ID-JAG exchange
        
        Returns:
            {"Authorization": "Bearer <access_token>"}
        """
        logger.debug("Using Okta Cross-App access token")
        return {
            "Authorization": f"Bearer {self.access_token}"
        }
    
    def requires_caching(self) -> bool:
        """ID-JAG tokens expire, so caching is needed"""
        return True


class PreSharedKeyAuthHandler(ResourceAuthHandler):
    """
    Handler for Pre-Shared Key authentication
    
    Static API key configured at gateway
    Same key used for all requests
    Simple, stateless authentication
    """
    
    def __init__(self, key: str, header_name: str = "X-API-Key"):
        """
        Initialize with static API key
        
        Args:
            key: Static API key/secret
            header_name: Header name to use (default: "X-API-Key")
        """
        self.key = key
        self.header_name = header_name
        logger.debug(f"Pre-Shared Key auth initialized with header: {header_name}")
    
    async def get_auth_headers(self) -> Dict[str, str]:
        """
        Return static API key header
        
        Returns:
            {header_name: key}
            e.g., {"X-API-Key": "api_key_123"}
        """
        logger.debug(f"Using pre-shared key in header: {self.header_name}")
        return {
            self.header_name: self.key
        }
    
    def requires_caching(self) -> bool:
        """Pre-shared keys don't expire, no caching needed"""
        return False


class ServiceAccountAuthHandler(ResourceAuthHandler):
    """
    Handler for Service Account authentication
    
    Gateway authenticates as service account
    Supports Basic Auth (username:password)
    No token caching needed
    """
    
    def __init__(self, username: str, password: str):
        """
        Initialize with service account credentials
        
        Args:
            username: Service account username/ID
            password: Service account password/secret
        """
        self.username = username
        self.password = password
        logger.debug(f"Service Account auth initialized for user: {username}")
    
    async def get_auth_headers(self) -> Dict[str, str]:
        """
        Return Basic Auth header (RFC 7617)
        
        Returns:
            {"Authorization": "Basic <base64(username:password)>"}
        """
        credentials = f"{self.username}:{self.password}"
        encoded = base64.b64encode(credentials.encode()).decode()
        logger.debug(f"Using service account Basic Auth for user: {self.username}")
        return {
            "Authorization": f"Basic {encoded}"
        }
    
    def requires_caching(self) -> bool:
        """Service account creds don't expire, no caching needed"""
        return False


class BearerPassthroughAuthHandler(ResourceAuthHandler):
    """
    Handler for Bearer token passthrough authentication.

    Forwards the user's original Okta Bearer token directly to the resource.
    Useful when the resource validates tokens independently (e.g., via JWKS verification)
    or has auth disabled for development (DEMO_OPS_DEPLOY_AUTH_DISABLED=true).
    """

    def __init__(self, user_token: str):
        self.user_token = user_token

    async def get_auth_headers(self) -> Dict[str, str]:
        logger.debug("Using bearer-passthrough (forwarding user token)")
        return {"Authorization": f"Bearer {self.user_token}"}

    def requires_caching(self) -> bool:
        return False


class VaultSecretAuthHandler(ResourceAuthHandler):
    """
    Handler for Okta STS_VAULT_SECRET authentication.

    Uses a secret value retrieved from Okta Privileged Access vault.
    The secret is injected at construction time (retrieved by the caller
    via OktaSecretsClient.get_vault_secret()).
    """

    def __init__(
        self,
        secret_value: str,
        header_name: str = "Authorization",
        header_prefix: str = "Bearer",
    ):
        """
        Initialize with a vault secret.

        Args:
            secret_value: The secret string from Okta Privileged Access.
            header_name: HTTP header name (default: "Authorization").
            header_prefix: Prefix before the value (default: "Bearer").
                Set to "" for raw value (e.g., API key).
        """
        self.secret_value = secret_value
        self.header_name = header_name
        self.header_prefix = header_prefix
        logger.debug(f"VaultSecret auth initialized (header={header_name})")

    async def get_auth_headers(self) -> Dict[str, str]:
        if self.header_prefix:
            return {self.header_name: f"{self.header_prefix} {self.secret_value}"}
        return {self.header_name: self.secret_value}

    def requires_caching(self) -> bool:
        return True


class StsServiceAccountAuthHandler(ResourceAuthHandler):
    """
    Handler for Okta STS_SERVICE_ACCOUNT authentication.

    Uses credentials retrieved from Okta Privileged Access.
    The credentials are injected at construction time (retrieved by the
    caller via OktaSecretsClient.get_service_account_credentials()).
    """

    def __init__(self, username: str, password: str):
        """
        Initialize with service account credentials from Okta PA.

        Args:
            username: Service account username.
            password: Service account password.
        """
        self.username = username
        self.password = password
        logger.debug(f"StsServiceAccount auth initialized for user: {username}")

    async def get_auth_headers(self) -> Dict[str, str]:
        credentials = f"{self.username}:{self.password}"
        encoded = base64.b64encode(credentials.encode()).decode()
        logger.debug(f"Using STS service account Basic Auth for user: {self.username}")
        return {"Authorization": f"Basic {encoded}"}

    def requires_caching(self) -> bool:
        return True


def create_auth_handler(
    auth_method: str,
    auth_config: Dict[str, Any],
    access_token: Optional[str] = None,
    user_token: Optional[str] = None,
) -> Optional[ResourceAuthHandler]:
    """
    Factory function to create appropriate auth handler

    Args:
        auth_method: One of "okta-cross-app", "pre-shared-key", "service-account",
            "bearer-passthrough", "vault-secret", "sts-service-account"
        auth_config: Auth configuration dict
        access_token: For okta-cross-app method, the already-exchanged token
        user_token: For bearer-passthrough method, the user's original token

    Returns:
        ResourceAuthHandler instance or None if method unknown
    """
    if auth_method == "bearer-passthrough":
        if not user_token:
            logger.error("bearer-passthrough requires user_token")
            return None
        return BearerPassthroughAuthHandler(user_token)

    if auth_method == "okta-cross-app":
        if not access_token:
            logger.error("okta-cross-app requires access_token")
            return None
        return OktaCrossAppAuthHandler(access_token)

    elif auth_method == "okta-sts":
        # STS brokered tokens use the same Bearer injection as okta-cross-app
        if not access_token:
            logger.error("okta-sts requires access_token")
            return None
        return OktaCrossAppAuthHandler(access_token)

    elif auth_method == "pre-shared-key":
        key = auth_config.get("key")
        if not key:
            logger.error("pre-shared-key requires 'key' in auth_config")
            return None
        header_name = auth_config.get("header_name", "X-API-Key")
        return PreSharedKeyAuthHandler(key, header_name)

    elif auth_method == "service-account":
        username = auth_config.get("username")
        password = auth_config.get("password")
        if not username or not password:
            logger.error("service-account requires 'username' and 'password' in auth_config")
            return None
        return ServiceAccountAuthHandler(username, password)

    elif auth_method == "vault-secret":
        secret_value = auth_config.get("secret_value")
        if not secret_value:
            logger.error("vault-secret requires 'secret_value' in auth_config")
            return None
        header_name = auth_config.get("header_name", "Authorization")
        header_prefix = auth_config.get("header_prefix", "Bearer")
        return VaultSecretAuthHandler(secret_value, header_name, header_prefix)

    elif auth_method == "sts-service-account":
        username = auth_config.get("username")
        password = auth_config.get("password")
        if not username or not password:
            logger.error("sts-service-account requires 'username' and 'password' in auth_config")
            return None
        return StsServiceAccountAuthHandler(username, password)

    else:
        logger.error(f"Unknown auth method: {auth_method}")
        return None

