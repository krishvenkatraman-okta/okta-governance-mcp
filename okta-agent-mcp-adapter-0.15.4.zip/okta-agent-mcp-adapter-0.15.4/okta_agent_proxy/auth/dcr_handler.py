"""
DCR (Dynamic Client Registration) Handler.

Orchestrates the full RFC 7591 registration flow:
1. Validate request via DCRPolicy
2. Provision relay-backed agent with placeholder credentials
3. Create agent and DCR registration records
4. Publish cache invalidation
5. Return RFC 7591 response

Agents start unlinked. The link_to_agent() method copies real Okta
credentials from a selectable imported agent, enabling token exchange.
"""

import json
import logging
import os
import secrets
import time
import uuid
from typing import List, Optional, Tuple

from okta_agent_proxy.audit import emit_audit_event, AuditEventType, AuditSeverity
from okta_agent_proxy.auth.dcr_policy import DCRPolicy

logger = logging.getLogger(__name__)

# Minimal JWK placeholder for agents created via DCR
# (a real deployment would generate a proper RSA or EC key)
_PLACEHOLDER_JWK = json.dumps({
    "kty": "oct",
    "k": "",
    "kid": "dcr-placeholder",
    "use": "sig",
})


class DCRHandler:
    """Orchestrates the full Dynamic Client Registration flow."""

    def __init__(
        self,
        *,
        dcr_policy: DCRPolicy,
        store,
        encryption_service=None,
        event_bus=None,
        ai_agent_promoter=None,
    ):
        self._policy = dcr_policy
        self._store = store
        self._encryption = encryption_service
        self._event_bus = event_bus
        self._ai_agent_promoter = ai_agent_promoter
        self._gateway_base_url = os.getenv("GATEWAY_BASE_URL", "http://localhost:8000")

    async def handle_registration(
        self,
        request_body: dict,
        source_ip: str,
        bearer_token: Optional[str] = None,
    ) -> Tuple[int, dict]:
        """Handle a DCR registration request.

        Args:
            request_body: The RFC 7591 registration request body.
            source_ip: Source IP of the registrant.
            bearer_token: Optional initial access token.

        Returns:
            (http_status_code, response_body) tuple.
        """
        result = await self._policy.validate(request_body, source_ip, bearer_token)
        if not result.allowed:
            await emit_audit_event(
                AuditEventType.DCR_REGISTRATION_REJECTED,
                severity=AuditSeverity.WARNING,
                details={
                    "source_ip": source_ip,
                    "reason": result.reason,
                    "client_name": request_body.get("client_name", ""),
                },
                outcome="failure",
            )
            return 400, {
                "error": "invalid_client_metadata",
                "error_description": result.reason,
            }
        return await self._provision(result.sanitized_body, source_ip)

    async def _provision(
        self, sanitized: dict, source_ip: str
    ) -> Tuple[int, dict]:
        """Create a relay-backed DCR client.

        CREDENTIAL SEPARATION:
        This method generates TWO distinct credentials:

        1. dcr_client_secret (returned to MCP client in RFC 7591 response):
           - Adapter-scoped, random token
           - Used by MCP client to authenticate to the adapter's token endpoint
           - Stored nowhere on the agent record (only in the RFC 7591 response)

        2. Linked Okta app client_secret (populated later by link_to_agent):
           - Stored AES-256-GCM encrypted on the DCR agent record
           - Used server-side only by ConfidentialRelay to talk to Okta
           - NEVER returned to or visible to the MCP client

        The dcr_client_id returned in the RFC 7591 response is also distinct
        from the Okta app client_id stored on the agent record after linking.
        """
        client_id = f"dcr_{uuid.uuid4().hex[:16]}"
        client_secret = secrets.token_urlsafe(48)
        issued_at = int(time.time())

        # No agent record is created — DCR registrations are lightweight.
        # Okta credentials come from the linked agent (set via link_to_agent).
        self._create_dcr_registration(
            client_id=client_id,
            client_name=sanitized["client_name"],
            agent_name=None,
            okta_app_id=None,
            redirect_uris=sanitized["redirect_uris"],
            grant_types=sanitized["grant_types"],
            provision_mode="relay",
            source_ip=source_ip,
        )

        # Best-effort AI Agent promotion (async, non-blocking)
        okta_ai_id = await self._try_promote(client_id, sanitized.get("client_name", ""))

        await emit_audit_event(
            AuditEventType.DCR_REGISTRATION,
            details={
                "dcr_client_id": client_id,
                "client_name": sanitized["client_name"],
                "source_ip": source_ip,
                "provision_mode": "relay",
                "linked": False,
                "okta_ai_agent_id": okta_ai_id,
            },
        )

        logger.info(
            "dcr_registration",
            extra={
                "event": "dcr_registration",
                "client_name": sanitized["client_name"],
                "client_id": client_id,
                "source_ip": source_ip,
                "provision_mode": "relay",
                "okta_ai_agent_id": okta_ai_id,
            },
        )

        return 201, self._build_rfc7591_response(
            client_id=client_id,
            client_secret=client_secret,
            client_id_issued_at=issued_at,
            client_secret_expires_at=0,
            sanitized=sanitized,
        )

    async def link_to_agent(
        self,
        dcr_client_id: str,
        target_agent_name: str,
        *,
        user: str = "admin",
    ) -> Tuple[bool, str]:
        """Link a DCR registration to an imported agent's Okta credentials.

        Args:
            dcr_client_id: The DCR-issued client_id.
            target_agent_name: The agent_name of the selectable agent to link to.
            user: The admin user performing the link.

        Returns:
            (success, message) tuple.
        """
        # Validate DCR registration
        registration = self._store.get_dcr_registration(dcr_client_id)
        if not registration:
            return False, "DCR registration not found"
        if registration.get("status") != "active":
            return False, "DCR registration is not active"

        # Validate target agent exists and is selectable
        target_agent = self._store.get_agent(target_agent_name, enabled_only=False)
        if not target_agent:
            return False, "Target agent not found"
        if not target_agent.get("dcr_selectable"):
            return False, "Target agent is not selectable for DCR linking"
        if not target_agent.get("client_id") or not target_agent.get("client_secret"):
            return False, "Target agent does not have Okta credentials"

        target_client_id = target_agent["client_id"]

        # Guard: the target agent's client_id must NOT be a DCR-issued id.
        # This prevents circular linking (a DCR agent linking to another DCR agent).
        if target_client_id.startswith("dcr_"):
            return False, (
                f"Target agent '{target_agent_name}' has a DCR-issued client_id. "
                f"Only agents with real Okta app credentials can be DCR link targets."
            )

        # Record the link on the DCR registration.
        # _resolve_dcr() looks up the linked agent's credentials at authorize time.
        self._store.update_dcr_registration_linked_agent(dcr_client_id, target_agent_name)

        await emit_audit_event(
            AuditEventType.DCR_AGENT_LINKED,
            details={
                "dcr_client_id": dcr_client_id,
                "target_agent_name": target_agent_name,
                "target_client_id_prefix": target_client_id[:8] + "...",
                "client_name": registration.get("client_name", ""),
                "credential_source": "linked_okta_app",
                "user": user,
            },
        )

        return True, f"Linked to agent {target_agent_name}"

    async def unlink_agent(
        self,
        dcr_client_id: str,
        *,
        user: str = "admin",
    ) -> Tuple[bool, str]:
        """Unlink a DCR registration from its linked agent.

        Clears the linked_agent_name on the DCR registration. No credential
        changes are needed on the DCR agent record since credentials are
        looked up from the linked agent at authorize time.

        Args:
            dcr_client_id: The DCR-issued client_id.
            user: The admin user performing the unlink.

        Returns:
            (success, message) tuple.
        """
        registration = self._store.get_dcr_registration(dcr_client_id)
        if not registration:
            return False, "DCR registration not found"

        previous_linked = registration.get("linked_agent_name")

        # Clear the link on the DCR registration
        self._store.update_dcr_registration_linked_agent(dcr_client_id, None)

        await emit_audit_event(
            AuditEventType.DCR_AGENT_UNLINKED,
            details={
                "dcr_client_id": dcr_client_id,
                "previous_linked_agent": previous_linked,
                "user": user,
            },
        )

        return True, "Agent unlinked"

    def get_selectable_agents(self) -> List[dict]:
        """Return agents with dcr_selectable=True and valid Okta credentials.

        Excludes agents whose client_id starts with ``dcr_`` to prevent
        circular linking (a DCR agent linking to another DCR agent).
        """
        all_agents = self._store.get_all_agents(enabled_only=False)
        return [
            {
                "agent_name": a.get("agent_name", ""),
                "agent_id": a.get("agent_id", ""),
                "registration_source": a.get("registration_source", ""),
                "principal_id": a.get("principal_id", ""),
            }
            for a in all_agents
            if a.get("dcr_selectable")
            and a.get("client_id")
            and a.get("client_secret")
            and not a.get("client_id", "").startswith("dcr_")
        ]

    def _create_dcr_registration(
        self,
        *,
        client_id: str,
        client_name: str,
        agent_name: str,
        okta_app_id: Optional[str],
        redirect_uris: list,
        grant_types: list,
        provision_mode: str,
        source_ip: str,
    ):
        """Create a DCR registration record in the store."""
        try:
            self._store.create_dcr_registration(
                client_id=client_id,
                client_name=client_name,
                agent_name=agent_name,
                okta_app_id=okta_app_id,
                redirect_uris=redirect_uris,
                grant_types=grant_types,
                provision_mode=provision_mode,
                source_ip=source_ip,
            )
        except Exception as e:
            logger.error(f"DCR: failed to create registration record: {e}")

    async def _publish_invalidation(self, agent_id: str):
        """Publish cache invalidation for the new agent."""
        if self._event_bus is not None:
            try:
                from okta_agent_proxy.cache.pubsub import CHANNEL_AGENT_INVALIDATE
                await self._event_bus.publish(CHANNEL_AGENT_INVALIDATE, agent_id)
            except Exception as e:
                logger.debug(f"DCR: cache invalidation publish failed: {e}")

    async def _try_promote(self, agent_name: str, client_name: str) -> Optional[str]:
        """Best-effort AI Agent promotion — never raises. Returns AI Agent ID or None."""
        if self._ai_agent_promoter is None:
            return None
        try:
            return await self._ai_agent_promoter.promote_to_okta(agent_name, client_name)
        except Exception as exc:
            logger.debug("AI Agent promotion failed (non-fatal): %s", exc)
            return None

    def _build_rfc7591_response(
        self,
        *,
        client_id: str,
        client_secret: str,
        client_id_issued_at: int,
        client_secret_expires_at: int,
        sanitized: dict,
    ) -> dict:
        """Build the RFC 7591 registration response."""
        return {
            "client_id": client_id,
            "client_secret": client_secret,
            "client_id_issued_at": client_id_issued_at,
            "client_secret_expires_at": client_secret_expires_at,
            "client_name": sanitized["client_name"],
            "redirect_uris": sanitized["redirect_uris"],
            "grant_types": sanitized["grant_types"],
            "response_types": sanitized.get("response_types", ["code"]),
            "token_endpoint_auth_method": sanitized.get(
                "token_endpoint_auth_method", "client_secret_basic"
            ),
            "registration_access_token": client_secret,
            "registration_client_uri": (
                f"{self._gateway_base_url}/.well-known/oauth/registration/{client_id}"
            ),
        }

    async def revoke_registration(
        self,
        client_id: str,
        *,
        user: str = "admin",
    ) -> Tuple[bool, str]:
        """Revoke a DCR registration.

        Args:
            client_id: The client_id of the registration to revoke.
            user: The admin user performing the revocation.

        Returns:
            (success, message) tuple.
        """
        registration = self._store.get_dcr_registration(client_id)
        if not registration:
            return False, "Registration not found"

        if registration.get("status") == "revoked":
            return False, "Registration already revoked"

        # Revoke the registration
        self._store.revoke_dcr_registration(client_id, user=user)

        await emit_audit_event(
            AuditEventType.DCR_REVOCATION,
            details={
                "client_id": client_id,
                "linked_agent_name": registration.get("linked_agent_name"),
                "user": user,
            },
        )

        return True, "Registration revoked"
