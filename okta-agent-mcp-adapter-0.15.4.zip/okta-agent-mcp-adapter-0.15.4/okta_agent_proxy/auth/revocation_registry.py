"""
User revocation registry.

When global logout cuts a user off, the relay's tracked-token map is purged
(see GatewayCodeManager.arevoke_by_user) but Okta-signed access tokens that
VS Code or any other MCP client is already holding remain cryptographically
valid until their natural ``exp``. This registry is consulted on the hot
request path so those still-unexpired tokens return 401 after logout.

Entries are keyed by Okta ``sub`` and TTL-bounded to at least the maximum
access-token lifetime (default 3600s).  Storage:

* L1 — in-process ``TTLCache`` (single-pod and unit tests)
* L2 — optional ``CacheService`` (cross-pod, same pattern as the other
  auth stores in this package)
* Pub/sub — when a ``CacheEventBus`` is wired, a ``CHANNEL_USER_LOGOUT``
  message is published so other pods prime their L1 immediately instead
  of waiting for the next L2 read.
"""

from __future__ import annotations

import json
import logging
import os
from typing import Optional

from cachetools import TTLCache

logger = logging.getLogger(__name__)

_REVOCATION_PREFIX = "revoked_sub:"
_DEFAULT_TTL = int(os.getenv("REVOCATION_REGISTRY_TTL", "3600"))
_DEFAULT_MAX_SIZE = int(os.getenv("REVOCATION_REGISTRY_MAX_SIZE", "100000"))


class RevocationRegistry:
    """Tracks recently revoked user subs so the hot path can short-circuit."""

    def __init__(
        self,
        ttl_seconds: int = _DEFAULT_TTL,
        max_size: int = _DEFAULT_MAX_SIZE,
        cache_service=None,
        event_bus=None,
    ):
        self._ttl = ttl_seconds
        self._cache: TTLCache = TTLCache(maxsize=max_size, ttl=ttl_seconds)
        self._cache_service = cache_service
        self._event_bus = event_bus

    def _l2_key(self, user_sub: str) -> str:
        return f"{_REVOCATION_PREFIX}{user_sub}"

    def is_revoked_sync(self, user_sub: str) -> bool:
        """L1-only synchronous check. Useful for pure-sync test paths."""
        if not user_sub:
            return False
        return user_sub in self._cache

    async def is_revoked(self, user_sub: str) -> bool:
        """L1 → L2 check. Returns True if the sub was revoked recently."""
        if not user_sub:
            return False
        if user_sub in self._cache:
            return True
        if self._cache_service:
            try:
                val = await self._cache_service.get(self._l2_key(user_sub))
                if val is not None:
                    # Prime L1 so subsequent requests avoid the L2 hop
                    self._cache[user_sub] = True
                    return True
            except Exception as e:
                logger.warning(f"[REVOCATION] L2 check failed: {e}")
        return False

    async def revoke(self, user_sub: str) -> None:
        """Mark user_sub as revoked in L1 + L2 and publish pub/sub fanout."""
        if not user_sub:
            return
        self._cache[user_sub] = True
        if self._cache_service:
            try:
                await self._cache_service.set(
                    self._l2_key(user_sub), "1", ttl_seconds=self._ttl
                )
            except Exception as e:
                logger.warning(f"[REVOCATION] L2 write failed, L1-only: {e}")
        if self._event_bus:
            try:
                from okta_agent_proxy.cache.pubsub import CHANNEL_USER_LOGOUT
                await self._event_bus.publish(
                    CHANNEL_USER_LOGOUT,
                    json.dumps({"v": 1, "key": user_sub}),
                )
            except Exception as e:
                logger.warning(f"[REVOCATION] Pub/sub publish failed: {e}")

    def note_revoked_local(self, user_sub: str) -> None:
        """Prime L1 only — used by pub/sub subscribers on peer pods."""
        if user_sub:
            self._cache[user_sub] = True


# ------------------------------------------------------------------
# Singleton accessor
# ------------------------------------------------------------------

_registry: Optional[RevocationRegistry] = None


def get_revocation_registry(
    cache_service=None,
    event_bus=None,
    ttl_seconds: Optional[int] = None,
) -> RevocationRegistry:
    """Return the process-wide RevocationRegistry, constructing on first use."""
    global _registry
    if _registry is None:
        _registry = RevocationRegistry(
            ttl_seconds=ttl_seconds if ttl_seconds is not None else _DEFAULT_TTL,
            cache_service=cache_service,
            event_bus=event_bus,
        )
    else:
        # Late-bind cache_service / event_bus if the singleton was built
        # during startup before Redis/pubsub were wired.
        if cache_service is not None and _registry._cache_service is None:
            _registry._cache_service = cache_service
        if event_bus is not None and _registry._event_bus is None:
            _registry._event_bus = event_bus
    return _registry


def reset_revocation_registry() -> None:
    """Test-only."""
    global _registry
    _registry = None
