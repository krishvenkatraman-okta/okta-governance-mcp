"""
Outbound DCR Client — dynamically registers the adapter as an OAuth client
with resource MCP servers that support RFC 7591 Dynamic Client Registration.

For resources with registration_strategy="dcr" or "auto", the adapter can
discover the resource's registration endpoint and register itself, storing
the resulting credentials for future use.

Configuration:
  The adapter's own CIMD metadata (from AdapterCIMDServer) is used as the
  registration request body.
"""

import dataclasses
import logging
from typing import Optional

import httpx

logger = logging.getLogger(__name__)


@dataclasses.dataclass
class OutboundRegistration:
    """Result of a successful outbound DCR registration."""
    client_id: str
    client_secret: Optional[str]
    registration_client_uri: Optional[str]


class OutboundDCRClient:
    """Registers the adapter with resource MCP servers via RFC 7591 DCR."""

    def __init__(self, adapter_cimd_server):
        """
        Args:
            adapter_cimd_server: AdapterCIMDServer instance providing the adapter's
                                 own client metadata for registration requests.
        """
        self._adapter_cimd = adapter_cimd_server

    async def register_with_resource(
        self, resource_url: str, registration_endpoint: str
    ) -> OutboundRegistration:
        """Register the adapter with a resource's DCR endpoint.

        Builds an RFC 7591 request body from the adapter's own CIMD metadata
        and POSTs it to the resource's registration_endpoint.

        Args:
            resource_url: The resource's base URL (for logging/context).
            registration_endpoint: The resource's DCR endpoint URL.

        Returns:
            OutboundRegistration with the assigned credentials.

        Raises:
            httpx.HTTPStatusError: If the registration request fails.
            ValueError: If the response is missing required fields.
        """
        metadata = self._adapter_cimd.get_client_metadata()

        # Build RFC 7591 registration request
        body = {
            "client_name": metadata["client_name"],
            "redirect_uris": metadata["redirect_uris"],
            "grant_types": metadata["grant_types"],
            "response_types": metadata["response_types"],
            "token_endpoint_auth_method": metadata["token_endpoint_auth_method"],
            "jwks_uri": metadata["jwks_uri"],
            "scope": metadata["scope"],
            "client_uri": metadata["client_uri"],
        }

        logger.info(
            f"Registering adapter with resource DCR endpoint: {registration_endpoint}"
        )

        async with httpx.AsyncClient() as client:
            response = await client.post(
                registration_endpoint,
                json=body,
                headers={"Content-Type": "application/json"},
                timeout=15,
            )
            response.raise_for_status()
            result = response.json()

        client_id = result.get("client_id")
        if not client_id:
            raise ValueError(
                f"DCR response from {registration_endpoint} missing client_id"
            )

        registration = OutboundRegistration(
            client_id=client_id,
            client_secret=result.get("client_secret"),
            registration_client_uri=result.get("registration_client_uri"),
        )

        logger.info(
            f"Successfully registered with resource {resource_url}: "
            f"client_id={registration.client_id}"
        )
        return registration

    async def discover_and_register(
        self, resource_url: str
    ) -> Optional[OutboundRegistration]:
        """Discover a resource's DCR endpoint and register.

        Fetches the resource's OAuth authorization server metadata to find
        the registration_endpoint, then calls register_with_resource.

        Args:
            resource_url: The target MCP server's base URL.

        Returns:
            OutboundRegistration if successful, None if no registration
            endpoint is found or registration fails.
        """
        registration_endpoint = await self._discover_registration_endpoint(resource_url)
        if not registration_endpoint:
            logger.info(f"No registration_endpoint found for {resource_url}")
            return None

        try:
            return await self.register_with_resource(resource_url, registration_endpoint)
        except Exception as e:
            logger.error(
                f"Failed to register with {resource_url}: {e}", exc_info=True
            )
            return None

    async def _discover_registration_endpoint(
        self, resource_url: str
    ) -> Optional[str]:
        """Fetch OAuth metadata from a resource to find its registration_endpoint.

        Tries /.well-known/oauth-authorization-server first, then falls back to
        /.well-known/openid-configuration.

        Returns:
            The registration_endpoint URL, or None if not found.
        """
        base = resource_url.rstrip("/")
        urls = [
            f"{base}/.well-known/oauth-authorization-server",
            f"{base}/.well-known/openid-configuration",
        ]

        async with httpx.AsyncClient() as client:
            for url in urls:
                try:
                    response = await client.get(url, timeout=10)
                    if response.status_code == 200:
                        data = response.json()
                        endpoint = data.get("registration_endpoint")
                        if endpoint:
                            logger.info(
                                f"Discovered registration_endpoint for {resource_url}: {endpoint}"
                            )
                            return endpoint
                except Exception as e:
                    logger.debug(f"Discovery failed for {url}: {e}")

        return None
