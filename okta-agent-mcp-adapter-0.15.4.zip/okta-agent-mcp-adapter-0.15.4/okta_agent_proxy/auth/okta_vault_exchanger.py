"""
Okta Vault Secret Exchanger — SDK-based token exchange for Privileged Access secrets.

Replaces direct HTTP calls (OktaSecretsClient) with the okta-client-python SDK's
TokenExchangeFlow for retrieving vault secrets and service account credentials
from Okta Privileged Access.

Uses RFC 8693 token exchange against the Okta ORG authorization server
(/oauth2/v1/token) with a client_assertion (private_key_jwt).

Credential resolution follows the same pattern as OktaCrossAppAccessManager:
agent credentials from DB, gateway fallback for placeholder keys.
"""

import json
import logging
import os
import time
import uuid
from typing import Any, Dict, Optional

try:
    import httpx
except ImportError:
    httpx = None

try:
    from jose import jwt as jose_jwt
except ImportError:
    jose_jwt = None

try:
    from okta_client.authfoundation import (
        OAuth2Client,
        OAuth2ClientConfiguration,
        LocalKeyProvider,
    )
    from okta_client.authfoundation.oauth2.jwt_bearer_claims import JWTBearerClaims
    from okta_client.authfoundation.oauth2.client_authorization import (
        ClientAssertionAuthorization,
    )
except ImportError:
    OAuth2Client = None
    OAuth2ClientConfiguration = None
    LocalKeyProvider = None
    JWTBearerClaims = None
    ClientAssertionAuthorization = None

# Lazy import to avoid circular dependency
from okta_agent_proxy.auth.adapter_cimd import AdapterCIMDServer  # noqa: E402

logger = logging.getLogger(__name__)

# RFC 8693 constants
GRANT_TYPE_TOKEN_EXCHANGE = "urn:ietf:params:oauth:grant-type:token-exchange"
REQUESTED_TOKEN_TYPE_VAULT = "urn:okta:params:oauth:token-type:vaulted-secret"
SUBJECT_TOKEN_TYPE_ID_TOKEN = "urn:ietf:params:oauth:token-type:id_token"
CLIENT_ASSERTION_TYPE_JWT_BEARER = "urn:ietf:params:oauth:client-assertion-type:jwt-bearer"


class OktaVaultSecretExchanger:
    """Exchanges user ID tokens for vault secrets via Okta STS TokenExchangeFlow.

    Uses the official okta-client-python SDK's TokenExchangeFlow against the
    Okta ORG authorization server (/oauth2/v1/token).

    Usage:
        exchanger = OktaVaultSecretExchanger(...)
        result = await exchanger.exchange_vault_secret(user_id_token, resource_orn)
    """

    def __init__(
        self,
        agent_id: str,
        client_id: str,
        agent_private_key,
        okta_domain: str = None,
        principal_id: str = None,
    ):
        """Initialize the Vault Secret Exchanger.

        Credential resolution follows the same pattern as OktaCrossAppAccessManager:
        agent credentials from DB, gateway fallback for placeholder keys.

        Args:
            agent_id: Agent identifier (from DB agent config)
            client_id: Okta OAuth app client ID (from DB agent config)
            agent_private_key: Private key in JWK JSON string (from DB).
                If None/PLACEHOLDER, falls back to gateway-level credentials.
            okta_domain: Okta domain (defaults to OKTA_DOMAIN env var)
            principal_id: Okta AI Agent ID for issuer/subject in JWT claims.
        """
        raw_domain = okta_domain or os.getenv("OKTA_DOMAIN", "").strip()
        if not raw_domain:
            raise ValueError(
                "OKTA_DOMAIN environment variable or parameter is required"
            )

        if raw_domain.startswith("http://"):
            self.okta_domain = raw_domain.replace("http://", "https://")
        elif raw_domain.startswith("https://"):
            self.okta_domain = raw_domain
        else:
            self.okta_domain = f"https://{raw_domain}"

        self.agent_id = agent_id
        self.client_id = client_id
        if not principal_id:
            raise ValueError(
                f"principal_id is required for vault secret exchange "
                f"(agent_id={agent_id}). Import the agent from Okta to set "
                f"the principal_id automatically."
            )
        self.principal_id = principal_id
        self.token_endpoint = f"{self.okta_domain}/oauth2/v1/token"

        logger.debug(
            f"[Vault] Init: agent_id={self.agent_id}, client_id={self.client_id}, "
            f"principal_id={self.principal_id}"
        )

        self._using_gateway_key = False
        _is_placeholder = self._is_placeholder_key(agent_private_key)
        agent_private_key_str = agent_private_key

        if _is_placeholder:
            agent_private_key_str = self._resolve_gateway_credentials()
        else:
            logger.info(
                f"[Vault] Agent has own private key — using agent-specific "
                f"credentials (client_id={self.client_id})"
            )

        if not self.agent_id or not self.client_id or not agent_private_key_str:
            logger.warning(
                f"Agent credentials not fully configured. Vault exchange disabled. "
                f"agent_id={self.agent_id}, client_id={self.client_id}, "
                f"has_key={bool(agent_private_key_str)}"
            )
            self._oauth2_client = None
            return

        try:
            if isinstance(agent_private_key_str, str) and agent_private_key_str.startswith("{"):
                self._private_key = json.loads(agent_private_key_str)
            else:
                self._private_key = agent_private_key_str

            if OAuth2Client and LocalKeyProvider:
                self._key_provider = LocalKeyProvider(
                    key=self._private_key,
                    algorithm=(
                        self._private_key.get("alg", "RS256")
                        if isinstance(self._private_key, dict)
                        else "RS256"
                    ),
                    key_id=(
                        self._private_key.get("kid")
                        if isinstance(self._private_key, dict)
                        else None
                    ),
                )
                self._jwt_claims = JWTBearerClaims(
                    issuer=self.principal_id,
                    subject=self.principal_id,
                    audience=self.token_endpoint,
                    expires_in=300,
                )
                self._client_config = OAuth2ClientConfiguration(
                    issuer=self.okta_domain,
                    client_authorization=ClientAssertionAuthorization(
                        assertion_claims=self._jwt_claims,
                        key_provider=self._key_provider,
                    ),
                )
                self._oauth2_client = OAuth2Client(
                    configuration=self._client_config
                )
            else:
                self._oauth2_client = None

            logger.info(
                f"[Vault] OktaVaultSecretExchanger initialized "
                f"(okta_domain={self.okta_domain}, principal_id={self.principal_id})"
            )

        except Exception as e:
            logger.error(
                f"Failed to initialize OktaVaultSecretExchanger: {e}",
                exc_info=True,
            )
            raise

    @staticmethod
    def _is_placeholder_key(key) -> bool:
        """Check if a private key is missing or a placeholder value."""
        if not key:
            return True
        if isinstance(key, str):
            if key == "PLACEHOLDER" or "PLACEHOLDER" in key:
                return True
        if isinstance(key, dict) and key.get("n") == "PLACEHOLDER":
            return True
        return False

    def _resolve_gateway_credentials(self) -> Optional[str]:
        """Resolve gateway-level shared credentials for agents without their own keys.

        Tries two sources in order:
        1. Okta AI Agent env vars (OKTA_AI_AGENT_PRIVATE_KEY, _CLIENT_ID, _ID)
        2. Adapter CIMD signing key (legacy fallback)
        """
        ai_agent_key = os.getenv("OKTA_AI_AGENT_PRIVATE_KEY")
        ai_agent_client_id = os.getenv("OKTA_AI_AGENT_CLIENT_ID")
        ai_agent_id = os.getenv("OKTA_AI_AGENT_ID")

        if ai_agent_key and ai_agent_client_id and ai_agent_id:
            self.client_id = ai_agent_client_id
            self.agent_id = ai_agent_id
            self.principal_id = ai_agent_id
            self._using_gateway_key = True
            logger.info(
                f"[Vault] Using Okta AI Agent gateway credentials "
                f"(client_id={self.client_id})"
            )
            return ai_agent_key

        try:
            adapter = AdapterCIMDServer()
            if ai_agent_id:
                self.agent_id = ai_agent_id
            self._using_gateway_key = True
            logger.info(
                f"[Vault] Using adapter signing key (legacy) "
                f"(client_id={self.client_id})"
            )
            return json.dumps(adapter._private_jwk)
        except Exception as e:
            logger.debug(f"[Vault] Could not fall back to gateway signing key: {e}")

        return None

    def build_client_assertion(self) -> str:
        """Build a signed JWT client assertion for the token exchange."""
        if not self._private_key:
            raise ValueError("No private key available for client assertion")
        if not jose_jwt:
            raise ImportError("python-jose is required for client assertions")

        now = int(time.time())
        claims = {
            "iss": self.principal_id,
            "sub": self.principal_id,
            "aud": self.token_endpoint,
            "exp": now + 300,
            "iat": now,
            "jti": str(uuid.uuid4()),
        }
        key_data = self._private_key
        if isinstance(key_data, str):
            key_data = json.loads(key_data)

        headers = {"alg": "RS256"}
        kid = key_data.get("kid") if isinstance(key_data, dict) else None
        if kid:
            headers["kid"] = kid

        return jose_jwt.encode(claims, key_data, algorithm="RS256", headers=headers)

    async def _raw_exchange(
        self, user_id_token: str, resource_orn: str, requested_token_type: str,
    ) -> Optional[Dict[str, Any]]:
        """Perform a raw RFC 8693 token exchange via httpx.

        Returns the full JSON response body from Okta, or None on error.
        Uses raw HTTP because Okta's vault secret response may not include
        an access_token field (which the SDK's Token class requires).
        """
        if not httpx:
            logger.error("[Vault] httpx is required for vault exchange")
            return None

        client_assertion = self.build_client_assertion()

        form_data = {
            "grant_type": GRANT_TYPE_TOKEN_EXCHANGE,
            "requested_token_type": requested_token_type,
            "subject_token": user_id_token,
            "subject_token_type": SUBJECT_TOKEN_TYPE_ID_TOKEN,
            "client_assertion_type": CLIENT_ASSERTION_TYPE_JWT_BEARER,
            "client_assertion": client_assertion,
            "resource": resource_orn,
        }

        async with httpx.AsyncClient(timeout=30) as client:
            response = await client.post(
                self.token_endpoint,
                data=form_data,
                headers={"Content-Type": "application/x-www-form-urlencoded"},
            )

        body = response.json()

        if response.status_code == 200:
            return body

        if response.status_code == 400 and body.get("error") == "interaction_required":
            return body

        # Unexpected error
        error_desc = body.get("error_description", body.get("error", ""))
        logger.error(
            f"[Vault] Okta returned {response.status_code}: {error_desc}"
        )
        return None

    async def exchange_vault_secret(
        self,
        user_id_token: str,
        resource_orn: str,
        resource_name: str = None,
    ) -> Optional[Dict[str, Any]]:
        """Exchange a user ID token for a vault secret via RFC 8693 token exchange.

        Args:
            user_id_token: User's ID token from Okta
            resource_orn: Resource ORN from the Managed Connection
            resource_name: Optional display name for logging/response

        Returns:
            Success: {"status": "success", "access_token": "...",
                      "expires_in": ..., "provider": resource_name}
            Consent: {"status": "consent_required", ...}
            Error:   None
        """
        if not self._private_key:
            logger.error("[Vault] No private key — vault exchange disabled")
            return None

        provider = resource_name or resource_orn

        try:
            logger.info(f"[Vault] Exchanging token for resource={provider}")

            body = await self._raw_exchange(
                user_id_token, resource_orn, REQUESTED_TOKEN_TYPE_VAULT,
            )

            if body is None:
                return None

            if body.get("error") == "interaction_required":
                logger.info(
                    "vault_secret_exchange",
                    extra={
                        "event": "vault_secret_exchange",
                        "status": "consent_required",
                        "agent_id": self.agent_id,
                        "resource_name": provider,
                    },
                )
                return {
                    "status": "consent_required",
                    "interaction_uri": body.get("interaction_uri", ""),
                    "provider": provider,
                    "error_description": body.get("error_description", ""),
                }

            # Okta vault secret responses use the 'vaulted_secret' field.
            # Fall back to other possible field names for compatibility.
            secret_value = (
                body.get("vaulted_secret")
                or body.get("access_token")
                or body.get("secret")
                or body.get("value")
                or body.get("token")
            )

            if not secret_value:
                logger.error(
                    f"[Vault] No secret value in response for {provider}. "
                    f"Response keys: {list(body.keys())}"
                )
                logger.debug(f"[Vault] Full response body: {json.dumps(body)}")
                return None

            expires_in = body.get("expires_in", 0)

            logger.info(
                "vault_secret_exchange",
                extra={
                    "event": "vault_secret_exchange",
                    "status": "success",
                    "agent_id": self.agent_id,
                    "resource_name": provider,
                    "using_gateway_key": self._using_gateway_key,
                    "expires_in": expires_in,
                },
            )

            return {
                "status": "success",
                "access_token": secret_value,
                "token_type": body.get("token_type", "Bearer"),
                "expires_in": expires_in,
                "provider": provider,
            }

        except Exception as e:
            logger.error(
                f"[Vault] Token exchange failed for {provider}: {e}",
                exc_info=True,
            )
            return None

    async def exchange_service_account(
        self,
        user_id_token: str,
        resource_orn: str,
        resource_name: str = None,
    ) -> Optional[Dict[str, Any]]:
        """Exchange a user ID token for service account credentials.

        Args:
            user_id_token: User's ID token from Okta
            resource_orn: Resource ORN from the Managed Connection
            resource_name: Optional display name for logging/response

        Returns:
            Success with creds: {"status": "success", "username": "...", "password": "...", ...}
            Success with token: {"status": "success", "access_token": "...", ...}
            Consent: {"status": "consent_required", ...}
            Error:   None
        """
        if not self._private_key:
            logger.error("[Vault] No private key — service account exchange disabled")
            return None

        provider = resource_name or resource_orn

        try:
            logger.info(f"[Vault] Exchanging token for service account resource={provider}")

            body = await self._raw_exchange(
                user_id_token, resource_orn, REQUESTED_TOKEN_TYPE_VAULT,
            )

            if body is None:
                return None

            if body.get("error") == "interaction_required":
                logger.info(
                    "vault_secret_exchange",
                    extra={
                        "event": "vault_secret_exchange",
                        "status": "consent_required",
                        "agent_id": self.agent_id,
                        "resource_name": provider,
                        "type": "service_account",
                    },
                )
                return {
                    "status": "consent_required",
                    "interaction_uri": body.get("interaction_uri", ""),
                    "provider": provider,
                    "error_description": body.get("error_description", ""),
                }

            # Check for direct username/password in response
            username = body.get("username")
            password = body.get("password")

            if username and password:
                logger.info(
                    "vault_secret_exchange",
                    extra={
                        "event": "vault_secret_exchange",
                        "status": "success",
                        "agent_id": self.agent_id,
                        "resource_name": provider,
                        "type": "service_account",
                    },
                )
                return {
                    "status": "success",
                    "username": username,
                    "password": password,
                    "provider": provider,
                }

            # Fall back to vaulted_secret / access_token / secret / value
            token_value = (
                body.get("vaulted_secret")
                or body.get("access_token")
                or body.get("secret")
                or body.get("value")
                or body.get("token")
            )

            if not token_value:
                logger.error(
                    f"[Vault] No credentials in response for {provider}. "
                    f"Response keys: {list(body.keys())}"
                )
                return None

            logger.info(
                "vault_secret_exchange",
                extra={
                    "event": "vault_secret_exchange",
                    "status": "success",
                    "agent_id": self.agent_id,
                    "resource_name": provider,
                    "type": "service_account_token",
                },
            )
            return {
                "status": "success",
                "access_token": token_value,
                "token_type": body.get("token_type", "Bearer"),
                "expires_in": body.get("expires_in", 0),
                "provider": provider,
            }

        except Exception as e:
            logger.error(
                f"[Vault] Service account exchange failed for {provider}: {e}",
                exc_info=True,
            )
            return None
