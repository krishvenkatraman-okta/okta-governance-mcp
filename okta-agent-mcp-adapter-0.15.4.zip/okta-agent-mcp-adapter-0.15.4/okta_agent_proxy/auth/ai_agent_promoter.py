"""
AI Agent Promoter — integrates with Okta for AI Agents (EA) to register
dynamically discovered clients as AI Agent principals in Universal Directory.

The Okta AI Agent Registration API (/api/v1/ai-agents) is Early Access and
the API surface may evolve.  All calls are behind feature flags and resilient
to API changes.

Configuration:
  OKTA_AI_AGENT_ID               — the adapter's own AI Agent ID
  OKTA_AI_AGENT_AUTO_REGISTER    — auto-promote DCR/CIMD agents (default: false)
  OKTA_AI_AGENT_DEFAULT_OWNER    — Okta user ID assigned as owner
  OKTA_DOMAIN                    — Okta org domain

Authentication:
  Uses OktaServiceAuth (private_key_jwt) when injected via constructor.
  Falls back to OKTA_API_TOKEN (SSWS) for backward compatibility.
"""

import logging
import os
from typing import Optional

import httpx

logger = logging.getLogger(__name__)


def _flag(name: str, default: bool = False) -> bool:
    return os.getenv(name, str(default)).lower() in ("true", "1", "yes")


class AIAgentPromoter:
    """Promotes dynamically registered clients to Okta AI Agent principals."""

    def __init__(self, store=None, service_auth=None):
        self._store = store
        self._service_auth = service_auth
        self._auto_register = _flag("OKTA_AI_AGENT_AUTO_REGISTER")
        self._adapter_agent_id = os.getenv("OKTA_AI_AGENT_ID", "")
        self._default_owner = os.getenv("OKTA_AI_AGENT_DEFAULT_OWNER", "")
        self._api_token = os.getenv("OKTA_API_TOKEN", "")

        domain = os.getenv("OKTA_DOMAIN", "").strip()
        if domain.startswith("https://"):
            self._base_url = domain.rstrip("/")
        elif domain.startswith("http://"):
            self._base_url = domain.rstrip("/")
        else:
            self._base_url = f"https://{domain}" if domain else ""

    # --------------------------------------------------------------------- #
    # Public API
    # --------------------------------------------------------------------- #

    async def promote_to_okta(
        self,
        agent_name: str,
        client_name: str,
        public_jwk: Optional[dict] = None,
    ) -> Optional[str]:
        """Promote a DCR/CIMD agent to an Okta AI Agent principal.

        Returns the Okta AI Agent ID on success, ``None`` on failure or if
        the feature is disabled.  All errors are logged but never raised.
        """
        if not self._auto_register:
            logger.debug(
                "AI Agent promotion skipped (OKTA_AI_AGENT_AUTO_REGISTER=%s)",
                self._auto_register,
            )
            return None

        if not self._base_url:
            logger.warning("AI Agent promotion skipped — OKTA_DOMAIN not set")
            return None

        headers = await self._auth_headers()
        if "Authorization" not in headers:
            logger.warning(
                "AI Agent promotion skipped — no auth available "
                "(set OKTA_SERVICE_CLIENT_ID or OKTA_API_TOKEN)"
            )
            return None

        try:
            async with httpx.AsyncClient() as client:
                # Step 1 — Create AI Agent
                resp = await client.post(
                    f"{self._base_url}/api/v1/ai-agents",
                    json={
                        "name": client_name,
                        "description": (
                            "Auto-registered by Okta MCP Adapter via DCR/CIMD"
                        ),
                    },
                    headers=headers,
                    timeout=15,
                )
                if resp.status_code not in (200, 201):
                    logger.warning(
                        "AI Agent creation failed: %s %s", resp.status_code, resp.text
                    )
                    return None

                body = resp.json()
                ai_agent_id = body.get("id") or body.get("ai_agent_id")
                if not ai_agent_id:
                    logger.warning("AI Agent response missing id: %s", body)
                    return None

                logger.info(
                    "Created Okta AI Agent %s for %s (STAGED)",
                    ai_agent_id,
                    client_name,
                )

                # Step 2 — Assign owner (best-effort)
                if self._default_owner:
                    await self._assign_owner(client, ai_agent_id, headers)

                # Step 3 — Add credential (best-effort)
                if public_jwk:
                    await self._add_credential(client, ai_agent_id, public_jwk, headers)

        except Exception as exc:
            logger.warning("AI Agent promotion error for %s: %s", agent_name, exc)
            return None

        # Step 4 — Persist in store
        self._update_store(agent_name, ai_agent_id)

        return ai_agent_id

    async def check_adapter_registration(self) -> bool:
        """Verify that the adapter's own AI Agent ID exists in Okta.

        Called once at startup.  Returns ``True`` if the agent is active,
        ``False`` otherwise.  The adapter should still start even on failure.
        """
        if not self._adapter_agent_id:
            logger.warning("OKTA_AI_AGENT_ID not set — cannot verify adapter registration")
            return False

        if not self._base_url:
            logger.warning("OKTA_DOMAIN not set — cannot verify adapter")
            return False

        try:
            headers = await self._auth_headers()
            if "Authorization" not in headers:
                logger.warning(
                    "No auth available for adapter verification "
                    "(set OKTA_SERVICE_CLIENT_ID or OKTA_API_TOKEN)"
                )
                return False
            async with httpx.AsyncClient() as client:
                resp = await client.get(
                    f"{self._base_url}/api/v1/ai-agents/{self._adapter_agent_id}",
                    headers=headers,
                    timeout=10,
                )

            if resp.status_code == 200:
                body = resp.json()
                status = body.get("status", "UNKNOWN")
                logger.info(
                    "Adapter AI Agent %s verified — status=%s",
                    self._adapter_agent_id,
                    status,
                )
                if status in ("DEACTIVATED", "DELETED"):
                    logger.error(
                        "Adapter AI Agent %s is %s — governance gap!",
                        self._adapter_agent_id,
                        status,
                    )
                    return False
                return True

            if resp.status_code == 404:
                logger.error(
                    "Adapter AI Agent %s not found in Okta — governance gap!",
                    self._adapter_agent_id,
                )
            else:
                logger.error(
                    "Failed to verify adapter AI Agent: %s %s",
                    resp.status_code,
                    resp.text,
                )
            return False

        except Exception as exc:
            logger.error("Error verifying adapter AI Agent: %s", exc)
            return False

    # --------------------------------------------------------------------- #
    # Internals
    # --------------------------------------------------------------------- #

    async def _auth_headers(self) -> dict:
        """Build auth headers, preferring service_auth (private_key_jwt) over SSWS."""
        headers = {
            "Accept": "application/json",
            "Content-Type": "application/json",
        }
        if self._service_auth:
            token = await self._service_auth.get_access_token()
            if token:
                headers["Authorization"] = f"Bearer {token}"
                return headers
        if self._api_token:
            headers["Authorization"] = f"SSWS {self._api_token}"
        return headers

    async def _assign_owner(
        self, client: httpx.AsyncClient, ai_agent_id: str, headers: dict
    ):
        try:
            resp = await client.post(
                f"{self._base_url}/api/v1/ai-agents/{ai_agent_id}/owners",
                json={"userId": self._default_owner},
                headers=headers,
                timeout=10,
            )
            if resp.status_code in (200, 201, 204):
                logger.info(
                    "Assigned owner %s to AI Agent %s",
                    self._default_owner,
                    ai_agent_id,
                )
            else:
                logger.warning(
                    "Owner assignment failed: %s %s", resp.status_code, resp.text
                )
        except Exception as exc:
            logger.warning("Owner assignment error: %s", exc)

    async def _add_credential(
        self,
        client: httpx.AsyncClient,
        ai_agent_id: str,
        public_jwk: dict,
        headers: dict,
    ):
        try:
            resp = await client.post(
                f"{self._base_url}/api/v1/ai-agents/{ai_agent_id}/credentials",
                json=public_jwk,
                headers=headers,
                timeout=10,
            )
            if resp.status_code in (200, 201):
                logger.info("Added credential to AI Agent %s", ai_agent_id)
            else:
                logger.warning(
                    "Credential addition failed: %s %s",
                    resp.status_code,
                    resp.text,
                )
        except Exception as exc:
            logger.warning("Credential addition error: %s", exc)

    def _update_store(self, agent_name: str, ai_agent_id: str):
        """Persist the AI Agent ID back to the store."""
        if not self._store:
            return
        try:
            self._store.update_agent(
                agent_name,
                {"okta_ai_agent_id": ai_agent_id},
                user="ai-agent-promoter",
            )
            logger.info(
                "Updated agent %s with okta_ai_agent_id=%s", agent_name, ai_agent_id
            )
        except Exception as exc:
            logger.warning("Failed to persist AI Agent ID for %s: %s", agent_name, exc)

        # Also update DCR registration if applicable
        try:
            self._store.update_dcr_registration_ai_agent_id(agent_name, ai_agent_id)
        except (AttributeError, Exception):
            pass  # Method may not exist or agent may not have a DCR record
