"""
Transparent id_token refresh for XAA.

When a stored id_token has expired, uses the stored refresh_token
to get fresh tokens from Okta. Updates the token store so the
agent's current access_token maps to the new id_token.
"""

import base64
import logging
import os
from typing import Optional

import httpx

from okta_agent_proxy.auth.user_token_store import UserTokenStore
from okta_agent_proxy.database import get_store

logger = logging.getLogger(__name__)


class TokenRefresher:
    """Refreshes expired id_tokens using stored refresh_tokens.

    When the XAA pipeline needs an id_token but the stored one has expired,
    this class transparently refreshes via Okta and updates the token store
    so the agent's current (old) access_token maps to the fresh id_token.
    """

    def __init__(self, token_store: UserTokenStore):
        self._store = token_store

    def _get_okta_token_url(self) -> str:
        """Build the Okta token endpoint URL from environment configuration."""
        okta_issuer = os.getenv("OKTA_ISSUER")
        if not okta_issuer:
            okta_domain = os.getenv("OKTA_DOMAIN", "").strip()
            okta_issuer = f"https://{okta_domain}"
        return f"{okta_issuer}/v1/token"

    @staticmethod
    def _build_basic_auth(client_id: str, client_secret: str) -> str:
        """Manually construct Basic auth header (DO NOT use httpx auth= parameter)."""
        credentials = f"{client_id}:{client_secret}"
        encoded = base64.b64encode(credentials.encode()).decode()
        return f"Basic {encoded}"

    async def refresh_id_token(self, access_token: str) -> Optional[str]:
        """Refresh the id_token for a given access_token.

        Looks up the stored entry, gets agent credentials, POSTs to Okta
        with grant_type=refresh_token, and updates the store.

        Returns the new id_token, or None if refresh is not possible.
        """
        # Look up stored entry
        entry = self._store.lookup(access_token)
        if not entry:
            logger.debug("[TOKEN-REFRESH] No stored entry for access_token")
            return None

        refresh_token = entry.get("refresh_token")
        if not refresh_token:
            logger.debug("[TOKEN-REFRESH] No refresh_token in stored entry")
            return None

        agent_id = entry.get("agent_id")
        user_sub = entry.get("user_sub", "unknown")

        # Get agent credentials from config store
        try:
            store = get_store()
            agent_config = store.get_agent(agent_id, enabled_only=True)
        except Exception as e:
            logger.warning(f"[TOKEN-REFRESH] Failed to get agent config for {agent_id}: {e}")
            return None

        if not agent_config:
            logger.warning(f"[TOKEN-REFRESH] Agent {agent_id} not found or disabled")
            return None

        client_id = agent_config.get("client_id")
        client_secret = agent_config.get("client_secret")
        if not client_id or not client_secret:
            logger.warning(f"[TOKEN-REFRESH] Agent {agent_id} missing client credentials")
            return None

        # POST to Okta token endpoint
        token_url = self._get_okta_token_url()
        auth_header = self._build_basic_auth(client_id, client_secret)

        try:
            async with httpx.AsyncClient() as client:
                resp = await client.post(
                    token_url,
                    headers={
                        "Authorization": auth_header,
                        "Content-Type": "application/x-www-form-urlencoded",
                    },
                    data={
                        "grant_type": "refresh_token",
                        "refresh_token": refresh_token,
                        "scope": "openid profile email offline_access",
                    },
                )
        except (httpx.HTTPError, OSError) as e:
            # Network error — do NOT remove the entry (transient failure)
            logger.warning(f"[TOKEN-REFRESH] Network error refreshing for user={user_sub}: {e}")
            return None

        if resp.status_code == 200:
            token_data = resp.json()
            new_id_token = token_data.get("id_token")
            new_access_token = token_data.get("access_token")
            new_refresh_token = token_data.get("refresh_token", "")
            new_expires_in = token_data.get("expires_in")

            if not new_id_token:
                logger.warning("[TOKEN-REFRESH] Okta response missing id_token")
                return None

            # Update the OLD access_token entry to point to the new id_token
            # (agent is still sending the old access_token)
            self._store.update(
                access_token,
                id_token=new_id_token,
                refresh_token=new_refresh_token,
            )

            # Also store a NEW access_token → new tokens mapping
            # (for when the agent eventually refreshes on its own)
            if new_access_token:
                self._store.store(
                    access_token=new_access_token,
                    id_token=new_id_token,
                    refresh_token=new_refresh_token,
                    user_sub=user_sub,
                    agent_id=agent_id,
                    expires_in=new_expires_in,
                )

            logger.info(
                f"[TOKEN-REFRESH] Refreshed id_token for user={user_sub}, "
                f"old AT mapped to new id_token"
            )
            return new_id_token

        if resp.status_code == 400:
            try:
                error_data = resp.json()
            except Exception:
                error_data = {}
            if error_data.get("error") == "invalid_grant":
                # Refresh token expired or revoked — remove the mapping
                self._store.remove(access_token)
                logger.info(
                    f"[TOKEN-REFRESH] Refresh token expired for user={user_sub}, "
                    f"removed mapping"
                )
                return None

        # Other error — log but don't remove entry
        logger.warning(
            f"[TOKEN-REFRESH] Okta returned {resp.status_code} for user={user_sub}"
        )
        return None


# ------------------------------------------------------------------
# Singleton accessor
# ------------------------------------------------------------------

_refresher: Optional[TokenRefresher] = None


def get_token_refresher() -> TokenRefresher:
    """Get or create the global TokenRefresher instance."""
    global _refresher
    if _refresher is None:
        from okta_agent_proxy.auth.user_token_store import get_user_token_store
        _refresher = TokenRefresher(token_store=get_user_token_store())
    return _refresher


def reset_token_refresher() -> None:
    """Reset the singleton (for testing)."""
    global _refresher
    _refresher = None
