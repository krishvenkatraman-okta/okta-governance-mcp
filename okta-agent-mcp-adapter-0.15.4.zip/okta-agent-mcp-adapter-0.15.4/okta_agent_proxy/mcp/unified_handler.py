"""
Unified MCP Handler

Serves as a single MCP endpoint at POST / that consolidates tools from all
resources an authenticated agent has access to. Enables MCP clients like Claude Code
that connect to a single URL and expect a unified tools/list.

Flow:
- initialize: Returns gateway capabilities (no auth needed)
- tools/list: Discovers tools from all accessible resources, namespaces them
- tools/call: Routes namespaced tool calls to the correct resource
- Other methods: Returns empty lists or errors as appropriate
"""

import logging
import json
import os
import time
import uuid
from typing import Dict, Any, Optional, List, Tuple

import httpx
import cachetools

from okta_agent_proxy import __version__
from okta_agent_proxy.auth.okta_validator import OktaTokenValidator
from okta_agent_proxy.auth.okta_vault_exchanger import OktaVaultSecretExchanger
from okta_agent_proxy.auth.resource_auth import create_auth_handler
from okta_agent_proxy.auth.resource_token_resolver import ResourceTokenResolver
from okta_agent_proxy.config import GatewaySettings
from okta_agent_proxy.middleware.auth import extract_bearer_token
from okta_agent_proxy.routing.router import ResourceRouter
from okta_agent_proxy.storage import ResourceConfigStore
from okta_agent_proxy.cache.serializers import serialize_json, deserialize_json
from okta_agent_proxy.audit import emit_audit_event, AuditEventType, AuditSeverity
from okta_agent_proxy.audit.context import agent_id_var, user_id_var, client_id_var

logger = logging.getLogger(__name__)

NAMESPACE_SEPARATOR = "__"

_TOOL_CACHE_PREFIX = "tool_catalog:"
_SESSION_PREFIX = "session:unified:"


def _parse_sse_response(text: str) -> Optional[Dict[str, Any]]:
    """Parse SSE response to extract JSON-RPC result from data: lines."""
    last_data = None
    for line in text.strip().split("\n"):
        line = line.strip()
        if line.startswith("data: "):
            try:
                last_data = json.loads(line[6:])
            except json.JSONDecodeError:
                continue
        elif line.startswith("data:") and len(line) > 5:
            try:
                last_data = json.loads(line[5:])
            except json.JSONDecodeError:
                continue
    return last_data


class UnifiedMCPHandler:
    """
    Handles MCP JSON-RPC requests at the root path (POST /).

    Consolidates tools from all resources the authenticated agent can access,
    namespacing tool names as {resource_name}__{tool_name}.
    """

    def __init__(
        self,
        router: ResourceRouter,
        validator: OktaTokenValidator,
        store: ResourceConfigStore,
        http_timeout: float = 30.0,
        cache_service=None,
        relay=None,
        client_registry=None,
    ):
        self.router = router
        self.validator = validator
        self.store = store
        self.http_timeout = http_timeout
        self._cache_service = cache_service
        self._relay = relay
        self._client_registry = client_registry

        # Fallback local caches (used when cache_service is None)
        # Cache: agent_id -> {"tools": [...], "tool_map": {namespaced_name: (resource_name, original_name)}}
        self._tool_cache: cachetools.TTLCache = cachetools.TTLCache(maxsize=100, ttl=300)

        # Resource session cache: "{user_id}:{resource_url}" -> session_id
        # User-scoped so GlobalLogoutHandler can terminate a single user's
        # backend MCP sessions without affecting other users on the same pod.
        # For flows where we don't yet have a user (initialize probes, tests),
        # user_id falls back to "_anon".
        self._resource_sessions: cachetools.TTLCache = cachetools.TTLCache(maxsize=1000, ttl=3600)

        mode = "CacheService" if cache_service else "standalone"
        logger.info(f"UnifiedMCPHandler initialized: mode={mode}")

    # ---- CacheService helpers ----

    async def _get_tool_catalog(self, agent_id: str) -> Optional[Dict]:
        """Get cached tool catalog from CacheService or local cache."""
        if self._cache_service:
            try:
                raw = await self._cache_service.get(f"{_TOOL_CACHE_PREFIX}{agent_id}")
                if raw is not None:
                    data = deserialize_json(raw)
                    # Reconstruct tool_map tuples from JSON lists
                    tool_map = {k: tuple(v) for k, v in data.get("tool_map", {}).items()}
                    return {"tools": data["tools"], "tool_map": tool_map}
            except Exception as e:
                logger.warning(f"CacheService get failed for tool catalog {agent_id}: {e}")

        if agent_id in self._tool_cache:
            return self._tool_cache[agent_id]
        return None

    async def get_cached_catalog(self, agent_id: str) -> Optional[Dict]:
        """Public accessor for the cached tool catalog (admin API, introspection)."""
        return await self._get_tool_catalog(agent_id)

    async def _set_tool_catalog(self, agent_id: str, catalog: Dict) -> None:
        """Store tool catalog in CacheService and local cache."""
        if self._cache_service:
            try:
                # Convert tool_map tuples to lists for JSON serialization
                serializable = {
                    "tools": catalog["tools"],
                    "tool_map": {k: list(v) for k, v in catalog["tool_map"].items()},
                }
                raw = serialize_json(serializable)
                await self._cache_service.set(
                    f"{_TOOL_CACHE_PREFIX}{agent_id}", raw, ttl_seconds=300
                )
            except Exception as e:
                logger.warning(f"CacheService set failed for tool catalog {agent_id}: {e}")

        # Always store in local cache too (L1-style)
        self._tool_cache[agent_id] = catalog

    @staticmethod
    def _session_cache_key(user_id: Optional[str], resource_url: str) -> str:
        return f"{user_id or '_anon'}:{resource_url}"

    async def _get_session(
        self, resource_url: str, user_id: Optional[str] = None
    ) -> Optional[str]:
        """Get cached resource session ID from CacheService or local cache."""
        cache_key = self._session_cache_key(user_id, resource_url)
        if self._cache_service:
            try:
                raw = await self._cache_service.get(f"{_SESSION_PREFIX}{cache_key}")
                if raw is not None:
                    return raw
            except Exception as e:
                logger.warning(f"CacheService get failed for session {cache_key}: {e}")

        return self._resource_sessions.get(cache_key)

    async def _set_session(
        self, resource_url: str, session_id: str, user_id: Optional[str] = None
    ) -> None:
        """Store resource session ID in CacheService and local cache."""
        cache_key = self._session_cache_key(user_id, resource_url)
        if self._cache_service:
            try:
                await self._cache_service.set(
                    f"{_SESSION_PREFIX}{cache_key}", session_id, ttl_seconds=3600
                )
            except Exception as e:
                logger.warning(f"CacheService set failed for session {cache_key}: {e}")

        self._resource_sessions[cache_key] = session_id

    async def terminate_all_for_user(self, user_id: str) -> int:
        """Drop local session-cache entries for this user. Returns count removed.

        L1-only: CacheService keys don't support enumeration, so peer pods'
        L1 caches aren't touched here. Those entries expire on TTL, and the
        revocation registry + relay purge already cut the user off on every
        pod via pub/sub fanout.
        """
        if not user_id:
            return 0
        prefix = f"{user_id}:"
        to_remove = [k for k in list(self._resource_sessions.keys())
                     if isinstance(k, str) and k.startswith(prefix)]
        for k in to_remove:
            self._resource_sessions.pop(k, None)
        # Best-effort L2 delete for the keys we knew about
        if self._cache_service:
            for k in to_remove:
                try:
                    await self._cache_service.delete(f"{_SESSION_PREFIX}{k}")
                except Exception as e:
                    logger.warning(f"CacheService delete failed for session {k}: {e}")
        if to_remove:
            logger.info(
                f"UnifiedMCPHandler: terminated {len(to_remove)} sessions for user={user_id}"
            )
        return len(to_remove)

    # ---- Main handler ----

    async def handle(self, body: Dict[str, Any], headers: Dict[str, str]) -> Tuple[Dict[str, Any], int, Dict[str, str]]:
        """
        Handle an MCP JSON-RPC request.

        Returns:
            (response_body, http_status, extra_headers)
        """
        method = body.get("method", "")
        params = body.get("params") or {}
        request_id = body.get("id")

        if method == "initialize":
            return self._handle_initialize(request_id, headers)

        if method == "notifications/initialized":
            return {}, 200, {}

        if method == "ping":
            return self._jsonrpc_result(request_id, {}), 200, {}

        # All other methods require authentication
        auth_result = await self._authenticate(headers)
        if auth_result is None:
            # RFC 9728: include resource_metadata as absolute URI in WWW-Authenticate
            # so MCP clients can associate this 401 with the correct auth session.
            gateway_base = os.getenv("GATEWAY_BASE_URL", "http://localhost:8000").rstrip("/")
            parts = [
                f'Bearer resource_metadata="{gateway_base}/.well-known/oauth-protected-resource"'
            ]
            # RFC 6750 §3.1: if the caller presented a token that we rejected,
            # signal invalid_token so the client clears its cached token and
            # starts a fresh auth flow rather than trying to "force re-register"
            # with the same credentials.
            had_auth_header = bool(
                headers.get("authorization") or headers.get("Authorization")
            )
            if had_auth_header:
                parts.append('error="invalid_token"')
                parts.append(
                    'error_description="The access token is invalid, expired, or has been revoked"'
                )
            www_auth = ", ".join(parts)
            return self._jsonrpc_error(request_id, -32001, "Authentication required"), 401, {
                "WWW-Authenticate": www_auth,
            }

        agent_id, agent_config, user_id, token = auth_result

        if method == "tools/list":
            return await self._handle_tools_list(request_id, agent_id, agent_config, user_id, token)

        if method == "tools/call":
            return await self._handle_tools_call(request_id, params, agent_id, agent_config, user_id, token)

        if method in ("resources/list", "prompts/list"):
            return self._jsonrpc_result(request_id, {method.split("/")[0]: []}), 200, {}

        return self._jsonrpc_error(request_id, -32601, f"Method not found: {method}"), 200, {}

    def _handle_initialize(self, request_id: Any, headers: Dict[str, str]) -> Tuple[Dict[str, Any], int, Dict[str, str]]:
        session_id = str(uuid.uuid4())
        settings = GatewaySettings()
        response = self._jsonrpc_result(request_id, {
            "protocolVersion": settings.mcp_protocol_version,
            "capabilities": {
                "tools": {"listChanged": False}
            },
            "serverInfo": {
                "name": "Okta MCP Gateway",
                "version": __version__
            }
        })
        return response, 200, {"Mcp-Session-Id": session_id}

    async def _authenticate(self, headers: Dict[str, str]) -> Optional[Tuple[str, Dict, str, str]]:
        """
        Validate JWT and resolve agent.

        For CIMD-authenticated tokens (issued via the confidential relay),
        bypasses JWT validation and creates a synthetic agent config with
        access to all configured resources.

        Returns (agent_id, agent_config, user_id, raw_token) or None.
        """
        auth_header = headers.get("authorization") or headers.get("Authorization")
        if not auth_header:
            logger.debug("_authenticate: no Authorization header present")
            return None

        token = extract_bearer_token(auth_header)
        if not token:
            logger.debug("_authenticate: no Bearer token in Authorization header")
            return None

        logger.debug(f"_authenticate: token present (len={len(token)}, prefix={token[:16]}...)")

        # Check if this is a CIMD-issued token (via confidential relay)
        if self._relay:
            cimd_info = self._relay.lookup_token(token)
            if cimd_info is None:
                logger.debug(
                    f"Token not found in relay lookup (len={len(token)}, "
                    f"prefix={token[:20]}..., tracked_count={len(self._relay._sessions_by_token)})"
                )
            if cimd_info:
                cimd_client_id = cimd_info["client_id"]
                logger.info(f"CIMD token authenticated for client: {cimd_client_id}")

                # Resolve resource access via Client Registry
                client_info = None
                if self._client_registry:
                    try:
                        client_info = await self._client_registry.resolve(cimd_client_id)
                    except Exception as e:
                        logger.warning(f"Client Registry resolution failed for {cimd_client_id}: {e}")

                if client_info and client_info.agent_config:
                    # Auto-provisioned or admin-configured agent record
                    agent_config = client_info.agent_config
                    agent_id = agent_config.get("agent_id", f"cimd:{cimd_client_id}")
                elif client_info:
                    # No agent record but policy resolved resource access
                    agent_config = {
                        "agent_id": f"cimd:{cimd_client_id}",
                        "client_id": cimd_client_id,
                        "resource_access": client_info.resource_access,
                        "enabled": True,
                    }
                    agent_id = agent_config["agent_id"]
                else:
                    # No client registry or resolution failed — empty access (safe default)
                    logger.warning(
                        f"CIMD client {cimd_client_id} has no resource access configured. "
                        f"Configure resources in the Admin UI, or set CIMD_TRUSTED_BACKEND_ACCESS "
                        f"/ CIMD_UNKNOWN_BACKEND_ACCESS env vars."
                    )
                    agent_config = {
                        "agent_id": f"cimd:{cimd_client_id}",
                        "client_id": cimd_client_id,
                        "resource_access": [],
                        "enabled": True,
                    }
                    agent_id = agent_config["agent_id"]

                user_id = cimd_info.get("user_id") or "cimd-user"

                # Enrich audit context
                agent_id_var.set(agent_id)
                user_id_var.set(user_id)
                client_id_var.set(cimd_client_id)

                return agent_id, agent_config, user_id, token

        # Resolve agent from header
        agent_id = None
        for h in ("x-mcp-agent", "X-MCP-Agent", "X-MCP-AGENT", "MCP-Agent"):
            if h in headers:
                agent_id = headers[h]
                break

        expected_client_id = None
        if agent_id:
            agent_config = self.store.get_agent_by_name(agent_id)
            if agent_config:
                expected_client_id = agent_config.get("client_id") if isinstance(agent_config, dict) else agent_config.client_id

        claims = await self.validator.validate_token(token, expected_client_id=expected_client_id)
        if not claims:
            return None

        user_id = claims.get("sub", "unknown")

        # Reject tokens whose sub was revoked via global logout.  Okta cannot
        # invalidate an already-issued JWT; we rely on this local registry
        # until the token expires naturally.
        try:
            from okta_agent_proxy.auth.revocation_registry import get_revocation_registry
            if await get_revocation_registry().is_revoked(user_id):
                logger.info(f"Rejecting token for revoked user: sub={user_id}")
                return None
        except Exception as e:
            logger.warning(f"Revocation registry check failed (allowing): {e}")

        # If no agent from header, try fallback by aud or cid
        if not agent_id or not agent_config:
            agent_config = None
            token_aud = claims.get("aud")
            token_cid = claims.get("cid")  # client_id claim in access_tokens
            lookup_values = [v for v in (token_aud, token_cid) if v]
            if lookup_values:
                all_agents = self.store.get_all_agents(enabled_only=False)
                matches = [
                    (a.get("agent_id"), a) for a in all_agents
                    if a and a.get("client_id") in lookup_values
                ]
                if len(matches) == 1:
                    agent_id, agent_config = matches[0]
            if not agent_config:
                return None

        # Enrich audit context
        if agent_id:
            agent_id_var.set(agent_id)
        if user_id:
            user_id_var.set(user_id)
        if agent_config:
            cid = agent_config.get("client_id") if isinstance(agent_config, dict) else getattr(agent_config, "client_id", None)
            if cid:
                client_id_var.set(cid)

        return agent_id, agent_config, user_id, token

    async def _handle_tools_list(
        self, request_id: Any, agent_id: str, agent_config: Dict, user_id: str, token: str
    ) -> Tuple[Dict[str, Any], int, Dict[str, str]]:
        start_time = time.monotonic()

        # Check cache (CacheService or local — already keyed by agent_id)
        cached = await self._get_tool_catalog(agent_id)
        if cached:
            logger.info(f"Returning cached tool catalog for agent '{agent_id}' ({len(cached['tools'])} tools)")
            latency_ms = round((time.monotonic() - start_time) * 1000, 2)
            await emit_audit_event(
                AuditEventType.MCP_TOOL_LIST,
                details={"method": "tools/list", "agent_id": agent_id,
                         "latency_ms": latency_ms,
                         "tool_count": len(cached["tools"]), "cache": "hit"},
            )
            return self._jsonrpc_result(request_id, {"tools": cached["tools"]}), 200, {}

        # Determine accessible resources from the router's resource list
        all_router_resources = self.router.list_resources()
        resource_names = list(all_router_resources.keys())
        logger.info(f"Router has {len(resource_names)} resources for tool discovery: {resource_names}")

        all_tools: List[Dict[str, Any]] = []
        tool_map: Dict[str, Tuple[str, str]] = {}  # namespaced_name -> (resource_name, original_name)
        resources_skipped = 0  # Track auth/discovery failures

        for resource_name in resource_names:
            resource_config = self.router.resolve_resource(resource_name, agent_id=agent_id)
            if not resource_config:
                logger.debug(f"[UNIFIED] Resource '{resource_name}' not available for agent '{agent_id}', skipping")
                continue

            if not resource_config.enabled:
                logger.debug(f"Resource '{resource_name}' is disabled, skipping")
                continue

            try:
                self._last_sts_consent = None
                auth_headers = await self._get_resource_auth_headers(
                    resource_name, resource_config, agent_config, user_id, token
                )
                if auth_headers is None:
                    if self._last_sts_consent and self._last_sts_consent.get("status") == "consent_required":
                        logger.warning(
                            f"Resource '{resource_name}' requires user consent — skipping from tool catalog"
                        )
                    else:
                        logger.warning(f"Could not create auth headers for resource '{resource_name}', skipping")
                    resources_skipped += 1
                    continue

                tools = await self._discover_tools(resource_config.url, auth_headers, user_id=user_id)
                logger.info(f"Discovered {len(tools)} tools from resource '{resource_name}'")

                for tool in tools:
                    original_name = tool["name"]
                    namespaced = f"{resource_name}{NAMESPACE_SEPARATOR}{original_name}"
                    tool_entry = {**tool, "name": namespaced}
                    all_tools.append(tool_entry)
                    tool_map[namespaced] = (resource_name, original_name)

            except Exception as e:
                logger.error(f"Failed to discover tools from resource '{resource_name}': {e}", exc_info=True)
                resources_skipped += 1
                continue

        # Only cache if all enabled resources were successfully discovered.
        # If any were skipped (auth failure, network error), leave cache empty
        # so the next request retries discovery for all resources.
        catalog = {"tools": all_tools, "tool_map": tool_map}
        if resources_skipped == 0:
            await self._set_tool_catalog(agent_id, catalog)
            logger.info(f"Consolidated {len(all_tools)} tools for agent '{agent_id}'")
        else:
            logger.warning(
                f"Consolidated {len(all_tools)} tools for agent '{agent_id}' "
                f"but {resources_skipped} resource(s) skipped — NOT caching (will retry)"
            )

        latency_ms = round((time.monotonic() - start_time) * 1000, 2)
        await emit_audit_event(
            AuditEventType.MCP_TOOL_LIST,
            details={"method": "tools/list", "agent_id": agent_id,
                     "latency_ms": latency_ms,
                     "tool_count": len(all_tools), "cache": "miss"},
        )

        return self._jsonrpc_result(request_id, {"tools": all_tools}), 200, {}

    async def _handle_tools_call(
        self, request_id: Any, params: Dict, agent_id: str, agent_config: Dict, user_id: str, token: str
    ) -> Tuple[Dict[str, Any], int, Dict[str, str]]:
        start_time = time.monotonic()
        tool_name = params.get("name", "")
        arguments = params.get("arguments", {})

        if NAMESPACE_SEPARATOR not in tool_name:
            return self._jsonrpc_error(request_id, -32601, f"Unknown tool: {tool_name}"), 200, {}

        # Parse namespace
        sep_idx = tool_name.index(NAMESPACE_SEPARATOR)
        resource_name = tool_name[:sep_idx]
        original_name = tool_name[sep_idx + len(NAMESPACE_SEPARATOR):]

        # Validate agent access via syncer/resource store
        try:
            from okta_agent_proxy.auth.agent_authz import check_agent_can_access_resource, AgentAuthorizationError
            await check_agent_can_access_resource(agent_id, agent_config, resource_name)
        except AgentAuthorizationError:
            return self._jsonrpc_error(
                request_id, -32603,
                f"Agent '{agent_id}' does not have access to resource '{resource_name}'"
            ), 403, {}

        resource_config = self.router.resolve_resource(resource_name, agent_id=agent_id)
        if not resource_config:
            return self._jsonrpc_error(
                request_id, -32603,
                f"Resource '{resource_name}' is not available for agent '{agent_id}'"
            ), 200, {}

        try:
            self._last_sts_consent = None  # Reset before auth attempt
            auth_headers = await self._get_resource_auth_headers(
                resource_name, resource_config, agent_config, user_id, token
            )
            if auth_headers is None:
                # Check if this was a consent_required from STS
                if self._last_sts_consent and self._last_sts_consent.get("status") == "consent_required":
                    consent = self._last_sts_consent
                    provider = consent.get("provider", resource_name)
                    return self._jsonrpc_error_with_data(
                        request_id,
                        code=-32001,
                        message=f"Authorization required for {provider}",
                        data={
                            "type": "consent_required",
                            "provider": provider,
                            "consent_url": consent.get("interaction_uri", ""),
                            "resource_indicator": consent.get("resource_indicator", ""),
                            "instructions": (
                                f"Open this URL in your browser to authorize the AI agent "
                                f"to access {provider} on your behalf. After authorizing, "
                                f"re-run your command."
                            ),
                            "retry_hint": "After completing authorization, simply re-run the same tool call.",
                            "expires_in": 600,
                        },
                    ), 200, {}
                return self._jsonrpc_error(request_id, -32603, f"Authentication failed for resource '{resource_name}'"), 200, {}

            logger.info(f"Routing tool '{tool_name}' to resource '{resource_name}' as '{original_name}'")

            rpc_request = {
                "jsonrpc": "2.0",
                "id": request_id or "1",
                "method": "tools/call",
                "params": {
                    "name": original_name,
                    "arguments": arguments,
                },
            }

            # Get or create resource session (per-user so force-logout can sweep)
            session_id = await self._get_resource_session(resource_config.url, auth_headers, user_id=user_id)

            request_headers = {
                **auth_headers,
                "Content-Type": "application/json",
                "Accept": "application/json, text/event-stream",
            }
            if session_id:
                request_headers["Mcp-Session-Id"] = session_id

            async with httpx.AsyncClient() as client:
                response = await client.post(
                    resource_config.url,
                    json=rpc_request,
                    headers=request_headers,
                    timeout=self.http_timeout,
                )

            if response.status_code != 200:
                logger.error(f"Resource '{resource_name}' returned {response.status_code}: {response.text}")
                return self._jsonrpc_error(
                    request_id, -32603, f"Resource '{resource_name}' returned HTTP {response.status_code}"
                ), 200, {}

            content_type = response.headers.get("content-type", "")
            if "text/event-stream" in content_type:
                result = _parse_sse_response(response.text)
            else:
                result = response.json()

            if result is None:
                return self._jsonrpc_error(request_id, -32603, f"Could not parse response from resource '{resource_name}'"), 200, {}

            # Extract the result field from resource JSON-RPC response
            resource_result = result.get("result", result)
            latency_ms = round((time.monotonic() - start_time) * 1000, 2)
            await emit_audit_event(
                AuditEventType.MCP_TOOL_CALL,
                resource_name=resource_name,
                details={"method": "tools/call", "tool_name": tool_name,
                         "agent_id": agent_id, "latency_ms": latency_ms},
            )
            return self._jsonrpc_result(request_id, resource_result), 200, {}

        except httpx.TimeoutException:
            logger.error(f"Timeout calling resource '{resource_name}'")
            latency_ms = round((time.monotonic() - start_time) * 1000, 2)
            await emit_audit_event(
                AuditEventType.MCP_TOOL_CALL,
                severity=AuditSeverity.WARNING,
                resource_name=resource_name,
                details={"method": "tools/call", "tool_name": tool_name,
                         "latency_ms": latency_ms, "error": "resource_timeout"},
                outcome="failure",
            )
            return self._jsonrpc_error(request_id, -32603, f"Resource '{resource_name}' is unavailable"), 200, {}

        except httpx.RequestError as e:
            logger.error(f"Network error calling resource '{resource_name}': {e}")
            latency_ms = round((time.monotonic() - start_time) * 1000, 2)
            await emit_audit_event(
                AuditEventType.MCP_TOOL_CALL,
                severity=AuditSeverity.WARNING,
                resource_name=resource_name,
                details={"method": "tools/call", "tool_name": tool_name,
                         "latency_ms": latency_ms, "error": "resource_connection_error"},
                outcome="failure",
            )
            return self._jsonrpc_error(request_id, -32603, f"Resource '{resource_name}' is unavailable"), 200, {}

        except Exception as e:
            logger.error(f"Error routing tools/call to '{resource_name}': {e}", exc_info=True)
            latency_ms = round((time.monotonic() - start_time) * 1000, 2)
            await emit_audit_event(
                AuditEventType.MCP_TOOL_CALL,
                severity=AuditSeverity.WARNING,
                resource_name=resource_name,
                details={"method": "tools/call", "tool_name": tool_name,
                         "latency_ms": latency_ms, "error": str(e)},
                outcome="failure",
            )
            return self._jsonrpc_error(request_id, -32603, str(e)), 200, {}

    async def _get_resource_auth_headers(
        self, resource_name: str, resource_config, agent_config: Dict, user_id: str, token: str
    ) -> Optional[Dict[str, str]]:
        """Build auth headers for a resource based on its auth_method.

        Delegates to the consolidated ResourceTokenResolver.
        """
        # Recover the MCP client's originally-requested custom scopes, stashed
        # on the relay session at /oauth/authorize and bound to this access
        # token via GatewayCodeManager.extra. Cache miss (no relay, no prior
        # stash, TTL expired) falls through to apply_scope_condition's
        # connection.scopes default — no downstream regression.
        requested_scopes = None
        if self._relay is not None:
            try:
                info = await self._relay.alookup_token(token)
                if info:
                    recovered = info.get("custom_scopes") or []
                    if recovered:
                        requested_scopes = list(recovered)
                        try:
                            await emit_audit_event(
                                AuditEventType.OAUTH_CUSTOM_SCOPES_RECOVERED,
                                details={
                                    "resource": resource_name,
                                    "count": len(recovered),
                                    "scopes": recovered,
                                },
                            )
                        except Exception as e:
                            logger.debug(f"Failed to emit OAUTH_CUSTOM_SCOPES_RECOVERED: {e}")
            except Exception as e:
                logger.debug(f"relay.alookup_token failed during scope recovery: {e}")

        result = await self.router.resolver.resolve_auth_headers(
            resource_name=resource_name,
            resource_config=resource_config,
            agent_config=agent_config,
            user_id=user_id,
            user_id_token=token,
            requested_scopes=requested_scopes,
        )
        if result.ok:
            return result.headers
        if result.consent_required:
            self._last_sts_consent = result.consent_required
        return None

    async def _get_resource_session(
        self,
        resource_url: str,
        auth_headers: Dict[str, str],
        user_id: Optional[str] = None,
    ) -> Optional[str]:
        """Get or create an MCP session with a resource via initialize handshake."""
        # Check CacheService or local cache
        cached = await self._get_session(resource_url, user_id=user_id)
        if cached:
            return cached

        try:
            settings = GatewaySettings()
            async with httpx.AsyncClient() as client:
                response = await client.post(
                    resource_url,
                    json={
                        "jsonrpc": "2.0",
                        "id": "gateway-init",
                        "method": "initialize",
                        "params": {
                            "protocolVersion": settings.mcp_protocol_version,
                            "capabilities": {},
                            "clientInfo": {"name": "Okta MCP Gateway", "version": __version__},
                        }
                    },
                    headers={
                        **auth_headers,
                        "Content-Type": "application/json",
                        "Accept": "application/json, text/event-stream",
                    },
                    timeout=10.0,
                )

                if response.status_code != 200:
                    logger.warning(f"initialize failed for {resource_url}: HTTP {response.status_code}")
                    return None

                session_id = response.headers.get("mcp-session-id") or response.headers.get("Mcp-Session-Id")
                if not session_id:
                    session_id = str(uuid.uuid4())
                    logger.debug(f"Resource {resource_url} did not return session ID, generated: {session_id[:8]}...")

                # Send notifications/initialized
                notify_headers = {
                    **auth_headers,
                    "Content-Type": "application/json",
                    "Accept": "application/json, text/event-stream",
                    "Mcp-Session-Id": session_id,
                }
                try:
                    await client.post(
                        resource_url,
                        json={"jsonrpc": "2.0", "method": "notifications/initialized"},
                        headers=notify_headers,
                        timeout=5.0,
                    )
                except Exception:
                    pass

                await self._set_session(resource_url, session_id, user_id=user_id)
                logger.info(
                    f"MCP session established with {resource_url} "
                    f"for user={user_id or '_anon'}: {session_id[:8]}..."
                )
                return session_id

        except Exception as e:
            logger.error(f"Error initializing session with {resource_url}: {e}")
            return None

    async def _discover_tools(
        self,
        resource_url: str,
        auth_headers: Dict[str, str],
        user_id: Optional[str] = None,
    ) -> List[Dict[str, Any]]:
        """Discover tools from a resource, handling session init and SSE responses."""
        session_id = await self._get_resource_session(resource_url, auth_headers, user_id=user_id)

        try:
            request_headers = {
                **auth_headers,
                "Content-Type": "application/json",
                "Accept": "application/json, text/event-stream",
            }
            if session_id:
                request_headers["Mcp-Session-Id"] = session_id

            async with httpx.AsyncClient() as client:
                response = await client.post(
                    resource_url,
                    json={
                        "jsonrpc": "2.0",
                        "id": "discover-tools",
                        "method": "tools/list",
                        "params": {}
                    },
                    headers=request_headers,
                    timeout=10.0,
                )

                if response.status_code != 200:
                    logger.warning(f"tools/list failed from {resource_url}: HTTP {response.status_code}")
                    return []

                content_type = response.headers.get("content-type", "")
                if "text/event-stream" in content_type:
                    result = _parse_sse_response(response.text)
                else:
                    result = response.json()

                if result is None:
                    return []

                return result.get("result", {}).get("tools", [])

        except Exception as e:
            logger.error(f"Error discovering tools from {resource_url}: {e}")
            return []

    async def refresh_catalog(self):
        """Invalidate all tool caches so the next tools/list re-discovers.

        Called after sync events (okta:sync, resource:changed) to ensure
        the tool catalog reflects the latest ResolvedResources.
        """
        self.invalidate_tool_cache()
        logger.info("UnifiedMCPHandler: tool catalog refreshed after sync event")

    def invalidate_tool_cache(self, agent_id: Optional[str] = None):
        """Invalidate tool cache for a specific agent or all agents."""
        if self._cache_service:
            import asyncio
            try:
                loop = asyncio.get_running_loop()
                if agent_id:
                    loop.create_task(
                        self._cache_service.delete(f"{_TOOL_CACHE_PREFIX}{agent_id}")
                    )
                else:
                    loop.create_task(
                        self._cache_service.clear_prefix(_TOOL_CACHE_PREFIX)
                    )
            except RuntimeError:
                pass

        # Also clear local cache
        if agent_id:
            self._tool_cache.pop(agent_id, None)
        else:
            self._tool_cache.clear()

    @staticmethod
    def _jsonrpc_result(request_id: Any, result: Any) -> Dict[str, Any]:
        return {"jsonrpc": "2.0", "id": request_id, "result": result}

    @staticmethod
    def _jsonrpc_error(request_id: Any, code: int, message: str) -> Dict[str, Any]:
        return {"jsonrpc": "2.0", "id": request_id, "error": {"code": code, "message": message}}

    @staticmethod
    def _jsonrpc_error_with_data(request_id: Any, code: int, message: str, data: Any) -> Dict[str, Any]:
        return {"jsonrpc": "2.0", "id": request_id, "error": {"code": code, "message": message, "data": data}}
