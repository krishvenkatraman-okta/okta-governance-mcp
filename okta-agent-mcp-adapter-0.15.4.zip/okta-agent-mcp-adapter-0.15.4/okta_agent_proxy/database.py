"""Database connection and configuration-store factory (psycopg3).

As of DB migration prompt P07, SQLAlchemy and psycopg2 are gone: the
adapter uses psycopg3 exclusively via :class:`DatabasePool`. The
``STORAGE_BACKEND`` env var is accepted for diagnostic logging only —
the psycopg path is the only implementation.
"""

import os
import logging
from typing import Optional

from okta_agent_proxy.storage.base import ResourceConfigStore
from okta_agent_proxy.crypto import get_encryption_service, EncryptionService

logger = logging.getLogger(__name__)

_config_store: Optional[ResourceConfigStore] = None
_database_pool = None


def _min_schema_version() -> str:
    from okta_agent_proxy.storage.constants import MIN_SCHEMA_VERSION

    return MIN_SCHEMA_VERSION


def _emit_schema_audit_event(
    *,
    event_type_name: str,
    outcome: str,
    details: dict,
    severity_name: str = "INFO",
) -> None:
    """Best-effort emit of a DB-schema audit event from sync context.

    At the point ``get_config_store`` runs (application import time) the
    audit emitter is almost never initialized yet, so this is usually a
    no-op by design. We still route through ``emit_audit_event`` so that
    if the emitter *is* wired up (tests, embedded use) the event lands.
    """
    try:
        import asyncio

        from okta_agent_proxy.audit import (
            AuditEventType,
            AuditSeverity,
            emit_audit_event,
            get_audit_emitter,
        )

        if get_audit_emitter() is None:
            return

        event_type = getattr(AuditEventType, event_type_name)
        severity = getattr(AuditSeverity, severity_name, AuditSeverity.INFO)
        coro = emit_audit_event(
            event_type,
            severity=severity,
            details=details,
            outcome=outcome,
        )
        try:
            loop = asyncio.get_event_loop()
            if loop.is_running():
                loop.create_task(coro)
            else:
                loop.run_until_complete(coro)
        except RuntimeError:
            asyncio.run(coro)
    except Exception:  # pragma: no cover - audit emission must not break startup
        logger.debug("Failed to emit schema audit event", exc_info=True)


def get_database_pool():
    """Return the process-wide :class:`DatabasePool` used by the store.

    Constructed lazily by :func:`get_config_store`. Raises
    :class:`RuntimeError` if the store has not been initialized yet.
    """
    if _database_pool is None:
        raise RuntimeError(
            "Database pool not initialized. Call get_config_store() first."
        )
    return _database_pool


def get_config_store(
    database_url: Optional[str] = None,
    encryption_service: Optional[EncryptionService] = None,
    cache_service=None,
) -> ResourceConfigStore:
    """Factory for the psycopg3-backed configuration store.

    Args:
        database_url: PostgreSQL connection string (default: from DATABASE_URL env)
        encryption_service: Encryption service (creates default if None)
        cache_service: Optional CacheService for config caching

    Returns:
        ResourceConfigStore instance (wrapped with caching when cache_service set)

    Raises:
        RuntimeError: If DATABASE_URL is not set or the pool cannot open.
    """
    global _config_store, _database_pool

    if _config_store is not None:
        return _config_store

    # Track whether the caller supplied database_url explicitly (programmatic
    # override / some tests) vs falling back to the DATABASE_URL env var. The
    # explicit path keeps direct StaticUrlCredentialProvider construction so
    # callers can override DATABASE_URL without touching the env. The env path
    # goes through the credential-provider factory so DB_CREDENTIAL_PROVIDER
    # is honored and the static path trips the ALLOW_STATIC_DATABASE_PASSWORD
    # gate (parity with ALLOW_STATIC_REDIS_PASSWORD on the cache side).
    explicit_database_url = database_url is not None

    if database_url is None:
        database_url = os.getenv("DATABASE_URL")

    # Symmetric with storage/migrate.py: when DB_CREDENTIAL_PROVIDER is set
    # (rds_iam, azure_entra, vault), the provider mints the conninfo at
    # runtime and DATABASE_URL is intentionally absent on the adapter task.
    if not database_url and not os.getenv("DB_CREDENTIAL_PROVIDER"):
        raise RuntimeError(
            "DATABASE_URL environment variable is required. "
            "See docs/OPERATIONS.md for setup instructions."
        )

    if encryption_service is None:
        encryption_service = get_encryption_service()

    # Honor ``STORAGE_BACKEND`` only to emit a warning when someone still
    # sets the legacy value — the psycopg path is the only implementation.
    backend = os.getenv("STORAGE_BACKEND", "psycopg").lower()
    if backend not in ("psycopg", ""):
        logger.warning(
            "STORAGE_BACKEND=%r is ignored as of P07; psycopg3 is the only "
            "supported backend.",
            backend,
        )

    from okta_agent_proxy.storage.credentials import (
        StaticUrlCredentialProvider,
        get_credential_provider,
    )
    from okta_agent_proxy.storage.pool import DatabasePool
    from okta_agent_proxy.storage.psycopg_store import PsycopgResourceStore
    from okta_agent_proxy.storage.schema_check import (
        SchemaNotInitializedError,
        SchemaVersionMismatchError,
        verify_schema,
    )

    if explicit_database_url:
        provider = StaticUrlCredentialProvider(database_url)
    else:
        provider = get_credential_provider()
    _database_pool = DatabasePool(provider)

    # Fail-fast schema version check — the adapter does not create schema at
    # runtime. Operators run the migration runner before starting the service.
    try:
        current_version = verify_schema(_database_pool)
        _emit_schema_audit_event(
            event_type_name="DB_SCHEMA_VERSION_CHECKED",
            outcome="success",
            details={
                "current_version": current_version,
                "min_required": _min_schema_version(),
            },
        )
    except (SchemaNotInitializedError, SchemaVersionMismatchError) as exc:
        _emit_schema_audit_event(
            event_type_name="DB_SCHEMA_VERSION_MISMATCH",
            outcome="failure",
            details={
                "error": exc.__class__.__name__,
                "min_required": _min_schema_version(),
            },
            severity_name="ERROR",
        )
        try:
            _database_pool.close()
        except Exception:  # pragma: no cover - cleanup best-effort
            logger.exception("Error closing database pool after schema check failure")
        _database_pool = None
        raise

    pg_store: ResourceConfigStore = PsycopgResourceStore(
        pool=_database_pool,
        encryption_service=encryption_service,
    )
    logger.info("Configuration store initialized (psycopg3)")

    if cache_service is not None:
        from okta_agent_proxy.storage.cached_store import CachedResourceStore
        _config_store = CachedResourceStore(
            pg_store,
            cache_service=cache_service,
            ttl_seconds=300,
            encryption_service=encryption_service,
        )
        logger.info("Configuration store wrapped with L1/L2 config cache")
    else:
        _config_store = pg_store

    return _config_store


def reset_config_store():
    """Reset the cached config store. Useful for tests."""
    global _config_store, _database_pool
    if _database_pool is not None:
        try:
            _database_pool.close()
        except Exception:
            logger.exception("Error closing database pool during reset")
    _config_store = None
    _database_pool = None
    logger.info("Config store cache cleared")


def get_store() -> ResourceConfigStore:
    """FastAPI dependency-injection helper returning the global store."""
    return get_config_store()
