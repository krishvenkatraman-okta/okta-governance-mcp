"""
MCP Session Manager

Handles MCP session lifecycle per resource:
1. Create session on first request
2. Cache session ID per user per resource
3. Include session ID in all subsequent requests
4. Clean up on timeout

Session cache key: {user_id}:{resource_name}
"""

import logging
import httpx
import uuid
from typing import Optional, Dict, Tuple
from datetime import datetime, timedelta
import cachetools

from okta_agent_proxy import __version__
from okta_agent_proxy.cache.serializers import serialize_json, deserialize_json
from okta_agent_proxy.audit import emit_audit_event, AuditEventType, AuditSeverity
from okta_agent_proxy.config import GatewaySettings

logger = logging.getLogger(__name__)

_SESSION_PREFIX = "session:proxy:"


class MCPSessionManager:
    """Manages MCP session creation and caching"""

    def __init__(self, session_ttl: int = 3600, cache_service=None):
        """
        Initialize session manager.

        Args:
            session_ttl: Session TTL in seconds (default: 1 hour)
            cache_service: Optional CacheService for shared/distributed caching
        """
        self.session_ttl = session_ttl
        self._cache_service = cache_service
        # Fallback local cache: {user_id}:{resource_name} -> {session_id, created_at, expires_at}
        self.sessions = cachetools.TTLCache(
            maxsize=1000,
            ttl=session_ttl
        )
        mode = "CacheService" if cache_service else "standalone"
        logger.info(f"MCPSessionManager initialized with TTL={session_ttl}s, mode={mode}")

    def _service_key(self, cache_key: str) -> str:
        return f"{_SESSION_PREFIX}{cache_key}"

    async def _get_from_service(self, cache_key: str) -> Optional[Dict]:
        """Try to get session data from CacheService."""
        if not self._cache_service:
            return None
        try:
            raw = await self._cache_service.get(self._service_key(cache_key))
            if raw is not None:
                return deserialize_json(raw)
        except Exception as e:
            logger.warning(f"CacheService get failed for session {cache_key}: {e}")
        return None

    async def _set_to_service(self, cache_key: str, session_data: Dict) -> bool:
        """Try to store session data in CacheService."""
        if not self._cache_service:
            return False
        try:
            serialized = serialize_json(session_data)
            await self._cache_service.set(
                self._service_key(cache_key), serialized, ttl_seconds=self.session_ttl
            )
            return True
        except Exception as e:
            logger.warning(f"CacheService set failed for session {cache_key}: {e}")
            return False

    async def _delete_from_service(self, cache_key: str) -> None:
        """Try to delete session data from CacheService."""
        if not self._cache_service:
            return
        try:
            await self._cache_service.delete(self._service_key(cache_key))
        except Exception as e:
            logger.warning(f"CacheService delete failed for session {cache_key}: {e}")

    async def get_or_create_session(
        self,
        user_id: str,
        resource_name: str,
        resource_url: str,
        access_token: str
    ) -> Optional[str]:
        """
        Get existing session or create new one.

        Args:
            user_id: User identifier
            resource_name: Resource MCP server name
            resource_url: Resource MCP URL (should include /mcp endpoint)
            access_token: Access token for auth (if needed for initialize)

        Returns:
            Session ID if successful, None if failed
        """
        cache_key = f"{user_id}:{resource_name}"

        # Check CacheService first
        if self._cache_service:
            session_data = await self._get_from_service(cache_key)
            if session_data:
                logger.debug(
                    f"Using cached session (service) for {cache_key}: "
                    f"{session_data['session_id'][:8]}..."
                )
                return session_data['session_id']

        # Check local cache
        if cache_key in self.sessions:
            session_data = self.sessions[cache_key]
            logger.debug(
                f"Using cached session for {cache_key}: "
                f"{session_data['session_id'][:8]}..."
            )
            return session_data['session_id']

        # Create new session
        logger.info(f"Creating new MCP session for {cache_key}")
        session_id = await self._create_session(resource_url, access_token)

        if not session_id:
            logger.error(f"Failed to create session for {cache_key}")
            return None

        # Build session data
        now = datetime.now()
        session_data = {
            'session_id': session_id,
            'created_at': now.isoformat(),
            'expires_at': (now + timedelta(seconds=self.session_ttl)).isoformat(),
            'resource_url': resource_url
        }

        # Store in CacheService
        await self._set_to_service(cache_key, session_data)

        # Also store in local cache (for L1-style fast access)
        self.sessions[cache_key] = session_data

        logger.info(
            f"Session created for {cache_key}: {session_id[:8]}... "
            f"(expires in {self.session_ttl}s)"
        )

        await emit_audit_event(
            AuditEventType.MCP_SESSION_CREATED,
            resource_name=resource_name,
            details={"user_id": user_id, "resource_name": resource_name,
                     "session_id": session_id[:8]},
        )

        return session_id

    async def _create_session(
        self,
        resource_url: str,
        access_token: str
    ) -> Optional[str]:
        """
        Create new MCP session by sending initialize request.

        For stateless resources (like FastMCP servers), generates a synthetic session ID
        since the resource won't return Mcp-Session-Id header.

        Args:
            resource_url: Resource MCP URL
            access_token: Access token (may be needed for initialize)

        Returns:
            Session ID from response header, or generated ID for stateless resources
        """
        try:
            async with httpx.AsyncClient(timeout=10) as client:
                headers = {
                    "Content-Type": "application/json",
                    "Accept": "application/json, text/event-stream",
                }
                # Include auth header even for initialize (some servers may require it)
                if access_token:
                    headers["Authorization"] = f"Bearer {access_token}"

                logger.debug(f"Initializing MCP session with {resource_url}")

                settings = GatewaySettings()
                response = await client.post(
                    resource_url,
                    json={
                        "jsonrpc": "2.0",
                        "method": "initialize",
                        "params": {
                            "protocolVersion": settings.mcp_protocol_version,
                            "capabilities": {},
                            "clientInfo": {"name": "Okta MCP Gateway", "version": __version__},
                        },
                        "id": str(uuid.uuid4())
                    },
                    headers=headers
                )

                if response.status_code != 200:
                    logger.error(
                        f"Initialize failed: {response.status_code} - {response.text}"
                    )
                    return None

                # Extract session ID from response header (case-insensitive)
                logger.debug(f"Initialize response headers: {dict(response.headers)}")
                session_id = response.headers.get("mcp-session-id") or response.headers.get("Mcp-Session-Id")

                # If resource doesn't return session ID (stateless), generate one
                if not session_id:
                    # Stateless resources (like FastMCP) don't track sessions
                    # Generate a synthetic ID for the gateway's internal tracking
                    session_id = str(uuid.uuid4())
                    logger.debug(
                        f"Resource did not return session ID - generated synthetic ID: {session_id[:8]}... "
                        "(resource is stateless, gateway will manage sessions)"
                    )
                else:
                    logger.debug(f"Session ID obtained from resource: {session_id[:8]}...")

                # Step 2: Send notifications/initialized (required by MCP protocol)
                try:
                    notify_headers = {
                        "Content-Type": "application/json",
                        "Accept": "application/json, text/event-stream",
                        "Mcp-Session-Id": session_id,
                    }
                    if access_token:
                        notify_headers["Authorization"] = f"Bearer {access_token}"

                    notify_response = await client.post(
                        resource_url,
                        json={
                            "jsonrpc": "2.0",
                            "method": "notifications/initialized",
                        },
                        headers=notify_headers,
                    )
                    logger.debug(
                        f"Sent notifications/initialized, status={notify_response.status_code}"
                    )
                except Exception as notify_err:
                    logger.warning(
                        f"Failed to send notifications/initialized: {notify_err}"
                    )

                return session_id

        except Exception as e:
            logger.error(f"Error creating session: {e}", exc_info=True)
            return None

    async def terminate_session(
        self,
        user_id: str,
        resource_name: str,
        resource_url: str,
        session_id: str
    ) -> bool:
        """
        Terminate MCP session.

        Args:
            user_id: User identifier
            resource_name: Resource name
            resource_url: Resource MCP URL
            session_id: Session ID to terminate

        Returns:
            True if successful, False otherwise
        """
        cache_key = f"{user_id}:{resource_name}"

        try:
            async with httpx.AsyncClient(timeout=5) as client:
                logger.debug(f"Terminating session {session_id[:8]}...")

                response = await client.delete(
                    resource_url,
                    headers={
                        "Mcp-Session-Id": session_id
                    }
                )

                if response.status_code in [200, 204]:
                    logger.info(f"Session terminated: {session_id[:8]}...")
                    # Remove from both caches
                    await self._delete_from_service(cache_key)
                    if cache_key in self.sessions:
                        del self.sessions[cache_key]
                    await emit_audit_event(
                        AuditEventType.MCP_SESSION_TERMINATED,
                        resource_name=resource_name,
                        details={"user_id": user_id, "resource_name": resource_name,
                                 "session_id": session_id[:8]},
                    )
                    return True
                else:
                    logger.warning(
                        f"Session terminate returned {response.status_code}: {response.text}"
                    )
                    return False

        except Exception as e:
            logger.error(f"Error terminating session: {e}")
            return False

    async def terminate_all_for_user(
        self,
        user_id: str,
        per_call_timeout: float = 3.0,
    ) -> Dict[str, bool]:
        """
        Terminate all locally-cached MCP sessions for a user across all
        backends, in parallel, with a per-call timeout.

        Used by global logout. Only iterates self.sessions (local L1).
        In multi-replica deployments, sessions held by peer replicas
        will not be terminated by this call — peer replicas' caches
        cannot be enumerated through CacheService. Those backend
        sessions die when the cache TTL expires; the UserTokenStore
        cross-pod pub/sub already cuts the user off at Layer 2 on
        every peer.
        """
        import asyncio

        prefix = f"{user_id}:"
        snapshot: list[tuple[str, str, str]] = []
        for key in list(self.sessions.keys()):
            if not isinstance(key, str) or not key.startswith(prefix):
                continue
            resource_name = key[len(prefix):]
            entry = self.sessions.get(key)
            if not entry:
                continue
            session_id = entry.get("session_id")
            resource_url = entry.get("resource_url")
            if not session_id or not resource_url:
                continue
            snapshot.append((resource_name, resource_url, session_id))

        if not snapshot:
            return {}

        async def _run(resource_name: str, resource_url: str, session_id: str):
            return await asyncio.wait_for(
                self.terminate_session(user_id, resource_name, resource_url, session_id),
                timeout=per_call_timeout,
            )

        tasks = [_run(rn, ru, sid) for rn, ru, sid in snapshot]
        results = await asyncio.gather(*tasks, return_exceptions=True)

        out: Dict[str, bool] = {}
        for (resource_name, _url, _sid), result in zip(snapshot, results):
            if result is True:
                out[resource_name] = True
                await emit_audit_event(
                    AuditEventType.GLOBAL_LOGOUT_BACKEND_SESSION_TERMINATED,
                    severity=AuditSeverity.INFO,
                    resource_name=resource_name,
                    details={"user_id": user_id, "resource_name": resource_name},
                )
            else:
                out[resource_name] = False
                if isinstance(result, BaseException):
                    error_str = f"{type(result).__name__}: {str(result)[:180]}"
                else:
                    error_str = "non_2xx_response"
                await emit_audit_event(
                    AuditEventType.GLOBAL_LOGOUT_BACKEND_SESSION_FAILED,
                    severity=AuditSeverity.WARNING,
                    resource_name=resource_name,
                    outcome="failure",
                    details={
                        "user_id": user_id,
                        "resource_name": resource_name,
                        "error": error_str,
                    },
                )

        return out

    def invalidate_session(self, user_id: str, resource_name: str) -> None:
        """
        Invalidate cached session (e.g., after auth error).

        Args:
            user_id: User identifier
            resource_name: Resource name
        """
        cache_key = f"{user_id}:{resource_name}"

        # Delete from CacheService (fire-and-forget from sync context)
        if self._cache_service:
            import asyncio
            try:
                loop = asyncio.get_running_loop()
                loop.create_task(self._delete_from_service(cache_key))
            except RuntimeError:
                pass

        if cache_key in self.sessions:
            session_id = self.sessions[cache_key]['session_id']
            logger.info(f"Invalidating session: {session_id[:8]}...")
            del self.sessions[cache_key]

    def get_session_stats(self) -> Dict[str, int]:
        """Get session cache statistics"""
        return {
            "active_sessions": len(self.sessions),
            "max_sessions": self.sessions.maxsize,
            "ttl_seconds": self.session_ttl
        }
