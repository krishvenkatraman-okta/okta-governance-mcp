"""
MCP Request Proxy Handler

Handles complete MCP request flow:
1. Token validation (from Phase 2)
2. Resource token exchange (from Phase 3)
3. Request forwarding to resource
4. Response propagation
5. Error handling (401, timeouts, etc.)
"""

import logging
import json
import time
from typing import Optional, Dict, Any
import httpx

from okta_agent_proxy.auth.okta_validator import OktaTokenValidator
from okta_agent_proxy.auth.resource_token_resolver import ResourceTokenResolver
from okta_agent_proxy.middleware.auth import extract_bearer_token, extract_scopes_from_claims
from okta_agent_proxy.routing.router import ResourceRouter
from okta_agent_proxy.auth.resource_auth import create_auth_handler


def _parse_sse_response(text: str) -> Optional[Dict[str, Any]]:
    """
    Parse a Server-Sent Events response to extract JSON-RPC result.

    SSE format:
        event: message
        data: {"jsonrpc":"2.0","id":"1","result":{...}}

    Returns the parsed JSON object from the last data line, or None.
    """
    last_data = None
    for line in text.strip().split("\n"):
        line = line.strip()
        if line.startswith("data: "):
            data_str = line[6:]  # Remove "data: " prefix
            try:
                last_data = json.loads(data_str)
            except json.JSONDecodeError:
                continue
        elif line.startswith("data:") and len(line) > 5:
            data_str = line[5:]  # Remove "data:" prefix (no space)
            try:
                last_data = json.loads(data_str)
            except json.JSONDecodeError:
                continue
    return last_data
from okta_agent_proxy.storage import ResourceConfigStore
from okta_agent_proxy.config import AgentConfig
from okta_agent_proxy.middleware.agent_extractor import AgentExtractor
from okta_agent_proxy.auth.agent_authz import (
    check_agent_can_access_resource,
    AgentAuthorizationError,
    create_authorization_error_response,
    create_missing_agent_error_response,
    create_invalid_agent_header_response
)
from okta_agent_proxy.proxy.session_manager import MCPSessionManager
from okta_agent_proxy.audit import emit_audit_event, AuditEventType, AuditSeverity
from okta_agent_proxy.audit.context import agent_id_var, user_id_var, client_id_var

logger = logging.getLogger(__name__)


class ProxyHandler:
    """
    Proxies MCP requests to appropriate resource MCP server.

    Handles:
    - Token validation against Okta
    - Token exchange for resource (ID-JAG)
    - Request routing and forwarding
    - Error propagation
    """

    def __init__(
        self,
        router: ResourceRouter,
        okta_validator: OktaTokenValidator,
        store: Optional[ResourceConfigStore] = None,
        http_timeout: float = 30.0,
        session_ttl: int = 3600,
        cache_service=None,
        relay=None,
        client_registry=None,
    ):
        """
        Initialize proxy handler.

        Args:
            router: ResourceRouter instance for routing and token exchange
            okta_validator: OktaTokenValidator for JWT validation
            store: Optional ResourceConfigStore for agent lookup
            http_timeout: HTTP request timeout in seconds
            session_ttl: MCP session TTL in seconds (default: 1 hour)
            cache_service: Optional CacheService for shared session caching
            relay: Optional ConfidentialRelay for CIMD token lookup
            client_registry: Optional ClientRegistry for CIMD agent resolution
        """
        self.router = router
        self.okta_validator = okta_validator
        self.store = store
        self.http_timeout = http_timeout
        self.agent_extractor = AgentExtractor(store) if store else None
        self.session_manager = MCPSessionManager(session_ttl=session_ttl, cache_service=cache_service)
        self._relay = relay
        self._client_registry = client_registry
        logger.info(f"ProxyHandler initialized with session_ttl={session_ttl}s")
    
    async def proxy_request(
        self,
        request_path: str,
        method: str,
        params: Optional[Dict[str, Any]],
        auth_header: Optional[str],
        request_id: Optional[str] = None,
        headers: Optional[Dict[str, str]] = None
    ) -> Dict[str, Any]:
        """
        Proxy a complete MCP request to appropriate resource.
        
        Flow:
        1. Extract and validate Bearer token from auth header
        2. Determine resource from request path
        3. Exchange token for resource (if needed)
        4. Forward request to resource
        5. Handle response or error
        
        Args:
            request_path: Request path (e.g., "/hr/mcp", "/partners")
            method: MCP method (e.g., "tools/list", "tools/call")
            params: Method parameters
            auth_header: Authorization header value
            request_id: Optional request ID
            
        Returns:
            Response dict (result or error)
        """
        start_time = time.monotonic()

        # Step 1: Validate token
        if not auth_header:
            logger.warning("No Authorization header provided")
            return {
                "error": "unauthorized",
                "message": "Authorization header required"
            }
        
        # Extract Bearer token
        token = extract_bearer_token(auth_header)
        if not token:
            logger.warning("Invalid Authorization header format")
            return {
                "error": "unauthorized",
                "message": "Invalid Authorization header format"
            }
        
        # Check if this is a CIMD-issued token (via confidential relay).
        # This must happen BEFORE Okta JWT validation since relay tokens are
        # gateway-issued and will fail Okta signature verification.
        cimd_authenticated = False
        if self._relay:
            cimd_info = self._relay.lookup_token(token)
            if cimd_info:
                cimd_client_id = cimd_info["client_id"]
                user_id = cimd_info.get("user_id") or "cimd-user"
                logger.info(f"CIMD token authenticated for client: {cimd_client_id} (path-based)")

                # Resolve resource access via Client Registry
                agent_id = None
                agent_config = None
                if self._client_registry:
                    try:
                        client_info = await self._client_registry.resolve(cimd_client_id)
                        if client_info and client_info.agent_config:
                            agent_config = client_info.agent_config
                            agent_id = agent_config.get("agent_id", f"cimd:{cimd_client_id}")
                        elif client_info:
                            agent_config = {
                                "agent_id": f"cimd:{cimd_client_id}",
                                "client_id": cimd_client_id,
                                "resource_access": client_info.resource_access,
                                "enabled": True,
                            }
                            agent_id = agent_config["agent_id"]
                    except Exception as e:
                        logger.warning(f"Client Registry resolution failed for {cimd_client_id}: {e}")

                if not agent_config:
                    agent_config = {
                        "agent_id": f"cimd:{cimd_client_id}",
                        "client_id": cimd_client_id,
                        "resource_access": [],
                        "enabled": True,
                    }
                    agent_id = agent_config["agent_id"]

                scopes = []
                cimd_authenticated = True
                logger.debug(f"CIMD user {user_id} authenticated via relay (path-based)")

        # --- Standard Okta JWT validation (skipped for CIMD tokens) ---
        if not cimd_authenticated:
            # Extract agent name from X-MCP-Agent header to get expected client_id
            expected_client_id = None
            if headers:
                agent_name = headers.get("x-mcp-agent") or headers.get("X-MCP-Agent")
                if agent_name and agent_name in self.store.get_all_agents(enabled_only=False):
                    agent = self.store.get_agent(agent_name)
                    if agent:
                        expected_client_id = agent.client_id
                        logger.debug(f"Agent '{agent_name}' mapped to client_id '{expected_client_id}'")

            # Validate token with Okta
            claims = await self.okta_validator.validate_token(token, expected_client_id=expected_client_id)
            if not claims:
                logger.warning(f"Token validation failed for method {method}")
                return {
                    "error": "unauthorized",
                    "message": "Invalid or expired token"
                }

            user_id = claims.get("sub")

            # Reject tokens whose sub was revoked via global logout. JWTs
            # remain cryptographically valid until exp; this registry is
            # what makes logout effective on the hot path.
            try:
                from okta_agent_proxy.auth.revocation_registry import get_revocation_registry
                if await get_revocation_registry().is_revoked(user_id):
                    logger.info(f"Rejecting token for revoked user: sub={user_id}")
                    return {
                        "error": "unauthorized",
                        "message": "Invalid or expired token"
                    }
            except Exception as e:
                logger.warning(f"Revocation registry check failed (allowing): {e}")

            scopes = extract_scopes_from_claims(claims)
            logger.debug(f"User {user_id} authenticated with scopes: {scopes}")

            # Extract agent ID (optional, for multi-agent support)
            agent_id = None
            agent_config = None

            # Try to get agent from X-MCP-Agent header (case-insensitive)
            if headers:
                for header_name in ["X-MCP-Agent", "x-mcp-agent", "X-MCP-AGENT", "MCP-Agent"]:
                    if header_name in headers:
                        agent_id = headers[header_name]
                        logger.debug(f"Found agent header: {header_name}={agent_id}")
                        break

            # Get agent config from store if agent_id is known
            if agent_id and self.store:
                agent_config = self.store.get_agent_by_name(agent_id)
                if agent_config:
                    client_id = agent_config.get("client_id") if isinstance(agent_config, dict) else agent_config.client_id
                    logger.info(f"Agent '{agent_id}' found from header (client_id={client_id})")
                else:
                    logger.warning(f"Agent '{agent_id}' specified in header but not found in config")
                    return create_missing_agent_error_response(f"Agent '{agent_id}' not found")

            # Fallback: Try to find agent by token's aud or cid claim (client_id)
            if not agent_config and claims and self.store:
                token_aud = claims.get("aud")
                token_cid = claims.get("cid")
                lookup_values = {v for v in (token_aud, token_cid) if v}
                if lookup_values:
                    logger.debug(f"Agent not in header, attempting fallback lookup by token aud={token_aud} cid={token_cid}")
                    all_agents = self.store.get_all_agents(enabled_only=False)
                    matches = []
                    for agent_dict in all_agents:
                        if agent_dict:
                            agent_id_from_list = agent_dict.get("agent_id")
                            agent_client_id = agent_dict.get("client_id")
                            if agent_client_id in lookup_values:
                                matches.append((agent_id_from_list, agent_dict))

                    if len(matches) == 1:
                        agent_id, agent_config = matches[0]
                        logger.info(f"Found agent by token aud (fallback): {agent_id}")
                    elif len(matches) > 1:
                        logger.error(f"Multiple agents with client_id {token_aud}: {[m[0] for m in matches]}. Cannot proceed without explicit agent header.")
                        return {
                            "error": "ambiguous_agent",
                            "message": f"Multiple agents match token. Please include X-MCP-Agent header in requests."
                        }
                    else:
                        logger.warning(f"Token aud {token_aud} does not match any configured agent")

        # Enrich audit context with resolved identities
        if agent_id:
            agent_id_var.set(agent_id)
        if user_id:
            user_id_var.set(user_id)
        if agent_config:
            cid = agent_config.get("client_id") if isinstance(agent_config, dict) else getattr(agent_config, "client_id", None)
            if cid:
                client_id_var.set(cid)

        # Step 2: Route to resource based on path
        resource_name = self.router.get_resource_for_path(request_path)
        if not resource_name:
            logger.warning(f"No resource found for path: {request_path}")
            return {
                "error": "resource_not_found",
                "message": f"No resource configured for path '{request_path}'"
            }
        
        # Step 3: Verify agent has access to this resource (via syncer/resource store)

        resource_config = self.router.resolve_resource(resource_name, agent_id=agent_id)
        if not resource_config:
            return {
                "error": "resource_not_found",
                "message": f"Resource '{resource_name}' configuration not found"
            }
        
        resource_url = resource_config.url
        auth_method = resource_config.auth_method
        logger.info(f"Routing {method} to resource '{resource_name}' (auth: {auth_method}) for user {user_id}")
        
        # Check agent authorization for resource (if agent is configured)
        if agent_id and agent_config:
            try:
                await check_agent_can_access_resource(agent_id, agent_config, resource_name)
                logger.debug(f"Agent {agent_id} authorized for resource {resource_name}")
            except AgentAuthorizationError as e:
                logger.warning(f"Authorization denied: {e}")
                return create_authorization_error_response(e)
        
        # Recover the MCP client's originally-requested custom scopes from the
        # relay stash (bound to this access token via GatewayCodeManager.extra
        # at /oauth/callback). The user's bearer token's own `scp` claim is
        # OIDC-only and not meaningful here. Cache miss falls through to
        # apply_scope_condition's connection.scopes default.
        requested_scopes = None
        if self._relay is not None:
            try:
                info = await self._relay.alookup_token(token)
                if info:
                    recovered = info.get("custom_scopes") or []
                    if recovered:
                        requested_scopes = list(recovered)
            except Exception as e:
                logger.debug(f"relay.alookup_token failed during scope recovery: {e}")

        # Step 3: Resolve auth headers via consolidated resolver
        auth_result = await self.router.resolver.resolve_auth_headers(
            resource_name=resource_name,
            resource_config=resource_config,
            agent_config=agent_config,
            user_id=user_id,
            user_id_token=token,
            requested_scopes=requested_scopes,
        )

        resource_token = None  # Used for session creation and 401 retry

        if auth_result.consent_required:
            consent = auth_result.consent_required
            provider = consent.get("provider", resource_name)
            logger.info(f"STS consent required for {resource_name} (provider={provider})")
            return {
                "error": "consent_required",
                "consent_url": consent.get("interaction_uri", ""),
                "provider": provider,
                "resource_indicator": consent.get("resource_indicator", ""),
                "instructions": f"Open this URL in your browser to authorize the AI agent to access {provider} on your behalf. After authorizing, re-run your command.",
                "retry_hint": "After completing authorization, simply re-run the same tool call.",
                "expires_in": 600,
            }

        if not auth_result.ok:
            error = auth_result.error or "auth_failed"
            message = auth_result.error_message or f"Auth failed for resource '{resource_name}'"
            logger.error(f"Auth resolution failed for {resource_name}: {error} — {message}")
            latency_ms = round((time.monotonic() - start_time) * 1000, 2)
            await emit_audit_event(
                AuditEventType.TOKEN_EXCHANGE_FAILURE,
                severity=AuditSeverity.WARNING,
                resource_name=resource_name,
                details={"agent_id": agent_id, "reason": error},
                outcome="failure",
            )
            await emit_audit_event(
                AuditEventType.MCP_TOOL_CALL if method == "tools/call" else AuditEventType.MCP_TOOL_LIST,
                severity=AuditSeverity.WARNING,
                resource_name=resource_name,
                details={"method": method, "latency_ms": latency_ms, "error": error},
                outcome="failure",
            )
            return {"error": error, "message": message}

        auth_headers = auth_result.headers

        if auth_method in ("okta-cross-app", "okta-sts"):
            # Extract token from Bearer header for session management
            bearer_val = auth_headers.get("Authorization", "")
            if bearer_val.startswith("Bearer "):
                resource_token = bearer_val[7:]
            await emit_audit_event(
                AuditEventType.TOKEN_EXCHANGE_SUCCESS,
                resource_name=resource_name,
                details={"agent_id": agent_id, "auth_method": auth_method},
            )
        elif auth_method in ("vault-secret", "sts-service-account"):
            await emit_audit_event(
                AuditEventType.TOKEN_EXCHANGE_SUCCESS,
                resource_name=resource_name,
                details={"agent_id": agent_id, "auth_method": auth_method},
            )
        
        # Step 4: Forward to resource
        try:
            logger.debug(
                f"Forwarding {method} request to {resource_name} at {resource_url}"
            )
            
            # Build JSON-RPC request for resource
            resource_request = {
                "jsonrpc": "2.0",
                "id": request_id or "1",
                "method": method,
            }
            if params:
                resource_request["params"] = params

            # Create or get MCP session
            session_id = await self.session_manager.get_or_create_session(
                user_id=user_id,
                resource_name=resource_name,
                resource_url=resource_url,
                access_token=resource_token if auth_method in ("okta-cross-app", "okta-sts") else ""
            )

            if not session_id:
                logger.error(f"Failed to create MCP session for {resource_name}")
                return {
                    "error": "session_creation_failed",
                    "message": f"Could not create MCP session for resource '{resource_name}'"
                }
            
            # Add session ID to headers
            request_headers = {
                **auth_headers,
                "Content-Type": "application/json",
                "Accept": "application/json, text/event-stream",
                "Mcp-Session-Id": session_id
            }
            
            async with httpx.AsyncClient() as client:
                response = await client.post(
                    resource_url,
                    json=resource_request,
                    headers=request_headers,
                    timeout=self.http_timeout
                )
            
            # Step 5: Handle response
            if response.status_code == 401:
                # Resource rejected token - invalidate cache and retry once with fresh token
                logger.warning(
                    f"Resource returned 401 for {user_id} on {resource_name}, "
                    f"invalidating cached token and retrying"
                )
                self.router.invalidate_resource_token(
                    user_id, resource_name,
                    agent_id=getattr(resource_config, "agent_id", None),
                    connection_id=getattr(resource_config, "connection_id", None),
                )
                self.session_manager.invalidate_session(user_id, resource_name)

                # Retry with a fresh token (for auth methods that support refresh)
                if auth_method in ("okta-cross-app", "okta-sts", "vault-secret", "sts-service-account"):
                    retry_result = await self.router.resolver.resolve_auth_headers(
                        resource_name=resource_name,
                        resource_config=resource_config,
                        agent_config=agent_config,
                        user_id=user_id,
                        user_id_token=token,
                        force_refresh=True,
                        requested_scopes=requested_scopes,
                    )
                    if retry_result.ok:
                        retry_auth_headers = retry_result.headers
                        # Extract token for session
                        retry_bearer = retry_auth_headers.get("Authorization", "")
                        retry_token_val = retry_bearer[7:] if retry_bearer.startswith("Bearer ") else ""

                        # Re-create session for retry
                        retry_session_id = await self.session_manager.get_or_create_session(
                            user_id=user_id,
                            resource_name=resource_name,
                            resource_url=resource_url,
                            access_token=retry_token_val
                        )
                        retry_headers = {
                            **retry_auth_headers,
                            "Content-Type": "application/json",
                            "Accept": "application/json, text/event-stream",
                        }
                        if retry_session_id:
                            retry_headers["Mcp-Session-Id"] = retry_session_id

                        async with httpx.AsyncClient() as client:
                            retry_response = await client.post(
                                resource_url,
                                json=resource_request,
                                headers=retry_headers,
                                timeout=self.http_timeout
                            )

                        if retry_response.status_code == 200:
                            logger.info(
                                f"Retry succeeded for {user_id} on {resource_name} after token refresh"
                            )
                            response = retry_response
                        else:
                            logger.warning(
                                f"Retry also failed with status {retry_response.status_code} "
                                f"for {user_id} on {resource_name}"
                            )

                # If we didn't retry or retry also failed, return error
                if response.status_code == 401:
                    latency_ms = round((time.monotonic() - start_time) * 1000, 2)
                    await emit_audit_event(
                        AuditEventType.MCP_TOOL_CALL if method == "tools/call" else AuditEventType.MCP_TOOL_LIST,
                        severity=AuditSeverity.WARNING,
                        resource_name=resource_name,
                        details={"method": method, "latency_ms": latency_ms, "error": "backend_unauthorized"},
                        outcome="failure",
                    )
                    return {
                        "error": "backend_unauthorized",
                        "message": f"Backend rejected authentication"
                    }

            # Handle 404 "Session not found" — stale cached session after resource restart
            if response.status_code == 404:
                resp_text = response.text
                if "Session not found" in resp_text or "session" in resp_text.lower():
                    logger.warning(
                        f"Resource {resource_name} returned 404 (stale session) for {user_id}, "
                        f"invalidating session and retrying with fresh session"
                    )
                    self.session_manager.invalidate_session(user_id, resource_name)

                    # Create a fresh session
                    retry_session_id = await self.session_manager.get_or_create_session(
                        user_id=user_id,
                        resource_name=resource_name,
                        resource_url=resource_url,
                        access_token=resource_token if auth_method in ("okta-cross-app", "okta-sts") else ""
                    )
                    retry_headers = {
                        **auth_headers,
                        "Content-Type": "application/json",
                        "Accept": "application/json, text/event-stream",
                    }
                    if retry_session_id:
                        retry_headers["Mcp-Session-Id"] = retry_session_id

                    async with httpx.AsyncClient() as client:
                        retry_response = await client.post(
                            resource_url,
                            json=resource_request,
                            headers=retry_headers,
                            timeout=self.http_timeout
                        )

                    if retry_response.status_code == 200:
                        logger.info(
                            f"Retry succeeded for {user_id} on {resource_name} after session refresh"
                        )
                        response = retry_response
                    else:
                        logger.warning(
                            f"Retry after session refresh also failed with status "
                            f"{retry_response.status_code} for {user_id} on {resource_name}"
                        )

            # After retry logic, response may have been replaced with successful retry.
            # Use if (not elif) so both original 200s and successful retries are handled.
            if response.status_code == 200:
                content_type = response.headers.get("content-type", "")

                if "text/event-stream" in content_type:
                    # Parse SSE response — extract JSON from "data:" lines
                    result = _parse_sse_response(response.text)
                else:
                    # Plain JSON response
                    result = response.json()

                if result is None:
                    logger.error(f"Failed to parse response from {resource_name}")
                    return {
                        "error": "proxy_error",
                        "message": f"Could not parse response from resource '{resource_name}'"
                    }

                logger.debug(f"Resource {resource_name} returned 200 OK for {method}")

                latency_ms = round((time.monotonic() - start_time) * 1000, 2)
                event_type = AuditEventType.MCP_TOOL_CALL if method == "tools/call" else AuditEventType.MCP_TOOL_LIST
                event_details: Dict[str, Any] = {"method": method, "latency_ms": latency_ms}

                # Log tools count if it's a tools/list response
                if method == "tools/list" and "result" in result:
                    tools = result["result"].get("tools", [])
                    logger.info(f"Resource returned {len(tools)} tools")
                    event_details["tool_count"] = len(tools)

                if method == "tools/call" and params:
                    event_details["tool_name"] = params.get("name", "")

                await emit_audit_event(
                    event_type,
                    resource_name=resource_name,
                    details=event_details,
                )

                return result.get("result", result)

            elif response.status_code != 401:
                # Other HTTP error from backend (401 already handled above)
                logger.error(
                    f"Resource {resource_name} returned {response.status_code}: "
                    f"{response.text}"
                )
                latency_ms = round((time.monotonic() - start_time) * 1000, 2)
                await emit_audit_event(
                    AuditEventType.MCP_TOOL_CALL if method == "tools/call" else AuditEventType.MCP_TOOL_LIST,
                    severity=AuditSeverity.WARNING,
                    resource_name=resource_name,
                    details={"method": method, "latency_ms": latency_ms,
                             "error": f"backend_http_{response.status_code}"},
                    outcome="failure",
                )
                return {
                    "error": f"backend_http_{response.status_code}",
                    "message": f"Backend returned HTTP {response.status_code}"
                }

        except httpx.TimeoutException:
            logger.error(f"Timeout connecting to resource {resource_name}")
            latency_ms = round((time.monotonic() - start_time) * 1000, 2)
            await emit_audit_event(
                AuditEventType.MCP_TOOL_CALL if method == "tools/call" else AuditEventType.MCP_TOOL_LIST,
                severity=AuditSeverity.WARNING,
                resource_name=resource_name,
                details={"method": method, "latency_ms": latency_ms, "error": "backend_timeout"},
                outcome="failure",
            )
            return {
                "error": "backend_timeout",
                "message": f"Resource '{resource_name}' did not respond in time"
            }

        except httpx.RequestError as e:
            logger.error(
                f"Network error connecting to {resource_name}: {e}",
                exc_info=True
            )
            latency_ms = round((time.monotonic() - start_time) * 1000, 2)
            await emit_audit_event(
                AuditEventType.MCP_TOOL_CALL if method == "tools/call" else AuditEventType.MCP_TOOL_LIST,
                severity=AuditSeverity.WARNING,
                resource_name=resource_name,
                details={"method": method, "latency_ms": latency_ms, "error": "backend_connection_error"},
                outcome="failure",
            )
            return {
                "error": "backend_connection_error",
                "message": f"Could not connect to resource '{resource_name}'"
            }

        except Exception as e:
            logger.error(
                f"Error proxying request to {resource_name}: {e}",
                exc_info=True
            )
            latency_ms = round((time.monotonic() - start_time) * 1000, 2)
            await emit_audit_event(
                AuditEventType.MCP_TOOL_CALL if method == "tools/call" else AuditEventType.MCP_TOOL_LIST,
                severity=AuditSeverity.WARNING,
                resource_name=resource_name,
                details={"method": method, "latency_ms": latency_ms, "error": str(e)},
                outcome="failure",
            )
            return {
                "error": "proxy_error",
                "message": str(e)
            }



# Global proxy handler instance
_proxy_handler: Optional[ProxyHandler] = None


def get_proxy_handler(
    router: Optional[ResourceRouter] = None,
    validator: Optional[OktaTokenValidator] = None,
    store: Optional[ResourceConfigStore] = None
) -> ProxyHandler:
    """
    Get or create the global ProxyHandler instance.
    
    Args:
        router: ResourceRouter instance (required on first call)
        validator: OktaTokenValidator instance (required on first call)
        store: Optional ResourceConfigStore for agent lookup

    Returns:
        ProxyHandler instance
    """
    global _proxy_handler
    if _proxy_handler is None:
        if not router or not validator:
            raise ValueError(
                "router and validator required on first ProxyHandler creation"
            )
        _proxy_handler = ProxyHandler(router, validator, store)
    return _proxy_handler

