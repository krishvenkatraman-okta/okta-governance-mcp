"""
Resource routing - maps request paths to appropriate MCP resource servers

Also handles:
- Resource token caching (by user + resource)
- Token exchange via Okta cross-app access (ID-JAG)
- Token expiration management
"""

import json
import logging
import os
from typing import Optional, Dict, Any
from datetime import datetime, timedelta
import httpx as httpx_lib

from okta_agent_proxy.config import BackendConfig, BackendAuthConfig
from okta_agent_proxy.cache import TokenCache
from okta_agent_proxy.audit import emit_audit_event, AuditEventType, AuditSeverity
from okta_agent_proxy.auth.cross_app_access import OktaCrossAppAccessManager
from okta_agent_proxy.auth.okta_vault_exchanger import OktaVaultSecretExchanger
from okta_agent_proxy.auth.adapter_cimd import AdapterCIMDServer
from okta_agent_proxy.auth.outbound_dcr import OutboundDCRClient
from okta_agent_proxy.discovery import get_discovery_client
from okta_agent_proxy.storage import ResourceConfigStore
from okta_agent_proxy.auth.user_token_store import get_user_token_store
from okta_agent_proxy.auth.token_refresher import get_token_refresher
from okta_agent_proxy.auth.resource_token_resolver import ResourceTokenResolver

logger = logging.getLogger(__name__)


class ResolvedResourceConfigAdapter:
    """Adapter that wraps a ResolvedResource to match the resource config interface.

    Allows the proxy pipeline (ProxyHandler, UnifiedMCPHandler) to consume
    ResolvedResource objects from the OktaConnectionSyncer without changes
    to their attribute-access patterns (e.g. resource_config.url,
    resource_config.auth_method).
    """

    def __init__(self, resolved_resource):
        self._rb = resolved_resource
        # Provide a minimal auth_config object that supports .model_dump()
        self.auth_config = _MinimalAuthConfig(resolved_resource)

    @property
    def name(self):
        return self._rb.name

    @property
    def url(self):
        return self._rb.mcp_url

    @property
    def auth_method(self):
        return self._rb.auth_method

    @property
    def resource_type(self):
        return self._rb.protocol

    @property
    def config(self):
        return self._rb.config

    @property
    def enabled(self):
        return self._rb.enabled

    @property
    def tags(self):
        return self._rb.tags

    @property
    def paths(self):
        return []  # Resources use canonical name routing

    @property
    def description(self):
        return self._rb.description

    @property
    def timeout_seconds(self):
        return self._rb.config.get("timeout_seconds", 30) if isinstance(self._rb.config, dict) else 30

    @property
    def resource_id(self):
        return self._rb.resource_id

    @property
    def connection_id(self):
        return self._rb.connection_id

    @property
    def agent_id(self):
        return self._rb.agent_id

    @property
    def isolation_key(self):
        return self._rb.isolation_key

    @property
    def connection_type(self):
        return self._rb.connection_type

    @property
    def protocol(self):
        return self._rb.protocol

    @property
    def scopes(self):
        return self._rb.scopes

    @property
    def scope_condition(self):
        return self._rb.scope_condition

    @property
    def metadata(self):
        return self._rb.metadata

    def to_dict(self):
        """Return a dict representation of the resolved resource."""
        return {
            "name": self._rb.name,
            "url": self._rb.mcp_url,
            "type": self._rb.protocol,
            "auth_method": self._rb.auth_method,
            "scopes": self._rb.scopes,
            "scope_condition": self._rb.scope_condition.value if hasattr(self._rb.scope_condition, 'value') else str(self._rb.scope_condition),
            "enabled": self._rb.enabled,
            "resource_id": self._rb.resource_id,
            "connection_id": self._rb.connection_id,
            "connection_type": self._rb.connection_type.value if hasattr(self._rb.connection_type, 'value') else str(self._rb.connection_type),
            "protocol": self._rb.protocol,
            "description": self._rb.description,
            "config": self._rb.config,
            "tags": self._rb.tags,
        }


class _MinimalAuthConfig:
    """Minimal auth_config that satisfies .model_dump() calls in the pipeline."""

    def __init__(self, resolved_resource):
        self._rb = resolved_resource

    def model_dump(self):
        return {
            "scopes": self._rb.scopes,
            "scope_condition": self._rb.scope_condition.value if hasattr(self._rb.scope_condition, 'value') else str(self._rb.scope_condition),
            "resource_id": self._rb.resource_id,
        }

    def dict(self):
        return self.model_dump()


class ResourceRouter:
    """
    Routes incoming requests to appropriate resource MCP server.

    Maintains mappings of URL paths to resource servers.
    Example: /hr -> employees_mcp, /partners -> partners_mcp
    """
    
    def __init__(
        self,
        resources_config: Dict[str, BackendConfig],
        store: Optional[ResourceConfigStore] = None,
        cache_service: Optional[Any] = None,
        encryption_service: Optional[Any] = None,
        syncer=None,
    ):
        """
        Initialize router with resource configurations.

        Args:
            resources_config: Dictionary of resource configurations
            store: Optional ResourceConfigStore for resource lookup/updates
            cache_service: Optional CacheService for shared/distributed token caching
            encryption_service: Optional EncryptionService for encrypting cached tokens
            syncer: Optional OktaConnectionSyncer — when present, syncer is the
                    primary source of resource configs (Resource Map architecture).
        """
        self.resources = resources_config
        self.store = store  # Can be used to dynamically load resources
        self.syncer = syncer  # Resource Map syncer (P3+)
        self._path_to_resource: Dict[str, str] = {}

        # Initialize token cache for resource tokens
        # Cache key: f"{user_id}:{resource_name}"
        # Value: {"token": str, "expires_at": datetime}
        self.resource_token_cache = TokenCache(
            max_size=50000,  # Cache up to 50k tokens
            ttl_seconds=3600,  # Default TTL (can vary by token)
            cache_service=cache_service,
            encryption_service=encryption_service,
        )
        
        # Cross-app access manager (will be initialized per agent in proxy handler)
        self.cross_app_manager = None

        # Consolidated auth resolver — single source of truth for token exchange
        self.resolver = ResourceTokenResolver(self.resource_token_cache)
        
        # Get discovery client for dynamic auth server discovery
        self.discovery_client = get_discovery_client(cache_service=cache_service)
        
        # Build path -> resource mapping from static config
        for resource_name, resource_config in resources_config.items():
            for path in resource_config.paths:
                self._path_to_resource[path] = resource_name
                logger.info(f"Route registered: {path} -> {resource_name} ({resource_config.url})")
            # Always register the resource name itself as a canonical route
            canonical_path = f"/{resource_name}"
            if canonical_path not in self._path_to_resource:
                self._path_to_resource[canonical_path] = resource_name
                logger.info(f"Route registered (canonical): {canonical_path} -> {resource_name} ({resource_config.url})")

        # Load resources from database store (supplements static config)
        self.load_resources_from_store()

    def load_resources_from_store(self):
        """Load resource configurations from the database store into the router."""
        if not self.store:
            return

        try:
            all_resources = self.store.get_all_resources()
            for resource_data in all_resources:
                name = resource_data.get("name")
                if not name:
                    continue

                # Skip if already registered from static config
                if name in self.resources:
                    logger.debug(f"Resource '{name}' already registered from static config, skipping store version")
                    continue

                # Parse paths (could be JSON string from DB or already a list)
                paths = resource_data.get("paths", [])
                if isinstance(paths, str):
                    try:
                        paths = json.loads(paths)
                    except (json.JSONDecodeError, TypeError):
                        paths = []

                # Parse auth_config (could be JSON string or dict)
                auth_config = resource_data.get("auth_config", {})
                if isinstance(auth_config, str):
                    try:
                        auth_config = json.loads(auth_config)
                    except (json.JSONDecodeError, TypeError):
                        auth_config = {}

                # Create BackendConfig from store data
                resource_config = BackendConfig(
                    name=name,
                    url=resource_data.get("url", ""),
                    paths=paths,
                    auth_method=resource_data.get("auth_method", "pre-shared-key"),
                    auth_config=BackendAuthConfig(**auth_config) if isinstance(auth_config, dict) else BackendAuthConfig(),
                    description=resource_data.get("description", ""),
                    timeout_seconds=resource_data.get("timeout_seconds", 30),
                    enabled=resource_data.get("enabled", True),
                )

                # Only register enabled resources
                if not resource_config.enabled:
                    logger.info(f"Resource '{name}' is disabled, skipping route registration")
                    continue

                # Add to resources dict and register routes
                self.resources[name] = resource_config
                for path in paths:
                    existing_owner = self._path_to_resource.get(path)
                    if existing_owner and existing_owner != name:
                        logger.warning(
                            f"Route conflict at startup: path '{path}' claimed by both "
                            f"'{existing_owner}' and '{name}' — '{name}' wins (last-write)"
                        )
                    self._path_to_resource[path] = name
                    logger.info(f"Route registered (from database): {path} -> {name} ({resource_config.url})")

                # Auto-register canonical path from resource name
                canonical_path = f"/{name}"
                if canonical_path not in self._path_to_resource:
                    self._path_to_resource[canonical_path] = name
                    logger.info(f"Route registered (canonical, from database): {canonical_path} -> {name}")

            logger.info(f"Loaded {len(all_resources)} resources from database, "
                        f"total routes: {len(self._path_to_resource)}")
        except Exception as e:
            logger.error(f"Failed to load resources from store: {e}", exc_info=True)

    def get_path_conflicts(self, name: str, paths: list) -> list:
        """
        Check if any of the given paths conflict with routes owned by other resources.

        Args:
            name: The resource name being created/updated (its own paths are not conflicts)
            paths: List of paths to check (e.g., ["/hr", "/employees"])

        Returns:
            List of conflict dicts: [{"path": "/hr", "owned_by": "other-resource"}]
        """
        conflicts = []
        for path in paths:
            if path in self._path_to_resource:
                owner = self._path_to_resource[path]
                if owner != name:
                    conflicts.append({"path": path, "owned_by": owner})
        return conflicts

    def register_resource(self, name: str, resource_config: BackendConfig):
        """
        Register a new resource and its routes dynamically.

        Called by Admin API when a resource is created or updated.
        """
        self.resources[name] = resource_config
        for path in resource_config.paths:
            existing_owner = self._path_to_resource.get(path)
            if existing_owner and existing_owner != name:
                logger.warning(
                    f"Route conflict: path '{path}' reassigned from resource "
                    f"'{existing_owner}' to '{name}'"
                )
            self._path_to_resource[path] = name
            logger.info(f"Route registered (dynamic): {path} -> {name} ({resource_config.url})")
        # Always register canonical path
        canonical_path = f"/{name}"
        if canonical_path not in self._path_to_resource:
            self._path_to_resource[canonical_path] = name
            logger.info(f"Route registered (canonical, dynamic): {canonical_path} -> {name}")

    def unregister_resource(self, name: str):
        """
        Remove a resource and its routes.

        Called by Admin API when a resource is deleted.
        """
        if name in self.resources:
            self.resources.pop(name)
            self._path_to_resource = {
                path: bn for path, bn in self._path_to_resource.items()
                if bn != name
            }
            logger.info(f"Resource '{name}' and its routes removed")

    def get_resource_for_path(self, path: str) -> Optional[str]:
        """
        Get resource name for a request path.

        Args:
            path: Request path (e.g., "/hr", "/partners")

        Returns:
            Resource name or None if path not found
        """
        # Direct match
        if path in self._path_to_resource:
            return self._path_to_resource[path]
        
        # Try matching with /mcp stripped (common in MCP requests)
        path_without_mcp = path.replace("/mcp", "", 1)
        if path_without_mcp in self._path_to_resource:
            return self._path_to_resource[path_without_mcp]
        
        # Extract base path (e.g., /hr from /hr/mcp)
        parts = path.split("/")
        if len(parts) > 1:
            base_path = "/" + parts[1]
            if base_path in self._path_to_resource:
                return self._path_to_resource[base_path]

        # Fallback: treat path as resource name directly
        stripped = path.lstrip("/").split("/")[0]
        if stripped in self.resources:
            return stripped

        # Check syncer resources by name (Resource Map canonical routing)
        if self.syncer and self.syncer.get_resource(stripped):
            return stripped

        logger.warning(f"No resource found for path: {path}")
        return None

    def get_token_cache(self):
        """Return the token cache instance."""
        return self.resource_token_cache

    def get_resource_config(self, resource_name: str) -> Optional[BackendConfig]:
        """
        Get configuration for a resource.

        When a syncer is configured (Resource Map architecture), it is checked
        first.  Falls back to the static resources dict.

        Args:
            resource_name: Resource identifier

        Returns:
            BackendConfig (or ResolvedResourceConfigAdapter) or None if not found
        """
        # Check syncer first (Resource Map path)
        if self.syncer:
            resolved = self.syncer.get_resource(resource_name)
            if resolved:
                return ResolvedResourceConfigAdapter(resolved)
        return self.resources.get(resource_name)

    def resolve_resource(
        self,
        resource_name: str,
        agent_id: str | None = None,
    ) -> Optional[BackendConfig]:
        """Resolve a resource scoped to the requesting agent.

        Resolution order:
        1. If agent_id provided and syncer available: agent-scoped resource
        2. Fall back to syncer lookup by name (any agent)
        3. Fall back to locally-configured resource (static config)
        4. Return None if no match

        Args:
            resource_name: Resource identifier
            agent_id: Agent ID for connection-scoped isolation (optional)

        Returns:
            BackendConfig (or ResolvedResourceConfigAdapter) or None
        """
        if agent_id and self.syncer:
            agent_resources = self.syncer.get_resolved_resources_for_agent(agent_id)
            if resource_name in agent_resources:
                resolved = agent_resources[resource_name]
                logger.debug(
                    "[ROUTER] Resolved '%s' for agent '%s' via connection '%s'",
                    resource_name, agent_id, resolved.connection_id,
                )
                return ResolvedResourceConfigAdapter(resolved)

        # Fall back to unscoped syncer lookup (backward compat)
        if self.syncer:
            resolved = self.syncer.get_resource(resource_name)
            if resolved:
                logger.debug("[ROUTER] Resolved '%s' via syncer (unscoped)", resource_name)
                return ResolvedResourceConfigAdapter(resolved)

        # Fall back to static config
        local = self.resources.get(resource_name)
        if local:
            logger.debug("[ROUTER] Resolved '%s' via local config", resource_name)
            return local

        logger.warning("[ROUTER] Resource '%s' not found for agent '%s'", resource_name, agent_id)
        return None

    def get_resource_url(self, resource_name: str) -> Optional[str]:
        """
        Get URL for a resource.

        Args:
            resource_name: Resource identifier

        Returns:
            Resource URL or None if not found
        """
        config = self.get_resource_config(resource_name)
        return config.url if config else None

    def list_resources(self) -> Dict[str, Dict]:
        """
        List all registered resources.

        Returns:
            Dictionary with resource info
        """
        result = {}
        # Include syncer resources first (Resource Map)
        if self.syncer:
            for rb in self.syncer.get_all_resources():
                result[rb.name] = {
                    "url": rb.mcp_url,
                    "description": rb.description,
                    "paths": [],
                    "timeout_seconds": 30,
                }
        # Then static resources (may override syncer entries)
        for resource_name, config in self.resources.items():
            result[resource_name] = {
                "url": config.url,
                "description": config.description,
                "paths": config.paths,
                "timeout_seconds": config.timeout_seconds
            }
        return result

    def list_routes(self) -> Dict[str, str]:
        """
        List all registered routes.

        Returns:
            Dictionary mapping paths to resource names
        """
        return dict(self._path_to_resource)
    
    async def resolve_resource_auth(
        self,
        resource_name: str,
        resource_config: dict,
        agent_config: dict,
        user_token: str,
    ) -> dict:
        """Select the outbound authentication strategy for a resource.

        Examines resource_config["registration_strategy"] to decide how the
        adapter authenticates to the resource:

          "static" → existing auth handler (PSK, service-account, bearer)
          "xaa"    → OktaCrossAppAccessManager (ID-JAG token exchange)
          "cimd"   → adapter uses private_key_jwt with its own CIMD identity
          "dcr"    → outbound DCR to obtain credentials, then use them
          "auto"   → try CIMD, then DCR, then error

        Returns:
            dict with keys:
              - "strategy": resolved strategy name
              - "client_id": (for cimd/dcr) assigned client_id
              - "client_secret": (for dcr) assigned secret
              - "client_assertion": (for cimd) signed JWT assertion
              - "token_endpoint": (for cimd/dcr) resource token endpoint
              - "error": (if resolution failed) error message
        """
        strategy = resource_config.get("registration_strategy", "static")
        resource_url = resource_config.get("url", "")

        if strategy == "static":
            return {"strategy": "static"}

        if strategy == "xaa":
            return {"strategy": "xaa"}

        if strategy == "cimd":
            return await self._resolve_cimd_auth(resource_url, resource_config)

        if strategy == "dcr":
            return await self._resolve_dcr_auth(resource_url, resource_config)

        if strategy == "auto":
            # Try CIMD first, then DCR
            result = await self._resolve_cimd_auth(resource_url, resource_config)
            if "error" not in result:
                return result

            result = await self._resolve_dcr_auth(resource_url, resource_config)
            if "error" not in result:
                return result

            return {
                "strategy": "auto",
                "error": (
                    f"Auto strategy exhausted for {resource_name}: "
                    "resource does not support CIMD or DCR"
                ),
            }

        return {"strategy": strategy, "error": f"Unknown strategy: {strategy}"}

    async def _resolve_cimd_auth(self, resource_url: str, resource_config: dict) -> dict:
        """Build a client_assertion for private_key_jwt auth using the adapter CIMD."""
        # Discover the resource's token endpoint
        base = resource_url.rstrip("/")
        token_endpoint = None

        try:
            async with httpx_lib.AsyncClient() as client:
                for path in [
                    "/.well-known/oauth-authorization-server",
                    "/.well-known/openid-configuration",
                ]:
                    resp = await client.get(f"{base}{path}", timeout=10)
                    if resp.status_code == 200:
                        data = resp.json()
                        token_endpoint = data.get("token_endpoint")
                        # Check if the resource advertises CIMD support
                        cimd_supported = data.get(
                            "client_id_metadata_document_supported", False
                        )
                        if token_endpoint:
                            break
        except Exception as e:
            logger.debug(f"CIMD discovery failed for {resource_url}: {e}")
            return {"strategy": "cimd", "error": f"Discovery failed: {e}"}

        if not token_endpoint:
            return {"strategy": "cimd", "error": "No token_endpoint discovered"}

        adapter_cimd = AdapterCIMDServer()
        assertion = adapter_cimd.sign_client_assertion(token_endpoint)

        return {
            "strategy": "cimd",
            "client_id": adapter_cimd.client_id,
            "client_assertion": assertion,
            "token_endpoint": token_endpoint,
        }

    async def _resolve_dcr_auth(self, resource_url: str, resource_config: dict) -> dict:
        """Perform outbound DCR to obtain credentials from the resource."""
        # Check if we already have cached DCR credentials in auth_config
        auth_config = resource_config.get("auth_config", {})
        if isinstance(auth_config, dict):
            existing_client_id = auth_config.get("dcr_client_id")
            existing_secret = auth_config.get("dcr_client_secret")
            if existing_client_id:
                return {
                    "strategy": "dcr",
                    "client_id": existing_client_id,
                    "client_secret": existing_secret,
                }

        adapter_cimd = AdapterCIMDServer()
        dcr_client = OutboundDCRClient(adapter_cimd)
        registration = await dcr_client.discover_and_register(resource_url)

        if not registration:
            return {"strategy": "dcr", "error": "Outbound DCR failed"}

        # Store credentials back into resource config for future use
        if self.store:
            try:
                self.store.update_resource(
                    resource_config.get("name", ""),
                    {
                        "auth_config": {
                            **auth_config,
                            "dcr_client_id": registration.client_id,
                            "dcr_client_secret": registration.client_secret,
                        }
                    },
                    user="system",
                )
            except Exception as e:
                logger.warning(f"Failed to persist DCR credentials: {e}")

        return {
            "strategy": "dcr",
            "client_id": registration.client_id,
            "client_secret": registration.client_secret,
        }

    async def get_resource_token(
        self,
        user_id: str,
        resource_name: str,
        user_id_token: str,
        agent_config: Optional[Dict[str, Any]] = None,
        force_refresh: bool = False,
        requested_scopes: Optional[list] = None,
    ) -> Optional[str]:
        """
        Get resource token via cache or ID-JAG flow using CrossAppAccessFlow.

        Implements IETF Identity Assertion Authorization Grant (ID-JAG) pattern:
        https://www.ietf.org/archive/id/draft-ietf-oauth-identity-assertion-authz-grant-00.html

        3-step flow via OktaCrossAppAccessManager:
        1. Exchange ID Token for ID-JAG token (org auth server)
        2. Verify ID-JAG token (optional)
        3. Exchange ID-JAG for target auth server token

        Cache:
        1. Check cache for existing access token
        2. If cached token valid, return it
        3. Otherwise, perform ID-JAG flow
        4. Cache new token with TTL
        5. Return access token

        Args:
            user_id: User identifier (from JWT sub claim)
            resource_name: Resource MCP server name
            user_id_token: User's ID token from agent/client authentication
            agent_config: Agent configuration dict with agent_id, client_id, private_key
            force_refresh: Force token refresh even if cached

        Returns:
            Access token for resource or None if exchange fails

        Raises:
            ValueError if resource not found
        """
        # Build cache key components
        # Try cache first (unless force_refresh)
        if not force_refresh:
            cached = self.resource_token_cache.get(user_id, resource_name)
            if cached:
                token_data = cached
                if isinstance(token_data, dict) and "token" in token_data:
                    # Check if token is still valid
                    expires_at = token_data.get("expires_at")
                    if expires_at and datetime.now() < expires_at:
                        logger.debug(
                            f"Using cached resource token for {user_id}:{resource_name}"
                        )
                        return token_data["token"]

        # Get resource config
        resource_config = self.get_resource_config(resource_name)
        if not resource_config:
            logger.error(f"Resource not found: {resource_name}")
            raise ValueError(f"Resource '{resource_name}' not found")

        # Check auth method — dispatch to appropriate flow
        auth_method = getattr(resource_config, "auth_method", None)

        if auth_method == "vault-secret":
            return await self._get_vault_secret_token(
                resource_name, resource_config, agent_config, user_id_token
            )

        if auth_method == "sts-service-account":
            return await self._get_sts_service_account_token(
                resource_name, resource_config, agent_config, user_id_token
            )

        if auth_method != "okta-cross-app":
            logger.warning(f"Resource {resource_name} does not use okta-cross-app auth")
            return user_id_token  # Return user token as fallback

        # For ResolvedResourceConfigAdapter (Resource Map), the resource_id IS
        # the authorization server ID — use it directly, no discovery needed.
        if isinstance(resource_config, ResolvedResourceConfigAdapter):
            target_auth_server_id = resource_config.resource_id
            target_authorization_server = f"{os.getenv('OKTA_DOMAIN', '')}"
            if target_authorization_server and not target_authorization_server.startswith("http"):
                target_authorization_server = f"https://{target_authorization_server}"
            target_authorization_server = f"{target_authorization_server}/oauth2/{target_auth_server_id}"
            auth_config = resource_config.auth_config.model_dump()
            logger.info(f"Resource Map resource {resource_name}: resource_id={target_auth_server_id}")
        else:
            # Get auth configuration
            auth_config = getattr(resource_config, "auth_config", {})
            logger.info(f"Resource {resource_name} auth_config type: {type(auth_config)}, value: {auth_config}")

            # Convert Pydantic model to dict if needed
            if hasattr(auth_config, "model_dump"):
                # Pydantic v2
                auth_config = auth_config.model_dump()
            elif hasattr(auth_config, "dict"):
                # Pydantic v1
                auth_config = auth_config.dict()
            elif not isinstance(auth_config, dict):
                logger.warning(f"Resource {resource_name} invalid auth_config format - expected dict or Pydantic model, got {type(auth_config)}")
                logger.warning(f"Resource {resource_name} config object: {resource_config}")
                return None

            logger.info(f"Converted auth_config to dict: {auth_config}")

        # Determine ID-JAG mode (static or dynamic)
        id_jag_mode = auth_config.get("id_jag_mode", "static")
        target_authorization_server = auth_config.get("target_authorization_server") or (
            target_authorization_server if isinstance(resource_config, ResolvedResourceConfigAdapter) else None
        )

        # For dynamic mode, discover auth server details from target
        if id_jag_mode == "dynamic":
            logger.info(f"Using DYNAMIC ID-JAG mode for {resource_name}")

            discovered = await self.discovery_client.extract_auth_server_details(
                resource_config.url,
                force_refresh=False
            )

            if not discovered:
                logger.error(f"Failed to discover auth server details for {resource_name}")
                return None

            target_authorization_server = discovered.get("target_authorization_server")
            logger.info(
                f"Discovered auth server for {resource_name}: {target_authorization_server}"
            )
        else:
            logger.info(f"Using STATIC ID-JAG mode for {resource_name}")

            if not target_authorization_server:
                logger.error(
                    f"Static ID-JAG mode requires target_authorization_server for {resource_name}"
                )
                return None

        # Use OktaCrossAppAccessManager for token exchange
        try:
            # Get authorization server ID from config
            # For static mode, it's configured in auth_config
            # For dynamic mode, it's discovered from resource
            target_auth_server_id = target_authorization_server.split("/oauth2/")[-1] if target_authorization_server else None
            if not target_auth_server_id:
                logger.error(f"Cannot extract authorization server ID from {target_authorization_server}")
                return None

            logger.info(f"Target auth server ID: {target_auth_server_id}")

            logger.info(
                f"Exchanging token for {user_id} -> {resource_name} "
                f"(target auth server: {target_authorization_server})"
            )
            logger.debug(f"User ID token (first 50 chars): {user_id_token[:50] if user_id_token else 'None'}...")
            logger.info(f"Auth config for {resource_name}: {auth_config}")

            # --- Resolve id_token for ID-JAG exchange ---
            # The agent sends an access_token as Bearer. Look up the associated id_token.
            # Fall back to Bearer token directly if no mapping exists (backward compat).
            id_token_for_exchange = user_id_token  # Default fallback
            _xaa_token_source = "agent"

            try:
                token_store = get_user_token_store()
                stored = token_store.lookup(user_id_token)  # Bearer token = access_token

                if stored and stored.get("id_token"):
                    stored_id_token = stored["id_token"]

                    # Check if stored id_token is still valid
                    import time
                    from jose import jwt as jose_jwt
                    try:
                        claims = jose_jwt.get_unverified_claims(stored_id_token)
                        exp = claims.get("exp", 0)

                        if exp > time.time() + 30:  # Valid with 30s buffer
                            id_token_for_exchange = stored_id_token
                            _xaa_token_source = "cache"
                            logger.debug("[XAA] Using stored id_token (source=cache)")
                        else:
                            # id_token expired — try transparent refresh
                            logger.info("[XAA] Stored id_token expired, attempting refresh")
                            refresher = get_token_refresher()
                            fresh_id_token = await refresher.refresh_id_token(user_id_token)

                            if fresh_id_token:
                                id_token_for_exchange = fresh_id_token
                                _xaa_token_source = "refresh"
                                logger.info("[XAA] Using refreshed id_token (source=refresh)")
                            else:
                                logger.warning("[XAA] Refresh failed, using Bearer token (source=agent)")
                    except Exception as e:
                        logger.debug(f"[XAA] Could not check id_token expiry: {e}")
                        id_token_for_exchange = stored_id_token  # Use it anyway
                        _xaa_token_source = "cache"
                else:
                    logger.debug("[XAA] No stored mapping, using Bearer token (source=agent)")
            except Exception as e:
                logger.debug(f"[XAA] Token store lookup failed: {e}, using Bearer token (source=agent)")

            logger.info(
                f"[XAA] Token resolved: source={_xaa_token_source} "
                f"user={user_id} resource={resource_name}"
            )

            # ID-JAG exchange using CrossAppAccessFlow (okta-client-python)
            # Uses agent credentials for JWT signing, exchanges ID token for MCP token
            logger.debug(f"Using ID-JAG flow (CrossAppAccessFlow) for {resource_name}")

            # Check if agent_config is available
            if not agent_config:
                logger.error(f"Cannot use ID-JAG flow: agent_config not provided")
                logger.info(f"Static ID-JAG requires an explicit agent via X-MCP-Agent header")
                return None

            # Extract agent credentials from agent_config
            try:
                agent_id = agent_config.get("agent_id") if isinstance(agent_config, dict) else agent_config.agent_id
                agent_private_key = agent_config.get("private_key") if isinstance(agent_config, dict) else agent_config.private_key
                agent_client_id = agent_config.get("client_id") if isinstance(agent_config, dict) else agent_config.client_id
                agent_principal_id = agent_config.get("principal_id") if isinstance(agent_config, dict) else getattr(agent_config, "principal_id", None)
                okta_domain = os.getenv("OKTA_DOMAIN")

                # Log when CIMD-matched agent provides real Okta credentials
                cimd_url = (agent_config.get("cimd_client_id_url")
                            if isinstance(agent_config, dict)
                            else getattr(agent_config, "cimd_client_id_url", None))
                if cimd_url:
                    logger.info(
                        f"[XAA] Using pre-registered CIMD agent credentials: "
                        f"agent={agent_id} client_id={agent_client_id} "
                        f"(matched from {cimd_url})"
                    )

                logger.debug(f"Creating OktaCrossAppAccessManager for {resource_name} with agent={agent_id}, principal_id={agent_principal_id}")
                cross_app_manager = OktaCrossAppAccessManager(
                    agent_id=agent_id,
                    client_id=agent_client_id,
                    agent_private_key=agent_private_key,
                    okta_domain=okta_domain,
                    target_auth_server_id=target_auth_server_id,
                    principal_id=agent_principal_id,
                )
            except Exception as e:
                logger.error(f"Failed to initialize OktaCrossAppAccessManager: {e}", exc_info=True)
                return None

            # Extract scope info from ResolvedResourceConfigAdapter if available
            _resource_scopes = None
            _scope_condition = None
            if isinstance(resource_config, ResolvedResourceConfigAdapter):
                _resource_scopes = resource_config.scopes
                _scope_condition = resource_config.scope_condition.value if hasattr(resource_config.scope_condition, 'value') else str(resource_config.scope_condition)

            resource_result = await cross_app_manager.exchange_id_token_to_mcp_token(
                user_id_token=id_token_for_exchange,
                resource_name=resource_name,
                target_auth_server_id=target_auth_server_id,
                scopes=requested_scopes,
                resource_scopes=_resource_scopes,
                scope_condition=_scope_condition,
            )

            if not resource_result or not resource_result.get("access_token"):
                logger.error(f"Failed to exchange token for {resource_name}")
                logger.error(f"OAuth exchange result: {resource_result}")
                return None

            access_token = resource_result["access_token"]
            expires_in = resource_result.get("expires_in", 3600)
            logger.info(f"Successfully obtained resource access token for {resource_name}, expires in {expires_in}s")

            # Cache token with expiration
            expires_at = datetime.now() + timedelta(seconds=expires_in - 60)  # Refresh 60s before expiry
            token_data = {
                "token": access_token,
                "expires_at": expires_at,
                "expires_in": expires_in
            }

            self.resource_token_cache.set(user_id, resource_name, token_data, ttl_seconds=expires_in)

            logger.info(
                f"Token exchange complete for {user_id}:{resource_name}, "
                f"access token cached for {expires_in}s"
            )

            return access_token

        except Exception as e:
            logger.error(
                f"Failed to complete token exchange for {user_id} -> {resource_name}: {e}",
                exc_info=True
            )
            return None

    async def _get_vault_secret_token(
        self,
        resource_name: str,
        resource_config,
        agent_config: Optional[Dict[str, Any]],
        user_id_token: str = None,
    ) -> Optional[str]:
        """Retrieve a vault secret via SDK TokenExchangeFlow and return it as a token string.

        Uses a shared cache key pattern: ``secret:{resource}:{connection_id}``
        so all users share the same credential for a given resource+connection.
        """
        if not isinstance(resource_config, ResolvedResourceConfigAdapter):
            logger.error(f"vault-secret requires ResolvedResourceConfigAdapter for {resource_name}")
            return None

        connection_id = resource_config.connection_id
        cache_key_user = f"secret:{resource_name}"
        cache_key_resource = connection_id

        # Check cache
        cached = self.resource_token_cache.get(cache_key_user, cache_key_resource)
        if cached and isinstance(cached, dict) and "token" in cached:
            expires_at = cached.get("expires_at")
            if expires_at and datetime.now() < expires_at:
                logger.debug(f"Using cached vault secret for {resource_name}")
                await emit_audit_event(
                    AuditEventType.VAULT_SECRET_CACHE_HIT,
                    resource_name=resource_name,
                    details={"connection_id": connection_id},
                )
                return cached["token"]

        if not user_id_token:
            logger.error(f"vault-secret requires user_id_token for {resource_name}")
            return None

        # Extract agent credentials (same pattern as XAA)
        if not agent_config:
            logger.error(f"vault-secret requires agent_config for {resource_name}")
            return None

        try:
            agent_id = agent_config.get("agent_id") if isinstance(agent_config, dict) else agent_config.agent_id
            agent_private_key = agent_config.get("private_key") if isinstance(agent_config, dict) else agent_config.private_key
            agent_client_id = agent_config.get("client_id") if isinstance(agent_config, dict) else agent_config.client_id
            agent_principal_id = agent_config.get("principal_id") if isinstance(agent_config, dict) else getattr(agent_config, "principal_id", None)
        except Exception as e:
            logger.error(f"Failed to extract agent credentials for vault-secret: {e}")
            return None

        # Resolve resource ORN from metadata
        metadata = getattr(resource_config, "metadata", None) or {}
        resource_orn = metadata.get("resource_indicator") or metadata.get("resource_orn") or connection_id

        try:
            exchanger = OktaVaultSecretExchanger(
                agent_id=agent_id,
                client_id=agent_client_id,
                agent_private_key=agent_private_key,
                principal_id=agent_principal_id,
            )
        except Exception as e:
            logger.error(f"Failed to create OktaVaultSecretExchanger for {resource_name}: {e}")
            return None

        result = await exchanger.exchange_vault_secret(user_id_token, resource_orn, resource_name=resource_name)

        if not result:
            logger.error(f"Failed to retrieve vault secret for {resource_name} (connection={connection_id})")
            await emit_audit_event(
                AuditEventType.VAULT_SECRET_EXCHANGE_FAILURE,
                AuditSeverity.WARNING,
                resource_name=resource_name,
                details={"connection_id": connection_id, "resource_orn": resource_orn, "reason": "exchange_returned_none"},
                outcome="failure",
            )
            return None

        if result.get("status") == "consent_required":
            logger.warning(f"Vault secret for {resource_name} requires consent — unexpected for vault secrets")
            await emit_audit_event(
                AuditEventType.VAULT_SECRET_EXCHANGE_FAILURE,
                AuditSeverity.WARNING,
                resource_name=resource_name,
                details={"connection_id": connection_id, "resource_orn": resource_orn, "reason": "consent_required"},
                outcome="failure",
            )
            return None

        secret_value = result.get("access_token")
        if not secret_value:
            logger.error(f"Vault secret exchange returned no access_token for {resource_name}")
            await emit_audit_event(
                AuditEventType.VAULT_SECRET_EXCHANGE_FAILURE,
                AuditSeverity.WARNING,
                resource_name=resource_name,
                details={"connection_id": connection_id, "resource_orn": resource_orn, "reason": "no_access_token"},
                outcome="failure",
            )
            return None

        ttl = result.get("expires_in") or 300

        token_data = {
            "token": secret_value,
            "expires_at": datetime.now() + timedelta(seconds=ttl),
            "expires_in": ttl,
        }
        self.resource_token_cache.set(cache_key_user, cache_key_resource, token_data, ttl_seconds=ttl)
        logger.info(f"Vault secret cached for {resource_name} (connection={connection_id}, ttl={ttl}s)")
        await emit_audit_event(
            AuditEventType.VAULT_SECRET_EXCHANGE_SUCCESS,
            resource_name=resource_name,
            details={"connection_id": connection_id, "resource_orn": resource_orn, "expires_in": ttl, "cached": False},
        )
        return secret_value

    async def _get_sts_service_account_token(
        self,
        resource_name: str,
        resource_config,
        agent_config: Optional[Dict[str, Any]],
        user_id_token: str = None,
    ) -> Optional[str]:
        """Retrieve STS service account credentials via SDK TokenExchangeFlow.

        Uses a shared cache key: ``secret:{resource}:{connection_id}``.
        Returns a pre-encoded ``Basic <base64>`` string that callers can use
        directly in an Authorization header.
        """
        if not isinstance(resource_config, ResolvedResourceConfigAdapter):
            logger.error(f"sts-service-account requires ResolvedResourceConfigAdapter for {resource_name}")
            return None

        connection_id = resource_config.connection_id
        cache_key_user = f"secret:{resource_name}"
        cache_key_resource = connection_id

        # Check cache
        cached = self.resource_token_cache.get(cache_key_user, cache_key_resource)
        if cached and isinstance(cached, dict) and "token" in cached:
            expires_at = cached.get("expires_at")
            if expires_at and datetime.now() < expires_at:
                logger.debug(f"Using cached STS service account creds for {resource_name}")
                await emit_audit_event(
                    AuditEventType.STS_SERVICE_ACCOUNT_CACHE_HIT,
                    resource_name=resource_name,
                    details={"connection_id": connection_id},
                )
                return cached["token"]

        if not user_id_token:
            logger.error(f"sts-service-account requires user_id_token for {resource_name}")
            return None

        if not agent_config:
            logger.error(f"sts-service-account requires agent_config for {resource_name}")
            return None

        try:
            agent_id = agent_config.get("agent_id") if isinstance(agent_config, dict) else agent_config.agent_id
            agent_private_key = agent_config.get("private_key") if isinstance(agent_config, dict) else agent_config.private_key
            agent_client_id = agent_config.get("client_id") if isinstance(agent_config, dict) else agent_config.client_id
            agent_principal_id = agent_config.get("principal_id") if isinstance(agent_config, dict) else getattr(agent_config, "principal_id", None)
        except Exception as e:
            logger.error(f"Failed to extract agent credentials for sts-service-account: {e}")
            return None

        metadata = getattr(resource_config, "metadata", None) or {}
        resource_orn = metadata.get("resource_indicator") or metadata.get("resource_orn") or connection_id

        try:
            exchanger = OktaVaultSecretExchanger(
                agent_id=agent_id,
                client_id=agent_client_id,
                agent_private_key=agent_private_key,
                principal_id=agent_principal_id,
            )
        except Exception as e:
            logger.error(f"Failed to create OktaVaultSecretExchanger for {resource_name}: {e}")
            return None

        result = await exchanger.exchange_service_account(user_id_token, resource_orn, resource_name=resource_name)

        if not result:
            logger.error(f"Failed to retrieve STS credentials for {resource_name} (connection={connection_id})")
            await emit_audit_event(
                AuditEventType.STS_SERVICE_ACCOUNT_EXCHANGE_FAILURE,
                AuditSeverity.WARNING,
                resource_name=resource_name,
                details={"connection_id": connection_id, "resource_orn": resource_orn, "reason": "exchange_returned_none"},
                outcome="failure",
            )
            return None

        if result.get("status") == "consent_required":
            logger.warning(f"STS service account for {resource_name} requires consent")
            await emit_audit_event(
                AuditEventType.STS_SERVICE_ACCOUNT_EXCHANGE_FAILURE,
                AuditSeverity.WARNING,
                resource_name=resource_name,
                details={"connection_id": connection_id, "resource_orn": resource_orn, "reason": "consent_required"},
                outcome="failure",
            )
            return None

        # If we got username/password directly, encode as Basic auth
        username = result.get("username")
        password = result.get("password")
        if username and password:
            import base64
            credentials = f"{username}:{password}"
            encoded = base64.b64encode(credentials.encode()).decode()
            token_str = f"Basic {encoded}"
        else:
            # Fall back to Bearer token
            access_token = result.get("access_token")
            if not access_token:
                logger.error(f"STS exchange returned no credentials for {resource_name}")
                await emit_audit_event(
                    AuditEventType.STS_SERVICE_ACCOUNT_EXCHANGE_FAILURE,
                    AuditSeverity.WARNING,
                    resource_name=resource_name,
                    details={"connection_id": connection_id, "resource_orn": resource_orn, "reason": "no_credentials"},
                    outcome="failure",
                )
                return None
            token_str = f"Bearer {access_token}"

        ttl = result.get("expires_in") or 300

        token_data = {
            "token": token_str,
            "expires_at": datetime.now() + timedelta(seconds=ttl),
            "expires_in": ttl,
        }
        self.resource_token_cache.set(cache_key_user, cache_key_resource, token_data, ttl_seconds=ttl)
        logger.info(f"STS service account creds cached for {resource_name} (connection={connection_id}, ttl={ttl}s)")
        await emit_audit_event(
            AuditEventType.STS_SERVICE_ACCOUNT_EXCHANGE_SUCCESS,
            resource_name=resource_name,
            details={"connection_id": connection_id, "resource_orn": resource_orn, "expires_in": ttl, "cached": False},
        )
        return token_str

    async def _exchange_id_jag_simple(
        self,
        user_id_token: str,
        target_auth_server: str,
        resource_url: str,
        auth_config: Dict[str, Any]
    ) -> Optional[Dict[str, Any]]:
        """
        Simple ID-JAG flow without client credentials.
        The user's ID token itself becomes the ID-JAG assertion.
        Target auth server validates it and returns an access token with the specified audience.
        
        This is used when the target MCP only needs to validate the token
        against its auth server and doesn't require additional JWT bearer exchange.
        Works with any agent (Cursor, Claude, Copilot, custom agents, etc.)
        """
        import httpx
        
        target_audience = auth_config.get("target_audience", resource_url)
        
        logger.debug(f"Simple ID-JAG: ID token as assertion, audience={target_audience}")
        
        # Extract auth server endpoint from target_authorization_server
        # E.g., https://domain.okta.com/oauth2/server-id -> https://domain.okta.com/oauth2/server-id/v1/token
        token_endpoint = f"{target_auth_server}/v1/token"
        
        try:
            async with httpx.AsyncClient() as client:
                # Exchange ID-JAG (ID token) for MCP access token
                # No client credentials needed - just assertion + audience
                response = await client.post(
                    token_endpoint,
                    data={
                        "grant_type": "urn:ietf:params:oauth:grant-type:token-exchange",
                        "subject_token": user_id_token,
                        "subject_token_type": "urn:ietf:params:oauth:token-type:id_jag",
                        "requested_token_type": "urn:ietf:params:oauth:token-type:access_token",
                        "audience": target_audience,
                    },
                    timeout=10
                )
                
                if response.status_code != 200:
                    logger.error(
                        f"Simple ID-JAG exchange failed: {response.status_code} - {response.text}"
                    )
                    return None
                
                result = response.json()
                logger.info(
                    f"Simple ID-JAG exchange success: token expires_in={result.get('expires_in')}s"
                )
                
                return {
                    "access_token": result.get("access_token"),
                    "expires_in": result.get("expires_in", 3600),
                    "token_type": result.get("token_type", "Bearer"),
                    "scope": result.get("scope")
                }
        
        except Exception as e:
            logger.error(f"Simple ID-JAG exchange error: {e}", exc_info=True)
            return None
    
    def invalidate_resource_token(
        self,
        user_id: str,
        resource_name: str,
        agent_id: str | None = None,
        connection_id: str | None = None,
    ) -> None:
        """
        Invalidate cached resource token (e.g., after 401 error).

        Forces a new token exchange on next request.

        Args:
            user_id: User identifier
            resource_name: Resource name
            agent_id: Agent ID for connection-scoped isolation (optional)
            connection_id: Okta connection ID for isolation (optional)
        """
        self.resource_token_cache.invalidate(
            user_id, resource_name,
            agent_id=agent_id, connection_id=connection_id,
        )
        logger.info(
            f"Invalidated resource token cache for user={user_id} resource={resource_name} "
            f"agent={agent_id} connection={connection_id}"
        )

    def get_cache_stats(self) -> Dict[str, Any]:
        """
        Get resource token cache statistics.
        
        Returns:
            Cache stats dict
        """
        return self.resource_token_cache.stats()

